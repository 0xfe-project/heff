// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ambiguous 41766
#define TAG_Among 19600
#define TAG_Args 26338
#define TAG_Asked 63168
#define TAG_BadShape 33347
#define TAG_Current 21643
#define TAG_Dropped 56062
#define TAG_Exit 20279
#define TAG_Extra 49222
#define TAG_Failed 62128
#define TAG_Given 9359
#define TAG_Help 25956
#define TAG_Interactive 42932
#define TAG_Kept 49931
#define TAG_Left 13886
#define TAG_Made 39756
#define TAG_Managed 63889
#define TAG_Many 40086
#define TAG_Missing 63220
#define TAG_MissingFlag 20234
#define TAG_MkRunning 3887
#define TAG_NoValue 57584
#define TAG_None 17785
#define TAG_NotIn 31836
#define TAG_One 26866
#define TAG_Own 27154
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_ShutDown 12133
#define TAG_Some 35658
#define TAG_SwitchValue 32207
#define TAG_Under 30640
#define TAG_Unkept 44192
#define TAG_Unknown 64328
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alone 294267509
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_bench 294981194
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_check 295985442
#define LBL_compile 1182349425
#define LBL_complete 145693389
#define LBL_dev 308879
#define LBL_doc 309170
#define LBL_dumpC 297304297
#define LBL_dumpCore 769862998
#define LBL_dumpEval 769928787
#define LBL_entries 787768015
#define LBL_explain 1070179126
#define LBL_filter 672649891
#define LBL_flag 9641011
#define LBL_fmt 311047
#define LBL_form 9644427
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_listing 413833414
#define LBL_long 9823043
#define LBL_lsp 316995
#define LBL_malg 9839318
#define LBL_menu 9843238
#define LBL_message 1186782793
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_project 2070030684
#define LBL_promote 2070130179
#define LBL_publish 2143976274
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_ret 322331
#define LBL_run 322821
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_start 311115900
#define LBL_step 10036115
#define LBL_tests 311609915
#define LBL_text 10052084
#define LBL_tool 10061407
#define LBL_typeAt 1088337976
#define LBL_typing 1088343202
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_view 10114924
static uint32_t shape_build__project__tool[] = {LBL_build, LBL_project, LBL_tool};
static uint32_t shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc[] = {LBL_check, LBL_run, LBL_tests, LBL_bench, LBL_promote, LBL_compile, LBL_explain, LBL_typeAt, LBL_fmt, LBL_doc};
static uint32_t shape_init__get__build__install__publish__dev[] = {LBL_init, LBL_get, LBL_build, LBL_install, LBL_publish, LBL_dev};
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_lsp__version__dumpCore__dumpEval__dumpC[] = {LBL_lsp, LBL_version, LBL_dumpCore, LBL_dumpEval, LBL_dumpC};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_prog__entries__filter__typing__menu__form__alone__listing[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form, LBL_alone, LBL_listing};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_start__step__view[] = {LBL_start, LBL_step, LBL_view};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929(V, V, V, V);
V g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuild_24s765974290x1270238929_clo;
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2ebuildCommands_24rec0_get(void);
V g_app_2eheff_2emain_2ebuildCommands_24rec1_get(void);
V g_app_2eheff_2emain_2ebuildCommands_24rec2_get(void);
V g_app_2eheff_2emain_2ebuildCommands_24rec3_get(void);
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585(V, V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s101399745x11401585_clo;
V g_app_2eheff_2emain_2eexplore_24s376107958x1173426871(V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_clo;
V g_app_2eheff_2emain_2eexplored_24s891876813x19684329(V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplored_24s891876813x19684329_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplored_24s891876813x19684329_clo;
V g_app_2eheff_2emain_2efuelSays_get(void);
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2emain(V, V, V);
V g_app_2eheff_2emain_2emain_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2emain_clo;
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468(V, V, V, V, V, V);
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_clo;
V g_app_2eheff_2emain_2eproject_24s666416962x1755251066(V, V, V);
V g_app_2eheff_2emain_2eproject_24s666416962x1755251066_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eproject_24s666416962x1755251066_clo;
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710(V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprompted_24s1557523500x207701710_clo;
V g_app_2eheff_2emain_2esaid_get(void);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992(V);
V g_app_2eheff_2emain_2etool_24s236854004x1777896992_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etool_24s236854004x1777896992_clo;
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_exception_2eattempted_24s1047538290x862646821_get(void);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_get(void);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032(V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372(V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_clo;
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535(V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784(V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267(V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_clo;
HeffT2 g_list_2efind_24s415920110x337325256_24cpr(V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24f1622709115x782387749(V, V);
V g_list_2ekeepIf_24f1622709115x782387749_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1622709115x782387749_clo;
V g_list_2emap_24s1531382666x123921537(V);
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2einteractive_2eformFilled(V, V);
V g_std_2ecli_2einteractive_2eformFilled_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformFilled_clo;
HeffT2 g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr(V, V);
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
HeffT2 g_std_2ecli_2eproblemOf_24cpr(V, V);
HeffT2 g_std_2ecli_2ereadLine_24cpr(V, V, V);
V g_std_2eprogress_2eshown_24s583895038x1291295401(V, V, V, V);
V g_std_2eprogress_2eshown_24s583895038x1291295401_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s583895038x1291295401_clo;
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400(V, V, V);
V g_std_2eterminal_2einteractWith_24s1999309355x1375671400_entry(V self, V *a);
extern Clo g_std_2eterminal_2einteractWith_24s1999309355x1375671400_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
HEFF_LIT(g_app_2eheff_2emain_2efuelSays_str0, 164, "with fuel (page, c): each loop ticked, so that std.fuel's `limited` stops a loop with no operation in it -- at a cost to every loop -- as a build.hf's `fuel = True`");

static V g_app_2eheff_2emain_2efuelSays_val;
static HEFF_ONCE g_app_2eheff_2emain_2efuelSays_st;
static V g_app_2eheff_2emain_2efuelSays_init(void) {
  return ((V)&g_app_2eheff_2emain_2efuelSays_str0);
}
V g_app_2eheff_2emain_2efuelSays_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2efuelSays_st)) return g_app_2eheff_2emain_2efuelSays_val;
  return heff_global(&g_app_2eheff_2emain_2efuelSays_val, &g_app_2eheff_2emain_2efuelSays_st, g_app_2eheff_2emain_2efuelSays_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_24rec0_str0, 4, "FILE");

static V g_app_2eheff_2emain_2ebuildCommands_24rec0_val;
static HEFF_ONCE g_app_2eheff_2emain_2ebuildCommands_24rec0_st;
static V g_app_2eheff_2emain_2ebuildCommands_24rec0_init(void) {
  return heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24rec0_str0), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
}
V g_app_2eheff_2emain_2ebuildCommands_24rec0_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ebuildCommands_24rec0_st)) return g_app_2eheff_2emain_2ebuildCommands_24rec0_val;
  return heff_global(&g_app_2eheff_2emain_2ebuildCommands_24rec0_val, &g_app_2eheff_2emain_2ebuildCommands_24rec0_st, g_app_2eheff_2emain_2ebuildCommands_24rec0_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_24rec2_str0, 4, "FILE");

static V g_app_2eheff_2emain_2ebuildCommands_24rec2_val;
static HEFF_ONCE g_app_2eheff_2emain_2ebuildCommands_24rec2_st;
static V g_app_2eheff_2emain_2ebuildCommands_24rec2_init(void) {
  return heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_24rec2_str0), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
}
V g_app_2eheff_2emain_2ebuildCommands_24rec2_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2ebuildCommands_24rec2_st)) return g_app_2eheff_2emain_2ebuildCommands_24rec2_val;
  return heff_global(&g_app_2eheff_2emain_2ebuildCommands_24rec2_val, &g_app_2eheff_2emain_2ebuildCommands_24rec2_st, g_app_2eheff_2emain_2ebuildCommands_24rec2_init);
}
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str0, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str1, 55, "elaborate FILE and what it imports; print its interface");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str2, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str3, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str4, 76, "run FILE's main with ARGS, compiled through C (by zig at -O1, in .heff/run/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str5, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str6, 4, "ARGS");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str7, 4, "test");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str8, 263, "check the expectations of the watches (the `-- ...` lines under them) and doc tests (the `-- | ...` lines under them), and run the tests (the definitions of type `Test`, check's), of the FILEs (a directory's .hf files), else of the project's here (src/ and test/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str9, 4, "seed");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str10, 1, "s");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str11, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str12, 64, "the seed the properties draw from (the same seed, the same runs)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str13, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str14, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str15, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str16, 82, "run only the tests whose names it matches, a level each between `/`s: `^lsp/hover`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str17, 4, "jobs");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str18, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str19, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str20, 76, "how many integration tests run at once (HEFF_TEST_JOBS, else half the cores)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str21, 6, "update");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str22, 1, "u");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str23, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str24, 58, "write each golden text the tests keep, not hold them to it");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str25, 5, "watch");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str26, 1, "w");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str27, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str28, 127, "then test again at each change of the FILEs, of what they import, and of the project's sources, until ended (not with --update)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str29, 5, "bench");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str30, 259, "run the benchmarks (the definitions of type `Bench`, bench's) of the FILEs (a directory's .hf files), else of the project's benchmarks here (bench/): each built through C (by zig at -O2), run until a run takes the bench time, and said a line each, as Go's are");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str31, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str32, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str33, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str34, 95, "run only the benchmarks whose names it matches, a level each between `/`s, as `heff test --run`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str35, 4, "time");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str36, 1, "t");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str37, 1, "D");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str38, 92, "how long each is run, at least: a duration (1s, the default; 500ms, 1.5s), or a count (100x)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str39, 5, "count");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str40, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str41, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str42, 33, "run each N times, a line each (1)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str43, 4, "json");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str44, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str45, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str46, 26, "say each as a line of JSON");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str47, 7, "promote");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str48, 67, "write each watch's and doc test's value under it as its expectation");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str49, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str50, 7, "compile");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str51, 164, "FILE compiled, by MODE: esm (an ES module), page (a script running the app NAME in a page), c (a C program running NAME, for `zig cc`); NAME is main, without --name");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str52, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str53, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str54, 3, "OUT");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str55, 4, "name");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str56, 1, "n");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str57, 4, "NAME");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str58, 47, "the computation run (page, c): main, without it");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str59, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str60, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str61, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str62, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str63, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str64, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str65, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str66, 7, "backend");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str67, 1, "b");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str68, 4, "MODE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str69, 22, "what it is compiled to");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str70, 7, "explain");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str71, 21, "the elaboration trace");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str72, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str73, 7, "type-at");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str74, 67, "what the name at each OFFSET resolved to, and its type, a line each");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str75, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str76, 6, "OFFSET");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str77, 3, "fmt");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str78, 21, "format FILEs in place");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str79, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str80, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str81, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str82, 32, "only say which are not formatted");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str83, 3, "doc");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str84, 235, "a reference page, Markdown, of each module of the FILEs (a directory's .hf files), else of the project's here (src/): its header comment, then each definition it exposes, its signature and its doc comment; printed, or written under DIR");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str85, 3, "out");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str86, 1, "o");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str87, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str88, 113, "write each page under DIR, at its module's path (std.path at DIR/std/path.md), and an index of them, DIR/index.md");
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam4, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam7, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam11, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam13, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam15_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam15, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam17_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam17, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam18, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam20, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam22(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam22_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam22, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam21(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam24(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam24_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam24, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam23(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam25(V self, V *args);
Clo g_app_2eheff_2emain_2ebuildCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_entry, 1, 0};

V g_app_2eheff_2emain_2ebuildCommands(V v_c_240) {
top: ;
  V v_check_241 = heff_take_field(v_c_240, 0);
  V v_run_242 = heff_take_field(v_c_240, 1);
  V v_tests_243 = heff_take_field(v_c_240, 2);
  V v_bench_244 = heff_take_field(v_c_240, 3);
  V v_promote_245 = heff_take_field(v_c_240, 4);
  V v_compile_246 = heff_take_field(v_c_240, 5);
  V v_explain_247 = heff_take_field(v_c_240, 6);
  V v_typeAt_248 = heff_take_field(v_c_240, 7);
  V v_fmt_249 = heff_take_field(v_c_240, 8);
  V v_doc_2410 = heff_get_n(v_c_240, 9, 10);
  V v_t_2422 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam0, 1, 1, (V[]){v_check_241})});
  V v_t_2445 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str3), ((V)&g_app_2eheff_2emain_2ebuildCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam2, 1, 1, (V[]){v_run_242})});
  V v_t_2491 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str7), ((V)&g_app_2eheff_2emain_2ebuildCommands_str8), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam5, 1, 1, (V[]){v_tests_243})});
  V v_t_24129 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str29), ((V)&g_app_2eheff_2emain_2ebuildCommands_str30), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam9, 1, 1, (V[]){v_bench_244})});
  V v_t_24141 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str47), ((V)&g_app_2eheff_2emain_2ebuildCommands_str48), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam12, 1, 1, (V[]){v_promote_245})});
  V v_t_24188 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str50), ((V)&g_app_2eheff_2emain_2ebuildCommands_str51), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam14, 1, 1, (V[]){v_compile_246})});
  V v_t_24200 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str70), ((V)&g_app_2eheff_2emain_2ebuildCommands_str71), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam19, 1, 1, (V[]){v_explain_247})});
  V v_t_24215 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str73), ((V)&g_app_2eheff_2emain_2ebuildCommands_str74), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam21, 1, 1, (V[]){v_typeAt_248})});
  V v_t_24231 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str77), ((V)&g_app_2eheff_2emain_2ebuildCommands_str78), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam23, 1, 1, (V[]){v_fmt_249})});
  V v_t_24244 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str83), ((V)&g_app_2eheff_2emain_2ebuildCommands_str84), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam25, 1, 1, (V[]){v_doc_2410})});
  V v_t_24245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24244, NTAG(TAG_Nil)});
  V v_t_24246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24215, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24231, v_t_24245})});
  V v_t_24247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24188, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24200, v_t_24246})});
  V v_t_24248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24129, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24141, v_t_24247})});
  V v_t_24249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2491, v_t_24248})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_24249});
}
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuildCommands(a[0]);
}
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args) {
  V v_x2_2415 = args[0];
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str2);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 2);
    return v_x_2416;
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_check_241 = heff_env(self)[0];
  V v_give_2412 = heff_take_field(v_s_2411, 0);
  V v_pos_2413 = heff_take_field(v_s_2411, 3);
  V v_ap_2414 = heff_get_n(v_s_2411, 1, 4);
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_give_2412), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam1_clo)}));
  V v_t_2419 = heff_tr(heff_call(v_pos_2413, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_2420 = heff_tr(heff_call(heff_dup(v_ap_2414), 2, (V[]){v_t_2418, v_t_2419}));
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tr(heff_call(v_give_2412, 1, (V[]){v_check_241}));
  V f_ = v_ap_2414;
  heff_room[0] = v_t_2421;
  heff_room[1] = v_x_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args) {
  V v_x2_2428 = args[0];
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str5);
  }
  case TAG_Cons: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    heff_take_n(v_x2_2428, 1ULL, 2);
    return v_x_2429;
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args) {
  V v_vs_2434 = args[0];
  switch (heff_tag_of(v_vs_2434)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2434, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2434);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_run_242 = heff_env(self)[0];
  V v_give_2424 = heff_take_field(v_s_2423, 0);
  V v_pos_2425 = heff_take_field(v_s_2423, 3);
  V v_ap_2426 = heff_take_field(v_s_2423, 1);
  V v_flag_2427 = heff_get_n(v_s_2423, 2, 4);
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_give_2424), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam3_clo)}));
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_pos_2425), 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_2433 = heff_tr(heff_call(heff_dup(v_ap_2426), 2, (V[]){v_t_2431, v_t_2432}));
  V v_t_2437 = heff_tr(heff_call(heff_dup(v_give_2424), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam4_clo)}));
  V v_t_2438 = heff_tr(heff_call(v_flag_2427, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec1_get())}));
  V v_y_2439 = heff_tr(heff_call(heff_dup(v_ap_2426), 2, (V[]){v_t_2437, v_t_2438}));
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tr(heff_call(v_give_2424, 1, (V[]){v_run_242}));
  V v_t_2441 = heff_tr(heff_call(heff_dup(v_ap_2426), 2, (V[]){v_t_2440, v_x_2433}));
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_ap_2426), 2, (V[]){v_t_2441, v_y_2439}));
  V v_t_2443 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str6), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_t_2444 = heff_tr(heff_call(v_pos_2425, 1, (V[]){v_t_2443}));
  V f_ = v_ap_2426;
  heff_room[0] = v_t_2442;
  heff_room[1] = v_t_2444;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args) {
  V v_vs_2463 = args[0];
  switch (heff_tag_of(v_vs_2463)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2463, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2463);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args) {
  V v_vs_2475 = args[0];
  switch (heff_tag_of(v_vs_2475)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2475, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2475);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args) {
  V v_vs_2483 = args[0];
  switch (heff_tag_of(v_vs_2483)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2483, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2483);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args) {
  V v_s_2446 = args[0];
  V v_tests_243 = heff_env(self)[0];
  V v_give_2447 = heff_take_field(v_s_2446, 0);
  V v_flag_2448 = heff_take_field(v_s_2446, 2);
  V v_ap_2449 = heff_take_field(v_s_2446, 1);
  V v_pos_2450 = heff_get_n(v_s_2446, 3, 4);
  V v_t_2451 = heff_tr(heff_call(heff_dup(v_give_2447), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2452 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_str10), ((V)&g_app_2eheff_2emain_2ebuildCommands_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_str12), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2453 = heff_tr(heff_call(heff_dup(v_flag_2448), 1, (V[]){v_t_2452}));
  V v_x_2454 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2451, v_t_2453}));
  V v_t_2455 = heff_tr(heff_call(heff_dup(v_give_2447), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2456 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_str14), ((V)&g_app_2eheff_2emain_2ebuildCommands_str15), ((V)&g_app_2eheff_2emain_2ebuildCommands_str16), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2457 = heff_tr(heff_call(heff_dup(v_flag_2448), 1, (V[]){v_t_2456}));
  V v_y_2458 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2455, v_t_2457}));
  V v_t_2459 = heff_tr(heff_call(heff_dup(v_give_2447), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2460 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str17), ((V)&g_app_2eheff_2emain_2ebuildCommands_str18), ((V)&g_app_2eheff_2emain_2ebuildCommands_str19), ((V)&g_app_2eheff_2emain_2ebuildCommands_str20), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2461 = heff_tr(heff_call(heff_dup(v_flag_2448), 1, (V[]){v_t_2460}));
  V v_z_2462 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2459, v_t_2461}));
  V v_t_2466 = heff_tr(heff_call(heff_dup(v_give_2447), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam6_clo)}));
  V v_t_2467 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str21), ((V)&g_app_2eheff_2emain_2ebuildCommands_str22), ((V)&g_app_2eheff_2emain_2ebuildCommands_str23), ((V)&g_app_2eheff_2emain_2ebuildCommands_str24), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2468 = heff_tr(heff_call(heff_dup(v_flag_2448), 1, (V[]){v_t_2467}));
  V v_w_2469 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2466, v_t_2468}));
  heff_clo_take(self, 1);
  V v_t_2470 = heff_tr(heff_call(heff_dup(v_give_2447), 1, (V[]){v_tests_243}));
  V v_t_2471 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2470, v_x_2454}));
  V v_t_2472 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2471, v_y_2458}));
  V v_t_2473 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2472, v_z_2462}));
  V v_t_2474 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2473, v_w_2469}));
  V v_t_2478 = heff_tr(heff_call(heff_dup(v_give_2447), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam7_clo)}));
  V v_t_2479 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str25), ((V)&g_app_2eheff_2emain_2ebuildCommands_str26), ((V)&g_app_2eheff_2emain_2ebuildCommands_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_str28), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2480 = heff_tr(heff_call(heff_dup(v_flag_2448), 1, (V[]){v_t_2479}));
  V v_t_2481 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2478, v_t_2480}));
  V v_t_2482 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2474, v_t_2481}));
  V v_t_2486 = heff_tr(heff_call(v_give_2447, 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam8_clo)}));
  V v_t_2487 = heff_tr(heff_call(v_flag_2448, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec1_get())}));
  V v_t_2488 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2486, v_t_2487}));
  V v_t_2489 = heff_tr(heff_call(heff_dup(v_ap_2449), 2, (V[]){v_t_2482, v_t_2488}));
  V v_t_2490 = heff_tr(heff_call(v_pos_2450, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec2_get())}));
  V f_ = v_ap_2449;
  heff_room[0] = v_t_2489;
  heff_room[1] = v_t_2490;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args) {
  V v_vs_24109 = args[0];
  switch (heff_tag_of(v_vs_24109)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24109, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24109);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args) {
  V v_vs_24121 = args[0];
  switch (heff_tag_of(v_vs_24121)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24121, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24121);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args) {
  V v_s_2492 = args[0];
  V v_bench_244 = heff_env(self)[0];
  V v_give_2493 = heff_take_field(v_s_2492, 0);
  V v_flag_2494 = heff_take_field(v_s_2492, 2);
  V v_ap_2495 = heff_take_field(v_s_2492, 1);
  V v_pos_2496 = heff_get_n(v_s_2492, 3, 4);
  V v_t_2497 = heff_tr(heff_call(heff_dup(v_give_2493), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2498 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str31), ((V)&g_app_2eheff_2emain_2ebuildCommands_str32), ((V)&g_app_2eheff_2emain_2ebuildCommands_str33), ((V)&g_app_2eheff_2emain_2ebuildCommands_str34), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2499 = heff_tr(heff_call(heff_dup(v_flag_2494), 1, (V[]){v_t_2498}));
  V v_x_24100 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_2497, v_t_2499}));
  V v_t_24101 = heff_tr(heff_call(heff_dup(v_give_2493), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24102 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str35), ((V)&g_app_2eheff_2emain_2ebuildCommands_str36), ((V)&g_app_2eheff_2emain_2ebuildCommands_str37), ((V)&g_app_2eheff_2emain_2ebuildCommands_str38), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24103 = heff_tr(heff_call(heff_dup(v_flag_2494), 1, (V[]){v_t_24102}));
  V v_y_24104 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24101, v_t_24103}));
  V v_t_24105 = heff_tr(heff_call(heff_dup(v_give_2493), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24106 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_str40), ((V)&g_app_2eheff_2emain_2ebuildCommands_str41), ((V)&g_app_2eheff_2emain_2ebuildCommands_str42), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24107 = heff_tr(heff_call(heff_dup(v_flag_2494), 1, (V[]){v_t_24106}));
  V v_z_24108 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24105, v_t_24107}));
  V v_t_24112 = heff_tr(heff_call(heff_dup(v_give_2493), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam10_clo)}));
  V v_t_24113 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str43), ((V)&g_app_2eheff_2emain_2ebuildCommands_str44), ((V)&g_app_2eheff_2emain_2ebuildCommands_str45), ((V)&g_app_2eheff_2emain_2ebuildCommands_str46), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24114 = heff_tr(heff_call(heff_dup(v_flag_2494), 1, (V[]){v_t_24113}));
  V v_w_24115 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24112, v_t_24114}));
  heff_clo_take(self, 1);
  V v_t_24116 = heff_tr(heff_call(heff_dup(v_give_2493), 1, (V[]){v_bench_244}));
  V v_t_24117 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24116, v_x_24100}));
  V v_t_24118 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24117, v_y_24104}));
  V v_t_24119 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24118, v_z_24108}));
  V v_t_24120 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24119, v_w_24115}));
  V v_t_24124 = heff_tr(heff_call(v_give_2493, 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam11_clo)}));
  V v_t_24125 = heff_tr(heff_call(v_flag_2494, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec1_get())}));
  V v_t_24126 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24124, v_t_24125}));
  V v_t_24127 = heff_tr(heff_call(heff_dup(v_ap_2495), 2, (V[]){v_t_24120, v_t_24126}));
  V v_t_24128 = heff_tr(heff_call(v_pos_2496, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec2_get())}));
  V f_ = v_ap_2495;
  heff_room[0] = v_t_24127;
  heff_room[1] = v_t_24128;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args) {
  V v_x2_24134 = args[0];
  switch (heff_tag_of(v_x2_24134)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str49);
  }
  case TAG_Cons: {
    V v_x_24135 = heff_field(v_x2_24134, 0);
    heff_take_n(v_x2_24134, 1ULL, 2);
    return v_x_24135;
  }
  default: return heff_nomatch(v_x2_24134);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args) {
  V v_s_24130 = args[0];
  V v_promote_245 = heff_env(self)[0];
  V v_give_24131 = heff_take_field(v_s_24130, 0);
  V v_pos_24132 = heff_take_field(v_s_24130, 3);
  V v_ap_24133 = heff_get_n(v_s_24130, 1, 4);
  V v_t_24137 = heff_tr(heff_call(heff_dup(v_give_24131), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam13_clo)}));
  V v_t_24138 = heff_tr(heff_call(v_pos_24132, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_24139 = heff_tr(heff_call(heff_dup(v_ap_24133), 2, (V[]){v_t_24137, v_t_24138}));
  heff_clo_take(self, 1);
  V v_t_24140 = heff_tr(heff_call(v_give_24131, 1, (V[]){v_promote_245}));
  V f_ = v_ap_24133;
  heff_room[0] = v_t_24140;
  heff_room[1] = v_x_24139;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args) {
  V v_x2_24147 = args[0];
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str52);
  }
  case TAG_Cons: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    heff_take_n(v_x2_24147, 1ULL, 2);
    return v_x_24148;
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args) {
  V v_x2_24153 = args[0];
  switch (heff_tag_of(v_x2_24153)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str53);
  }
  case TAG_Cons: {
    V v_x_24154 = heff_field(v_x2_24153, 0);
    heff_take_n(v_x2_24153, 1ULL, 2);
    return v_x_24154;
  }
  default: return heff_nomatch(v_x2_24153);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args) {
  V v_vs_24164 = args[0];
  HeffT2 v_t_24165 = ({ V a_0 = v_vs_24164; HeffT2 r_ = (g_std_2ecli_2elastS_24cpr(a_0)); heff_drop(v_vs_24164); r_; });
  {
    V v_field_24167 = v_t_24165.f[1];
    int64_t v_tag_24166 = ((int64_t)v_t_24165.f[0]);
    if ((v_tag_24166 == ((int64_t)0ULL))) {
      V v_x_24168 = v_field_24167;
      return v_x_24168;
    } else {
      heff_drop(v_field_24167);
      return ((V)&g_app_2eheff_2emain_2ebuildCommands_str59);
    }
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args) {
  V v_vs_24182 = args[0];
  switch (heff_tag_of(v_vs_24182)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24182, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24182);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args) {
  V v_s_24142 = args[0];
  V v_compile_246 = heff_env(self)[0];
  V v_give_24143 = heff_take_field(v_s_24142, 0);
  V v_pos_24144 = heff_take_field(v_s_24142, 3);
  V v_ap_24145 = heff_take_field(v_s_24142, 1);
  V v_flag_24146 = heff_get_n(v_s_24142, 2, 4);
  V v_t_24150 = heff_tr(heff_call(heff_dup(v_give_24143), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam15_clo)}));
  V v_t_24151 = heff_tr(heff_call(heff_dup(v_pos_24144), 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_24152 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24150, v_t_24151}));
  V v_t_24156 = heff_tr(heff_call(heff_dup(v_give_24143), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam16_clo)}));
  V v_t_24157 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str54), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_24158 = heff_tr(heff_call(v_pos_24144, 1, (V[]){v_t_24157}));
  V v_y_24159 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24156, v_t_24158}));
  V v_t_24160 = heff_tr(heff_call(heff_dup(v_give_24143), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24161 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str55), ((V)&g_app_2eheff_2emain_2ebuildCommands_str56), ((V)&g_app_2eheff_2emain_2ebuildCommands_str57), ((V)&g_app_2eheff_2emain_2ebuildCommands_str58), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24162 = heff_tr(heff_call(heff_dup(v_flag_24146), 1, (V[]){v_t_24161}));
  V v_z_24163 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24160, v_t_24162}));
  V v_t_24169 = heff_tr(heff_call(heff_dup(v_give_24143), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam17_clo)}));
  V v_t_24170 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str60), NTAG(TAG_Nil)});
  V v_t_24171 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str61), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str62), v_t_24170})});
  V v_t_24172 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str63), NTAG(TAG_Nil)});
  V v_t_24173 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str64), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str65), v_t_24172})});
  V v_t_24174 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str66), ((V)&g_app_2eheff_2emain_2ebuildCommands_str67), ((V)&g_app_2eheff_2emain_2ebuildCommands_str68), ((V)&g_app_2eheff_2emain_2ebuildCommands_str69), v_t_24171, NTAG(TAG_False), NTAG(TAG_True), heff_tag_n(TAG_Among, 1, (V[]){v_t_24173})});
  V v_t_24175 = heff_tr(heff_call(heff_dup(v_flag_24146), 1, (V[]){v_t_24174}));
  V v_w_24176 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24169, v_t_24175}));
  heff_clo_take(self, 1);
  V v_t_24177 = heff_tr(heff_call(heff_dup(v_give_24143), 1, (V[]){v_compile_246}));
  V v_t_24178 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24177, v_x_24152}));
  V v_t_24179 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24178, v_y_24159}));
  V v_t_24180 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24179, v_z_24163}));
  V v_t_24181 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24180, v_w_24176}));
  V v_t_24185 = heff_tr(heff_call(v_give_24143, 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam18_clo)}));
  V v_t_24186 = heff_tr(heff_call(v_flag_24146, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec1_get())}));
  V v_t_24187 = heff_tr(heff_call(heff_dup(v_ap_24145), 2, (V[]){v_t_24185, v_t_24186}));
  V f_ = v_ap_24145;
  heff_room[0] = v_t_24181;
  heff_room[1] = v_t_24187;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args) {
  V v_x2_24193 = args[0];
  switch (heff_tag_of(v_x2_24193)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str72);
  }
  case TAG_Cons: {
    V v_x_24194 = heff_field(v_x2_24193, 0);
    heff_take_n(v_x2_24193, 1ULL, 2);
    return v_x_24194;
  }
  default: return heff_nomatch(v_x2_24193);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args) {
  V v_s_24189 = args[0];
  V v_explain_247 = heff_env(self)[0];
  V v_give_24190 = heff_take_field(v_s_24189, 0);
  V v_pos_24191 = heff_take_field(v_s_24189, 3);
  V v_ap_24192 = heff_get_n(v_s_24189, 1, 4);
  V v_t_24196 = heff_tr(heff_call(heff_dup(v_give_24190), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam20_clo)}));
  V v_t_24197 = heff_tr(heff_call(v_pos_24191, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_24198 = heff_tr(heff_call(heff_dup(v_ap_24192), 2, (V[]){v_t_24196, v_t_24197}));
  heff_clo_take(self, 1);
  V v_t_24199 = heff_tr(heff_call(v_give_24190, 1, (V[]){v_explain_247}));
  V f_ = v_ap_24192;
  heff_room[0] = v_t_24199;
  heff_room[1] = v_x_24198;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam22(V self, V *args) {
  V v_x2_24205 = args[0];
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str75);
  }
  case TAG_Cons: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    heff_take_n(v_x2_24205, 1ULL, 2);
    return v_x_24206;
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam21(V self, V *args) {
  V v_s_24201 = args[0];
  V v_typeAt_248 = heff_env(self)[0];
  V v_give_24202 = heff_take_field(v_s_24201, 0);
  V v_pos_24203 = heff_take_field(v_s_24201, 3);
  V v_ap_24204 = heff_get_n(v_s_24201, 1, 4);
  V v_t_24208 = heff_tr(heff_call(heff_dup(v_give_24202), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam22_clo)}));
  V v_t_24209 = heff_tr(heff_call(heff_dup(v_pos_24203), 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_24210 = heff_tr(heff_call(heff_dup(v_ap_24204), 2, (V[]){v_t_24208, v_t_24209}));
  V v_t_24211 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str76), NTAG(TAG_Some), NTAG(TAG_None)});
  V v_y_24212 = heff_tr(heff_call(v_pos_24203, 1, (V[]){v_t_24211}));
  heff_clo_take(self, 1);
  V v_t_24213 = heff_tr(heff_call(v_give_24202, 1, (V[]){v_typeAt_248}));
  V v_t_24214 = heff_tr(heff_call(heff_dup(v_ap_24204), 2, (V[]){v_t_24213, v_x_24210}));
  V f_ = v_ap_24204;
  heff_room[0] = v_t_24214;
  heff_room[1] = v_y_24212;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam24(V self, V *args) {
  V v_vs_24221 = args[0];
  switch (heff_tag_of(v_vs_24221)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24221, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24221);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam23(V self, V *args) {
  V v_s_24216 = args[0];
  V v_fmt_249 = heff_env(self)[0];
  V v_give_24217 = heff_take_field(v_s_24216, 0);
  V v_flag_24218 = heff_take_field(v_s_24216, 2);
  V v_ap_24219 = heff_take_field(v_s_24216, 1);
  V v_pos_24220 = heff_get_n(v_s_24216, 3, 4);
  V v_t_24224 = heff_tr(heff_call(heff_dup(v_give_24217), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam24_clo)}));
  V v_t_24225 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str79), ((V)&g_app_2eheff_2emain_2ebuildCommands_str80), ((V)&g_app_2eheff_2emain_2ebuildCommands_str81), ((V)&g_app_2eheff_2emain_2ebuildCommands_str82), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24226 = heff_tr(heff_call(v_flag_24218, 1, (V[]){v_t_24225}));
  V v_x_24227 = heff_tr(heff_call(heff_dup(v_ap_24219), 2, (V[]){v_t_24224, v_t_24226}));
  V v_y_24228 = heff_tr(heff_call(v_pos_24220, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec3_get())}));
  heff_clo_take(self, 1);
  V v_t_24229 = heff_tr(heff_call(v_give_24217, 1, (V[]){v_fmt_249}));
  V v_t_24230 = heff_tr(heff_call(heff_dup(v_ap_24219), 2, (V[]){v_t_24229, v_x_24227}));
  V f_ = v_ap_24219;
  heff_room[0] = v_t_24230;
  heff_room[1] = v_y_24228;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam25(V self, V *args) {
  V v_s_24232 = args[0];
  V v_doc_2410 = heff_env(self)[0];
  V v_give_24233 = heff_take_field(v_s_24232, 0);
  V v_flag_24234 = heff_take_field(v_s_24232, 2);
  V v_ap_24235 = heff_take_field(v_s_24232, 1);
  V v_pos_24236 = heff_get_n(v_s_24232, 3, 4);
  V v_t_24237 = heff_tr(heff_call(heff_dup(v_give_24233), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24238 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str85), ((V)&g_app_2eheff_2emain_2ebuildCommands_str86), ((V)&g_app_2eheff_2emain_2ebuildCommands_str87), ((V)&g_app_2eheff_2emain_2ebuildCommands_str88), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24239 = heff_tr(heff_call(v_flag_24234, 1, (V[]){v_t_24238}));
  V v_x_24240 = heff_tr(heff_call(heff_dup(v_ap_24235), 2, (V[]){v_t_24237, v_t_24239}));
  V v_y_24241 = heff_tr(heff_call(v_pos_24236, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec2_get())}));
  heff_clo_take(self, 1);
  V v_t_24242 = heff_tr(heff_call(v_give_24233, 1, (V[]){v_doc_2410}));
  V v_t_24243 = heff_tr(heff_call(heff_dup(v_ap_24235), 2, (V[]){v_t_24242, v_x_24240}));
  V f_ = v_ap_24235;
  heff_room[0] = v_t_24243;
  heff_room[1] = v_y_24241;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str0, 3, "lsp");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str1, 34, "a language server, on stdin/stdout");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str2, 5, "FLAGS");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str3, 7, "version");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str4, 68, "which heff this is: its version, as the package.hf it came with says");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str5, 9, "dump-core");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str7, 9, "dump-eval");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str8, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str9, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str10, 6, "dump-c");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str11, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str12, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str14, 3, "OUT");
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam4, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam7, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args);
Clo g_app_2eheff_2emain_2etoolCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_entry, 1, 0};

V g_app_2eheff_2emain_2etoolCommands(V v_c_240) {
top: ;
  V v_lsp_241 = heff_take_field(v_c_240, 0);
  V v_version_242 = heff_rget_v(v_c_240, 1);
  V v_dumpCore_243 = heff_take_field(v_c_240, 2);
  V v_dumpEval_244 = heff_take_field(v_c_240, 3);
  V v_dumpC_245 = heff_get_n(v_c_240, 4, 5);
  V v_t_2413 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam0, 1, 1, (V[]){v_lsp_241})});
  V v_t_2415 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam1, 1, 1, (V[]){v_version_242})});
  V v_t_2422 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str5), ((V)&g_app_2eheff_2emain_2etoolCommands_str6), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam2, 1, 1, (V[]){v_dumpCore_243})});
  V v_t_2434 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str7), ((V)&g_app_2eheff_2emain_2etoolCommands_str8), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam3, 1, 1, (V[]){v_dumpEval_244})});
  V v_t_2454 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str10), ((V)&g_app_2eheff_2emain_2etoolCommands_str11), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam5, 1, 1, (V[]){v_dumpC_245})});
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2455})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2456})});
}
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etoolCommands(a[0]);
}
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lsp_241 = heff_env(self)[0];
  V v_pos_247 = heff_take_field(v_s_246, 3);
  V v_give_248 = heff_take_field(v_s_246, 0);
  V v_ap_249 = heff_get_n(v_s_246, 1, 4);
  V v_t_2410 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str2), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_x_2411 = heff_tr(heff_call(v_pos_247, 1, (V[]){v_t_2410}));
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tr(heff_call(v_give_248, 1, (V[]){v_lsp_241}));
  V f_ = v_ap_249;
  heff_room[0] = v_t_2412;
  heff_room[1] = v_x_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_version_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2414, 0, 4);
  args[0] = v_version_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_dumpCore_243 = heff_env(self)[0];
  V v_pos_2417 = heff_take_field(v_s_2416, 3);
  V v_give_2418 = heff_take_field(v_s_2416, 0);
  V v_ap_2419 = heff_get_n(v_s_2416, 1, 4);
  V v_x_2420 = heff_tr(heff_call(v_pos_2417, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec2_get())}));
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tr(heff_call(v_give_2418, 1, (V[]){v_dumpCore_243}));
  V f_ = v_ap_2419;
  heff_room[0] = v_t_2421;
  heff_room[1] = v_x_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args) {
  V v_x2_2427 = args[0];
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str9);
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    heff_take_n(v_x2_2427, 1ULL, 2);
    return v_x_2428;
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_dumpEval_244 = heff_env(self)[0];
  V v_give_2424 = heff_take_field(v_s_2423, 0);
  V v_pos_2425 = heff_take_field(v_s_2423, 3);
  V v_ap_2426 = heff_get_n(v_s_2423, 1, 4);
  V v_t_2430 = heff_tr(heff_call(heff_dup(v_give_2424), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam4_clo)}));
  V v_t_2431 = heff_tr(heff_call(v_pos_2425, 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_2432 = heff_tr(heff_call(heff_dup(v_ap_2426), 2, (V[]){v_t_2430, v_t_2431}));
  heff_clo_take(self, 1);
  V v_t_2433 = heff_tr(heff_call(v_give_2424, 1, (V[]){v_dumpEval_244}));
  V f_ = v_ap_2426;
  heff_room[0] = v_t_2433;
  heff_room[1] = v_x_2432;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args) {
  V v_x2_2439 = args[0];
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str12);
  }
  case TAG_Cons: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    heff_take_n(v_x2_2439, 1ULL, 2);
    return v_x_2440;
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args) {
  V v_x2_2445 = args[0];
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str13);
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    heff_take_n(v_x2_2445, 1ULL, 2);
    return v_x_2446;
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args) {
  V v_s_2435 = args[0];
  V v_dumpC_245 = heff_env(self)[0];
  V v_give_2436 = heff_take_field(v_s_2435, 0);
  V v_pos_2437 = heff_take_field(v_s_2435, 3);
  V v_ap_2438 = heff_get_n(v_s_2435, 1, 4);
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_give_2436), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam6_clo)}));
  V v_t_2443 = heff_tr(heff_call(heff_dup(v_pos_2437), 1, (V[]){heff_dup(g_app_2eheff_2emain_2ebuildCommands_24rec0_get())}));
  V v_x_2444 = heff_tr(heff_call(heff_dup(v_ap_2438), 2, (V[]){v_t_2442, v_t_2443}));
  V v_t_2448 = heff_tr(heff_call(heff_dup(v_give_2436), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam7_clo)}));
  V v_t_2449 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str14), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2450 = heff_tr(heff_call(v_pos_2437, 1, (V[]){v_t_2449}));
  V v_y_2451 = heff_tr(heff_call(heff_dup(v_ap_2438), 2, (V[]){v_t_2448, v_t_2450}));
  heff_clo_take(self, 1);
  V v_t_2452 = heff_tr(heff_call(v_give_2436, 1, (V[]){v_dumpC_245}));
  V v_t_2453 = heff_tr(heff_call(heff_dup(v_ap_2438), 2, (V[]){v_t_2452, v_x_2444}));
  V f_ = v_ap_2438;
  heff_room[0] = v_t_2453;
  heff_room[1] = v_y_2451;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2esaid_str0, 6, "check ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str1, 7, "--fuel ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str2, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str3, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str4, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str5, 4, "run ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str6, 2, " [");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str7, 1, "]");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str8, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str9, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str10, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str11, 10, " --update ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str12, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str13, 8, "--watch ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str14, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str15, 7, "--fuel ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str16, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str17, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str18, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str19, 5, "test ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str20, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str21, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str22, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str23, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str24, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str25, 8, " --json ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str26, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str27, 7, "--fuel ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str28, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str29, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str30, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str31, 6, "bench ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str32, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str33, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str34, 8, "promote ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str35, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str36, 7, " --fuel");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str37, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str38, 8, "compile ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str39, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str40, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str41, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str42, 8, "explain ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str43, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str44, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str45, 8, "type-at ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str46, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str47, 8, "--check ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str48, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str49, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str50, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str51, 4, "fmt ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str52, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str53, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str54, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str55, 4, "doc ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str56, 1, " ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str57, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str58, 5, "init ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str59, 1, "-");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str60, 4, "get ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str61, 5, "build");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str62, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str63, 8, "install ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str64, 8, "publish ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str65, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str66, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str67, 4, "dev ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str68, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str69, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str70, 4, "lsp ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str71, 7, "version");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str72, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str73, 1, ",");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str74, 10, "dump-core ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str75, 10, "dump-eval ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str76, 7, "dump-c ");
HEFF_LIT(g_app_2eheff_2emain_2esaid_str77, 1, " ");
V g_app_2eheff_2emain_2esaid_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam0, 1, 0};
V g_app_2eheff_2emain_2esaid_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam1, 3, 0};
V g_app_2eheff_2emain_2esaid_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam2, 7, 0};
V g_app_2eheff_2emain_2esaid_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam3, 6, 0};
V g_app_2eheff_2emain_2esaid_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam4, 1, 0};
V g_app_2eheff_2emain_2esaid_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam5, 5, 0};
V g_app_2eheff_2emain_2esaid_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam6, 1, 0};
V g_app_2eheff_2emain_2esaid_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam7, 2, 0};
V g_app_2eheff_2emain_2esaid_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam8, 2, 0};
V g_app_2eheff_2emain_2esaid_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam9, 2, 0};
V g_app_2eheff_2emain_2esaid_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam10, 1, 0};
V g_app_2eheff_2emain_2esaid_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam11, 1, 0};
V g_app_2eheff_2emain_2esaid_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam12, 1, 0};
V g_app_2eheff_2emain_2esaid_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam13, 1, 0};
V g_app_2eheff_2emain_2esaid_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam14, 1, 0};
V g_app_2eheff_2emain_2esaid_lam15(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam15_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam15, 1, 0};
V g_app_2eheff_2emain_2esaid_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam16, 1, 0};
V g_app_2eheff_2emain_2esaid_lam17(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam17_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam17, 1, 0};
V g_app_2eheff_2emain_2esaid_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2esaid_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2esaid_lam18, 2, 0};

static V g_app_2eheff_2emain_2esaid_val;
static HEFF_ONCE g_app_2eheff_2emain_2esaid_st;
static V g_app_2eheff_2emain_2esaid_init(void) {
  return heff_rec_n(3, shape_build__project__tool, (V[]){heff_rec_n(10, shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc, (V[]){((V)&g_app_2eheff_2emain_2esaid_lam0_clo), ((V)&g_app_2eheff_2emain_2esaid_lam1_clo), ((V)&g_app_2eheff_2emain_2esaid_lam2_clo), ((V)&g_app_2eheff_2emain_2esaid_lam3_clo), ((V)&g_app_2eheff_2emain_2esaid_lam4_clo), ((V)&g_app_2eheff_2emain_2esaid_lam5_clo), ((V)&g_app_2eheff_2emain_2esaid_lam6_clo), ((V)&g_app_2eheff_2emain_2esaid_lam7_clo), ((V)&g_app_2eheff_2emain_2esaid_lam8_clo), ((V)&g_app_2eheff_2emain_2esaid_lam9_clo)}), heff_rec_n(6, shape_init__get__build__install__publish__dev, (V[]){((V)&g_app_2eheff_2emain_2esaid_lam10_clo), ((V)&g_app_2eheff_2emain_2esaid_lam11_clo), ((V)&g_app_2eheff_2emain_2esaid_str61), ((V)&g_app_2eheff_2emain_2esaid_lam12_clo), ((V)&g_app_2eheff_2emain_2esaid_lam13_clo), ((V)&g_app_2eheff_2emain_2esaid_lam14_clo)}), heff_rec_n(5, shape_lsp__version__dumpCore__dumpEval__dumpC, (V[]){((V)&g_app_2eheff_2emain_2esaid_lam15_clo), ((V)&g_app_2eheff_2emain_2esaid_str71), ((V)&g_app_2eheff_2emain_2esaid_lam16_clo), ((V)&g_app_2eheff_2emain_2esaid_lam17_clo), ((V)&g_app_2eheff_2emain_2esaid_lam18_clo)})});
}
V g_app_2eheff_2emain_2esaid_get(void) {
  if (HEFF_DONE(g_app_2eheff_2emain_2esaid_st)) return g_app_2eheff_2emain_2esaid_val;
  return heff_global(&g_app_2eheff_2emain_2esaid_val, &g_app_2eheff_2emain_2esaid_st, g_app_2eheff_2emain_2esaid_init);
}
V g_app_2eheff_2emain_2esaid_lam0(V self, V *args) {
  V v_f_240 = args[0];
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str0), v_f_240);
}
V g_app_2eheff_2emain_2esaid_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_u_242 = args[1];
  V v_argv_243 = args[2];
  V v_t_244;
  if ((heff_dup(v_u_242) == NTAG(TAG_True))) {
    heff_drop(v_u_242);
    v_t_244 = ((V)&g_app_2eheff_2emain_2esaid_str1);
  } else {
    heff_drop(v_u_242);
    v_t_244 = ((V)&g_app_2eheff_2emain_2esaid_str2);
  }
  V v_t_247;
  switch (heff_tag_of(v_argv_243)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_app_2eheff_2emain_2esaid_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_argv_243, 0);
    V v_xs_246 = heff_field(v_argv_243, 1);
    heff_take_n(v_argv_243, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str4); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_argv_243);
  }
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str5), v_t_244), v_f_241);
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_app_2eheff_2emain_2esaid_str6)), v_t_247);
  return heff_strAppend(v_t_249, ((V)&g_app_2eheff_2emain_2esaid_str7));
}
V g_app_2eheff_2emain_2esaid_lam2(V self, V *args) {
  V v_sd_2410 = args[0];
  V v_r_2411 = args[1];
  V v_j_2412 = args[2];
  V v_u_2413 = args[3];
  V v_w_2414 = args[4];
  V v_g_2415 = args[5];
  V v_fs_2416 = args[6];
  V v_t_2418;
  switch (heff_tag_of(v_sd_2410)) {
  case TAG_Nothing: {
    v_t_2418 = ((V)&g_app_2eheff_2emain_2esaid_str8);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_sd_2410, 0);
    heff_take_n(v_sd_2410, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_sd_2410);
  }
  V v_t_2420;
  switch (heff_tag_of(v_r_2411)) {
  case TAG_Nothing: {
    v_t_2420 = ((V)&g_app_2eheff_2emain_2esaid_str9);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_field(v_r_2411, 0);
    heff_take_n(v_r_2411, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_r_2411);
  }
  V v_t_2422;
  switch (heff_tag_of(v_j_2412)) {
  case TAG_Nothing: {
    v_t_2422 = ((V)&g_app_2eheff_2emain_2esaid_str10);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_j_2412, 0);
    heff_take_n(v_j_2412, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_j_2412);
  }
  V v_t_2423;
  if ((heff_dup(v_u_2413) == NTAG(TAG_True))) {
    heff_drop(v_u_2413);
    v_t_2423 = ((V)&g_app_2eheff_2emain_2esaid_str11);
  } else {
    heff_drop(v_u_2413);
    v_t_2423 = ((V)&g_app_2eheff_2emain_2esaid_str12);
  }
  V v_t_2424;
  if ((heff_dup(v_w_2414) == NTAG(TAG_True))) {
    heff_drop(v_w_2414);
    v_t_2424 = ((V)&g_app_2eheff_2emain_2esaid_str13);
  } else {
    heff_drop(v_w_2414);
    v_t_2424 = ((V)&g_app_2eheff_2emain_2esaid_str14);
  }
  V v_t_2425;
  if ((heff_dup(v_g_2415) == NTAG(TAG_True))) {
    heff_drop(v_g_2415);
    v_t_2425 = ((V)&g_app_2eheff_2emain_2esaid_str15);
  } else {
    heff_drop(v_g_2415);
    v_t_2425 = ((V)&g_app_2eheff_2emain_2esaid_str16);
  }
  V v_t_2428;
  switch (heff_tag_of(v_fs_2416)) {
  case TAG_Nil: {
    v_t_2428 = ((V)&g_app_2eheff_2emain_2esaid_str17);
    break;
  }
  case TAG_Cons: {
    V v_x_2426 = heff_field(v_fs_2416, 0);
    V v_xs_2427 = heff_field(v_fs_2416, 1);
    heff_take_n(v_fs_2416, 3ULL, 2);
    v_t_2428 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str18); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
    break;
  }
  default: heff_nomatch(v_fs_2416);
  }
  V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str19), v_t_2418), ((V)&g_app_2eheff_2emain_2esaid_str20));
  V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2420), ((V)&g_app_2eheff_2emain_2esaid_str21));
  V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, v_t_2422), v_t_2423);
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, v_t_2424), v_t_2425);
  return heff_strAppend(v_t_2432, v_t_2428);
}
V g_app_2eheff_2emain_2esaid_lam3(V self, V *args) {
  V v_r_2433 = args[0];
  V v_t_2434 = args[1];
  V v_c_2435 = args[2];
  V v_j_2436 = args[3];
  V v_f_2437 = args[4];
  V v_fs_2438 = args[5];
  V v_t_2440;
  switch (heff_tag_of(v_r_2433)) {
  case TAG_Nothing: {
    v_t_2440 = ((V)&g_app_2eheff_2emain_2esaid_str22);
    break;
  }
  case TAG_Just: {
    V v_x_2439 = heff_field(v_r_2433, 0);
    heff_take_n(v_r_2433, 1ULL, 1);
    v_t_2440 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_r_2433);
  }
  V v_t_2442;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_Nothing: {
    v_t_2442 = ((V)&g_app_2eheff_2emain_2esaid_str23);
    break;
  }
  case TAG_Just: {
    V v_x_2441 = heff_field(v_t_2434, 0);
    heff_take_n(v_t_2434, 1ULL, 1);
    v_t_2442 = v_x_2441;
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  V v_t_2444;
  switch (heff_tag_of(v_c_2435)) {
  case TAG_Nothing: {
    v_t_2444 = ((V)&g_app_2eheff_2emain_2esaid_str24);
    break;
  }
  case TAG_Just: {
    V v_x_2443 = heff_field(v_c_2435, 0);
    heff_take_n(v_c_2435, 1ULL, 1);
    v_t_2444 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_c_2435);
  }
  V v_t_2445;
  if ((heff_dup(v_j_2436) == NTAG(TAG_True))) {
    heff_drop(v_j_2436);
    v_t_2445 = ((V)&g_app_2eheff_2emain_2esaid_str25);
  } else {
    heff_drop(v_j_2436);
    v_t_2445 = ((V)&g_app_2eheff_2emain_2esaid_str26);
  }
  V v_t_2446;
  if ((heff_dup(v_f_2437) == NTAG(TAG_True))) {
    heff_drop(v_f_2437);
    v_t_2446 = ((V)&g_app_2eheff_2emain_2esaid_str27);
  } else {
    heff_drop(v_f_2437);
    v_t_2446 = ((V)&g_app_2eheff_2emain_2esaid_str28);
  }
  V v_t_2449;
  switch (heff_tag_of(v_fs_2438)) {
  case TAG_Nil: {
    v_t_2449 = ((V)&g_app_2eheff_2emain_2esaid_str29);
    break;
  }
  case TAG_Cons: {
    V v_x_2447 = heff_field(v_fs_2438, 0);
    V v_xs_2448 = heff_field(v_fs_2438, 1);
    heff_take_n(v_fs_2438, 3ULL, 2);
    v_t_2449 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str30); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
    break;
  }
  default: heff_nomatch(v_fs_2438);
  }
  V v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str31), v_t_2440), ((V)&g_app_2eheff_2emain_2esaid_str32));
  V v_t_2451 = heff_strAppend(heff_strAppend(v_t_2450, v_t_2442), ((V)&g_app_2eheff_2emain_2esaid_str33));
  V v_t_2452 = heff_strAppend(heff_strAppend(v_t_2451, v_t_2444), v_t_2445);
  return heff_strAppend(heff_strAppend(v_t_2452, v_t_2446), v_t_2449);
}
V g_app_2eheff_2emain_2esaid_lam4(V self, V *args) {
  V v_f_2453 = args[0];
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str34), v_f_2453);
}
V g_app_2eheff_2emain_2esaid_lam5(V self, V *args) {
  V v_f_2454 = args[0];
  V v_o_2455 = args[1];
  V v_n_2456 = args[2];
  V v_b_2457 = args[3];
  V v_u_2458 = args[4];
  V v_t_2460;
  switch (heff_tag_of(v_n_2456)) {
  case TAG_Nothing: {
    v_t_2460 = ((V)&g_app_2eheff_2emain_2esaid_str35);
    break;
  }
  case TAG_Just: {
    V v_x_2459 = heff_field(v_n_2456, 0);
    heff_take_n(v_n_2456, 1ULL, 1);
    v_t_2460 = v_x_2459;
    break;
  }
  default: heff_nomatch(v_n_2456);
  }
  V v_t_2461;
  if ((heff_dup(v_u_2458) == NTAG(TAG_True))) {
    heff_drop(v_u_2458);
    v_t_2461 = ((V)&g_app_2eheff_2emain_2esaid_str36);
  } else {
    heff_drop(v_u_2458);
    v_t_2461 = ((V)&g_app_2eheff_2emain_2esaid_str37);
  }
  V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str38), v_f_2454), ((V)&g_app_2eheff_2emain_2esaid_str39));
  V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2462, v_o_2455), ((V)&g_app_2eheff_2emain_2esaid_str40));
  V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2463, v_t_2460), ((V)&g_app_2eheff_2emain_2esaid_str41));
  return heff_strAppend(heff_strAppend(v_t_2464, v_b_2457), v_t_2461);
}
V g_app_2eheff_2emain_2esaid_lam6(V self, V *args) {
  V v_f_2465 = args[0];
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str42), v_f_2465);
}
V g_app_2eheff_2emain_2esaid_lam7(V self, V *args) {
  V v_f_2466 = args[0];
  V v_os_2467 = args[1];
  V v_t_2470;
  switch (heff_tag_of(v_os_2467)) {
  case TAG_Nil: {
    v_t_2470 = ((V)&g_app_2eheff_2emain_2esaid_str43);
    break;
  }
  case TAG_Cons: {
    V v_x_2468 = heff_field(v_os_2467, 0);
    V v_xs_2469 = heff_field(v_os_2467, 1);
    heff_take_n(v_os_2467, 3ULL, 2);
    v_t_2470 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str44); V a_1 = v_x_2468; V a_2 = v_xs_2469; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2469); r_; });
    break;
  }
  default: heff_nomatch(v_os_2467);
  }
  V v_t_2471 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str45), v_f_2466), ((V)&g_app_2eheff_2emain_2esaid_str46));
  return heff_strAppend(v_t_2471, v_t_2470);
}
V g_app_2eheff_2emain_2esaid_lam8(V self, V *args) {
  V v_c_2472 = args[0];
  V v_fs_2473 = args[1];
  V v_t_2474;
  if ((heff_dup(v_c_2472) == NTAG(TAG_True))) {
    heff_drop(v_c_2472);
    v_t_2474 = ((V)&g_app_2eheff_2emain_2esaid_str47);
  } else {
    heff_drop(v_c_2472);
    v_t_2474 = ((V)&g_app_2eheff_2emain_2esaid_str48);
  }
  V v_t_2477;
  switch (heff_tag_of(v_fs_2473)) {
  case TAG_Nil: {
    v_t_2477 = ((V)&g_app_2eheff_2emain_2esaid_str49);
    break;
  }
  case TAG_Cons: {
    V v_x_2475 = heff_field(v_fs_2473, 0);
    V v_xs_2476 = heff_field(v_fs_2473, 1);
    heff_take_n(v_fs_2473, 3ULL, 2);
    v_t_2477 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str50); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
    break;
  }
  default: heff_nomatch(v_fs_2473);
  }
  return heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str51), v_t_2474), v_t_2477);
}
V g_app_2eheff_2emain_2esaid_lam9(V self, V *args) {
  V v_o_2478 = args[0];
  V v_fs_2479 = args[1];
  V v_t_2481;
  switch (heff_tag_of(v_o_2478)) {
  case TAG_Nothing: {
    v_t_2481 = ((V)&g_app_2eheff_2emain_2esaid_str52);
    break;
  }
  case TAG_Just: {
    V v_x_2480 = heff_field(v_o_2478, 0);
    heff_take_n(v_o_2478, 1ULL, 1);
    v_t_2481 = v_x_2480;
    break;
  }
  default: heff_nomatch(v_o_2478);
  }
  V v_t_2484;
  switch (heff_tag_of(v_fs_2479)) {
  case TAG_Nil: {
    v_t_2484 = ((V)&g_app_2eheff_2emain_2esaid_str53);
    break;
  }
  case TAG_Cons: {
    V v_x_2482 = heff_field(v_fs_2479, 0);
    V v_xs_2483 = heff_field(v_fs_2479, 1);
    heff_take_n(v_fs_2479, 3ULL, 2);
    v_t_2484 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str54); V a_1 = v_x_2482; V a_2 = v_xs_2483; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2483); r_; });
    break;
  }
  default: heff_nomatch(v_fs_2479);
  }
  V v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str55), v_t_2481), ((V)&g_app_2eheff_2emain_2esaid_str56));
  return heff_strAppend(v_t_2485, v_t_2484);
}
V g_app_2eheff_2emain_2esaid_lam10(V self, V *args) {
  V v_d_2486 = args[0];
  V v_t_2488;
  switch (heff_tag_of(v_d_2486)) {
  case TAG_Nothing: {
    v_t_2488 = ((V)&g_app_2eheff_2emain_2esaid_str57);
    break;
  }
  case TAG_Just: {
    V v_x_2487 = heff_field(v_d_2486, 0);
    heff_take_n(v_d_2486, 1ULL, 1);
    v_t_2488 = v_x_2487;
    break;
  }
  default: heff_nomatch(v_d_2486);
  }
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str58), v_t_2488);
}
V g_app_2eheff_2emain_2esaid_lam11(V self, V *args) {
  V v_p_2489 = args[0];
  V v_t_2491;
  switch (heff_tag_of(v_p_2489)) {
  case TAG_Nothing: {
    v_t_2491 = ((V)&g_app_2eheff_2emain_2esaid_str59);
    break;
  }
  case TAG_Just: {
    V v_x_2490 = heff_field(v_p_2489, 0);
    heff_take_n(v_p_2489, 1ULL, 1);
    v_t_2491 = v_x_2490;
    break;
  }
  default: heff_nomatch(v_p_2489);
  }
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str60), v_t_2491);
}
V g_app_2eheff_2emain_2esaid_lam12(V self, V *args) {
  V v_d_2492 = args[0];
  V v_t_2494;
  switch (heff_tag_of(v_d_2492)) {
  case TAG_Nothing: {
    v_t_2494 = ((V)&g_app_2eheff_2emain_2esaid_str62);
    break;
  }
  case TAG_Just: {
    V v_x_2493 = heff_field(v_d_2492, 0);
    heff_take_n(v_d_2492, 1ULL, 1);
    v_t_2494 = v_x_2493;
    break;
  }
  default: heff_nomatch(v_d_2492);
  }
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str63), v_t_2494);
}
V g_app_2eheff_2emain_2esaid_lam13(V self, V *args) {
  V v_v_2495 = args[0];
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str64), v_v_2495);
}
V g_app_2eheff_2emain_2esaid_lam14(V self, V *args) {
  V v_argv_2496 = args[0];
  V v_t_2499;
  switch (heff_tag_of(v_argv_2496)) {
  case TAG_Nil: {
    v_t_2499 = ((V)&g_app_2eheff_2emain_2esaid_str65);
    break;
  }
  case TAG_Cons: {
    V v_x_2497 = heff_field(v_argv_2496, 0);
    V v_xs_2498 = heff_field(v_argv_2496, 1);
    heff_take_n(v_argv_2496, 3ULL, 2);
    v_t_2499 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str66); V a_1 = v_x_2497; V a_2 = v_xs_2498; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2498); r_; });
    break;
  }
  default: heff_nomatch(v_argv_2496);
  }
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str67), v_t_2499);
}
V g_app_2eheff_2emain_2esaid_lam15(V self, V *args) {
  V v_fs_24100 = args[0];
  V v_t_24103;
  switch (heff_tag_of(v_fs_24100)) {
  case TAG_Nil: {
    v_t_24103 = ((V)&g_app_2eheff_2emain_2esaid_str68);
    break;
  }
  case TAG_Cons: {
    V v_x_24101 = heff_field(v_fs_24100, 0);
    V v_xs_24102 = heff_field(v_fs_24100, 1);
    heff_take_n(v_fs_24100, 3ULL, 2);
    v_t_24103 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str69); V a_1 = v_x_24101; V a_2 = v_xs_24102; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24102); r_; });
    break;
  }
  default: heff_nomatch(v_fs_24100);
  }
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str70), v_t_24103);
}
V g_app_2eheff_2emain_2esaid_lam16(V self, V *args) {
  V v_fs_24104 = args[0];
  V v_t_24107;
  switch (heff_tag_of(v_fs_24104)) {
  case TAG_Nil: {
    v_t_24107 = ((V)&g_app_2eheff_2emain_2esaid_str72);
    break;
  }
  case TAG_Cons: {
    V v_x_24105 = heff_field(v_fs_24104, 0);
    V v_xs_24106 = heff_field(v_fs_24104, 1);
    heff_take_n(v_fs_24104, 3ULL, 2);
    v_t_24107 = ({ V a_0 = ((V)&g_app_2eheff_2emain_2esaid_str73); V a_1 = v_x_24105; V a_2 = v_xs_24106; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24106); r_; });
    break;
  }
  default: heff_nomatch(v_fs_24104);
  }
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str74), v_t_24107);
}
V g_app_2eheff_2emain_2esaid_lam17(V self, V *args) {
  V v_f_24108 = args[0];
  return heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str75), v_f_24108);
}
V g_app_2eheff_2emain_2esaid_lam18(V self, V *args) {
  V v_f_24109 = args[0];
  V v_o_24110 = args[1];
  V v_t_24111 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2esaid_str76), v_f_24109), ((V)&g_app_2eheff_2emain_2esaid_str77));
  return heff_strAppend(v_t_24111, v_o_24110);
}
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s666416962x1755251066_str0, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s666416962x1755251066_str1, 1, ".");
V g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam0, 1, 0};
V g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam1, 1, 0};
Clo g_app_2eheff_2emain_2eproject_24s666416962x1755251066_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s666416962x1755251066_entry, 3, 0};

V g_app_2eheff_2emain_2eproject_24s666416962x1755251066(V v_clock_240, V v_ex_241, V v_cu_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2edevCmd_24s1799196592x1252394372_clo), 3, (V[]){v_clock_240, v_ex_241, v_cu_242}));
  return heff_rec_n(6, shape_init__get__build__install__publish__dev, (V[]){((V)&g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam0_clo), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_clo), heff_dup(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_get()), ((V)&g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam1_clo), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_clo), v_t_243});
}
V g_app_2eheff_2emain_2eproject_24s666416962x1755251066_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eproject_24s666416962x1755251066(a[0], a[1], a[2]);
}
V g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam0(V self, V *args) {
  V v_dir_244 = args[0];
  V v_t_246;
  switch (heff_tag_of(v_dir_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_app_2eheff_2emain_2eproject_24s666416962x1755251066_str0);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_dir_244, 0);
    heff_take_n(v_dir_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_dir_244);
  }
  V f_ = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_clo);
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2eproject_24s666416962x1755251066_lam1(V self, V *args) {
  V v_dir_247 = args[0];
  V v_t_249;
  switch (heff_tag_of(v_dir_247)) {
  case TAG_Nothing: {
    v_t_249 = ((V)&g_app_2eheff_2emain_2eproject_24s666416962x1755251066_str1);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_dir_247, 0);
    heff_take_n(v_dir_247, 1ULL, 1);
    v_t_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_dir_247);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1493138617x999908032_clo);
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_app_2eheff_2emain_2edispatch_24s101399745x11401585_str0, 4, "heff");
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585_lam1(V self, V *args);
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585_lam0(V self, V *args);
Clo g_app_2eheff_2emain_2edispatch_24s101399745x11401585_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2edispatch_24s101399745x11401585_entry, 5, 0};

V g_app_2eheff_2emain_2edispatch_24s101399745x11401585(V v_clock_240, V v_rx_241, V v_ex_242, V v_cu_243, V v_argv_244) {
top: ;
  V v_t_245 = (g_app_2eheff_2emain_2ebuild_24s765974290x1270238929(heff_dup(v_clock_240), v_rx_241, heff_dup(v_ex_242), heff_dup(v_cu_243)));
  V v_t_246 = (g_app_2eheff_2emain_2eproject_24s666416962x1755251066(v_clock_240, heff_dup(v_ex_242), v_cu_243));
  V v_t_247 = ({ V a_0 = v_ex_242; V r_ = (g_app_2eheff_2emain_2etool_24s236854004x1777896992(a_0)); heff_drop(v_ex_242); r_; });
  V v_t_248 = (g_app_2eheff_2emain_2ebuildCommands(v_t_245));
  V v_t_249 = (g_app_2eheff_2emain_2eprojectCommands(v_t_246));
  V v_t_2410 = (g_app_2eheff_2emain_2etoolCommands(v_t_247));
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
  V v_t_2412 = (g_prelude_2e_2b_2b(v_t_248, v_t_2411));
  HeffT2 v_t_2413 = (g_std_2ecli_2ereadLine_24cpr(((V)&g_app_2eheff_2emain_2edispatch_24s101399745x11401585_str0), v_t_2412, v_argv_244));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_text_2416 = v_field_2415;
      return heff_clo_n(g_app_2eheff_2emain_2edispatch_24s101399745x11401585_lam0, 2, 1, (V[]){v_text_2416});
    } else {
      if ((v_tag_2414 == ((int64_t)1ULL))) {
        V v_text_2432 = v_field_2415;
        V v_t_2433 = heff_tag_n(TAG_Write, 2, (V[]){v_text_2432, NTAG(TAG_MkUnit)});
        V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
        V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
        V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
        return heff_tail(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      } else {
        V v_act_2439 = v_field_2415;
        return v_act_2439;
      }
    }
  }
}
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_app_2eheff_2emain_2edispatch_24s101399745x11401585(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2417, v_k_2418));
}
V g_app_2eheff_2emain_2edispatch_24s101399745x11401585_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_text_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_text_2416, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_2417), heff_clo_n(g_app_2eheff_2emain_2edispatch_24s101399745x11401585_lam1, 1, 2, (V[]){v_hd_2417, v_k_2418})));
}
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_str0, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_str1, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_str2, 4, "heff");
V g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_lam0(V self, V *args);
Clo g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_entry, 7, 0};

V g_app_2eheff_2emain_2eexplore_24s376107958x1173426871(V v_clock_240, V v_rx_241, V v_ex_242, V v_cu_243, V v_x1_244, V v_z_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
    V v_t_247 = (g_app_2eheff_2emain_2ebuild_24s765974290x1270238929(heff_dup(v_clock_240), heff_dup(v_rx_241), heff_dup(v_ex_242), heff_dup(v_cu_243)));
    V v_t_248 = (g_app_2eheff_2emain_2eproject_24s666416962x1755251066(heff_dup(v_clock_240), heff_dup(v_ex_242), heff_dup(v_cu_243)));
    V v_t_249 = (g_app_2eheff_2emain_2etool_24s236854004x1777896992(v_ex_242));
    V v_t_2410 = (g_app_2eheff_2emain_2ebuildCommands(v_t_247));
    V v_t_2411 = (g_app_2eheff_2emain_2eprojectCommands(v_t_248));
    V v_t_2412 = (g_app_2eheff_2emain_2etoolCommands(v_t_249));
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
    V v_t_2414 = (g_list_2ekeepIf_24f1622709115x782387749(v_t_2410, v_t_2413));
    V v_es_2415 = (g_list_2emap_24s1531382666x123921537(v_t_2414));
    V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2417 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_str1)), v_t_2416});
    V v_t_2418 = heff_rec_n(8, shape_prog__entries__filter__typing__menu__form__alone__listing, (V[]){((V)&g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_str2), v_es_2415, v_t_2417, NTAG(TAG_False), heff_dup(g_std_2eterminal_2ewidget_2emenu_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_Nothing)});
    V v_t_2419 = heff_rec_n(3, shape_start__step__view, (V[]){v_t_2418, ((V)&g_std_2ecli_2einteractive_2estep_clo), ((V)&g_std_2ecli_2einteractive_2eview_clo)});
    return (g_std_2eterminal_2einteractWith_24s1999309355x1375671400(v_t_2419, heff_dup(v_z_245), heff_clo_n(g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_lam0, 1, 6, (V[]){v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_z_245, v_z_246})));
  } else {
    V v_t_2421 = ({ V a_0 = v_clock_240; V a_1 = v_rx_241; V a_2 = v_ex_242; V a_3 = v_cu_243; V b_4 = NTAG(TAG_Nil); V r_ = heff_tr(g_app_2eheff_2emain_2edispatch_24s101399745x11401585(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    return heff_tail(v_t_2421, 2, (V[]){v_z_245, v_z_246});
  }
}
V g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_app_2eheff_2emain_2eexplore_24s376107958x1173426871(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
V g_app_2eheff_2emain_2eexplore_24s376107958x1173426871_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_rx_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_cu_243 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_app_2eheff_2emain_2eexplored_24s891876813x19684329(v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_x_2420, v_z_245, v_z_246));
}
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam0, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam2, 1, 0};
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam3(V self, V *args);
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_entry, 6, 0};

V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468(V v_clock_240, V v_rx_241, V v_ex_242, V v_cu_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s535099379x685970669(v_t_2412, heff_dup(v_hd_244), heff_clo_n(g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam1, 1, 6, (V[]){v_hd_244, v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_k_245})));
}
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eprogram_24s20467304x1811691468(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam0(V self, V *args) {
  V v_a_246 = args[0];
  return v_a_246;
}
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam2(V self, V *args) {
  V v_b_2414 = args[0];
  return v_b_2414;
}
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_rx_241 = heff_env(self)[1];
  V v_ex_242 = heff_env(self)[2];
  V v_cu_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_clock_240; V a_1 = v_rx_241; V a_2 = v_ex_242; V a_3 = v_cu_243; V a_4 = v_x_2418; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_app_2eheff_2emain_2eexplore_24s376107958x1173426871(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2418); r_; });
}
V g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_clock_240 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_ex_242 = heff_env(self)[3];
  V v_cu_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nil: {
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Interactive, 1, (V[]){((V)&g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam2_clo)})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    heff_clo_take(self, 6);
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_244), heff_clo_n(g_app_2eheff_2emain_2eprogram_24s20467304x1811691468_lam3, 1, 6, (V[]){v_clock_240, v_rx_241, v_ex_242, v_cu_243, v_hd_244, v_k_245})));
  }
  case TAG_Cons: {
    V v_t_2421 = (g_app_2eheff_2emain_2ebuildCommands(heff_dup(heff_rfield(g_app_2eheff_2emain_2esaid_get(), 0))));
    V v_t_2422 = (g_app_2eheff_2emain_2eprojectCommands(heff_dup(heff_rfield(g_app_2eheff_2emain_2esaid_get(), 1))));
    V v_t_2423 = (g_app_2eheff_2emain_2etoolCommands(heff_dup(heff_rfield(g_app_2eheff_2emain_2esaid_get(), 2))));
    V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2422, v_t_2423));
    V v_t_2425 = (g_list_2ekeepIf_24f1622709115x782387749(v_t_2421, v_t_2424));
    V v_es_2426 = (g_list_2emap_24s1531382666x123921537(v_t_2425));
    V v_x2_2427 = heff_dup(v_x_2413);
    V v_t_2462;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      heff_drop(v_es_2426);
      v_t_2462 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_name_2428 = heff_field(v_x2_2427, 0);
      V v_ws_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      HeffT2 v_t_2430 = ({ V a_0 = v_name_2428; V a_1 = v_es_2426; HeffT2 r_ = (g_list_2efind_24s415920110x337325256_24cpr(a_0, a_1)); heff_drop(v_name_2428); heff_drop(v_es_2426); r_; });
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_e_2433 = v_field_2432;
          V v_sh_2434 = heff_dup(heff_rfield(v_e_2433, 2));
          HeffT2 v_t_2435 = (g_std_2ecli_2eproblemOf_24cpr(heff_dup(v_sh_2434), heff_dup(v_ws_2429)));
          {
            V v_field_2437 = v_t_2435.f[1];
            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
            if ((v_tag_2436 == ((int64_t)0ULL))) {
              V v_it1_2438 = v_field_2437;
              switch (heff_tag_of(v_it1_2438)) {
              case TAG_Unknown: {
                heff_take_n(v_it1_2438, 0ULL, 2);
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_NoValue: {
                heff_take_n(v_it1_2438, 0ULL, 1);
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SwitchValue: {
                heff_take_n(v_it1_2438, 0ULL, 1);
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Ambiguous: {
                heff_take_n(v_it1_2438, 0ULL, 2);
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_MissingFlag: {
                V v_ru_24it1_2438_24MissingFlag = heff_take_reuse_n(v_it1_2438, 0ULL, 1);
                HeffT2 v_t_2446 = (g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr(v_sh_2434, v_ws_2429));
                {
                  V v_field_2448 = v_t_2446.f[1];
                  int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
                  if ((v_tag_2447 == ((int64_t)0ULL))) {
                    V v_sp_2449 = v_field_2448;
                    V v_t_2450 = (g_std_2ecli_2einteractive_2eformFilled(v_e_2433, v_sp_2449));
                    v_t_2462 = heff_tag_at_n(v_ru_24it1_2438_24MissingFlag, TAG_Just, 1, (V[]){v_t_2450});
                  } else {
                    heff_drop_rec(v_e_2433, 3);
                    heff_drop_cell(v_ru_24it1_2438_24MissingFlag, 1);
                    heff_drop(v_field_2448);
                    v_t_2462 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              case TAG_NotIn: {
                heff_take_n(v_it1_2438, 0ULL, 3);
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Missing: {
                V v_ru_24it1_2438_24Missing = heff_take_reuse_n(v_it1_2438, 0ULL, 1);
                HeffT2 v_t_2455 = (g_std_2ecli_2einteractive_2elackingOnly_2efitting_240_24cpr(v_sh_2434, v_ws_2429));
                {
                  V v_field_2457 = v_t_2455.f[1];
                  int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
                  if ((v_tag_2456 == ((int64_t)0ULL))) {
                    V v_sp_2458 = v_field_2457;
                    V v_t_2459 = (g_std_2ecli_2einteractive_2eformFilled(v_e_2433, v_sp_2458));
                    v_t_2462 = heff_tag_at_n(v_ru_24it1_2438_24Missing, TAG_Just, 1, (V[]){v_t_2459});
                  } else {
                    heff_drop_rec(v_e_2433, 3);
                    heff_drop_cell(v_ru_24it1_2438_24Missing, 1);
                    heff_drop(v_field_2457);
                    v_t_2462 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              case TAG_Extra: {
                heff_take_n(v_it1_2438, 0ULL, 1);
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Help: {
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_BadShape: {
                heff_take_n(v_it1_2438, 0ULL, 1);
                heff_drop(v_ws_2429);
                heff_drop_rec(v_e_2433, 3);
                heff_drop(v_sh_2434);
                v_t_2462 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_it1_2438);
              }
            } else {
              heff_drop(v_ws_2429);
              heff_drop_rec(v_e_2433, 3);
              heff_drop(v_sh_2434);
              heff_drop(v_field_2437);
              v_t_2462 = NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_ws_2429);
          heff_drop(v_field_2432);
          v_t_2462 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    heff_clo_take(self, 6);
    return ({ V a_0 = v_clock_240; V a_1 = v_rx_241; V a_2 = v_ex_242; V a_3 = v_cu_243; V a_4 = v_x_2413; V a_5 = v_t_2462; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_app_2eheff_2emain_2eprompted_24s1557523500x207701710(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop_tag(v_x_2413, 2); r_; });
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_app_2eheff_2emain_2emain_str0, 2, ": ");
HEFF_LIT(g_app_2eheff_2emain_2emain_str1, 2, ": ");
HEFF_LIT(g_app_2eheff_2emain_2emain_str2, 6, "heff: ");
HEFF_LIT(g_app_2eheff_2emain_2emain_str3, 1, "\012");
V g_app_2eheff_2emain_2emain_lam1(V self, V *args);
V g_app_2eheff_2emain_2emain_lam2(V self, V *args);
V g_app_2eheff_2emain_2emain_lam3(V self, V *args);
V g_app_2eheff_2emain_2emain_lam4(V self, V *args);
V g_app_2eheff_2emain_2emain_lam7(V self, V *args);
V g_app_2eheff_2emain_2emain_lam6(V self, V *args);
V g_app_2eheff_2emain_2emain_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam5, 1, 0};
V g_app_2eheff_2emain_2emain_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam0, 1, 0};
V g_app_2eheff_2emain_2emain_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam8, 1, 0};
V g_app_2eheff_2emain_2emain_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam9, 1, 0};
V g_app_2eheff_2emain_2emain_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam10, 1, 0};
V g_app_2eheff_2emain_2emain_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam11, 1, 0};
V g_app_2eheff_2emain_2emain_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam12, 3, 0};
V g_app_2eheff_2emain_2emain_lam15(V self, V *args);
V g_app_2eheff_2emain_2emain_lam14(V self, V *args);
V g_app_2eheff_2emain_2emain_lam13(V self, V *args);
Clo g_app_2eheff_2emain_2emain_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_entry, 3, 0};

V g_app_2eheff_2emain_2emain(V v_z_240, V v_z_241, V v_z_242) {
top: ;
  V v_t_2447 = heff_rec_n(3, shape_ret__bind__malg, (V[]){heff_dup(heff_rfield(g_exception_2eattempted_24s1047538290x862646821_get(), 0)), heff_dup(heff_rfield(g_exception_2eattempted_24s1047538290x862646821_get(), 1)), ((V)&g_app_2eheff_2emain_2emain_lam0_clo)});
  V v_c_2458 = heff_tr(g_app_2eheff_2emain_2eprogram_24s20467304x1811691468(((V)&g_app_2eheff_2emain_2emain_lam8_clo), ((V)&g_app_2eheff_2emain_2emain_lam9_clo), ((V)&g_app_2eheff_2emain_2emain_lam10_clo), ((V)&g_app_2eheff_2emain_2emain_lam11_clo), v_t_2447, ((V)&g_app_2eheff_2emain_2emain_lam12_clo)));
  return (g_std_2eprogress_2eshown_24s583895038x1291295401(heff_clo_n(g_app_2eheff_2emain_2emain_lam13, 2, 1, (V[]){v_c_2458}), v_z_240, v_z_241, v_z_242));
}
V g_app_2eheff_2emain_2emain_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2emain(a[0], a[1], a[2]);
}
V g_app_2eheff_2emain_2emain_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_drop(v_hd_2414);
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_drop(v_hd_2418);
  heff_clo_take(self, 1);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_x_2423 = heff_env(self)[0];
  heff_drop(v_hd_2424);
  heff_clo_take(self, 1);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_x_2432 = heff_env(self)[0];
  heff_drop(v_hd_2433);
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  V v_k_2439 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_x_2443 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_k_2439);
    V f_ = v_k_2441;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2443});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2444 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    heff_clo_take(self, 2);
    V v_x_2445 = heff_tr(heff_call(v_k_2439, 1, (V[]){v_y_2444}));
    V f_ = v_k_2441;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2445});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_app_2eheff_2emain_2emain_lam6(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_m_2438 = heff_env(self)[0];
  V v_k_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_m_2438;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_app_2eheff_2emain_2emain_lam7, 1, 2, (V[]){v_k_2441, v_k_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2emain_lam5(V self, V *args) {
  V v_r_2437 = args[0];
  switch (heff_tag_of(v_r_2437)) {
  case TAG_MkRunning: {
    V v_m_2438 = heff_field(v_r_2437, 0);
    V v_k_2439 = heff_field(v_r_2437, 1);
    heff_take_n(v_r_2437, 3ULL, 2);
    return heff_clo_n(g_app_2eheff_2emain_2emain_lam6, 2, 2, (V[]){v_m_2438, v_k_2439});
  }
  default: return heff_nomatch(v_r_2437);
  }
}
V g_app_2eheff_2emain_2emain_lam0(V self, V *args) {
  V v_p_243 = args[0];
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_t_244 = heff_field(v_p_243, 0);
    heff_take_n(v_p_243, 1ULL, 1);
    V v_x2_245 = v_t_244;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Asked: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_Made: {
        heff_take_n(v_x21_246, 0ULL, 3);
        return heff_abandon();
      }
      case TAG_ShutDown: {
        heff_take_n(v_x21_246, 0ULL, 2);
        return heff_abandon();
      }
      case TAG_Dropped: {
        V v_x_2413 = heff_field(v_x21_246, 1);
        heff_take_n(v_x21_246, 2ULL, 2);
        return heff_clo_n(g_app_2eheff_2emain_2emain_lam1, 2, 1, (V[]){v_x_2413});
      }
      case TAG_Own: {
        V v_x_2417 = heff_field(v_x21_246, 1);
        heff_take_n(v_x21_246, 2ULL, 2);
        return heff_clo_n(g_app_2eheff_2emain_2emain_lam2, 2, 1, (V[]){v_x_2417});
      }
      case TAG_Failed: {
        heff_take_n(v_x21_246, 0ULL, 2);
        return heff_abandon();
      }
      case TAG_Current: {
        V v_k_2422 = heff_field(v_x21_246, 0);
        heff_take_n(v_x21_246, 1ULL, 1);
        V v_x_2423 = heff_tr(heff_call(v_k_2422, 1, (V[]){NTAG(TAG_Nothing)}));
        return heff_clo_n(g_app_2eheff_2emain_2emain_lam3, 2, 1, (V[]){v_x_2423});
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    case TAG_Given: {
      V v_x21_2426 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      switch (heff_tag_of(v_x21_2426)) {
      case TAG_Managed: {
        heff_take_n(v_x21_2426, 0ULL, 3);
        return heff_abandon();
      }
      case TAG_Kept: {
        V v_k_2431 = heff_field(v_x21_2426, 1);
        heff_take_n(v_x21_2426, 2ULL, 2);
        V v_x_2432 = heff_tr(heff_call(v_k_2431, 1, (V[]){NTAG(TAG_Unkept)}));
        return heff_clo_n(g_app_2eheff_2emain_2emain_lam4, 2, 1, (V[]){v_x_2432});
      }
      case TAG_Under: {
        V v_s_2436 = heff_field(v_x21_2426, 1);
        heff_take_n(v_x21_2426, 2ULL, 2);
        V f_ = v_s_2436;
        args[0] = ((V)&g_app_2eheff_2emain_2emain_lam5_clo);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x21_2426);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  case TAG_InR: {
    V v_q_2446 = heff_field(v_p_243, 0);
    heff_take_n(v_p_243, 1ULL, 1);
    V f_ = heff_dup(heff_rfield(g_exception_2eattempted_24s1047538290x862646821_get(), 2));
    args[0] = v_q_2446;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_app_2eheff_2emain_2emain_lam8(V self, V *args) {
  V v_p_2324446_2448 = args[0];
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2324446_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return heff_tag_n(TAG_InR, 1, (V[]){v_t_2450});
}
V g_app_2eheff_2emain_2emain_lam9(V self, V *args) {
  V v_p_2324446_2451 = args[0];
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_2324446_2451})});
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
}
V g_app_2eheff_2emain_2emain_lam10(V self, V *args) {
  V v_p_2324446_2453 = args[0];
  return heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_p_2324446_2453})});
}
V g_app_2eheff_2emain_2emain_lam11(V self, V *args) {
  V v_p_2324446_2454 = args[0];
  return heff_tag_n(TAG_InL, 1, (V[]){v_p_2324446_2454});
}
V g_app_2eheff_2emain_2emain_lam12(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2456 = args[1];
  V v_k_2457 = args[2];
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam15(V self, V *args) {
  V v_x_2480 = args[0];
  V v_malg_2464 = heff_env(self)[0];
  V v_bind_2465 = heff_env(self)[1];
  V v_p_2466 = heff_env(self)[2];
  heff_drop(v_x_2480);
  V v_t_2481 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  heff_clo_take(self, 3);
  V v_t_2486 = heff_tr(heff_call(v_malg_2464, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})}));
  V f_ = v_bind_2465;
  heff_room[0] = v_t_2486;
  heff_room[1] = v_p_2466;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2emain_lam14(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_2459 = heff_env(self)[0];
  V v_k_2460 = heff_env(self)[1];
  V v_x1_2462 = v_x_2461;
  heff_clo_take(self, 2);
  V v_p_2463 = v_hd_2459;
  V v_malg_2464 = heff_take_field(v_p_2463, 2);
  V v_bind_2465 = heff_get_n(v_p_2463, 1, 3);
  V v_p_2466 = v_k_2460;
  switch (heff_tag_of(v_x1_2462)) {
  case TAG_Left: {
    V v_err_2467 = heff_field(v_x1_2462, 0);
    V v_ru_24x1_2462_24Left = heff_take_reuse_n(v_x1_2462, 1ULL, 1);
    V v_path_2468 = heff_take_field(v_err_2467, 3);
    V v_name_2469 = heff_take_field(v_err_2467, 1);
    V v_message_2470 = heff_get_n(v_err_2467, 2, 4);
    V v_t_2471 = heff_strAppend(heff_strAppend(v_path_2468, ((V)&g_app_2eheff_2emain_2emain_str0)), v_name_2469);
    V v_t_2472 = heff_strAppend(heff_strAppend(v_t_2471, ((V)&g_app_2eheff_2emain_2emain_str1)), v_message_2470);
    V v_t_2473 = heff_strAppend(heff_strAppend(((V)&g_app_2eheff_2emain_2emain_str2), v_t_2472), ((V)&g_app_2eheff_2emain_2emain_str3));
    V v_t_2474 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2473, NTAG(TAG_MkUnit)});
    V v_t_2475 = heff_tag_at_n(v_ru_24x1_2462_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tr(heff_call(heff_dup(v_malg_2464), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})}));
    V f_ = heff_dup(v_bind_2465);
    heff_room[0] = v_t_2479;
    heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2emain_lam15, 1, 3, (V[]){v_malg_2464, v_bind_2465, v_p_2466});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x1_2462, 0ULL, 1);
    heff_drop(v_malg_2464);
    heff_drop(v_bind_2465);
    V f_ = v_p_2466;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x1_2462);
  }
}
V g_app_2eheff_2emain_2emain_lam13(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_c_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2458;
  args[0] = heff_dup(v_hd_2459);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2emain_lam14, 1, 2, (V[]){v_hd_2459, v_k_2460});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}