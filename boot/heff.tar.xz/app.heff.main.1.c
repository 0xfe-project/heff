// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Among 19600
#define TAG_Args 26338
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_Interactive 42932
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_Some 35658
#define TAG_Start 63542
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_backend 2032133329
#define LBL_bench 294981194
#define LBL_build 295453320
#define LBL_check 295985442
#define LBL_checked 974171621
#define LBL_compile 1182349425
#define LBL_complete 145693389
#define LBL_cwd 308458
#define LBL_dev 308879
#define LBL_devPages 1831184971
#define LBL_doc 309170
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_dumpC 297304297
#define LBL_dumpCore 769862998
#define LBL_dumpEval 769928787
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_explain 1070179126
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_flag 9641011
#define LBL_fmt 311047
#define LBL_get 311760
#define LBL_give 9668568
#define LBL_globals 352931696
#define LBL_heff 9694020
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_init 9732567
#define LBL_install 41944028
#define LBL_lib 316671
#define LBL_long 9823043
#define LBL_lsp 316995
#define LBL_meta 9843404
#define LBL_mod 317820
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_outPath 1272254166
#define LBL_own 320000
#define LBL_pos 320718
#define LBL_project 2070030684
#define LBL_promote 2070130179
#define LBL_publish 2143976274
#define LBL_ran 322201
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_run 322821
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_shutdown 575795380
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_top 324559
#define LBL_typeAt 1088337976
#define LBL_values 1123329101
#define LBL_version 583465758
#define LBL_watch 314261737
static uint32_t shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc[] = {LBL_check, LBL_run, LBL_tests, LBL_bench, LBL_promote, LBL_compile, LBL_explain, LBL_typeAt, LBL_fmt, LBL_doc};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_file__outPath__name__backend[] = {LBL_file, LBL_outPath, LBL_name, LBL_backend};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_init__get__build__install__publish__dev[] = {LBL_init, LBL_get, LBL_build, LBL_install, LBL_publish, LBL_dev};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_long__short__meta__doc__values__repeated__required__complete[] = {LBL_long, LBL_short, LBL_meta, LBL_doc, LBL_values, LBL_repeated, LBL_required, LBL_complete};
static uint32_t shape_lsp__version__dumpCore__dumpEval__dumpC__devPages[] = {LBL_lsp, LBL_version, LBL_dumpCore, LBL_dumpEval, LBL_dumpC, LBL_devPages};
static uint32_t shape_meta__arity__complete[] = {LBL_meta, LBL_arity, LBL_complete};
static uint32_t shape_name__doc__shown__args[] = {LBL_name, LBL_doc, LBL_shown, LBL_args};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008(V);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_clo;
V g_app_2eheff_2emain_2ebuildCommands(V);
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2ebuildCommands_clo;
V g_app_2eheff_2emain_2edispatch_24s56716935x916488738(V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s56716935x916488738_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s56716935x916488738_clo;
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815(V, V, V, V, V, V);
V g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eexplore_24s1488403284x165539815_clo;
V g_app_2eheff_2emain_2ehf_get(void);
V g_app_2eheff_2emain_2emain(V, V, V);
V g_app_2eheff_2emain_2emain_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2emain_clo;
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711(V);
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eproject_24s816933939x1507085711_clo;
V g_app_2eheff_2emain_2eprojectCommands(V);
V g_app_2eheff_2emain_2eprojectCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprojectCommands_clo;
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889(V);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etool_24s1521631011x1066814889_clo;
V g_app_2eheff_2emain_2etoolCommands(V);
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2etoolCommands_clo;
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279(V, V, V, V);
V g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eunheard_24s1646521510x754669279_clo;
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(void);
V g_co_2e_3c_2b_3e_24s1267745919x482036999(V);
V g_co_2e_3c_2b_3e_24s1267745919x482036999_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1267745919x482036999_clo;
V g_co_2e_3c_2b_3e_24s1419042510x1098087825(V);
V g_co_2e_3c_2b_3e_24s1419042510x1098087825_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1419042510x1098087825_clo;
V g_co_2e_3c_2b_3e_24s1585861108x1258949188(V);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1585861108x1258949188_clo;
V g_co_2e_3c_2b_3e_24s1611985049x766020670(V);
V g_co_2e_3c_2b_3e_24s1611985049x766020670_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1611985049x766020670_clo;
V g_co_2e_3c_2b_3e_24s191044587x696072828(V);
V g_co_2e_3c_2b_3e_24s191044587x696072828_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s191044587x696072828_clo;
V g_co_2e_3c_2b_3e_24s199445780x454385136(V);
V g_co_2e_3c_2b_3e_24s199445780x454385136_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s199445780x454385136_clo;
V g_co_2e_3c_2b_3e_24s219000013x892923660(V);
V g_co_2e_3c_2b_3e_24s219000013x892923660_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s219000013x892923660_clo;
V g_co_2e_3c_2b_3e_24s965351493x1073186978(V);
V g_co_2e_3c_2b_3e_24s965351493x1073186978_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s965351493x1073186978_clo;
V g_co_2eop_24s1701369613x1410211592(V, V, V, V);
V g_co_2eop_24s1701369613x1410211592_entry(V self, V *a);
extern Clo g_co_2eop_24s1701369613x1410211592_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s67557612x799002753(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s67557612x799002753_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s67557612x799002753_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1721676377x465145401(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1721676377x465145401_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1721676377x465145401_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508(V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646(V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318(V, V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_clo;
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546(V, V, V, V);
V g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_clo;
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528(V, V, V, V, V);
V g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_clo;
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954(V, V, V);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_clo;
V g_heff_2ebuild_2edriver_2eevalPick(V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271(V, V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876(V, V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738(V, V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386(V, V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023_clo;
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998(V, V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_clo;
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1271133029x1548514599(V, V);
V g_list_2efoldl_24s1271133029x1548514599_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1271133029x1548514599_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
HeffT2 g_std_2ecli_2ereadLine_24cpr(V, V, V);
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eprogress_2eroot_get(void);
V g_std_2eprogress_2eshown_24s368808293x755970834(V, V, V, V, V);
V g_std_2eprogress_2eshown_24s368808293x755970834_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s368808293x755970834_clo;
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str0, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str1, 55, "elaborate FILE and what it imports; print its interface");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str2, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str3, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str4, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str5, 76, "run FILE's main with ARGS, compiled through C (by zig at -O1, in .heff/run/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str8, 4, "ARGS");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str9, 4, "test");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str10, 263, "check the expectations of the watches (the `-- ...` lines under them) and doc tests (the `-- | ...` lines under them), and run the tests (the definitions of type `Test`, check's), of the FILEs (a directory's .hf files), else of the project's here (src/ and test/)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str11, 4, "seed");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str12, 1, "s");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str13, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str14, 64, "the seed the properties draw from (the same seed, the same runs)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str15, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str16, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str17, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str18, 82, "run only the tests whose names it matches, a level each between `/`s: `^lsp/hover`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str19, 4, "jobs");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str20, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str21, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str22, 76, "how many integration tests run at once (HEFF_TEST_JOBS, else half the cores)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str23, 6, "update");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str24, 1, "u");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str25, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str26, 58, "write each golden text the tests keep, not hold them to it");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str27, 5, "watch");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str28, 1, "w");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str29, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str30, 127, "then test again at each change of the FILEs, of what they import, and of the project's sources, until ended (not with --update)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str31, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str32, 5, "bench");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str33, 259, "run the benchmarks (the definitions of type `Bench`, bench's) of the FILEs (a directory's .hf files), else of the project's benchmarks here (bench/): each built through C (by zig at -O2), run until a run takes the bench time, and said a line each, as Go's are");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str34, 3, "run");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str35, 1, "r");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str36, 6, "REGEXP");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str37, 95, "run only the benchmarks whose names it matches, a level each between `/`s, as `heff test --run`");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str38, 4, "time");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str39, 1, "t");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str40, 1, "D");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str41, 92, "how long each is run, at least: a duration (1s, the default; 500ms, 1.5s), or a count (100x)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str42, 5, "count");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str43, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str44, 1, "N");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str45, 33, "run each N times, a line each (1)");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str46, 4, "json");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str47, 1, "j");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str48, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str49, 26, "say each as a line of JSON");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str50, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str51, 7, "promote");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str52, 67, "write each watch's and doc test's value under it as its expectation");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str53, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str54, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str55, 7, "compile");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str56, 164, "FILE compiled, by MODE: esm (an ES module), page (a script running the app NAME in a page), c (a C program running NAME, for `zig cc`); NAME is main, without --name");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str57, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str58, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str59, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str60, 3, "OUT");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str61, 4, "name");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str62, 1, "n");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str63, 4, "NAME");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str64, 47, "the computation run (page, c): main, without it");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str65, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str66, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str67, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str68, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str69, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str70, 3, "esm");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str71, 4, "page");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str72, 7, "backend");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str73, 1, "b");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str74, 4, "MODE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str75, 22, "what it is compiled to");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str76, 7, "explain");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str77, 21, "the elaboration trace");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str78, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str79, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str80, 7, "type-at");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str81, 67, "what the name at each OFFSET resolved to, and its type, a line each");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str82, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str83, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str84, 6, "OFFSET");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str85, 3, "fmt");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str86, 21, "format FILEs in place");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str87, 5, "check");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str88, 1, "c");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str89, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str90, 32, "only say which are not formatted");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str91, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str92, 3, "doc");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str93, 235, "a reference page, Markdown, of each module of the FILEs (a directory's .hf files), else of the project's here (src/): its header comment, then each definition it exposes, its signature and its doc comment; printed, or written under DIR");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str94, 3, "out");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str95, 1, "o");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str96, 3, "DIR");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str97, 113, "write each page under DIR, at its module's path (std.path at DIR/std/path.md), and an index of them, DIR/index.md");
HEFF_LIT(g_app_2eheff_2emain_2ebuildCommands_str98, 4, "FILE");
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam1_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam1, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam3, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam5_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam5, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam12, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam13_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam13, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam14_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam14, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam16, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam18_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam18, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2ebuildCommands_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_lam20, 1, 0};
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args);
V g_app_2eheff_2emain_2ebuildCommands_lam21(V self, V *args);
Clo g_app_2eheff_2emain_2ebuildCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuildCommands_entry, 1, 0};

V g_app_2eheff_2emain_2ebuildCommands(V v_c_240) {
top: ;
  V v_check_241 = heff_take_field(v_c_240, 0);
  V v_run_242 = heff_take_field(v_c_240, 1);
  V v_tests_243 = heff_take_field(v_c_240, 2);
  V v_bench_244 = heff_take_field(v_c_240, 3);
  V v_promote_245 = heff_take_field(v_c_240, 4);
  V v_compile_246 = heff_take_field(v_c_240, 5);
  V v_explain_247 = heff_take_field(v_c_240, 6);
  V v_typeAt_248 = heff_take_field(v_c_240, 7);
  V v_fmt_249 = heff_take_field(v_c_240, 8);
  V v_doc_2410 = heff_get_n(v_c_240, 9, 10);
  V v_t_2423 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str0), ((V)&g_app_2eheff_2emain_2ebuildCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam0, 1, 1, (V[]){v_check_241})});
  V v_t_2439 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str4), ((V)&g_app_2eheff_2emain_2ebuildCommands_str5), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam2, 1, 1, (V[]){v_run_242})});
  V v_t_2479 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str9), ((V)&g_app_2eheff_2emain_2ebuildCommands_str10), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam4, 1, 1, (V[]){v_tests_243})});
  V v_t_24111 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str32), ((V)&g_app_2eheff_2emain_2ebuildCommands_str33), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam7, 1, 1, (V[]){v_bench_244})});
  V v_t_24124 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str51), ((V)&g_app_2eheff_2emain_2ebuildCommands_str52), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam9, 1, 1, (V[]){v_promote_245})});
  V v_t_24165 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str55), ((V)&g_app_2eheff_2emain_2ebuildCommands_str56), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam11, 1, 1, (V[]){v_compile_246})});
  V v_t_24178 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str76), ((V)&g_app_2eheff_2emain_2ebuildCommands_str77), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam15, 1, 1, (V[]){v_explain_247})});
  V v_t_24194 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str80), ((V)&g_app_2eheff_2emain_2ebuildCommands_str81), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam17, 1, 1, (V[]){v_typeAt_248})});
  V v_t_24211 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str85), ((V)&g_app_2eheff_2emain_2ebuildCommands_str86), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam19, 1, 1, (V[]){v_fmt_249})});
  V v_t_24225 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str92), ((V)&g_app_2eheff_2emain_2ebuildCommands_str93), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2ebuildCommands_lam21, 1, 1, (V[]){v_doc_2410})});
  V v_t_24226 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24225, NTAG(TAG_Nil)});
  V v_t_24227 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24194, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24211, v_t_24226})});
  V v_t_24228 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24178, v_t_24227})});
  V v_t_24229 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, v_t_24228})});
  V v_t_24230 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_t_24229})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_24230});
}
V g_app_2eheff_2emain_2ebuildCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuildCommands(a[0]);
}
V g_app_2eheff_2emain_2ebuildCommands_lam1(V self, V *args) {
  V v_x2_2415 = args[0];
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str2);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 2);
    return v_x_2416;
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_check_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2412 = heff_take_field(v_s_2411, 1);
  V v_give_2413 = heff_take_field(v_s_2411, 0);
  V v_pos_2414 = heff_get_n(v_s_2411, 3, 4);
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_give_2413), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam1_clo)}));
  V v_t_2419 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str3), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2420 = heff_tr(heff_call(v_pos_2414, 1, (V[]){v_t_2419}));
  V v_x_2421 = heff_tr(heff_call(heff_dup(v_ap_2412), 2, (V[]){v_t_2418, v_t_2420}));
  V v_t_2422 = heff_tr(heff_call(v_give_2413, 1, (V[]){v_check_241}));
  V f_ = v_ap_2412;
  heff_room[0] = v_t_2422;
  heff_room[1] = v_x_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam3(V self, V *args) {
  V v_x2_2428 = args[0];
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str6);
  }
  case TAG_Cons: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    heff_take_n(v_x2_2428, 1ULL, 2);
    return v_x_2429;
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam2(V self, V *args) {
  V v_s_2424 = args[0];
  V v_run_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2425 = heff_take_field(v_s_2424, 1);
  V v_give_2426 = heff_take_field(v_s_2424, 0);
  V v_pos_2427 = heff_get_n(v_s_2424, 3, 4);
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_give_2426), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam3_clo)}));
  V v_t_2432 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str7), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2433 = heff_tr(heff_call(heff_dup(v_pos_2427), 1, (V[]){v_t_2432}));
  V v_x_2434 = heff_tr(heff_call(heff_dup(v_ap_2425), 2, (V[]){v_t_2431, v_t_2433}));
  V v_t_2435 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str8), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_y_2436 = heff_tr(heff_call(v_pos_2427, 1, (V[]){v_t_2435}));
  V v_t_2437 = heff_tr(heff_call(v_give_2426, 1, (V[]){v_run_242}));
  V v_t_2438 = heff_tr(heff_call(heff_dup(v_ap_2425), 2, (V[]){v_t_2437, v_x_2434}));
  V f_ = v_ap_2425;
  heff_room[0] = v_t_2438;
  heff_room[1] = v_y_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam5(V self, V *args) {
  V v_vs_2457 = args[0];
  switch (heff_tag_of(v_vs_2457)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2457, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2457);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam6(V self, V *args) {
  V v_vs_2469 = args[0];
  switch (heff_tag_of(v_vs_2469)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2469, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2469);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam4(V self, V *args) {
  V v_s_2440 = args[0];
  V v_tests_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2441 = heff_take_field(v_s_2440, 1);
  V v_give_2442 = heff_take_field(v_s_2440, 0);
  V v_flag_2443 = heff_take_field(v_s_2440, 2);
  V v_pos_2444 = heff_get_n(v_s_2440, 3, 4);
  V v_t_2445 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2446 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str11), ((V)&g_app_2eheff_2emain_2ebuildCommands_str12), ((V)&g_app_2eheff_2emain_2ebuildCommands_str13), ((V)&g_app_2eheff_2emain_2ebuildCommands_str14), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2447 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2446}));
  V v_x_2448 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2445, v_t_2447}));
  V v_t_2449 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2450 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str15), ((V)&g_app_2eheff_2emain_2ebuildCommands_str16), ((V)&g_app_2eheff_2emain_2ebuildCommands_str17), ((V)&g_app_2eheff_2emain_2ebuildCommands_str18), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2451 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2450}));
  V v_y_2452 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2449, v_t_2451}));
  V v_t_2453 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2454 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str19), ((V)&g_app_2eheff_2emain_2ebuildCommands_str20), ((V)&g_app_2eheff_2emain_2ebuildCommands_str21), ((V)&g_app_2eheff_2emain_2ebuildCommands_str22), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2455 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2454}));
  V v_z_2456 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2453, v_t_2455}));
  V v_t_2460 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam5_clo)}));
  V v_t_2461 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str23), ((V)&g_app_2eheff_2emain_2ebuildCommands_str24), ((V)&g_app_2eheff_2emain_2ebuildCommands_str25), ((V)&g_app_2eheff_2emain_2ebuildCommands_str26), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2462 = heff_tr(heff_call(heff_dup(v_flag_2443), 1, (V[]){v_t_2461}));
  V v_w_2463 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2460, v_t_2462}));
  V v_t_2464 = heff_tr(heff_call(heff_dup(v_give_2442), 1, (V[]){v_tests_243}));
  V v_t_2465 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2464, v_x_2448}));
  V v_t_2466 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2465, v_y_2452}));
  V v_t_2467 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2466, v_z_2456}));
  V v_t_2468 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2467, v_w_2463}));
  V v_t_2472 = heff_tr(heff_call(v_give_2442, 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam6_clo)}));
  V v_t_2473 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str27), ((V)&g_app_2eheff_2emain_2ebuildCommands_str28), ((V)&g_app_2eheff_2emain_2ebuildCommands_str29), ((V)&g_app_2eheff_2emain_2ebuildCommands_str30), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2474 = heff_tr(heff_call(v_flag_2443, 1, (V[]){v_t_2473}));
  V v_t_2475 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2472, v_t_2474}));
  V v_t_2476 = heff_tr(heff_call(heff_dup(v_ap_2441), 2, (V[]){v_t_2468, v_t_2475}));
  V v_t_2477 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str31), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2478 = heff_tr(heff_call(v_pos_2444, 1, (V[]){v_t_2477}));
  V f_ = v_ap_2441;
  heff_room[0] = v_t_2476;
  heff_room[1] = v_t_2478;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam8(V self, V *args) {
  V v_vs_2497 = args[0];
  switch (heff_tag_of(v_vs_2497)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_2497, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_2497);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam7(V self, V *args) {
  V v_s_2480 = args[0];
  V v_bench_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2481 = heff_take_field(v_s_2480, 1);
  V v_give_2482 = heff_take_field(v_s_2480, 0);
  V v_flag_2483 = heff_take_field(v_s_2480, 2);
  V v_pos_2484 = heff_get_n(v_s_2480, 3, 4);
  V v_t_2485 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2486 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str34), ((V)&g_app_2eheff_2emain_2ebuildCommands_str35), ((V)&g_app_2eheff_2emain_2ebuildCommands_str36), ((V)&g_app_2eheff_2emain_2ebuildCommands_str37), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2487 = heff_tr(heff_call(heff_dup(v_flag_2483), 1, (V[]){v_t_2486}));
  V v_x_2488 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_2485, v_t_2487}));
  V v_t_2489 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2490 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str38), ((V)&g_app_2eheff_2emain_2ebuildCommands_str39), ((V)&g_app_2eheff_2emain_2ebuildCommands_str40), ((V)&g_app_2eheff_2emain_2ebuildCommands_str41), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2491 = heff_tr(heff_call(heff_dup(v_flag_2483), 1, (V[]){v_t_2490}));
  V v_y_2492 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_2489, v_t_2491}));
  V v_t_2493 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_2494 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str42), ((V)&g_app_2eheff_2emain_2ebuildCommands_str43), ((V)&g_app_2eheff_2emain_2ebuildCommands_str44), ((V)&g_app_2eheff_2emain_2ebuildCommands_str45), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_2495 = heff_tr(heff_call(heff_dup(v_flag_2483), 1, (V[]){v_t_2494}));
  V v_z_2496 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_2493, v_t_2495}));
  V v_t_24100 = heff_tr(heff_call(heff_dup(v_give_2482), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam8_clo)}));
  V v_t_24101 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str46), ((V)&g_app_2eheff_2emain_2ebuildCommands_str47), ((V)&g_app_2eheff_2emain_2ebuildCommands_str48), ((V)&g_app_2eheff_2emain_2ebuildCommands_str49), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24102 = heff_tr(heff_call(v_flag_2483, 1, (V[]){v_t_24101}));
  V v_w_24103 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24100, v_t_24102}));
  V v_t_24104 = heff_tr(heff_call(v_give_2482, 1, (V[]){v_bench_244}));
  V v_t_24105 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24104, v_x_2488}));
  V v_t_24106 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24105, v_y_2492}));
  V v_t_24107 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24106, v_z_2496}));
  V v_t_24108 = heff_tr(heff_call(heff_dup(v_ap_2481), 2, (V[]){v_t_24107, v_w_24103}));
  V v_t_24109 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str50), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24110 = heff_tr(heff_call(v_pos_2484, 1, (V[]){v_t_24109}));
  V f_ = v_ap_2481;
  heff_room[0] = v_t_24108;
  heff_room[1] = v_t_24110;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam10(V self, V *args) {
  V v_x2_24116 = args[0];
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str53);
  }
  case TAG_Cons: {
    V v_x_24117 = heff_field(v_x2_24116, 0);
    heff_take_n(v_x2_24116, 1ULL, 2);
    return v_x_24117;
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam9(V self, V *args) {
  V v_s_24112 = args[0];
  V v_promote_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24113 = heff_take_field(v_s_24112, 1);
  V v_give_24114 = heff_take_field(v_s_24112, 0);
  V v_pos_24115 = heff_get_n(v_s_24112, 3, 4);
  V v_t_24119 = heff_tr(heff_call(heff_dup(v_give_24114), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam10_clo)}));
  V v_t_24120 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str54), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24121 = heff_tr(heff_call(v_pos_24115, 1, (V[]){v_t_24120}));
  V v_x_24122 = heff_tr(heff_call(heff_dup(v_ap_24113), 2, (V[]){v_t_24119, v_t_24121}));
  V v_t_24123 = heff_tr(heff_call(v_give_24114, 1, (V[]){v_promote_245}));
  V f_ = v_ap_24113;
  heff_room[0] = v_t_24123;
  heff_room[1] = v_x_24122;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam12(V self, V *args) {
  V v_x2_24130 = args[0];
  switch (heff_tag_of(v_x2_24130)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str57);
  }
  case TAG_Cons: {
    V v_x_24131 = heff_field(v_x2_24130, 0);
    heff_take_n(v_x2_24130, 1ULL, 2);
    return v_x_24131;
  }
  default: return heff_nomatch(v_x2_24130);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam13(V self, V *args) {
  V v_x2_24137 = args[0];
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str59);
  }
  case TAG_Cons: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    heff_take_n(v_x2_24137, 1ULL, 2);
    return v_x_24138;
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam14(V self, V *args) {
  V v_vs_24148 = args[0];
  HeffT2 v_t_24149 = ({ V a_0 = v_vs_24148; HeffT2 r_ = (g_std_2ecli_2elastS_24cpr(a_0)); heff_drop(v_vs_24148); r_; });
  {
    V v_field_24151 = v_t_24149.f[1];
    int64_t v_tag_24150 = ((int64_t)v_t_24149.f[0]);
    if ((v_tag_24150 == ((int64_t)0ULL))) {
      V v_x_24152 = v_field_24151;
      return v_x_24152;
    } else {
      heff_drop(v_field_24151);
      return ((V)&g_app_2eheff_2emain_2ebuildCommands_str65);
    }
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam11(V self, V *args) {
  V v_s_24125 = args[0];
  V v_compile_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24126 = heff_take_field(v_s_24125, 1);
  V v_give_24127 = heff_take_field(v_s_24125, 0);
  V v_pos_24128 = heff_take_field(v_s_24125, 3);
  V v_flag_24129 = heff_get_n(v_s_24125, 2, 4);
  V v_t_24133 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam12_clo)}));
  V v_t_24134 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str58), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24135 = heff_tr(heff_call(heff_dup(v_pos_24128), 1, (V[]){v_t_24134}));
  V v_x_24136 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24133, v_t_24135}));
  V v_t_24140 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam13_clo)}));
  V v_t_24141 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str60), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_24142 = heff_tr(heff_call(v_pos_24128, 1, (V[]){v_t_24141}));
  V v_y_24143 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24140, v_t_24142}));
  V v_t_24144 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24145 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str61), ((V)&g_app_2eheff_2emain_2ebuildCommands_str62), ((V)&g_app_2eheff_2emain_2ebuildCommands_str63), ((V)&g_app_2eheff_2emain_2ebuildCommands_str64), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24146 = heff_tr(heff_call(heff_dup(v_flag_24129), 1, (V[]){v_t_24145}));
  V v_z_24147 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24144, v_t_24146}));
  V v_t_24153 = heff_tr(heff_call(heff_dup(v_give_24127), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam14_clo)}));
  V v_t_24154 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str66), NTAG(TAG_Nil)});
  V v_t_24155 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str67), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str68), v_t_24154})});
  V v_t_24156 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str69), NTAG(TAG_Nil)});
  V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str70), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str71), v_t_24156})});
  V v_t_24158 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str72), ((V)&g_app_2eheff_2emain_2ebuildCommands_str73), ((V)&g_app_2eheff_2emain_2ebuildCommands_str74), ((V)&g_app_2eheff_2emain_2ebuildCommands_str75), v_t_24155, NTAG(TAG_False), NTAG(TAG_True), heff_tag_n(TAG_Among, 1, (V[]){v_t_24157})});
  V v_t_24159 = heff_tr(heff_call(v_flag_24129, 1, (V[]){v_t_24158}));
  V v_w_24160 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24153, v_t_24159}));
  V v_t_24161 = heff_tr(heff_call(v_give_24127, 1, (V[]){v_compile_246}));
  V v_t_24162 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24161, v_x_24136}));
  V v_t_24163 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24162, v_y_24143}));
  V v_t_24164 = heff_tr(heff_call(heff_dup(v_ap_24126), 2, (V[]){v_t_24163, v_z_24147}));
  V f_ = v_ap_24126;
  heff_room[0] = v_t_24164;
  heff_room[1] = v_w_24160;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam16(V self, V *args) {
  V v_x2_24170 = args[0];
  switch (heff_tag_of(v_x2_24170)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str78);
  }
  case TAG_Cons: {
    V v_x_24171 = heff_field(v_x2_24170, 0);
    heff_take_n(v_x2_24170, 1ULL, 2);
    return v_x_24171;
  }
  default: return heff_nomatch(v_x2_24170);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam15(V self, V *args) {
  V v_s_24166 = args[0];
  V v_explain_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24167 = heff_take_field(v_s_24166, 1);
  V v_give_24168 = heff_take_field(v_s_24166, 0);
  V v_pos_24169 = heff_get_n(v_s_24166, 3, 4);
  V v_t_24173 = heff_tr(heff_call(heff_dup(v_give_24168), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam16_clo)}));
  V v_t_24174 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str79), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24175 = heff_tr(heff_call(v_pos_24169, 1, (V[]){v_t_24174}));
  V v_x_24176 = heff_tr(heff_call(heff_dup(v_ap_24167), 2, (V[]){v_t_24173, v_t_24175}));
  V v_t_24177 = heff_tr(heff_call(v_give_24168, 1, (V[]){v_explain_247}));
  V f_ = v_ap_24167;
  heff_room[0] = v_t_24177;
  heff_room[1] = v_x_24176;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam18(V self, V *args) {
  V v_x2_24183 = args[0];
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2ebuildCommands_str82);
  }
  case TAG_Cons: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    heff_take_n(v_x2_24183, 1ULL, 2);
    return v_x_24184;
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam17(V self, V *args) {
  V v_s_24179 = args[0];
  V v_typeAt_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24180 = heff_take_field(v_s_24179, 1);
  V v_give_24181 = heff_take_field(v_s_24179, 0);
  V v_pos_24182 = heff_get_n(v_s_24179, 3, 4);
  V v_t_24186 = heff_tr(heff_call(heff_dup(v_give_24181), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam18_clo)}));
  V v_t_24187 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str83), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_24188 = heff_tr(heff_call(heff_dup(v_pos_24182), 1, (V[]){v_t_24187}));
  V v_x_24189 = heff_tr(heff_call(heff_dup(v_ap_24180), 2, (V[]){v_t_24186, v_t_24188}));
  V v_t_24190 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str84), NTAG(TAG_Some), NTAG(TAG_None)});
  V v_y_24191 = heff_tr(heff_call(v_pos_24182, 1, (V[]){v_t_24190}));
  V v_t_24192 = heff_tr(heff_call(v_give_24181, 1, (V[]){v_typeAt_248}));
  V v_t_24193 = heff_tr(heff_call(heff_dup(v_ap_24180), 2, (V[]){v_t_24192, v_x_24189}));
  V f_ = v_ap_24180;
  heff_room[0] = v_t_24193;
  heff_room[1] = v_y_24191;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam20(V self, V *args) {
  V v_vs_24200 = args[0];
  switch (heff_tag_of(v_vs_24200)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_vs_24200, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_vs_24200);
  }
}
V g_app_2eheff_2emain_2ebuildCommands_lam19(V self, V *args) {
  V v_s_24195 = args[0];
  V v_fmt_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24196 = heff_take_field(v_s_24195, 1);
  V v_give_24197 = heff_take_field(v_s_24195, 0);
  V v_flag_24198 = heff_take_field(v_s_24195, 2);
  V v_pos_24199 = heff_get_n(v_s_24195, 3, 4);
  V v_t_24203 = heff_tr(heff_call(heff_dup(v_give_24197), 1, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_lam20_clo)}));
  V v_t_24204 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str87), ((V)&g_app_2eheff_2emain_2ebuildCommands_str88), ((V)&g_app_2eheff_2emain_2ebuildCommands_str89), ((V)&g_app_2eheff_2emain_2ebuildCommands_str90), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24205 = heff_tr(heff_call(v_flag_24198, 1, (V[]){v_t_24204}));
  V v_x_24206 = heff_tr(heff_call(heff_dup(v_ap_24196), 2, (V[]){v_t_24203, v_t_24205}));
  V v_t_24207 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str91), NTAG(TAG_Some), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24208 = heff_tr(heff_call(v_pos_24199, 1, (V[]){v_t_24207}));
  V v_t_24209 = heff_tr(heff_call(v_give_24197, 1, (V[]){v_fmt_249}));
  V v_t_24210 = heff_tr(heff_call(heff_dup(v_ap_24196), 2, (V[]){v_t_24209, v_x_24206}));
  V f_ = v_ap_24196;
  heff_room[0] = v_t_24210;
  heff_room[1] = v_y_24208;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuildCommands_lam21(V self, V *args) {
  V v_s_24212 = args[0];
  V v_doc_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_24213 = heff_take_field(v_s_24212, 1);
  V v_give_24214 = heff_take_field(v_s_24212, 0);
  V v_flag_24215 = heff_take_field(v_s_24212, 2);
  V v_pos_24216 = heff_get_n(v_s_24212, 3, 4);
  V v_t_24217 = heff_tr(heff_call(heff_dup(v_give_24214), 1, (V[]){((V)&g_std_2ecli_2elastS_clo)}));
  V v_t_24218 = heff_rec_n(8, shape_long__short__meta__doc__values__repeated__required__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str94), ((V)&g_app_2eheff_2emain_2ebuildCommands_str95), ((V)&g_app_2eheff_2emain_2ebuildCommands_str96), ((V)&g_app_2eheff_2emain_2ebuildCommands_str97), NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False), NTAG(TAG_None)});
  V v_t_24219 = heff_tr(heff_call(v_flag_24215, 1, (V[]){v_t_24218}));
  V v_x_24220 = heff_tr(heff_call(heff_dup(v_ap_24213), 2, (V[]){v_t_24217, v_t_24219}));
  V v_t_24221 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2ebuildCommands_str98), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_y_24222 = heff_tr(heff_call(v_pos_24216, 1, (V[]){v_t_24221}));
  V v_t_24223 = heff_tr(heff_call(v_give_24214, 1, (V[]){v_doc_2410}));
  V v_t_24224 = heff_tr(heff_call(heff_dup(v_ap_24213), 2, (V[]){v_t_24223, v_x_24220}));
  V f_ = v_ap_24213;
  heff_room[0] = v_t_24224;
  heff_room[1] = v_y_24222;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str0, 3, "lsp");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str1, 34, "a language server, on stdin/stdout");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str2, 5, "FLAGS");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str3, 7, "version");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str4, 68, "which heff this is: its version, as the package.hf it came with says");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str5, 9, "dump-core");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str6, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str7, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str8, 9, "dump-eval");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str9, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str10, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str11, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str12, 6, "dump-c");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str13, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str14, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str15, 4, "FILE");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str16, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str17, 3, "OUT");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str18, 9, "dev-pages");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str19, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str20, 0, "");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str21, 4, "PORT");
HEFF_LIT(g_app_2eheff_2emain_2etoolCommands_str22, 5, "PROXY");
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam4, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam6_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam6, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam7, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args);
V g_app_2eheff_2emain_2etoolCommands_lam9(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam9_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam9, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam10(V self, V *args); static Clo g_app_2eheff_2emain_2etoolCommands_lam10_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_lam10, 1, 0};
V g_app_2eheff_2emain_2etoolCommands_lam8(V self, V *args);
Clo g_app_2eheff_2emain_2etoolCommands_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etoolCommands_entry, 1, 0};

V g_app_2eheff_2emain_2etoolCommands(V v_c_240) {
top: ;
  V v_lsp_241 = heff_take_field(v_c_240, 0);
  V v_version_242 = heff_rget_v(v_c_240, 1);
  V v_dumpCore_243 = heff_take_field(v_c_240, 2);
  V v_dumpEval_244 = heff_take_field(v_c_240, 3);
  V v_dumpC_245 = heff_take_field(v_c_240, 4);
  V v_devPages_246 = heff_get_n(v_c_240, 5, 6);
  V v_t_2414 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str0), ((V)&g_app_2eheff_2emain_2etoolCommands_str1), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam0, 1, 1, (V[]){v_lsp_241})});
  V v_t_2416 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str3), ((V)&g_app_2eheff_2emain_2etoolCommands_str4), NTAG(TAG_True), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam1, 1, 1, (V[]){v_version_242})});
  V v_t_2424 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str5), ((V)&g_app_2eheff_2emain_2etoolCommands_str6), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam2, 1, 1, (V[]){v_dumpCore_243})});
  V v_t_2437 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str8), ((V)&g_app_2eheff_2emain_2etoolCommands_str9), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam3, 1, 1, (V[]){v_dumpEval_244})});
  V v_t_2458 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str12), ((V)&g_app_2eheff_2emain_2etoolCommands_str13), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam5, 1, 1, (V[]){v_dumpC_245})});
  V v_t_2479 = heff_rec_n(4, shape_name__doc__shown__args, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str18), ((V)&g_app_2eheff_2emain_2etoolCommands_str19), NTAG(TAG_False), heff_clo_n(g_app_2eheff_2emain_2etoolCommands_lam8, 1, 1, (V[]){v_devPages_246})});
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2481})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2482});
}
V g_app_2eheff_2emain_2etoolCommands_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etoolCommands(a[0]);
}
V g_app_2eheff_2emain_2etoolCommands_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_lsp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pos_248 = heff_take_field(v_s_247, 3);
  V v_ap_249 = heff_take_field(v_s_247, 1);
  V v_give_2410 = heff_get_n(v_s_247, 0, 4);
  V v_t_2411 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str2), NTAG(TAG_Rest), NTAG(TAG_None)});
  V v_x_2412 = heff_tr(heff_call(v_pos_248, 1, (V[]){v_t_2411}));
  V v_t_2413 = heff_tr(heff_call(v_give_2410, 1, (V[]){v_lsp_241}));
  V f_ = v_ap_249;
  heff_room[0] = v_t_2413;
  heff_room[1] = v_x_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_version_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_s_2415, 0, 4);
  args[0] = v_version_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2etoolCommands_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_dumpCore_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_pos_2418 = heff_take_field(v_s_2417, 3);
  V v_ap_2419 = heff_take_field(v_s_2417, 1);
  V v_give_2420 = heff_get_n(v_s_2417, 0, 4);
  V v_t_2421 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str7), NTAG(TAG_Many), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_x_2422 = heff_tr(heff_call(v_pos_2418, 1, (V[]){v_t_2421}));
  V v_t_2423 = heff_tr(heff_call(v_give_2420, 1, (V[]){v_dumpCore_243}));
  V f_ = v_ap_2419;
  heff_room[0] = v_t_2423;
  heff_room[1] = v_x_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam4(V self, V *args) {
  V v_x2_2429 = args[0];
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str10);
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    heff_take_n(v_x2_2429, 1ULL, 2);
    return v_x_2430;
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_dumpEval_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2426 = heff_take_field(v_s_2425, 1);
  V v_give_2427 = heff_take_field(v_s_2425, 0);
  V v_pos_2428 = heff_get_n(v_s_2425, 3, 4);
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_give_2427), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam4_clo)}));
  V v_t_2433 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str11), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2434 = heff_tr(heff_call(v_pos_2428, 1, (V[]){v_t_2433}));
  V v_x_2435 = heff_tr(heff_call(heff_dup(v_ap_2426), 2, (V[]){v_t_2432, v_t_2434}));
  V v_t_2436 = heff_tr(heff_call(v_give_2427, 1, (V[]){v_dumpEval_244}));
  V f_ = v_ap_2426;
  heff_room[0] = v_t_2436;
  heff_room[1] = v_x_2435;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam6(V self, V *args) {
  V v_x2_2442 = args[0];
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str14);
  }
  case TAG_Cons: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    heff_take_n(v_x2_2442, 1ULL, 2);
    return v_x_2443;
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam7(V self, V *args) {
  V v_x2_2449 = args[0];
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str16);
  }
  case TAG_Cons: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    heff_take_n(v_x2_2449, 1ULL, 2);
    return v_x_2450;
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam5(V self, V *args) {
  V v_s_2438 = args[0];
  V v_dumpC_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2439 = heff_take_field(v_s_2438, 1);
  V v_give_2440 = heff_take_field(v_s_2438, 0);
  V v_pos_2441 = heff_get_n(v_s_2438, 3, 4);
  V v_t_2445 = heff_tr(heff_call(heff_dup(v_give_2440), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam6_clo)}));
  V v_t_2446 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str15), NTAG(TAG_One), heff_dup(g_app_2eheff_2emain_2ehf_get())});
  V v_t_2447 = heff_tr(heff_call(heff_dup(v_pos_2441), 1, (V[]){v_t_2446}));
  V v_x_2448 = heff_tr(heff_call(heff_dup(v_ap_2439), 2, (V[]){v_t_2445, v_t_2447}));
  V v_t_2452 = heff_tr(heff_call(heff_dup(v_give_2440), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam7_clo)}));
  V v_t_2453 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str17), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2454 = heff_tr(heff_call(v_pos_2441, 1, (V[]){v_t_2453}));
  V v_y_2455 = heff_tr(heff_call(heff_dup(v_ap_2439), 2, (V[]){v_t_2452, v_t_2454}));
  V v_t_2456 = heff_tr(heff_call(v_give_2440, 1, (V[]){v_dumpC_245}));
  V v_t_2457 = heff_tr(heff_call(heff_dup(v_ap_2439), 2, (V[]){v_t_2456, v_x_2448}));
  V f_ = v_ap_2439;
  heff_room[0] = v_t_2457;
  heff_room[1] = v_y_2455;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etoolCommands_lam9(V self, V *args) {
  V v_x2_2463 = args[0];
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_Nil: {
    return ((V)&g_app_2eheff_2emain_2etoolCommands_str20);
  }
  case TAG_Cons: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    heff_take_n(v_x2_2463, 1ULL, 2);
    return v_x_2464;
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam10(V self, V *args) {
  V v_ws_2470 = args[0];
  switch (heff_tag_of(v_ws_2470)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2471 = heff_field(v_ws_2470, 0);
    heff_take_n(v_ws_2470, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){v_x_2471});
  }
  default: return heff_nomatch(v_ws_2470);
  }
}
V g_app_2eheff_2emain_2etoolCommands_lam8(V self, V *args) {
  V v_s_2459 = args[0];
  V v_devPages_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ap_2460 = heff_take_field(v_s_2459, 1);
  V v_give_2461 = heff_take_field(v_s_2459, 0);
  V v_pos_2462 = heff_get_n(v_s_2459, 3, 4);
  V v_t_2466 = heff_tr(heff_call(heff_dup(v_give_2461), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam9_clo)}));
  V v_t_2467 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str21), NTAG(TAG_One), NTAG(TAG_None)});
  V v_t_2468 = heff_tr(heff_call(heff_dup(v_pos_2462), 1, (V[]){v_t_2467}));
  V v_x_2469 = heff_tr(heff_call(heff_dup(v_ap_2460), 2, (V[]){v_t_2466, v_t_2468}));
  V v_t_2473 = heff_tr(heff_call(heff_dup(v_give_2461), 1, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_lam10_clo)}));
  V v_t_2474 = heff_rec_n(3, shape_meta__arity__complete, (V[]){((V)&g_app_2eheff_2emain_2etoolCommands_str22), NTAG(TAG_Optional), NTAG(TAG_None)});
  V v_t_2475 = heff_tr(heff_call(v_pos_2462, 1, (V[]){v_t_2474}));
  V v_y_2476 = heff_tr(heff_call(heff_dup(v_ap_2460), 2, (V[]){v_t_2473, v_t_2475}));
  V v_t_2477 = heff_tr(heff_call(v_give_2461, 1, (V[]){v_devPages_246}));
  V v_t_2478 = heff_tr(heff_call(heff_dup(v_ap_2460), 2, (V[]){v_t_2477, v_x_2469}));
  V f_ = v_ap_2460;
  heff_room[0] = v_t_2478;
  heff_room[1] = v_y_2476;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_str1, 7, "testing");
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam3(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam2(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam1(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam0(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam8, 1, 0};
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam9(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam7(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam6(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam5(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam4(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam13(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam12(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam11(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam10(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam14(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam17(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam16(V self, V *args);
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam15(V self, V *args);
Clo g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_entry, 1, 0};

V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008(V v_e_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1072044984x1979184684_clo), 1, (V[]){heff_dup(v_e_240)}));
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_clo), 1, (V[]){heff_dup(v_e_240)}));
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s769790401x1374028584_clo), 1, (V[]){heff_dup(v_e_240)}));
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_clo), 1, (V[]){heff_dup(v_e_240)}));
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_clo), 1, (V[]){heff_dup(v_e_240)}));
  return heff_rec_n(10, shape_check__run__tests__bench__promote__compile__explain__typeAt__fmt__doc, (V[]){heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam0, 3, 1, (V[]){heff_dup(v_e_240)}), v_t_241, heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam4, 6, 1, (V[]){heff_dup(v_e_240)}), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam10, 5, 1, (V[]){heff_dup(v_e_240)}), v_t_242, heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam14, 4, 1, (V[]){heff_dup(v_e_240)}), v_t_243, v_t_244, heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam15, 2, 1, (V[]){v_e_240}), v_t_245});
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2ebuild_24s734590437x1846621008(a[0]);
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2410, 1));
  heff_drop(v_x_2410);
  return ({ V a_0 = v_e_240; V a_1 = v_t_2413; V a_2 = heff_get_n(v_x_2412, 0, 2); V a_3 = v_hd_247; V a_4 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2echeckLast_24s1149627917x406604773(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2411 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), v_x_249));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam3, 1, 4, (V[]){v_x_2410, v_e_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_str0), heff_dup(heff_rfield(v_x_249, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam2, 1, 4, (V[]){v_e_240, v_x_249, v_hd_247, v_k_248})));
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam0(V self, V *args) {
  V v_file_246 = args[0];
  V v_hd_247 = args[1];
  V v_k_248 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), v_file_246, heff_dup(v_hd_247), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam1, 1, 3, (V[]){v_e_240, v_hd_247, v_k_248})));
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam8(V self, V *args) {
  V v_t_2427 = args[0];
  return v_t_2427;
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam9(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_hd_2421 = heff_env(self)[3];
  V v_k_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2etesting_2etestCmd_24s171052250x1101890966(v_e_240, v_x_2430, v_x_2423, v_x_2425, heff_dup(g_heff_2ebuild_2etesting_2enoRes_get()), NTAG(TAG_Nil), v_hd_2421, v_k_2422));
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_total_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2425));
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_str1), v_total_2426, ((V)&g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam8_clo)})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2429, heff_dup(v_hd_2421), heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam9, 1, 5, (V[]){v_e_240, v_x_2423, v_x_2425, v_hd_2421, v_k_2422})));
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_given_2419 = heff_env(self)[1];
  V v_hd_2421 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2424 = (g_heff_2ebuild_2etesting_2etestFiles_24s1361201778x1598189386(heff_dup(v_e_240), v_given_2419));
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_2421);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam7, 1, 4, (V[]){v_e_240, v_hd_2421, v_x_2423, v_k_2422});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_given_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam6, 1, 4, (V[]){v_e_240, v_given_2419, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam4(V self, V *args) {
  V v_seed_2414 = args[0];
  V v_pattern_2415 = args[1];
  V v_jobs_2416 = args[2];
  V v_update_2417 = args[3];
  V v_watch_2418 = args[4];
  V v_given_2419 = args[5];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if ((heff_dup(v_watch_2418) == NTAG(TAG_True))) {
    heff_drop(v_watch_2418);
    return ({ V a_0 = v_e_240; V a_1 = v_seed_2414; V a_2 = v_pattern_2415; V a_3 = v_jobs_2416; V a_4 = v_update_2417; V a_5 = v_given_2419; V r_ = (g_heff_2ebuild_2etesting_2etestsWatched_24s494105568x1398882615(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_seed_2414); heff_drop(v_pattern_2415); heff_drop(v_jobs_2416); heff_drop(v_update_2417); r_; });
  } else {
    heff_drop(v_watch_2418);
    V v_c_2420 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_seed_2414; V a_2 = v_pattern_2415; V a_3 = v_jobs_2416; V a_4 = v_update_2417; V r_ = (g_heff_2ebuild_2etesting_2etestOptions_24s620268879x1497056023(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_seed_2414); heff_drop(v_pattern_2415); heff_drop(v_jobs_2416); r_; });
    return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam5, 2, 3, (V[]){v_c_2420, v_e_240, v_given_2419});
  }
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam13(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_e_240; V a_1 = v_x_2439; V a_2 = v_x_2441; V a_3 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V a_4 = v_hd_2437; V a_5 = v_k_2438; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s67557612x799002753(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2441); r_; });
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam12(V self, V *args) {
  V v_x_2439 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_given_2435 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2440 = (g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318(heff_dup(v_e_240), v_given_2435));
  V f_ = v_c_2440;
  heff_room[0] = heff_dup(v_hd_2437);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam13, 1, 4, (V[]){v_e_240, v_x_2439, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam11(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_given_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam12, 1, 4, (V[]){v_e_240, v_given_2435, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam10(V self, V *args) {
  V v_pattern_2431 = args[0];
  V v_time_2432 = args[1];
  V v_count_2433 = args[2];
  V v_json_2434 = args[3];
  V v_given_2435 = args[4];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2436 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_pattern_2431; V a_2 = v_time_2432; V a_3 = v_count_2433; V a_4 = v_json_2434; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1721676377x465145401(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_pattern_2431); r_; });
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam11, 2, 3, (V[]){v_c_2436, v_e_240, v_given_2435});
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam14(V self, V *args) {
  V v_file_2442 = args[0];
  V v_outPath_2443 = args[1];
  V v_name_2444 = args[2];
  V v_backend_2445 = args[3];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1559731888x51384291_clo);
  args[0] = v_e_240;
  args[1] = heff_rec_n(4, shape_file__outPath__name__backend, (V[]){v_file_2442, v_outPath_2443, v_name_2444, v_backend_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam17(V self, V *args) {
  V v_x_2451 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2449 = heff_env(self)[1];
  V v_k_2450 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intLt_c(MK_INT(0LL), v_x_2451)) {
    V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_hd_2449, v_k_2450));
  } else {
    heff_drop(v_e_240);
    heff_drop(v_hd_2449);
    V f_ = v_k_2450;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam16(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_c_2448 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2448;
  args[0] = heff_dup(v_hd_2449);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam17, 1, 3, (V[]){v_e_240, v_hd_2449, v_k_2450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam15(V self, V *args) {
  V v_check_2446 = args[0];
  V v_files_2447 = args[1];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2448 = (g_heff_2ebuild_2ecommands_2efmtAll_24s538215992x491312355(heff_dup(v_e_240), v_check_2446, v_files_2447, MK_INT(0LL)));
  return heff_clo_n(g_app_2eheff_2emain_2ebuild_24s734590437x1846621008_lam16, 2, 2, (V[]){v_c_2448, v_e_240});
}
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s816933939x1507085711_str0, 1, ".");
HEFF_LIT(g_app_2eheff_2emain_2eproject_24s816933939x1507085711_str1, 1, ".");
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711_lam0(V self, V *args);
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711_lam1(V self, V *args);
Clo g_app_2eheff_2emain_2eproject_24s816933939x1507085711_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2eproject_24s816933939x1507085711_entry, 1, 0};

V g_app_2eheff_2emain_2eproject_24s816933939x1507085711(V v_e_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1013312713x1611226271_clo), 1, (V[]){heff_dup(v_e_240)}));
  V v_t_242 = (g_heff_2ebuild_2ecommands_2ebuildCmd_24s1994710537x2133873508(heff_dup(v_e_240)));
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_clo), 1, (V[]){heff_dup(v_e_240)}));
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2edevCmd_24s1083858858x1224196546_clo), 1, (V[]){heff_dup(v_e_240)}));
  return heff_rec_n(6, shape_init__get__build__install__publish__dev, (V[]){heff_clo_n(g_app_2eheff_2emain_2eproject_24s816933939x1507085711_lam0, 1, 1, (V[]){heff_dup(v_e_240)}), v_t_241, v_t_242, heff_clo_n(g_app_2eheff_2emain_2eproject_24s816933939x1507085711_lam1, 1, 1, (V[]){v_e_240}), v_t_243, v_t_244});
}
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2eproject_24s816933939x1507085711(a[0]);
}
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711_lam0(V self, V *args) {
  V v_dir_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_dir_245)) {
  case TAG_Nothing: {
    v_t_247 = ((V)&g_app_2eheff_2emain_2eproject_24s816933939x1507085711_str0);
    break;
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_dir_245, 0);
    heff_take_n(v_dir_245, 1ULL, 1);
    v_t_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_dir_245);
  }
  V f_ = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_clo);
  heff_room[0] = v_e_240;
  heff_room[1] = v_t_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2eproject_24s816933939x1507085711_lam1(V self, V *args) {
  V v_dir_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410;
  switch (heff_tag_of(v_dir_248)) {
  case TAG_Nothing: {
    v_t_2410 = ((V)&g_app_2eheff_2emain_2eproject_24s816933939x1507085711_str1);
    break;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_dir_248, 0);
    heff_take_n(v_dir_248, 1ULL, 1);
    v_t_2410 = v_x_249;
    break;
  }
  default: heff_nomatch(v_dir_248);
  }
  V f_ = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s10256197x433870646_clo);
  heff_room[0] = v_e_240;
  heff_room[1] = v_t_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_str0, 4, "heff");
HEFF_LIT(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_str1, 1, "#");
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam2(V self, V *args); static Clo g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam2_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam2, 1, 0};
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam3(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam1(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam0(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam7(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam6(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam5(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam4(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam13(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam14(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam15(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam12(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam11(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam10(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam9(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam8(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam18(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam17(V self, V *args);
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam16(V self, V *args);
Clo g_app_2eheff_2emain_2etool_24s1521631011x1066814889_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2etool_24s1521631011x1066814889_entry, 1, 0};

V g_app_2eheff_2emain_2etool_24s1521631011x1066814889(V v_e_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1634360896x59217318_clo), 1, (V[]){heff_dup(v_e_240)}));
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edev_2epagesCmd_24s1577624450x780115528_clo), 1, (V[]){heff_dup(v_e_240)}));
  return heff_rec_n(6, shape_lsp__version__dumpCore__dumpEval__dumpC__devPages, (V[]){heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam0, 3, 1, (V[]){heff_dup(v_e_240)}), v_t_241, heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam4, 1, 1, (V[]){heff_dup(v_e_240)}), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam8, 3, 1, (V[]){heff_dup(v_e_240)}), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam16, 4, 1, (V[]){v_e_240}), v_t_242});
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2etool_24s1521631011x1066814889(a[0]);
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam2(V self, V *args) {
  V v_a_247 = args[0];
  return v_a_247;
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = ({ V rv_0 = v_x_2414; V rr_ = heff_rec_reuse_nf(v_x_246, 30ULL, 5, shape_lib__mod__cwd__style__heff, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2416 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_False), v_t_2415});
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998(v_e_240, v_t_2416, v_hd_244, v_k_245));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_AbsPath, 2, (V[]){heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam2_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2413, heff_dup(v_hd_244), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam3, 1, 4, (V[]){v_x_246, v_e_240, v_hd_244, v_k_245})));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam0(V self, V *args) {
  V v_flags_243 = args[0];
  V v_hd_244 = args[1];
  V v_k_245 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_flags_243);
  return (g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(heff_dup(v_e_240), heff_dup(v_hd_244), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam1, 1, 3, (V[]){v_e_240, v_hd_244, v_k_245})));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intEq_c(v_x_2424, MK_INT(0LL))) {
    heff_drop(v_e_240);
    heff_drop(v_hd_2419);
    V f_ = v_k_2420;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2419, v_k_2420));
  }
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = (g_list_2efoldl_24s1271133029x1548514599(NTAG(TAG_Nil), v_x_2421));
  V v_c_2423 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_t_2422; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_2419);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam7, 1, 3, (V[]){v_k_2420, v_e_240, v_hd_2419});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam6, 1, 3, (V[]){v_e_240, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam4(V self, V *args) {
  V v_paths_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2418 = (g_heff_2ebuild_2ecommands_2ereadAll_24s183352629x243503994(heff_dup(v_e_240), NTAG(TAG_Nil), v_paths_2417));
  return heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam5, 2, 2, (V[]){v_c_2418, v_e_240});
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam13(V self, V *args) {
  V v_acc_2455 = args[0];
  V v_k_2456 = args[1];
  V v_entries_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2457 = ({ V a_0 = v_entries_2453; V a_1 = v_k_2456; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2453); r_; });
  {
    V v_field_2459 = v_t_2457.f[1];
    int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
    if ((v_tag_2458 == ((int64_t)0ULL))) {
      V v_e_2460 = v_field_2459;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2456, v_e_2460}), v_acc_2455});
    } else {
      heff_drop(v_k_2456);
      heff_drop(v_field_2459);
      return v_acc_2455;
    }
  }
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam14(V self, V *args) {
  V v_k_2462 = args[0];
  V v_own_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463 = (g_list_2emap_24s152505078x225062837(v_own_2451));
  return ({ V a_0 = v_k_2462; V a_1 = v_t_2463; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_k_2462); heff_drop(v_t_2463); r_; });
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam15(V self, V *args) {
  V v_x_2467 = args[0];
  V v_badL_2440 = heff_env(self)[0];
  V v_cs_2441 = heff_env(self)[1];
  V v_e_2439 = heff_env(self)[2];
  V v_hd_2442 = heff_env(self)[3];
  V v_k_2443 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (((heff_dup(v_badL_2440) == NTAG(TAG_True)) || ({ V v_c_2497 = (g_list_2eany_24s1740858080x874135214(v_cs_2441)); int c_ = ((heff_dup(v_c_2497) == NTAG(TAG_True)) || (heff_dup(v_x_2467) == NTAG(TAG_True))); heff_drop(v_c_2497); c_; }))) {
    heff_drop(v_x_2467);
    heff_drop(v_badL_2440);
    heff_drop(v_cs_2441);
    V v_t_2468 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
    return (g_co_2eop_24s310169282x2049378029(v_e_2439, heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), v_hd_2442, v_k_2443));
  } else {
    heff_drop(v_x_2467);
    heff_drop(v_badL_2440);
    heff_drop(v_cs_2441);
    heff_drop(v_e_2439);
    heff_drop(v_hd_2442);
    V f_ = v_k_2443;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam12(V self, V *args) {
  V v_x_2444 = args[0];
  V v_cs_2441 = heff_env(self)[0];
  V v_e_2439 = heff_env(self)[1];
  V v_hd_2442 = heff_env(self)[2];
  V v_badL_2440 = heff_env(self)[3];
  V v_k_2443 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2444);
  HeffT2 v_t_2445 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2441));
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      V v_c_2448 = v_field_2447;
      V v_c_2449 = v_c_2448;
      V v_top_2450 = heff_take_field(v_c_2449, 5);
      V v_own_2451 = heff_get_n(v_c_2449, 7, 14);
      V v_gs_2452 = heff_dup(heff_rfield(v_top_2450, 0));
      V v_entries_2453 = heff_take_field(v_gs_2452, 1);
      V v_order_2454 = heff_get_n(v_gs_2452, 0, 8);
      V v_t_2461 = ({ V a_0 = heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam13, 2, 1, (V[]){v_entries_2453}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_2454; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_order_2454); r_; });
      V v_t_2464 = (g_heff_2ecompile_2einterp_2eevalGlobalsGo(heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam14, 1, 1, (V[]){heff_dup(v_own_2451)}), heff_dup(g_std_2eordmap_2eempty_get()), v_t_2461, NTAG(TAG_Nil)));
      V v_t_2465 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_app_2eheff_2emain_2etool_24s1521631011x1066814889_str1); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_2451; V r_ = (g_list_2ekeepIf_24s958254147x1083401940(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
      V v_t_2466 = ({ V a_0 = heff_get_n(v_top_2450, 0, 10); V a_1 = v_t_2464; V a_2 = v_t_2465; V r_ = (g_heff_2ebuild_2edriver_2eevalPick(a_0, a_1, a_2)); heff_drop(v_t_2464); r_; });
      return (g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479(heff_dup(v_e_2439), v_t_2466, heff_dup(v_hd_2442), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam15, 1, 5, (V[]){v_badL_2440, v_cs_2441, v_e_2439, v_hd_2442, v_k_2443})));
    } else {
      heff_drop(v_cs_2441);
      heff_drop(v_badL_2440);
      heff_drop(v_field_2447);
      V v_t_2475 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
      return (g_co_2eop_24s310169282x2049378029(v_e_2439, heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), v_hd_2442, v_k_2443));
    }
  }
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2436 = heff_env(self)[1];
  V v_hd_2433 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_e_2439 = v_e_240;
  V v_badL_2440 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2436, 1));
  heff_drop(v_x_2436);
  V v_cs_2441 = heff_get_n(v_x_2438, 0, 2);
  V v_hd_2442 = v_hd_2433;
  V v_k_2443 = v_k_2434;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_2439), heff_dup(v_cs_2441), heff_dup(v_hd_2442), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam12, 1, 5, (V[]){v_cs_2441, v_e_2439, v_hd_2442, v_badL_2440, v_k_2443})));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam10(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_hd_2433 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2437 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), v_x_2435));
  V f_ = v_c_2437;
  heff_room[0] = heff_dup(v_hd_2433);
  heff_room[1] = heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam11, 1, 4, (V[]){v_e_240, v_x_2436, v_hd_2433, v_k_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam9(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2433 = heff_env(self)[1];
  V v_k_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_app_2eheff_2emain_2etool_24s1521631011x1066814889_str0), heff_dup(heff_rfield(v_x_2435, 1)), MK_INT(0LL), heff_dup(v_hd_2433), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam10, 1, 4, (V[]){v_e_240, v_x_2435, v_hd_2433, v_k_2434})));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam8(V self, V *args) {
  V v_file_2432 = args[0];
  V v_hd_2433 = args[1];
  V v_k_2434 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), v_file_2432, heff_dup(v_hd_2433), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam9, 1, 3, (V[]){v_e_240, v_hd_2433, v_k_2434})));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam18(V self, V *args) {
  V v_why_2487 = args[0];
  V v_z_2488 = args[1];
  V v_z_2489 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_why_2487);
  V v_t_2490 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2495})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2496}), v_z_2488, v_z_2489));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam17(V self, V *args) {
  V v_x_2486 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_outPath_2483 = heff_env(self)[1];
  V v_file_2482 = heff_env(self)[2];
  V v_hd_2484 = heff_env(self)[3];
  V v_k_2485 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s48802665x474938741(heff_dup(v_e_240), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam18, 3, 1, (V[]){v_e_240}), v_x_2486, NTAG(TAG_Nothing), v_outPath_2483, v_file_2482, v_hd_2484, v_k_2485));
}
V g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam16(V self, V *args) {
  V v_file_2482 = args[0];
  V v_outPath_2483 = args[1];
  V v_hd_2484 = args[2];
  V v_k_2485 = args[3];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_file_2482), heff_dup(v_hd_2484), heff_clo_n(g_app_2eheff_2emain_2etool_24s1521631011x1066814889_lam17, 1, 5, (V[]){v_e_240, v_outPath_2483, v_file_2482, v_hd_2484, v_k_2485})));
}
HEFF_LIT(g_app_2eheff_2emain_2edispatch_24s56716935x916488738_str0, 4, "heff");
V g_app_2eheff_2emain_2edispatch_24s56716935x916488738_lam0(V self, V *args);
Clo g_app_2eheff_2emain_2edispatch_24s56716935x916488738_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2edispatch_24s56716935x916488738_entry, 4, 0};

V g_app_2eheff_2emain_2edispatch_24s56716935x916488738(V v_e_240, V v_argv_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = (g_app_2eheff_2emain_2ebuild_24s734590437x1846621008(heff_dup(v_e_240)));
  V v_t_245 = (g_app_2eheff_2emain_2eproject_24s816933939x1507085711(heff_dup(v_e_240)));
  V v_t_246 = (g_app_2eheff_2emain_2etool_24s1521631011x1066814889(heff_dup(v_e_240)));
  V v_t_247 = (g_app_2eheff_2emain_2ebuildCommands(v_t_244));
  V v_t_248 = (g_app_2eheff_2emain_2eprojectCommands(v_t_245));
  V v_t_249 = (g_app_2eheff_2emain_2etoolCommands(v_t_246));
  V v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_247, v_t_2410));
  HeffT2 v_t_2412 = (g_std_2ecli_2ereadLine_24cpr(((V)&g_app_2eheff_2emain_2edispatch_24s56716935x916488738_str0), v_t_2411, v_argv_241));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_text_2415 = v_field_2414;
      V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_text_2415, NTAG(TAG_MkUnit)});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
      HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_z_242), heff_clo_n(g_app_2eheff_2emain_2edispatch_24s56716935x916488738_lam0, 1, 3, (V[]){v_e_240, v_z_242, v_z_243}));
    } else {
      if ((v_tag_2413 == ((int64_t)1ULL))) {
        V v_text_2431 = v_field_2414;
        V v_t_2432 = heff_tag_n(TAG_Write, 2, (V[]){v_text_2431, NTAG(TAG_MkUnit)});
        V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
        V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
        V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
        V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
        HEFF_LAST return g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_z_242, v_z_243);
      } else {
        heff_drop(v_e_240);
        V v_act_2439 = v_field_2414;
        return heff_tail(v_act_2439, 2, (V[]){v_z_242, v_z_243});
      }
    }
  }
}
V g_app_2eheff_2emain_2edispatch_24s56716935x916488738_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2edispatch_24s56716935x916488738(a[0], a[1], a[2], a[3]);
}
V g_app_2eheff_2emain_2edispatch_24s56716935x916488738_lam0(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_z_242, v_z_243));
}
V g_app_2eheff_2emain_2emain_lam1(V self, V *args);
V g_app_2eheff_2emain_2emain_lam2(V self, V *args);
V g_app_2eheff_2emain_2emain_lam0(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam0_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam0, 3, 0};
V g_app_2eheff_2emain_2emain_lam3(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam3_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam3, 4, 0};
V g_app_2eheff_2emain_2emain_lam5(V self, V *args);
V g_app_2eheff_2emain_2emain_lam6(V self, V *args);
V g_app_2eheff_2emain_2emain_lam4(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam4_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam4, 3, 0};
V g_app_2eheff_2emain_2emain_lam7(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam7_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam7, 4, 0};
V g_app_2eheff_2emain_2emain_lam9(V self, V *args);
V g_app_2eheff_2emain_2emain_lam10(V self, V *args);
V g_app_2eheff_2emain_2emain_lam8(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam8_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam8, 3, 0};
V g_app_2eheff_2emain_2emain_lam11(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam11_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam11, 4, 0};
V g_app_2eheff_2emain_2emain_lam13(V self, V *args);
V g_app_2eheff_2emain_2emain_lam14(V self, V *args);
V g_app_2eheff_2emain_2emain_lam12(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam12_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam12, 3, 0};
V g_app_2eheff_2emain_2emain_lam15(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam15_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam15, 4, 0};
V g_app_2eheff_2emain_2emain_lam17(V self, V *args);
V g_app_2eheff_2emain_2emain_lam18(V self, V *args);
V g_app_2eheff_2emain_2emain_lam16(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam16_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam16, 3, 0};
V g_app_2eheff_2emain_2emain_lam19(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam19_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam19, 4, 0};
V g_app_2eheff_2emain_2emain_lam20(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam20_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam20, 1, 0};
V g_app_2eheff_2emain_2emain_lam22(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam22_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam22, 1, 0};
V g_app_2eheff_2emain_2emain_lam24(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam24_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam24, 3, 0};
V g_app_2eheff_2emain_2emain_lam23(V self, V *args);
V g_app_2eheff_2emain_2emain_lam25(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam25_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam25, 3, 0};
V g_app_2eheff_2emain_2emain_lam21(V self, V *args);
V g_app_2eheff_2emain_2emain_lam26(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam26_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam26, 3, 0};
V g_app_2eheff_2emain_2emain_lam28(V self, V *args);
V g_app_2eheff_2emain_2emain_lam29(V self, V *args);
V g_app_2eheff_2emain_2emain_lam27(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam27_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam27, 3, 0};
V g_app_2eheff_2emain_2emain_lam30(V self, V *args); static Clo g_app_2eheff_2emain_2emain_lam30_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_lam30, 4, 0};
V g_app_2eheff_2emain_2emain_lam32(V self, V *args);
V g_app_2eheff_2emain_2emain_lam31(V self, V *args);
Clo g_app_2eheff_2emain_2emain_clo = {{0x80000000u, K_CLO, 0}, g_app_2eheff_2emain_2emain_entry, 3, 0};

V g_app_2eheff_2emain_2emain(V v_z_240, V v_z_241, V v_z_242) {
top: ;
  V v_t_2431 = (g_co_2e_3c_2b_3e_24s1611985049x766020670(heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_app_2eheff_2emain_2emain_lam0_clo), ((V)&g_app_2eheff_2emain_2emain_lam3_clo)})));
  V v_t_2432 = (g_co_2e_3c_2b_3e_24s1267745919x482036999(v_t_2431));
  V v_t_2433 = (g_co_2e_3c_2b_3e_24s219000013x892923660(v_t_2432));
  V v_t_2434 = (g_co_2e_3c_2b_3e_24s191044587x696072828(v_t_2433));
  V v_t_2435 = (g_co_2e_3c_2b_3e_24s199445780x454385136(v_t_2434));
  V v_t_2436 = (g_co_2e_3c_2b_3e_24s965351493x1073186978(v_t_2435));
  V v_t_2465 = (g_co_2e_3c_2b_3e_24s1611985049x766020670(heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_app_2eheff_2emain_2emain_lam4_clo), ((V)&g_app_2eheff_2emain_2emain_lam7_clo)})));
  V v_t_2466 = (g_co_2e_3c_2b_3e_24s1267745919x482036999(v_t_2465));
  V v_t_2467 = (g_co_2e_3c_2b_3e_24s219000013x892923660(v_t_2466));
  V v_t_2468 = (g_co_2e_3c_2b_3e_24s191044587x696072828(v_t_2467));
  V v_t_2469 = (g_co_2e_3c_2b_3e_24s199445780x454385136(v_t_2468));
  V v_t_2470 = (g_co_2e_3c_2b_3e_24s965351493x1073186978(v_t_2469));
  V v_h_2471 = (g_co_2e_3c_2b_3e_24s1419042510x1098087825(v_t_2470));
  heff_drop(v_h_2471);
  V v_t_24100 = (g_co_2e_3c_2b_3e_24s1611985049x766020670(heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_app_2eheff_2emain_2emain_lam8_clo), ((V)&g_app_2eheff_2emain_2emain_lam11_clo)})));
  V v_t_24101 = (g_co_2e_3c_2b_3e_24s1267745919x482036999(v_t_24100));
  V v_t_24102 = (g_co_2e_3c_2b_3e_24s219000013x892923660(v_t_24101));
  V v_t_24103 = (g_co_2e_3c_2b_3e_24s191044587x696072828(v_t_24102));
  V v_t_24104 = (g_co_2e_3c_2b_3e_24s199445780x454385136(v_t_24103));
  V v_t_24105 = (g_co_2e_3c_2b_3e_24s965351493x1073186978(v_t_24104));
  V v_e_24106 = (g_co_2e_3c_2b_3e_24s1419042510x1098087825(v_t_24105));
  V v_t_24135 = (g_co_2e_3c_2b_3e_24s1611985049x766020670(heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_app_2eheff_2emain_2emain_lam12_clo), ((V)&g_app_2eheff_2emain_2emain_lam15_clo)})));
  V v_t_24136 = (g_co_2e_3c_2b_3e_24s1267745919x482036999(v_t_24135));
  V v_t_24137 = (g_co_2e_3c_2b_3e_24s219000013x892923660(v_t_24136));
  V v_t_24138 = (g_co_2e_3c_2b_3e_24s191044587x696072828(v_t_24137));
  V v_t_24139 = (g_co_2e_3c_2b_3e_24s199445780x454385136(v_t_24138));
  V v_t_24140 = (g_co_2e_3c_2b_3e_24s965351493x1073186978(v_t_24139));
  V v_t_24141 = (g_co_2e_3c_2b_3e_24s1419042510x1098087825(v_t_24140));
  V v_e_24142 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_24141));
  V v_t_24171 = (g_co_2e_3c_2b_3e_24s1611985049x766020670(heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_app_2eheff_2emain_2emain_lam16_clo), ((V)&g_app_2eheff_2emain_2emain_lam19_clo)})));
  V v_t_24172 = (g_co_2e_3c_2b_3e_24s1267745919x482036999(v_t_24171));
  V v_t_24173 = (g_co_2e_3c_2b_3e_24s219000013x892923660(v_t_24172));
  V v_t_24174 = (g_co_2e_3c_2b_3e_24s191044587x696072828(v_t_24173));
  V v_t_24175 = (g_co_2e_3c_2b_3e_24s199445780x454385136(v_t_24174));
  V v_t_24176 = (g_co_2e_3c_2b_3e_24s965351493x1073186978(v_t_24175));
  V v_t_24177 = (g_co_2e_3c_2b_3e_24s1419042510x1098087825(v_t_24176));
  V v_t_24178 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_24177));
  V v_t_24179 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_24178));
  V v_lit_24180 = v_e_24142;
  V v_e_24181 = v_t_24179;
  V v_t_24183 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Args, 1, (V[]){((V)&g_app_2eheff_2emain_2emain_lam20_clo)})});
  V v_t_24184 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24183})});
  V v_t_24185 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24184})});
  V v_t_24186 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24185})});
  V v_t_24187 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24186})});
  V v_t_24188 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24187})});
  V v_t_24189 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24188})});
  V v_c_24213 = (g_co_2eop_24s1701369613x1410211592(heff_dup(v_lit_24180), heff_dup(v_e_24181), v_t_24189, heff_clo_n(g_app_2eheff_2emain_2emain_lam21, 3, 2, (V[]){v_lit_24180, v_e_24181})));
  V v_t_24214 = (g_exception_2eattempted(v_e_24106));
  V v_c_24218 = heff_tr(heff_call(v_c_24213, 2, (V[]){v_t_24214, ((V)&g_app_2eheff_2emain_2emain_lam26_clo)}));
  V v_t_24247 = (g_co_2e_3c_2b_3e_24s1611985049x766020670(heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_app_2eheff_2emain_2emain_lam27_clo), ((V)&g_app_2eheff_2emain_2emain_lam30_clo)})));
  V v_t_24248 = (g_co_2e_3c_2b_3e_24s1267745919x482036999(v_t_24247));
  V v_t_24249 = (g_co_2e_3c_2b_3e_24s219000013x892923660(v_t_24248));
  V v_t_24250 = (g_co_2e_3c_2b_3e_24s191044587x696072828(v_t_24249));
  V v_t_24251 = (g_co_2e_3c_2b_3e_24s199445780x454385136(v_t_24250));
  V v_t_24252 = (g_co_2e_3c_2b_3e_24s965351493x1073186978(v_t_24251));
  V v_t_24253 = (g_co_2e_3c_2b_3e_24s1419042510x1098087825(v_t_24252));
  return (g_std_2eprogress_2eshown_24s368808293x755970834(v_t_2436, heff_clo_n(g_app_2eheff_2emain_2emain_lam31, 2, 2, (V[]){v_c_24218, v_t_24253}), v_z_240, v_z_241, v_z_242));
}
V g_app_2eheff_2emain_2emain_entry(V self, V *a) {
  (void)self;
  return g_app_2eheff_2emain_2emain(a[0], a[1], a[2]);
}
V g_app_2eheff_2emain_2emain_lam1(V self, V *args) {
  V v_b_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_b_2415}));
  V f_ = v_g_244;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam2(V self, V *args) {
  V v_b_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_b_2418}));
  V f_ = v_g_244;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_2421;
    switch (heff_tag_of(v_x_246)) {
    case TAG_InL: {
      V v_x_247 = heff_field(v_x_246, 0);
      V v_ru_24x_246_24InL = heff_take_reuse_n(v_x_246, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_247)) {
      case TAG_InL: {
        V v_x_248 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 1);
        V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_x_248}));
        v_t_2412 = heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_249});
        break;
      }
      case TAG_InR: {
        V v_y_2410 = heff_field(v_x_247, 0);
        V v_ru_24x_247_24InR = heff_take_reuse_n(v_x_247, 1ULL, 1);
        heff_drop_cell(v_ru_24p_245_24InL, 1);
        V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_y_2410}));
        v_t_2412 = heff_tag_at_n(v_ru_24x_247_24InR, TAG_InR, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      v_t_2421 = heff_tag_at_n(v_ru_24x_246_24InL, TAG_InL, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_InR: {
      V v_y_2413 = heff_field(v_x_246, 0);
      V v_ru_24x_246_24InR = heff_take_reuse_n(v_x_246, 1ULL, 1);
      heff_drop(v_m_243);
      heff_drop_cell(v_ru_24p_245_24InL, 1);
      V v_t_2420;
      switch (heff_tag_of(v_y_2413)) {
      case TAG_UseColor: {
        V v_k_2414 = heff_field(v_y_2413, 0);
        V v_ru_24y_2413_24UseColor = heff_take_reuse_n(v_y_2413, 1ULL, 1);
        v_t_2420 = heff_tag_at_n(v_ru_24y_2413_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam1, 1, 2, (V[]){v_k_2414, v_g_244})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2417 = heff_field(v_y_2413, 0);
        V v_ru_24y_2413_24ErrColor = heff_take_reuse_n(v_y_2413, 1ULL, 1);
        v_t_2420 = heff_tag_at_n(v_ru_24y_2413_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam2, 1, 2, (V[]){v_k_2417, v_g_244})});
        break;
      }
      default: heff_nomatch(v_y_2413);
      }
      v_t_2421 = heff_tag_at_n(v_ru_24x_246_24InR, TAG_InR, 1, (V[]){v_t_2420});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2421});
  }
  case TAG_InR: {
    V v_y_2422 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_y_2422}));
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_2423});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_app_2eheff_2emain_2emain_lam3(V self, V *args) {
  V v_m_2424 = args[0];
  V v_n_2425 = args[1];
  V v_nt_2426 = args[2];
  V v_p_2427 = args[3];
  switch (heff_tag_of(v_p_2427)) {
  case TAG_InL: {
    V v_x_2428 = heff_field(v_p_2427, 0);
    V v_ru_24p_2427_24InL = heff_take_reuse_n(v_p_2427, 1ULL, 1);
    heff_drop(v_m_2424);
    heff_drop(v_n_2425);
    heff_drop(v_nt_2426);
    return heff_tag_at_n(v_ru_24p_2427_24InL, TAG_InL, 1, (V[]){v_x_2428});
  }
  case TAG_InR: {
    V v_y_2429 = heff_field(v_p_2427, 0);
    V v_ru_24p_2427_24InR = heff_take_reuse_n(v_p_2427, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2424, v_n_2425, v_nt_2426, v_y_2429}));
    return heff_tag_at_n(v_ru_24p_2427_24InR, TAG_InR, 1, (V[]){v_t_2430});
  }
  default: return heff_nomatch(v_p_2427);
  }
}
V g_app_2eheff_2emain_2emain_lam5(V self, V *args) {
  V v_b_2449 = args[0];
  V v_k_2448 = heff_env(self)[0];
  V v_g_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_tr(heff_call(v_k_2448, 1, (V[]){v_b_2449}));
  V f_ = v_g_2438;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam6(V self, V *args) {
  V v_b_2452 = args[0];
  V v_k_2451 = heff_env(self)[0];
  V v_g_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = heff_tr(heff_call(v_k_2451, 1, (V[]){v_b_2452}));
  V f_ = v_g_2438;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam4(V self, V *args) {
  V v_m_2437 = args[0];
  V v_g_2438 = args[1];
  V v_p_2439 = args[2];
  switch (heff_tag_of(v_p_2439)) {
  case TAG_InL: {
    V v_x_2440 = heff_field(v_p_2439, 0);
    V v_ru_24p_2439_24InL = heff_take_reuse_n(v_p_2439, 1ULL, 1);
    V v_t_2455;
    switch (heff_tag_of(v_x_2440)) {
    case TAG_InL: {
      V v_x_2441 = heff_field(v_x_2440, 0);
      V v_ru_24x_2440_24InL = heff_take_reuse_n(v_x_2440, 1ULL, 1);
      V v_t_2446;
      switch (heff_tag_of(v_x_2441)) {
      case TAG_InL: {
        V v_x_2442 = heff_field(v_x_2441, 0);
        heff_take_n(v_x_2441, 1ULL, 1);
        V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(), 0)), 3, (V[]){v_m_2437, v_g_2438, v_x_2442}));
        v_t_2446 = heff_tag_at_n(v_ru_24p_2439_24InL, TAG_InL, 1, (V[]){v_t_2443});
        break;
      }
      case TAG_InR: {
        V v_y_2444 = heff_field(v_x_2441, 0);
        V v_ru_24x_2441_24InR = heff_take_reuse_n(v_x_2441, 1ULL, 1);
        heff_drop_cell(v_ru_24p_2439_24InL, 1);
        V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_2437, v_g_2438, v_y_2444}));
        v_t_2446 = heff_tag_at_n(v_ru_24x_2441_24InR, TAG_InR, 1, (V[]){v_t_2445});
        break;
      }
      default: heff_nomatch(v_x_2441);
      }
      v_t_2455 = heff_tag_at_n(v_ru_24x_2440_24InL, TAG_InL, 1, (V[]){v_t_2446});
      break;
    }
    case TAG_InR: {
      V v_y_2447 = heff_field(v_x_2440, 0);
      V v_ru_24x_2440_24InR = heff_take_reuse_n(v_x_2440, 1ULL, 1);
      heff_drop(v_m_2437);
      heff_drop_cell(v_ru_24p_2439_24InL, 1);
      V v_t_2454;
      switch (heff_tag_of(v_y_2447)) {
      case TAG_UseColor: {
        V v_k_2448 = heff_field(v_y_2447, 0);
        V v_ru_24y_2447_24UseColor = heff_take_reuse_n(v_y_2447, 1ULL, 1);
        v_t_2454 = heff_tag_at_n(v_ru_24y_2447_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam5, 1, 2, (V[]){v_k_2448, v_g_2438})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2451 = heff_field(v_y_2447, 0);
        V v_ru_24y_2447_24ErrColor = heff_take_reuse_n(v_y_2447, 1ULL, 1);
        v_t_2454 = heff_tag_at_n(v_ru_24y_2447_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam6, 1, 2, (V[]){v_k_2451, v_g_2438})});
        break;
      }
      default: heff_nomatch(v_y_2447);
      }
      v_t_2455 = heff_tag_at_n(v_ru_24x_2440_24InR, TAG_InR, 1, (V[]){v_t_2454});
      break;
    }
    default: heff_nomatch(v_x_2440);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2455});
  }
  case TAG_InR: {
    V v_y_2456 = heff_field(v_p_2439, 0);
    V v_ru_24p_2439_24InR = heff_take_reuse_n(v_p_2439, 1ULL, 1);
    V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_2437, v_g_2438, v_y_2456}));
    return heff_tag_at_n(v_ru_24p_2439_24InR, TAG_InR, 1, (V[]){v_t_2457});
  }
  default: return heff_nomatch(v_p_2439);
  }
}
V g_app_2eheff_2emain_2emain_lam7(V self, V *args) {
  V v_m_2458 = args[0];
  V v_n_2459 = args[1];
  V v_nt_2460 = args[2];
  V v_p_2461 = args[3];
  switch (heff_tag_of(v_p_2461)) {
  case TAG_InL: {
    V v_x_2462 = heff_field(v_p_2461, 0);
    V v_ru_24p_2461_24InL = heff_take_reuse_n(v_p_2461, 1ULL, 1);
    heff_drop(v_m_2458);
    heff_drop(v_n_2459);
    heff_drop(v_nt_2460);
    return heff_tag_at_n(v_ru_24p_2461_24InL, TAG_InL, 1, (V[]){v_x_2462});
  }
  case TAG_InR: {
    V v_y_2463 = heff_field(v_p_2461, 0);
    V v_ru_24p_2461_24InR = heff_take_reuse_n(v_p_2461, 1ULL, 1);
    V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2458, v_n_2459, v_nt_2460, v_y_2463}));
    return heff_tag_at_n(v_ru_24p_2461_24InR, TAG_InR, 1, (V[]){v_t_2464});
  }
  default: return heff_nomatch(v_p_2461);
  }
}
V g_app_2eheff_2emain_2emain_lam9(V self, V *args) {
  V v_b_2484 = args[0];
  V v_k_2483 = heff_env(self)[0];
  V v_g_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_tr(heff_call(v_k_2483, 1, (V[]){v_b_2484}));
  V f_ = v_g_2473;
  args[0] = v_t_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam10(V self, V *args) {
  V v_b_2487 = args[0];
  V v_k_2486 = heff_env(self)[0];
  V v_g_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2488 = heff_tr(heff_call(v_k_2486, 1, (V[]){v_b_2487}));
  V f_ = v_g_2473;
  args[0] = v_t_2488;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam8(V self, V *args) {
  V v_m_2472 = args[0];
  V v_g_2473 = args[1];
  V v_p_2474 = args[2];
  switch (heff_tag_of(v_p_2474)) {
  case TAG_InL: {
    V v_x_2475 = heff_field(v_p_2474, 0);
    V v_ru_24p_2474_24InL = heff_take_reuse_n(v_p_2474, 1ULL, 1);
    V v_t_2490;
    switch (heff_tag_of(v_x_2475)) {
    case TAG_InL: {
      V v_x_2476 = heff_field(v_x_2475, 0);
      V v_ru_24x_2475_24InL = heff_take_reuse_n(v_x_2475, 1ULL, 1);
      V v_t_2481;
      switch (heff_tag_of(v_x_2476)) {
      case TAG_InL: {
        V v_x_2477 = heff_field(v_x_2476, 0);
        heff_take_n(v_x_2476, 1ULL, 1);
        V v_t_2478 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(), 0)), 3, (V[]){v_m_2472, v_g_2473, v_x_2477}));
        v_t_2481 = heff_tag_at_n(v_ru_24p_2474_24InL, TAG_InL, 1, (V[]){v_t_2478});
        break;
      }
      case TAG_InR: {
        V v_y_2479 = heff_field(v_x_2476, 0);
        V v_ru_24x_2476_24InR = heff_take_reuse_n(v_x_2476, 1ULL, 1);
        heff_drop_cell(v_ru_24p_2474_24InL, 1);
        V v_t_2480 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_2472, v_g_2473, v_y_2479}));
        v_t_2481 = heff_tag_at_n(v_ru_24x_2476_24InR, TAG_InR, 1, (V[]){v_t_2480});
        break;
      }
      default: heff_nomatch(v_x_2476);
      }
      v_t_2490 = heff_tag_at_n(v_ru_24x_2475_24InL, TAG_InL, 1, (V[]){v_t_2481});
      break;
    }
    case TAG_InR: {
      V v_y_2482 = heff_field(v_x_2475, 0);
      V v_ru_24x_2475_24InR = heff_take_reuse_n(v_x_2475, 1ULL, 1);
      heff_drop(v_m_2472);
      heff_drop_cell(v_ru_24p_2474_24InL, 1);
      V v_t_2489;
      switch (heff_tag_of(v_y_2482)) {
      case TAG_UseColor: {
        V v_k_2483 = heff_field(v_y_2482, 0);
        V v_ru_24y_2482_24UseColor = heff_take_reuse_n(v_y_2482, 1ULL, 1);
        v_t_2489 = heff_tag_at_n(v_ru_24y_2482_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam9, 1, 2, (V[]){v_k_2483, v_g_2473})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2486 = heff_field(v_y_2482, 0);
        V v_ru_24y_2482_24ErrColor = heff_take_reuse_n(v_y_2482, 1ULL, 1);
        v_t_2489 = heff_tag_at_n(v_ru_24y_2482_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam10, 1, 2, (V[]){v_k_2486, v_g_2473})});
        break;
      }
      default: heff_nomatch(v_y_2482);
      }
      v_t_2490 = heff_tag_at_n(v_ru_24x_2475_24InR, TAG_InR, 1, (V[]){v_t_2489});
      break;
    }
    default: heff_nomatch(v_x_2475);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2490});
  }
  case TAG_InR: {
    V v_y_2491 = heff_field(v_p_2474, 0);
    V v_ru_24p_2474_24InR = heff_take_reuse_n(v_p_2474, 1ULL, 1);
    V v_t_2492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_2472, v_g_2473, v_y_2491}));
    return heff_tag_at_n(v_ru_24p_2474_24InR, TAG_InR, 1, (V[]){v_t_2492});
  }
  default: return heff_nomatch(v_p_2474);
  }
}
V g_app_2eheff_2emain_2emain_lam11(V self, V *args) {
  V v_m_2493 = args[0];
  V v_n_2494 = args[1];
  V v_nt_2495 = args[2];
  V v_p_2496 = args[3];
  switch (heff_tag_of(v_p_2496)) {
  case TAG_InL: {
    V v_x_2497 = heff_field(v_p_2496, 0);
    V v_ru_24p_2496_24InL = heff_take_reuse_n(v_p_2496, 1ULL, 1);
    heff_drop(v_m_2493);
    heff_drop(v_n_2494);
    heff_drop(v_nt_2495);
    return heff_tag_at_n(v_ru_24p_2496_24InL, TAG_InL, 1, (V[]){v_x_2497});
  }
  case TAG_InR: {
    V v_y_2498 = heff_field(v_p_2496, 0);
    V v_ru_24p_2496_24InR = heff_take_reuse_n(v_p_2496, 1ULL, 1);
    V v_t_2499 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2493, v_n_2494, v_nt_2495, v_y_2498}));
    return heff_tag_at_n(v_ru_24p_2496_24InR, TAG_InR, 1, (V[]){v_t_2499});
  }
  default: return heff_nomatch(v_p_2496);
  }
}
V g_app_2eheff_2emain_2emain_lam13(V self, V *args) {
  V v_b_24119 = args[0];
  V v_k_24118 = heff_env(self)[0];
  V v_g_24108 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24120 = heff_tr(heff_call(v_k_24118, 1, (V[]){v_b_24119}));
  V f_ = v_g_24108;
  args[0] = v_t_24120;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam14(V self, V *args) {
  V v_b_24122 = args[0];
  V v_k_24121 = heff_env(self)[0];
  V v_g_24108 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24123 = heff_tr(heff_call(v_k_24121, 1, (V[]){v_b_24122}));
  V f_ = v_g_24108;
  args[0] = v_t_24123;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam12(V self, V *args) {
  V v_m_24107 = args[0];
  V v_g_24108 = args[1];
  V v_p_24109 = args[2];
  switch (heff_tag_of(v_p_24109)) {
  case TAG_InL: {
    V v_x_24110 = heff_field(v_p_24109, 0);
    V v_ru_24p_24109_24InL = heff_take_reuse_n(v_p_24109, 1ULL, 1);
    V v_t_24125;
    switch (heff_tag_of(v_x_24110)) {
    case TAG_InL: {
      V v_x_24111 = heff_field(v_x_24110, 0);
      V v_ru_24x_24110_24InL = heff_take_reuse_n(v_x_24110, 1ULL, 1);
      V v_t_24116;
      switch (heff_tag_of(v_x_24111)) {
      case TAG_InL: {
        V v_x_24112 = heff_field(v_x_24111, 0);
        heff_take_n(v_x_24111, 1ULL, 1);
        V v_t_24113 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(), 0)), 3, (V[]){v_m_24107, v_g_24108, v_x_24112}));
        v_t_24116 = heff_tag_at_n(v_ru_24p_24109_24InL, TAG_InL, 1, (V[]){v_t_24113});
        break;
      }
      case TAG_InR: {
        V v_y_24114 = heff_field(v_x_24111, 0);
        V v_ru_24x_24111_24InR = heff_take_reuse_n(v_x_24111, 1ULL, 1);
        heff_drop_cell(v_ru_24p_24109_24InL, 1);
        V v_t_24115 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_24107, v_g_24108, v_y_24114}));
        v_t_24116 = heff_tag_at_n(v_ru_24x_24111_24InR, TAG_InR, 1, (V[]){v_t_24115});
        break;
      }
      default: heff_nomatch(v_x_24111);
      }
      v_t_24125 = heff_tag_at_n(v_ru_24x_24110_24InL, TAG_InL, 1, (V[]){v_t_24116});
      break;
    }
    case TAG_InR: {
      V v_y_24117 = heff_field(v_x_24110, 0);
      V v_ru_24x_24110_24InR = heff_take_reuse_n(v_x_24110, 1ULL, 1);
      heff_drop(v_m_24107);
      heff_drop_cell(v_ru_24p_24109_24InL, 1);
      V v_t_24124;
      switch (heff_tag_of(v_y_24117)) {
      case TAG_UseColor: {
        V v_k_24118 = heff_field(v_y_24117, 0);
        V v_ru_24y_24117_24UseColor = heff_take_reuse_n(v_y_24117, 1ULL, 1);
        v_t_24124 = heff_tag_at_n(v_ru_24y_24117_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam13, 1, 2, (V[]){v_k_24118, v_g_24108})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_24121 = heff_field(v_y_24117, 0);
        V v_ru_24y_24117_24ErrColor = heff_take_reuse_n(v_y_24117, 1ULL, 1);
        v_t_24124 = heff_tag_at_n(v_ru_24y_24117_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam14, 1, 2, (V[]){v_k_24121, v_g_24108})});
        break;
      }
      default: heff_nomatch(v_y_24117);
      }
      v_t_24125 = heff_tag_at_n(v_ru_24x_24110_24InR, TAG_InR, 1, (V[]){v_t_24124});
      break;
    }
    default: heff_nomatch(v_x_24110);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_24125});
  }
  case TAG_InR: {
    V v_y_24126 = heff_field(v_p_24109, 0);
    V v_ru_24p_24109_24InR = heff_take_reuse_n(v_p_24109, 1ULL, 1);
    V v_t_24127 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_24107, v_g_24108, v_y_24126}));
    return heff_tag_at_n(v_ru_24p_24109_24InR, TAG_InR, 1, (V[]){v_t_24127});
  }
  default: return heff_nomatch(v_p_24109);
  }
}
V g_app_2eheff_2emain_2emain_lam15(V self, V *args) {
  V v_m_24128 = args[0];
  V v_n_24129 = args[1];
  V v_nt_24130 = args[2];
  V v_p_24131 = args[3];
  switch (heff_tag_of(v_p_24131)) {
  case TAG_InL: {
    V v_x_24132 = heff_field(v_p_24131, 0);
    V v_ru_24p_24131_24InL = heff_take_reuse_n(v_p_24131, 1ULL, 1);
    heff_drop(v_m_24128);
    heff_drop(v_n_24129);
    heff_drop(v_nt_24130);
    return heff_tag_at_n(v_ru_24p_24131_24InL, TAG_InL, 1, (V[]){v_x_24132});
  }
  case TAG_InR: {
    V v_y_24133 = heff_field(v_p_24131, 0);
    V v_ru_24p_24131_24InR = heff_take_reuse_n(v_p_24131, 1ULL, 1);
    V v_t_24134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_24128, v_n_24129, v_nt_24130, v_y_24133}));
    return heff_tag_at_n(v_ru_24p_24131_24InR, TAG_InR, 1, (V[]){v_t_24134});
  }
  default: return heff_nomatch(v_p_24131);
  }
}
V g_app_2eheff_2emain_2emain_lam17(V self, V *args) {
  V v_b_24155 = args[0];
  V v_k_24154 = heff_env(self)[0];
  V v_g_24144 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24156 = heff_tr(heff_call(v_k_24154, 1, (V[]){v_b_24155}));
  V f_ = v_g_24144;
  args[0] = v_t_24156;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam18(V self, V *args) {
  V v_b_24158 = args[0];
  V v_k_24157 = heff_env(self)[0];
  V v_g_24144 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24159 = heff_tr(heff_call(v_k_24157, 1, (V[]){v_b_24158}));
  V f_ = v_g_24144;
  args[0] = v_t_24159;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam16(V self, V *args) {
  V v_m_24143 = args[0];
  V v_g_24144 = args[1];
  V v_p_24145 = args[2];
  switch (heff_tag_of(v_p_24145)) {
  case TAG_InL: {
    V v_x_24146 = heff_field(v_p_24145, 0);
    V v_ru_24p_24145_24InL = heff_take_reuse_n(v_p_24145, 1ULL, 1);
    V v_t_24161;
    switch (heff_tag_of(v_x_24146)) {
    case TAG_InL: {
      V v_x_24147 = heff_field(v_x_24146, 0);
      V v_ru_24x_24146_24InL = heff_take_reuse_n(v_x_24146, 1ULL, 1);
      V v_t_24152;
      switch (heff_tag_of(v_x_24147)) {
      case TAG_InL: {
        V v_x_24148 = heff_field(v_x_24147, 0);
        heff_take_n(v_x_24147, 1ULL, 1);
        V v_t_24149 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(), 0)), 3, (V[]){v_m_24143, v_g_24144, v_x_24148}));
        v_t_24152 = heff_tag_at_n(v_ru_24p_24145_24InL, TAG_InL, 1, (V[]){v_t_24149});
        break;
      }
      case TAG_InR: {
        V v_y_24150 = heff_field(v_x_24147, 0);
        V v_ru_24x_24147_24InR = heff_take_reuse_n(v_x_24147, 1ULL, 1);
        heff_drop_cell(v_ru_24p_24145_24InL, 1);
        V v_t_24151 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_24143, v_g_24144, v_y_24150}));
        v_t_24152 = heff_tag_at_n(v_ru_24x_24147_24InR, TAG_InR, 1, (V[]){v_t_24151});
        break;
      }
      default: heff_nomatch(v_x_24147);
      }
      v_t_24161 = heff_tag_at_n(v_ru_24x_24146_24InL, TAG_InL, 1, (V[]){v_t_24152});
      break;
    }
    case TAG_InR: {
      V v_y_24153 = heff_field(v_x_24146, 0);
      V v_ru_24x_24146_24InR = heff_take_reuse_n(v_x_24146, 1ULL, 1);
      heff_drop(v_m_24143);
      heff_drop_cell(v_ru_24p_24145_24InL, 1);
      V v_t_24160;
      switch (heff_tag_of(v_y_24153)) {
      case TAG_UseColor: {
        V v_k_24154 = heff_field(v_y_24153, 0);
        V v_ru_24y_24153_24UseColor = heff_take_reuse_n(v_y_24153, 1ULL, 1);
        v_t_24160 = heff_tag_at_n(v_ru_24y_24153_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam17, 1, 2, (V[]){v_k_24154, v_g_24144})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_24157 = heff_field(v_y_24153, 0);
        V v_ru_24y_24153_24ErrColor = heff_take_reuse_n(v_y_24153, 1ULL, 1);
        v_t_24160 = heff_tag_at_n(v_ru_24y_24153_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam18, 1, 2, (V[]){v_k_24157, v_g_24144})});
        break;
      }
      default: heff_nomatch(v_y_24153);
      }
      v_t_24161 = heff_tag_at_n(v_ru_24x_24146_24InR, TAG_InR, 1, (V[]){v_t_24160});
      break;
    }
    default: heff_nomatch(v_x_24146);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_24161});
  }
  case TAG_InR: {
    V v_y_24162 = heff_field(v_p_24145, 0);
    V v_ru_24p_24145_24InR = heff_take_reuse_n(v_p_24145, 1ULL, 1);
    V v_t_24163 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_24143, v_g_24144, v_y_24162}));
    return heff_tag_at_n(v_ru_24p_24145_24InR, TAG_InR, 1, (V[]){v_t_24163});
  }
  default: return heff_nomatch(v_p_24145);
  }
}
V g_app_2eheff_2emain_2emain_lam19(V self, V *args) {
  V v_m_24164 = args[0];
  V v_n_24165 = args[1];
  V v_nt_24166 = args[2];
  V v_p_24167 = args[3];
  switch (heff_tag_of(v_p_24167)) {
  case TAG_InL: {
    V v_x_24168 = heff_field(v_p_24167, 0);
    V v_ru_24p_24167_24InL = heff_take_reuse_n(v_p_24167, 1ULL, 1);
    heff_drop(v_m_24164);
    heff_drop(v_n_24165);
    heff_drop(v_nt_24166);
    return heff_tag_at_n(v_ru_24p_24167_24InL, TAG_InL, 1, (V[]){v_x_24168});
  }
  case TAG_InR: {
    V v_y_24169 = heff_field(v_p_24167, 0);
    V v_ru_24p_24167_24InR = heff_take_reuse_n(v_p_24167, 1ULL, 1);
    V v_t_24170 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_24164, v_n_24165, v_nt_24166, v_y_24169}));
    return heff_tag_at_n(v_ru_24p_24167_24InR, TAG_InR, 1, (V[]){v_t_24170});
  }
  default: return heff_nomatch(v_p_24167);
  }
}
V g_app_2eheff_2emain_2emain_lam20(V self, V *args) {
  V v_a_24182 = args[0];
  return v_a_24182;
}
V g_app_2eheff_2emain_2emain_lam22(V self, V *args) {
  V v_b_24193 = args[0];
  return v_b_24193;
}
V g_app_2eheff_2emain_2emain_lam24(V self, V *args) {
  V v_a_24202 = args[0];
  V v_a_24203 = args[1];
  V v_a_24204 = args[2];
  heff_drop(v_a_24203);
  V f_ = v_a_24204;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_a_24202});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam23(V self, V *args) {
  V v_x_24198 = args[0];
  V v_z_24199 = args[1];
  V v_z_24200 = args[2];
  V v_lit_24180 = heff_env(self)[0];
  V v_e_24181 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24201 = (g_exception_2eattempted(v_lit_24180));
  return ({ V a_0 = v_e_24181; V a_1 = v_x_24198; V a_2 = v_t_24201; V a_3 = ((V)&g_app_2eheff_2emain_2emain_lam24_clo); V a_4 = v_z_24199; V a_5 = v_z_24200; V r_ = (g_app_2eheff_2emain_2eexplore_24s1488403284x165539815(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_24198); r_; });
}
V g_app_2eheff_2emain_2emain_lam25(V self, V *args) {
  V v_a_24209 = args[0];
  V v_a_24210 = args[1];
  V v_a_24211 = args[2];
  heff_drop(v_a_24210);
  V f_ = v_a_24211;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_a_24209});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam21(V self, V *args) {
  V v_x_24190 = args[0];
  V v_z_24191 = args[1];
  V v_z_24192 = args[2];
  V v_lit_24180 = heff_env(self)[0];
  V v_e_24181 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_24190)) {
  case TAG_Nil: {
    V v_t_24194 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Interactive, 1, (V[]){((V)&g_app_2eheff_2emain_2emain_lam22_clo)})});
    V v_t_24195 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24194})});
    V v_t_24196 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24195})});
    V v_t_24197 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24196})});
    V v_t_24205 = (g_co_2eop_24s1701369613x1410211592(heff_dup(v_lit_24180), heff_dup(v_e_24181), heff_tag_n(TAG_InR, 1, (V[]){v_t_24197}), heff_clo_n(g_app_2eheff_2emain_2emain_lam23, 3, 2, (V[]){v_lit_24180, v_e_24181})));
    V f_ = v_t_24205;
    args[0] = v_z_24191;
    args[1] = v_z_24192;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_t_24208 = (g_exception_2eattempted(v_lit_24180));
    V v_t_24212 = heff_tr(g_app_2eheff_2emain_2edispatch_24s56716935x916488738(v_e_24181, v_x_24190, v_t_24208, ((V)&g_app_2eheff_2emain_2emain_lam25_clo)));
    V f_ = v_t_24212;
    args[0] = v_z_24191;
    args[1] = v_z_24192;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_24190);
  }
}
V g_app_2eheff_2emain_2emain_lam26(V self, V *args) {
  V v_x_24215 = args[0];
  V v_hd_24216 = args[1];
  V v_k_24217 = args[2];
  heff_drop(v_hd_24216);
  V f_ = v_k_24217;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24215});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam28(V self, V *args) {
  V v_b_24231 = args[0];
  V v_k_24230 = heff_env(self)[0];
  V v_g_24220 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24232 = heff_tr(heff_call(v_k_24230, 1, (V[]){v_b_24231}));
  V f_ = v_g_24220;
  args[0] = v_t_24232;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam29(V self, V *args) {
  V v_b_24234 = args[0];
  V v_k_24233 = heff_env(self)[0];
  V v_g_24220 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24235 = heff_tr(heff_call(v_k_24233, 1, (V[]){v_b_24234}));
  V f_ = v_g_24220;
  args[0] = v_t_24235;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_app_2eheff_2emain_2emain_lam27(V self, V *args) {
  V v_m_24219 = args[0];
  V v_g_24220 = args[1];
  V v_p_24221 = args[2];
  switch (heff_tag_of(v_p_24221)) {
  case TAG_InL: {
    V v_x_24222 = heff_field(v_p_24221, 0);
    V v_ru_24p_24221_24InL = heff_take_reuse_n(v_p_24221, 1ULL, 1);
    V v_t_24237;
    switch (heff_tag_of(v_x_24222)) {
    case TAG_InL: {
      V v_x_24223 = heff_field(v_x_24222, 0);
      V v_ru_24x_24222_24InL = heff_take_reuse_n(v_x_24222, 1ULL, 1);
      V v_t_24228;
      switch (heff_tag_of(v_x_24223)) {
      case TAG_InL: {
        V v_x_24224 = heff_field(v_x_24223, 0);
        heff_take_n(v_x_24223, 1ULL, 1);
        V v_t_24225 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(), 0)), 3, (V[]){v_m_24219, v_g_24220, v_x_24224}));
        v_t_24228 = heff_tag_at_n(v_ru_24p_24221_24InL, TAG_InL, 1, (V[]){v_t_24225});
        break;
      }
      case TAG_InR: {
        V v_y_24226 = heff_field(v_x_24223, 0);
        V v_ru_24x_24223_24InR = heff_take_reuse_n(v_x_24223, 1ULL, 1);
        heff_drop_cell(v_ru_24p_24221_24InL, 1);
        V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_24219, v_g_24220, v_y_24226}));
        v_t_24228 = heff_tag_at_n(v_ru_24x_24223_24InR, TAG_InR, 1, (V[]){v_t_24227});
        break;
      }
      default: heff_nomatch(v_x_24223);
      }
      v_t_24237 = heff_tag_at_n(v_ru_24x_24222_24InL, TAG_InL, 1, (V[]){v_t_24228});
      break;
    }
    case TAG_InR: {
      V v_y_24229 = heff_field(v_x_24222, 0);
      V v_ru_24x_24222_24InR = heff_take_reuse_n(v_x_24222, 1ULL, 1);
      heff_drop(v_m_24219);
      heff_drop_cell(v_ru_24p_24221_24InL, 1);
      V v_t_24236;
      switch (heff_tag_of(v_y_24229)) {
      case TAG_UseColor: {
        V v_k_24230 = heff_field(v_y_24229, 0);
        V v_ru_24y_24229_24UseColor = heff_take_reuse_n(v_y_24229, 1ULL, 1);
        v_t_24236 = heff_tag_at_n(v_ru_24y_24229_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam28, 1, 2, (V[]){v_k_24230, v_g_24220})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_24233 = heff_field(v_y_24229, 0);
        V v_ru_24y_24229_24ErrColor = heff_take_reuse_n(v_y_24229, 1ULL, 1);
        v_t_24236 = heff_tag_at_n(v_ru_24y_24229_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_app_2eheff_2emain_2emain_lam29, 1, 2, (V[]){v_k_24233, v_g_24220})});
        break;
      }
      default: heff_nomatch(v_y_24229);
      }
      v_t_24237 = heff_tag_at_n(v_ru_24x_24222_24InR, TAG_InR, 1, (V[]){v_t_24236});
      break;
    }
    default: heff_nomatch(v_x_24222);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_24237});
  }
  case TAG_InR: {
    V v_y_24238 = heff_field(v_p_24221, 0);
    V v_ru_24p_24221_24InR = heff_take_reuse_n(v_p_24221, 1ULL, 1);
    V v_t_24239 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_24219, v_g_24220, v_y_24238}));
    return heff_tag_at_n(v_ru_24p_24221_24InR, TAG_InR, 1, (V[]){v_t_24239});
  }
  default: return heff_nomatch(v_p_24221);
  }
}
V g_app_2eheff_2emain_2emain_lam30(V self, V *args) {
  V v_m_24240 = args[0];
  V v_n_24241 = args[1];
  V v_nt_24242 = args[2];
  V v_p_24243 = args[3];
  switch (heff_tag_of(v_p_24243)) {
  case TAG_InL: {
    V v_x_24244 = heff_field(v_p_24243, 0);
    V v_ru_24p_24243_24InL = heff_take_reuse_n(v_p_24243, 1ULL, 1);
    heff_drop(v_m_24240);
    heff_drop(v_n_24241);
    heff_drop(v_nt_24242);
    return heff_tag_at_n(v_ru_24p_24243_24InL, TAG_InL, 1, (V[]){v_x_24244});
  }
  case TAG_InR: {
    V v_y_24245 = heff_field(v_p_24243, 0);
    V v_ru_24p_24243_24InR = heff_take_reuse_n(v_p_24243, 1ULL, 1);
    V v_t_24246 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_24240, v_n_24241, v_nt_24242, v_y_24245}));
    return heff_tag_at_n(v_ru_24p_24243_24InR, TAG_InR, 1, (V[]){v_t_24246});
  }
  default: return heff_nomatch(v_p_24243);
  }
}
V g_app_2eheff_2emain_2emain_lam32(V self, V *args) {
  V v_x_24256 = args[0];
  V v_t_24253 = heff_env(self)[0];
  V v_hd_24254 = heff_env(self)[1];
  V v_k_24255 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_app_2eheff_2emain_2eunheard_24s1646521510x754669279(v_t_24253, v_x_24256, v_hd_24254, v_k_24255));
}
V g_app_2eheff_2emain_2emain_lam31(V self, V *args) {
  V v_hd_24254 = args[0];
  V v_k_24255 = args[1];
  V v_c_24218 = heff_env(self)[0];
  V v_t_24253 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24218;
  args[0] = heff_dup(v_hd_24254);
  args[1] = heff_clo_n(g_app_2eheff_2emain_2emain_lam32, 1, 3, (V[]){v_t_24253, v_hd_24254, v_k_24255});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}