// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361 38668
#define TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481 14273
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetMut 50164
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2eelab_2elocals_2earguments(V, V, V);
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_clo;
HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V, V);
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo;
HeffT2 g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(V, V);
HeffT2 g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_24cpr(V, V);
HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V, V);
V g_heff_2eelab_2elocals_2elamBinders(V);
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elamBinders_clo;
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V, V);
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V, V, V, V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
HeffT2 g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(V, V);
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24dps(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo;
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V, V);
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo;
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_list_2efilter_24s2018073091x1385246979(V);
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1133029339x682401273(V);
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_clo;
V g_list_2emap_24f342794667x1308411312(V, V);
V g_list_2emap_24f342794667x1308411312_entry(V self, V *a);
extern Clo g_list_2emap_24f342794667x1308411312_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;

static V g_heff_2eelab_2elocals_2enone_val;
static HEFF_ONCE g_heff_2eelab_2elocals_2enone_st;
static V g_heff_2eelab_2elocals_2enone_init(void) {
  return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2elocals_2enone_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2elocals_2enone_st)) return g_heff_2eelab_2elocals_2enone_val;
  return heff_global(&g_heff_2eelab_2elocals_2enone_val, &g_heff_2eelab_2elocals_2enone_st, g_heff_2eelab_2elocals_2enone_init);
}

HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_b_242, 0)), heff_dup(v_x_240))) {
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_b_242}});
    } else {
      heff_drop_rec(v_b_242, 3);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_p2_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2eelab_2elocals_2epatternBinders_str0), 2)) {
        heff_drop(v_p2_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_243, v_p2_242, NTAG(TAG_False)});
        return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2420));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_241, 0);
      V v_sp_2424 = heff_field(v_p1_241, 1);
      V v_q_2425 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop(v_p2_242);
      V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
      V v_cell_2427 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2425, heff_dup(v_cell_2427)));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24dps_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24dps_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_p2_243 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24dps_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        V v_t_247 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_247);
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2411); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2412);
    }
    case TAG_PatOp: {
      V v_ps_2415 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2415));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2416); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2417);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2421 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2423);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2425 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2425));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2426); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2427);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2429 = heff_field(v_p1_242, 0);
      V v_sp_2430 = heff_field(v_p1_242, 1);
      V v_q_2431 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2432 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_sp_2430, NTAG(TAG_False)});
      V v_cell_2433 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2432, heff_hole()});
      V v_u_2434 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2433));
      heff_drop(v_u_2434);
      V t_0 = v_q_2431;
      V t_1 = v_cell_2433;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str1, 1, "_");
Clo g_heff_2eelab_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_241, ((V)&g_heff_2eelab_2elocals_2elamBinders_str0), 2)) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_245 = heff_field(v_x1_240, 0);
    V v_sp_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2eelab_2elocals_2elamBinders_str1), 2)) {
      heff_drop(v_x_245);
      heff_drop(v_sp_246);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_248 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_245, v_sp_246, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_249 = heff_field(v_x1_240, 0);
    V v_sp_2410 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_249, v_sp_2410, NTAG(TAG_False)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry, 2, 0};

V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_248));
        V v_b_2412;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2412 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2411 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2412 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2411));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_t_2413 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2410, 0), heff_take_field(v_b_2412, 0)));
        V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2410, 1, 2), heff_get_n(v_b_2412, 1, 2)));
        V v_t_2415 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2416 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_env_240}), v_rest_243));
        V v_t_2417 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2418 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
        V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2418, heff_take_field(v_b_2416, 0)));
        V v_t_2420 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2416, 1, 2)));
        V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2419));
        V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2420));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2421, v_t_2422});
      }
      case TAG_BadFieldDecl: {
        V v_f_2423 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2424 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_f_2423));
        V v_b_2425 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_rest_243));
        V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2424, 0), heff_take_field(v_b_2425, 0)));
        V v_t_2427 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2424, 1, 2), heff_get_n(v_b_2425, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2426, v_t_2427});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry, 2, 0};

V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_248));
        V v_t_2410 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2411 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_env_240}), v_rest_243));
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2413 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_take_field(v_b_2411, 0)));
        V v_t_2415 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
        V v_t_2416 = (g_prelude_2e_2b_2b(heff_take_field(v_a_249, 0), v_t_2414));
        V v_t_2417 = (g_prelude_2e_2b_2b(heff_get_n(v_a_249, 1, 2), v_t_2415));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2416, v_t_2417});
      }
      case TAG_StmtLet: {
        V v_p_2418 = heff_field(v_x311_244, 0);
        V v_e_2419 = heff_field(v_x311_244, 1);
        heff_take_n(v_x311_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2420 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2419));
        V v_bs_2421 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_p_2418)));
        V v_env_2422 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2418));
        V v_b_2423 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2422, v_rest_243));
        V v_t_2424 = (g_prelude_2e_2b_2b(v_bs_2421, heff_take_field(v_b_2423, 0)));
        V v_t_2425 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2423, 1, 2)));
        V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2420, 0), v_t_2424));
        V v_t_2427 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2420, 1, 2), v_t_2425));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2426, v_t_2427});
      }
      case TAG_StmtExpr: {
        V v_e_2428 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2429 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2428));
        V v_b_2430 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_rest_243));
        V v_t_2431 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2429, 0), heff_take_field(v_b_2430, 0)));
        V v_t_2432 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2429, 1, 2), heff_get_n(v_b_2430, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2431, v_t_2432});
      }
      case TAG_StmtLetMut: {
        V v_x_2433 = heff_field(v_x311_244, 0);
        V v_sp_2434 = heff_field(v_x311_244, 1);
        V v_e_2435 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2436 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2435));
        V v_t_2437 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2433), heff_dup(v_sp_2434), NTAG(TAG_False)});
        V v_b_2438 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2437, v_env_240}), v_rest_243));
        V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2433, v_sp_2434, NTAG(TAG_False)});
        V v_t_2440 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
        V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2440, heff_take_field(v_b_2438, 0)));
        V v_t_2442 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2438, 1, 2)));
        V v_t_2443 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2436, 0), v_t_2441));
        V v_t_2444 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2436, 1, 2), v_t_2442));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2443, v_t_2444});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 12ULL, 4);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, v_rhs_247));
      V v_f_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_take_field(v_b_2411, 0)));
      V v_f_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
      return ((HeffT2){{v_f_2412, v_f_2413}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_t_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_247 = ({ V a_0 = v_x_244; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_244); r_; });
      V v_a_2413;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_b_2411 = v_field_249;
          V v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2411, v_xsp_245}), NTAG(TAG_Nil)});
          v_a_2413 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2412});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_245);
          heff_drop(v_field_249);
          v_a_2413 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_b_2414 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_246));
      V v_f_2415 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2413, 0), heff_take_field(v_b_2414, 0)));
      V v_f_2416 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2413, 1, 2), heff_get_n(v_b_2414, 1, 2)));
      return ((HeffT2){{v_f_2415, v_f_2416}});
    }
    case TAG_ImplicitParam: {
      V v_x_2417 = heff_field(v_x31_242, 0);
      V v_xsp_2418 = heff_field(v_x31_242, 1);
      V v_t_2419 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_2420 = ({ V a_0 = v_x_2417; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2417); r_; });
      V v_a_2426;
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_b_2424 = v_field_2422;
          V v_t_2425 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2424, v_xsp_2418}), NTAG(TAG_Nil)});
          v_a_2426 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2425});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2418);
          heff_drop(v_field_2422);
          v_a_2426 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_b_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2419));
      V v_f_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2426, 0), heff_take_field(v_b_2427, 0)));
      V v_f_2429 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2426, 1, 2), heff_get_n(v_b_2427, 1, 2)));
      return ((HeffT2){{v_f_2428, v_f_2429}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry, 2, 0};

V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x31_242, 0);
      V v_fsp_245 = heff_field(v_x31_242, 1);
      V v_ty_247 = heff_field(v_x31_242, 3);
      V v_eqs_248 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 27ULL, 5);
      HeffT2 v_t_249 = ({ V a_0 = v_f_244; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_244); r_; });
      V v_a_2415;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_b_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2413, v_fsp_245}), NTAG(TAG_Nil)});
          v_a_2415 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2414});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_fsp_245);
          heff_drop(v_field_2411);
          v_a_2415 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_a_2416 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_ty_247));
      V v_b_2424 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2416, 0), heff_take_field(v_b_2424, 0)));
      V v_t_2426 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2416, 1, 2), heff_get_n(v_b_2424, 1, 2)));
      V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2415, 0), v_t_2425));
      V v_t_2428 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2415, 1, 2), v_t_2426));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2427, v_t_2428});
    }
    case TAG_DeclDefine: {
      V v_x_2429 = heff_field(v_x31_242, 0);
      V v_xsp_2430 = heff_field(v_x31_242, 1);
      V v_ps_2431 = heff_field(v_x31_242, 2);
      V v_u_2432 = heff_field(v_x31_242, 3);
      V v_body_2433 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 31ULL, 5);
      HeffT2 v_t_2434 = ({ V a_0 = v_x_2429; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2429); r_; });
      V v_a_2440;
      {
        V v_field_2436 = v_t_2434.f[1];
        int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
        if ((v_tag_2435 == ((int64_t)0ULL))) {
          V v_b_2438 = v_field_2436;
          V v_t_2439 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2438, v_xsp_2430}), NTAG(TAG_Nil)});
          v_a_2440 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2439});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2430);
          heff_drop(v_field_2436);
          v_a_2440 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_a_2448 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_ps_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2431); r_; });
      V v_a_2449 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_u_2432));
      V v_b_2450 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2433));
      V v_t_2451 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2449, 0), heff_take_field(v_b_2450, 0)));
      V v_t_2452 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2449, 1, 2), heff_get_n(v_b_2450, 1, 2)));
      V v_t_2453 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2448, 0), v_t_2451));
      V v_t_2454 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2448, 1, 2), v_t_2452));
      V v_t_2455 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2440, 0), v_t_2453));
      V v_t_2456 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2440, 1, 2), v_t_2454));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2455, v_t_2456});
    }
    case TAG_DeclTheory: {
      V v_body_2460 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2460);
    }
    case TAG_DeclPrimitive: {
      V v_x_2461 = heff_field(v_x31_242, 0);
      V v_xsp_2462 = heff_field(v_x31_242, 1);
      V v_t_2463 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_2464 = ({ V a_0 = v_x_2461; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2461); r_; });
      V v_a_2470;
      {
        V v_field_2466 = v_t_2464.f[1];
        int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
        if ((v_tag_2465 == ((int64_t)0ULL))) {
          V v_b_2468 = v_field_2466;
          V v_t_2469 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2468, v_xsp_2462}), NTAG(TAG_Nil)});
          v_a_2470 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2469});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2462);
          heff_drop(v_field_2466);
          v_a_2470 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_b_2471 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2463));
      V v_t_2472 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2470, 0), heff_take_field(v_b_2471, 0)));
      V v_t_2473 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2470, 1, 2), heff_get_n(v_b_2471, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2472, v_t_2473});
    }
    case TAG_DeclTest: {
      V v_x_2474 = heff_field(v_x31_242, 0);
      V v_xsp_2475 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      HeffT2 v_t_2476 = ({ V a_0 = v_x_2474; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2474); r_; });
      {
        V v_field_2478 = v_t_2476.f[1];
        int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
        if ((v_tag_2477 == ((int64_t)0ULL))) {
          V v_b_2480 = v_field_2478;
          V v_t_2481 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2480, v_xsp_2475}), NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2481});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2475);
          heff_drop(v_field_2478);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
    }
    case TAG_DeclWatch: {
      V v_e_2482 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_2482);
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args) {
  V v_acc_2417 = args[0];
  V v_eq_2418 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(v_env_240, v_eq_2418));
  {
    V v_field_2420 = v_t_2419.f[0];
    V v_field_2421 = v_t_2419.f[1];
    V v_t_2422 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2417, 0), v_field_2420));
    V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2417, 1, 2), v_field_2421));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2422, v_t_2423});
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args) {
  V v_acc_2441 = args[0];
  V v_m_2442 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2443 = (g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(v_env_240, v_m_2442));
  {
    V v_field_2444 = v_t_2443.f[0];
    V v_field_2445 = v_t_2443.f[1];
    V v_t_2446 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2441, 0), v_field_2444));
    V v_t_2447 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2441, 1, 2), v_field_2445));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2446, v_t_2447});
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry, 2, 0};

V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      heff_take_n(v_d1_242, 24ULL, 5);
      heff_drop_tag(v_d_241, 2);
      V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), heff_dup(v_ty_247)));
      V v_b_2433 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_t_2434 = (g_prelude_2e_2b_2b(heff_take_field(v_a_249, 0), heff_take_field(v_b_2433, 0)));
      V v_t_2435 = (g_prelude_2e_2b_2b(heff_get_n(v_a_249, 1, 2), heff_get_n(v_b_2433, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2434, v_t_2435});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_d1_242, 0ULL, 5);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_d1_242, 0ULL, 4);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_d1_242, 0ULL, 3);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_d1_242, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_eq_2411 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2424;
  switch (heff_tag_of(v_eq_2411)) {
  case TAG_At: {
    V v_x21_2412 = heff_dup(heff_field(v_eq_2411, 0));
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_fsp_2415 = heff_field(v_x21_2412, 1);
      heff_take_n(v_x21_2412, 3ULL, 4);
      HeffT2 v_t_2418 = ({ V a_0 = v_f_2414; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_2414); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_b_2422 = v_field_2420;
          V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2422, v_fsp_2415}), NTAG(TAG_Nil)});
          v_a_2424 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2423});
        } else {
          heff_drop(v_fsp_2415);
          heff_drop(v_field_2420);
          v_a_2424 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      break;
    }
    default: heff_nomatch(v_x21_2412);
    }
    break;
  }
  default: heff_nomatch(v_eq_2411);
  }
  V v_t_2425 = (g_list_2efoldl_24f1488358745x465096512(v_env_240, v_ty_247));
  HeffT2 v_t_2426 = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(v_t_2425, v_eq_2411));
  {
    V v_field_2427 = v_t_2426.f[0];
    V v_field_2428 = v_t_2426.f[1];
    V v_t_2429 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2424, 0), v_field_2427));
    V v_t_2430 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2424, 1, 2), v_field_2428));
    V v_t_2431 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2410, 0), v_t_2429));
    V v_t_2432 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2410, 1, 2), v_t_2430));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2431, v_t_2432});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4, 0, "");
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry, 6, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V v_tag_240, V v_env_241, V v_x3_242, V v_body_243, V v_env_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: {
    top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: ;
    heff_drop(v_env_244);
    heff_drop(v_n_245);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
      V t_1 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1);
      V t_3 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2);
      V t_4 = v_env_241;
      V t_5 = v_body_243;
      v_tag_240 = t_0;
      v_env_241 = t_1;
      v_x3_242 = t_2;
      v_body_243 = t_3;
      v_env_244 = t_4;
      v_n_245 = t_5;
      goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
    }
    case TAG_Cons: {
      V v_d_246 = heff_field(v_x3_242, 0);
      V v_ds_247 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2431;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_248 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_248)) {
        case TAG_DeclEquations: {
          V v_f_2410 = heff_field(v_d1_248, 0);
          V v_fsp_2411 = heff_field(v_d1_248, 1);
          heff_take_n(v_d1_248, 3ULL, 5);
          V v_t_2415 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2410, v_fsp_2411, NTAG(TAG_False)});
          v_t_2431 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_248, 0ULL, 5);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_248, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_248, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_248, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_248, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_248);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_241), v_t_2431));
      V v_a_2433 = (g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(v_t_2432, heff_dup(v_d_246)));
      V v_t_2457;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2434 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_2434)) {
        case TAG_DeclEquations: {
          V v_f_2436 = heff_field(v_d1_2434, 0);
          V v_fsp_2437 = heff_field(v_d1_2434, 1);
          heff_take_n(v_d1_2434, 3ULL, 5);
          V v_t_2441 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2436, v_fsp_2437, NTAG(TAG_False)});
          v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2434, 0ULL, 5);
          v_t_2457 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2434, 0ULL, 4);
          v_t_2457 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2434, 0ULL, 3);
          v_t_2457 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2434, 0ULL, 2);
          v_t_2457 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2434, 0ULL, 1);
          v_t_2457 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2434);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(v_env_241, v_t_2457));
      V v_b_2459 = (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_t_2458, v_ds_247, v_body_243));
      V v_t_2460 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2433, 0), heff_take_field(v_b_2459, 0)));
      V v_t_2461 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2433, 1, 2), heff_get_n(v_b_2459, 1, 2)));
      V v_t_2485;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2462 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24At = heff_take_reuse_n(v_d_246, 1ULL, 2);
        switch (heff_tag_of(v_d1_2462)) {
        case TAG_DeclEquations: {
          V v_f_2464 = heff_field(v_d1_2462, 0);
          V v_fsp_2465 = heff_field(v_d1_2462, 1);
          heff_take_n(v_d1_2462, 3ULL, 5);
          V v_t_2469 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2464, v_fsp_2465, NTAG(TAG_False)});
          v_t_2485 = heff_tag_at_n(v_ru_24d_246_24At, TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2462, 0ULL, 5);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2485 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2462, 0ULL, 4);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2485 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2462, 0ULL, 3);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2485 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2462, 0ULL, 2);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2485 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2462, 0ULL, 1);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2485 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2462);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2486 = (g_prelude_2e_2b_2b(v_t_2485, v_t_2460));
      V v_t_2487 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2461));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2486, v_t_2487});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: {
    top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: ;
    switch (heff_tag_of(v_n_245)) {
    case TAG_At: {
      V v_n1_2488 = heff_dup(heff_field(v_n_245, 0));
      switch (heff_tag_of(v_n1_2488)) {
      case TAG_EVar: {
        V v_x_2490 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        HeffT2 v_t_2491 = ({ V a_0 = v_x_2490; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2490); r_; });
        {
          V v_field_2493 = v_t_2491.f[1];
          int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
          if ((v_tag_2492 == ((int64_t)0ULL))) {
            V v_b_2495 = v_field_2493;
            V v_t_2498;
            switch (heff_tag_of(v_n_245)) {
            case TAG_At: {
              V v_s_2497 = heff_field(v_n_245, 1);
              heff_take_n(v_n_245, 2ULL, 2);
              v_t_2498 = v_s_2497;
              break;
            }
            default: heff_nomatch(v_n_245);
            }
            V v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2495, v_t_2498}), NTAG(TAG_Nil)});
            return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2499});
          } else {
            heff_drop_tag(v_n_245, 2);
            heff_drop(v_field_2493);
            return heff_dup(g_heff_2eelab_2elocals_2enone_get());
          }
        }
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_ETag: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EInt: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EFloat: {
        heff_take_na(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EString: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EBinary: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_ERune: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EWord: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EApp: {
        V v_h_24108 = heff_field(v_n1_2488, 0);
        V v_args_24109 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24110 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_h_24108));
        V v_b_24116 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24109; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24109); r_; });
        V v_t_24117 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24110, 0), heff_take_field(v_b_24116, 0)));
        V v_t_24118 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24110, 1, 2), heff_get_n(v_b_24116, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24117, v_t_24118});
      }
      case TAG_EProject: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_ENamed: {
        V v_e_24121 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 2ULL, 2);
        heff_drop_tag(v_n_245, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
        V t_1 = v_env_241;
        V t_2 = v_x3_242;
        V t_3 = v_body_243;
        V t_4 = v_env_244;
        V t_5 = v_e_24121;
        v_tag_240 = t_0;
        v_env_241 = t_1;
        v_x3_242 = t_2;
        v_body_243 = t_3;
        v_env_244 = t_4;
        v_n_245 = t_5;
        goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
      }
      case TAG_EPi: {
        V v_n11_24122 = heff_field(v_n1_2488, 0);
        V v_r_24123 = heff_field(v_n1_2488, 1);
        V v_ru_24n1_2488_24EPi = heff_take_reuse_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        switch (heff_tag_of(v_n11_24122)) {
        case TAG_PiNamed: {
          V v_x_24124 = heff_field(v_n11_24122, 0);
          V v_sp_24125 = heff_field(v_n11_24122, 1);
          V v_a_24126 = heff_field(v_n11_24122, 2);
          heff_take_n(v_n11_24122, 7ULL, 3);
          V v_a_24127 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24126));
          V v_t_24128 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24124), heff_dup(v_sp_24125), NTAG(TAG_False)});
          V v_t_24129 = heff_tag_at_n(v_ru_24n1_2488_24EPi, TAG_Cons, 2, (V[]){v_t_24128, NTAG(TAG_Nil)});
          V v_env_24130 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24129));
          V v_b_24131 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24130, v_r_24123));
          V v_t_24132 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24124, v_sp_24125, NTAG(TAG_False)});
          V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
          V v_t_24134 = (g_prelude_2e_2b_2b(v_t_24133, heff_take_field(v_b_24131, 0)));
          V v_t_24135 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24131, 1, 2)));
          V v_t_24136 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24127, 0), v_t_24134));
          V v_t_24137 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24127, 1, 2), v_t_24135));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24136, v_t_24137});
        }
        case TAG_PiImplicit: {
          V v_x_24138 = heff_field(v_n11_24122, 0);
          V v_sp_24139 = heff_field(v_n11_24122, 1);
          V v_a_24141 = heff_field(v_n11_24122, 3);
          V v_d_24142 = heff_field(v_n11_24122, 4);
          heff_take_n(v_n11_24122, 27ULL, 5);
          V v_a_24143 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24141));
          V v_b_24145;
          switch (heff_tag_of(v_d_24142)) {
          case TAG_Nothing: {
            v_b_24145 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            break;
          }
          case TAG_Just: {
            V v_x_24144 = heff_field(v_d_24142, 0);
            heff_take_n(v_d_24142, 1ULL, 1);
            v_b_24145 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24144));
            break;
          }
          default: heff_nomatch(v_d_24142);
          }
          V v_t_24146 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24143, 0), heff_take_field(v_b_24145, 0)));
          V v_t_24147 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24143, 1, 2), heff_get_n(v_b_24145, 1, 2)));
          V v_t_24148 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24138), heff_dup(v_sp_24139), NTAG(TAG_False)});
          V v_t_24149 = heff_tag_at_n(v_ru_24n1_2488_24EPi, TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
          V v_env_24150 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24149));
          V v_b_24151 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24150, v_r_24123));
          V v_t_24152 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24138, v_sp_24139, NTAG(TAG_False)});
          V v_t_24153 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24152, NTAG(TAG_Nil)});
          V v_t_24154 = (g_prelude_2e_2b_2b(v_t_24153, heff_take_field(v_b_24151, 0)));
          V v_t_24155 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24151, 1, 2)));
          V v_t_24156 = (g_prelude_2e_2b_2b(v_t_24146, v_t_24154));
          V v_t_24157 = (g_prelude_2e_2b_2b(v_t_24147, v_t_24155));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24156, v_t_24157});
        }
        case TAG_PiInstance: {
          V v_x_24158 = heff_field(v_n11_24122, 0);
          V v_sp_24159 = heff_field(v_n11_24122, 1);
          V v_a_24161 = heff_field(v_n11_24122, 3);
          heff_take_n(v_n11_24122, 11ULL, 4);
          V v_a_24162 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24161));
          V v_t_24163 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24158), heff_dup(v_sp_24159), NTAG(TAG_False)});
          V v_t_24164 = heff_tag_at_n(v_ru_24n1_2488_24EPi, TAG_Cons, 2, (V[]){v_t_24163, NTAG(TAG_Nil)});
          V v_env_24165 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24164));
          V v_b_24166 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24165, v_r_24123));
          V v_t_24167 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24158, v_sp_24159, NTAG(TAG_False)});
          V v_t_24168 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24167, NTAG(TAG_Nil)});
          V v_t_24169 = (g_prelude_2e_2b_2b(v_t_24168, heff_take_field(v_b_24166, 0)));
          V v_t_24170 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24166, 1, 2)));
          V v_t_24171 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24162, 0), v_t_24169));
          V v_t_24172 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24162, 1, 2), v_t_24170));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24171, v_t_24172});
        }
        case TAG_PiAnon: {
          V v_a_24173 = heff_field(v_n11_24122, 0);
          heff_take_n(v_n11_24122, 1ULL, 1);
          heff_drop_cell(v_ru_24n1_2488_24EPi, 2);
          V v_a_24174 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24173));
          V v_b_24175 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_r_24123));
          V v_t_24176 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24174, 0), heff_take_field(v_b_24175, 0)));
          V v_t_24177 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24174, 1, 2), heff_get_n(v_b_24175, 1, 2)));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24176, v_t_24177});
        }
        default: return heff_nomatch(v_n11_24122);
        }
      }
      case TAG_ELam: {
        V v_n11_24178 = heff_field(v_n1_2488, 0);
        V v_r_24179 = heff_field(v_n1_2488, 1);
        V v_ru_24n1_2488_24ELam = heff_take_reuse_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        switch (heff_tag_of(v_n11_24178)) {
        case TAG_LamName: {
          heff_drop_cell(v_ru_24n1_2488_24ELam, 2);
          V v_bs_24182 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24178));
          V v_env_24183 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24182)));
          V v_b_24184 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24183, v_r_24179));
          V v_t_24185 = (g_prelude_2e_2b_2b(v_bs_24182, heff_take_field(v_b_24184, 0)));
          V v_t_24186 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24184, 1, 2)));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24185, v_t_24186});
        }
        case TAG_LamImplicit: {
          heff_drop_cell(v_ru_24n1_2488_24ELam, 2);
          V v_bs_24189 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24178));
          V v_env_24190 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24189)));
          V v_b_24191 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24190, v_r_24179));
          V v_t_24192 = (g_prelude_2e_2b_2b(v_bs_24189, heff_take_field(v_b_24191, 0)));
          V v_t_24193 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24191, 1, 2)));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24192, v_t_24193});
        }
        case TAG_LamAnn: {
          V v_x_24194 = heff_field(v_n11_24178, 0);
          V v_sp_24195 = heff_field(v_n11_24178, 1);
          V v_a_24196 = heff_field(v_n11_24178, 2);
          heff_take_n(v_n11_24178, 7ULL, 3);
          V v_a_24197 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24196));
          V v_t_24198 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24194), heff_dup(v_sp_24195), NTAG(TAG_False)});
          V v_t_24199 = heff_tag_at_n(v_ru_24n1_2488_24ELam, TAG_Cons, 2, (V[]){v_t_24198, NTAG(TAG_Nil)});
          V v_env_24200 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24199));
          V v_b_24201 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24200, v_r_24179));
          V v_t_24202 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24194, v_sp_24195, NTAG(TAG_False)});
          V v_t_24203 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24202, NTAG(TAG_Nil)});
          V v_t_24204 = (g_prelude_2e_2b_2b(v_t_24203, heff_take_field(v_b_24201, 0)));
          V v_t_24205 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24201, 1, 2)));
          V v_t_24206 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24197, 0), v_t_24204));
          V v_t_24207 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24197, 1, 2), v_t_24205));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24206, v_t_24207});
        }
        default: return heff_nomatch(v_n11_24178);
        }
      }
      case TAG_EAnn: {
        V v_e_24208 = heff_field(v_n1_2488, 0);
        V v_t_24209 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24210 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24208));
        V v_b_24211 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_t_24209));
        V v_t_24212 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24210, 0), heff_take_field(v_b_24211, 0)));
        V v_t_24213 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24210, 1, 2), heff_get_n(v_b_24211, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24212, v_t_24213});
      }
      case TAG_ESpec: {
        V v_acc_24214 = heff_field(v_n1_2488, 0);
        V v_v_24217 = heff_field(v_n1_2488, 3);
        heff_take_n(v_n1_2488, 9ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24218 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_acc_24214));
        V v_b_24219 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_v_24217));
        V v_t_24220 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24218, 0), heff_take_field(v_b_24219, 0)));
        V v_t_24221 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24218, 1, 2), heff_get_n(v_b_24219, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24220, v_t_24221});
      }
      case TAG_ESig: {
        V v_fs_24222 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        return (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_244, v_fs_24222));
      }
      case TAG_ESum: {
        V v_vs_24223 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_vs_24223; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24223); r_; });
      }
      case TAG_EStruct: {
        V v_fs_24240 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_fs_24240; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24240); r_; });
      }
      case TAG_EUpdate: {
        V v_a_24252 = heff_field(v_n1_2488, 0);
        V v_fs_24253 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_t_24254 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24252));
        return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4, 2, 1, (V[]){v_env_244}); V a_1 = v_t_24254; V a_2 = v_fs_24253; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24253); r_; });
      }
      case TAG_EMatch: {
        V v_s_24264 = heff_field(v_n1_2488, 0);
        V v_alts_24265 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24266 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_s_24264));
        V v_b_24281 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_alts_24265; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24265); r_; });
        V v_t_24282 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24266, 0), heff_take_field(v_b_24281, 0)));
        V v_t_24283 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24266, 1, 2), heff_get_n(v_b_24281, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24282, v_t_24283});
      }
      case TAG_ELetIn: {
        V v_rhs_24284 = heff_field(v_n1_2488, 0);
        V v_a_24285 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24286 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_rhs_24284));
        V v_b_24296;
        switch (heff_tag_of(v_a_24285)) {
        case TAG_At: {
          V v_x31_24287 = heff_field(v_a_24285, 0);
          heff_take_n(v_a_24285, 1ULL, 2);
          switch (heff_tag_of(v_x31_24287)) {
          case TAG_MkAlt: {
            V v_p_24289 = heff_field(v_x31_24287, 0);
            V v_r_24290 = heff_field(v_x31_24287, 1);
            heff_take_n(v_x31_24287, 3ULL, 2);
            V v_bs_24291 = (g_heff_2eelab_2elocals_2epatternBinders(v_p_24289));
            V v_env_24292 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24291)));
            V v_b_24293 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24292, v_r_24290));
            V v_t_24294 = (g_prelude_2e_2b_2b(v_bs_24291, heff_take_field(v_b_24293, 0)));
            V v_t_24295 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24293, 1, 2)));
            v_b_24296 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24294, v_t_24295});
            break;
          }
          default: heff_nomatch(v_x31_24287);
          }
          break;
        }
        default: heff_nomatch(v_a_24285);
        }
        V v_t_24297 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24286, 0), heff_take_field(v_b_24296, 0)));
        V v_t_24298 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24286, 1, 2), heff_get_n(v_b_24296, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24297, v_t_24298});
      }
      case TAG_EDo: {
        V v_stmts_24299 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        return (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_stmts_24299));
      }
      case TAG_ELocal: {
        V v_body_24300 = heff_field(v_n1_2488, 0);
        V v_defs_24301 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361);
        V t_1 = v_env_244;
        V t_2 = v_defs_24301;
        V t_3 = v_body_24300;
        V t_4 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3);
        V t_5 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4);
        v_tag_240 = t_0;
        v_env_241 = t_1;
        v_x3_242 = t_2;
        v_body_243 = t_3;
        v_env_244 = t_4;
        v_n_245 = t_5;
        goto top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361;
      }
      case TAG_EInvalid: {
        heff_take_n(v_n1_2488, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EAssign: {
        V v_x_24303 = heff_field(v_n1_2488, 0);
        V v_xsp_24304 = heff_field(v_n1_2488, 1);
        V v_e_24305 = heff_field(v_n1_2488, 2);
        heff_take_n(v_n1_2488, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        HeffT2 v_t_24306 = ({ V a_0 = v_x_24303; V a_1 = heff_dup(v_env_244); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24303); r_; });
        V v_a_24312;
        {
          V v_field_24308 = v_t_24306.f[1];
          int64_t v_tag_24307 = ((int64_t)v_t_24306.f[0]);
          if ((v_tag_24307 == ((int64_t)0ULL))) {
            V v_b_24310 = v_field_24308;
            V v_t_24311 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24310, v_xsp_24304}), NTAG(TAG_Nil)});
            v_a_24312 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24311});
          } else {
            heff_drop(v_xsp_24304);
            heff_drop(v_field_24308);
            v_a_24312 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          }
        }
        V v_b_24313 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24305));
        V v_t_24314 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24312, 0), heff_take_field(v_b_24313, 0)));
        V v_t_24315 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24312, 1, 2), heff_get_n(v_b_24313, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24314, v_t_24315});
      }
      case TAG_EWhile: {
        V v_c_24316 = heff_field(v_n1_2488, 0);
        V v_body_24317 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24318 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24316));
        V v_b_24319 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_body_24317));
        V v_t_24320 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24318, 0), heff_take_field(v_b_24319, 0)));
        V v_t_24321 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24318, 1, 2), heff_get_n(v_b_24319, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24320, v_t_24321});
      }
      case TAG_EFor: {
        V v_p_24322 = heff_field(v_n1_2488, 0);
        V v_c_24323 = heff_field(v_n1_2488, 1);
        V v_body_24324 = heff_field(v_n1_2488, 2);
        heff_take_n(v_n1_2488, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24325 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24323));
        V v_bs_24326 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_p_24322)));
        V v_env_24327 = (g_list_2efoldl_24f1677743806x2032371213(v_env_244, v_p_24322));
        V v_b_24328 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24327, v_body_24324));
        V v_t_24329 = (g_prelude_2e_2b_2b(v_bs_24326, heff_take_field(v_b_24328, 0)));
        V v_t_24330 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24328, 1, 2)));
        V v_t_24331 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24325, 0), v_t_24329));
        V v_t_24332 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24325, 1, 2), v_t_24330));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24331, v_t_24332});
      }
      case TAG_EIfThen: {
        V v_c_24333 = heff_field(v_n1_2488, 0);
        V v_a_24334 = heff_field(v_n1_2488, 1);
        heff_take_n(v_n1_2488, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24335 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24333));
        V v_b_24336 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24334));
        V v_t_24337 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24335, 0), heff_take_field(v_b_24336, 0)));
        V v_t_24338 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24335, 1, 2), heff_get_n(v_b_24336, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24337, v_t_24338});
      }
      case TAG_EBreak: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EContinue: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        heff_drop_tag(v_n_245, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_EReturn: {
        V v_e_24339 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop_tag(v_n_245, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
        V t_1 = v_env_241;
        V t_2 = v_x3_242;
        V t_3 = v_body_243;
        V t_4 = v_env_244;
        V t_5 = v_e_24339;
        v_tag_240 = t_0;
        v_env_241 = t_1;
        v_x3_242 = t_2;
        v_body_243 = t_3;
        v_env_244 = t_4;
        v_n_245 = t_5;
        goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
      }
      case TAG_ENest: {
        V v_e_24340 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop_tag(v_n_245, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
        V t_1 = v_env_241;
        V t_2 = v_x3_242;
        V t_3 = v_body_243;
        V t_4 = v_env_244;
        V t_5 = v_e_24340;
        v_tag_240 = t_0;
        v_env_241 = t_1;
        v_x3_242 = t_2;
        v_body_243 = t_3;
        v_env_244 = t_4;
        v_n_245 = t_5;
        goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
      }
      case TAG_EIfLet: {
        V v_p_24341 = heff_field(v_n1_2488, 0);
        V v_s_24342 = heff_field(v_n1_2488, 1);
        V v_a_24343 = heff_field(v_n1_2488, 2);
        V v_b_24344 = heff_field(v_n1_2488, 3);
        heff_take_n(v_n1_2488, 15ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24345 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_s_24342));
        V v_bs_24346 = (g_heff_2eelab_2elocals_2epatternBinders(v_p_24341));
        V v_env_24347 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_244), heff_dup(v_bs_24346)));
        V v_b_24348 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24347, v_a_24343));
        V v_t_24349 = (g_prelude_2e_2b_2b(v_bs_24346, heff_take_field(v_b_24348, 0)));
        V v_t_24350 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24348, 1, 2)));
        V v_b_24352;
        switch (heff_tag_of(v_b_24344)) {
        case TAG_Nothing: {
          heff_drop(v_env_244);
          v_b_24352 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_24351 = heff_field(v_b_24344, 0);
          heff_take_n(v_b_24344, 1ULL, 1);
          v_b_24352 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24351));
          break;
        }
        default: heff_nomatch(v_b_24344);
        }
        V v_t_24353 = (g_prelude_2e_2b_2b(v_t_24349, heff_take_field(v_b_24352, 0)));
        V v_t_24354 = (g_prelude_2e_2b_2b(v_t_24350, heff_get_n(v_b_24352, 1, 2)));
        V v_t_24355 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24345, 0), v_t_24353));
        V v_t_24356 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24345, 1, 2), v_t_24354));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24355, v_t_24356});
      }
      case TAG_ETry: {
        V v_n11_24357 = heff_field(v_n1_2488, 0);
        heff_take_n(v_n1_2488, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        switch (heff_tag_of(v_n11_24357)) {
        case TAG_MkTry: {
          V v_ty_24358 = heff_field(v_n11_24357, 0);
          V v_body_24359 = heff_field(v_n11_24357, 1);
          V v_c_24360 = heff_field(v_n11_24357, 2);
          heff_take_n(v_n11_24357, 7ULL, 3);
          V v_a_24362;
          switch (heff_tag_of(v_ty_24358)) {
          case TAG_Nothing: {
            v_a_24362 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            break;
          }
          case TAG_Just: {
            V v_x_24361 = heff_field(v_ty_24358, 0);
            heff_take_n(v_ty_24358, 1ULL, 1);
            v_a_24362 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24361));
            break;
          }
          default: heff_nomatch(v_ty_24358);
          }
          V v_b_24363 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_244), v_body_24359));
          V v_t_24364 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24362, 0), heff_take_field(v_b_24363, 0)));
          V v_t_24365 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24362, 1, 2), heff_get_n(v_b_24363, 1, 2)));
          HeffT2 v_t_24366 = (g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(v_env_244, v_c_24360));
          {
            V v_field_24367 = v_t_24366.f[0];
            V v_field_24368 = v_t_24366.f[1];
            V v_t_24369 = (g_prelude_2e_2b_2b(v_t_24364, v_field_24367));
            V v_t_24370 = (g_prelude_2e_2b_2b(v_t_24365, v_field_24368));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24369, v_t_24370});
          }
        }
        default: return heff_nomatch(v_n11_24357);
        }
      }
      case TAG_EWith: {
        V v_e_24371 = heff_field(v_n1_2488, 0);
        V v_x_24372 = heff_field(v_n1_2488, 1);
        V v_xsp_24373 = heff_field(v_n1_2488, 2);
        V v_body_24374 = heff_field(v_n1_2488, 3);
        heff_take_n(v_n1_2488, 15ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop_tag(v_n_245, 2);
        V v_a_24375 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24371));
        V v_t_24376 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24372), heff_dup(v_xsp_24373), NTAG(TAG_False)});
        V v_t_24377 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24376, NTAG(TAG_Nil)});
        V v_env_24378 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24377));
        V v_b_24379 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24378, v_body_24374));
        V v_t_24380 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24372, v_xsp_24373, NTAG(TAG_False)});
        V v_t_24381 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24380, NTAG(TAG_Nil)});
        V v_t_24382 = (g_prelude_2e_2b_2b(v_t_24381, heff_take_field(v_b_24379, 0)));
        V v_t_24383 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24379, 1, 2)));
        V v_t_24384 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24375, 0), v_t_24382));
        V v_t_24385 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24375, 1, 2), v_t_24383));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24384, v_t_24385});
      }
      default: return heff_nomatch(v_n1_2488);
      }
    }
    default: return heff_nomatch(v_n_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args) {
  V v_acc_24111 = args[0];
  V v_x_24112 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24113 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24112));
  V v_t_24114 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24111, 0), heff_take_field(v_b_24113, 0)));
  V v_t_24115 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24111, 1, 2), heff_get_n(v_b_24113, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24114, v_t_24115});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args) {
  V v_acc_24231 = args[0];
  V v_x_24232 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24233 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24232));
  V v_t_24234 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24231, 0), heff_take_field(v_b_24233, 0)));
  V v_t_24235 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24231, 1, 2), heff_get_n(v_b_24233, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24234, v_t_24235});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args) {
  V v_acc_24224 = args[0];
  V v_v_24225 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24237;
  switch (heff_tag_of(v_v_24225)) {
  case TAG_At: {
    V v_it1_24226 = heff_field(v_v_24225, 0);
    heff_take_n(v_v_24225, 1ULL, 2);
    switch (heff_tag_of(v_it1_24226)) {
    case TAG_TagVariant: {
      V v_args_24230 = heff_field(v_it1_24226, 2);
      heff_take_n(v_it1_24226, 4ULL, 3);
      v_b_24237 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24230; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24230); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24236 = heff_field(v_it1_24226, 0);
      heff_take_n(v_it1_24226, 1ULL, 1);
      v_b_24237 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24236));
      break;
    }
    default: heff_nomatch(v_it1_24226);
    }
    break;
  }
  default: heff_nomatch(v_v_24225);
  }
  V v_t_24238 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24224, 0), heff_take_field(v_b_24237, 0)));
  V v_t_24239 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24224, 1, 2), heff_get_n(v_b_24237, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24238, v_t_24239});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args) {
  V v_acc_24241 = args[0];
  V v_f_24242 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24249;
  switch (heff_tag_of(v_f_24242)) {
  case TAG_At: {
    V v_x31_24243 = heff_field(v_f_24242, 0);
    heff_take_n(v_f_24242, 1ULL, 2);
    switch (heff_tag_of(v_x31_24243)) {
    case TAG_SetField: {
      V v_e_24247 = heff_field(v_x31_24243, 2);
      heff_take_n(v_x31_24243, 4ULL, 3);
      v_b_24249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24247));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24248 = heff_field(v_x31_24243, 0);
      heff_take_n(v_x31_24243, 1ULL, 1);
      v_b_24249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24248));
      break;
    }
    default: heff_nomatch(v_x31_24243);
    }
    break;
  }
  default: heff_nomatch(v_f_24242);
  }
  V v_t_24250 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24241, 0), heff_take_field(v_b_24249, 0)));
  V v_t_24251 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24241, 1, 2), heff_get_n(v_b_24249, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24250, v_t_24251});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args) {
  V v_acc_24255 = args[0];
  V v_f_24256 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24256)) {
  case TAG_At: {
    V v_it1_24257 = heff_field(v_f_24256, 0);
    heff_take_n(v_f_24256, 1ULL, 2);
    switch (heff_tag_of(v_it1_24257)) {
    case TAG_SetPath: {
      V v_e_24260 = heff_field(v_it1_24257, 1);
      heff_take_n(v_it1_24257, 2ULL, 2);
      V v_b_24261 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24260));
      V v_t_24262 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24255, 0), heff_take_field(v_b_24261, 0)));
      V v_t_24263 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24255, 1, 2), heff_get_n(v_b_24261, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24262, v_t_24263});
    }
    default: return heff_nomatch(v_it1_24257);
    }
  }
  default: return heff_nomatch(v_f_24256);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args) {
  V v_acc_24267 = args[0];
  V v_a_24268 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24278;
  switch (heff_tag_of(v_a_24268)) {
  case TAG_At: {
    V v_x31_24269 = heff_field(v_a_24268, 0);
    heff_take_n(v_a_24268, 1ULL, 2);
    switch (heff_tag_of(v_x31_24269)) {
    case TAG_MkAlt: {
      V v_p_24271 = heff_field(v_x31_24269, 0);
      V v_r_24272 = heff_field(v_x31_24269, 1);
      heff_take_n(v_x31_24269, 3ULL, 2);
      V v_bs_24273 = (g_heff_2eelab_2elocals_2epatternBinders(v_p_24271));
      V v_env_24274 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24273)));
      V v_b_24275 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24274, v_r_24272));
      V v_t_24276 = (g_prelude_2e_2b_2b(v_bs_24273, heff_take_field(v_b_24275, 0)));
      V v_t_24277 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24275, 1, 2)));
      v_b_24278 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24276, v_t_24277});
      break;
    }
    default: heff_nomatch(v_x31_24269);
    }
    break;
  }
  default: heff_nomatch(v_a_24268);
  }
  V v_t_24279 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24267, 0), heff_take_field(v_b_24278, 0)));
  V v_t_24280 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24267, 1, 2), heff_get_n(v_b_24278, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24279, v_t_24280});
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1, 0, "");
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry, 3, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361), v_env_240, v_x3_241, v_body_242, ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0), ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1)));
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkCatchArm: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ss_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkCatchArm = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_LamName: {
      heff_drop_cell(v_ru_24x3_241_24MkCatchArm, 2);
      V v_bs_246 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_247 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_248 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_247));
      V v_b_249 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_248, v_ss_243));
      V v_f_2410 = (g_prelude_2e_2b_2b(v_bs_246, heff_take_field(v_b_249, 0)));
      V v_f_2411 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_249, 1, 2)));
      return ((HeffT2){{v_f_2410, v_f_2411}});
    }
    case TAG_LamImplicit: {
      heff_drop_cell(v_ru_24x3_241_24MkCatchArm, 2);
      V v_bs_2414 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_2415 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_2416 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2415));
      V v_b_2417 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2416, v_ss_243));
      V v_f_2418 = (g_prelude_2e_2b_2b(v_bs_2414, heff_take_field(v_b_2417, 0)));
      V v_f_2419 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2417, 1, 2)));
      return ((HeffT2){{v_f_2418, v_f_2419}});
    }
    case TAG_LamAnn: {
      V v_x_2420 = heff_field(v_x31_242, 0);
      V v_sp_2421 = heff_field(v_x31_242, 1);
      V v_t_2422 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_a_2423 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2422));
      V v_t_2424 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2420), heff_dup(v_sp_2421), NTAG(TAG_False)});
      V v_t_2425 = heff_tag_at_n(v_ru_24x3_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
      V v_env_2426 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2425));
      V v_b_2427 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2426, v_ss_243));
      V v_t_2428 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2420, v_sp_2421, NTAG(TAG_False)});
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2429, heff_take_field(v_b_2427, 0)));
      V v_t_2431 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2427, 1, 2)));
      V v_f_2432 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2423, 0), v_t_2430));
      V v_f_2433 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2423, 1, 2), v_t_2431));
      return ((HeffT2){{v_f_2432, v_f_2433}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2, 0, "");
Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry, 2, 0};

V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V v_env_240, V v_n_241) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2), v_env_240, v_n_241));
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2earguments_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_entry, 3, 0};

V g_heff_2eelab_2elocals_2earguments(V v_env_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2eelab_2elocals_2earguments_lam0, 2, 1, (V[]){v_env_240}), heff_dup(g_heff_2eelab_2elocals_2enone_get()), v_rest_242);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_tl_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_x211_2410 = heff_field(v_x21_248, 0);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 1ULL, 2);
      switch (heff_tag_of(v_x211_2410)) {
      case TAG_ExplicitParam: {
        V v_x_2412 = heff_field(v_x211_2410, 0);
        V v_sp_2413 = heff_field(v_x211_2410, 1);
        V v_t_2414 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2415 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2414));
        V v_t_2416 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2412), heff_dup(v_sp_2413), NTAG(TAG_False)});
        V v_b_2417 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2418 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2412, v_sp_2413, NTAG(TAG_False)});
        V v_t_2419 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, heff_take_field(v_b_2417, 0)));
        V v_t_2421 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2417, 1, 2)));
        V v_t_2422 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2415, 0), v_t_2420));
        V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2415, 1, 2), v_t_2421));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2422, v_t_2423});
      }
      case TAG_ImplicitParam: {
        V v_x_2424 = heff_field(v_x211_2410, 0);
        V v_sp_2425 = heff_field(v_x211_2410, 1);
        V v_t_2426 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2426));
        V v_t_2428 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2424), heff_dup(v_sp_2425), NTAG(TAG_False)});
        V v_b_2429 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2428, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2430 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2424, v_sp_2425, NTAG(TAG_False)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
        V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, heff_take_field(v_b_2429, 0)));
        V v_t_2433 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2429, 1, 2)));
        V v_t_2434 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2427, 0), v_t_2432));
        V v_t_2435 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2427, 1, 2), v_t_2433));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2434, v_t_2435});
      }
      default: return heff_nomatch(v_x211_2410);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2elocals_2earguments(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_245 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_244));
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_243, 0), heff_take_field(v_b_245, 0)));
  V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_243, 1, 2), heff_get_n(v_b_245, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_246, v_t_247});
}

HeffT2 g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 12ULL, 4);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, v_rhs_247));
      V v_f_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_take_field(v_b_2411, 0)));
      V v_f_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
      return ((HeffT2){{v_f_2412, v_f_2413}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclaration_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclaration_entry, 1, 0};

V g_heff_2eelab_2elocals_2edeclaration(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_eqs_247 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 24ULL, 5);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_a_248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_ty_246)));
      V v_b_2417 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclaration_lam0, 2, 1, (V[]){v_ty_246}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_247); r_; });
      V v_t_2418 = (g_prelude_2e_2b_2b(heff_take_field(v_a_248, 0), heff_take_field(v_b_2417, 0)));
      V v_t_2419 = (g_prelude_2e_2b_2b(heff_get_n(v_a_248, 1, 2), heff_get_n(v_b_2417, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2418, v_t_2419});
    }
    case TAG_DeclDefine: {
      V v_ps_2422 = heff_field(v_x11_241, 2);
      V v_ty_2423 = heff_field(v_x11_241, 3);
      V v_body_2424 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 28ULL, 5);
      V v_t_2425 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2424, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2422; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_ty_2423, v_t_2425}); V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    }
    case TAG_DeclTheory: {
      V v_ps_2428 = heff_field(v_x11_241, 2);
      V v_body_2429 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 12ULL, 4);
      V v_t_2430 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2429, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2428; V a_2 = v_t_2430; V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, a_2)); heff_drop_tag(v_t_2430, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      V v_t_2433 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_t_2433));
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_DeclWatch: {
      V v_e_2436 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_e_2436));
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclaration(a[0]);
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_eq_2410 = args[1];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_list_2efoldl_24f1488358745x465096512(NTAG(TAG_Nil), v_ty_246));
  HeffT2 v_t_2412 = (g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_24cpr(v_t_2411, v_eq_2410));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_t_2415 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_249, 0), v_field_2413));
    V v_t_2416 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_249, 1, 2), v_field_2414));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2415, v_t_2416});
  }
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V v_found_240) {
top: ;
  V v_t_241 = (g_list_2efilter_24s2018073091x1385246979(heff_dup(heff_rfield(v_found_240, 0))));
  V v_f_244 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_found_240)}), v_t_241));
  V v_f_245 = (g_list_2emap_24f1133029339x682401273(heff_get_n(v_found_240, 1, 2)));
  return ((HeffT2){{v_f_244, v_f_245}});
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args) {
  V v_b_242 = args[0];
  V v_found_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_list_2emap_24f342794667x1308411312(heff_dup(v_b_242), heff_get_n(v_found_240, 1, 2)));
  return heff_rec_n(3, shape_name__binder__uses, (V[]){heff_dup(heff_rfield(v_b_242, 0)), heff_get_n(v_b_242, 1, 3), v_t_243});
}
Clo g_heff_2eelab_2elocals_2elocalsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsOf_entry, 1, 0};

V g_heff_2eelab_2elocals_2elocalsOf(V v_found_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_found_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_locals__fields, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsOf(a[0]);
}