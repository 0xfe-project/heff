// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361 38668
#define TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481 14273
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo;
HeffT2 g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V, V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo;
HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo;
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V, V);
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo;
HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V, V);
V g_heff_2eelab_2elocals_2elamBinders(V);
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elamBinders_clo;
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V, V);
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V, V, V, V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24dps(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo;
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V, V);
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo;
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s228254919x1092684261(V, V, V);
V g_list_2efoldl_24s228254919x1092684261_entry(V self, V *a);
extern Clo g_list_2efoldl_24s228254919x1092684261_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2ekeepIf_24s1266148589x1647110933(V);
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1213328022x1811586494(V, V);
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_clo;
V g_list_2emap_24f565269645x1954016017(V);
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_REC_LIT(g_heff_2eelab_2elocals_2enone_lit0, 2, shape_binders__uses, NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2eelab_2elocals_2enone_val;
static HEFF_ONCE g_heff_2eelab_2elocals_2enone_st;
static V g_heff_2eelab_2elocals_2enone_init(void) {
  return ((V)&g_heff_2eelab_2elocals_2enone_lit0);
}
V g_heff_2eelab_2elocals_2enone_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2elocals_2enone_st)) return g_heff_2eelab_2elocals_2enone_val;
  return heff_global(&g_heff_2eelab_2elocals_2enone_val, &g_heff_2eelab_2elocals_2enone_st, g_heff_2eelab_2elocals_2enone_init);
}

HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_b_242, 0)), heff_dup(v_x_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_b_242)}});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_p2_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2eelab_2elocals_2epatternBinders_str0), 2)) {
        heff_drop(v_p2_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_244 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_243, v_p2_242, NTAG(TAG_False)});
        return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_247));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2411 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2416 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2416));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2417); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2419 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2419));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2420); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2422 = heff_field(v_p1_241, 0);
      V v_sp_2423 = heff_field(v_p1_241, 1);
      V v_q_2424 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop(v_p2_242);
      V v_t_2425 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2422, v_sp_2423, NTAG(TAG_False)});
      V v_cell_2426 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
      V v_u_2427 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2424, v_cell_2426));
      heff_drop(v_u_2427);
      return v_cell_2426;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24dps_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24dps_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_p2_243 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24dps_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        V v_t_246 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
        return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_246);
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2411);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2416);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2420));
      V v_t_2422 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2421); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2422);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2424 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2425); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2426);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2428 = heff_field(v_p1_242, 0);
      V v_sp_2429 = heff_field(v_p1_242, 1);
      V v_q_2430 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2431 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2428, v_sp_2429, NTAG(TAG_False)});
      V v_cell_2432 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2431, heff_hole()});
      V v_u_2433 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2432);
      V t_0 = v_q_2430;
      V t_1 = v_u_2433;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2epatternBinders_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str1, 1, "_");
Clo g_heff_2eelab_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_241, ((V)&g_heff_2eelab_2elocals_2elamBinders_str0), 2)) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_243 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_sp_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2elamBinders_str1), 2)) {
      heff_drop(v_x_244);
      heff_drop(v_sp_245);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_245, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_247 = heff_field(v_x1_240, 0);
    V v_sp_248 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2410 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_247, v_sp_248, NTAG(TAG_False)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry, 2, 0};

V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_248));
        V v_binders_2411 = heff_take_field(v_a_2410, 0);
        V v_uses_2412 = heff_get_n(v_a_2410, 1, 2);
        V v_b_2414;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2414 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2413 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2414 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2413));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_binders_2415 = heff_take_field(v_b_2414, 0);
        V v_uses_2416 = heff_get_n(v_b_2414, 1, 2);
        V v_t_2417 = (g_prelude_2e_2b_2b(v_binders_2411, v_binders_2415));
        V v_t_2418 = (g_prelude_2e_2b_2b(v_uses_2412, v_uses_2416));
        V v_t_2419 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2420 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, v_env_240}), v_rest_243));
        V v_binders_2421 = heff_take_field(v_b_2420, 0);
        V v_uses_2422 = heff_take_field(v_b_2420, 1);
        V v_t_2423 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2417, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2423, v_binders_2421})));
        V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2418, v_uses_2422));
        return ({ V rv_0 = v_t_2424; V rv_1 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_b_2420, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_BadFieldDecl: {
        V v_f_2426 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_f_2426));
        V v_binders_2428 = heff_take_field(v_a_2427, 0);
        V v_uses_2429 = heff_get_n(v_a_2427, 1, 2);
        V v_b_2430 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_rest_243));
        V v_binders_2431 = heff_take_field(v_b_2430, 0);
        V v_uses_2432 = heff_take_field(v_b_2430, 1);
        V v_t_2433 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2428, v_binders_2431));
        V v_t_2434 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2429, v_uses_2432));
        return ({ V rv_0 = v_t_2433; V rv_1 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_b_2430, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry, 2, 0};

V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_248));
        V v_binders_2410 = heff_take_field(v_a_249, 0);
        V v_uses_2411 = heff_get_n(v_a_249, 1, 2);
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2413 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, v_env_240}), v_rest_243));
        V v_binders_2414 = heff_take_field(v_b_2413, 0);
        V v_uses_2415 = heff_take_field(v_b_2413, 1);
        V v_t_2416 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2417 = (g_prelude_2e_2b_2b(v_binders_2410, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2416, v_binders_2414})));
        V v_t_2418 = (g_prelude_2e_2b_2b(v_uses_2411, v_uses_2415));
        return ({ V rv_0 = v_t_2417; V rv_1 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_b_2413, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_StmtLet: {
        V v_p_2419 = heff_field(v_x311_244, 0);
        V v_e_2420 = heff_field(v_x311_244, 1);
        V v_ru_24x311_244_24StmtLet = heff_take_reuse_n(v_x311_244, 3ULL, 2);
        V v_a_2421 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2420));
        V v_binders_2422 = heff_take_field(v_a_2421, 0);
        V v_uses_2423 = heff_get_n(v_a_2421, 1, 2);
        V v_bs_2424 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2419)));
        V v_env_2425 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2419));
        V v_b_2426 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2425, v_rest_243));
        V v_binders_2427 = heff_take_field(v_b_2426, 0);
        V v_uses_2428 = heff_take_field(v_b_2426, 1);
        V v_t_2429 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2424, v_binders_2427));
        V v_t_2430 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x311_244_24StmtLet, v_binders_2422, v_t_2429));
        V v_t_2431 = (g_prelude_2e_2b_2b(v_uses_2423, v_uses_2428));
        return ({ V rv_0 = v_t_2430; V rv_1 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_b_2426, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_StmtExpr: {
        V v_e_2432 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2433 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2432));
        V v_binders_2434 = heff_take_field(v_a_2433, 0);
        V v_uses_2435 = heff_get_n(v_a_2433, 1, 2);
        V v_b_2436 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_rest_243));
        V v_binders_2437 = heff_take_field(v_b_2436, 0);
        V v_uses_2438 = heff_take_field(v_b_2436, 1);
        V v_t_2439 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2434, v_binders_2437));
        V v_t_2440 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2435, v_uses_2438));
        return ({ V rv_0 = v_t_2439; V rv_1 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_b_2436, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_StmtLetMut: {
        V v_x_2441 = heff_field(v_x311_244, 0);
        V v_sp_2442 = heff_field(v_x311_244, 1);
        V v_e_2443 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2444 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2443));
        V v_binders_2445 = heff_take_field(v_a_2444, 0);
        V v_uses_2446 = heff_get_n(v_a_2444, 1, 2);
        V v_t_2447 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2441), heff_dup(v_sp_2442), NTAG(TAG_False)});
        V v_b_2448 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2447, v_env_240}), v_rest_243));
        V v_binders_2449 = heff_take_field(v_b_2448, 0);
        V v_uses_2450 = heff_take_field(v_b_2448, 1);
        V v_t_2451 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2441, v_sp_2442, NTAG(TAG_False)});
        V v_t_2452 = (g_prelude_2e_2b_2b(v_binders_2445, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2451, v_binders_2449})));
        V v_t_2453 = (g_prelude_2e_2b_2b(v_uses_2446, v_uses_2450));
        return ({ V rv_0 = v_t_2452; V rv_1 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_b_2448, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_StmtLetElse: {
        V v_p_2454 = heff_field(v_x311_244, 0);
        V v_e_2455 = heff_field(v_x311_244, 1);
        V v_ss_2456 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2457 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2455));
        V v_binders_2458 = heff_take_field(v_a_2457, 0);
        V v_uses_2459 = heff_get_n(v_a_2457, 1, 2);
        V v_a_2460 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_240), v_ss_2456));
        V v_binders_2461 = heff_take_field(v_a_2460, 0);
        V v_uses_2462 = heff_get_n(v_a_2460, 1, 2);
        V v_bs_2463 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2454)));
        V v_env_2464 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2454));
        V v_b_2465 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2464, v_rest_243));
        V v_binders_2466 = heff_take_field(v_b_2465, 0);
        V v_uses_2467 = heff_take_field(v_b_2465, 1);
        V v_t_2468 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2463, v_binders_2466));
        V v_t_2469 = (g_prelude_2e_2b_2b(v_binders_2461, v_t_2468));
        V v_t_2470 = (g_prelude_2e_2b_2b(v_uses_2462, v_uses_2467));
        V v_t_2471 = (g_prelude_2e_2b_2b(v_binders_2458, v_t_2469));
        V v_t_2472 = (g_prelude_2e_2b_2b(v_uses_2459, v_t_2470));
        return ({ V rv_0 = v_t_2471; V rv_1 = v_t_2472; V rr_ = heff_rec_reuse_nf(v_b_2465, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry, 2, 0};

V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x31_242, 0);
      V v_fsp_245 = heff_field(v_x31_242, 1);
      V v_ty_247 = heff_field(v_x31_242, 3);
      V v_eqs_248 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 27ULL, 5);
      HeffT2 v_t_249 = ({ V a_0 = v_f_244; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_244); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_a_2414;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_b_2412 = v_field_2411;
          V v_t_2413 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2412, v_fsp_245}), NTAG(TAG_Nil)});
          v_a_2414 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2413});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_fsp_245);
          heff_drop(v_field_2411);
          v_a_2414 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2415 = heff_take_field(v_a_2414, 0);
        V v_uses_2416 = heff_get_n(v_a_2414, 1, 2);
        V v_a_2417 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_ty_247));
        V v_binders_2418 = heff_take_field(v_a_2417, 0);
        V v_uses_2419 = heff_get_n(v_a_2417, 1, 2);
        V v_b_2440 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
        V v_binders_2441 = heff_take_field(v_b_2440, 0);
        V v_uses_2442 = heff_take_field(v_b_2440, 1);
        V v_t_2443 = (g_prelude_2e_2b_2b(v_binders_2418, v_binders_2441));
        V v_t_2444 = (g_prelude_2e_2b_2b(v_uses_2419, v_uses_2442));
        V v_t_2445 = (g_prelude_2e_2b_2b(v_binders_2415, v_t_2443));
        V v_t_2446 = (g_prelude_2e_2b_2b(v_uses_2416, v_t_2444));
        return ({ V rv_0 = v_t_2445; V rv_1 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_b_2440, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
    }
    case TAG_DeclDefine: {
      V v_x_2447 = heff_field(v_x31_242, 0);
      V v_xsp_2448 = heff_field(v_x31_242, 1);
      V v_ps_2449 = heff_field(v_x31_242, 2);
      V v_u_2450 = heff_field(v_x31_242, 3);
      V v_body_2451 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 31ULL, 5);
      HeffT2 v_t_2452 = ({ V a_0 = v_x_2447; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2447); r_; });
      {
        V v_field_2454 = v_t_2452.f[1];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        V v_a_2457;
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_b_2455 = v_field_2454;
          V v_t_2456 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2455, v_xsp_2448}), NTAG(TAG_Nil)});
          v_a_2457 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2456});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2448);
          heff_drop(v_field_2454);
          v_a_2457 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2458 = heff_take_field(v_a_2457, 0);
        V v_uses_2459 = heff_get_n(v_a_2457, 1, 2);
        V v_a_24105 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_ps_2449; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2449); r_; });
        V v_binders_24106 = heff_take_field(v_a_24105, 0);
        V v_uses_24107 = heff_get_n(v_a_24105, 1, 2);
        V v_a_24108 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_u_2450));
        V v_binders_24109 = heff_take_field(v_a_24108, 0);
        V v_uses_24110 = heff_get_n(v_a_24108, 1, 2);
        V v_b_24111 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2451));
        V v_binders_24112 = heff_take_field(v_b_24111, 0);
        V v_uses_24113 = heff_take_field(v_b_24111, 1);
        V v_t_24114 = (g_prelude_2e_2b_2b(v_binders_24109, v_binders_24112));
        V v_t_24115 = (g_prelude_2e_2b_2b(v_uses_24110, v_uses_24113));
        V v_t_24116 = (g_prelude_2e_2b_2b(v_binders_24106, v_t_24114));
        V v_t_24117 = (g_prelude_2e_2b_2b(v_uses_24107, v_t_24115));
        V v_t_24118 = (g_prelude_2e_2b_2b(v_binders_2458, v_t_24116));
        V v_t_24119 = (g_prelude_2e_2b_2b(v_uses_2459, v_t_24117));
        return ({ V rv_0 = v_t_24118; V rv_1 = v_t_24119; V rr_ = heff_rec_reuse_nf(v_b_24111, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
    }
    case TAG_DeclTheory: {
      V v_body_24123 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_24123);
    }
    case TAG_DeclPrimitive: {
      V v_x_24124 = heff_field(v_x31_242, 0);
      V v_xsp_24125 = heff_field(v_x31_242, 1);
      V v_t_24126 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_24127 = ({ V a_0 = v_x_24124; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24124); r_; });
      {
        V v_field_24129 = v_t_24127.f[1];
        int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
        V v_a_24132;
        if ((v_tag_24128 == ((int64_t)0ULL))) {
          V v_b_24130 = v_field_24129;
          V v_t_24131 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24130, v_xsp_24125}), NTAG(TAG_Nil)});
          v_a_24132 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24131});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_24125);
          heff_drop(v_field_24129);
          v_a_24132 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_24133 = heff_take_field(v_a_24132, 0);
        V v_uses_24134 = heff_get_n(v_a_24132, 1, 2);
        V v_b_24135 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_24126));
        V v_binders_24136 = heff_take_field(v_b_24135, 0);
        V v_uses_24137 = heff_take_field(v_b_24135, 1);
        V v_t_24138 = (g_prelude_2e_2b_2b(v_binders_24133, v_binders_24136));
        V v_t_24139 = (g_prelude_2e_2b_2b(v_uses_24134, v_uses_24137));
        return ({ V rv_0 = v_t_24138; V rv_1 = v_t_24139; V rr_ = heff_rec_reuse_nf(v_b_24135, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
    }
    case TAG_DeclTest: {
      V v_x_24140 = heff_field(v_x31_242, 0);
      V v_xsp_24141 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      HeffT2 v_t_24142 = ({ V a_0 = v_x_24140; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24140); heff_drop(v_env_240); r_; });
      {
        V v_field_24144 = v_t_24142.f[1];
        int64_t v_tag_24143 = ((int64_t)v_t_24142.f[0]);
        if ((v_tag_24143 == ((int64_t)0ULL))) {
          V v_b_24145 = v_field_24144;
          V v_t_24146 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24145, v_xsp_24141}), NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24146});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_24141);
          heff_drop(v_field_24144);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
    }
    case TAG_DeclWatch: {
      V v_e_24147 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24147);
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_eq_2421 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_binders_2422 = heff_take_field(v_acc_2420, 0);
  V v_uses_2423 = heff_get_n(v_acc_2420, 1, 2);
  V v_b_2435;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_eq_2421)) {
  case TAG_At: {
    V v_x31_2424 = heff_field(v_eq_2421, 0);
    V v_ru_24eq_2421_24At = heff_take_reuse_n(v_eq_2421, 1ULL, 2);
    switch (heff_tag_of(v_x31_2424)) {
    case TAG_MkEquation: {
      V v_ps_2428 = heff_field(v_x31_2424, 2);
      V v_rhs_2429 = heff_field(v_x31_2424, 3);
      heff_take_n(v_x31_2424, 12ULL, 4);
      V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2428));
      V v_bs_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2430); r_; });
      V v_env_2432 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_2431)));
      V v_b_2433 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2432, v_rhs_2429));
      V v_t_2434 = (g_prelude_2e_2b_2b_24tok2(v_ru_24eq_2421_24At, v_bs_2431, heff_take_field(v_b_2433, 0)));
      v_b_2435 = ({ V rv_0 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_b_2433, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_2424);
    }
    break;
  }
  default: heff_nomatch(v_eq_2421);
  }
  V v_binders_2436 = heff_take_field(v_b_2435, 0);
  V v_uses_2437 = heff_take_field(v_b_2435, 1);
  V v_t_2438 = (g_prelude_2e_2b_2b(v_binders_2422, v_binders_2436));
  V v_t_2439 = (g_prelude_2e_2b_2b(v_uses_2423, v_uses_2437));
  return ({ V rv_0 = v_t_2438; V rv_1 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_b_2435, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args) {
  V v_acc_2460 = args[0];
  V v_m_2461 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_binders_2462 = heff_take_field(v_acc_2460, 0);
  V v_uses_2463 = heff_take_field(v_acc_2460, 1);
  heff_clo_take(self, 1);
  V v_env_2464 = v_env_240;
  V v_x3_2465 = v_m_2461;
  V v_b_24100;
  switch (heff_tag_of(v_x3_2465)) {
  case TAG_At: {
    V v_x31_2466 = heff_field(v_x3_2465, 0);
    V v_ru_24x3_2465_24At = heff_take_reuse_n(v_x3_2465, 1ULL, 2);
    switch (heff_tag_of(v_x31_2466)) {
    case TAG_ExplicitParam: {
      V v_x_2468 = heff_field(v_x31_2466, 0);
      V v_xsp_2469 = heff_field(v_x31_2466, 1);
      V v_t_2470 = heff_field(v_x31_2466, 2);
      heff_take_n(v_x31_2466, 7ULL, 3);
      HeffT2 v_t_2471 = ({ V a_0 = v_x_2468; V a_1 = v_env_2464; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2468); r_; });
      {
        V v_field_2473 = v_t_2471.f[1];
        int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
        V v_a_2476;
        if ((v_tag_2472 == ((int64_t)0ULL))) {
          V v_b_2474 = v_field_2473;
          V v_t_2475 = heff_tag_at_n(v_ru_24x3_2465_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2474, v_xsp_2469}), NTAG(TAG_Nil)});
          v_a_2476 = ({ V rv_0 = NTAG(TAG_Nil); V rv_1 = v_t_2475; V rr_ = heff_rec_reuse_nf(v_acc_2460, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        } else {
          heff_drop_rec(v_acc_2460, 2);
          heff_drop_cell(v_ru_24x3_2465_24At, 2);
          heff_drop(v_xsp_2469);
          heff_drop(v_field_2473);
          v_a_2476 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2477 = heff_take_field(v_a_2476, 0);
        V v_uses_2478 = heff_get_n(v_a_2476, 1, 2);
        V v_b_2479 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2464, v_t_2470));
        V v_binders_2480 = heff_take_field(v_b_2479, 0);
        V v_uses_2481 = heff_take_field(v_b_2479, 1);
        V v_t_2482 = (g_prelude_2e_2b_2b(v_binders_2477, v_binders_2480));
        V v_t_2483 = (g_prelude_2e_2b_2b(v_uses_2478, v_uses_2481));
        v_b_24100 = ({ V rv_0 = v_t_2482; V rv_1 = v_t_2483; V rr_ = heff_rec_reuse_nf(v_b_2479, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      break;
    }
    case TAG_ImplicitParam: {
      V v_x_2484 = heff_field(v_x31_2466, 0);
      V v_xsp_2485 = heff_field(v_x31_2466, 1);
      V v_t_2486 = heff_field(v_x31_2466, 2);
      heff_take_n(v_x31_2466, 7ULL, 3);
      HeffT2 v_t_2487 = ({ V a_0 = v_x_2484; V a_1 = v_env_2464; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2484); r_; });
      {
        V v_field_2489 = v_t_2487.f[1];
        int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
        V v_a_2492;
        if ((v_tag_2488 == ((int64_t)0ULL))) {
          V v_b_2490 = v_field_2489;
          V v_t_2491 = heff_tag_at_n(v_ru_24x3_2465_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2490, v_xsp_2485}), NTAG(TAG_Nil)});
          v_a_2492 = ({ V rv_0 = NTAG(TAG_Nil); V rv_1 = v_t_2491; V rr_ = heff_rec_reuse_nf(v_acc_2460, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        } else {
          heff_drop_rec(v_acc_2460, 2);
          heff_drop_cell(v_ru_24x3_2465_24At, 2);
          heff_drop(v_xsp_2485);
          heff_drop(v_field_2489);
          v_a_2492 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2493 = heff_take_field(v_a_2492, 0);
        V v_uses_2494 = heff_get_n(v_a_2492, 1, 2);
        V v_b_2495 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2464, v_t_2486));
        V v_binders_2496 = heff_take_field(v_b_2495, 0);
        V v_uses_2497 = heff_take_field(v_b_2495, 1);
        V v_t_2498 = (g_prelude_2e_2b_2b(v_binders_2493, v_binders_2496));
        V v_t_2499 = (g_prelude_2e_2b_2b(v_uses_2494, v_uses_2497));
        v_b_24100 = ({ V rv_0 = v_t_2498; V rv_1 = v_t_2499; V rr_ = heff_rec_reuse_nf(v_b_2495, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      break;
    }
    default: heff_nomatch(v_x31_2466);
    }
    break;
  }
  default: heff_nomatch(v_x3_2465);
  }
  V v_binders_24101 = heff_take_field(v_b_24100, 0);
  V v_uses_24102 = heff_take_field(v_b_24100, 1);
  V v_t_24103 = (g_prelude_2e_2b_2b(v_binders_2462, v_binders_24101));
  V v_t_24104 = (g_prelude_2e_2b_2b(v_uses_2463, v_uses_24102));
  return ({ V rv_0 = v_t_24103; V rv_1 = v_t_24104; V rr_ = heff_rec_reuse_nf(v_b_24100, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry, 2, 0};

V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      heff_take_n(v_d1_242, 24ULL, 5);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 0ULL, 2);
        V v_a_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), heff_dup(v_ty_247)));
        V v_binders_2412 = heff_take_field(v_a_2411, 0);
        V v_uses_2413 = heff_get_n(v_a_2411, 1, 2);
        V v_b_2452 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
        V v_binders_2453 = heff_take_field(v_b_2452, 0);
        V v_uses_2454 = heff_take_field(v_b_2452, 1);
        V v_t_2455 = (g_prelude_2e_2b_2b_24tok2(v_ru_24d_241_24At, v_binders_2412, v_binders_2453));
        V v_t_2456 = (g_prelude_2e_2b_2b(v_uses_2413, v_uses_2454));
        return ({ V rv_0 = v_t_2455; V rv_1 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_b_2452, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_d1_242, 0ULL, 5);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_d1_242, 0ULL, 4);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_d1_242, 0ULL, 3);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_d1_242, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_eq_2415 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  V v_binders_2416 = heff_take_field(v_acc_2414, 0);
  V v_uses_2417 = heff_take_field(v_acc_2414, 1);
  V v_a_2429;
  switch (heff_tag_of(v_eq_2415)) {
  case TAG_At: {
    V v_x21_2418 = heff_dup(heff_field(v_eq_2415, 0));
    switch (heff_tag_of(v_x21_2418)) {
    case TAG_MkEquation: {
      V v_f_2420 = heff_field(v_x21_2418, 0);
      V v_fsp_2421 = heff_field(v_x21_2418, 1);
      heff_take_n(v_x21_2418, 3ULL, 4);
      HeffT2 v_t_2424 = ({ V a_0 = v_f_2420; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_2420); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_b_2427 = v_field_2426;
          V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2427, v_fsp_2421}), NTAG(TAG_Nil)});
          v_a_2429 = ({ V rv_0 = NTAG(TAG_Nil); V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_acc_2414, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        } else {
          heff_drop_rec(v_acc_2414, 2);
          heff_drop(v_fsp_2421);
          heff_drop(v_field_2426);
          v_a_2429 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      break;
    }
    default: heff_nomatch(v_x21_2418);
    }
    break;
  }
  default: heff_nomatch(v_eq_2415);
  }
  V v_binders_2430 = heff_take_field(v_a_2429, 0);
  V v_uses_2431 = heff_get_n(v_a_2429, 1, 2);
  heff_clo_take(self, 2);
  V v_env_2432 = (g_list_2efoldl_24f1488358745x465096512(v_env_240, v_ty_247));
  V v_x3_2433 = v_eq_2415;
  V v_b_2445;
  switch (heff_tag_of(v_x3_2433)) {
  case TAG_At: {
    V v_x31_2434 = heff_field(v_x3_2433, 0);
    V v_ru_24x3_2433_24At = heff_take_reuse_n(v_x3_2433, 1ULL, 2);
    switch (heff_tag_of(v_x31_2434)) {
    case TAG_MkEquation: {
      V v_ps_2438 = heff_field(v_x31_2434, 2);
      V v_rhs_2439 = heff_field(v_x31_2434, 3);
      heff_take_n(v_x31_2434, 12ULL, 4);
      V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2438));
      V v_bs_2441 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2440; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2440); r_; });
      V v_env_2442 = (g_list_2efoldl_24s1370882877x364361272(v_env_2432, heff_dup(v_bs_2441)));
      V v_b_2443 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2442, v_rhs_2439));
      V v_t_2444 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_2433_24At, v_bs_2441, heff_take_field(v_b_2443, 0)));
      v_b_2445 = ({ V rv_0 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_b_2443, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_2434);
    }
    break;
  }
  default: heff_nomatch(v_x3_2433);
  }
  V v_binders_2446 = heff_take_field(v_b_2445, 0);
  V v_uses_2447 = heff_take_field(v_b_2445, 1);
  V v_t_2448 = (g_prelude_2e_2b_2b(v_binders_2430, v_binders_2446));
  V v_t_2449 = (g_prelude_2e_2b_2b(v_uses_2431, v_uses_2447));
  V v_t_2450 = (g_prelude_2e_2b_2b(v_binders_2416, v_t_2448));
  V v_t_2451 = (g_prelude_2e_2b_2b(v_uses_2417, v_t_2449));
  return ({ V rv_0 = v_t_2450; V rv_1 = v_t_2451; V rr_ = heff_rec_reuse_nf(v_b_2445, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str6, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str7, 1, "_");
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam7(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry, 6, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V v_tag_240, V v_env_241, V v_x3_242, V v_body_243, V v_env_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: {
    top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: ;
    heff_drop(v_env_244);
    heff_drop(v_n_245);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
      V t_1 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1);
      V t_3 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2);
      V t_4 = v_env_241;
      V t_5 = v_body_243;
      v_tag_240 = t_0;
      v_env_241 = t_1;
      v_x3_242 = t_2;
      v_body_243 = t_3;
      v_env_244 = t_4;
      v_n_245 = t_5;
      goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
    }
    case TAG_Cons: {
      V v_d_246 = heff_field(v_x3_242, 0);
      V v_ds_247 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2431;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_248 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_248)) {
        case TAG_DeclEquations: {
          V v_f_2410 = heff_field(v_d1_248, 0);
          V v_fsp_2411 = heff_field(v_d1_248, 1);
          heff_take_n(v_d1_248, 3ULL, 5);
          V v_t_2415 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2410, v_fsp_2411, NTAG(TAG_False)});
          v_t_2431 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_248, 0ULL, 5);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_248, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_248, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_248, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_248, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_248);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2455;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2432 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_2432)) {
        case TAG_DeclEquations: {
          V v_f_2434 = heff_field(v_d1_2432, 0);
          V v_fsp_2435 = heff_field(v_d1_2432, 1);
          heff_take_n(v_d1_2432, 3ULL, 5);
          V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2434, v_fsp_2435, NTAG(TAG_False)});
          v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2432, 0ULL, 5);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2432, 0ULL, 4);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2432, 0ULL, 3);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2432, 0ULL, 2);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2432, 0ULL, 1);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2432);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_241), v_t_2455));
      V v_a_2457 = (g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(v_t_2456, heff_dup(v_d_246)));
      V v_binders_2458 = heff_take_field(v_a_2457, 0);
      V v_uses_2459 = heff_get_n(v_a_2457, 1, 2);
      V v_t_2483;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2460 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24At = heff_take_reuse_n(v_d_246, 1ULL, 2);
        switch (heff_tag_of(v_d1_2460)) {
        case TAG_DeclEquations: {
          V v_f_2462 = heff_field(v_d1_2460, 0);
          V v_fsp_2463 = heff_field(v_d1_2460, 1);
          heff_take_n(v_d1_2460, 3ULL, 5);
          V v_t_2467 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2462, v_fsp_2463, NTAG(TAG_False)});
          v_t_2483 = heff_tag_at_n(v_ru_24d_246_24At, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2460, 0ULL, 5);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2460, 0ULL, 4);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2460, 0ULL, 3);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2460, 0ULL, 2);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2460, 0ULL, 1);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2460);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2484 = (g_list_2efoldl_24s1370882877x364361272(v_env_241, v_t_2483));
      V v_b_2485 = (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_t_2484, v_ds_247, v_body_243));
      V v_binders_2486 = heff_take_field(v_b_2485, 0);
      V v_uses_2487 = heff_take_field(v_b_2485, 1);
      V v_t_2488 = (g_prelude_2e_2b_2b(v_binders_2458, v_binders_2486));
      V v_t_2489 = (g_prelude_2e_2b_2b(v_uses_2459, v_uses_2487));
      V v_t_2490 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2488));
      return ({ V rv_0 = v_t_2490; V rv_1 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_b_2485, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: {
    top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: ;
    switch (heff_tag_of(v_n_245)) {
    case TAG_At: {
      V v_n1_2491 = heff_dup(heff_field(v_n_245, 0));
      switch (heff_tag_of(v_n1_2491)) {
      case TAG_EVar: {
        V v_x_2493 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        HeffT2 v_t_2494 = ({ V a_0 = v_x_2493; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2493); heff_drop(v_env_244); r_; });
        {
          V v_field_2496 = v_t_2494.f[1];
          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
          if ((v_tag_2495 == ((int64_t)0ULL))) {
            V v_b_2497 = v_field_2496;
            V v_t_24100;
            switch (heff_tag_of(v_n_245)) {
            case TAG_At: {
              V v_s_2499 = heff_field(v_n_245, 1);
              heff_take_n(v_n_245, 2ULL, 2);
              v_t_24100 = v_s_2499;
              break;
            }
            default: heff_nomatch(v_n_245);
            }
            V v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2497, v_t_24100}), NTAG(TAG_Nil)});
            return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24101});
          } else {
            heff_drop_tag(v_n_245, 2);
            heff_drop(v_field_2496);
            return heff_dup(g_heff_2eelab_2elocals_2enone_get());
          }
        }
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENotationVar: {
        heff_take_n(v_n1_2491, 0ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETag: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInt: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFloat: {
        heff_take_nf(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EString: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBinary: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ERune: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWord: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EApp: {
        V v_h_24131 = heff_field(v_n1_2491, 0);
        V v_args_24132 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EApp = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24135 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_h_24131));
          V v_binders_24136 = heff_take_field(v_a_24135, 0);
          V v_uses_24137 = heff_get_n(v_a_24135, 1, 2);
          V v_b_24147 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24132; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24132); r_; });
          V v_binders_24148 = heff_take_field(v_b_24147, 0);
          V v_uses_24149 = heff_take_field(v_b_24147, 1);
          V v_t_24150 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EApp, v_binders_24136, v_binders_24148));
          V v_t_24151 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24137, v_uses_24149));
          return ({ V rv_0 = v_t_24150; V rv_1 = v_t_24151; V rr_ = heff_rec_reuse_nf(v_b_24147, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EProject: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENamed: {
        V v_e_24156 = heff_field(v_n1_2491, 1);
        heff_take_n(v_n1_2491, 2ULL, 2);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24156;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EPi: {
        V v_n11_24159 = heff_field(v_n1_2491, 0);
        V v_r_24160 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EPi = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24159)) {
          case TAG_PiNamed: {
            V v_x_24163 = heff_field(v_n11_24159, 0);
            V v_sp_24164 = heff_field(v_n11_24159, 1);
            V v_a_24165 = heff_field(v_n11_24159, 2);
            heff_take_n(v_n11_24159, 7ULL, 3);
            V v_a_24166 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24165));
            V v_binders_24167 = heff_take_field(v_a_24166, 0);
            V v_uses_24168 = heff_get_n(v_a_24166, 1, 2);
            V v_t_24169 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24163), heff_dup(v_sp_24164), NTAG(TAG_False)});
            V v_b_24170 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24EPi, TAG_Cons, 2, (V[]){v_t_24169, v_env_244}), v_r_24160));
            V v_binders_24171 = heff_take_field(v_b_24170, 0);
            V v_uses_24172 = heff_take_field(v_b_24170, 1);
            V v_t_24173 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24163, v_sp_24164, NTAG(TAG_False)});
            V v_t_24174 = (g_prelude_2e_2b_2b(v_binders_24167, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24173, v_binders_24171})));
            V v_t_24175 = (g_prelude_2e_2b_2b(v_uses_24168, v_uses_24172));
            return ({ V rv_0 = v_t_24174; V rv_1 = v_t_24175; V rr_ = heff_rec_reuse_nf(v_b_24170, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          case TAG_PiImplicit: {
            V v_x_24176 = heff_field(v_n11_24159, 0);
            V v_sp_24177 = heff_field(v_n11_24159, 1);
            V v_a_24179 = heff_field(v_n11_24159, 3);
            V v_d_24180 = heff_field(v_n11_24159, 4);
            heff_take_n(v_n11_24159, 27ULL, 5);
            V v_a_24181 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24179));
            V v_binders_24182 = heff_take_field(v_a_24181, 0);
            V v_uses_24183 = heff_get_n(v_a_24181, 1, 2);
            V v_b_24185;
            switch (heff_tag_of(v_d_24180)) {
            case TAG_Nothing: {
              v_b_24185 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24184 = heff_field(v_d_24180, 0);
              heff_take_n(v_d_24180, 1ULL, 1);
              v_b_24185 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24184));
              break;
            }
            default: heff_nomatch(v_d_24180);
            }
            V v_binders_24186 = heff_take_field(v_b_24185, 0);
            V v_uses_24187 = heff_get_n(v_b_24185, 1, 2);
            V v_t_24188 = (g_prelude_2e_2b_2b(v_binders_24182, v_binders_24186));
            V v_t_24189 = (g_prelude_2e_2b_2b(v_uses_24183, v_uses_24187));
            V v_t_24190 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24176), heff_dup(v_sp_24177), NTAG(TAG_False)});
            V v_b_24191 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24EPi, TAG_Cons, 2, (V[]){v_t_24190, v_env_244}), v_r_24160));
            V v_binders_24192 = heff_take_field(v_b_24191, 0);
            V v_uses_24193 = heff_take_field(v_b_24191, 1);
            V v_t_24194 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24176, v_sp_24177, NTAG(TAG_False)});
            V v_t_24195 = (g_prelude_2e_2b_2b(v_t_24188, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24194, v_binders_24192})));
            V v_t_24196 = (g_prelude_2e_2b_2b(v_t_24189, v_uses_24193));
            return ({ V rv_0 = v_t_24195; V rv_1 = v_t_24196; V rr_ = heff_rec_reuse_nf(v_b_24191, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          case TAG_PiInstance: {
            V v_x_24197 = heff_field(v_n11_24159, 0);
            V v_sp_24198 = heff_field(v_n11_24159, 1);
            V v_a_24200 = heff_field(v_n11_24159, 3);
            heff_take_n(v_n11_24159, 11ULL, 4);
            V v_a_24201 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24200));
            V v_binders_24202 = heff_take_field(v_a_24201, 0);
            V v_uses_24203 = heff_get_n(v_a_24201, 1, 2);
            V v_t_24204 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24197), heff_dup(v_sp_24198), NTAG(TAG_False)});
            V v_b_24205 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24EPi, TAG_Cons, 2, (V[]){v_t_24204, v_env_244}), v_r_24160));
            V v_binders_24206 = heff_take_field(v_b_24205, 0);
            V v_uses_24207 = heff_take_field(v_b_24205, 1);
            V v_t_24208 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24197, v_sp_24198, NTAG(TAG_False)});
            V v_t_24209 = (g_prelude_2e_2b_2b(v_binders_24202, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24208, v_binders_24206})));
            V v_t_24210 = (g_prelude_2e_2b_2b(v_uses_24203, v_uses_24207));
            return ({ V rv_0 = v_t_24209; V rv_1 = v_t_24210; V rr_ = heff_rec_reuse_nf(v_b_24205, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          case TAG_PiAnon: {
            V v_a_24211 = heff_field(v_n11_24159, 0);
            heff_take_n(v_n11_24159, 1ULL, 1);
            V v_a_24212 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24211));
            V v_binders_24213 = heff_take_field(v_a_24212, 0);
            V v_uses_24214 = heff_get_n(v_a_24212, 1, 2);
            V v_b_24215 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_r_24160));
            V v_binders_24216 = heff_take_field(v_b_24215, 0);
            V v_uses_24217 = heff_take_field(v_b_24215, 1);
            V v_t_24218 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EPi, v_binders_24213, v_binders_24216));
            V v_t_24219 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24214, v_uses_24217));
            return ({ V rv_0 = v_t_24218; V rv_1 = v_t_24219; V rr_ = heff_rec_reuse_nf(v_b_24215, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          default: return heff_nomatch(v_n11_24159);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELam: {
        V v_n11_24220 = heff_field(v_n1_2491, 0);
        V v_r_24221 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24ELam = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24220)) {
          case TAG_LamName: {
            heff_drop_cell(v_ru_24n_245_24At, 2);
            V v_bs_24226 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24220));
            V v_env_24227 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24226)));
            V v_b_24228 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24227, v_r_24221));
            V v_t_24229 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24ELam, v_bs_24226, heff_take_field(v_b_24228, 0)));
            return ({ V rv_0 = v_t_24229; V rr_ = heff_rec_reuse_nf(v_b_24228, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          }
          case TAG_LamImplicit: {
            heff_drop_cell(v_ru_24n_245_24At, 2);
            V v_bs_24232 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24220));
            V v_env_24233 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24232)));
            V v_b_24234 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24233, v_r_24221));
            V v_t_24235 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24ELam, v_bs_24232, heff_take_field(v_b_24234, 0)));
            return ({ V rv_0 = v_t_24235; V rr_ = heff_rec_reuse_nf(v_b_24234, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          }
          case TAG_LamAnn: {
            V v_x_24236 = heff_field(v_n11_24220, 0);
            V v_sp_24237 = heff_field(v_n11_24220, 1);
            V v_a_24238 = heff_field(v_n11_24220, 2);
            heff_take_n(v_n11_24220, 7ULL, 3);
            V v_a_24239 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24238));
            V v_binders_24240 = heff_take_field(v_a_24239, 0);
            V v_uses_24241 = heff_get_n(v_a_24239, 1, 2);
            V v_t_24242 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24236), heff_dup(v_sp_24237), NTAG(TAG_False)});
            V v_b_24243 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24ELam, TAG_Cons, 2, (V[]){v_t_24242, v_env_244}), v_r_24221));
            V v_binders_24244 = heff_take_field(v_b_24243, 0);
            V v_uses_24245 = heff_take_field(v_b_24243, 1);
            V v_t_24246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24236, v_sp_24237, NTAG(TAG_False)});
            V v_t_24247 = (g_prelude_2e_2b_2b(v_binders_24240, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24246, v_binders_24244})));
            V v_t_24248 = (g_prelude_2e_2b_2b(v_uses_24241, v_uses_24245));
            return ({ V rv_0 = v_t_24247; V rv_1 = v_t_24248; V rr_ = heff_rec_reuse_nf(v_b_24243, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          }
          default: return heff_nomatch(v_n11_24220);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAnn: {
        V v_e_24249 = heff_field(v_n1_2491, 0);
        V v_t_24250 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EAnn = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24253 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24249));
          V v_binders_24254 = heff_take_field(v_a_24253, 0);
          V v_uses_24255 = heff_get_n(v_a_24253, 1, 2);
          V v_b_24256 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_t_24250));
          V v_binders_24257 = heff_take_field(v_b_24256, 0);
          V v_uses_24258 = heff_take_field(v_b_24256, 1);
          V v_t_24259 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EAnn, v_binders_24254, v_binders_24257));
          V v_t_24260 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24255, v_uses_24258));
          return ({ V rv_0 = v_t_24259; V rv_1 = v_t_24260; V rr_ = heff_rec_reuse_nf(v_b_24256, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESpec: {
        V v_acc_24261 = heff_field(v_n1_2491, 0);
        V v_v_24264 = heff_field(v_n1_2491, 3);
        heff_take_n(v_n1_2491, 9ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24267 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_acc_24261));
          V v_binders_24268 = heff_take_field(v_a_24267, 0);
          V v_uses_24269 = heff_get_n(v_a_24267, 1, 2);
          V v_b_24270 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_v_24264));
          V v_binders_24271 = heff_take_field(v_b_24270, 0);
          V v_uses_24272 = heff_take_field(v_b_24270, 1);
          V v_t_24273 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24268, v_binders_24271));
          V v_t_24274 = (g_prelude_2e_2b_2b(v_uses_24269, v_uses_24272));
          return ({ V rv_0 = v_t_24273; V rv_1 = v_t_24274; V rr_ = heff_rec_reuse_nf(v_b_24270, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESig: {
        V v_fs_24275 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_244, v_fs_24275));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESum: {
        V v_vs_24278 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_vs_24278; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24278); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EStruct: {
        V v_fs_24305 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_fs_24305; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24305); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EUpdate: {
        V v_a_24323 = heff_field(v_n1_2491, 0);
        V v_fs_24324 = heff_field(v_n1_2491, 1);
        heff_take_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V v_t_24327 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24323));
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4, 2, 1, (V[]){v_env_244}); V a_1 = v_t_24327; V a_2 = v_fs_24324; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24324); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EMatch: {
        V v_s_24341 = heff_field(v_n1_2491, 0);
        V v_alts_24342 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EMatch = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24345 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_s_24341));
          V v_binders_24346 = heff_take_field(v_a_24345, 0);
          V v_uses_24347 = heff_get_n(v_a_24345, 1, 2);
          V v_b_24365 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_alts_24342; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24342); r_; });
          V v_binders_24366 = heff_take_field(v_b_24365, 0);
          V v_uses_24367 = heff_take_field(v_b_24365, 1);
          V v_t_24368 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EMatch, v_binders_24346, v_binders_24366));
          V v_t_24369 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24347, v_uses_24367));
          return ({ V rv_0 = v_t_24368; V rv_1 = v_t_24369; V rr_ = heff_rec_reuse_nf(v_b_24365, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELetIn: {
        V v_rhs_24370 = heff_field(v_n1_2491, 0);
        V v_a_24371 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24ELetIn = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24374 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_rhs_24370));
          V v_binders_24375 = heff_take_field(v_a_24374, 0);
          V v_uses_24376 = heff_get_n(v_a_24374, 1, 2);
          V v_b_24385;
          switch (heff_tag_of(v_a_24371)) {
          case TAG_At: {
            V v_x31_24377 = heff_field(v_a_24371, 0);
            heff_take_n(v_a_24371, 1ULL, 2);
            switch (heff_tag_of(v_x31_24377)) {
            case TAG_MkAlt: {
              V v_p_24379 = heff_field(v_x31_24377, 0);
              V v_r_24380 = heff_field(v_x31_24377, 1);
              heff_take_n(v_x31_24377, 3ULL, 2);
              V v_bs_24381 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n1_2491_24ELetIn, v_p_24379));
              V v_env_24382 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24381)));
              V v_b_24383 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24382, v_r_24380));
              V v_t_24384 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_bs_24381, heff_take_field(v_b_24383, 0)));
              v_b_24385 = ({ V rv_0 = v_t_24384; V rr_ = heff_rec_reuse_nf(v_b_24383, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              break;
            }
            default: heff_nomatch(v_x31_24377);
            }
            break;
          }
          default: heff_nomatch(v_a_24371);
          }
          V v_binders_24386 = heff_take_field(v_b_24385, 0);
          V v_uses_24387 = heff_take_field(v_b_24385, 1);
          V v_t_24388 = (g_prelude_2e_2b_2b(v_binders_24375, v_binders_24386));
          V v_t_24389 = (g_prelude_2e_2b_2b(v_uses_24376, v_uses_24387));
          return ({ V rv_0 = v_t_24388; V rv_1 = v_t_24389; V rr_ = heff_rec_reuse_nf(v_b_24385, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EDo: {
        V v_stmts_24390 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_stmts_24390));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELocal: {
        V v_body_24393 = heff_field(v_n1_2491, 0);
        V v_defs_24394 = heff_field(v_n1_2491, 1);
        heff_take_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361);
          V t_1 = v_env_244;
          V t_2 = v_defs_24394;
          V t_3 = v_body_24393;
          V t_4 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3);
          V t_5 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4);
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInvalid: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAssign: {
        V v_x_24400 = heff_field(v_n1_2491, 0);
        V v_xsp_24401 = heff_field(v_n1_2491, 1);
        V v_e_24402 = heff_field(v_n1_2491, 2);
        heff_take_n(v_n1_2491, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          HeffT2 v_t_24405 = ({ V a_0 = v_x_24400; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24400); r_; });
          {
            V v_field_24407 = v_t_24405.f[1];
            int64_t v_tag_24406 = ((int64_t)v_t_24405.f[0]);
            V v_a_24410;
            if ((v_tag_24406 == ((int64_t)0ULL))) {
              V v_b_24408 = v_field_24407;
              V v_t_24409 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24408, v_xsp_24401}), NTAG(TAG_Nil)});
              v_a_24410 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24409});
            } else {
              heff_drop(v_xsp_24401);
              heff_drop_cell(v_ru_24n_245_24At, 2);
              heff_drop(v_field_24407);
              v_a_24410 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            }
            V v_binders_24411 = heff_take_field(v_a_24410, 0);
            V v_uses_24412 = heff_get_n(v_a_24410, 1, 2);
            V v_b_24413 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24402));
            V v_binders_24414 = heff_take_field(v_b_24413, 0);
            V v_uses_24415 = heff_take_field(v_b_24413, 1);
            V v_t_24416 = (g_prelude_2e_2b_2b(v_binders_24411, v_binders_24414));
            V v_t_24417 = (g_prelude_2e_2b_2b(v_uses_24412, v_uses_24415));
            return ({ V rv_0 = v_t_24416; V rv_1 = v_t_24417; V rr_ = heff_rec_reuse_nf(v_b_24413, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWhile: {
        V v_c_24418 = heff_field(v_n1_2491, 0);
        V v_body_24419 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EWhile = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24422 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24418));
          V v_binders_24423 = heff_take_field(v_a_24422, 0);
          V v_uses_24424 = heff_get_n(v_a_24422, 1, 2);
          V v_b_24425 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_body_24419));
          V v_binders_24426 = heff_take_field(v_b_24425, 0);
          V v_uses_24427 = heff_take_field(v_b_24425, 1);
          V v_t_24428 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EWhile, v_binders_24423, v_binders_24426));
          V v_t_24429 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24424, v_uses_24427));
          return ({ V rv_0 = v_t_24428; V rv_1 = v_t_24429; V rr_ = heff_rec_reuse_nf(v_b_24425, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFor: {
        V v_p_24430 = heff_field(v_n1_2491, 0);
        V v_c_24431 = heff_field(v_n1_2491, 1);
        V v_body_24432 = heff_field(v_n1_2491, 2);
        heff_take_n(v_n1_2491, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24435 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24431));
          V v_binders_24436 = heff_take_field(v_a_24435, 0);
          V v_uses_24437 = heff_get_n(v_a_24435, 1, 2);
          V v_bs_24438 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n_245_24At, heff_dup(v_p_24430)));
          V v_env_24439 = (g_list_2efoldl_24f1677743806x2032371213(v_env_244, v_p_24430));
          V v_b_24440 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24439, v_body_24432));
          V v_binders_24441 = heff_take_field(v_b_24440, 0);
          V v_uses_24442 = heff_take_field(v_b_24440, 1);
          V v_t_24443 = (g_prelude_2e_2b_2b(v_bs_24438, v_binders_24441));
          V v_t_24444 = (g_prelude_2e_2b_2b(v_binders_24436, v_t_24443));
          V v_t_24445 = (g_prelude_2e_2b_2b(v_uses_24437, v_uses_24442));
          return ({ V rv_0 = v_t_24444; V rv_1 = v_t_24445; V rr_ = heff_rec_reuse_nf(v_b_24440, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EIfThen: {
        V v_c_24446 = heff_field(v_n1_2491, 0);
        V v_a_24447 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EIfThen = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24450 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24446));
          V v_binders_24451 = heff_take_field(v_a_24450, 0);
          V v_uses_24452 = heff_get_n(v_a_24450, 1, 2);
          V v_b_24453 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24447));
          V v_binders_24454 = heff_take_field(v_b_24453, 0);
          V v_uses_24455 = heff_take_field(v_b_24453, 1);
          V v_t_24456 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EIfThen, v_binders_24451, v_binders_24454));
          V v_t_24457 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24452, v_uses_24455));
          return ({ V rv_0 = v_t_24456; V rv_1 = v_t_24457; V rr_ = heff_rec_reuse_nf(v_b_24453, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBreak: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EContinue: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EReturn: {
        V v_e_24462 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24462;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENest: {
        V v_e_24465 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24465;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELazy: {
        V v_e_24468 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24468;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETuple: {
        V v_es_24471 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_es_24471; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_24471); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETry: {
        V v_n11_24483 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24483)) {
          case TAG_MkTry: {
            V v_ty_24486 = heff_field(v_n11_24483, 0);
            V v_body_24487 = heff_field(v_n11_24483, 1);
            V v_c_24488 = heff_field(v_n11_24483, 2);
            heff_take_n(v_n11_24483, 7ULL, 3);
            V v_a_24490;
            switch (heff_tag_of(v_ty_24486)) {
            case TAG_Nothing: {
              v_a_24490 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24489 = heff_field(v_ty_24486, 0);
              heff_take_n(v_ty_24486, 1ULL, 1);
              v_a_24490 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24489));
              break;
            }
            default: heff_nomatch(v_ty_24486);
            }
            V v_binders_24491 = heff_take_field(v_a_24490, 0);
            V v_uses_24492 = heff_get_n(v_a_24490, 1, 2);
            V v_b_24493 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_244), v_body_24487));
            V v_binders_24494 = heff_take_field(v_b_24493, 0);
            V v_uses_24495 = heff_take_field(v_b_24493, 1);
            V v_t_24496 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24491, v_binders_24494));
            V v_t_24497 = (g_prelude_2e_2b_2b(v_uses_24492, v_uses_24495));
            HeffT2 v_t_24498 = (g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(v_env_244, v_c_24488));
            {
              V v_field_24499 = v_t_24498.f[0];
              V v_field_24500 = v_t_24498.f[1];
              V v_t_24501 = (g_prelude_2e_2b_2b(v_t_24496, v_field_24499));
              V v_t_24502 = (g_prelude_2e_2b_2b(v_t_24497, v_field_24500));
              return ({ V rv_0 = v_t_24501; V rv_1 = v_t_24502; V rr_ = heff_rec_reuse_nf(v_b_24493, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            }
          }
          default: return heff_nomatch(v_n11_24483);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWith: {
        V v_e_24503 = heff_field(v_n1_2491, 0);
        V v_x_24504 = heff_field(v_n1_2491, 1);
        V v_xsp_24505 = heff_field(v_n1_2491, 2);
        V v_body_24506 = heff_field(v_n1_2491, 3);
        heff_take_n(v_n1_2491, 15ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24509 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24503));
          V v_binders_24510 = heff_take_field(v_a_24509, 0);
          V v_uses_24511 = heff_get_n(v_a_24509, 1, 2);
          V v_t_24512 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24504), heff_dup(v_xsp_24505), NTAG(TAG_False)});
          V v_b_24513 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24512, v_env_244}), v_body_24506));
          V v_binders_24514 = heff_take_field(v_b_24513, 0);
          V v_uses_24515 = heff_take_field(v_b_24513, 1);
          V v_t_24516 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24504, v_xsp_24505, NTAG(TAG_False)});
          V v_t_24517 = (g_prelude_2e_2b_2b(v_binders_24510, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24516, v_binders_24514})));
          V v_t_24518 = (g_prelude_2e_2b_2b(v_uses_24511, v_uses_24515));
          return ({ V rv_0 = v_t_24517; V rv_1 = v_t_24518; V rr_ = heff_rec_reuse_nf(v_b_24513, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWithBound: {
        V v_bs_24519 = heff_field(v_n1_2491, 0);
        V v_p_24520 = heff_field(v_n1_2491, 1);
        V v_body_24521 = heff_field(v_n1_2491, 2);
        heff_take_n(v_n1_2491, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24538 = (g_list_2efoldl(heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam7, 2, 1, (V[]){heff_dup(v_env_244)}), heff_dup(g_heff_2eelab_2elocals_2enone_get()), v_bs_24519));
          V v_binders_24539 = heff_take_field(v_a_24538, 0);
          V v_uses_24540 = heff_get_n(v_a_24538, 1, 2);
          V v_t_24541 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_24519)));
          V v_bs_24542 = ({ V b_0 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str5); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24541; V r_ = (g_list_2efoldl_24s228254919x1092684261(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          V v_a_24547;
          switch (heff_tag_of(v_p_24520)) {
          case TAG_Nothing: {
            v_a_24547 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            break;
          }
          case TAG_Just: {
            V v_c_24543 = heff_field(v_p_24520, 0);
            heff_take_n(v_p_24520, 1ULL, 1);
            V v_t_24544 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_24519)));
            V v_bs_24545 = ({ V b_0 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str6); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24544; V r_ = (g_list_2efoldl_24s228254919x1092684261(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            V v_env_24546 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_244), v_bs_24545));
            v_a_24547 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24546, v_c_24543));
            break;
          }
          default: heff_nomatch(v_p_24520);
          }
          V v_binders_24548 = heff_take_field(v_a_24547, 0);
          V v_uses_24549 = heff_get_n(v_a_24547, 1, 2);
          V v_t_24550 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_24519));
          V v_bs_24551 = ({ V b_0 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str7); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24550; V r_ = (g_list_2efoldl_24s228254919x1092684261(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          V v_env_24552 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_bs_24551));
          V v_b_24553 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24552, v_body_24521));
          V v_binders_24554 = heff_take_field(v_b_24553, 0);
          V v_uses_24555 = heff_take_field(v_b_24553, 1);
          V v_t_24556 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24548, v_binders_24554));
          V v_t_24557 = (g_prelude_2e_2b_2b(v_uses_24549, v_uses_24555));
          V v_t_24558 = (g_prelude_2e_2b_2b(v_bs_24542, v_t_24556));
          V v_t_24559 = (g_prelude_2e_2b_2b(v_binders_24539, v_t_24558));
          V v_t_24560 = (g_prelude_2e_2b_2b(v_uses_24540, v_t_24557));
          return ({ V rv_0 = v_t_24559; V rv_1 = v_t_24560; V rr_ = heff_rec_reuse_nf(v_b_24553, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      default: return heff_nomatch(v_n1_2491);
      }
    }
    default: return heff_nomatch(v_n_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args) {
  V v_acc_24138 = args[0];
  V v_x_24139 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24140 = heff_take_field(v_acc_24138, 0);
  V v_uses_24141 = heff_get_n(v_acc_24138, 1, 2);
  heff_clo_take(self, 1);
  V v_b_24142 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24139));
  V v_binders_24143 = heff_take_field(v_b_24142, 0);
  V v_uses_24144 = heff_take_field(v_b_24142, 1);
  V v_t_24145 = (g_prelude_2e_2b_2b(v_binders_24140, v_binders_24143));
  V v_t_24146 = (g_prelude_2e_2b_2b(v_uses_24141, v_uses_24144));
  return ({ V rv_0 = v_t_24145; V rv_1 = v_t_24146; V rr_ = heff_rec_reuse_nf(v_b_24142, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args) {
  V v_acc_24290 = args[0];
  V v_x_24291 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24292 = heff_take_field(v_acc_24290, 0);
  V v_uses_24293 = heff_get_n(v_acc_24290, 1, 2);
  heff_clo_take(self, 1);
  V v_b_24294 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24291));
  V v_binders_24295 = heff_take_field(v_b_24294, 0);
  V v_uses_24296 = heff_take_field(v_b_24294, 1);
  V v_t_24297 = (g_prelude_2e_2b_2b(v_binders_24292, v_binders_24295));
  V v_t_24298 = (g_prelude_2e_2b_2b(v_uses_24293, v_uses_24296));
  return ({ V rv_0 = v_t_24297; V rv_1 = v_t_24298; V rr_ = heff_rec_reuse_nf(v_b_24294, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args) {
  V v_acc_24281 = args[0];
  V v_v_24282 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24283 = heff_take_field(v_acc_24281, 0);
  V v_uses_24284 = heff_get_n(v_acc_24281, 1, 2);
  V v_b_24300;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_24282)) {
  case TAG_At: {
    V v_it1_24285 = heff_field(v_v_24282, 0);
    heff_take_n(v_v_24282, 1ULL, 2);
    switch (heff_tag_of(v_it1_24285)) {
    case TAG_TagVariant: {
      V v_args_24289 = heff_field(v_it1_24285, 2);
      heff_take_n(v_it1_24285, 4ULL, 3);
      v_b_24300 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24289; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24289); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24299 = heff_field(v_it1_24285, 0);
      heff_take_n(v_it1_24285, 1ULL, 1);
      v_b_24300 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24299));
      break;
    }
    default: heff_nomatch(v_it1_24285);
    }
    break;
  }
  default: heff_nomatch(v_v_24282);
  }
  V v_binders_24301 = heff_take_field(v_b_24300, 0);
  V v_uses_24302 = heff_take_field(v_b_24300, 1);
  V v_t_24303 = (g_prelude_2e_2b_2b(v_binders_24283, v_binders_24301));
  V v_t_24304 = (g_prelude_2e_2b_2b(v_uses_24284, v_uses_24302));
  return ({ V rv_0 = v_t_24303; V rv_1 = v_t_24304; V rr_ = heff_rec_reuse_nf(v_b_24300, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args) {
  V v_acc_24308 = args[0];
  V v_f_24309 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24310 = heff_take_field(v_acc_24308, 0);
  V v_uses_24311 = heff_get_n(v_acc_24308, 1, 2);
  V v_b_24318;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24309)) {
  case TAG_At: {
    V v_x31_24312 = heff_field(v_f_24309, 0);
    heff_take_n(v_f_24309, 1ULL, 2);
    switch (heff_tag_of(v_x31_24312)) {
    case TAG_SetField: {
      V v_e_24316 = heff_field(v_x31_24312, 2);
      heff_take_n(v_x31_24312, 4ULL, 3);
      v_b_24318 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24316));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24317 = heff_field(v_x31_24312, 0);
      heff_take_n(v_x31_24312, 1ULL, 1);
      v_b_24318 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24317));
      break;
    }
    default: heff_nomatch(v_x31_24312);
    }
    break;
  }
  default: heff_nomatch(v_f_24309);
  }
  V v_binders_24319 = heff_take_field(v_b_24318, 0);
  V v_uses_24320 = heff_take_field(v_b_24318, 1);
  V v_t_24321 = (g_prelude_2e_2b_2b(v_binders_24310, v_binders_24319));
  V v_t_24322 = (g_prelude_2e_2b_2b(v_uses_24311, v_uses_24320));
  return ({ V rv_0 = v_t_24321; V rv_1 = v_t_24322; V rr_ = heff_rec_reuse_nf(v_b_24318, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args) {
  V v_acc_24328 = args[0];
  V v_f_24329 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24330 = heff_take_field(v_acc_24328, 0);
  V v_uses_24331 = heff_get_n(v_acc_24328, 1, 2);
  switch (heff_tag_of(v_f_24329)) {
  case TAG_At: {
    V v_it1_24332 = heff_field(v_f_24329, 0);
    V v_ru_24f_24329_24At = heff_take_reuse_n(v_f_24329, 1ULL, 2);
    switch (heff_tag_of(v_it1_24332)) {
    case TAG_SetPath: {
      V v_e_24335 = heff_field(v_it1_24332, 1);
      V v_ru_24it1_24332_24SetPath = heff_take_reuse_n(v_it1_24332, 2ULL, 2);
      heff_clo_take(self, 1);
      V v_b_24336 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24335));
      V v_binders_24337 = heff_take_field(v_b_24336, 0);
      V v_uses_24338 = heff_take_field(v_b_24336, 1);
      V v_t_24339 = (g_prelude_2e_2b_2b_24tok2(v_ru_24f_24329_24At, v_binders_24330, v_binders_24337));
      V v_t_24340 = (g_prelude_2e_2b_2b_24tok2(v_ru_24it1_24332_24SetPath, v_uses_24331, v_uses_24338));
      return ({ V rv_0 = v_t_24339; V rv_1 = v_t_24340; V rr_ = heff_rec_reuse_nf(v_b_24336, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    default: return heff_nomatch(v_it1_24332);
    }
  }
  default: return heff_nomatch(v_f_24329);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args) {
  V v_acc_24348 = args[0];
  V v_a_24349 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24350 = heff_take_field(v_acc_24348, 0);
  V v_uses_24351 = heff_get_n(v_acc_24348, 1, 2);
  V v_b_24360;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24349)) {
  case TAG_At: {
    V v_x31_24352 = heff_field(v_a_24349, 0);
    V v_ru_24a_24349_24At = heff_take_reuse_n(v_a_24349, 1ULL, 2);
    switch (heff_tag_of(v_x31_24352)) {
    case TAG_MkAlt: {
      V v_p_24354 = heff_field(v_x31_24352, 0);
      V v_r_24355 = heff_field(v_x31_24352, 1);
      V v_ru_24x31_24352_24MkAlt = heff_take_reuse_n(v_x31_24352, 3ULL, 2);
      V v_bs_24356 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24a_24349_24At, v_p_24354));
      V v_env_24357 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24356)));
      V v_b_24358 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24357, v_r_24355));
      V v_t_24359 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_24352_24MkAlt, v_bs_24356, heff_take_field(v_b_24358, 0)));
      v_b_24360 = ({ V rv_0 = v_t_24359; V rr_ = heff_rec_reuse_nf(v_b_24358, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_24352);
    }
    break;
  }
  default: heff_nomatch(v_a_24349);
  }
  V v_binders_24361 = heff_take_field(v_b_24360, 0);
  V v_uses_24362 = heff_take_field(v_b_24360, 1);
  V v_t_24363 = (g_prelude_2e_2b_2b(v_binders_24350, v_binders_24361));
  V v_t_24364 = (g_prelude_2e_2b_2b(v_uses_24351, v_uses_24362));
  return ({ V rv_0 = v_t_24363; V rv_1 = v_t_24364; V rr_ = heff_rec_reuse_nf(v_b_24360, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args) {
  V v_acc_24474 = args[0];
  V v_x_24475 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24476 = heff_take_field(v_acc_24474, 0);
  V v_uses_24477 = heff_get_n(v_acc_24474, 1, 2);
  heff_clo_take(self, 1);
  V v_b_24478 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24475));
  V v_binders_24479 = heff_take_field(v_b_24478, 0);
  V v_uses_24480 = heff_take_field(v_b_24478, 1);
  V v_t_24481 = (g_prelude_2e_2b_2b(v_binders_24476, v_binders_24479));
  V v_t_24482 = (g_prelude_2e_2b_2b(v_uses_24477, v_uses_24480));
  return ({ V rv_0 = v_t_24481; V rv_1 = v_t_24482; V rr_ = heff_rec_reuse_nf(v_b_24478, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam7(V self, V *args) {
  V v_acc_24524 = args[0];
  V v_b_24525 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24526 = heff_take_field(v_acc_24524, 0);
  V v_uses_24527 = heff_get_n(v_acc_24524, 1, 2);
  switch (heff_tag_of(v_b_24525)) {
  case TAG_At: {
    V v_it1_24528 = heff_field(v_b_24525, 0);
    V v_ru_24b_24525_24At = heff_take_reuse_n(v_b_24525, 1ULL, 2);
    switch (heff_tag_of(v_it1_24528)) {
    case TAG_MkBinding: {
      V v_m_24532 = heff_field(v_it1_24528, 2);
      heff_take_n(v_it1_24528, 4ULL, 3);
      heff_clo_take(self, 1);
      V v_b_24533 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_m_24532));
      V v_binders_24534 = heff_take_field(v_b_24533, 0);
      V v_uses_24535 = heff_take_field(v_b_24533, 1);
      V v_t_24536 = (g_prelude_2e_2b_2b_24tok2(v_ru_24b_24525_24At, v_binders_24526, v_binders_24534));
      V v_t_24537 = (g_prelude_2e_2b_2b(v_uses_24527, v_uses_24535));
      return ({ V rv_0 = v_t_24536; V rv_1 = v_t_24537; V rr_ = heff_rec_reuse_nf(v_b_24533, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    default: return heff_nomatch(v_it1_24528);
    }
  }
  default: return heff_nomatch(v_b_24525);
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1, 0, "");
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry, 3, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361), v_env_240, v_x3_241, v_body_242, ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0), ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1)));
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkCatchArm: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ss_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkCatchArm = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_LamName: {
      V v_bs_246 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_247 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_248 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_247));
      V v_b_249 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_248, v_ss_243));
      V v_binders_2410 = heff_take_field(v_b_249, 0);
      V v_uses_2411 = heff_get_n(v_b_249, 1, 2);
      V v_t_2412 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_246, v_binders_2410));
      V v_f_2413 = v_uses_2411;
      return ((HeffT2){{v_t_2412, v_f_2413}});
    }
    case TAG_LamImplicit: {
      V v_bs_2416 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_2417 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_2418 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2417));
      V v_b_2419 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2418, v_ss_243));
      V v_binders_2420 = heff_take_field(v_b_2419, 0);
      V v_uses_2421 = heff_get_n(v_b_2419, 1, 2);
      V v_t_2422 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_2416, v_binders_2420));
      V v_f_2423 = v_uses_2421;
      return ((HeffT2){{v_t_2422, v_f_2423}});
    }
    case TAG_LamAnn: {
      V v_x_2424 = heff_field(v_x31_242, 0);
      V v_sp_2425 = heff_field(v_x31_242, 1);
      V v_t_2426 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_a_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2426));
      V v_binders_2428 = heff_take_field(v_a_2427, 0);
      V v_uses_2429 = heff_get_n(v_a_2427, 1, 2);
      V v_t_2430 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2424), heff_dup(v_sp_2425), NTAG(TAG_False)});
      V v_b_2431 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_2430, v_env_240}), v_ss_243));
      V v_binders_2432 = heff_take_field(v_b_2431, 0);
      V v_uses_2433 = heff_get_n(v_b_2431, 1, 2);
      V v_t_2434 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2424, v_sp_2425, NTAG(TAG_False)});
      V v_t_2435 = (g_prelude_2e_2b_2b(v_binders_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_binders_2432})));
      V v_t_2436 = (g_prelude_2e_2b_2b(v_uses_2429, v_uses_2433));
      return ((HeffT2){{v_t_2435, v_t_2436}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2, 0, "");
Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry, 2, 0};

V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V v_env_240, V v_n_241) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2), v_env_240, v_n_241));
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry, 4, 0};

V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V v_lit_240, V v_lit_241, V v_env_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    V v_b_244 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_242), v_lit_240));
    V v_binders_245 = heff_take_field(v_b_244, 0);
    V v_uses_246 = heff_get_n(v_b_244, 1, 2);
    V v_b_247 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_242, v_lit_241));
    V v_binders_248 = heff_take_field(v_b_247, 0);
    V v_uses_249 = heff_take_field(v_b_247, 1);
    V v_t_2410 = (g_prelude_2e_2b_2b(v_binders_245, v_binders_248));
    V v_t_2411 = (g_prelude_2e_2b_2b(v_uses_246, v_uses_249));
    V v_z_2412 = ({ V rv_0 = v_t_2410; V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_b_247, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    return v_z_2412;
  }
  case TAG_Cons: {
    V v_x21_2413 = heff_field(v_x2_243, 0);
    V v_tl_2414 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x21_2413)) {
    case TAG_At: {
      V v_x211_2415 = heff_field(v_x21_2413, 0);
      V v_ru_24x21_2413_24At = heff_take_reuse_n(v_x21_2413, 1ULL, 2);
      switch (heff_tag_of(v_x211_2415)) {
      case TAG_ExplicitParam: {
        V v_x_2417 = heff_field(v_x211_2415, 0);
        V v_sp_2418 = heff_field(v_x211_2415, 1);
        V v_t_2419 = heff_field(v_x211_2415, 2);
        heff_take_n(v_x211_2415, 7ULL, 3);
        V v_a_2420 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_242), v_t_2419));
        V v_binders_2421 = heff_take_field(v_a_2420, 0);
        V v_uses_2422 = heff_get_n(v_a_2420, 1, 2);
        V v_t_2423 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2417), heff_dup(v_sp_2418), NTAG(TAG_False)});
        V v_b_2424 = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_lit_240, v_lit_241, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2423, v_env_242}), v_tl_2414));
        V v_binders_2425 = heff_take_field(v_b_2424, 0);
        V v_uses_2426 = heff_take_field(v_b_2424, 1);
        V v_t_2427 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2417, v_sp_2418, NTAG(TAG_False)});
        V v_t_2428 = (g_prelude_2e_2b_2b(v_binders_2421, heff_tag_at_n(v_ru_24x21_2413_24At, TAG_Cons, 2, (V[]){v_t_2427, v_binders_2425})));
        V v_t_2429 = (g_prelude_2e_2b_2b(v_uses_2422, v_uses_2426));
        return ({ V rv_0 = v_t_2428; V rv_1 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_b_2424, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_ImplicitParam: {
        V v_x_2430 = heff_field(v_x211_2415, 0);
        V v_sp_2431 = heff_field(v_x211_2415, 1);
        V v_t_2432 = heff_field(v_x211_2415, 2);
        heff_take_n(v_x211_2415, 7ULL, 3);
        V v_a_2433 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_242), v_t_2432));
        V v_binders_2434 = heff_take_field(v_a_2433, 0);
        V v_uses_2435 = heff_get_n(v_a_2433, 1, 2);
        V v_t_2436 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2430), heff_dup(v_sp_2431), NTAG(TAG_False)});
        V v_b_2437 = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_lit_240, v_lit_241, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2436, v_env_242}), v_tl_2414));
        V v_binders_2438 = heff_take_field(v_b_2437, 0);
        V v_uses_2439 = heff_take_field(v_b_2437, 1);
        V v_t_2440 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2430, v_sp_2431, NTAG(TAG_False)});
        V v_t_2441 = (g_prelude_2e_2b_2b(v_binders_2434, heff_tag_at_n(v_ru_24x21_2413_24At, TAG_Cons, 2, (V[]){v_t_2440, v_binders_2438})));
        V v_t_2442 = (g_prelude_2e_2b_2b(v_uses_2435, v_uses_2439));
        return ({ V rv_0 = v_t_2441; V rv_1 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_b_2437, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      default: return heff_nomatch(v_x211_2415);
      }
    }
    default: return heff_nomatch(v_x21_2413);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(V v_lit_240, V v_env_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    V v_b_243 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_241, v_lit_240));
    V v_binders_244 = heff_take_field(v_b_243, 0);
    V v_uses_245 = heff_get_n(v_b_243, 1, 2);
    V v_f_246 = v_binders_244;
    V v_f_247 = v_uses_245;
    return ((HeffT2){{v_f_246, v_f_247}});
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_242, 0);
    V v_tl_249 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_x211_2410 = heff_field(v_x21_248, 0);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 1ULL, 2);
      switch (heff_tag_of(v_x211_2410)) {
      case TAG_ExplicitParam: {
        V v_x_2412 = heff_field(v_x211_2410, 0);
        V v_sp_2413 = heff_field(v_x211_2410, 1);
        V v_t_2414 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2415 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_241), v_t_2414));
        V v_binders_2416 = heff_take_field(v_a_2415, 0);
        V v_uses_2417 = heff_get_n(v_a_2415, 1, 2);
        V v_t_2418 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2412), heff_dup(v_sp_2413), NTAG(TAG_False)});
        HeffT2 v_t_2419 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2418, v_env_241}), v_tl_249));
        {
          V v_field_2420 = v_t_2419.f[0];
          V v_field_2421 = v_t_2419.f[1];
          V v_t_2422 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2412, v_sp_2413, NTAG(TAG_False)});
          V v_t_2423 = (g_prelude_2e_2b_2b(v_binders_2416, heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2422, v_field_2420})));
          V v_t_2424 = (g_prelude_2e_2b_2b(v_uses_2417, v_field_2421));
          return ((HeffT2){{v_t_2423, v_t_2424}});
        }
      }
      case TAG_ImplicitParam: {
        V v_x_2425 = heff_field(v_x211_2410, 0);
        V v_sp_2426 = heff_field(v_x211_2410, 1);
        V v_t_2427 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2428 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_241), v_t_2427));
        V v_binders_2429 = heff_take_field(v_a_2428, 0);
        V v_uses_2430 = heff_get_n(v_a_2428, 1, 2);
        V v_t_2431 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2425), heff_dup(v_sp_2426), NTAG(TAG_False)});
        HeffT2 v_t_2432 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2431, v_env_241}), v_tl_249));
        {
          V v_field_2433 = v_t_2432.f[0];
          V v_field_2434 = v_t_2432.f[1];
          V v_t_2435 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2425, v_sp_2426, NTAG(TAG_False)});
          V v_t_2436 = (g_prelude_2e_2b_2b(v_binders_2429, heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2435, v_field_2433})));
          V v_t_2437 = (g_prelude_2e_2b_2b(v_uses_2430, v_field_2434));
          return ((HeffT2){{v_t_2436, v_t_2437}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}
Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry, 3, 0};

V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V v_lit_240, V v_env_241, V v_x2_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, v_env_241, v_x2_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_rec_n(2, shape_binders__uses, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(a[0], a[1], a[2]);
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V v_found_240) {
top: ;
  V v_binders_241 = heff_take_field(v_found_240, 0);
  V v_uses_242 = heff_get_n(v_found_240, 1, 2);
  V v_t_243 = (g_list_2ekeepIf_24s1266148589x1647110933(v_binders_241));
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_uses_242)}), v_t_243));
  V v_t_247 = (g_list_2emap_24f565269645x1954016017(v_uses_242));
  return ((HeffT2){{v_t_246, v_t_247}});
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args) {
  V v_b_244 = args[0];
  V v_uses_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_list_2emap_24f1213328022x1811586494(heff_dup(v_b_244), v_uses_242));
  return heff_rec_n(3, shape_name__binder__uses, (V[]){heff_dup(heff_rfield(v_b_244, 0)), heff_get_n(v_b_244, 1, 3), v_t_245});
}
Clo g_heff_2eelab_2elocals_2elocalsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsOf_entry, 1, 0};

V g_heff_2eelab_2elocals_2elocalsOf(V v_found_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_found_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_locals__fields, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsOf(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V v_tok_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_p2_243 = heff_field(v_p_241, 1);
    heff_take_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0), 2)) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_p2_243);
        heff_drop(v_x_244);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2420));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_242, 0);
      V v_sp_2424 = heff_field(v_p1_242, 1);
      V v_q_2425 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
      V v_cell_2427 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2425, v_cell_2427));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24tok2(a[0], a[1]);
}