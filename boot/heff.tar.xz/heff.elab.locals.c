// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2eelab_2elocals_2earguments(V, V, V);
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_clo;
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V, V);
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo;
V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(V, V);
V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_clo;
V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(V, V);
V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_clo;
V g_heff_2eelab_2elocals_2efindBinder(V, V);
V g_heff_2eelab_2elocals_2efindBinder_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2efindBinder_clo;
V g_heff_2eelab_2elocals_2elamBinders(V);
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elamBinders_clo;
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V, V);
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(V, V);
V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_clo;
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24dps(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo;
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V, V);
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo;
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_list_2efilter_24s2018073091x1385246979(V);
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1133029339x682401273(V);
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_clo;
V g_list_2emap_24f342794667x1308411312(V, V);
V g_list_2emap_24f342794667x1308411312_entry(V self, V *a);
extern Clo g_list_2emap_24f342794667x1308411312_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;

static V g_heff_2eelab_2elocals_2enone_val;
static HEFF_ONCE g_heff_2eelab_2elocals_2enone_st;
static V g_heff_2eelab_2elocals_2enone_init(void) {
  return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2elocals_2enone_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2elocals_2enone_st)) return g_heff_2eelab_2elocals_2enone_val;
  return heff_global(&g_heff_2eelab_2elocals_2enone_val, &g_heff_2eelab_2elocals_2enone_st, g_heff_2eelab_2elocals_2enone_init);
}
Clo g_heff_2eelab_2elocals_2efindBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2efindBinder_entry, 2, 0};

V g_heff_2eelab_2elocals_2efindBinder(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_b_242, 0)), heff_dup(v_x_240))) {
      heff_drop(v_x_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_b_242)});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2elocals_2efindBinder_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2efindBinder(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_sp_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2eelab_2elocals_2epatternBinders_str0), 2)) {
        heff_drop(v_sp_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_243, v_sp_242, NTAG(TAG_False)});
        return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2420));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_241, 0);
      V v_p12_2424 = heff_field(v_p1_241, 1);
      V v_q_2425 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop(v_sp_242);
      V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_p12_2424, NTAG(TAG_False)});
      V v_cell_2427 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2425, heff_dup(v_cell_2427)));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24dps_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24dps_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_sp_243 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24dps_str0), 2)) {
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_243, NTAG(TAG_False)});
        V v_t_247 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_247);
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2411); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2412);
    }
    case TAG_PatOp: {
      V v_ps_2415 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2415));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2416); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2417);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2421 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2423);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2425 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2425));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2426); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2427);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2429 = heff_field(v_p1_242, 0);
      V v_p12_2430 = heff_field(v_p1_242, 1);
      V v_q_2431 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_sp_243);
      V v_t_2432 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_p12_2430, NTAG(TAG_False)});
      V v_cell_2433 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2432, heff_hole()});
      V v_u_2434 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2433));
      heff_drop(v_u_2434);
      V t_0 = v_q_2431;
      V t_1 = v_cell_2433;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str1, 1, "_");
Clo g_heff_2eelab_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_241, ((V)&g_heff_2eelab_2elocals_2elamBinders_str0), 2)) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_245 = heff_field(v_x1_240, 0);
    V v_sp_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2eelab_2elocals_2elamBinders_str1), 2)) {
      heff_drop(v_x_245);
      heff_drop(v_sp_246);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_248 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_245, v_sp_246, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_249 = heff_field(v_x1_240, 0);
    V v_sp_2410 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_249, v_sp_2410, NTAG(TAG_False)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry, 2, 0};

V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_248));
        V v_b_2412;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2412 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2411 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2412 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2411));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_t_2413 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2410, 0), heff_take_field(v_b_2412, 0)));
        V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2410, 1, 2), heff_get_n(v_b_2412, 1, 2)));
        V v_t_2415 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2416 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_env_240}), v_rest_243));
        V v_t_2417 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2418 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
        V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2418, heff_take_field(v_b_2416, 0)));
        V v_t_2420 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2416, 1, 2)));
        V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2419));
        V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2420));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2421, v_t_2422});
      }
      case TAG_BadFieldDecl: {
        V v_f_2423 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2424 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_f_2423));
        V v_b_2425 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_rest_243));
        V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2424, 0), heff_take_field(v_b_2425, 0)));
        V v_t_2427 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2424, 1, 2), heff_get_n(v_b_2425, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2426, v_t_2427});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry, 2, 0};

V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_248));
        V v_t_2410 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2411 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_env_240}), v_rest_243));
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2413 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_take_field(v_b_2411, 0)));
        V v_t_2415 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
        V v_t_2416 = (g_prelude_2e_2b_2b(heff_take_field(v_a_249, 0), v_t_2414));
        V v_t_2417 = (g_prelude_2e_2b_2b(heff_get_n(v_a_249, 1, 2), v_t_2415));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2416, v_t_2417});
      }
      case TAG_StmtLet: {
        V v_p_2418 = heff_field(v_x311_244, 0);
        V v_e_2419 = heff_field(v_x311_244, 1);
        heff_take_n(v_x311_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2420 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2419));
        V v_bs_2421 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_p_2418)));
        V v_env_2422 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2418));
        V v_b_2423 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2422, v_rest_243));
        V v_t_2424 = (g_prelude_2e_2b_2b(v_bs_2421, heff_take_field(v_b_2423, 0)));
        V v_t_2425 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2423, 1, 2)));
        V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2420, 0), v_t_2424));
        V v_t_2427 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2420, 1, 2), v_t_2425));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2426, v_t_2427});
      }
      case TAG_StmtExpr: {
        V v_e_2428 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2429 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2428));
        V v_b_2430 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_rest_243));
        V v_t_2431 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2429, 0), heff_take_field(v_b_2430, 0)));
        V v_t_2432 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2429, 1, 2), heff_get_n(v_b_2430, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2431, v_t_2432});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_entry, 2, 0};

V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_take_field(v_b_2411, 0)));
      V v_t_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_entry, 2, 0};

V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_t_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_247 = (g_heff_2eelab_2elocals_2efindBinder(v_x_244, v_env_240));
      V v_a_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_245);
        v_a_2410 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_249 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_248, v_xsp_245}), NTAG(TAG_Nil)});
        v_a_2410 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_249});
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_246));
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2410, 0), heff_take_field(v_b_2411, 0)));
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2410, 1, 2), heff_get_n(v_b_2411, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x31_242, 0);
      V v_xsp_2415 = heff_field(v_x31_242, 1);
      V v_t_2416 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_2417 = (g_heff_2eelab_2elocals_2efindBinder(v_x_2414, v_env_240));
      V v_a_2420;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2415);
        v_a_2420 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2418 = heff_field(v_t_2417, 0);
        heff_take_n(v_t_2417, 1ULL, 1);
        V v_t_2419 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2418, v_xsp_2415}), NTAG(TAG_Nil)});
        v_a_2420 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2419});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      V v_b_2421 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2416));
      V v_t_2422 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2420, 0), heff_take_field(v_b_2421, 0)));
      V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2420, 1, 2), heff_get_n(v_b_2421, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2422, v_t_2423});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry, 2, 0};

V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x31_242, 0);
      V v_fsp_245 = heff_field(v_x31_242, 1);
      V v_ty_247 = heff_field(v_x31_242, 3);
      V v_eqs_248 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 27ULL, 5);
      V v_t_249 = (g_heff_2eelab_2elocals_2efindBinder(v_f_244, v_env_240));
      V v_a_2412;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_fsp_245);
        v_a_2412 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2410, v_fsp_245}), NTAG(TAG_Nil)});
        v_a_2412 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2411});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_a_2413 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_ty_247));
      V v_b_2419 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_t_2420 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2413, 0), heff_take_field(v_b_2419, 0)));
      V v_t_2421 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2413, 1, 2), heff_get_n(v_b_2419, 1, 2)));
      V v_t_2422 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2412, 0), v_t_2420));
      V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2412, 1, 2), v_t_2421));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2422, v_t_2423});
    }
    case TAG_DeclDefine: {
      V v_x_2424 = heff_field(v_x31_242, 0);
      V v_xsp_2425 = heff_field(v_x31_242, 1);
      V v_ps_2426 = heff_field(v_x31_242, 2);
      V v_u_2427 = heff_field(v_x31_242, 3);
      V v_body_2428 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 31ULL, 5);
      V v_t_2429 = (g_heff_2eelab_2elocals_2efindBinder(v_x_2424, v_env_240));
      V v_a_2432;
      switch (heff_tag_of(v_t_2429)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2425);
        v_a_2432 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2430 = heff_field(v_t_2429, 0);
        heff_take_n(v_t_2429, 1ULL, 1);
        V v_t_2431 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2430, v_xsp_2425}), NTAG(TAG_Nil)});
        v_a_2432 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2431});
        break;
      }
      default: heff_nomatch(v_t_2429);
      }
      V v_a_2438 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_ps_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2426); r_; });
      V v_a_2439 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_u_2427));
      V v_b_2440 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2428));
      V v_t_2441 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2439, 0), heff_take_field(v_b_2440, 0)));
      V v_t_2442 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2439, 1, 2), heff_get_n(v_b_2440, 1, 2)));
      V v_t_2443 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2438, 0), v_t_2441));
      V v_t_2444 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2438, 1, 2), v_t_2442));
      V v_t_2445 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2432, 0), v_t_2443));
      V v_t_2446 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2432, 1, 2), v_t_2444));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2445, v_t_2446});
    }
    case TAG_DeclTheory: {
      V v_body_2450 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2450);
    }
    case TAG_DeclPrimitive: {
      V v_x_2451 = heff_field(v_x31_242, 0);
      V v_xsp_2452 = heff_field(v_x31_242, 1);
      V v_t_2453 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_2454 = (g_heff_2eelab_2elocals_2efindBinder(v_x_2451, v_env_240));
      V v_a_2457;
      switch (heff_tag_of(v_t_2454)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2452);
        v_a_2457 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2455 = heff_field(v_t_2454, 0);
        heff_take_n(v_t_2454, 1ULL, 1);
        V v_t_2456 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2455, v_xsp_2452}), NTAG(TAG_Nil)});
        v_a_2457 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2456});
        break;
      }
      default: heff_nomatch(v_t_2454);
      }
      V v_b_2458 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2453));
      V v_t_2459 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2457, 0), heff_take_field(v_b_2458, 0)));
      V v_t_2460 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2457, 1, 2), heff_get_n(v_b_2458, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2459, v_t_2460});
    }
    case TAG_DeclTest: {
      V v_x_2461 = heff_field(v_x31_242, 0);
      V v_xsp_2462 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_t_2463 = ({ V a_0 = v_x_2461; V a_1 = v_env_240; V r_ = (g_heff_2eelab_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
      switch (heff_tag_of(v_t_2463)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2462);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_Just: {
        V v_b_2464 = heff_field(v_t_2463, 0);
        heff_take_n(v_t_2463, 1ULL, 1);
        V v_t_2465 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2464, v_xsp_2462}), NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2465});
      }
      default: return heff_nomatch(v_t_2463);
      }
    }
    case TAG_DeclWatch: {
      V v_e_2466 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_2466);
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_eq_2415 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2416 = ({ V a_0 = v_env_240; V a_1 = v_eq_2415; V r_ = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(a_0, a_1)); heff_drop(v_eq_2415); r_; });
  V v_t_2417 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2414, 0), heff_take_field(v_b_2416, 0)));
  V v_t_2418 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2414, 1, 2), heff_get_n(v_b_2416, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2417, v_t_2418});
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args) {
  V v_acc_2433 = args[0];
  V v_m_2434 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2435 = (g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(v_env_240, v_m_2434));
  V v_t_2436 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2433, 0), heff_take_field(v_b_2435, 0)));
  V v_t_2437 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2433, 1, 2), heff_get_n(v_b_2435, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2436, v_t_2437});
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry, 2, 0};

V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      heff_take_n(v_d1_242, 24ULL, 5);
      heff_drop_tag(v_d_241, 2);
      V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), heff_dup(v_ty_247)));
      V v_b_2428 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_t_2429 = (g_prelude_2e_2b_2b(heff_take_field(v_a_249, 0), heff_take_field(v_b_2428, 0)));
      V v_t_2430 = (g_prelude_2e_2b_2b(heff_get_n(v_a_249, 1, 2), heff_get_n(v_b_2428, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2429, v_t_2430});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_d1_242, 0ULL, 5);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_d1_242, 0ULL, 4);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_d1_242, 0ULL, 3);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_d1_242, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_eq_2411 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2421;
  switch (heff_tag_of(v_eq_2411)) {
  case TAG_At: {
    V v_x21_2412 = heff_dup(heff_field(v_eq_2411, 0));
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_fsp_2415 = heff_field(v_x21_2412, 1);
      heff_take_n(v_x21_2412, 3ULL, 4);
      V v_t_2418 = (g_heff_2eelab_2elocals_2efindBinder(v_f_2414, v_env_240));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        heff_drop(v_fsp_2415);
        v_a_2421 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2419 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2419, v_fsp_2415}), NTAG(TAG_Nil)});
        v_a_2421 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2420});
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    default: heff_nomatch(v_x21_2412);
    }
    break;
  }
  default: heff_nomatch(v_eq_2411);
  }
  V v_t_2422 = (g_list_2efoldl_24f1488358745x465096512(v_env_240, v_ty_247));
  V v_b_2423 = ({ V a_0 = v_t_2422; V a_1 = v_eq_2411; V r_ = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(a_0, a_1)); heff_drop(v_eq_2411); r_; });
  V v_t_2424 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2421, 0), heff_take_field(v_b_2423, 0)));
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2421, 1, 2), heff_get_n(v_b_2423, 1, 2)));
  V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2410, 0), v_t_2424));
  V v_t_2427 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2410, 1, 2), v_t_2425));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2426, v_t_2427});
}
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry, 3, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_242));
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x3_241, 0);
    V v_ds_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_d1_245 = heff_dup(heff_field(v_d_243, 0));
      switch (heff_tag_of(v_d1_245)) {
      case TAG_DeclEquations: {
        V v_f_247 = heff_field(v_d1_245, 0);
        V v_fsp_248 = heff_field(v_d1_245, 1);
        heff_take_n(v_d1_245, 3ULL, 5);
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_247, v_fsp_248, NTAG(TAG_False)});
        v_t_2428 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_d1_245, 0ULL, 5);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_d1_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_d1_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_d1_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_d1_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_d1_245);
      }
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_240), v_t_2428));
    V v_a_2430 = (g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(v_t_2429, heff_dup(v_d_243)));
    V v_t_2454;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_d1_2431 = heff_dup(heff_field(v_d_243, 0));
      switch (heff_tag_of(v_d1_2431)) {
      case TAG_DeclEquations: {
        V v_f_2433 = heff_field(v_d1_2431, 0);
        V v_fsp_2434 = heff_field(v_d1_2431, 1);
        heff_take_n(v_d1_2431, 3ULL, 5);
        V v_t_2438 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2433, v_fsp_2434, NTAG(TAG_False)});
        v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_d1_2431, 0ULL, 5);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_d1_2431, 0ULL, 4);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_d1_2431, 0ULL, 3);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_d1_2431, 0ULL, 2);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_d1_2431, 0ULL, 1);
        v_t_2454 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_d1_2431);
      }
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2454));
    V v_b_2456 = (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_t_2455, v_ds_244, v_body_242));
    V v_t_2457 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2430, 0), heff_take_field(v_b_2456, 0)));
    V v_t_2458 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2430, 1, 2), heff_get_n(v_b_2456, 1, 2)));
    V v_t_2482;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_d1_2459 = heff_field(v_d_243, 0);
      V v_ru_24d_243_24At = heff_take_reuse_n(v_d_243, 1ULL, 2);
      switch (heff_tag_of(v_d1_2459)) {
      case TAG_DeclEquations: {
        V v_f_2461 = heff_field(v_d1_2459, 0);
        V v_fsp_2462 = heff_field(v_d1_2459, 1);
        heff_take_n(v_d1_2459, 3ULL, 5);
        V v_t_2466 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2461, v_fsp_2462, NTAG(TAG_False)});
        v_t_2482 = heff_tag_at_n(v_ru_24d_243_24At, TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_d1_2459, 0ULL, 5);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2482 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_d1_2459, 0ULL, 4);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2482 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_d1_2459, 0ULL, 3);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2482 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_d1_2459, 0ULL, 2);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2482 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_d1_2459, 0ULL, 1);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2482 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_d1_2459);
      }
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_t_2483 = (g_prelude_2e_2b_2b(v_t_2482, v_t_2457));
    V v_t_2484 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2458));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2483, v_t_2484});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a[0], a[1], a[2]);
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam2(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam1(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam3(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam4(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam5(V self, V *args);
Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry, 2, 0};

V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V v_env_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      V v_t_245 = ({ V a_0 = v_x_244; V a_1 = v_env_240; V r_ = (g_heff_2eelab_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        heff_drop_tag(v_n_241, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_Just: {
        V v_b_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_n_241)) {
        case TAG_At: {
          V v_s_248 = heff_field(v_n_241, 1);
          heff_take_n(v_n_241, 2ULL, 2);
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_n_241);
        }
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_246, v_t_249}), NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2410});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_ETag: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EInt: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EFloat: {
      heff_take_na(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EString: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EBinary: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_ERune: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EWord: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_n1_242, 0);
      V v_args_2420 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_2421 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_h_2419));
      V v_b_2427 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_2420); r_; });
      V v_t_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2421, 0), heff_take_field(v_b_2427, 0)));
      V v_t_2429 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2421, 1, 2), heff_get_n(v_b_2427, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2428, v_t_2429});
    }
    case TAG_EProject: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_ENamed: {
      V v_e_2432 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 2ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V t_0 = v_env_240;
      V t_1 = v_e_2432;
      v_env_240 = t_0;
      v_n_241 = t_1;
      goto top;
    }
    case TAG_EPi: {
      V v_n11_2433 = heff_field(v_n1_242, 0);
      V v_r_2434 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24EPi = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      switch (heff_tag_of(v_n11_2433)) {
      case TAG_PiNamed: {
        V v_x_2435 = heff_field(v_n11_2433, 0);
        V v_sp_2436 = heff_field(v_n11_2433, 1);
        V v_a_2437 = heff_field(v_n11_2433, 2);
        heff_take_n(v_n11_2433, 7ULL, 3);
        V v_a_2438 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2437));
        V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2435), heff_dup(v_sp_2436), NTAG(TAG_False)});
        V v_t_2440 = heff_tag_at_n(v_ru_24n1_242_24EPi, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
        V v_env_2441 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2440));
        V v_b_2442 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2441, v_r_2434));
        V v_t_2443 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2435, v_sp_2436, NTAG(TAG_False)});
        V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
        V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2444, heff_take_field(v_b_2442, 0)));
        V v_t_2446 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2442, 1, 2)));
        V v_t_2447 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2438, 0), v_t_2445));
        V v_t_2448 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2438, 1, 2), v_t_2446));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2447, v_t_2448});
      }
      case TAG_PiImplicit: {
        V v_x_2449 = heff_field(v_n11_2433, 0);
        V v_sp_2450 = heff_field(v_n11_2433, 1);
        V v_a_2452 = heff_field(v_n11_2433, 3);
        V v_d_2453 = heff_field(v_n11_2433, 4);
        heff_take_n(v_n11_2433, 27ULL, 5);
        V v_a_2454 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2452));
        V v_b_2456;
        switch (heff_tag_of(v_d_2453)) {
        case TAG_Nothing: {
          v_b_2456 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2455 = heff_field(v_d_2453, 0);
          heff_take_n(v_d_2453, 1ULL, 1);
          v_b_2456 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2455));
          break;
        }
        default: heff_nomatch(v_d_2453);
        }
        V v_t_2457 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2454, 0), heff_take_field(v_b_2456, 0)));
        V v_t_2458 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2454, 1, 2), heff_get_n(v_b_2456, 1, 2)));
        V v_t_2459 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2449), heff_dup(v_sp_2450), NTAG(TAG_False)});
        V v_t_2460 = heff_tag_at_n(v_ru_24n1_242_24EPi, TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
        V v_env_2461 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2460));
        V v_b_2462 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2461, v_r_2434));
        V v_t_2463 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2449, v_sp_2450, NTAG(TAG_False)});
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
        V v_t_2465 = (g_prelude_2e_2b_2b(v_t_2464, heff_take_field(v_b_2462, 0)));
        V v_t_2466 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2462, 1, 2)));
        V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2457, v_t_2465));
        V v_t_2468 = (g_prelude_2e_2b_2b(v_t_2458, v_t_2466));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2467, v_t_2468});
      }
      case TAG_PiInstance: {
        V v_x_2469 = heff_field(v_n11_2433, 0);
        V v_sp_2470 = heff_field(v_n11_2433, 1);
        V v_a_2472 = heff_field(v_n11_2433, 3);
        heff_take_n(v_n11_2433, 11ULL, 4);
        V v_a_2473 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2472));
        V v_t_2474 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2469), heff_dup(v_sp_2470), NTAG(TAG_False)});
        V v_t_2475 = heff_tag_at_n(v_ru_24n1_242_24EPi, TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
        V v_env_2476 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2475));
        V v_b_2477 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2476, v_r_2434));
        V v_t_2478 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2469, v_sp_2470, NTAG(TAG_False)});
        V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, NTAG(TAG_Nil)});
        V v_t_2480 = (g_prelude_2e_2b_2b(v_t_2479, heff_take_field(v_b_2477, 0)));
        V v_t_2481 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2477, 1, 2)));
        V v_t_2482 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2473, 0), v_t_2480));
        V v_t_2483 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2473, 1, 2), v_t_2481));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2482, v_t_2483});
      }
      case TAG_PiAnon: {
        V v_a_2484 = heff_field(v_n11_2433, 0);
        heff_take_n(v_n11_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24n1_242_24EPi, 2);
        V v_a_2485 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2484));
        V v_b_2486 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_r_2434));
        V v_t_2487 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2485, 0), heff_take_field(v_b_2486, 0)));
        V v_t_2488 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2485, 1, 2), heff_get_n(v_b_2486, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2487, v_t_2488});
      }
      default: return heff_nomatch(v_n11_2433);
      }
    }
    case TAG_ELam: {
      V v_n11_2489 = heff_field(v_n1_242, 0);
      V v_r_2490 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24ELam = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      switch (heff_tag_of(v_n11_2489)) {
      case TAG_LamName: {
        heff_drop_cell(v_ru_24n1_242_24ELam, 2);
        V v_bs_2493 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_2489));
        V v_env_2494 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_2493)));
        V v_b_2495 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2494, v_r_2490));
        V v_t_2496 = (g_prelude_2e_2b_2b(v_bs_2493, heff_take_field(v_b_2495, 0)));
        V v_t_2497 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2495, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2496, v_t_2497});
      }
      case TAG_LamImplicit: {
        heff_drop_cell(v_ru_24n1_242_24ELam, 2);
        V v_bs_24100 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_2489));
        V v_env_24101 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24100)));
        V v_b_24102 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24101, v_r_2490));
        V v_t_24103 = (g_prelude_2e_2b_2b(v_bs_24100, heff_take_field(v_b_24102, 0)));
        V v_t_24104 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24102, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24103, v_t_24104});
      }
      case TAG_LamAnn: {
        V v_x_24105 = heff_field(v_n11_2489, 0);
        V v_sp_24106 = heff_field(v_n11_2489, 1);
        V v_a_24107 = heff_field(v_n11_2489, 2);
        heff_take_n(v_n11_2489, 7ULL, 3);
        V v_a_24108 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_24107));
        V v_t_24109 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24105), heff_dup(v_sp_24106), NTAG(TAG_False)});
        V v_t_24110 = heff_tag_at_n(v_ru_24n1_242_24ELam, TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
        V v_env_24111 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_24110));
        V v_b_24112 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24111, v_r_2490));
        V v_t_24113 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24105, v_sp_24106, NTAG(TAG_False)});
        V v_t_24114 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, NTAG(TAG_Nil)});
        V v_t_24115 = (g_prelude_2e_2b_2b(v_t_24114, heff_take_field(v_b_24112, 0)));
        V v_t_24116 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24112, 1, 2)));
        V v_t_24117 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24108, 0), v_t_24115));
        V v_t_24118 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24108, 1, 2), v_t_24116));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24117, v_t_24118});
      }
      default: return heff_nomatch(v_n11_2489);
      }
    }
    case TAG_EAnn: {
      V v_e_24119 = heff_field(v_n1_242, 0);
      V v_t_24120 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_24121 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_24119));
      V v_b_24122 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_24120));
      V v_t_24123 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24121, 0), heff_take_field(v_b_24122, 0)));
      V v_t_24124 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24121, 1, 2), heff_get_n(v_b_24122, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24123, v_t_24124});
    }
    case TAG_ESpec: {
      V v_acc_24125 = heff_field(v_n1_242, 0);
      V v_v_24128 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 9ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_a_24129 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_acc_24125));
      V v_b_24130 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_v_24128));
      V v_t_24131 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24129, 0), heff_take_field(v_b_24130, 0)));
      V v_t_24132 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24129, 1, 2), heff_get_n(v_b_24130, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24131, v_t_24132});
    }
    case TAG_ESig: {
      V v_fs_24133 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_fs_24133);
    }
    case TAG_ESum: {
      V v_vs_24134 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam1, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_vs_24134; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24134); r_; });
    }
    case TAG_EStruct: {
      V v_fs_24151 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam3, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_fs_24151; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24151); r_; });
    }
    case TAG_EUpdate: {
      V v_a_24163 = heff_field(v_n1_242, 0);
      V v_fs_24164 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_24165 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_24163));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam4, 2, 1, (V[]){v_env_240}); V a_1 = v_t_24165; V a_2 = v_fs_24164; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24164); r_; });
    }
    case TAG_EMatch: {
      V v_s_24175 = heff_field(v_n1_242, 0);
      V v_alts_24176 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_24177 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_s_24175));
      V v_b_24192 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam5, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_alts_24176; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24176); r_; });
      V v_t_24193 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24177, 0), heff_take_field(v_b_24192, 0)));
      V v_t_24194 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24177, 1, 2), heff_get_n(v_b_24192, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24193, v_t_24194});
    }
    case TAG_ELetIn: {
      V v_rhs_24195 = heff_field(v_n1_242, 0);
      V v_a_24196 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_24197 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_rhs_24195));
      V v_b_24207;
      switch (heff_tag_of(v_a_24196)) {
      case TAG_At: {
        V v_x31_24198 = heff_field(v_a_24196, 0);
        heff_take_n(v_a_24196, 1ULL, 2);
        switch (heff_tag_of(v_x31_24198)) {
        case TAG_MkAlt: {
          V v_p_24200 = heff_field(v_x31_24198, 0);
          V v_r_24201 = heff_field(v_x31_24198, 1);
          heff_take_n(v_x31_24198, 3ULL, 2);
          V v_bs_24202 = (g_heff_2eelab_2elocals_2epatternBinders(v_p_24200));
          V v_env_24203 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24202)));
          V v_b_24204 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24203, v_r_24201));
          V v_t_24205 = (g_prelude_2e_2b_2b(v_bs_24202, heff_take_field(v_b_24204, 0)));
          V v_t_24206 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24204, 1, 2)));
          v_b_24207 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24205, v_t_24206});
          break;
        }
        default: heff_nomatch(v_x31_24198);
        }
        break;
      }
      default: heff_nomatch(v_a_24196);
      }
      V v_t_24208 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24197, 0), heff_take_field(v_b_24207, 0)));
      V v_t_24209 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24197, 1, 2), heff_get_n(v_b_24207, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24208, v_t_24209});
    }
    case TAG_EDo: {
      V v_stmts_24210 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_stmts_24210);
    }
    case TAG_ELocal: {
      V v_body_24211 = heff_field(v_n1_242, 0);
      V v_defs_24212 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_env_240, v_defs_24212, v_body_24211));
    }
    case TAG_EInvalid: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam0(V self, V *args) {
  V v_acc_2422 = args[0];
  V v_x_2423 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2424 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_2423));
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2422, 0), heff_take_field(v_b_2424, 0)));
  V v_t_2426 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2422, 1, 2), heff_get_n(v_b_2424, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2425, v_t_2426});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam2(V self, V *args) {
  V v_acc_24142 = args[0];
  V v_x_24143 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24144 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_24143));
  V v_t_24145 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24142, 0), heff_take_field(v_b_24144, 0)));
  V v_t_24146 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24142, 1, 2), heff_get_n(v_b_24144, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24145, v_t_24146});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam1(V self, V *args) {
  V v_acc_24135 = args[0];
  V v_v_24136 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24148;
  switch (heff_tag_of(v_v_24136)) {
  case TAG_At: {
    V v_it1_24137 = heff_field(v_v_24136, 0);
    heff_take_n(v_v_24136, 1ULL, 2);
    switch (heff_tag_of(v_it1_24137)) {
    case TAG_TagVariant: {
      V v_args_24141 = heff_field(v_it1_24137, 2);
      heff_take_n(v_it1_24137, 4ULL, 3);
      v_b_24148 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam2, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24141; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24141); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24147 = heff_field(v_it1_24137, 0);
      heff_take_n(v_it1_24137, 1ULL, 1);
      v_b_24148 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24147));
      break;
    }
    default: heff_nomatch(v_it1_24137);
    }
    break;
  }
  default: heff_nomatch(v_v_24136);
  }
  V v_t_24149 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24135, 0), heff_take_field(v_b_24148, 0)));
  V v_t_24150 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24135, 1, 2), heff_get_n(v_b_24148, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24149, v_t_24150});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam3(V self, V *args) {
  V v_acc_24152 = args[0];
  V v_f_24153 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24160;
  switch (heff_tag_of(v_f_24153)) {
  case TAG_At: {
    V v_x31_24154 = heff_field(v_f_24153, 0);
    heff_take_n(v_f_24153, 1ULL, 2);
    switch (heff_tag_of(v_x31_24154)) {
    case TAG_SetField: {
      V v_e_24158 = heff_field(v_x31_24154, 2);
      heff_take_n(v_x31_24154, 4ULL, 3);
      v_b_24160 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24158));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24159 = heff_field(v_x31_24154, 0);
      heff_take_n(v_x31_24154, 1ULL, 1);
      v_b_24160 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24159));
      break;
    }
    default: heff_nomatch(v_x31_24154);
    }
    break;
  }
  default: heff_nomatch(v_f_24153);
  }
  V v_t_24161 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24152, 0), heff_take_field(v_b_24160, 0)));
  V v_t_24162 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24152, 1, 2), heff_get_n(v_b_24160, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24161, v_t_24162});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam4(V self, V *args) {
  V v_acc_24166 = args[0];
  V v_f_24167 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24167)) {
  case TAG_At: {
    V v_it1_24168 = heff_field(v_f_24167, 0);
    heff_take_n(v_f_24167, 1ULL, 2);
    switch (heff_tag_of(v_it1_24168)) {
    case TAG_SetPath: {
      V v_e_24171 = heff_field(v_it1_24168, 1);
      heff_take_n(v_it1_24168, 2ULL, 2);
      V v_b_24172 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24171));
      V v_t_24173 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24166, 0), heff_take_field(v_b_24172, 0)));
      V v_t_24174 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24166, 1, 2), heff_get_n(v_b_24172, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24173, v_t_24174});
    }
    default: return heff_nomatch(v_it1_24168);
    }
  }
  default: return heff_nomatch(v_f_24167);
  }
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam5(V self, V *args) {
  V v_acc_24178 = args[0];
  V v_a_24179 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24189;
  switch (heff_tag_of(v_a_24179)) {
  case TAG_At: {
    V v_x31_24180 = heff_field(v_a_24179, 0);
    heff_take_n(v_a_24179, 1ULL, 2);
    switch (heff_tag_of(v_x31_24180)) {
    case TAG_MkAlt: {
      V v_p_24182 = heff_field(v_x31_24180, 0);
      V v_r_24183 = heff_field(v_x31_24180, 1);
      heff_take_n(v_x31_24180, 3ULL, 2);
      V v_bs_24184 = (g_heff_2eelab_2elocals_2epatternBinders(v_p_24182));
      V v_env_24185 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24184)));
      V v_b_24186 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24185, v_r_24183));
      V v_t_24187 = (g_prelude_2e_2b_2b(v_bs_24184, heff_take_field(v_b_24186, 0)));
      V v_t_24188 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24186, 1, 2)));
      v_b_24189 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24187, v_t_24188});
      break;
    }
    default: heff_nomatch(v_x31_24180);
    }
    break;
  }
  default: heff_nomatch(v_a_24179);
  }
  V v_t_24190 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24178, 0), heff_take_field(v_b_24189, 0)));
  V v_t_24191 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24178, 1, 2), heff_get_n(v_b_24189, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24190, v_t_24191});
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2earguments_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_entry, 3, 0};

V g_heff_2eelab_2elocals_2earguments(V v_env_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2eelab_2elocals_2earguments_lam0, 2, 1, (V[]){v_env_240}), heff_dup(g_heff_2eelab_2elocals_2enone_get()), v_rest_242);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_tl_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_x211_2410 = heff_field(v_x21_248, 0);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 1ULL, 2);
      switch (heff_tag_of(v_x211_2410)) {
      case TAG_ExplicitParam: {
        V v_x_2412 = heff_field(v_x211_2410, 0);
        V v_sp_2413 = heff_field(v_x211_2410, 1);
        V v_t_2414 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2415 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2414));
        V v_t_2416 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2412), heff_dup(v_sp_2413), NTAG(TAG_False)});
        V v_b_2417 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2418 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2412, v_sp_2413, NTAG(TAG_False)});
        V v_t_2419 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, heff_take_field(v_b_2417, 0)));
        V v_t_2421 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2417, 1, 2)));
        V v_t_2422 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2415, 0), v_t_2420));
        V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2415, 1, 2), v_t_2421));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2422, v_t_2423});
      }
      case TAG_ImplicitParam: {
        V v_x_2424 = heff_field(v_x211_2410, 0);
        V v_sp_2425 = heff_field(v_x211_2410, 1);
        V v_t_2426 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2426));
        V v_t_2428 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2424), heff_dup(v_sp_2425), NTAG(TAG_False)});
        V v_b_2429 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2428, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2430 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2424, v_sp_2425, NTAG(TAG_False)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
        V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, heff_take_field(v_b_2429, 0)));
        V v_t_2433 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2429, 1, 2)));
        V v_t_2434 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2427, 0), v_t_2432));
        V v_t_2435 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2427, 1, 2), v_t_2433));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2434, v_t_2435});
      }
      default: return heff_nomatch(v_x211_2410);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2elocals_2earguments(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_245 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_244));
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_243, 0), heff_take_field(v_b_245, 0)));
  V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_243, 1, 2), heff_get_n(v_b_245, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_246, v_t_247});
}
Clo g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_entry, 2, 0};

V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_take_field(v_b_2411, 0)));
      V v_t_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclaration_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclaration_entry, 1, 0};

V g_heff_2eelab_2elocals_2edeclaration(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_eqs_247 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 24ULL, 5);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_a_248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_ty_246)));
      V v_b_2415 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclaration_lam0, 2, 1, (V[]){v_ty_246}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_247); r_; });
      V v_t_2416 = (g_prelude_2e_2b_2b(heff_take_field(v_a_248, 0), heff_take_field(v_b_2415, 0)));
      V v_t_2417 = (g_prelude_2e_2b_2b(heff_get_n(v_a_248, 1, 2), heff_get_n(v_b_2415, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2416, v_t_2417});
    }
    case TAG_DeclDefine: {
      V v_ps_2420 = heff_field(v_x11_241, 2);
      V v_ty_2421 = heff_field(v_x11_241, 3);
      V v_body_2422 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 28ULL, 5);
      V v_t_2423 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2422, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2420; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_ty_2421, v_t_2423}); V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    }
    case TAG_DeclTheory: {
      V v_ps_2426 = heff_field(v_x11_241, 2);
      V v_body_2427 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 12ULL, 4);
      V v_t_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2427, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2426; V a_2 = v_t_2428; V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, a_2)); heff_drop_tag(v_t_2428, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      V v_t_2431 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_t_2431));
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_DeclWatch: {
      V v_e_2434 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_e_2434));
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclaration(a[0]);
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_eq_2410 = args[1];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_list_2efoldl_24f1488358745x465096512(NTAG(TAG_Nil), v_ty_246));
  V v_b_2412 = ({ V a_0 = v_t_2411; V a_1 = v_eq_2410; V r_ = (g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(a_0, a_1)); heff_drop(v_eq_2410); r_; });
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_249, 0), heff_take_field(v_b_2412, 0)));
  V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_249, 1, 2), heff_get_n(v_b_2412, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2413, v_t_2414});
}
V g_heff_2eelab_2elocals_2elocalsOf_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsOf_entry, 1, 0};

V g_heff_2eelab_2elocals_2elocalsOf(V v_found_240) {
top: ;
  V v_t_241 = (g_list_2efilter_24s2018073091x1385246979(heff_dup(heff_rfield(v_found_240, 0))));
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2elocals_2elocalsOf_lam0, 1, 1, (V[]){heff_dup(v_found_240)}), v_t_241));
  V v_t_245 = (g_list_2emap_24f1133029339x682401273(heff_get_n(v_found_240, 1, 2)));
  return heff_rec_n(2, shape_locals__fields, (V[]){v_t_244, v_t_245});
}
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsOf(a[0]);
}
V g_heff_2eelab_2elocals_2elocalsOf_lam0(V self, V *args) {
  V v_b_242 = args[0];
  V v_found_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_list_2emap_24f342794667x1308411312(heff_dup(v_b_242), heff_get_n(v_found_240, 1, 2)));
  return heff_rec_n(3, shape_name__binder__uses, (V[]){heff_dup(heff_rfield(v_b_242, 0)), heff_get_n(v_b_242, 1, 3), v_t_243});
}