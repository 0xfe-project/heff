// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361 38668
#define TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481 14273
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2eelab_2elocals_2earguments(V, V, V);
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_clo;
HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V, V);
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo;
HeffT2 g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(V, V);
HeffT2 g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_24cpr(V, V);
HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V, V);
V g_heff_2eelab_2elocals_2elamBinders(V);
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elamBinders_clo;
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V, V);
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V, V, V, V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
HeffT2 g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(V, V);
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24dps(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo;
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V, V);
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo;
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2ekeepIf_24s1266148589x1647110933(V);
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1213328022x1811586494(V, V);
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_clo;
V g_list_2emap_24f565269645x1954016017(V);
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;

static V g_heff_2eelab_2elocals_2enone_val;
static HEFF_ONCE g_heff_2eelab_2elocals_2enone_st;
static V g_heff_2eelab_2elocals_2enone_init(void) {
  return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2elocals_2enone_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2elocals_2enone_st)) return g_heff_2eelab_2elocals_2enone_val;
  return heff_global(&g_heff_2eelab_2elocals_2enone_val, &g_heff_2eelab_2elocals_2enone_st, g_heff_2eelab_2elocals_2enone_init);
}

HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_b_242, 0)), heff_dup(v_x_240))) {
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_b_242}});
    } else {
      heff_drop_rec(v_b_242, 3);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_p2_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2eelab_2elocals_2epatternBinders_str0), 2)) {
        heff_drop(v_p2_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_244 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_243, v_p2_242, NTAG(TAG_False)});
        return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_247));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2411 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2416 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2416));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2417); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2419 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2419));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2420); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2422 = heff_field(v_p1_241, 0);
      V v_sp_2423 = heff_field(v_p1_241, 1);
      V v_q_2424 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop(v_p2_242);
      V v_t_2425 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2422, v_sp_2423, NTAG(TAG_False)});
      V v_cell_2426 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
      V v_u_2427 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2424, heff_dup(v_cell_2426)));
      heff_drop(v_u_2427);
      return v_cell_2426;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24dps_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24dps_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_p2_243 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24dps_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        V v_t_246 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_246);
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2416);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2420));
      V v_t_2422 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2421); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2422);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2424 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2425); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2426);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2428 = heff_field(v_p1_242, 0);
      V v_sp_2429 = heff_field(v_p1_242, 1);
      V v_q_2430 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2431 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2428, v_sp_2429, NTAG(TAG_False)});
      V v_cell_2432 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2431, heff_hole()});
      V v_u_2433 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2432));
      heff_drop(v_u_2433);
      V t_0 = v_q_2430;
      V t_1 = v_cell_2432;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str1, 1, "_");
Clo g_heff_2eelab_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_241, ((V)&g_heff_2eelab_2elocals_2elamBinders_str0), 2)) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_243 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_sp_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2elamBinders_str1), 2)) {
      heff_drop(v_x_244);
      heff_drop(v_sp_245);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_245, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_247 = heff_field(v_x1_240, 0);
    V v_sp_248 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2410 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_247, v_sp_248, NTAG(TAG_False)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry, 2, 0};

V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_248));
        V v_binders_2411 = heff_take_field(v_a_2410, 0);
        V v_uses_2412 = heff_get_n(v_a_2410, 1, 2);
        V v_b_2414;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2414 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2413 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2414 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2413));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_binders_2415 = heff_take_field(v_b_2414, 0);
        V v_uses_2416 = heff_get_n(v_b_2414, 1, 2);
        V v_t_2417 = (g_prelude_2e_2b_2b(v_binders_2411, v_binders_2415));
        V v_t_2418 = (g_prelude_2e_2b_2b(v_uses_2412, v_uses_2416));
        V v_t_2419 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2420 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, v_env_240}), v_rest_243));
        V v_binders_2421 = heff_take_field(v_b_2420, 0);
        V v_uses_2422 = heff_get_n(v_b_2420, 1, 2);
        V v_t_2423 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2424 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
        V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2424, v_binders_2421));
        V v_t_2426 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2422));
        V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2425));
        V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2426));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2427, v_t_2428});
      }
      case TAG_BadFieldDecl: {
        V v_f_2429 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2430 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_f_2429));
        V v_binders_2431 = heff_take_field(v_a_2430, 0);
        V v_uses_2432 = heff_get_n(v_a_2430, 1, 2);
        V v_b_2433 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_rest_243));
        V v_binders_2434 = heff_take_field(v_b_2433, 0);
        V v_uses_2435 = heff_get_n(v_b_2433, 1, 2);
        V v_t_2436 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2431, v_binders_2434));
        V v_t_2437 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2432, v_uses_2435));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2436, v_t_2437});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry, 2, 0};

V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_248));
        V v_binders_2410 = heff_take_field(v_a_249, 0);
        V v_uses_2411 = heff_get_n(v_a_249, 1, 2);
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2413 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, v_env_240}), v_rest_243));
        V v_binders_2414 = heff_take_field(v_b_2413, 0);
        V v_uses_2415 = heff_get_n(v_b_2413, 1, 2);
        V v_t_2416 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2417 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
        V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2417, v_binders_2414));
        V v_t_2419 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2415));
        V v_t_2420 = (g_prelude_2e_2b_2b(v_binders_2410, v_t_2418));
        V v_t_2421 = (g_prelude_2e_2b_2b(v_uses_2411, v_t_2419));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2420, v_t_2421});
      }
      case TAG_StmtLet: {
        V v_p_2422 = heff_field(v_x311_244, 0);
        V v_e_2423 = heff_field(v_x311_244, 1);
        V v_ru_24x311_244_24StmtLet = heff_take_reuse_n(v_x311_244, 3ULL, 2);
        V v_a_2424 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2423));
        V v_binders_2425 = heff_take_field(v_a_2424, 0);
        V v_uses_2426 = heff_get_n(v_a_2424, 1, 2);
        V v_bs_2427 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2422)));
        V v_env_2428 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2422));
        V v_b_2429 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2428, v_rest_243));
        V v_binders_2430 = heff_take_field(v_b_2429, 0);
        V v_uses_2431 = heff_get_n(v_b_2429, 1, 2);
        V v_t_2432 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2427, v_binders_2430));
        V v_t_2433 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x311_244_24StmtLet, NTAG(TAG_Nil), v_uses_2431));
        V v_t_2434 = (g_prelude_2e_2b_2b(v_binders_2425, v_t_2432));
        V v_t_2435 = (g_prelude_2e_2b_2b(v_uses_2426, v_t_2433));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2434, v_t_2435});
      }
      case TAG_StmtExpr: {
        V v_e_2436 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2437 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2436));
        V v_binders_2438 = heff_take_field(v_a_2437, 0);
        V v_uses_2439 = heff_get_n(v_a_2437, 1, 2);
        V v_b_2440 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_rest_243));
        V v_binders_2441 = heff_take_field(v_b_2440, 0);
        V v_uses_2442 = heff_get_n(v_b_2440, 1, 2);
        V v_t_2443 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2438, v_binders_2441));
        V v_t_2444 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2439, v_uses_2442));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2443, v_t_2444});
      }
      case TAG_StmtLetMut: {
        V v_x_2445 = heff_field(v_x311_244, 0);
        V v_sp_2446 = heff_field(v_x311_244, 1);
        V v_e_2447 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2448 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2447));
        V v_binders_2449 = heff_take_field(v_a_2448, 0);
        V v_uses_2450 = heff_get_n(v_a_2448, 1, 2);
        V v_t_2451 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2445), heff_dup(v_sp_2446), NTAG(TAG_False)});
        V v_b_2452 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2451, v_env_240}), v_rest_243));
        V v_binders_2453 = heff_take_field(v_b_2452, 0);
        V v_uses_2454 = heff_get_n(v_b_2452, 1, 2);
        V v_t_2455 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2445, v_sp_2446, NTAG(TAG_False)});
        V v_t_2456 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
        V v_t_2457 = (g_prelude_2e_2b_2b(v_t_2456, v_binders_2453));
        V v_t_2458 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2454));
        V v_t_2459 = (g_prelude_2e_2b_2b(v_binders_2449, v_t_2457));
        V v_t_2460 = (g_prelude_2e_2b_2b(v_uses_2450, v_t_2458));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2459, v_t_2460});
      }
      case TAG_StmtLetElse: {
        V v_p_2461 = heff_field(v_x311_244, 0);
        V v_e_2462 = heff_field(v_x311_244, 1);
        V v_ss_2463 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2464 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2462));
        V v_binders_2465 = heff_take_field(v_a_2464, 0);
        V v_uses_2466 = heff_get_n(v_a_2464, 1, 2);
        V v_a_2467 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_240), v_ss_2463));
        V v_binders_2468 = heff_take_field(v_a_2467, 0);
        V v_uses_2469 = heff_get_n(v_a_2467, 1, 2);
        V v_bs_2470 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2461)));
        V v_env_2471 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2461));
        V v_b_2472 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2471, v_rest_243));
        V v_binders_2473 = heff_take_field(v_b_2472, 0);
        V v_uses_2474 = heff_get_n(v_b_2472, 1, 2);
        V v_t_2475 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2470, v_binders_2473));
        V v_t_2476 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2474));
        V v_t_2477 = (g_prelude_2e_2b_2b(v_binders_2468, v_t_2475));
        V v_t_2478 = (g_prelude_2e_2b_2b(v_uses_2469, v_t_2476));
        V v_t_2479 = (g_prelude_2e_2b_2b(v_binders_2465, v_t_2477));
        V v_t_2480 = (g_prelude_2e_2b_2b(v_uses_2466, v_t_2478));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2479, v_t_2480});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 12ULL, 4);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, v_rhs_247));
      V v_binders_2412 = heff_take_field(v_b_2411, 0);
      V v_uses_2413 = heff_get_n(v_b_2411, 1, 2);
      V v_f_2414 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24At, v_bs_249, v_binders_2412));
      V v_f_2415 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2413));
      return ((HeffT2){{v_f_2414, v_f_2415}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_t_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_247 = ({ V a_0 = v_x_244; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_244); r_; });
      V v_a_2412;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_b_2410 = v_field_249;
          V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2410, v_xsp_245}), NTAG(TAG_Nil)});
          v_a_2412 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2411});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_245);
          heff_drop(v_field_249);
          v_a_2412 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2413 = heff_take_field(v_a_2412, 0);
      V v_uses_2414 = heff_get_n(v_a_2412, 1, 2);
      V v_b_2415 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_246));
      V v_binders_2416 = heff_take_field(v_b_2415, 0);
      V v_uses_2417 = heff_get_n(v_b_2415, 1, 2);
      V v_f_2418 = (g_prelude_2e_2b_2b(v_binders_2413, v_binders_2416));
      V v_f_2419 = (g_prelude_2e_2b_2b(v_uses_2414, v_uses_2417));
      return ((HeffT2){{v_f_2418, v_f_2419}});
    }
    case TAG_ImplicitParam: {
      V v_x_2420 = heff_field(v_x31_242, 0);
      V v_xsp_2421 = heff_field(v_x31_242, 1);
      V v_t_2422 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_2423 = ({ V a_0 = v_x_2420; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2420); r_; });
      V v_a_2428;
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          V v_b_2426 = v_field_2425;
          V v_t_2427 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2426, v_xsp_2421}), NTAG(TAG_Nil)});
          v_a_2428 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2427});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2421);
          heff_drop(v_field_2425);
          v_a_2428 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2429 = heff_take_field(v_a_2428, 0);
      V v_uses_2430 = heff_get_n(v_a_2428, 1, 2);
      V v_b_2431 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2422));
      V v_binders_2432 = heff_take_field(v_b_2431, 0);
      V v_uses_2433 = heff_get_n(v_b_2431, 1, 2);
      V v_f_2434 = (g_prelude_2e_2b_2b(v_binders_2429, v_binders_2432));
      V v_f_2435 = (g_prelude_2e_2b_2b(v_uses_2430, v_uses_2433));
      return ((HeffT2){{v_f_2434, v_f_2435}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry, 2, 0};

V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x31_242, 0);
      V v_fsp_245 = heff_field(v_x31_242, 1);
      V v_ty_247 = heff_field(v_x31_242, 3);
      V v_eqs_248 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 27ULL, 5);
      HeffT2 v_t_249 = ({ V a_0 = v_f_244; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_244); r_; });
      V v_a_2414;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_b_2412 = v_field_2411;
          V v_t_2413 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2412, v_fsp_245}), NTAG(TAG_Nil)});
          v_a_2414 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2413});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_fsp_245);
          heff_drop(v_field_2411);
          v_a_2414 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2415 = heff_take_field(v_a_2414, 0);
      V v_uses_2416 = heff_get_n(v_a_2414, 1, 2);
      V v_a_2417 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_ty_247));
      V v_binders_2418 = heff_take_field(v_a_2417, 0);
      V v_uses_2419 = heff_get_n(v_a_2417, 1, 2);
      V v_b_2429 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_binders_2430 = heff_take_field(v_b_2429, 0);
      V v_uses_2431 = heff_get_n(v_b_2429, 1, 2);
      V v_t_2432 = (g_prelude_2e_2b_2b(v_binders_2418, v_binders_2430));
      V v_t_2433 = (g_prelude_2e_2b_2b(v_uses_2419, v_uses_2431));
      V v_t_2434 = (g_prelude_2e_2b_2b(v_binders_2415, v_t_2432));
      V v_t_2435 = (g_prelude_2e_2b_2b(v_uses_2416, v_t_2433));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2434, v_t_2435});
    }
    case TAG_DeclDefine: {
      V v_x_2436 = heff_field(v_x31_242, 0);
      V v_xsp_2437 = heff_field(v_x31_242, 1);
      V v_ps_2438 = heff_field(v_x31_242, 2);
      V v_u_2439 = heff_field(v_x31_242, 3);
      V v_body_2440 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 31ULL, 5);
      HeffT2 v_t_2441 = ({ V a_0 = v_x_2436; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2436); r_; });
      V v_a_2446;
      {
        V v_field_2443 = v_t_2441.f[1];
        int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
        if ((v_tag_2442 == ((int64_t)0ULL))) {
          V v_b_2444 = v_field_2443;
          V v_t_2445 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2444, v_xsp_2437}), NTAG(TAG_Nil)});
          v_a_2446 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2445});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2437);
          heff_drop(v_field_2443);
          v_a_2446 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2447 = heff_take_field(v_a_2446, 0);
      V v_uses_2448 = heff_get_n(v_a_2446, 1, 2);
      V v_a_2458 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_ps_2438; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2438); r_; });
      V v_binders_2459 = heff_take_field(v_a_2458, 0);
      V v_uses_2460 = heff_get_n(v_a_2458, 1, 2);
      V v_a_2461 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_u_2439));
      V v_binders_2462 = heff_take_field(v_a_2461, 0);
      V v_uses_2463 = heff_get_n(v_a_2461, 1, 2);
      V v_b_2464 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2440));
      V v_binders_2465 = heff_take_field(v_b_2464, 0);
      V v_uses_2466 = heff_get_n(v_b_2464, 1, 2);
      V v_t_2467 = (g_prelude_2e_2b_2b(v_binders_2462, v_binders_2465));
      V v_t_2468 = (g_prelude_2e_2b_2b(v_uses_2463, v_uses_2466));
      V v_t_2469 = (g_prelude_2e_2b_2b(v_binders_2459, v_t_2467));
      V v_t_2470 = (g_prelude_2e_2b_2b(v_uses_2460, v_t_2468));
      V v_t_2471 = (g_prelude_2e_2b_2b(v_binders_2447, v_t_2469));
      V v_t_2472 = (g_prelude_2e_2b_2b(v_uses_2448, v_t_2470));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2471, v_t_2472});
    }
    case TAG_DeclTheory: {
      V v_body_2476 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2476);
    }
    case TAG_DeclPrimitive: {
      V v_x_2477 = heff_field(v_x31_242, 0);
      V v_xsp_2478 = heff_field(v_x31_242, 1);
      V v_t_2479 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_2480 = ({ V a_0 = v_x_2477; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2477); r_; });
      V v_a_2485;
      {
        V v_field_2482 = v_t_2480.f[1];
        int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
        if ((v_tag_2481 == ((int64_t)0ULL))) {
          V v_b_2483 = v_field_2482;
          V v_t_2484 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2483, v_xsp_2478}), NTAG(TAG_Nil)});
          v_a_2485 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2484});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2478);
          heff_drop(v_field_2482);
          v_a_2485 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2486 = heff_take_field(v_a_2485, 0);
      V v_uses_2487 = heff_get_n(v_a_2485, 1, 2);
      V v_b_2488 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2479));
      V v_binders_2489 = heff_take_field(v_b_2488, 0);
      V v_uses_2490 = heff_get_n(v_b_2488, 1, 2);
      V v_t_2491 = (g_prelude_2e_2b_2b(v_binders_2486, v_binders_2489));
      V v_t_2492 = (g_prelude_2e_2b_2b(v_uses_2487, v_uses_2490));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2491, v_t_2492});
    }
    case TAG_DeclTest: {
      V v_x_2493 = heff_field(v_x31_242, 0);
      V v_xsp_2494 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      HeffT2 v_t_2495 = ({ V a_0 = v_x_2493; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2493); r_; });
      {
        V v_field_2497 = v_t_2495.f[1];
        int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
        if ((v_tag_2496 == ((int64_t)0ULL))) {
          V v_b_2498 = v_field_2497;
          V v_t_2499 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2498, v_xsp_2494}), NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2499});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2494);
          heff_drop(v_field_2497);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
    }
    case TAG_DeclWatch: {
      V v_e_24100 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24100);
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_eq_2421 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_2422 = heff_take_field(v_acc_2420, 0);
  V v_uses_2423 = heff_get_n(v_acc_2420, 1, 2);
  HeffT2 v_t_2424 = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(v_env_240, v_eq_2421));
  {
    V v_field_2425 = v_t_2424.f[0];
    V v_field_2426 = v_t_2424.f[1];
    V v_t_2427 = (g_prelude_2e_2b_2b(v_binders_2422, v_field_2425));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_uses_2423, v_field_2426));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2427, v_t_2428});
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args) {
  V v_acc_2449 = args[0];
  V v_m_2450 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_2451 = heff_take_field(v_acc_2449, 0);
  V v_uses_2452 = heff_get_n(v_acc_2449, 1, 2);
  HeffT2 v_t_2453 = (g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(v_env_240, v_m_2450));
  {
    V v_field_2454 = v_t_2453.f[0];
    V v_field_2455 = v_t_2453.f[1];
    V v_t_2456 = (g_prelude_2e_2b_2b(v_binders_2451, v_field_2454));
    V v_t_2457 = (g_prelude_2e_2b_2b(v_uses_2452, v_field_2455));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2456, v_t_2457});
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry, 2, 0};

V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      heff_take_n(v_d1_242, 24ULL, 5);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 0ULL, 2);
        V v_a_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), heff_dup(v_ty_247)));
        V v_binders_2412 = heff_take_field(v_a_2411, 0);
        V v_uses_2413 = heff_get_n(v_a_2411, 1, 2);
        V v_b_2440 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
        V v_binders_2441 = heff_take_field(v_b_2440, 0);
        V v_uses_2442 = heff_get_n(v_b_2440, 1, 2);
        V v_t_2443 = (g_prelude_2e_2b_2b_24tok2(v_ru_24d_241_24At, v_binders_2412, v_binders_2441));
        V v_t_2444 = (g_prelude_2e_2b_2b(v_uses_2413, v_uses_2442));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2443, v_t_2444});
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_d1_242, 0ULL, 5);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_d1_242, 0ULL, 4);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_d1_242, 0ULL, 3);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_d1_242, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_eq_2415 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_binders_2416 = heff_take_field(v_acc_2414, 0);
  V v_uses_2417 = heff_get_n(v_acc_2414, 1, 2);
  V v_a_2429;
  switch (heff_tag_of(v_eq_2415)) {
  case TAG_At: {
    V v_x21_2418 = heff_dup(heff_field(v_eq_2415, 0));
    switch (heff_tag_of(v_x21_2418)) {
    case TAG_MkEquation: {
      V v_f_2420 = heff_field(v_x21_2418, 0);
      V v_fsp_2421 = heff_field(v_x21_2418, 1);
      heff_take_n(v_x21_2418, 3ULL, 4);
      HeffT2 v_t_2424 = ({ V a_0 = v_f_2420; V a_1 = heff_dup(v_env_240); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_2420); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_b_2427 = v_field_2426;
          V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2427, v_fsp_2421}), NTAG(TAG_Nil)});
          v_a_2429 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2428});
        } else {
          heff_drop(v_fsp_2421);
          heff_drop(v_field_2426);
          v_a_2429 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      break;
    }
    default: heff_nomatch(v_x21_2418);
    }
    break;
  }
  default: heff_nomatch(v_eq_2415);
  }
  V v_binders_2430 = heff_take_field(v_a_2429, 0);
  V v_uses_2431 = heff_get_n(v_a_2429, 1, 2);
  V v_t_2432 = (g_list_2efoldl_24f1488358745x465096512(v_env_240, v_ty_247));
  HeffT2 v_t_2433 = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(v_t_2432, v_eq_2415));
  {
    V v_field_2434 = v_t_2433.f[0];
    V v_field_2435 = v_t_2433.f[1];
    V v_t_2436 = (g_prelude_2e_2b_2b(v_binders_2430, v_field_2434));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_uses_2431, v_field_2435));
    V v_t_2438 = (g_prelude_2e_2b_2b(v_binders_2416, v_t_2436));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_uses_2417, v_t_2437));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2438, v_t_2439});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4, 0, "");
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry, 6, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V v_tag_240, V v_env_241, V v_x3_242, V v_body_243, V v_env_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: {
    top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: ;
    heff_drop(v_env_244);
    heff_drop(v_n_245);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
      V t_1 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1);
      V t_3 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2);
      V t_4 = v_env_241;
      V t_5 = v_body_243;
      v_tag_240 = t_0;
      v_env_241 = t_1;
      v_x3_242 = t_2;
      v_body_243 = t_3;
      v_env_244 = t_4;
      v_n_245 = t_5;
      goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
    }
    case TAG_Cons: {
      V v_d_246 = heff_field(v_x3_242, 0);
      V v_ds_247 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2431;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_248 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_248)) {
        case TAG_DeclEquations: {
          V v_f_2410 = heff_field(v_d1_248, 0);
          V v_fsp_2411 = heff_field(v_d1_248, 1);
          heff_take_n(v_d1_248, 3ULL, 5);
          V v_t_2415 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2410, v_fsp_2411, NTAG(TAG_False)});
          v_t_2431 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_248, 0ULL, 5);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_248, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_248, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_248, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_248, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_248);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_241), v_t_2431));
      V v_a_2433 = (g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(v_t_2432, heff_dup(v_d_246)));
      V v_binders_2434 = heff_take_field(v_a_2433, 0);
      V v_uses_2435 = heff_get_n(v_a_2433, 1, 2);
      V v_t_2459;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2436 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_2436)) {
        case TAG_DeclEquations: {
          V v_f_2438 = heff_field(v_d1_2436, 0);
          V v_fsp_2439 = heff_field(v_d1_2436, 1);
          heff_take_n(v_d1_2436, 3ULL, 5);
          V v_t_2443 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2438, v_fsp_2439, NTAG(TAG_False)});
          v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2436, 0ULL, 5);
          v_t_2459 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2436, 0ULL, 4);
          v_t_2459 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2436, 0ULL, 3);
          v_t_2459 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2436, 0ULL, 2);
          v_t_2459 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2436, 0ULL, 1);
          v_t_2459 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2436);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2460 = (g_list_2efoldl_24s1370882877x364361272(v_env_241, v_t_2459));
      V v_b_2461 = (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_t_2460, v_ds_247, v_body_243));
      V v_binders_2462 = heff_take_field(v_b_2461, 0);
      V v_uses_2463 = heff_get_n(v_b_2461, 1, 2);
      V v_t_2464 = (g_prelude_2e_2b_2b(v_binders_2434, v_binders_2462));
      V v_t_2465 = (g_prelude_2e_2b_2b(v_uses_2435, v_uses_2463));
      V v_t_2489;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2466 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24At = heff_take_reuse_n(v_d_246, 1ULL, 2);
        switch (heff_tag_of(v_d1_2466)) {
        case TAG_DeclEquations: {
          V v_f_2468 = heff_field(v_d1_2466, 0);
          V v_fsp_2469 = heff_field(v_d1_2466, 1);
          heff_take_n(v_d1_2466, 3ULL, 5);
          V v_t_2473 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2468, v_fsp_2469, NTAG(TAG_False)});
          v_t_2489 = heff_tag_at_n(v_ru_24d_246_24At, TAG_Cons, 2, (V[]){v_t_2473, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2466, 0ULL, 5);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2489 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2466, 0ULL, 4);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2489 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2466, 0ULL, 3);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2489 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2466, 0ULL, 2);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2489 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2466, 0ULL, 1);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2489 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2466);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2490 = (g_prelude_2e_2b_2b(v_t_2489, v_t_2464));
      V v_t_2491 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2465));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2490, v_t_2491});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: {
    top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: ;
    switch (heff_tag_of(v_n_245)) {
    case TAG_At: {
      V v_n1_2492 = heff_dup(heff_field(v_n_245, 0));
      switch (heff_tag_of(v_n1_2492)) {
      case TAG_EVar: {
        V v_x_2494 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        HeffT2 v_t_2495 = ({ V a_0 = v_x_2494; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2494); r_; });
        {
          V v_field_2497 = v_t_2495.f[1];
          int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
          if ((v_tag_2496 == ((int64_t)0ULL))) {
            V v_b_2498 = v_field_2497;
            V v_t_24101;
            switch (heff_tag_of(v_n_245)) {
            case TAG_At: {
              V v_s_24100 = heff_field(v_n_245, 1);
              heff_take_n(v_n_245, 2ULL, 2);
              v_t_24101 = v_s_24100;
              break;
            }
            default: heff_nomatch(v_n_245);
            }
            V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2498, v_t_24101}), NTAG(TAG_Nil)});
            return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24102});
          } else {
            heff_drop_tag(v_n_245, 2);
            heff_drop(v_field_2497);
            return heff_dup(g_heff_2eelab_2elocals_2enone_get());
          }
        }
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETag: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInt: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFloat: {
        heff_take_na(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EString: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBinary: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ERune: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWord: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EApp: {
        V v_h_24127 = heff_field(v_n1_2492, 0);
        V v_args_24128 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24EApp = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24131 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_h_24127));
          V v_binders_24132 = heff_take_field(v_a_24131, 0);
          V v_uses_24133 = heff_get_n(v_a_24131, 1, 2);
          V v_b_24143 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24128; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24128); r_; });
          V v_binders_24144 = heff_take_field(v_b_24143, 0);
          V v_uses_24145 = heff_get_n(v_b_24143, 1, 2);
          V v_t_24146 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24EApp, v_binders_24132, v_binders_24144));
          V v_t_24147 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24133, v_uses_24145));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24146, v_t_24147});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EProject: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENamed: {
        V v_e_24152 = heff_field(v_n1_2492, 1);
        heff_take_n(v_n1_2492, 2ULL, 2);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24152;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EPi: {
        V v_n11_24155 = heff_field(v_n1_2492, 0);
        V v_r_24156 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24EPi = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24155)) {
          case TAG_PiNamed: {
            V v_x_24159 = heff_field(v_n11_24155, 0);
            V v_sp_24160 = heff_field(v_n11_24155, 1);
            V v_a_24161 = heff_field(v_n11_24155, 2);
            heff_take_n(v_n11_24155, 7ULL, 3);
            V v_a_24162 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24161));
            V v_binders_24163 = heff_take_field(v_a_24162, 0);
            V v_uses_24164 = heff_get_n(v_a_24162, 1, 2);
            V v_t_24165 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24159), heff_dup(v_sp_24160), NTAG(TAG_False)});
            V v_t_24166 = heff_tag_at_n(v_ru_24n1_2492_24EPi, TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
            V v_env_24167 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24166));
            V v_b_24168 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24167, v_r_24156));
            V v_binders_24169 = heff_take_field(v_b_24168, 0);
            V v_uses_24170 = heff_get_n(v_b_24168, 1, 2);
            V v_t_24171 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24159, v_sp_24160, NTAG(TAG_False)});
            V v_t_24172 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24171, NTAG(TAG_Nil)});
            V v_t_24173 = (g_prelude_2e_2b_2b(v_t_24172, v_binders_24169));
            V v_t_24174 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_24170));
            V v_t_24175 = (g_prelude_2e_2b_2b(v_binders_24163, v_t_24173));
            V v_t_24176 = (g_prelude_2e_2b_2b(v_uses_24164, v_t_24174));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24175, v_t_24176});
          }
          case TAG_PiImplicit: {
            V v_x_24177 = heff_field(v_n11_24155, 0);
            V v_sp_24178 = heff_field(v_n11_24155, 1);
            V v_a_24180 = heff_field(v_n11_24155, 3);
            V v_d_24181 = heff_field(v_n11_24155, 4);
            heff_take_n(v_n11_24155, 27ULL, 5);
            V v_a_24182 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24180));
            V v_binders_24183 = heff_take_field(v_a_24182, 0);
            V v_uses_24184 = heff_get_n(v_a_24182, 1, 2);
            V v_b_24186;
            switch (heff_tag_of(v_d_24181)) {
            case TAG_Nothing: {
              v_b_24186 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24185 = heff_field(v_d_24181, 0);
              heff_take_n(v_d_24181, 1ULL, 1);
              v_b_24186 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24185));
              break;
            }
            default: heff_nomatch(v_d_24181);
            }
            V v_binders_24187 = heff_take_field(v_b_24186, 0);
            V v_uses_24188 = heff_get_n(v_b_24186, 1, 2);
            V v_t_24189 = (g_prelude_2e_2b_2b(v_binders_24183, v_binders_24187));
            V v_t_24190 = (g_prelude_2e_2b_2b(v_uses_24184, v_uses_24188));
            V v_t_24191 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24177), heff_dup(v_sp_24178), NTAG(TAG_False)});
            V v_t_24192 = heff_tag_at_n(v_ru_24n1_2492_24EPi, TAG_Cons, 2, (V[]){v_t_24191, NTAG(TAG_Nil)});
            V v_env_24193 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24192));
            V v_b_24194 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24193, v_r_24156));
            V v_binders_24195 = heff_take_field(v_b_24194, 0);
            V v_uses_24196 = heff_get_n(v_b_24194, 1, 2);
            V v_t_24197 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24177, v_sp_24178, NTAG(TAG_False)});
            V v_t_24198 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24197, NTAG(TAG_Nil)});
            V v_t_24199 = (g_prelude_2e_2b_2b(v_t_24198, v_binders_24195));
            V v_t_24200 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_24196));
            V v_t_24201 = (g_prelude_2e_2b_2b(v_t_24189, v_t_24199));
            V v_t_24202 = (g_prelude_2e_2b_2b(v_t_24190, v_t_24200));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24201, v_t_24202});
          }
          case TAG_PiInstance: {
            V v_x_24203 = heff_field(v_n11_24155, 0);
            V v_sp_24204 = heff_field(v_n11_24155, 1);
            V v_a_24206 = heff_field(v_n11_24155, 3);
            heff_take_n(v_n11_24155, 11ULL, 4);
            V v_a_24207 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24206));
            V v_binders_24208 = heff_take_field(v_a_24207, 0);
            V v_uses_24209 = heff_get_n(v_a_24207, 1, 2);
            V v_t_24210 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24203), heff_dup(v_sp_24204), NTAG(TAG_False)});
            V v_t_24211 = heff_tag_at_n(v_ru_24n1_2492_24EPi, TAG_Cons, 2, (V[]){v_t_24210, NTAG(TAG_Nil)});
            V v_env_24212 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24211));
            V v_b_24213 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24212, v_r_24156));
            V v_binders_24214 = heff_take_field(v_b_24213, 0);
            V v_uses_24215 = heff_get_n(v_b_24213, 1, 2);
            V v_t_24216 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24203, v_sp_24204, NTAG(TAG_False)});
            V v_t_24217 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24216, NTAG(TAG_Nil)});
            V v_t_24218 = (g_prelude_2e_2b_2b(v_t_24217, v_binders_24214));
            V v_t_24219 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_24215));
            V v_t_24220 = (g_prelude_2e_2b_2b(v_binders_24208, v_t_24218));
            V v_t_24221 = (g_prelude_2e_2b_2b(v_uses_24209, v_t_24219));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24220, v_t_24221});
          }
          case TAG_PiAnon: {
            V v_a_24222 = heff_field(v_n11_24155, 0);
            heff_take_n(v_n11_24155, 1ULL, 1);
            V v_a_24223 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24222));
            V v_binders_24224 = heff_take_field(v_a_24223, 0);
            V v_uses_24225 = heff_get_n(v_a_24223, 1, 2);
            V v_b_24226 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_r_24156));
            V v_binders_24227 = heff_take_field(v_b_24226, 0);
            V v_uses_24228 = heff_get_n(v_b_24226, 1, 2);
            V v_t_24229 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24EPi, v_binders_24224, v_binders_24227));
            V v_t_24230 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24225, v_uses_24228));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24229, v_t_24230});
          }
          default: return heff_nomatch(v_n11_24155);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELam: {
        V v_n11_24231 = heff_field(v_n1_2492, 0);
        V v_r_24232 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24ELam = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24231)) {
          case TAG_LamName: {
            V v_bs_24237 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24231));
            V v_env_24238 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24237)));
            V v_b_24239 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24238, v_r_24232));
            V v_binders_24240 = heff_take_field(v_b_24239, 0);
            V v_uses_24241 = heff_get_n(v_b_24239, 1, 2);
            V v_t_24242 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24ELam, v_bs_24237, v_binders_24240));
            V v_t_24243 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, NTAG(TAG_Nil), v_uses_24241));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24242, v_t_24243});
          }
          case TAG_LamImplicit: {
            V v_bs_24246 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24231));
            V v_env_24247 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24246)));
            V v_b_24248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24247, v_r_24232));
            V v_binders_24249 = heff_take_field(v_b_24248, 0);
            V v_uses_24250 = heff_get_n(v_b_24248, 1, 2);
            V v_t_24251 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24ELam, v_bs_24246, v_binders_24249));
            V v_t_24252 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, NTAG(TAG_Nil), v_uses_24250));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24251, v_t_24252});
          }
          case TAG_LamAnn: {
            V v_x_24253 = heff_field(v_n11_24231, 0);
            V v_sp_24254 = heff_field(v_n11_24231, 1);
            V v_a_24255 = heff_field(v_n11_24231, 2);
            heff_take_n(v_n11_24231, 7ULL, 3);
            V v_a_24256 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24255));
            V v_binders_24257 = heff_take_field(v_a_24256, 0);
            V v_uses_24258 = heff_get_n(v_a_24256, 1, 2);
            V v_t_24259 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24253), heff_dup(v_sp_24254), NTAG(TAG_False)});
            V v_t_24260 = heff_tag_at_n(v_ru_24n1_2492_24ELam, TAG_Cons, 2, (V[]){v_t_24259, NTAG(TAG_Nil)});
            V v_env_24261 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24260));
            V v_b_24262 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24261, v_r_24232));
            V v_binders_24263 = heff_take_field(v_b_24262, 0);
            V v_uses_24264 = heff_get_n(v_b_24262, 1, 2);
            V v_t_24265 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24253, v_sp_24254, NTAG(TAG_False)});
            V v_t_24266 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24265, NTAG(TAG_Nil)});
            V v_t_24267 = (g_prelude_2e_2b_2b(v_t_24266, v_binders_24263));
            V v_t_24268 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_24264));
            V v_t_24269 = (g_prelude_2e_2b_2b(v_binders_24257, v_t_24267));
            V v_t_24270 = (g_prelude_2e_2b_2b(v_uses_24258, v_t_24268));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24269, v_t_24270});
          }
          default: return heff_nomatch(v_n11_24231);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAnn: {
        V v_e_24271 = heff_field(v_n1_2492, 0);
        V v_t_24272 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24EAnn = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24275 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24271));
          V v_binders_24276 = heff_take_field(v_a_24275, 0);
          V v_uses_24277 = heff_get_n(v_a_24275, 1, 2);
          V v_b_24278 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_t_24272));
          V v_binders_24279 = heff_take_field(v_b_24278, 0);
          V v_uses_24280 = heff_get_n(v_b_24278, 1, 2);
          V v_t_24281 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24EAnn, v_binders_24276, v_binders_24279));
          V v_t_24282 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24277, v_uses_24280));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24281, v_t_24282});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESpec: {
        V v_acc_24283 = heff_field(v_n1_2492, 0);
        V v_v_24286 = heff_field(v_n1_2492, 3);
        heff_take_n(v_n1_2492, 9ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24289 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_acc_24283));
          V v_binders_24290 = heff_take_field(v_a_24289, 0);
          V v_uses_24291 = heff_get_n(v_a_24289, 1, 2);
          V v_b_24292 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_v_24286));
          V v_binders_24293 = heff_take_field(v_b_24292, 0);
          V v_uses_24294 = heff_get_n(v_b_24292, 1, 2);
          V v_t_24295 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24290, v_binders_24293));
          V v_t_24296 = (g_prelude_2e_2b_2b(v_uses_24291, v_uses_24294));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24295, v_t_24296});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESig: {
        V v_fs_24297 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_244, v_fs_24297));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESum: {
        V v_vs_24300 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_vs_24300; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24300); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EStruct: {
        V v_fs_24327 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_fs_24327; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24327); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EUpdate: {
        V v_a_24345 = heff_field(v_n1_2492, 0);
        V v_fs_24346 = heff_field(v_n1_2492, 1);
        heff_take_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V v_t_24349 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24345));
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4, 2, 1, (V[]){v_env_244}); V a_1 = v_t_24349; V a_2 = v_fs_24346; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24346); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EMatch: {
        V v_s_24363 = heff_field(v_n1_2492, 0);
        V v_alts_24364 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24EMatch = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24367 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_s_24363));
          V v_binders_24368 = heff_take_field(v_a_24367, 0);
          V v_uses_24369 = heff_get_n(v_a_24367, 1, 2);
          V v_b_24390 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_alts_24364; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24364); r_; });
          V v_binders_24391 = heff_take_field(v_b_24390, 0);
          V v_uses_24392 = heff_get_n(v_b_24390, 1, 2);
          V v_t_24393 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24EMatch, v_binders_24368, v_binders_24391));
          V v_t_24394 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24369, v_uses_24392));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24393, v_t_24394});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELetIn: {
        V v_rhs_24395 = heff_field(v_n1_2492, 0);
        V v_a_24396 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24ELetIn = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24399 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_rhs_24395));
          V v_binders_24400 = heff_take_field(v_a_24399, 0);
          V v_uses_24401 = heff_get_n(v_a_24399, 1, 2);
          V v_b_24413;
          switch (heff_tag_of(v_a_24396)) {
          case TAG_At: {
            V v_x31_24402 = heff_field(v_a_24396, 0);
            V v_ru_24a_24396_24At = heff_take_reuse_n(v_a_24396, 1ULL, 2);
            switch (heff_tag_of(v_x31_24402)) {
            case TAG_MkAlt: {
              V v_p_24404 = heff_field(v_x31_24402, 0);
              V v_r_24405 = heff_field(v_x31_24402, 1);
              heff_take_n(v_x31_24402, 3ULL, 2);
              V v_bs_24406 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n1_2492_24ELetIn, v_p_24404));
              V v_env_24407 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24406)));
              V v_b_24408 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24407, v_r_24405));
              V v_binders_24409 = heff_take_field(v_b_24408, 0);
              V v_uses_24410 = heff_get_n(v_b_24408, 1, 2);
              V v_t_24411 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_bs_24406, v_binders_24409));
              V v_t_24412 = (g_prelude_2e_2b_2b_24tok2(v_ru_24a_24396_24At, NTAG(TAG_Nil), v_uses_24410));
              v_b_24413 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24411, v_t_24412});
              break;
            }
            default: heff_nomatch(v_x31_24402);
            }
            break;
          }
          default: heff_nomatch(v_a_24396);
          }
          V v_binders_24414 = heff_take_field(v_b_24413, 0);
          V v_uses_24415 = heff_get_n(v_b_24413, 1, 2);
          V v_t_24416 = (g_prelude_2e_2b_2b(v_binders_24400, v_binders_24414));
          V v_t_24417 = (g_prelude_2e_2b_2b(v_uses_24401, v_uses_24415));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24416, v_t_24417});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EDo: {
        V v_stmts_24418 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_stmts_24418));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELocal: {
        V v_body_24421 = heff_field(v_n1_2492, 0);
        V v_defs_24422 = heff_field(v_n1_2492, 1);
        heff_take_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361);
          V t_1 = v_env_244;
          V t_2 = v_defs_24422;
          V t_3 = v_body_24421;
          V t_4 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3);
          V t_5 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4);
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInvalid: {
        heff_take_n(v_n1_2492, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAssign: {
        V v_x_24428 = heff_field(v_n1_2492, 0);
        V v_xsp_24429 = heff_field(v_n1_2492, 1);
        V v_e_24430 = heff_field(v_n1_2492, 2);
        heff_take_n(v_n1_2492, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          HeffT2 v_t_24433 = ({ V a_0 = v_x_24428; V a_1 = heff_dup(v_env_244); HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24428); r_; });
          V v_a_24438;
          {
            V v_field_24435 = v_t_24433.f[1];
            int64_t v_tag_24434 = ((int64_t)v_t_24433.f[0]);
            if ((v_tag_24434 == ((int64_t)0ULL))) {
              V v_b_24436 = v_field_24435;
              V v_t_24437 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24436, v_xsp_24429}), NTAG(TAG_Nil)});
              v_a_24438 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24437});
            } else {
              heff_drop(v_xsp_24429);
              heff_drop_cell(v_ru_24n_245_24At, 2);
              heff_drop(v_field_24435);
              v_a_24438 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            }
          }
          V v_binders_24439 = heff_take_field(v_a_24438, 0);
          V v_uses_24440 = heff_get_n(v_a_24438, 1, 2);
          V v_b_24441 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24430));
          V v_binders_24442 = heff_take_field(v_b_24441, 0);
          V v_uses_24443 = heff_get_n(v_b_24441, 1, 2);
          V v_t_24444 = (g_prelude_2e_2b_2b(v_binders_24439, v_binders_24442));
          V v_t_24445 = (g_prelude_2e_2b_2b(v_uses_24440, v_uses_24443));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24444, v_t_24445});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWhile: {
        V v_c_24446 = heff_field(v_n1_2492, 0);
        V v_body_24447 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24EWhile = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24450 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24446));
          V v_binders_24451 = heff_take_field(v_a_24450, 0);
          V v_uses_24452 = heff_get_n(v_a_24450, 1, 2);
          V v_b_24453 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_body_24447));
          V v_binders_24454 = heff_take_field(v_b_24453, 0);
          V v_uses_24455 = heff_get_n(v_b_24453, 1, 2);
          V v_t_24456 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24EWhile, v_binders_24451, v_binders_24454));
          V v_t_24457 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24452, v_uses_24455));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24456, v_t_24457});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFor: {
        V v_p_24458 = heff_field(v_n1_2492, 0);
        V v_c_24459 = heff_field(v_n1_2492, 1);
        V v_body_24460 = heff_field(v_n1_2492, 2);
        heff_take_n(v_n1_2492, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24463 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24459));
          V v_binders_24464 = heff_take_field(v_a_24463, 0);
          V v_uses_24465 = heff_get_n(v_a_24463, 1, 2);
          V v_bs_24466 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n_245_24At, heff_dup(v_p_24458)));
          V v_env_24467 = (g_list_2efoldl_24f1677743806x2032371213(v_env_244, v_p_24458));
          V v_b_24468 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24467, v_body_24460));
          V v_binders_24469 = heff_take_field(v_b_24468, 0);
          V v_uses_24470 = heff_get_n(v_b_24468, 1, 2);
          V v_t_24471 = (g_prelude_2e_2b_2b(v_bs_24466, v_binders_24469));
          V v_t_24472 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_24470));
          V v_t_24473 = (g_prelude_2e_2b_2b(v_binders_24464, v_t_24471));
          V v_t_24474 = (g_prelude_2e_2b_2b(v_uses_24465, v_t_24472));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24473, v_t_24474});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EIfThen: {
        V v_c_24475 = heff_field(v_n1_2492, 0);
        V v_a_24476 = heff_field(v_n1_2492, 1);
        V v_ru_24n1_2492_24EIfThen = heff_take_reuse_n(v_n1_2492, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24479 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24475));
          V v_binders_24480 = heff_take_field(v_a_24479, 0);
          V v_uses_24481 = heff_get_n(v_a_24479, 1, 2);
          V v_b_24482 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24476));
          V v_binders_24483 = heff_take_field(v_b_24482, 0);
          V v_uses_24484 = heff_get_n(v_b_24482, 1, 2);
          V v_t_24485 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2492_24EIfThen, v_binders_24480, v_binders_24483));
          V v_t_24486 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24481, v_uses_24484));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24485, v_t_24486});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBreak: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EContinue: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EReturn: {
        V v_e_24491 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24491;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENest: {
        V v_e_24494 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24494;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELazy: {
        V v_e_24497 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24497;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETuple: {
        V v_es_24500 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_es_24500; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_24500); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETry: {
        V v_n11_24512 = heff_field(v_n1_2492, 0);
        heff_take_n(v_n1_2492, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24512)) {
          case TAG_MkTry: {
            V v_ty_24515 = heff_field(v_n11_24512, 0);
            V v_body_24516 = heff_field(v_n11_24512, 1);
            V v_c_24517 = heff_field(v_n11_24512, 2);
            heff_take_n(v_n11_24512, 7ULL, 3);
            V v_a_24519;
            switch (heff_tag_of(v_ty_24515)) {
            case TAG_Nothing: {
              v_a_24519 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24518 = heff_field(v_ty_24515, 0);
              heff_take_n(v_ty_24515, 1ULL, 1);
              v_a_24519 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24518));
              break;
            }
            default: heff_nomatch(v_ty_24515);
            }
            V v_binders_24520 = heff_take_field(v_a_24519, 0);
            V v_uses_24521 = heff_get_n(v_a_24519, 1, 2);
            V v_b_24522 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_244), v_body_24516));
            V v_binders_24523 = heff_take_field(v_b_24522, 0);
            V v_uses_24524 = heff_get_n(v_b_24522, 1, 2);
            V v_t_24525 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24520, v_binders_24523));
            V v_t_24526 = (g_prelude_2e_2b_2b(v_uses_24521, v_uses_24524));
            HeffT2 v_t_24527 = (g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(v_env_244, v_c_24517));
            {
              V v_field_24528 = v_t_24527.f[0];
              V v_field_24529 = v_t_24527.f[1];
              V v_t_24530 = (g_prelude_2e_2b_2b(v_t_24525, v_field_24528));
              V v_t_24531 = (g_prelude_2e_2b_2b(v_t_24526, v_field_24529));
              return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24530, v_t_24531});
            }
          }
          default: return heff_nomatch(v_n11_24512);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWith: {
        V v_e_24532 = heff_field(v_n1_2492, 0);
        V v_x_24533 = heff_field(v_n1_2492, 1);
        V v_xsp_24534 = heff_field(v_n1_2492, 2);
        V v_body_24535 = heff_field(v_n1_2492, 3);
        heff_take_n(v_n1_2492, 15ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24538 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24532));
          V v_binders_24539 = heff_take_field(v_a_24538, 0);
          V v_uses_24540 = heff_get_n(v_a_24538, 1, 2);
          V v_t_24541 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24533), heff_dup(v_xsp_24534), NTAG(TAG_False)});
          V v_t_24542 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24541, NTAG(TAG_Nil)});
          V v_env_24543 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, v_t_24542));
          V v_b_24544 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24543, v_body_24535));
          V v_binders_24545 = heff_take_field(v_b_24544, 0);
          V v_uses_24546 = heff_get_n(v_b_24544, 1, 2);
          V v_t_24547 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24533, v_xsp_24534, NTAG(TAG_False)});
          V v_t_24548 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24547, NTAG(TAG_Nil)});
          V v_t_24549 = (g_prelude_2e_2b_2b(v_t_24548, v_binders_24545));
          V v_t_24550 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_24546));
          V v_t_24551 = (g_prelude_2e_2b_2b(v_binders_24539, v_t_24549));
          V v_t_24552 = (g_prelude_2e_2b_2b(v_uses_24540, v_t_24550));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24551, v_t_24552});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      default: return heff_nomatch(v_n1_2492);
      }
    }
    default: return heff_nomatch(v_n_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args) {
  V v_acc_24134 = args[0];
  V v_x_24135 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24136 = heff_take_field(v_acc_24134, 0);
  V v_uses_24137 = heff_get_n(v_acc_24134, 1, 2);
  V v_b_24138 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24135));
  V v_binders_24139 = heff_take_field(v_b_24138, 0);
  V v_uses_24140 = heff_get_n(v_b_24138, 1, 2);
  V v_t_24141 = (g_prelude_2e_2b_2b(v_binders_24136, v_binders_24139));
  V v_t_24142 = (g_prelude_2e_2b_2b(v_uses_24137, v_uses_24140));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24141, v_t_24142});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args) {
  V v_acc_24312 = args[0];
  V v_x_24313 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24314 = heff_take_field(v_acc_24312, 0);
  V v_uses_24315 = heff_get_n(v_acc_24312, 1, 2);
  V v_b_24316 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24313));
  V v_binders_24317 = heff_take_field(v_b_24316, 0);
  V v_uses_24318 = heff_get_n(v_b_24316, 1, 2);
  V v_t_24319 = (g_prelude_2e_2b_2b(v_binders_24314, v_binders_24317));
  V v_t_24320 = (g_prelude_2e_2b_2b(v_uses_24315, v_uses_24318));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24319, v_t_24320});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args) {
  V v_acc_24303 = args[0];
  V v_v_24304 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24305 = heff_take_field(v_acc_24303, 0);
  V v_uses_24306 = heff_get_n(v_acc_24303, 1, 2);
  V v_b_24322;
  switch (heff_tag_of(v_v_24304)) {
  case TAG_At: {
    V v_it1_24307 = heff_field(v_v_24304, 0);
    heff_take_n(v_v_24304, 1ULL, 2);
    switch (heff_tag_of(v_it1_24307)) {
    case TAG_TagVariant: {
      V v_args_24311 = heff_field(v_it1_24307, 2);
      heff_take_n(v_it1_24307, 4ULL, 3);
      v_b_24322 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24311; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24311); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24321 = heff_field(v_it1_24307, 0);
      heff_take_n(v_it1_24307, 1ULL, 1);
      v_b_24322 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24321));
      break;
    }
    default: heff_nomatch(v_it1_24307);
    }
    break;
  }
  default: heff_nomatch(v_v_24304);
  }
  V v_binders_24323 = heff_take_field(v_b_24322, 0);
  V v_uses_24324 = heff_get_n(v_b_24322, 1, 2);
  V v_t_24325 = (g_prelude_2e_2b_2b(v_binders_24305, v_binders_24323));
  V v_t_24326 = (g_prelude_2e_2b_2b(v_uses_24306, v_uses_24324));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24325, v_t_24326});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args) {
  V v_acc_24330 = args[0];
  V v_f_24331 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24332 = heff_take_field(v_acc_24330, 0);
  V v_uses_24333 = heff_get_n(v_acc_24330, 1, 2);
  V v_b_24340;
  switch (heff_tag_of(v_f_24331)) {
  case TAG_At: {
    V v_x31_24334 = heff_field(v_f_24331, 0);
    heff_take_n(v_f_24331, 1ULL, 2);
    switch (heff_tag_of(v_x31_24334)) {
    case TAG_SetField: {
      V v_e_24338 = heff_field(v_x31_24334, 2);
      heff_take_n(v_x31_24334, 4ULL, 3);
      v_b_24340 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24338));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24339 = heff_field(v_x31_24334, 0);
      heff_take_n(v_x31_24334, 1ULL, 1);
      v_b_24340 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24339));
      break;
    }
    default: heff_nomatch(v_x31_24334);
    }
    break;
  }
  default: heff_nomatch(v_f_24331);
  }
  V v_binders_24341 = heff_take_field(v_b_24340, 0);
  V v_uses_24342 = heff_get_n(v_b_24340, 1, 2);
  V v_t_24343 = (g_prelude_2e_2b_2b(v_binders_24332, v_binders_24341));
  V v_t_24344 = (g_prelude_2e_2b_2b(v_uses_24333, v_uses_24342));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24343, v_t_24344});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args) {
  V v_acc_24350 = args[0];
  V v_f_24351 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24352 = heff_take_field(v_acc_24350, 0);
  V v_uses_24353 = heff_get_n(v_acc_24350, 1, 2);
  switch (heff_tag_of(v_f_24351)) {
  case TAG_At: {
    V v_it1_24354 = heff_field(v_f_24351, 0);
    V v_ru_24f_24351_24At = heff_take_reuse_n(v_f_24351, 1ULL, 2);
    switch (heff_tag_of(v_it1_24354)) {
    case TAG_SetPath: {
      V v_e_24357 = heff_field(v_it1_24354, 1);
      V v_ru_24it1_24354_24SetPath = heff_take_reuse_n(v_it1_24354, 2ULL, 2);
      V v_b_24358 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24357));
      V v_binders_24359 = heff_take_field(v_b_24358, 0);
      V v_uses_24360 = heff_get_n(v_b_24358, 1, 2);
      V v_t_24361 = (g_prelude_2e_2b_2b_24tok2(v_ru_24f_24351_24At, v_binders_24352, v_binders_24359));
      V v_t_24362 = (g_prelude_2e_2b_2b_24tok2(v_ru_24it1_24354_24SetPath, v_uses_24353, v_uses_24360));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24361, v_t_24362});
    }
    default: return heff_nomatch(v_it1_24354);
    }
  }
  default: return heff_nomatch(v_f_24351);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args) {
  V v_acc_24370 = args[0];
  V v_a_24371 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24372 = heff_take_field(v_acc_24370, 0);
  V v_uses_24373 = heff_get_n(v_acc_24370, 1, 2);
  V v_b_24385;
  switch (heff_tag_of(v_a_24371)) {
  case TAG_At: {
    V v_x31_24374 = heff_field(v_a_24371, 0);
    V v_ru_24a_24371_24At = heff_take_reuse_n(v_a_24371, 1ULL, 2);
    switch (heff_tag_of(v_x31_24374)) {
    case TAG_MkAlt: {
      V v_p_24376 = heff_field(v_x31_24374, 0);
      V v_r_24377 = heff_field(v_x31_24374, 1);
      V v_ru_24x31_24374_24MkAlt = heff_take_reuse_n(v_x31_24374, 3ULL, 2);
      V v_bs_24378 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24a_24371_24At, v_p_24376));
      V v_env_24379 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24378)));
      V v_b_24380 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24379, v_r_24377));
      V v_binders_24381 = heff_take_field(v_b_24380, 0);
      V v_uses_24382 = heff_get_n(v_b_24380, 1, 2);
      V v_t_24383 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_24374_24MkAlt, v_bs_24378, v_binders_24381));
      V v_t_24384 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_24382));
      v_b_24385 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24383, v_t_24384});
      break;
    }
    default: heff_nomatch(v_x31_24374);
    }
    break;
  }
  default: heff_nomatch(v_a_24371);
  }
  V v_binders_24386 = heff_take_field(v_b_24385, 0);
  V v_uses_24387 = heff_get_n(v_b_24385, 1, 2);
  V v_t_24388 = (g_prelude_2e_2b_2b(v_binders_24372, v_binders_24386));
  V v_t_24389 = (g_prelude_2e_2b_2b(v_uses_24373, v_uses_24387));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24388, v_t_24389});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args) {
  V v_acc_24503 = args[0];
  V v_x_24504 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24505 = heff_take_field(v_acc_24503, 0);
  V v_uses_24506 = heff_get_n(v_acc_24503, 1, 2);
  V v_b_24507 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24504));
  V v_binders_24508 = heff_take_field(v_b_24507, 0);
  V v_uses_24509 = heff_get_n(v_b_24507, 1, 2);
  V v_t_24510 = (g_prelude_2e_2b_2b(v_binders_24505, v_binders_24508));
  V v_t_24511 = (g_prelude_2e_2b_2b(v_uses_24506, v_uses_24509));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24510, v_t_24511});
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1, 0, "");
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry, 3, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361), v_env_240, v_x3_241, v_body_242, ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0), ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1)));
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkCatchArm: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ss_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkCatchArm = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_LamName: {
      V v_bs_246 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_247 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_248 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_247));
      V v_b_249 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_248, v_ss_243));
      V v_binders_2410 = heff_take_field(v_b_249, 0);
      V v_uses_2411 = heff_get_n(v_b_249, 1, 2);
      V v_f_2412 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_246, v_binders_2410));
      V v_f_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2411));
      return ((HeffT2){{v_f_2412, v_f_2413}});
    }
    case TAG_LamImplicit: {
      V v_bs_2416 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_2417 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_2418 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2417));
      V v_b_2419 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2418, v_ss_243));
      V v_binders_2420 = heff_take_field(v_b_2419, 0);
      V v_uses_2421 = heff_get_n(v_b_2419, 1, 2);
      V v_f_2422 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_2416, v_binders_2420));
      V v_f_2423 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2421));
      return ((HeffT2){{v_f_2422, v_f_2423}});
    }
    case TAG_LamAnn: {
      V v_x_2424 = heff_field(v_x31_242, 0);
      V v_sp_2425 = heff_field(v_x31_242, 1);
      V v_t_2426 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_a_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2426));
      V v_binders_2428 = heff_take_field(v_a_2427, 0);
      V v_uses_2429 = heff_get_n(v_a_2427, 1, 2);
      V v_t_2430 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2424), heff_dup(v_sp_2425), NTAG(TAG_False)});
      V v_t_2431 = heff_tag_at_n(v_ru_24x3_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      V v_env_2432 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2431));
      V v_b_2433 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2432, v_ss_243));
      V v_binders_2434 = heff_take_field(v_b_2433, 0);
      V v_uses_2435 = heff_get_n(v_b_2433, 1, 2);
      V v_t_2436 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2424, v_sp_2425, NTAG(TAG_False)});
      V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2437, v_binders_2434));
      V v_t_2439 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2435));
      V v_f_2440 = (g_prelude_2e_2b_2b(v_binders_2428, v_t_2438));
      V v_f_2441 = (g_prelude_2e_2b_2b(v_uses_2429, v_t_2439));
      return ((HeffT2){{v_f_2440, v_f_2441}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2, 0, "");
Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry, 2, 0};

V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V v_env_240, V v_n_241) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2), v_env_240, v_n_241));
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2earguments_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_entry, 3, 0};

V g_heff_2eelab_2elocals_2earguments(V v_env_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2eelab_2elocals_2earguments_lam0, 2, 1, (V[]){v_env_240}), heff_dup(g_heff_2eelab_2elocals_2enone_get()), v_rest_242);
  }
  case TAG_Cons: {
    V v_x21_2412 = heff_field(v_x2_241, 0);
    V v_tl_2413 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_At: {
      V v_x211_2414 = heff_field(v_x21_2412, 0);
      V v_ru_24x21_2412_24At = heff_take_reuse_n(v_x21_2412, 1ULL, 2);
      switch (heff_tag_of(v_x211_2414)) {
      case TAG_ExplicitParam: {
        V v_x_2416 = heff_field(v_x211_2414, 0);
        V v_sp_2417 = heff_field(v_x211_2414, 1);
        V v_t_2418 = heff_field(v_x211_2414, 2);
        heff_take_n(v_x211_2414, 7ULL, 3);
        V v_a_2419 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2418));
        V v_binders_2420 = heff_take_field(v_a_2419, 0);
        V v_uses_2421 = heff_get_n(v_a_2419, 1, 2);
        V v_t_2422 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2416), heff_dup(v_sp_2417), NTAG(TAG_False)});
        V v_b_2423 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2422, v_env_240}), v_tl_2413, v_rest_242));
        V v_binders_2424 = heff_take_field(v_b_2423, 0);
        V v_uses_2425 = heff_get_n(v_b_2423, 1, 2);
        V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2416, v_sp_2417, NTAG(TAG_False)});
        V v_t_2427 = heff_tag_at_n(v_ru_24x21_2412_24At, TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
        V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_binders_2424));
        V v_t_2429 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2425));
        V v_t_2430 = (g_prelude_2e_2b_2b(v_binders_2420, v_t_2428));
        V v_t_2431 = (g_prelude_2e_2b_2b(v_uses_2421, v_t_2429));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2430, v_t_2431});
      }
      case TAG_ImplicitParam: {
        V v_x_2432 = heff_field(v_x211_2414, 0);
        V v_sp_2433 = heff_field(v_x211_2414, 1);
        V v_t_2434 = heff_field(v_x211_2414, 2);
        heff_take_n(v_x211_2414, 7ULL, 3);
        V v_a_2435 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2434));
        V v_binders_2436 = heff_take_field(v_a_2435, 0);
        V v_uses_2437 = heff_get_n(v_a_2435, 1, 2);
        V v_t_2438 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2432), heff_dup(v_sp_2433), NTAG(TAG_False)});
        V v_b_2439 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2438, v_env_240}), v_tl_2413, v_rest_242));
        V v_binders_2440 = heff_take_field(v_b_2439, 0);
        V v_uses_2441 = heff_get_n(v_b_2439, 1, 2);
        V v_t_2442 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2432, v_sp_2433, NTAG(TAG_False)});
        V v_t_2443 = heff_tag_at_n(v_ru_24x21_2412_24At, TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
        V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2443, v_binders_2440));
        V v_t_2445 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2441));
        V v_t_2446 = (g_prelude_2e_2b_2b(v_binders_2436, v_t_2444));
        V v_t_2447 = (g_prelude_2e_2b_2b(v_uses_2437, v_t_2445));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2446, v_t_2447});
      }
      default: return heff_nomatch(v_x211_2414);
      }
    }
    default: return heff_nomatch(v_x21_2412);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2elocals_2earguments(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_245 = heff_take_field(v_acc_243, 0);
  V v_uses_246 = heff_get_n(v_acc_243, 1, 2);
  V v_b_247 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_244));
  V v_binders_248 = heff_take_field(v_b_247, 0);
  V v_uses_249 = heff_get_n(v_b_247, 1, 2);
  V v_t_2410 = (g_prelude_2e_2b_2b(v_binders_245, v_binders_248));
  V v_t_2411 = (g_prelude_2e_2b_2b(v_uses_246, v_uses_249));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2410, v_t_2411});
}

HeffT2 g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 12ULL, 4);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, v_rhs_247));
      V v_binders_2412 = heff_take_field(v_b_2411, 0);
      V v_uses_2413 = heff_get_n(v_b_2411, 1, 2);
      V v_f_2414 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24At, v_bs_249, v_binders_2412));
      V v_f_2415 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_uses_2413));
      return ((HeffT2){{v_f_2414, v_f_2415}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclaration_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclaration_entry, 1, 0};

V g_heff_2eelab_2elocals_2edeclaration(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_eqs_247 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 24ULL, 5);
      V v_a_248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_ty_246)));
      V v_binders_249 = heff_take_field(v_a_248, 0);
      V v_uses_2410 = heff_get_n(v_a_248, 1, 2);
      V v_b_2421 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclaration_lam0, 2, 1, (V[]){v_ty_246}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_247); r_; });
      V v_binders_2422 = heff_take_field(v_b_2421, 0);
      V v_uses_2423 = heff_get_n(v_b_2421, 1, 2);
      V v_t_2424 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_240_24At, v_binders_249, v_binders_2422));
      V v_t_2425 = (g_prelude_2e_2b_2b(v_uses_2410, v_uses_2423));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2424, v_t_2425});
    }
    case TAG_DeclDefine: {
      V v_ps_2428 = heff_field(v_x11_241, 2);
      V v_ty_2429 = heff_field(v_x11_241, 3);
      V v_body_2430 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 28ULL, 5);
      V v_t_2431 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2430, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2428; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_ty_2429, v_t_2431}); V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    }
    case TAG_DeclTheory: {
      V v_ps_2434 = heff_field(v_x11_241, 2);
      V v_body_2435 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 12ULL, 4);
      V v_t_2436 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2435, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2434; V a_2 = v_t_2436; V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, a_2)); heff_drop_tag(v_t_2436, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      V v_t_2439 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_t_2439));
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_DeclWatch: {
      V v_e_2442 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_e_2442));
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclaration(a[0]);
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_eq_2412 = args[1];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_2413 = heff_take_field(v_acc_2411, 0);
  V v_uses_2414 = heff_get_n(v_acc_2411, 1, 2);
  V v_t_2415 = (g_list_2efoldl_24f1488358745x465096512(NTAG(TAG_Nil), v_ty_246));
  HeffT2 v_t_2416 = (g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_24cpr(v_t_2415, v_eq_2412));
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2418 = v_t_2416.f[1];
    V v_t_2419 = (g_prelude_2e_2b_2b(v_binders_2413, v_field_2417));
    V v_t_2420 = (g_prelude_2e_2b_2b(v_uses_2414, v_field_2418));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2419, v_t_2420});
  }
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V v_found_240) {
top: ;
  V v_uses_241 = heff_take_field(v_found_240, 1);
  V v_binders_242 = heff_get_n(v_found_240, 0, 2);
  V v_t_243 = (g_list_2ekeepIf_24s1266148589x1647110933(v_binders_242));
  V v_f_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_uses_241)}), v_t_243));
  V v_f_247 = (g_list_2emap_24f565269645x1954016017(v_uses_241));
  return ((HeffT2){{v_f_246, v_f_247}});
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args) {
  V v_b_244 = args[0];
  V v_uses_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_list_2emap_24f1213328022x1811586494(heff_dup(v_b_244), v_uses_241));
  return heff_rec_n(3, shape_name__binder__uses, (V[]){heff_dup(heff_rfield(v_b_244, 0)), heff_get_n(v_b_244, 1, 3), v_t_245});
}
Clo g_heff_2eelab_2elocals_2elocalsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsOf_entry, 1, 0};

V g_heff_2eelab_2elocals_2elocalsOf(V v_found_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_found_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_locals__fields, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsOf(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V v_tok_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_p2_243 = heff_field(v_p_241, 1);
    heff_take_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0), 2)) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_p2_243);
        heff_drop(v_x_244);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2420));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_242, 0);
      V v_sp_2424 = heff_field(v_p1_242, 1);
      V v_q_2425 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
      V v_cell_2427 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2425, heff_dup(v_cell_2427)));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24tok2(a[0], a[1]);
}