// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361 38668
#define TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481 14273
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo;
HeffT2 g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V, V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo;
HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo;
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V, V);
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo;
HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V, V);
V g_heff_2eelab_2elocals_2elamBinders(V);
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elamBinders_clo;
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V, V);
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V, V, V, V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24dps(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo;
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V, V);
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo;
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2ekeepIf_24s1266148589x1647110933(V);
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1213328022x1811586494(V, V);
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_clo;
V g_list_2emap_24f565269645x1954016017(V);
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;

static V g_heff_2eelab_2elocals_2enone_val;
static HEFF_ONCE g_heff_2eelab_2elocals_2enone_st;
static V g_heff_2eelab_2elocals_2enone_init(void) {
  return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2elocals_2enone_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2elocals_2enone_st)) return g_heff_2eelab_2elocals_2enone_val;
  return heff_global(&g_heff_2eelab_2elocals_2enone_val, &g_heff_2eelab_2elocals_2enone_st, g_heff_2eelab_2elocals_2enone_init);
}

HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_b_242, 0)), heff_dup(v_x_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_b_242)}});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_p2_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2eelab_2elocals_2epatternBinders_str0), 2)) {
        heff_drop(v_p2_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_244 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_243, v_p2_242, NTAG(TAG_False)});
        return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_247));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2411 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2416 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2416));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2417); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2419 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2419));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2420); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2422 = heff_field(v_p1_241, 0);
      V v_sp_2423 = heff_field(v_p1_241, 1);
      V v_q_2424 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop(v_p2_242);
      V v_t_2425 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2422, v_sp_2423, NTAG(TAG_False)});
      V v_cell_2426 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
      V v_u_2427 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2424, heff_dup(v_cell_2426)));
      heff_drop(v_u_2427);
      return v_cell_2426;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24dps_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24dps_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_p2_243 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24dps_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        V v_t_246 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_246);
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2416);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2420));
      V v_t_2422 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2421); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2422);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2424 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2425); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2426);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2428 = heff_field(v_p1_242, 0);
      V v_sp_2429 = heff_field(v_p1_242, 1);
      V v_q_2430 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2431 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2428, v_sp_2429, NTAG(TAG_False)});
      V v_cell_2432 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2431, heff_hole()});
      V v_u_2433 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2432));
      heff_drop(v_u_2433);
      V t_0 = v_q_2430;
      V t_1 = v_cell_2432;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str1, 1, "_");
Clo g_heff_2eelab_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_241, ((V)&g_heff_2eelab_2elocals_2elamBinders_str0), 2)) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_243 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_sp_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2elamBinders_str1), 2)) {
      heff_drop(v_x_244);
      heff_drop(v_sp_245);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_245, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_247 = heff_field(v_x1_240, 0);
    V v_sp_248 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2410 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_247, v_sp_248, NTAG(TAG_False)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry, 2, 0};

V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_248));
        V v_binders_2411 = heff_take_field(v_a_2410, 0);
        V v_uses_2412 = heff_get_n(v_a_2410, 1, 2);
        V v_b_2414;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2414 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2413 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2414 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2413));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_binders_2415 = heff_take_field(v_b_2414, 0);
        V v_uses_2416 = heff_get_n(v_b_2414, 1, 2);
        V v_t_2417 = (g_prelude_2e_2b_2b(v_binders_2411, v_binders_2415));
        V v_t_2418 = (g_prelude_2e_2b_2b(v_uses_2412, v_uses_2416));
        V v_t_2419 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2420 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, v_env_240}), v_rest_243));
        V v_binders_2421 = heff_take_field(v_b_2420, 0);
        V v_uses_2422 = heff_get_n(v_b_2420, 1, 2);
        V v_t_2423 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2417, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2423, v_binders_2421})));
        V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2418, v_uses_2422));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2424, v_t_2425});
      }
      case TAG_BadFieldDecl: {
        V v_f_2426 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_f_2426));
        V v_binders_2428 = heff_take_field(v_a_2427, 0);
        V v_uses_2429 = heff_get_n(v_a_2427, 1, 2);
        V v_b_2430 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_rest_243));
        V v_binders_2431 = heff_take_field(v_b_2430, 0);
        V v_uses_2432 = heff_get_n(v_b_2430, 1, 2);
        V v_t_2433 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2428, v_binders_2431));
        V v_t_2434 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2429, v_uses_2432));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2433, v_t_2434});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry, 2, 0};

V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_248));
        V v_binders_2410 = heff_take_field(v_a_249, 0);
        V v_uses_2411 = heff_get_n(v_a_249, 1, 2);
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2413 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, v_env_240}), v_rest_243));
        V v_binders_2414 = heff_take_field(v_b_2413, 0);
        V v_uses_2415 = heff_get_n(v_b_2413, 1, 2);
        V v_t_2416 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2417 = (g_prelude_2e_2b_2b(v_binders_2410, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2416, v_binders_2414})));
        V v_t_2418 = (g_prelude_2e_2b_2b(v_uses_2411, v_uses_2415));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2417, v_t_2418});
      }
      case TAG_StmtLet: {
        V v_p_2419 = heff_field(v_x311_244, 0);
        V v_e_2420 = heff_field(v_x311_244, 1);
        V v_ru_24x311_244_24StmtLet = heff_take_reuse_n(v_x311_244, 3ULL, 2);
        V v_a_2421 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2420));
        V v_binders_2422 = heff_take_field(v_a_2421, 0);
        V v_uses_2423 = heff_get_n(v_a_2421, 1, 2);
        V v_bs_2424 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2419)));
        V v_env_2425 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2419));
        V v_b_2426 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2425, v_rest_243));
        V v_binders_2427 = heff_take_field(v_b_2426, 0);
        V v_uses_2428 = heff_get_n(v_b_2426, 1, 2);
        V v_t_2429 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2424, v_binders_2427));
        V v_t_2430 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x311_244_24StmtLet, v_binders_2422, v_t_2429));
        V v_t_2431 = (g_prelude_2e_2b_2b(v_uses_2423, v_uses_2428));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2430, v_t_2431});
      }
      case TAG_StmtExpr: {
        V v_e_2432 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2433 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2432));
        V v_binders_2434 = heff_take_field(v_a_2433, 0);
        V v_uses_2435 = heff_get_n(v_a_2433, 1, 2);
        V v_b_2436 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_rest_243));
        V v_binders_2437 = heff_take_field(v_b_2436, 0);
        V v_uses_2438 = heff_get_n(v_b_2436, 1, 2);
        V v_t_2439 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2434, v_binders_2437));
        V v_t_2440 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2435, v_uses_2438));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2439, v_t_2440});
      }
      case TAG_StmtLetMut: {
        V v_x_2441 = heff_field(v_x311_244, 0);
        V v_sp_2442 = heff_field(v_x311_244, 1);
        V v_e_2443 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2444 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2443));
        V v_binders_2445 = heff_take_field(v_a_2444, 0);
        V v_uses_2446 = heff_get_n(v_a_2444, 1, 2);
        V v_t_2447 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2441), heff_dup(v_sp_2442), NTAG(TAG_False)});
        V v_b_2448 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2447, v_env_240}), v_rest_243));
        V v_binders_2449 = heff_take_field(v_b_2448, 0);
        V v_uses_2450 = heff_get_n(v_b_2448, 1, 2);
        V v_t_2451 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2441, v_sp_2442, NTAG(TAG_False)});
        V v_t_2452 = (g_prelude_2e_2b_2b(v_binders_2445, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2451, v_binders_2449})));
        V v_t_2453 = (g_prelude_2e_2b_2b(v_uses_2446, v_uses_2450));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2452, v_t_2453});
      }
      case TAG_StmtLetElse: {
        V v_p_2454 = heff_field(v_x311_244, 0);
        V v_e_2455 = heff_field(v_x311_244, 1);
        V v_ss_2456 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2457 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2455));
        V v_binders_2458 = heff_take_field(v_a_2457, 0);
        V v_uses_2459 = heff_get_n(v_a_2457, 1, 2);
        V v_a_2460 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_240), v_ss_2456));
        V v_binders_2461 = heff_take_field(v_a_2460, 0);
        V v_uses_2462 = heff_get_n(v_a_2460, 1, 2);
        V v_bs_2463 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2454)));
        V v_env_2464 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2454));
        V v_b_2465 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2464, v_rest_243));
        V v_binders_2466 = heff_take_field(v_b_2465, 0);
        V v_uses_2467 = heff_get_n(v_b_2465, 1, 2);
        V v_t_2468 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2463, v_binders_2466));
        V v_t_2469 = (g_prelude_2e_2b_2b(v_binders_2461, v_t_2468));
        V v_t_2470 = (g_prelude_2e_2b_2b(v_uses_2462, v_uses_2467));
        V v_t_2471 = (g_prelude_2e_2b_2b(v_binders_2458, v_t_2469));
        V v_t_2472 = (g_prelude_2e_2b_2b(v_uses_2459, v_t_2470));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2471, v_t_2472});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry, 2, 0};

V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x31_242, 0);
      V v_fsp_245 = heff_field(v_x31_242, 1);
      V v_ty_247 = heff_field(v_x31_242, 3);
      V v_eqs_248 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 27ULL, 5);
      HeffT2 v_t_249 = ({ V a_0 = v_f_244; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_244); r_; });
      V v_a_2414;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_b_2412 = v_field_2411;
          V v_t_2413 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2412, v_fsp_245}), NTAG(TAG_Nil)});
          v_a_2414 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2413});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_fsp_245);
          heff_drop(v_field_2411);
          v_a_2414 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2415 = heff_take_field(v_a_2414, 0);
      V v_uses_2416 = heff_get_n(v_a_2414, 1, 2);
      V v_a_2417 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_ty_247));
      V v_binders_2418 = heff_take_field(v_a_2417, 0);
      V v_uses_2419 = heff_get_n(v_a_2417, 1, 2);
      V v_b_2440 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_binders_2441 = heff_take_field(v_b_2440, 0);
      V v_uses_2442 = heff_get_n(v_b_2440, 1, 2);
      V v_t_2443 = (g_prelude_2e_2b_2b(v_binders_2418, v_binders_2441));
      V v_t_2444 = (g_prelude_2e_2b_2b(v_uses_2419, v_uses_2442));
      V v_t_2445 = (g_prelude_2e_2b_2b(v_binders_2415, v_t_2443));
      V v_t_2446 = (g_prelude_2e_2b_2b(v_uses_2416, v_t_2444));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2445, v_t_2446});
    }
    case TAG_DeclDefine: {
      V v_x_2447 = heff_field(v_x31_242, 0);
      V v_xsp_2448 = heff_field(v_x31_242, 1);
      V v_ps_2449 = heff_field(v_x31_242, 2);
      V v_u_2450 = heff_field(v_x31_242, 3);
      V v_body_2451 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 31ULL, 5);
      HeffT2 v_t_2452 = ({ V a_0 = v_x_2447; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2447); r_; });
      V v_a_2457;
      {
        V v_field_2454 = v_t_2452.f[1];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_b_2455 = v_field_2454;
          V v_t_2456 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2455, v_xsp_2448}), NTAG(TAG_Nil)});
          v_a_2457 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2456});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2448);
          heff_drop(v_field_2454);
          v_a_2457 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2458 = heff_take_field(v_a_2457, 0);
      V v_uses_2459 = heff_get_n(v_a_2457, 1, 2);
      V v_a_24105 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_ps_2449; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2449); r_; });
      V v_binders_24106 = heff_take_field(v_a_24105, 0);
      V v_uses_24107 = heff_get_n(v_a_24105, 1, 2);
      V v_a_24108 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_u_2450));
      V v_binders_24109 = heff_take_field(v_a_24108, 0);
      V v_uses_24110 = heff_get_n(v_a_24108, 1, 2);
      V v_b_24111 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2451));
      V v_binders_24112 = heff_take_field(v_b_24111, 0);
      V v_uses_24113 = heff_get_n(v_b_24111, 1, 2);
      V v_t_24114 = (g_prelude_2e_2b_2b(v_binders_24109, v_binders_24112));
      V v_t_24115 = (g_prelude_2e_2b_2b(v_uses_24110, v_uses_24113));
      V v_t_24116 = (g_prelude_2e_2b_2b(v_binders_24106, v_t_24114));
      V v_t_24117 = (g_prelude_2e_2b_2b(v_uses_24107, v_t_24115));
      V v_t_24118 = (g_prelude_2e_2b_2b(v_binders_2458, v_t_24116));
      V v_t_24119 = (g_prelude_2e_2b_2b(v_uses_2459, v_t_24117));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24118, v_t_24119});
    }
    case TAG_DeclTheory: {
      V v_body_24123 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_24123);
    }
    case TAG_DeclPrimitive: {
      V v_x_24124 = heff_field(v_x31_242, 0);
      V v_xsp_24125 = heff_field(v_x31_242, 1);
      V v_t_24126 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_24127 = ({ V a_0 = v_x_24124; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24124); r_; });
      V v_a_24132;
      {
        V v_field_24129 = v_t_24127.f[1];
        int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
        if ((v_tag_24128 == ((int64_t)0ULL))) {
          V v_b_24130 = v_field_24129;
          V v_t_24131 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24130, v_xsp_24125}), NTAG(TAG_Nil)});
          v_a_24132 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24131});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_24125);
          heff_drop(v_field_24129);
          v_a_24132 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_24133 = heff_take_field(v_a_24132, 0);
      V v_uses_24134 = heff_get_n(v_a_24132, 1, 2);
      V v_b_24135 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_24126));
      V v_binders_24136 = heff_take_field(v_b_24135, 0);
      V v_uses_24137 = heff_get_n(v_b_24135, 1, 2);
      V v_t_24138 = (g_prelude_2e_2b_2b(v_binders_24133, v_binders_24136));
      V v_t_24139 = (g_prelude_2e_2b_2b(v_uses_24134, v_uses_24137));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24138, v_t_24139});
    }
    case TAG_DeclTest: {
      V v_x_24140 = heff_field(v_x31_242, 0);
      V v_xsp_24141 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      HeffT2 v_t_24142 = ({ V a_0 = v_x_24140; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24140); heff_drop(v_env_240); r_; });
      {
        V v_field_24144 = v_t_24142.f[1];
        int64_t v_tag_24143 = ((int64_t)v_t_24142.f[0]);
        if ((v_tag_24143 == ((int64_t)0ULL))) {
          V v_b_24145 = v_field_24144;
          V v_t_24146 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24145, v_xsp_24141}), NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24146});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_24141);
          heff_drop(v_field_24144);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
    }
    case TAG_DeclWatch: {
      V v_e_24147 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24147);
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_eq_2421 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_2422 = heff_take_field(v_acc_2420, 0);
  V v_uses_2423 = heff_get_n(v_acc_2420, 1, 2);
  V v_b_2435;
  switch (heff_tag_of(v_eq_2421)) {
  case TAG_At: {
    V v_x31_2424 = heff_field(v_eq_2421, 0);
    V v_ru_24eq_2421_24At = heff_take_reuse_n(v_eq_2421, 1ULL, 2);
    switch (heff_tag_of(v_x31_2424)) {
    case TAG_MkEquation: {
      V v_ps_2428 = heff_field(v_x31_2424, 2);
      V v_rhs_2429 = heff_field(v_x31_2424, 3);
      heff_take_n(v_x31_2424, 12ULL, 4);
      V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2428));
      V v_bs_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2430); r_; });
      V v_env_2432 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_2431)));
      V v_b_2433 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2432, v_rhs_2429));
      V v_t_2434 = (g_prelude_2e_2b_2b_24tok2(v_ru_24eq_2421_24At, v_bs_2431, heff_take_field(v_b_2433, 0)));
      v_b_2435 = ({ V rv_0 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_b_2433, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_2424);
    }
    break;
  }
  default: heff_nomatch(v_eq_2421);
  }
  V v_binders_2436 = heff_take_field(v_b_2435, 0);
  V v_uses_2437 = heff_get_n(v_b_2435, 1, 2);
  V v_t_2438 = (g_prelude_2e_2b_2b(v_binders_2422, v_binders_2436));
  V v_t_2439 = (g_prelude_2e_2b_2b(v_uses_2423, v_uses_2437));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2438, v_t_2439});
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args) {
  V v_acc_2460 = args[0];
  V v_m_2461 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_2462 = heff_take_field(v_acc_2460, 0);
  V v_uses_2463 = heff_get_n(v_acc_2460, 1, 2);
  V v_env_2464 = v_env_240;
  V v_x3_2465 = v_m_2461;
  V v_b_24100;
  switch (heff_tag_of(v_x3_2465)) {
  case TAG_At: {
    V v_x31_2466 = heff_field(v_x3_2465, 0);
    V v_ru_24x3_2465_24At = heff_take_reuse_n(v_x3_2465, 1ULL, 2);
    switch (heff_tag_of(v_x31_2466)) {
    case TAG_ExplicitParam: {
      V v_x_2468 = heff_field(v_x31_2466, 0);
      V v_xsp_2469 = heff_field(v_x31_2466, 1);
      V v_t_2470 = heff_field(v_x31_2466, 2);
      heff_take_n(v_x31_2466, 7ULL, 3);
      HeffT2 v_t_2471 = ({ V a_0 = v_x_2468; V a_1 = v_env_2464; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2468); r_; });
      V v_a_2476;
      {
        V v_field_2473 = v_t_2471.f[1];
        int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
        if ((v_tag_2472 == ((int64_t)0ULL))) {
          V v_b_2474 = v_field_2473;
          V v_t_2475 = heff_tag_at_n(v_ru_24x3_2465_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2474, v_xsp_2469}), NTAG(TAG_Nil)});
          v_a_2476 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2475});
        } else {
          heff_drop_cell(v_ru_24x3_2465_24At, 2);
          heff_drop(v_xsp_2469);
          heff_drop(v_field_2473);
          v_a_2476 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2477 = heff_take_field(v_a_2476, 0);
      V v_uses_2478 = heff_get_n(v_a_2476, 1, 2);
      V v_b_2479 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2464, v_t_2470));
      V v_binders_2480 = heff_take_field(v_b_2479, 0);
      V v_uses_2481 = heff_get_n(v_b_2479, 1, 2);
      V v_t_2482 = (g_prelude_2e_2b_2b(v_binders_2477, v_binders_2480));
      V v_t_2483 = (g_prelude_2e_2b_2b(v_uses_2478, v_uses_2481));
      v_b_24100 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2482, v_t_2483});
      break;
    }
    case TAG_ImplicitParam: {
      V v_x_2484 = heff_field(v_x31_2466, 0);
      V v_xsp_2485 = heff_field(v_x31_2466, 1);
      V v_t_2486 = heff_field(v_x31_2466, 2);
      heff_take_n(v_x31_2466, 7ULL, 3);
      HeffT2 v_t_2487 = ({ V a_0 = v_x_2484; V a_1 = v_env_2464; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2484); r_; });
      V v_a_2492;
      {
        V v_field_2489 = v_t_2487.f[1];
        int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
        if ((v_tag_2488 == ((int64_t)0ULL))) {
          V v_b_2490 = v_field_2489;
          V v_t_2491 = heff_tag_at_n(v_ru_24x3_2465_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2490, v_xsp_2485}), NTAG(TAG_Nil)});
          v_a_2492 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2491});
        } else {
          heff_drop_cell(v_ru_24x3_2465_24At, 2);
          heff_drop(v_xsp_2485);
          heff_drop(v_field_2489);
          v_a_2492 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      V v_binders_2493 = heff_take_field(v_a_2492, 0);
      V v_uses_2494 = heff_get_n(v_a_2492, 1, 2);
      V v_b_2495 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2464, v_t_2486));
      V v_binders_2496 = heff_take_field(v_b_2495, 0);
      V v_uses_2497 = heff_get_n(v_b_2495, 1, 2);
      V v_t_2498 = (g_prelude_2e_2b_2b(v_binders_2493, v_binders_2496));
      V v_t_2499 = (g_prelude_2e_2b_2b(v_uses_2494, v_uses_2497));
      v_b_24100 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2498, v_t_2499});
      break;
    }
    default: heff_nomatch(v_x31_2466);
    }
    break;
  }
  default: heff_nomatch(v_x3_2465);
  }
  V v_binders_24101 = heff_take_field(v_b_24100, 0);
  V v_uses_24102 = heff_get_n(v_b_24100, 1, 2);
  V v_t_24103 = (g_prelude_2e_2b_2b(v_binders_2462, v_binders_24101));
  V v_t_24104 = (g_prelude_2e_2b_2b(v_uses_2463, v_uses_24102));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24103, v_t_24104});
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry, 2, 0};

V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      heff_take_n(v_d1_242, 24ULL, 5);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 0ULL, 2);
        V v_a_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), heff_dup(v_ty_247)));
        V v_binders_2412 = heff_take_field(v_a_2411, 0);
        V v_uses_2413 = heff_get_n(v_a_2411, 1, 2);
        V v_b_2452 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
        V v_binders_2453 = heff_take_field(v_b_2452, 0);
        V v_uses_2454 = heff_get_n(v_b_2452, 1, 2);
        V v_t_2455 = (g_prelude_2e_2b_2b_24tok2(v_ru_24d_241_24At, v_binders_2412, v_binders_2453));
        V v_t_2456 = (g_prelude_2e_2b_2b(v_uses_2413, v_uses_2454));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2455, v_t_2456});
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_d1_242, 0ULL, 5);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_d1_242, 0ULL, 4);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_d1_242, 0ULL, 3);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_d1_242, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_eq_2415 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_binders_2416 = heff_take_field(v_acc_2414, 0);
  V v_uses_2417 = heff_get_n(v_acc_2414, 1, 2);
  V v_a_2429;
  switch (heff_tag_of(v_eq_2415)) {
  case TAG_At: {
    V v_x21_2418 = heff_dup(heff_field(v_eq_2415, 0));
    switch (heff_tag_of(v_x21_2418)) {
    case TAG_MkEquation: {
      V v_f_2420 = heff_field(v_x21_2418, 0);
      V v_fsp_2421 = heff_field(v_x21_2418, 1);
      heff_take_n(v_x21_2418, 3ULL, 4);
      HeffT2 v_t_2424 = ({ V a_0 = v_f_2420; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_2420); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_b_2427 = v_field_2426;
          V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2427, v_fsp_2421}), NTAG(TAG_Nil)});
          v_a_2429 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2428});
        } else {
          heff_drop(v_fsp_2421);
          heff_drop(v_field_2426);
          v_a_2429 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      break;
    }
    default: heff_nomatch(v_x21_2418);
    }
    break;
  }
  default: heff_nomatch(v_eq_2415);
  }
  V v_binders_2430 = heff_take_field(v_a_2429, 0);
  V v_uses_2431 = heff_get_n(v_a_2429, 1, 2);
  V v_env_2432 = (g_list_2efoldl_24f1488358745x465096512(v_env_240, v_ty_247));
  V v_x3_2433 = v_eq_2415;
  V v_b_2445;
  switch (heff_tag_of(v_x3_2433)) {
  case TAG_At: {
    V v_x31_2434 = heff_field(v_x3_2433, 0);
    V v_ru_24x3_2433_24At = heff_take_reuse_n(v_x3_2433, 1ULL, 2);
    switch (heff_tag_of(v_x31_2434)) {
    case TAG_MkEquation: {
      V v_ps_2438 = heff_field(v_x31_2434, 2);
      V v_rhs_2439 = heff_field(v_x31_2434, 3);
      heff_take_n(v_x31_2434, 12ULL, 4);
      V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2438));
      V v_bs_2441 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2440; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2440); r_; });
      V v_env_2442 = (g_list_2efoldl_24s1370882877x364361272(v_env_2432, heff_dup(v_bs_2441)));
      V v_b_2443 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2442, v_rhs_2439));
      V v_t_2444 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_2433_24At, v_bs_2441, heff_take_field(v_b_2443, 0)));
      v_b_2445 = ({ V rv_0 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_b_2443, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_2434);
    }
    break;
  }
  default: heff_nomatch(v_x3_2433);
  }
  V v_binders_2446 = heff_take_field(v_b_2445, 0);
  V v_uses_2447 = heff_get_n(v_b_2445, 1, 2);
  V v_t_2448 = (g_prelude_2e_2b_2b(v_binders_2430, v_binders_2446));
  V v_t_2449 = (g_prelude_2e_2b_2b(v_uses_2431, v_uses_2447));
  V v_t_2450 = (g_prelude_2e_2b_2b(v_binders_2416, v_t_2448));
  V v_t_2451 = (g_prelude_2e_2b_2b(v_uses_2417, v_t_2449));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2450, v_t_2451});
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4, 0, "");
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry, 6, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V v_tag_240, V v_env_241, V v_x3_242, V v_body_243, V v_env_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: {
    top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: ;
    heff_drop(v_env_244);
    heff_drop(v_n_245);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
      V t_1 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1);
      V t_3 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2);
      V t_4 = v_env_241;
      V t_5 = v_body_243;
      v_tag_240 = t_0;
      v_env_241 = t_1;
      v_x3_242 = t_2;
      v_body_243 = t_3;
      v_env_244 = t_4;
      v_n_245 = t_5;
      goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
    }
    case TAG_Cons: {
      V v_d_246 = heff_field(v_x3_242, 0);
      V v_ds_247 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2431;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_248 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_248)) {
        case TAG_DeclEquations: {
          V v_f_2410 = heff_field(v_d1_248, 0);
          V v_fsp_2411 = heff_field(v_d1_248, 1);
          heff_take_n(v_d1_248, 3ULL, 5);
          V v_t_2415 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2410, v_fsp_2411, NTAG(TAG_False)});
          v_t_2431 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_248, 0ULL, 5);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_248, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_248, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_248, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_248, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_248);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2455;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2432 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_2432)) {
        case TAG_DeclEquations: {
          V v_f_2434 = heff_field(v_d1_2432, 0);
          V v_fsp_2435 = heff_field(v_d1_2432, 1);
          heff_take_n(v_d1_2432, 3ULL, 5);
          V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2434, v_fsp_2435, NTAG(TAG_False)});
          v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2432, 0ULL, 5);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2432, 0ULL, 4);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2432, 0ULL, 3);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2432, 0ULL, 2);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2432, 0ULL, 1);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2432);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_241), v_t_2455));
      V v_a_2457 = (g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(v_t_2456, heff_dup(v_d_246)));
      V v_binders_2458 = heff_take_field(v_a_2457, 0);
      V v_uses_2459 = heff_get_n(v_a_2457, 1, 2);
      V v_t_2483;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2460 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24At = heff_take_reuse_n(v_d_246, 1ULL, 2);
        switch (heff_tag_of(v_d1_2460)) {
        case TAG_DeclEquations: {
          V v_f_2462 = heff_field(v_d1_2460, 0);
          V v_fsp_2463 = heff_field(v_d1_2460, 1);
          heff_take_n(v_d1_2460, 3ULL, 5);
          V v_t_2467 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2462, v_fsp_2463, NTAG(TAG_False)});
          v_t_2483 = heff_tag_at_n(v_ru_24d_246_24At, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2460, 0ULL, 5);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2460, 0ULL, 4);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2460, 0ULL, 3);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2460, 0ULL, 2);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2460, 0ULL, 1);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2483 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2460);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2484 = (g_list_2efoldl_24s1370882877x364361272(v_env_241, v_t_2483));
      V v_b_2485 = (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_t_2484, v_ds_247, v_body_243));
      V v_binders_2486 = heff_take_field(v_b_2485, 0);
      V v_uses_2487 = heff_get_n(v_b_2485, 1, 2);
      V v_t_2488 = (g_prelude_2e_2b_2b(v_binders_2458, v_binders_2486));
      V v_t_2489 = (g_prelude_2e_2b_2b(v_uses_2459, v_uses_2487));
      V v_t_2490 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2488));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2490, v_t_2489});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: {
    top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: ;
    switch (heff_tag_of(v_n_245)) {
    case TAG_At: {
      V v_n1_2491 = heff_dup(heff_field(v_n_245, 0));
      switch (heff_tag_of(v_n1_2491)) {
      case TAG_EVar: {
        V v_x_2493 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        HeffT2 v_t_2494 = ({ V a_0 = v_x_2493; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2493); heff_drop(v_env_244); r_; });
        {
          V v_field_2496 = v_t_2494.f[1];
          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
          if ((v_tag_2495 == ((int64_t)0ULL))) {
            V v_b_2497 = v_field_2496;
            V v_t_24100;
            switch (heff_tag_of(v_n_245)) {
            case TAG_At: {
              V v_s_2499 = heff_field(v_n_245, 1);
              heff_take_n(v_n_245, 2ULL, 2);
              v_t_24100 = v_s_2499;
              break;
            }
            default: heff_nomatch(v_n_245);
            }
            V v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2497, v_t_24100}), NTAG(TAG_Nil)});
            return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24101});
          } else {
            heff_drop_tag(v_n_245, 2);
            heff_drop(v_field_2496);
            return heff_dup(g_heff_2eelab_2elocals_2enone_get());
          }
        }
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETag: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInt: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFloat: {
        heff_take_nf(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EString: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBinary: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ERune: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWord: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EApp: {
        V v_h_24126 = heff_field(v_n1_2491, 0);
        V v_args_24127 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EApp = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24130 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_h_24126));
          V v_binders_24131 = heff_take_field(v_a_24130, 0);
          V v_uses_24132 = heff_get_n(v_a_24130, 1, 2);
          V v_b_24142 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24127; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24127); r_; });
          V v_binders_24143 = heff_take_field(v_b_24142, 0);
          V v_uses_24144 = heff_get_n(v_b_24142, 1, 2);
          V v_t_24145 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EApp, v_binders_24131, v_binders_24143));
          V v_t_24146 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24132, v_uses_24144));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24145, v_t_24146});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EProject: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENamed: {
        V v_e_24151 = heff_field(v_n1_2491, 1);
        heff_take_n(v_n1_2491, 2ULL, 2);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24151;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EPi: {
        V v_n11_24154 = heff_field(v_n1_2491, 0);
        V v_r_24155 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EPi = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24154)) {
          case TAG_PiNamed: {
            V v_x_24158 = heff_field(v_n11_24154, 0);
            V v_sp_24159 = heff_field(v_n11_24154, 1);
            V v_a_24160 = heff_field(v_n11_24154, 2);
            heff_take_n(v_n11_24154, 7ULL, 3);
            V v_a_24161 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24160));
            V v_binders_24162 = heff_take_field(v_a_24161, 0);
            V v_uses_24163 = heff_get_n(v_a_24161, 1, 2);
            V v_t_24164 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24158), heff_dup(v_sp_24159), NTAG(TAG_False)});
            V v_b_24165 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24EPi, TAG_Cons, 2, (V[]){v_t_24164, v_env_244}), v_r_24155));
            V v_binders_24166 = heff_take_field(v_b_24165, 0);
            V v_uses_24167 = heff_get_n(v_b_24165, 1, 2);
            V v_t_24168 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24158, v_sp_24159, NTAG(TAG_False)});
            V v_t_24169 = (g_prelude_2e_2b_2b(v_binders_24162, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24168, v_binders_24166})));
            V v_t_24170 = (g_prelude_2e_2b_2b(v_uses_24163, v_uses_24167));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24169, v_t_24170});
          }
          case TAG_PiImplicit: {
            V v_x_24171 = heff_field(v_n11_24154, 0);
            V v_sp_24172 = heff_field(v_n11_24154, 1);
            V v_a_24174 = heff_field(v_n11_24154, 3);
            V v_d_24175 = heff_field(v_n11_24154, 4);
            heff_take_n(v_n11_24154, 27ULL, 5);
            V v_a_24176 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24174));
            V v_binders_24177 = heff_take_field(v_a_24176, 0);
            V v_uses_24178 = heff_get_n(v_a_24176, 1, 2);
            V v_b_24180;
            switch (heff_tag_of(v_d_24175)) {
            case TAG_Nothing: {
              v_b_24180 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24179 = heff_field(v_d_24175, 0);
              heff_take_n(v_d_24175, 1ULL, 1);
              v_b_24180 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24179));
              break;
            }
            default: heff_nomatch(v_d_24175);
            }
            V v_binders_24181 = heff_take_field(v_b_24180, 0);
            V v_uses_24182 = heff_get_n(v_b_24180, 1, 2);
            V v_t_24183 = (g_prelude_2e_2b_2b(v_binders_24177, v_binders_24181));
            V v_t_24184 = (g_prelude_2e_2b_2b(v_uses_24178, v_uses_24182));
            V v_t_24185 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24171), heff_dup(v_sp_24172), NTAG(TAG_False)});
            V v_b_24186 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24EPi, TAG_Cons, 2, (V[]){v_t_24185, v_env_244}), v_r_24155));
            V v_binders_24187 = heff_take_field(v_b_24186, 0);
            V v_uses_24188 = heff_get_n(v_b_24186, 1, 2);
            V v_t_24189 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24171, v_sp_24172, NTAG(TAG_False)});
            V v_t_24190 = (g_prelude_2e_2b_2b(v_t_24183, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24189, v_binders_24187})));
            V v_t_24191 = (g_prelude_2e_2b_2b(v_t_24184, v_uses_24188));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24190, v_t_24191});
          }
          case TAG_PiInstance: {
            V v_x_24192 = heff_field(v_n11_24154, 0);
            V v_sp_24193 = heff_field(v_n11_24154, 1);
            V v_a_24195 = heff_field(v_n11_24154, 3);
            heff_take_n(v_n11_24154, 11ULL, 4);
            V v_a_24196 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24195));
            V v_binders_24197 = heff_take_field(v_a_24196, 0);
            V v_uses_24198 = heff_get_n(v_a_24196, 1, 2);
            V v_t_24199 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24192), heff_dup(v_sp_24193), NTAG(TAG_False)});
            V v_b_24200 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24EPi, TAG_Cons, 2, (V[]){v_t_24199, v_env_244}), v_r_24155));
            V v_binders_24201 = heff_take_field(v_b_24200, 0);
            V v_uses_24202 = heff_get_n(v_b_24200, 1, 2);
            V v_t_24203 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24192, v_sp_24193, NTAG(TAG_False)});
            V v_t_24204 = (g_prelude_2e_2b_2b(v_binders_24197, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24203, v_binders_24201})));
            V v_t_24205 = (g_prelude_2e_2b_2b(v_uses_24198, v_uses_24202));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24204, v_t_24205});
          }
          case TAG_PiAnon: {
            V v_a_24206 = heff_field(v_n11_24154, 0);
            heff_take_n(v_n11_24154, 1ULL, 1);
            V v_a_24207 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24206));
            V v_binders_24208 = heff_take_field(v_a_24207, 0);
            V v_uses_24209 = heff_get_n(v_a_24207, 1, 2);
            V v_b_24210 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_r_24155));
            V v_binders_24211 = heff_take_field(v_b_24210, 0);
            V v_uses_24212 = heff_get_n(v_b_24210, 1, 2);
            V v_t_24213 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EPi, v_binders_24208, v_binders_24211));
            V v_t_24214 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24209, v_uses_24212));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24213, v_t_24214});
          }
          default: return heff_nomatch(v_n11_24154);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELam: {
        V v_n11_24215 = heff_field(v_n1_2491, 0);
        V v_r_24216 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24ELam = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24215)) {
          case TAG_LamName: {
            heff_drop_cell(v_ru_24n_245_24At, 2);
            V v_bs_24221 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24215));
            V v_env_24222 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24221)));
            V v_b_24223 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24222, v_r_24216));
            V v_t_24224 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24ELam, v_bs_24221, heff_take_field(v_b_24223, 0)));
            return ({ V rv_0 = v_t_24224; V rr_ = heff_rec_reuse_nf(v_b_24223, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          }
          case TAG_LamImplicit: {
            heff_drop_cell(v_ru_24n_245_24At, 2);
            V v_bs_24227 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24215));
            V v_env_24228 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24227)));
            V v_b_24229 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24228, v_r_24216));
            V v_t_24230 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24ELam, v_bs_24227, heff_take_field(v_b_24229, 0)));
            return ({ V rv_0 = v_t_24230; V rr_ = heff_rec_reuse_nf(v_b_24229, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          }
          case TAG_LamAnn: {
            V v_x_24231 = heff_field(v_n11_24215, 0);
            V v_sp_24232 = heff_field(v_n11_24215, 1);
            V v_a_24233 = heff_field(v_n11_24215, 2);
            heff_take_n(v_n11_24215, 7ULL, 3);
            V v_a_24234 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24233));
            V v_binders_24235 = heff_take_field(v_a_24234, 0);
            V v_uses_24236 = heff_get_n(v_a_24234, 1, 2);
            V v_t_24237 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24231), heff_dup(v_sp_24232), NTAG(TAG_False)});
            V v_b_24238 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_tag_at_n(v_ru_24n1_2491_24ELam, TAG_Cons, 2, (V[]){v_t_24237, v_env_244}), v_r_24216));
            V v_binders_24239 = heff_take_field(v_b_24238, 0);
            V v_uses_24240 = heff_get_n(v_b_24238, 1, 2);
            V v_t_24241 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24231, v_sp_24232, NTAG(TAG_False)});
            V v_t_24242 = (g_prelude_2e_2b_2b(v_binders_24235, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24241, v_binders_24239})));
            V v_t_24243 = (g_prelude_2e_2b_2b(v_uses_24236, v_uses_24240));
            return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24242, v_t_24243});
          }
          default: return heff_nomatch(v_n11_24215);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAnn: {
        V v_e_24244 = heff_field(v_n1_2491, 0);
        V v_t_24245 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EAnn = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24244));
          V v_binders_24249 = heff_take_field(v_a_24248, 0);
          V v_uses_24250 = heff_get_n(v_a_24248, 1, 2);
          V v_b_24251 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_t_24245));
          V v_binders_24252 = heff_take_field(v_b_24251, 0);
          V v_uses_24253 = heff_get_n(v_b_24251, 1, 2);
          V v_t_24254 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EAnn, v_binders_24249, v_binders_24252));
          V v_t_24255 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24250, v_uses_24253));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24254, v_t_24255});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESpec: {
        V v_acc_24256 = heff_field(v_n1_2491, 0);
        V v_v_24259 = heff_field(v_n1_2491, 3);
        heff_take_n(v_n1_2491, 9ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24262 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_acc_24256));
          V v_binders_24263 = heff_take_field(v_a_24262, 0);
          V v_uses_24264 = heff_get_n(v_a_24262, 1, 2);
          V v_b_24265 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_v_24259));
          V v_binders_24266 = heff_take_field(v_b_24265, 0);
          V v_uses_24267 = heff_get_n(v_b_24265, 1, 2);
          V v_t_24268 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24263, v_binders_24266));
          V v_t_24269 = (g_prelude_2e_2b_2b(v_uses_24264, v_uses_24267));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24268, v_t_24269});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESig: {
        V v_fs_24270 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_244, v_fs_24270));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESum: {
        V v_vs_24273 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_vs_24273; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24273); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EStruct: {
        V v_fs_24300 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_fs_24300; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24300); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EUpdate: {
        V v_a_24318 = heff_field(v_n1_2491, 0);
        V v_fs_24319 = heff_field(v_n1_2491, 1);
        heff_take_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V v_t_24322 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_a_24318));
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4, 2, 1, (V[]){v_env_244}); V a_1 = v_t_24322; V a_2 = v_fs_24319; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24319); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EMatch: {
        V v_s_24336 = heff_field(v_n1_2491, 0);
        V v_alts_24337 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EMatch = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24340 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_s_24336));
          V v_binders_24341 = heff_take_field(v_a_24340, 0);
          V v_uses_24342 = heff_get_n(v_a_24340, 1, 2);
          V v_b_24360 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_alts_24337; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24337); r_; });
          V v_binders_24361 = heff_take_field(v_b_24360, 0);
          V v_uses_24362 = heff_get_n(v_b_24360, 1, 2);
          V v_t_24363 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EMatch, v_binders_24341, v_binders_24361));
          V v_t_24364 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24342, v_uses_24362));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24363, v_t_24364});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELetIn: {
        V v_rhs_24365 = heff_field(v_n1_2491, 0);
        V v_a_24366 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24ELetIn = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24369 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_rhs_24365));
          V v_binders_24370 = heff_take_field(v_a_24369, 0);
          V v_uses_24371 = heff_get_n(v_a_24369, 1, 2);
          V v_b_24380;
          switch (heff_tag_of(v_a_24366)) {
          case TAG_At: {
            V v_x31_24372 = heff_field(v_a_24366, 0);
            heff_take_n(v_a_24366, 1ULL, 2);
            switch (heff_tag_of(v_x31_24372)) {
            case TAG_MkAlt: {
              V v_p_24374 = heff_field(v_x31_24372, 0);
              V v_r_24375 = heff_field(v_x31_24372, 1);
              heff_take_n(v_x31_24372, 3ULL, 2);
              V v_bs_24376 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n1_2491_24ELetIn, v_p_24374));
              V v_env_24377 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24376)));
              V v_b_24378 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24377, v_r_24375));
              V v_t_24379 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_bs_24376, heff_take_field(v_b_24378, 0)));
              v_b_24380 = ({ V rv_0 = v_t_24379; V rr_ = heff_rec_reuse_nf(v_b_24378, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              break;
            }
            default: heff_nomatch(v_x31_24372);
            }
            break;
          }
          default: heff_nomatch(v_a_24366);
          }
          V v_binders_24381 = heff_take_field(v_b_24380, 0);
          V v_uses_24382 = heff_get_n(v_b_24380, 1, 2);
          V v_t_24383 = (g_prelude_2e_2b_2b(v_binders_24370, v_binders_24381));
          V v_t_24384 = (g_prelude_2e_2b_2b(v_uses_24371, v_uses_24382));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24383, v_t_24384});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EDo: {
        V v_stmts_24385 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_stmts_24385));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELocal: {
        V v_body_24388 = heff_field(v_n1_2491, 0);
        V v_defs_24389 = heff_field(v_n1_2491, 1);
        heff_take_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361);
          V t_1 = v_env_244;
          V t_2 = v_defs_24389;
          V t_3 = v_body_24388;
          V t_4 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3);
          V t_5 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4);
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInvalid: {
        heff_take_n(v_n1_2491, 0ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAssign: {
        V v_x_24395 = heff_field(v_n1_2491, 0);
        V v_xsp_24396 = heff_field(v_n1_2491, 1);
        V v_e_24397 = heff_field(v_n1_2491, 2);
        heff_take_n(v_n1_2491, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          HeffT2 v_t_24400 = ({ V a_0 = v_x_24395; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24395); r_; });
          V v_a_24405;
          {
            V v_field_24402 = v_t_24400.f[1];
            int64_t v_tag_24401 = ((int64_t)v_t_24400.f[0]);
            if ((v_tag_24401 == ((int64_t)0ULL))) {
              V v_b_24403 = v_field_24402;
              V v_t_24404 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24403, v_xsp_24396}), NTAG(TAG_Nil)});
              v_a_24405 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_24404});
            } else {
              heff_drop(v_xsp_24396);
              heff_drop_cell(v_ru_24n_245_24At, 2);
              heff_drop(v_field_24402);
              v_a_24405 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            }
          }
          V v_binders_24406 = heff_take_field(v_a_24405, 0);
          V v_uses_24407 = heff_get_n(v_a_24405, 1, 2);
          V v_b_24408 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24397));
          V v_binders_24409 = heff_take_field(v_b_24408, 0);
          V v_uses_24410 = heff_get_n(v_b_24408, 1, 2);
          V v_t_24411 = (g_prelude_2e_2b_2b(v_binders_24406, v_binders_24409));
          V v_t_24412 = (g_prelude_2e_2b_2b(v_uses_24407, v_uses_24410));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24411, v_t_24412});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWhile: {
        V v_c_24413 = heff_field(v_n1_2491, 0);
        V v_body_24414 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EWhile = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24417 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24413));
          V v_binders_24418 = heff_take_field(v_a_24417, 0);
          V v_uses_24419 = heff_get_n(v_a_24417, 1, 2);
          V v_b_24420 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_244, v_body_24414));
          V v_binders_24421 = heff_take_field(v_b_24420, 0);
          V v_uses_24422 = heff_get_n(v_b_24420, 1, 2);
          V v_t_24423 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EWhile, v_binders_24418, v_binders_24421));
          V v_t_24424 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24419, v_uses_24422));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24423, v_t_24424});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFor: {
        V v_p_24425 = heff_field(v_n1_2491, 0);
        V v_c_24426 = heff_field(v_n1_2491, 1);
        V v_body_24427 = heff_field(v_n1_2491, 2);
        heff_take_n(v_n1_2491, 7ULL, 3);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24430 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24426));
          V v_binders_24431 = heff_take_field(v_a_24430, 0);
          V v_uses_24432 = heff_get_n(v_a_24430, 1, 2);
          V v_bs_24433 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n_245_24At, heff_dup(v_p_24425)));
          V v_env_24434 = (g_list_2efoldl_24f1677743806x2032371213(v_env_244, v_p_24425));
          V v_b_24435 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24434, v_body_24427));
          V v_binders_24436 = heff_take_field(v_b_24435, 0);
          V v_uses_24437 = heff_get_n(v_b_24435, 1, 2);
          V v_t_24438 = (g_prelude_2e_2b_2b(v_bs_24433, v_binders_24436));
          V v_t_24439 = (g_prelude_2e_2b_2b(v_binders_24431, v_t_24438));
          V v_t_24440 = (g_prelude_2e_2b_2b(v_uses_24432, v_uses_24437));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24439, v_t_24440});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EIfThen: {
        V v_c_24441 = heff_field(v_n1_2491, 0);
        V v_a_24442 = heff_field(v_n1_2491, 1);
        V v_ru_24n1_2491_24EIfThen = heff_take_reuse_n(v_n1_2491, 3ULL, 2);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24445 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_c_24441));
          V v_binders_24446 = heff_take_field(v_a_24445, 0);
          V v_uses_24447 = heff_get_n(v_a_24445, 1, 2);
          V v_b_24448 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24442));
          V v_binders_24449 = heff_take_field(v_b_24448, 0);
          V v_uses_24450 = heff_get_n(v_b_24448, 1, 2);
          V v_t_24451 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2491_24EIfThen, v_binders_24446, v_binders_24449));
          V v_t_24452 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24447, v_uses_24450));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24451, v_t_24452});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBreak: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EContinue: {
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        heff_drop(v_env_244);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EReturn: {
        V v_e_24457 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24457;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENest: {
        V v_e_24460 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24460;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELazy: {
        V v_e_24463 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24463;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETuple: {
        V v_es_24466 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_es_24466; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_24466); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETry: {
        V v_n11_24478 = heff_field(v_n1_2491, 0);
        heff_take_n(v_n1_2491, 1ULL, 1);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24478)) {
          case TAG_MkTry: {
            V v_ty_24481 = heff_field(v_n11_24478, 0);
            V v_body_24482 = heff_field(v_n11_24478, 1);
            V v_c_24483 = heff_field(v_n11_24478, 2);
            heff_take_n(v_n11_24478, 7ULL, 3);
            V v_a_24485;
            switch (heff_tag_of(v_ty_24481)) {
            case TAG_Nothing: {
              v_a_24485 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24484 = heff_field(v_ty_24481, 0);
              heff_take_n(v_ty_24481, 1ULL, 1);
              v_a_24485 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_x_24484));
              break;
            }
            default: heff_nomatch(v_ty_24481);
            }
            V v_binders_24486 = heff_take_field(v_a_24485, 0);
            V v_uses_24487 = heff_get_n(v_a_24485, 1, 2);
            V v_b_24488 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_244), v_body_24482));
            V v_binders_24489 = heff_take_field(v_b_24488, 0);
            V v_uses_24490 = heff_get_n(v_b_24488, 1, 2);
            V v_t_24491 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24486, v_binders_24489));
            V v_t_24492 = (g_prelude_2e_2b_2b(v_uses_24487, v_uses_24490));
            HeffT2 v_t_24493 = (g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(v_env_244, v_c_24483));
            {
              V v_field_24494 = v_t_24493.f[0];
              V v_field_24495 = v_t_24493.f[1];
              V v_t_24496 = (g_prelude_2e_2b_2b(v_t_24491, v_field_24494));
              V v_t_24497 = (g_prelude_2e_2b_2b(v_t_24492, v_field_24495));
              return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24496, v_t_24497});
            }
          }
          default: return heff_nomatch(v_n11_24478);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWith: {
        V v_e_24498 = heff_field(v_n1_2491, 0);
        V v_x_24499 = heff_field(v_n1_2491, 1);
        V v_xsp_24500 = heff_field(v_n1_2491, 2);
        V v_body_24501 = heff_field(v_n1_2491, 3);
        heff_take_n(v_n1_2491, 15ULL, 4);
        heff_drop(v_env_241);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24504 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_244), v_e_24498));
          V v_binders_24505 = heff_take_field(v_a_24504, 0);
          V v_uses_24506 = heff_get_n(v_a_24504, 1, 2);
          V v_t_24507 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24499), heff_dup(v_xsp_24500), NTAG(TAG_False)});
          V v_b_24508 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24507, v_env_244}), v_body_24501));
          V v_binders_24509 = heff_take_field(v_b_24508, 0);
          V v_uses_24510 = heff_get_n(v_b_24508, 1, 2);
          V v_t_24511 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24499, v_xsp_24500, NTAG(TAG_False)});
          V v_t_24512 = (g_prelude_2e_2b_2b(v_binders_24505, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24511, v_binders_24509})));
          V v_t_24513 = (g_prelude_2e_2b_2b(v_uses_24506, v_uses_24510));
          return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24512, v_t_24513});
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      default: return heff_nomatch(v_n1_2491);
      }
    }
    default: return heff_nomatch(v_n_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args) {
  V v_acc_24133 = args[0];
  V v_x_24134 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24135 = heff_take_field(v_acc_24133, 0);
  V v_uses_24136 = heff_get_n(v_acc_24133, 1, 2);
  V v_b_24137 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24134));
  V v_binders_24138 = heff_take_field(v_b_24137, 0);
  V v_uses_24139 = heff_get_n(v_b_24137, 1, 2);
  V v_t_24140 = (g_prelude_2e_2b_2b(v_binders_24135, v_binders_24138));
  V v_t_24141 = (g_prelude_2e_2b_2b(v_uses_24136, v_uses_24139));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24140, v_t_24141});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args) {
  V v_acc_24285 = args[0];
  V v_x_24286 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24287 = heff_take_field(v_acc_24285, 0);
  V v_uses_24288 = heff_get_n(v_acc_24285, 1, 2);
  V v_b_24289 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24286));
  V v_binders_24290 = heff_take_field(v_b_24289, 0);
  V v_uses_24291 = heff_get_n(v_b_24289, 1, 2);
  V v_t_24292 = (g_prelude_2e_2b_2b(v_binders_24287, v_binders_24290));
  V v_t_24293 = (g_prelude_2e_2b_2b(v_uses_24288, v_uses_24291));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24292, v_t_24293});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args) {
  V v_acc_24276 = args[0];
  V v_v_24277 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24278 = heff_take_field(v_acc_24276, 0);
  V v_uses_24279 = heff_get_n(v_acc_24276, 1, 2);
  V v_b_24295;
  switch (heff_tag_of(v_v_24277)) {
  case TAG_At: {
    V v_it1_24280 = heff_field(v_v_24277, 0);
    heff_take_n(v_v_24277, 1ULL, 2);
    switch (heff_tag_of(v_it1_24280)) {
    case TAG_TagVariant: {
      V v_args_24284 = heff_field(v_it1_24280, 2);
      heff_take_n(v_it1_24280, 4ULL, 3);
      v_b_24295 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24284; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24284); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24294 = heff_field(v_it1_24280, 0);
      heff_take_n(v_it1_24280, 1ULL, 1);
      v_b_24295 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24294));
      break;
    }
    default: heff_nomatch(v_it1_24280);
    }
    break;
  }
  default: heff_nomatch(v_v_24277);
  }
  V v_binders_24296 = heff_take_field(v_b_24295, 0);
  V v_uses_24297 = heff_get_n(v_b_24295, 1, 2);
  V v_t_24298 = (g_prelude_2e_2b_2b(v_binders_24278, v_binders_24296));
  V v_t_24299 = (g_prelude_2e_2b_2b(v_uses_24279, v_uses_24297));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24298, v_t_24299});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args) {
  V v_acc_24303 = args[0];
  V v_f_24304 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24305 = heff_take_field(v_acc_24303, 0);
  V v_uses_24306 = heff_get_n(v_acc_24303, 1, 2);
  V v_b_24313;
  switch (heff_tag_of(v_f_24304)) {
  case TAG_At: {
    V v_x31_24307 = heff_field(v_f_24304, 0);
    heff_take_n(v_f_24304, 1ULL, 2);
    switch (heff_tag_of(v_x31_24307)) {
    case TAG_SetField: {
      V v_e_24311 = heff_field(v_x31_24307, 2);
      heff_take_n(v_x31_24307, 4ULL, 3);
      v_b_24313 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24311));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24312 = heff_field(v_x31_24307, 0);
      heff_take_n(v_x31_24307, 1ULL, 1);
      v_b_24313 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24312));
      break;
    }
    default: heff_nomatch(v_x31_24307);
    }
    break;
  }
  default: heff_nomatch(v_f_24304);
  }
  V v_binders_24314 = heff_take_field(v_b_24313, 0);
  V v_uses_24315 = heff_get_n(v_b_24313, 1, 2);
  V v_t_24316 = (g_prelude_2e_2b_2b(v_binders_24305, v_binders_24314));
  V v_t_24317 = (g_prelude_2e_2b_2b(v_uses_24306, v_uses_24315));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24316, v_t_24317});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args) {
  V v_acc_24323 = args[0];
  V v_f_24324 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24325 = heff_take_field(v_acc_24323, 0);
  V v_uses_24326 = heff_get_n(v_acc_24323, 1, 2);
  switch (heff_tag_of(v_f_24324)) {
  case TAG_At: {
    V v_it1_24327 = heff_field(v_f_24324, 0);
    V v_ru_24f_24324_24At = heff_take_reuse_n(v_f_24324, 1ULL, 2);
    switch (heff_tag_of(v_it1_24327)) {
    case TAG_SetPath: {
      V v_e_24330 = heff_field(v_it1_24327, 1);
      V v_ru_24it1_24327_24SetPath = heff_take_reuse_n(v_it1_24327, 2ULL, 2);
      V v_b_24331 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24330));
      V v_binders_24332 = heff_take_field(v_b_24331, 0);
      V v_uses_24333 = heff_get_n(v_b_24331, 1, 2);
      V v_t_24334 = (g_prelude_2e_2b_2b_24tok2(v_ru_24f_24324_24At, v_binders_24325, v_binders_24332));
      V v_t_24335 = (g_prelude_2e_2b_2b_24tok2(v_ru_24it1_24327_24SetPath, v_uses_24326, v_uses_24333));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24334, v_t_24335});
    }
    default: return heff_nomatch(v_it1_24327);
    }
  }
  default: return heff_nomatch(v_f_24324);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args) {
  V v_acc_24343 = args[0];
  V v_a_24344 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24345 = heff_take_field(v_acc_24343, 0);
  V v_uses_24346 = heff_get_n(v_acc_24343, 1, 2);
  V v_b_24355;
  switch (heff_tag_of(v_a_24344)) {
  case TAG_At: {
    V v_x31_24347 = heff_field(v_a_24344, 0);
    V v_ru_24a_24344_24At = heff_take_reuse_n(v_a_24344, 1ULL, 2);
    switch (heff_tag_of(v_x31_24347)) {
    case TAG_MkAlt: {
      V v_p_24349 = heff_field(v_x31_24347, 0);
      V v_r_24350 = heff_field(v_x31_24347, 1);
      V v_ru_24x31_24347_24MkAlt = heff_take_reuse_n(v_x31_24347, 3ULL, 2);
      V v_bs_24351 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24a_24344_24At, v_p_24349));
      V v_env_24352 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24351)));
      V v_b_24353 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24352, v_r_24350));
      V v_t_24354 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_24347_24MkAlt, v_bs_24351, heff_take_field(v_b_24353, 0)));
      v_b_24355 = ({ V rv_0 = v_t_24354; V rr_ = heff_rec_reuse_nf(v_b_24353, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_24347);
    }
    break;
  }
  default: heff_nomatch(v_a_24344);
  }
  V v_binders_24356 = heff_take_field(v_b_24355, 0);
  V v_uses_24357 = heff_get_n(v_b_24355, 1, 2);
  V v_t_24358 = (g_prelude_2e_2b_2b(v_binders_24345, v_binders_24356));
  V v_t_24359 = (g_prelude_2e_2b_2b(v_uses_24346, v_uses_24357));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24358, v_t_24359});
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args) {
  V v_acc_24469 = args[0];
  V v_x_24470 = args[1];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_24471 = heff_take_field(v_acc_24469, 0);
  V v_uses_24472 = heff_get_n(v_acc_24469, 1, 2);
  V v_b_24473 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24470));
  V v_binders_24474 = heff_take_field(v_b_24473, 0);
  V v_uses_24475 = heff_get_n(v_b_24473, 1, 2);
  V v_t_24476 = (g_prelude_2e_2b_2b(v_binders_24471, v_binders_24474));
  V v_t_24477 = (g_prelude_2e_2b_2b(v_uses_24472, v_uses_24475));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24476, v_t_24477});
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1, 0, "");
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry, 3, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361), v_env_240, v_x3_241, v_body_242, ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0), ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1)));
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkCatchArm: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ss_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkCatchArm = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_LamName: {
      V v_bs_246 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_247 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_248 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_247));
      V v_b_249 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_248, v_ss_243));
      V v_binders_2410 = heff_take_field(v_b_249, 0);
      V v_uses_2411 = heff_get_n(v_b_249, 1, 2);
      V v_f_2412 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_246, v_binders_2410));
      V v_f_2413 = v_uses_2411;
      return ((HeffT2){{v_f_2412, v_f_2413}});
    }
    case TAG_LamImplicit: {
      V v_bs_2416 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_2417 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_2418 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2417));
      V v_b_2419 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2418, v_ss_243));
      V v_binders_2420 = heff_take_field(v_b_2419, 0);
      V v_uses_2421 = heff_get_n(v_b_2419, 1, 2);
      V v_f_2422 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_2416, v_binders_2420));
      V v_f_2423 = v_uses_2421;
      return ((HeffT2){{v_f_2422, v_f_2423}});
    }
    case TAG_LamAnn: {
      V v_x_2424 = heff_field(v_x31_242, 0);
      V v_sp_2425 = heff_field(v_x31_242, 1);
      V v_t_2426 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_a_2427 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2426));
      V v_binders_2428 = heff_take_field(v_a_2427, 0);
      V v_uses_2429 = heff_get_n(v_a_2427, 1, 2);
      V v_t_2430 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2424), heff_dup(v_sp_2425), NTAG(TAG_False)});
      V v_b_2431 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_2430, v_env_240}), v_ss_243));
      V v_binders_2432 = heff_take_field(v_b_2431, 0);
      V v_uses_2433 = heff_get_n(v_b_2431, 1, 2);
      V v_t_2434 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2424, v_sp_2425, NTAG(TAG_False)});
      V v_f_2435 = (g_prelude_2e_2b_2b(v_binders_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_binders_2432})));
      V v_f_2436 = (g_prelude_2e_2b_2b(v_uses_2429, v_uses_2433));
      return ((HeffT2){{v_f_2435, v_f_2436}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2, 0, "");
Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry, 2, 0};

V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V v_env_240, V v_n_241) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2), v_env_240, v_n_241));
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry, 4, 0};

V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V v_lit_240, V v_lit_241, V v_env_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    V v_f_2413 = heff_clo_n(g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_lam0, 2, 1, (V[]){v_env_242});
    V v_z_2414 = heff_tr(heff_call(heff_dup(v_f_2413), 2, (V[]){heff_dup(g_heff_2eelab_2elocals_2enone_get()), v_lit_240}));
    V v_z_2415 = heff_tr(heff_call(v_f_2413, 2, (V[]){v_z_2414, v_lit_241}));
    return v_z_2415;
  }
  case TAG_Cons: {
    V v_x21_2416 = heff_field(v_x2_243, 0);
    V v_tl_2417 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x21_2416)) {
    case TAG_At: {
      V v_x211_2418 = heff_field(v_x21_2416, 0);
      V v_ru_24x21_2416_24At = heff_take_reuse_n(v_x21_2416, 1ULL, 2);
      switch (heff_tag_of(v_x211_2418)) {
      case TAG_ExplicitParam: {
        V v_x_2420 = heff_field(v_x211_2418, 0);
        V v_sp_2421 = heff_field(v_x211_2418, 1);
        V v_t_2422 = heff_field(v_x211_2418, 2);
        heff_take_n(v_x211_2418, 7ULL, 3);
        V v_a_2423 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_242), v_t_2422));
        V v_binders_2424 = heff_take_field(v_a_2423, 0);
        V v_uses_2425 = heff_get_n(v_a_2423, 1, 2);
        V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2420), heff_dup(v_sp_2421), NTAG(TAG_False)});
        V v_b_2427 = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_lit_240, v_lit_241, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2426, v_env_242}), v_tl_2417));
        V v_binders_2428 = heff_take_field(v_b_2427, 0);
        V v_uses_2429 = heff_get_n(v_b_2427, 1, 2);
        V v_t_2430 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2420, v_sp_2421, NTAG(TAG_False)});
        V v_t_2431 = (g_prelude_2e_2b_2b(v_binders_2424, heff_tag_at_n(v_ru_24x21_2416_24At, TAG_Cons, 2, (V[]){v_t_2430, v_binders_2428})));
        V v_t_2432 = (g_prelude_2e_2b_2b(v_uses_2425, v_uses_2429));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2431, v_t_2432});
      }
      case TAG_ImplicitParam: {
        V v_x_2433 = heff_field(v_x211_2418, 0);
        V v_sp_2434 = heff_field(v_x211_2418, 1);
        V v_t_2435 = heff_field(v_x211_2418, 2);
        heff_take_n(v_x211_2418, 7ULL, 3);
        V v_a_2436 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_242), v_t_2435));
        V v_binders_2437 = heff_take_field(v_a_2436, 0);
        V v_uses_2438 = heff_get_n(v_a_2436, 1, 2);
        V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2433), heff_dup(v_sp_2434), NTAG(TAG_False)});
        V v_b_2440 = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_lit_240, v_lit_241, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2439, v_env_242}), v_tl_2417));
        V v_binders_2441 = heff_take_field(v_b_2440, 0);
        V v_uses_2442 = heff_get_n(v_b_2440, 1, 2);
        V v_t_2443 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2433, v_sp_2434, NTAG(TAG_False)});
        V v_t_2444 = (g_prelude_2e_2b_2b(v_binders_2437, heff_tag_at_n(v_ru_24x21_2416_24At, TAG_Cons, 2, (V[]){v_t_2443, v_binders_2441})));
        V v_t_2445 = (g_prelude_2e_2b_2b(v_uses_2438, v_uses_2442));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2444, v_t_2445});
      }
      default: return heff_nomatch(v_x211_2418);
      }
    }
    default: return heff_nomatch(v_x21_2416);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_env_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_246 = heff_take_field(v_acc_244, 0);
  V v_uses_247 = heff_get_n(v_acc_244, 1, 2);
  V v_b_248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_242, v_x_245));
  V v_binders_249 = heff_take_field(v_b_248, 0);
  V v_uses_2410 = heff_get_n(v_b_248, 1, 2);
  V v_t_2411 = (g_prelude_2e_2b_2b(v_binders_246, v_binders_249));
  V v_t_2412 = (g_prelude_2e_2b_2b(v_uses_247, v_uses_2410));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2411, v_t_2412});
}

HeffT2 g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(V v_lit_240, V v_env_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    V v_b_243 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_241, v_lit_240));
    V v_binders_244 = heff_take_field(v_b_243, 0);
    V v_uses_245 = heff_get_n(v_b_243, 1, 2);
    V v_f_246 = v_binders_244;
    V v_f_247 = v_uses_245;
    return ((HeffT2){{v_f_246, v_f_247}});
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_242, 0);
    V v_tl_249 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_x211_2410 = heff_field(v_x21_248, 0);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 1ULL, 2);
      switch (heff_tag_of(v_x211_2410)) {
      case TAG_ExplicitParam: {
        V v_x_2412 = heff_field(v_x211_2410, 0);
        V v_sp_2413 = heff_field(v_x211_2410, 1);
        V v_t_2414 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2415 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_241), v_t_2414));
        V v_binders_2416 = heff_take_field(v_a_2415, 0);
        V v_uses_2417 = heff_get_n(v_a_2415, 1, 2);
        V v_t_2418 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2412), heff_dup(v_sp_2413), NTAG(TAG_False)});
        HeffT2 v_t_2419 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2418, v_env_241}), v_tl_249));
        {
          V v_field_2420 = v_t_2419.f[0];
          V v_field_2421 = v_t_2419.f[1];
          V v_t_2422 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2412, v_sp_2413, NTAG(TAG_False)});
          V v_f_2423 = (g_prelude_2e_2b_2b(v_binders_2416, heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2422, v_field_2420})));
          V v_f_2424 = (g_prelude_2e_2b_2b(v_uses_2417, v_field_2421));
          return ((HeffT2){{v_f_2423, v_f_2424}});
        }
      }
      case TAG_ImplicitParam: {
        V v_x_2425 = heff_field(v_x211_2410, 0);
        V v_sp_2426 = heff_field(v_x211_2410, 1);
        V v_t_2427 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2428 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_241), v_t_2427));
        V v_binders_2429 = heff_take_field(v_a_2428, 0);
        V v_uses_2430 = heff_get_n(v_a_2428, 1, 2);
        V v_t_2431 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2425), heff_dup(v_sp_2426), NTAG(TAG_False)});
        HeffT2 v_t_2432 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2431, v_env_241}), v_tl_249));
        {
          V v_field_2433 = v_t_2432.f[0];
          V v_field_2434 = v_t_2432.f[1];
          V v_t_2435 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2425, v_sp_2426, NTAG(TAG_False)});
          V v_f_2436 = (g_prelude_2e_2b_2b(v_binders_2429, heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2435, v_field_2433})));
          V v_f_2437 = (g_prelude_2e_2b_2b(v_uses_2430, v_field_2434));
          return ((HeffT2){{v_f_2436, v_f_2437}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}
Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry, 3, 0};

V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V v_lit_240, V v_env_241, V v_x2_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, v_env_241, v_x2_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_rec_n(2, shape_binders__uses, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(a[0], a[1], a[2]);
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V v_found_240) {
top: ;
  V v_uses_241 = heff_take_field(v_found_240, 1);
  V v_binders_242 = heff_get_n(v_found_240, 0, 2);
  V v_t_243 = (g_list_2ekeepIf_24s1266148589x1647110933(v_binders_242));
  V v_f_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_uses_241)}), v_t_243));
  V v_f_247 = (g_list_2emap_24f565269645x1954016017(v_uses_241));
  return ((HeffT2){{v_f_246, v_f_247}});
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args) {
  V v_b_244 = args[0];
  V v_uses_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_list_2emap_24f1213328022x1811586494(heff_dup(v_b_244), v_uses_241));
  return heff_rec_n(3, shape_name__binder__uses, (V[]){heff_dup(heff_rfield(v_b_244, 0)), heff_get_n(v_b_244, 1, 3), v_t_245});
}
Clo g_heff_2eelab_2elocals_2elocalsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsOf_entry, 1, 0};

V g_heff_2eelab_2elocals_2elocalsOf(V v_found_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_found_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_locals__fields, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsOf(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V v_tok_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_p2_243 = heff_field(v_p_241, 1);
    heff_take_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0), 2)) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_p2_243);
        heff_drop(v_x_244);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2420));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_242, 0);
      V v_sp_2424 = heff_field(v_p1_242, 1);
      V v_q_2425 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
      V v_cell_2427 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2425, heff_dup(v_cell_2427)));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24tok2(a[0], a[1]);
}