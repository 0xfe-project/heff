// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361 38668
#define TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481 14273
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_env 310119
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_scopes 1039373258
#define LBL_span 10032145
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses__scopes[] = {LBL_binders, LBL_uses, LBL_scopes};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_span__env[] = {LBL_span, LBL_env};
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo;
HeffT3 g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V, V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo;
HeffT3 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V, V);
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo;
HeffT3 g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(V, V);
HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V, V);
V g_heff_2eelab_2elocals_2elamBinders(V);
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elamBinders_clo;
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V, V);
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V, V, V, V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
HeffT3 g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(V, V);
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24dps(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo;
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V, V);
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo;
V g_heff_2eelab_2elocals_2eunshadowed(V, V);
V g_heff_2eelab_2elocals_2eunshadowed_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2eunshadowed_clo;
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_list_2eany_24s166327466x268514900(V, V);
V g_list_2eany_24s166327466x268514900_entry(V self, V *a);
extern Clo g_list_2eany_24s166327466x268514900_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s884736396x2007513852(V, V);
V g_list_2efoldl_24s884736396x2007513852_entry(V self, V *a);
extern Clo g_list_2efoldl_24s884736396x2007513852_clo;
V g_list_2ekeepIf_24s1266148589x1647110933(V);
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1213328022x1811586494(V, V);
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_clo;
V g_list_2emap_24f565269645x1954016017(V);
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_REC_LIT(g_heff_2eelab_2elocals_2enone_lit0, 3, shape_binders__uses__scopes, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2eelab_2elocals_2enone_val;
static HEFF_ONCE g_heff_2eelab_2elocals_2enone_st;
static V g_heff_2eelab_2elocals_2enone_init(void) {
  return ((V)&g_heff_2eelab_2elocals_2enone_lit0);
}
V g_heff_2eelab_2elocals_2enone_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2elocals_2enone_st)) return g_heff_2eelab_2elocals_2enone_val;
  return heff_global(&g_heff_2eelab_2elocals_2enone_val, &g_heff_2eelab_2elocals_2enone_st, g_heff_2eelab_2elocals_2enone_init);
}

HeffT2 g_heff_2eelab_2elocals_2efindBinder_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_b_242, 0)), heff_dup(v_x_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_b_242)}});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_p2_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2eelab_2elocals_2epatternBinders_str0), 2)) {
        heff_drop(v_p2_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_244 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_243, v_p2_242, NTAG(TAG_False)});
        return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_247));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2411 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2416 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2416));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2417); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2419 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2419));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2420); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2422 = heff_field(v_p1_241, 0);
      V v_sp_2423 = heff_field(v_p1_241, 1);
      V v_q_2424 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop(v_p2_242);
      V v_t_2425 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2422, v_sp_2423, NTAG(TAG_False)});
      V v_cell_2426 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
      V v_u_2427 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2424, v_cell_2426));
      heff_drop(v_u_2427);
      return v_cell_2426;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24dps_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24dps_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_p2_243 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24dps_str0), 2)) {
        heff_drop(v_p2_243);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        V v_t_246 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
        return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_246);
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2411);
    }
    case TAG_PatOp: {
      V v_ps_2414 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2414));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2416);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2420));
      V v_t_2422 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2421); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2422);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2424 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2425); r_; });
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2426);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_p2_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2428 = heff_field(v_p1_242, 0);
      V v_sp_2429 = heff_field(v_p1_242, 1);
      V v_q_2430 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2431 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2428, v_sp_2429, NTAG(TAG_False)});
      V v_cell_2432 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2431, heff_hole()});
      V v_u_2433 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2432);
      V t_0 = v_q_2430;
      V t_1 = v_u_2433;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2epatternBinders_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str1, 1, "_");
Clo g_heff_2eelab_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_241, ((V)&g_heff_2eelab_2elocals_2elamBinders_str0), 2)) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_243 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_sp_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2elamBinders_str1), 2)) {
      heff_drop(v_x_244);
      heff_drop(v_sp_245);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_245, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_247 = heff_field(v_x1_240, 0);
    V v_sp_248 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2410 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_247, v_sp_248, NTAG(TAG_False)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry, 2, 0};

V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_a_248));
        V v_binders_2411 = heff_take_field(v_a_2410, 0);
        V v_uses_2412 = heff_take_field(v_a_2410, 1);
        V v_scopes_2413 = heff_get_n(v_a_2410, 2, 3);
        V v_b_2415;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2415 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2414 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2415 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_2414));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_binders_2416 = heff_take_field(v_b_2415, 0);
        V v_uses_2417 = heff_take_field(v_b_2415, 1);
        V v_scopes_2418 = heff_get_n(v_b_2415, 2, 3);
        V v_t_2419 = (g_prelude_2e_2b_2b(v_binders_2411, v_binders_2416));
        V v_t_2420 = (g_prelude_2e_2b_2b(v_uses_2412, v_uses_2417));
        V v_t_2421 = (g_prelude_2e_2b_2b(v_scopes_2413, v_scopes_2418));
        V v_t_2422 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2423 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2422, v_env_240}), v_rest_243));
        V v_binders_2424 = heff_take_field(v_b_2423, 0);
        V v_uses_2425 = heff_take_field(v_b_2423, 1);
        V v_scopes_2426 = heff_take_field(v_b_2423, 2);
        V v_t_2427 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2419, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2427, v_binders_2424})));
        V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2420, v_uses_2425));
        V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2421, v_scopes_2426));
        return ({ V rv_0 = v_t_2428; V rv_1 = v_t_2429; V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_b_2423, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      case TAG_BadFieldDecl: {
        V v_f_2431 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2432 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_f_2431));
        V v_binders_2433 = heff_take_field(v_a_2432, 0);
        V v_uses_2434 = heff_take_field(v_a_2432, 1);
        V v_scopes_2435 = heff_get_n(v_a_2432, 2, 3);
        V v_b_2436 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_rest_243));
        V v_binders_2437 = heff_take_field(v_b_2436, 0);
        V v_uses_2438 = heff_take_field(v_b_2436, 1);
        V v_scopes_2439 = heff_take_field(v_b_2436, 2);
        V v_t_2440 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2433, v_binders_2437));
        V v_t_2441 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2434, v_uses_2438));
        V v_t_2442 = (g_prelude_2e_2b_2b(v_scopes_2435, v_scopes_2439));
        return ({ V rv_0 = v_t_2440; V rv_1 = v_t_2441; V rv_2 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_b_2436, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry, 2, 0};

V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_248));
        V v_binders_2410 = heff_take_field(v_a_249, 0);
        V v_uses_2411 = heff_take_field(v_a_249, 1);
        V v_scopes_2412 = heff_get_n(v_a_249, 2, 3);
        V v_t_2413 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2414 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_env_240}), v_rest_243));
        V v_binders_2415 = heff_take_field(v_b_2414, 0);
        V v_uses_2416 = heff_take_field(v_b_2414, 1);
        V v_scopes_2417 = heff_take_field(v_b_2414, 2);
        V v_t_2418 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2419 = (g_prelude_2e_2b_2b(v_binders_2410, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2418, v_binders_2415})));
        V v_t_2420 = (g_prelude_2e_2b_2b(v_uses_2411, v_uses_2416));
        V v_t_2421 = (g_prelude_2e_2b_2b(v_scopes_2412, v_scopes_2417));
        return ({ V rv_0 = v_t_2419; V rv_1 = v_t_2420; V rv_2 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_b_2414, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      case TAG_StmtLet: {
        V v_p_2422 = heff_field(v_x311_244, 0);
        V v_e_2423 = heff_field(v_x311_244, 1);
        V v_ru_24x311_244_24StmtLet = heff_take_reuse_n(v_x311_244, 3ULL, 2);
        V v_a_2424 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_2423));
        V v_binders_2425 = heff_take_field(v_a_2424, 0);
        V v_uses_2426 = heff_take_field(v_a_2424, 1);
        V v_scopes_2427 = heff_get_n(v_a_2424, 2, 3);
        V v_bs_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2422)));
        V v_env_2429 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2422));
        V v_b_2430 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2429, v_rest_243));
        V v_binders_2431 = heff_take_field(v_b_2430, 0);
        V v_uses_2432 = heff_take_field(v_b_2430, 1);
        V v_scopes_2433 = heff_take_field(v_b_2430, 2);
        V v_t_2434 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2428, v_binders_2431));
        V v_t_2435 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x311_244_24StmtLet, v_binders_2425, v_t_2434));
        V v_t_2436 = (g_prelude_2e_2b_2b(v_uses_2426, v_uses_2432));
        V v_t_2437 = (g_prelude_2e_2b_2b(v_scopes_2427, v_scopes_2433));
        return ({ V rv_0 = v_t_2435; V rv_1 = v_t_2436; V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_b_2430, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      case TAG_StmtExpr: {
        V v_e_2438 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        V v_a_2439 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_2438));
        V v_binders_2440 = heff_take_field(v_a_2439, 0);
        V v_uses_2441 = heff_take_field(v_a_2439, 1);
        V v_scopes_2442 = heff_get_n(v_a_2439, 2, 3);
        V v_b_2443 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_rest_243));
        V v_binders_2444 = heff_take_field(v_b_2443, 0);
        V v_uses_2445 = heff_take_field(v_b_2443, 1);
        V v_scopes_2446 = heff_take_field(v_b_2443, 2);
        V v_t_2447 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_binders_2440, v_binders_2444));
        V v_t_2448 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_uses_2441, v_uses_2445));
        V v_t_2449 = (g_prelude_2e_2b_2b(v_scopes_2442, v_scopes_2446));
        return ({ V rv_0 = v_t_2447; V rv_1 = v_t_2448; V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_b_2443, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      case TAG_StmtLetMut: {
        V v_x_2450 = heff_field(v_x311_244, 0);
        V v_sp_2451 = heff_field(v_x311_244, 1);
        V v_e_2452 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2453 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_2452));
        V v_binders_2454 = heff_take_field(v_a_2453, 0);
        V v_uses_2455 = heff_take_field(v_a_2453, 1);
        V v_scopes_2456 = heff_get_n(v_a_2453, 2, 3);
        V v_t_2457 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2450), heff_dup(v_sp_2451), NTAG(TAG_False)});
        V v_b_2458 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2457, v_env_240}), v_rest_243));
        V v_binders_2459 = heff_take_field(v_b_2458, 0);
        V v_uses_2460 = heff_take_field(v_b_2458, 1);
        V v_scopes_2461 = heff_take_field(v_b_2458, 2);
        V v_t_2462 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2450, v_sp_2451, NTAG(TAG_False)});
        V v_t_2463 = (g_prelude_2e_2b_2b(v_binders_2454, heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2462, v_binders_2459})));
        V v_t_2464 = (g_prelude_2e_2b_2b(v_uses_2455, v_uses_2460));
        V v_t_2465 = (g_prelude_2e_2b_2b(v_scopes_2456, v_scopes_2461));
        return ({ V rv_0 = v_t_2463; V rv_1 = v_t_2464; V rv_2 = v_t_2465; V rr_ = heff_rec_reuse_nf(v_b_2458, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      case TAG_StmtLetElse: {
        V v_p_2466 = heff_field(v_x311_244, 0);
        V v_e_2467 = heff_field(v_x311_244, 1);
        V v_ss_2468 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_2469 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_2467));
        V v_binders_2470 = heff_take_field(v_a_2469, 0);
        V v_uses_2471 = heff_take_field(v_a_2469, 1);
        V v_scopes_2472 = heff_get_n(v_a_2469, 2, 3);
        V v_a_2473 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_240), v_ss_2468));
        V v_binders_2474 = heff_take_field(v_a_2473, 0);
        V v_uses_2475 = heff_take_field(v_a_2473, 1);
        V v_scopes_2476 = heff_get_n(v_a_2473, 2, 3);
        V v_bs_2477 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24x3_241_24Cons, heff_dup(v_p_2466)));
        V v_env_2478 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2466));
        V v_b_2479 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2478, v_rest_243));
        V v_binders_2480 = heff_take_field(v_b_2479, 0);
        V v_uses_2481 = heff_take_field(v_b_2479, 1);
        V v_scopes_2482 = heff_take_field(v_b_2479, 2);
        V v_t_2483 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_242_24At, v_bs_2477, v_binders_2480));
        V v_t_2484 = (g_prelude_2e_2b_2b(v_binders_2474, v_t_2483));
        V v_t_2485 = (g_prelude_2e_2b_2b(v_uses_2475, v_uses_2481));
        V v_t_2486 = (g_prelude_2e_2b_2b(v_scopes_2476, v_scopes_2482));
        V v_t_2487 = (g_prelude_2e_2b_2b(v_binders_2470, v_t_2484));
        V v_t_2488 = (g_prelude_2e_2b_2b(v_uses_2471, v_t_2485));
        V v_t_2489 = (g_prelude_2e_2b_2b(v_scopes_2472, v_t_2486));
        return ({ V rv_0 = v_t_2487; V rv_1 = v_t_2488; V rv_2 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_b_2479, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(a[0], a[1]);
}

HeffT3 g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = ({ V a_0 = v_env_2410; V a_1 = heff_dup(v_rhs_247); V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_2410); r_; });
      V v_binders_2412 = heff_take_field(v_b_2411, 0);
      V v_uses_2413 = heff_take_field(v_b_2411, 1);
      V v_scopes_2414 = heff_get_n(v_b_2411, 2, 3);
      V v_t_2415 = (g_prelude_2e_2b_2b(v_bs_249, v_binders_2412));
      V v_f_2416 = v_uses_2413;
      V v_f_2417 = v_scopes_2414;
      return ((HeffT3){{v_t_2415, v_f_2416, v_f_2417}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}

HeffT3 g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_t_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_247 = ({ V a_0 = v_x_244; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_244); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_a_2412;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_b_2410 = v_field_249;
          V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2410, v_xsp_245}), NTAG(TAG_Nil)});
          v_a_2412 = heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_2411, NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_245);
          heff_drop(v_field_249);
          v_a_2412 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2413 = heff_take_field(v_a_2412, 0);
        V v_uses_2414 = heff_take_field(v_a_2412, 1);
        V v_scopes_2415 = heff_get_n(v_a_2412, 2, 3);
        V v_b_2416 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_246));
        V v_binders_2417 = heff_take_field(v_b_2416, 0);
        V v_uses_2418 = heff_take_field(v_b_2416, 1);
        V v_scopes_2419 = heff_get_n(v_b_2416, 2, 3);
        V v_t_2420 = (g_prelude_2e_2b_2b(v_binders_2413, v_binders_2417));
        V v_t_2421 = (g_prelude_2e_2b_2b(v_uses_2414, v_uses_2418));
        V v_t_2422 = (g_prelude_2e_2b_2b(v_scopes_2415, v_scopes_2419));
        return ((HeffT3){{v_t_2420, v_t_2421, v_t_2422}});
      }
    }
    case TAG_ImplicitParam: {
      V v_x_2423 = heff_field(v_x31_242, 0);
      V v_xsp_2424 = heff_field(v_x31_242, 1);
      V v_t_2425 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_2426 = ({ V a_0 = v_x_2423; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2423); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        V v_a_2431;
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_b_2429 = v_field_2428;
          V v_t_2430 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2429, v_xsp_2424}), NTAG(TAG_Nil)});
          v_a_2431 = heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_2430, NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2424);
          heff_drop(v_field_2428);
          v_a_2431 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2432 = heff_take_field(v_a_2431, 0);
        V v_uses_2433 = heff_take_field(v_a_2431, 1);
        V v_scopes_2434 = heff_get_n(v_a_2431, 2, 3);
        V v_b_2435 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2425));
        V v_binders_2436 = heff_take_field(v_b_2435, 0);
        V v_uses_2437 = heff_take_field(v_b_2435, 1);
        V v_scopes_2438 = heff_get_n(v_b_2435, 2, 3);
        V v_t_2439 = (g_prelude_2e_2b_2b(v_binders_2432, v_binders_2436));
        V v_t_2440 = (g_prelude_2e_2b_2b(v_uses_2433, v_uses_2437));
        V v_t_2441 = (g_prelude_2e_2b_2b(v_scopes_2434, v_scopes_2438));
        return ((HeffT3){{v_t_2439, v_t_2440, v_t_2441}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry, 2, 0};

V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x31_242, 0);
      V v_fsp_245 = heff_field(v_x31_242, 1);
      V v_ty_247 = heff_field(v_x31_242, 3);
      V v_eqs_248 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 27ULL, 5);
      HeffT2 v_t_249 = ({ V a_0 = v_f_244; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_244); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_a_2414;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_b_2412 = v_field_2411;
          V v_t_2413 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2412, v_fsp_245}), NTAG(TAG_Nil)});
          v_a_2414 = heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_2413, NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_fsp_245);
          heff_drop(v_field_2411);
          v_a_2414 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2415 = heff_take_field(v_a_2414, 0);
        V v_uses_2416 = heff_take_field(v_a_2414, 1);
        V v_scopes_2417 = heff_get_n(v_a_2414, 2, 3);
        V v_a_2418 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_ty_247));
        V v_binders_2419 = heff_take_field(v_a_2418, 0);
        V v_uses_2420 = heff_take_field(v_a_2418, 1);
        V v_scopes_2421 = heff_get_n(v_a_2418, 2, 3);
        V v_b_2434 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_eqs_248); r_; });
        V v_binders_2435 = heff_take_field(v_b_2434, 0);
        V v_uses_2436 = heff_take_field(v_b_2434, 1);
        V v_scopes_2437 = heff_take_field(v_b_2434, 2);
        V v_t_2438 = (g_prelude_2e_2b_2b(v_binders_2419, v_binders_2435));
        V v_t_2439 = (g_prelude_2e_2b_2b(v_uses_2420, v_uses_2436));
        V v_t_2440 = (g_prelude_2e_2b_2b(v_scopes_2421, v_scopes_2437));
        V v_t_2441 = (g_prelude_2e_2b_2b(v_binders_2415, v_t_2438));
        V v_t_2442 = (g_prelude_2e_2b_2b(v_uses_2416, v_t_2439));
        V v_t_2443 = (g_prelude_2e_2b_2b(v_scopes_2417, v_t_2440));
        return ({ V rv_0 = v_t_2441; V rv_1 = v_t_2442; V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_b_2434, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    case TAG_DeclDefine: {
      V v_x_2444 = heff_field(v_x31_242, 0);
      V v_xsp_2445 = heff_field(v_x31_242, 1);
      V v_ps_2446 = heff_field(v_x31_242, 2);
      V v_u_2447 = heff_field(v_x31_242, 3);
      V v_body_2448 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 31ULL, 5);
      HeffT2 v_t_2449 = ({ V a_0 = v_x_2444; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2444); r_; });
      {
        V v_field_2451 = v_t_2449.f[1];
        int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
        V v_a_2454;
        if ((v_tag_2450 == ((int64_t)0ULL))) {
          V v_b_2452 = v_field_2451;
          V v_t_2453 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2452, v_xsp_2445}), NTAG(TAG_Nil)});
          v_a_2454 = heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_2453, NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2445);
          heff_drop(v_field_2451);
          v_a_2454 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_2455 = heff_take_field(v_a_2454, 0);
        V v_uses_2456 = heff_take_field(v_a_2454, 1);
        V v_scopes_2457 = heff_get_n(v_a_2454, 2, 3);
        V v_a_2470 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_ps_2446; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_ps_2446); r_; });
        V v_binders_2471 = heff_take_field(v_a_2470, 0);
        V v_uses_2472 = heff_take_field(v_a_2470, 1);
        V v_scopes_2473 = heff_get_n(v_a_2470, 2, 3);
        V v_a_2474 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_u_2447));
        V v_binders_2475 = heff_take_field(v_a_2474, 0);
        V v_uses_2476 = heff_take_field(v_a_2474, 1);
        V v_scopes_2477 = heff_get_n(v_a_2474, 2, 3);
        V v_b_2478 = ({ V a_0 = v_env_240; V a_1 = v_body_2448; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_240); r_; });
        V v_binders_2479 = heff_take_field(v_b_2478, 0);
        V v_uses_2480 = heff_take_field(v_b_2478, 1);
        V v_scopes_2481 = heff_take_field(v_b_2478, 2);
        V v_t_2482 = (g_prelude_2e_2b_2b(v_binders_2475, v_binders_2479));
        V v_t_2483 = (g_prelude_2e_2b_2b(v_uses_2476, v_uses_2480));
        V v_t_2484 = (g_prelude_2e_2b_2b(v_scopes_2477, v_scopes_2481));
        V v_t_2485 = (g_prelude_2e_2b_2b(v_binders_2471, v_t_2482));
        V v_t_2486 = (g_prelude_2e_2b_2b(v_uses_2472, v_t_2483));
        V v_t_2487 = (g_prelude_2e_2b_2b(v_scopes_2473, v_t_2484));
        V v_t_2488 = (g_prelude_2e_2b_2b(v_binders_2455, v_t_2485));
        V v_t_2489 = (g_prelude_2e_2b_2b(v_uses_2456, v_t_2486));
        V v_t_2490 = (g_prelude_2e_2b_2b(v_scopes_2457, v_t_2487));
        return ({ V rv_0 = v_t_2488; V rv_1 = v_t_2489; V rv_2 = v_t_2490; V rr_ = heff_rec_reuse_nf(v_b_2478, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    case TAG_DeclTheory: {
      V v_body_2494 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      return ({ V a_0 = v_env_240; V a_1 = v_body_2494; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_240); r_; });
    }
    case TAG_DeclPrimitive: {
      V v_x_2495 = heff_field(v_x31_242, 0);
      V v_xsp_2496 = heff_field(v_x31_242, 1);
      V v_t_2497 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      HeffT2 v_t_2498 = ({ V a_0 = v_x_2495; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2495); r_; });
      {
        V v_field_24100 = v_t_2498.f[1];
        int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
        V v_a_24103;
        if ((v_tag_2499 == ((int64_t)0ULL))) {
          V v_b_24101 = v_field_24100;
          V v_t_24102 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24101, v_xsp_2496}), NTAG(TAG_Nil)});
          v_a_24103 = heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_24102, NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_2496);
          heff_drop(v_field_24100);
          v_a_24103 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        V v_binders_24104 = heff_take_field(v_a_24103, 0);
        V v_uses_24105 = heff_take_field(v_a_24103, 1);
        V v_scopes_24106 = heff_get_n(v_a_24103, 2, 3);
        V v_b_24107 = ({ V a_0 = v_env_240; V a_1 = v_t_2497; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_240); r_; });
        V v_binders_24108 = heff_take_field(v_b_24107, 0);
        V v_uses_24109 = heff_take_field(v_b_24107, 1);
        V v_scopes_24110 = heff_take_field(v_b_24107, 2);
        V v_t_24111 = (g_prelude_2e_2b_2b(v_binders_24104, v_binders_24108));
        V v_t_24112 = (g_prelude_2e_2b_2b(v_uses_24105, v_uses_24109));
        V v_t_24113 = (g_prelude_2e_2b_2b(v_scopes_24106, v_scopes_24110));
        return ({ V rv_0 = v_t_24111; V rv_1 = v_t_24112; V rv_2 = v_t_24113; V rr_ = heff_rec_reuse_nf(v_b_24107, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    case TAG_DeclTest: {
      V v_x_24114 = heff_field(v_x31_242, 0);
      V v_xsp_24115 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      HeffT2 v_t_24116 = ({ V a_0 = v_x_24114; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24114); heff_drop(v_env_240); r_; });
      {
        V v_field_24118 = v_t_24116.f[1];
        int64_t v_tag_24117 = ((int64_t)v_t_24116.f[0]);
        if ((v_tag_24117 == ((int64_t)0ULL))) {
          V v_b_24119 = v_field_24118;
          V v_t_24120 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24119, v_xsp_24115}), NTAG(TAG_Nil)});
          return heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_24120, NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop(v_xsp_24115);
          heff_drop(v_field_24118);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
    }
    case TAG_DeclWatch: {
      V v_e_24121 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      return ({ V a_0 = v_env_240; V a_1 = v_e_24121; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_240); r_; });
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args) {
  V v_acc_2422 = args[0];
  V v_eq_2423 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_binders_2424 = heff_take_field(v_acc_2422, 0);
  V v_uses_2425 = heff_take_field(v_acc_2422, 1);
  V v_scopes_2426 = heff_take_field(v_acc_2422, 2);
  heff_clo_take(self, 1);
  HeffT3 v_t_2427 = ({ V a_0 = v_env_240; V a_1 = v_eq_2423; HeffT3 r_ = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(a_0, a_1)); heff_drop(v_eq_2423); r_; });
  {
    V v_field_2428 = v_t_2427.f[0];
    V v_field_2429 = v_t_2427.f[1];
    V v_field_2430 = v_t_2427.f[2];
    V v_t_2431 = (g_prelude_2e_2b_2b(v_binders_2424, v_field_2428));
    V v_t_2432 = (g_prelude_2e_2b_2b(v_uses_2425, v_field_2429));
    V v_t_2433 = (g_prelude_2e_2b_2b(v_scopes_2426, v_field_2430));
    return ({ V rv_0 = v_t_2431; V rv_1 = v_t_2432; V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_acc_2422, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args) {
  V v_acc_2458 = args[0];
  V v_m_2459 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_binders_2460 = heff_take_field(v_acc_2458, 0);
  V v_uses_2461 = heff_take_field(v_acc_2458, 1);
  V v_scopes_2462 = heff_take_field(v_acc_2458, 2);
  heff_clo_take(self, 1);
  HeffT3 v_t_2463 = ({ V a_0 = v_env_240; V a_1 = v_m_2459; HeffT3 r_ = (g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_24cpr(a_0, a_1)); heff_drop(v_env_240); r_; });
  {
    V v_field_2464 = v_t_2463.f[0];
    V v_field_2465 = v_t_2463.f[1];
    V v_field_2466 = v_t_2463.f[2];
    V v_t_2467 = (g_prelude_2e_2b_2b(v_binders_2460, v_field_2464));
    V v_t_2468 = (g_prelude_2e_2b_2b(v_uses_2461, v_field_2465));
    V v_t_2469 = (g_prelude_2e_2b_2b(v_scopes_2462, v_field_2466));
    return ({ V rv_0 = v_t_2467; V rv_1 = v_t_2468; V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_acc_2458, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry, 2, 0};

V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      heff_take_n(v_d1_242, 24ULL, 5);
      switch (heff_tag_of(v_d_241)) {
      case TAG_At: {
        V v_ru_24d_241_24At = heff_take_reuse_n(v_d_241, 0ULL, 2);
        V v_a_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, heff_dup(v_ty_247)));
        V v_binders_2412 = heff_take_field(v_a_2411, 0);
        V v_uses_2413 = heff_take_field(v_a_2411, 1);
        V v_scopes_2414 = heff_get_n(v_a_2411, 2, 3);
        V v_b_2446 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_eqs_248); r_; });
        V v_binders_2447 = heff_take_field(v_b_2446, 0);
        V v_uses_2448 = heff_take_field(v_b_2446, 1);
        V v_scopes_2449 = heff_take_field(v_b_2446, 2);
        V v_t_2450 = (g_prelude_2e_2b_2b_24tok2(v_ru_24d_241_24At, v_binders_2412, v_binders_2447));
        V v_t_2451 = (g_prelude_2e_2b_2b(v_uses_2413, v_uses_2448));
        V v_t_2452 = (g_prelude_2e_2b_2b(v_scopes_2414, v_scopes_2449));
        return ({ V rv_0 = v_t_2450; V rv_1 = v_t_2451; V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_b_2446, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      default: return heff_nomatch(v_d_241);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_d1_242, 0ULL, 5);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_d1_242, 0ULL, 4);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_d1_242, 0ULL, 3);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_d1_242, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args) {
  V v_acc_2415 = args[0];
  V v_eq_2416 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  V v_binders_2417 = heff_take_field(v_acc_2415, 0);
  V v_uses_2418 = heff_take_field(v_acc_2415, 1);
  V v_scopes_2419 = heff_take_field(v_acc_2415, 2);
  V v_a_2431;
  switch (heff_tag_of(v_eq_2416)) {
  case TAG_At: {
    V v_x21_2420 = heff_dup(heff_field(v_eq_2416, 0));
    switch (heff_tag_of(v_x21_2420)) {
    case TAG_MkEquation: {
      V v_f_2422 = heff_field(v_x21_2420, 0);
      V v_fsp_2423 = heff_field(v_x21_2420, 1);
      heff_take_n(v_x21_2420, 3ULL, 4);
      HeffT2 v_t_2426 = ({ V a_0 = v_f_2422; V a_1 = v_env_240; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_f_2422); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_b_2429 = v_field_2428;
          V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2429, v_fsp_2423}), NTAG(TAG_Nil)});
          v_a_2431 = ({ V rv_0 = NTAG(TAG_Nil); V rv_1 = v_t_2430; V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_acc_2415, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        } else {
          heff_drop_rec(v_acc_2415, 3);
          heff_drop(v_fsp_2423);
          heff_drop(v_field_2428);
          v_a_2431 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
      }
      break;
    }
    default: heff_nomatch(v_x21_2420);
    }
    break;
  }
  default: heff_nomatch(v_eq_2416);
  }
  V v_binders_2432 = heff_take_field(v_a_2431, 0);
  V v_uses_2433 = heff_take_field(v_a_2431, 1);
  V v_scopes_2434 = heff_take_field(v_a_2431, 2);
  heff_clo_take(self, 2);
  V v_t_2435 = (g_list_2efoldl_24f1488358745x465096512(v_env_240, v_ty_247));
  HeffT3 v_t_2436 = ({ V a_0 = v_t_2435; V a_1 = v_eq_2416; HeffT3 r_ = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_24cpr(a_0, a_1)); heff_drop(v_eq_2416); r_; });
  {
    V v_field_2437 = v_t_2436.f[0];
    V v_field_2438 = v_t_2436.f[1];
    V v_field_2439 = v_t_2436.f[2];
    V v_t_2440 = (g_prelude_2e_2b_2b(v_binders_2432, v_field_2437));
    V v_t_2441 = (g_prelude_2e_2b_2b(v_uses_2433, v_field_2438));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_scopes_2434, v_field_2439));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_binders_2417, v_t_2440));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_uses_2418, v_t_2441));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_scopes_2419, v_t_2442));
    return ({ V rv_0 = v_t_2443; V rv_1 = v_t_2444; V rv_2 = v_t_2445; V rr_ = heff_rec_reuse_nf(v_a_2431, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4, 0, "");
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam7(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry, 6, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(V v_tag_240, V v_env_241, V v_x3_242, V v_body_243, V v_env_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: {
    top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361: ;
    heff_drop(v_n_245);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
      V t_1 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str1);
      V t_3 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str2);
      V t_4 = v_env_241;
      V t_5 = v_body_243;
      v_tag_240 = t_0;
      v_env_241 = t_1;
      v_x3_242 = t_2;
      v_body_243 = t_3;
      v_env_244 = t_4;
      v_n_245 = t_5;
      goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
    }
    case TAG_Cons: {
      V v_d_246 = heff_field(v_x3_242, 0);
      V v_ds_247 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2431;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_248 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_248)) {
        case TAG_DeclEquations: {
          V v_f_2410 = heff_field(v_d1_248, 0);
          V v_fsp_2411 = heff_field(v_d1_248, 1);
          heff_take_n(v_d1_248, 3ULL, 5);
          V v_t_2415 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2410, v_fsp_2411, NTAG(TAG_False)});
          v_t_2431 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_248, 0ULL, 5);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_248, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_248, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_248, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_248, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_2431 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_248);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2455;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2432 = heff_dup(heff_field(v_d_246, 0));
        switch (heff_tag_of(v_d1_2432)) {
        case TAG_DeclEquations: {
          V v_f_2434 = heff_field(v_d1_2432, 0);
          V v_fsp_2435 = heff_field(v_d1_2432, 1);
          heff_take_n(v_d1_2432, 3ULL, 5);
          V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2434, v_fsp_2435, NTAG(TAG_False)});
          v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2432, 0ULL, 5);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2432, 0ULL, 4);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2432, 0ULL, 3);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2432, 0ULL, 2);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2432, 0ULL, 1);
          v_t_2455 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2432);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_241), v_t_2455));
      V v_a_2457 = (g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(v_t_2456, heff_dup(v_d_246)));
      V v_binders_2458 = heff_take_field(v_a_2457, 0);
      V v_uses_2459 = heff_take_field(v_a_2457, 1);
      V v_scopes_2460 = heff_get_n(v_a_2457, 2, 3);
      V v_t_2484;
      switch (heff_tag_of(v_d_246)) {
      case TAG_At: {
        V v_d1_2461 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24At = heff_take_reuse_n(v_d_246, 1ULL, 2);
        switch (heff_tag_of(v_d1_2461)) {
        case TAG_DeclEquations: {
          V v_f_2463 = heff_field(v_d1_2461, 0);
          V v_fsp_2464 = heff_field(v_d1_2461, 1);
          heff_take_n(v_d1_2461, 3ULL, 5);
          V v_t_2468 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2463, v_fsp_2464, NTAG(TAG_False)});
          v_t_2484 = heff_tag_at_n(v_ru_24d_246_24At, TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_d1_2461, 0ULL, 5);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2484 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_d1_2461, 0ULL, 4);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2484 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_d1_2461, 0ULL, 3);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2484 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_d1_2461, 0ULL, 2);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2484 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_d1_2461, 0ULL, 1);
          heff_drop_cell(v_ru_24d_246_24At, 2);
          v_t_2484 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d1_2461);
        }
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      V v_t_2485 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_241), v_t_2484));
      V v_b_2486 = ({ V a_0 = v_t_2485; V a_1 = v_ds_247; V a_2 = v_body_243; V r_ = (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a_0, a_1, a_2)); heff_drop(v_t_2485); r_; });
      V v_binders_2487 = heff_take_field(v_b_2486, 0);
      V v_uses_2488 = heff_take_field(v_b_2486, 1);
      V v_scopes_2489 = heff_take_field(v_b_2486, 2);
      V v_t_2490 = (g_prelude_2e_2b_2b(v_binders_2458, v_binders_2487));
      V v_t_2491 = (g_prelude_2e_2b_2b(v_uses_2459, v_uses_2488));
      V v_t_2492 = (g_prelude_2e_2b_2b(v_scopes_2460, v_scopes_2489));
      V v_t_2493 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2490));
      return ({ V rv_0 = v_t_2493; V rv_1 = v_t_2491; V rv_2 = v_t_2492; V rr_ = heff_rec_reuse_nf(v_b_2486, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: {
    top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481: ;
    switch (heff_tag_of(v_n_245)) {
    case TAG_At: {
      V v_n1_2494 = heff_dup(heff_field(v_n_245, 0));
      switch (heff_tag_of(v_n1_2494)) {
      case TAG_EVar: {
        V v_x_2496 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        HeffT2 v_t_2497 = ({ V a_0 = v_x_2496; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_2496); r_; });
        {
          V v_field_2499 = v_t_2497.f[1];
          int64_t v_tag_2498 = ((int64_t)v_t_2497.f[0]);
          V v_a_24105;
          if ((v_tag_2498 == ((int64_t)0ULL))) {
            V v_b_24100 = v_field_2499;
            V v_t_24103;
            switch (heff_tag_of(v_n_245)) {
            case TAG_At: {
              V v_s_24102 = heff_dup(heff_field(v_n_245, 1));
              v_t_24103 = v_s_24102;
              break;
            }
            default: heff_nomatch(v_n_245);
            }
            V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24100, v_t_24103}), NTAG(TAG_Nil)});
            v_a_24105 = heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_24104, NTAG(TAG_Nil)});
          } else {
            heff_drop(v_field_2499);
            v_a_24105 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          }
          V v_binders_24106 = heff_take_field(v_a_24105, 0);
          V v_uses_24107 = heff_take_field(v_a_24105, 1);
          V v_scopes_24108 = heff_take_field(v_a_24105, 2);
          V v_t_24109 = (g_prelude_2e_2b_2b(v_binders_24106, NTAG(TAG_Nil)));
          V v_t_24110 = (g_prelude_2e_2b_2b(v_uses_24107, NTAG(TAG_Nil)));
          V v_t_24113;
          switch (heff_tag_of(v_n_245)) {
          case TAG_At: {
            V v_s_24112 = heff_field(v_n_245, 1);
            heff_take_n(v_n_245, 2ULL, 2);
            v_t_24113 = v_s_24112;
            break;
          }
          default: heff_nomatch(v_n_245);
          }
          V v_t_24114 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_span__env, (V[]){v_t_24113, heff_dup(v_env_244)}), NTAG(TAG_Nil)});
          V v_t_24115 = (g_prelude_2e_2b_2b(v_scopes_24108, v_t_24114));
          return ({ V rv_0 = v_t_24109; V rv_1 = v_t_24110; V rv_2 = v_t_24115; V rr_ = heff_rec_reuse_nf(v_a_24105, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENotationVar: {
        heff_take_n(v_n1_2494, 0ULL, 3);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETag: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInt: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFloat: {
        heff_take_nf(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EString: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBinary: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ERune: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWord: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EApp: {
        V v_h_24145 = heff_field(v_n1_2494, 0);
        V v_args_24146 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24EApp = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24149 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_h_24145));
          V v_binders_24150 = heff_take_field(v_a_24149, 0);
          V v_uses_24151 = heff_take_field(v_a_24149, 1);
          V v_scopes_24152 = heff_get_n(v_a_24149, 2, 3);
          V v_b_24165 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0, 2, 1, (V[]){heff_dup(v_env_244)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24146; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_args_24146); r_; });
          V v_binders_24166 = heff_take_field(v_b_24165, 0);
          V v_uses_24167 = heff_take_field(v_b_24165, 1);
          V v_scopes_24168 = heff_take_field(v_b_24165, 2);
          V v_t_24169 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24EApp, v_binders_24150, v_binders_24166));
          V v_t_24170 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24151, v_uses_24167));
          V v_t_24171 = (g_prelude_2e_2b_2b(v_scopes_24152, v_scopes_24168));
          return ({ V rv_0 = v_t_24169; V rv_1 = v_t_24170; V rv_2 = v_t_24171; V rr_ = heff_rec_reuse_nf(v_b_24165, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EProject: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENamed: {
        V v_e_24176 = heff_field(v_n1_2494, 1);
        heff_take_n(v_n1_2494, 2ULL, 2);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24176;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EPi: {
        V v_n11_24179 = heff_field(v_n1_2494, 0);
        V v_r_24180 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24EPi = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24179)) {
          case TAG_PiNamed: {
            V v_x_24183 = heff_field(v_n11_24179, 0);
            V v_sp_24184 = heff_field(v_n11_24179, 1);
            V v_a_24185 = heff_field(v_n11_24179, 2);
            heff_take_n(v_n11_24179, 7ULL, 3);
            V v_a_24186 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24185));
            V v_binders_24187 = heff_take_field(v_a_24186, 0);
            V v_uses_24188 = heff_take_field(v_a_24186, 1);
            V v_scopes_24189 = heff_get_n(v_a_24186, 2, 3);
            V v_t_24190 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24183), heff_dup(v_sp_24184), NTAG(TAG_False)});
            V v_b_24191 = ({ V b_0 = heff_tag_at_n(v_ru_24n1_2494_24EPi, TAG_Cons, 2, (V[]){v_t_24190, heff_dup(v_env_244)}); V a_1 = v_r_24180; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(b_0, a_1)); heff_drop(b_0); r_; });
            V v_binders_24192 = heff_take_field(v_b_24191, 0);
            V v_uses_24193 = heff_take_field(v_b_24191, 1);
            V v_scopes_24194 = heff_take_field(v_b_24191, 2);
            V v_t_24195 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24183, v_sp_24184, NTAG(TAG_False)});
            V v_t_24196 = (g_prelude_2e_2b_2b(v_binders_24187, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24195, v_binders_24192})));
            V v_t_24197 = (g_prelude_2e_2b_2b(v_uses_24188, v_uses_24193));
            V v_t_24198 = (g_prelude_2e_2b_2b(v_scopes_24189, v_scopes_24194));
            return ({ V rv_0 = v_t_24196; V rv_1 = v_t_24197; V rv_2 = v_t_24198; V rr_ = heff_rec_reuse_nf(v_b_24191, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          }
          case TAG_PiImplicit: {
            V v_x_24199 = heff_field(v_n11_24179, 0);
            V v_sp_24200 = heff_field(v_n11_24179, 1);
            V v_a_24202 = heff_field(v_n11_24179, 3);
            V v_d_24203 = heff_field(v_n11_24179, 4);
            heff_take_n(v_n11_24179, 27ULL, 5);
            V v_a_24204 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24202));
            V v_binders_24205 = heff_take_field(v_a_24204, 0);
            V v_uses_24206 = heff_take_field(v_a_24204, 1);
            V v_scopes_24207 = heff_get_n(v_a_24204, 2, 3);
            V v_b_24209;
            switch (heff_tag_of(v_d_24203)) {
            case TAG_Nothing: {
              v_b_24209 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24208 = heff_field(v_d_24203, 0);
              heff_take_n(v_d_24203, 1ULL, 1);
              v_b_24209 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24208));
              break;
            }
            default: heff_nomatch(v_d_24203);
            }
            V v_binders_24210 = heff_take_field(v_b_24209, 0);
            V v_uses_24211 = heff_take_field(v_b_24209, 1);
            V v_scopes_24212 = heff_get_n(v_b_24209, 2, 3);
            V v_t_24213 = (g_prelude_2e_2b_2b(v_binders_24205, v_binders_24210));
            V v_t_24214 = (g_prelude_2e_2b_2b(v_uses_24206, v_uses_24211));
            V v_t_24215 = (g_prelude_2e_2b_2b(v_scopes_24207, v_scopes_24212));
            V v_t_24216 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24199), heff_dup(v_sp_24200), NTAG(TAG_False)});
            V v_b_24217 = ({ V b_0 = heff_tag_at_n(v_ru_24n1_2494_24EPi, TAG_Cons, 2, (V[]){v_t_24216, heff_dup(v_env_244)}); V a_1 = v_r_24180; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(b_0, a_1)); heff_drop(b_0); r_; });
            V v_binders_24218 = heff_take_field(v_b_24217, 0);
            V v_uses_24219 = heff_take_field(v_b_24217, 1);
            V v_scopes_24220 = heff_take_field(v_b_24217, 2);
            V v_t_24221 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24199, v_sp_24200, NTAG(TAG_False)});
            V v_t_24222 = (g_prelude_2e_2b_2b(v_t_24213, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24221, v_binders_24218})));
            V v_t_24223 = (g_prelude_2e_2b_2b(v_t_24214, v_uses_24219));
            V v_t_24224 = (g_prelude_2e_2b_2b(v_t_24215, v_scopes_24220));
            return ({ V rv_0 = v_t_24222; V rv_1 = v_t_24223; V rv_2 = v_t_24224; V rr_ = heff_rec_reuse_nf(v_b_24217, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          }
          case TAG_PiInstance: {
            V v_x_24225 = heff_field(v_n11_24179, 0);
            V v_sp_24226 = heff_field(v_n11_24179, 1);
            V v_a_24228 = heff_field(v_n11_24179, 3);
            heff_take_n(v_n11_24179, 11ULL, 4);
            V v_a_24229 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24228));
            V v_binders_24230 = heff_take_field(v_a_24229, 0);
            V v_uses_24231 = heff_take_field(v_a_24229, 1);
            V v_scopes_24232 = heff_get_n(v_a_24229, 2, 3);
            V v_t_24233 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24225), heff_dup(v_sp_24226), NTAG(TAG_False)});
            V v_b_24234 = ({ V b_0 = heff_tag_at_n(v_ru_24n1_2494_24EPi, TAG_Cons, 2, (V[]){v_t_24233, heff_dup(v_env_244)}); V a_1 = v_r_24180; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(b_0, a_1)); heff_drop(b_0); r_; });
            V v_binders_24235 = heff_take_field(v_b_24234, 0);
            V v_uses_24236 = heff_take_field(v_b_24234, 1);
            V v_scopes_24237 = heff_take_field(v_b_24234, 2);
            V v_t_24238 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24225, v_sp_24226, NTAG(TAG_False)});
            V v_t_24239 = (g_prelude_2e_2b_2b(v_binders_24230, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24238, v_binders_24235})));
            V v_t_24240 = (g_prelude_2e_2b_2b(v_uses_24231, v_uses_24236));
            V v_t_24241 = (g_prelude_2e_2b_2b(v_scopes_24232, v_scopes_24237));
            return ({ V rv_0 = v_t_24239; V rv_1 = v_t_24240; V rv_2 = v_t_24241; V rr_ = heff_rec_reuse_nf(v_b_24234, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          }
          case TAG_PiAnon: {
            V v_a_24242 = heff_field(v_n11_24179, 0);
            heff_take_n(v_n11_24179, 1ULL, 1);
            V v_a_24243 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24242));
            V v_binders_24244 = heff_take_field(v_a_24243, 0);
            V v_uses_24245 = heff_take_field(v_a_24243, 1);
            V v_scopes_24246 = heff_get_n(v_a_24243, 2, 3);
            V v_b_24247 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_r_24180));
            V v_binders_24248 = heff_take_field(v_b_24247, 0);
            V v_uses_24249 = heff_take_field(v_b_24247, 1);
            V v_scopes_24250 = heff_take_field(v_b_24247, 2);
            V v_t_24251 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24EPi, v_binders_24244, v_binders_24248));
            V v_t_24252 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24245, v_uses_24249));
            V v_t_24253 = (g_prelude_2e_2b_2b(v_scopes_24246, v_scopes_24250));
            return ({ V rv_0 = v_t_24251; V rv_1 = v_t_24252; V rv_2 = v_t_24253; V rr_ = heff_rec_reuse_nf(v_b_24247, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          }
          default: return heff_nomatch(v_n11_24179);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELam: {
        V v_n11_24254 = heff_field(v_n1_2494, 0);
        V v_r_24255 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24ELam = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24254)) {
          case TAG_LamName: {
            heff_drop_cell(v_ru_24n_245_24At, 2);
            V v_bs_24260 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24254));
            V v_env_24261 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_244), heff_dup(v_bs_24260)));
            V v_b_24262 = ({ V a_0 = v_env_24261; V a_1 = v_r_24255; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_24261); r_; });
            V v_t_24263 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24ELam, v_bs_24260, heff_take_field(v_b_24262, 0)));
            return ({ V rv_0 = v_t_24263; V rr_ = heff_rec_reuse_nf(v_b_24262, 6ULL, 3, shape_binders__uses__scopes, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          }
          case TAG_LamImplicit: {
            heff_drop_cell(v_ru_24n_245_24At, 2);
            V v_bs_24266 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_24254));
            V v_env_24267 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_244), heff_dup(v_bs_24266)));
            V v_b_24268 = ({ V a_0 = v_env_24267; V a_1 = v_r_24255; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_24267); r_; });
            V v_t_24269 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24ELam, v_bs_24266, heff_take_field(v_b_24268, 0)));
            return ({ V rv_0 = v_t_24269; V rr_ = heff_rec_reuse_nf(v_b_24268, 6ULL, 3, shape_binders__uses__scopes, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          }
          case TAG_LamAnn: {
            V v_x_24270 = heff_field(v_n11_24254, 0);
            V v_sp_24271 = heff_field(v_n11_24254, 1);
            V v_a_24272 = heff_field(v_n11_24254, 2);
            heff_take_n(v_n11_24254, 7ULL, 3);
            V v_a_24273 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24272));
            V v_binders_24274 = heff_take_field(v_a_24273, 0);
            V v_uses_24275 = heff_take_field(v_a_24273, 1);
            V v_scopes_24276 = heff_get_n(v_a_24273, 2, 3);
            V v_t_24277 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24270), heff_dup(v_sp_24271), NTAG(TAG_False)});
            V v_b_24278 = ({ V b_0 = heff_tag_at_n(v_ru_24n1_2494_24ELam, TAG_Cons, 2, (V[]){v_t_24277, heff_dup(v_env_244)}); V a_1 = v_r_24255; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(b_0, a_1)); heff_drop(b_0); r_; });
            V v_binders_24279 = heff_take_field(v_b_24278, 0);
            V v_uses_24280 = heff_take_field(v_b_24278, 1);
            V v_scopes_24281 = heff_take_field(v_b_24278, 2);
            V v_t_24282 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24270, v_sp_24271, NTAG(TAG_False)});
            V v_t_24283 = (g_prelude_2e_2b_2b(v_binders_24274, heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24282, v_binders_24279})));
            V v_t_24284 = (g_prelude_2e_2b_2b(v_uses_24275, v_uses_24280));
            V v_t_24285 = (g_prelude_2e_2b_2b(v_scopes_24276, v_scopes_24281));
            return ({ V rv_0 = v_t_24283; V rv_1 = v_t_24284; V rv_2 = v_t_24285; V rr_ = heff_rec_reuse_nf(v_b_24278, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          }
          default: return heff_nomatch(v_n11_24254);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAnn: {
        V v_e_24286 = heff_field(v_n1_2494, 0);
        V v_t_24287 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24EAnn = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24290 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24286));
          V v_binders_24291 = heff_take_field(v_a_24290, 0);
          V v_uses_24292 = heff_take_field(v_a_24290, 1);
          V v_scopes_24293 = heff_get_n(v_a_24290, 2, 3);
          V v_b_24294 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_t_24287));
          V v_binders_24295 = heff_take_field(v_b_24294, 0);
          V v_uses_24296 = heff_take_field(v_b_24294, 1);
          V v_scopes_24297 = heff_take_field(v_b_24294, 2);
          V v_t_24298 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24EAnn, v_binders_24291, v_binders_24295));
          V v_t_24299 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24292, v_uses_24296));
          V v_t_24300 = (g_prelude_2e_2b_2b(v_scopes_24293, v_scopes_24297));
          return ({ V rv_0 = v_t_24298; V rv_1 = v_t_24299; V rv_2 = v_t_24300; V rr_ = heff_rec_reuse_nf(v_b_24294, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESpec: {
        V v_acc_24301 = heff_field(v_n1_2494, 0);
        V v_v_24304 = heff_field(v_n1_2494, 3);
        heff_take_n(v_n1_2494, 9ULL, 4);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24307 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_acc_24301));
          V v_binders_24308 = heff_take_field(v_a_24307, 0);
          V v_uses_24309 = heff_take_field(v_a_24307, 1);
          V v_scopes_24310 = heff_get_n(v_a_24307, 2, 3);
          V v_b_24311 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_v_24304));
          V v_binders_24312 = heff_take_field(v_b_24311, 0);
          V v_uses_24313 = heff_take_field(v_b_24311, 1);
          V v_scopes_24314 = heff_take_field(v_b_24311, 2);
          V v_t_24315 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24308, v_binders_24312));
          V v_t_24316 = (g_prelude_2e_2b_2b(v_uses_24309, v_uses_24313));
          V v_t_24317 = (g_prelude_2e_2b_2b(v_scopes_24310, v_scopes_24314));
          return ({ V rv_0 = v_t_24315; V rv_1 = v_t_24316; V rv_2 = v_t_24317; V rr_ = heff_rec_reuse_nf(v_b_24311, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESig: {
        V v_fs_24318 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_dup(v_env_244), v_fs_24318));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ESum: {
        V v_vs_24321 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1, 2, 1, (V[]){heff_dup(v_env_244)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_vs_24321; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_vs_24321); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EStruct: {
        V v_fs_24354 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3, 2, 1, (V[]){heff_dup(v_env_244)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_fs_24354; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_fs_24354); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EUpdate: {
        V v_a_24375 = heff_field(v_n1_2494, 0);
        V v_fs_24376 = heff_field(v_n1_2494, 1);
        heff_take_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V v_t_24379 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24375));
          return ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4, 2, 1, (V[]){heff_dup(v_env_244)}); V a_1 = v_t_24379; V a_2 = v_fs_24376; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_fs_24376); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EMatch: {
        V v_s_24396 = heff_field(v_n1_2494, 0);
        V v_alts_24397 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24EMatch = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24400 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_s_24396));
          V v_binders_24401 = heff_take_field(v_a_24400, 0);
          V v_uses_24402 = heff_take_field(v_a_24400, 1);
          V v_scopes_24403 = heff_get_n(v_a_24400, 2, 3);
          V v_b_24424 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5, 2, 1, (V[]){heff_dup(v_env_244)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_alts_24397; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_alts_24397); r_; });
          V v_binders_24425 = heff_take_field(v_b_24424, 0);
          V v_uses_24426 = heff_take_field(v_b_24424, 1);
          V v_scopes_24427 = heff_take_field(v_b_24424, 2);
          V v_t_24428 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24EMatch, v_binders_24401, v_binders_24425));
          V v_t_24429 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24402, v_uses_24426));
          V v_t_24430 = (g_prelude_2e_2b_2b(v_scopes_24403, v_scopes_24427));
          return ({ V rv_0 = v_t_24428; V rv_1 = v_t_24429; V rv_2 = v_t_24430; V rr_ = heff_rec_reuse_nf(v_b_24424, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELetIn: {
        V v_rhs_24431 = heff_field(v_n1_2494, 0);
        V v_a_24432 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24ELetIn = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24435 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_rhs_24431));
          V v_binders_24436 = heff_take_field(v_a_24435, 0);
          V v_uses_24437 = heff_take_field(v_a_24435, 1);
          V v_scopes_24438 = heff_get_n(v_a_24435, 2, 3);
          V v_b_24447;
          switch (heff_tag_of(v_a_24432)) {
          case TAG_At: {
            V v_x31_24439 = heff_field(v_a_24432, 0);
            heff_take_n(v_a_24432, 1ULL, 2);
            switch (heff_tag_of(v_x31_24439)) {
            case TAG_MkAlt: {
              V v_p_24441 = heff_field(v_x31_24439, 0);
              V v_r_24442 = heff_field(v_x31_24439, 1);
              heff_take_n(v_x31_24439, 3ULL, 2);
              V v_bs_24443 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n1_2494_24ELetIn, v_p_24441));
              V v_env_24444 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_244), heff_dup(v_bs_24443)));
              V v_b_24445 = ({ V a_0 = v_env_24444; V a_1 = v_r_24442; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_24444); r_; });
              V v_t_24446 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_bs_24443, heff_take_field(v_b_24445, 0)));
              v_b_24447 = ({ V rv_0 = v_t_24446; V rr_ = heff_rec_reuse_nf(v_b_24445, 6ULL, 3, shape_binders__uses__scopes, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              break;
            }
            default: heff_nomatch(v_x31_24439);
            }
            break;
          }
          default: heff_nomatch(v_a_24432);
          }
          V v_binders_24448 = heff_take_field(v_b_24447, 0);
          V v_uses_24449 = heff_take_field(v_b_24447, 1);
          V v_scopes_24450 = heff_take_field(v_b_24447, 2);
          V v_t_24451 = (g_prelude_2e_2b_2b(v_binders_24436, v_binders_24448));
          V v_t_24452 = (g_prelude_2e_2b_2b(v_uses_24437, v_uses_24449));
          V v_t_24453 = (g_prelude_2e_2b_2b(v_scopes_24438, v_scopes_24450));
          return ({ V rv_0 = v_t_24451; V rv_1 = v_t_24452; V rv_2 = v_t_24453; V rr_ = heff_rec_reuse_nf(v_b_24447, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EDo: {
        V v_stmts_24454 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_244), v_stmts_24454));
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELocal: {
        V v_body_24457 = heff_field(v_n1_2494, 0);
        V v_defs_24458 = heff_field(v_n1_2494, 1);
        heff_take_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361);
          V t_1 = v_env_244;
          V t_2 = v_defs_24458;
          V t_3 = v_body_24457;
          V t_4 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str3);
          V t_5 = ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_str4);
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EInvalid: {
        heff_take_n(v_n1_2494, 0ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EAssign: {
        V v_x_24464 = heff_field(v_n1_2494, 0);
        V v_xsp_24465 = heff_field(v_n1_2494, 1);
        V v_e_24466 = heff_field(v_n1_2494, 2);
        heff_take_n(v_n1_2494, 7ULL, 3);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          HeffT2 v_t_24469 = ({ V a_0 = v_x_24464; V a_1 = v_env_244; HeffT2 r_ = (g_heff_2eelab_2elocals_2efindBinder_24cpr(a_0, a_1)); heff_drop(v_x_24464); r_; });
          {
            V v_field_24471 = v_t_24469.f[1];
            int64_t v_tag_24470 = ((int64_t)v_t_24469.f[0]);
            V v_a_24474;
            if ((v_tag_24470 == ((int64_t)0ULL))) {
              V v_b_24472 = v_field_24471;
              V v_t_24473 = heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_24472, v_xsp_24465}), NTAG(TAG_Nil)});
              v_a_24474 = heff_rec_n(3, shape_binders__uses__scopes, (V[]){NTAG(TAG_Nil), v_t_24473, NTAG(TAG_Nil)});
            } else {
              heff_drop(v_xsp_24465);
              heff_drop_cell(v_ru_24n_245_24At, 2);
              heff_drop(v_field_24471);
              v_a_24474 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            }
            V v_binders_24475 = heff_take_field(v_a_24474, 0);
            V v_uses_24476 = heff_take_field(v_a_24474, 1);
            V v_scopes_24477 = heff_get_n(v_a_24474, 2, 3);
            V v_b_24478 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24466));
            V v_binders_24479 = heff_take_field(v_b_24478, 0);
            V v_uses_24480 = heff_take_field(v_b_24478, 1);
            V v_scopes_24481 = heff_take_field(v_b_24478, 2);
            V v_t_24482 = (g_prelude_2e_2b_2b(v_binders_24475, v_binders_24479));
            V v_t_24483 = (g_prelude_2e_2b_2b(v_uses_24476, v_uses_24480));
            V v_t_24484 = (g_prelude_2e_2b_2b(v_scopes_24477, v_scopes_24481));
            return ({ V rv_0 = v_t_24482; V rv_1 = v_t_24483; V rv_2 = v_t_24484; V rr_ = heff_rec_reuse_nf(v_b_24478, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWhile: {
        V v_c_24485 = heff_field(v_n1_2494, 0);
        V v_body_24486 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24EWhile = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24489 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_c_24485));
          V v_binders_24490 = heff_take_field(v_a_24489, 0);
          V v_uses_24491 = heff_take_field(v_a_24489, 1);
          V v_scopes_24492 = heff_get_n(v_a_24489, 2, 3);
          V v_b_24493 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_244), v_body_24486));
          V v_binders_24494 = heff_take_field(v_b_24493, 0);
          V v_uses_24495 = heff_take_field(v_b_24493, 1);
          V v_scopes_24496 = heff_take_field(v_b_24493, 2);
          V v_t_24497 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24EWhile, v_binders_24490, v_binders_24494));
          V v_t_24498 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24491, v_uses_24495));
          V v_t_24499 = (g_prelude_2e_2b_2b(v_scopes_24492, v_scopes_24496));
          return ({ V rv_0 = v_t_24497; V rv_1 = v_t_24498; V rv_2 = v_t_24499; V rr_ = heff_rec_reuse_nf(v_b_24493, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EFor: {
        V v_p_24500 = heff_field(v_n1_2494, 0);
        V v_c_24501 = heff_field(v_n1_2494, 1);
        V v_body_24502 = heff_field(v_n1_2494, 2);
        heff_take_n(v_n1_2494, 7ULL, 3);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24505 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_c_24501));
          V v_binders_24506 = heff_take_field(v_a_24505, 0);
          V v_uses_24507 = heff_take_field(v_a_24505, 1);
          V v_scopes_24508 = heff_get_n(v_a_24505, 2, 3);
          V v_bs_24509 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24n_245_24At, heff_dup(v_p_24500)));
          V v_env_24510 = (g_list_2efoldl_24f1677743806x2032371213(heff_dup(v_env_244), v_p_24500));
          V v_b_24511 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24510, v_body_24502));
          V v_binders_24512 = heff_take_field(v_b_24511, 0);
          V v_uses_24513 = heff_take_field(v_b_24511, 1);
          V v_scopes_24514 = heff_take_field(v_b_24511, 2);
          V v_t_24515 = (g_prelude_2e_2b_2b(v_bs_24509, v_binders_24512));
          V v_t_24516 = (g_prelude_2e_2b_2b(v_binders_24506, v_t_24515));
          V v_t_24517 = (g_prelude_2e_2b_2b(v_uses_24507, v_uses_24513));
          V v_t_24518 = (g_prelude_2e_2b_2b(v_scopes_24508, v_scopes_24514));
          return ({ V rv_0 = v_t_24516; V rv_1 = v_t_24517; V rv_2 = v_t_24518; V rr_ = heff_rec_reuse_nf(v_b_24511, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EIfThen: {
        V v_c_24519 = heff_field(v_n1_2494, 0);
        V v_a_24520 = heff_field(v_n1_2494, 1);
        V v_ru_24n1_2494_24EIfThen = heff_take_reuse_n(v_n1_2494, 3ULL, 2);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24523 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_c_24519));
          V v_binders_24524 = heff_take_field(v_a_24523, 0);
          V v_uses_24525 = heff_take_field(v_a_24523, 1);
          V v_scopes_24526 = heff_get_n(v_a_24523, 2, 3);
          V v_b_24527 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_a_24520));
          V v_binders_24528 = heff_take_field(v_b_24527, 0);
          V v_uses_24529 = heff_take_field(v_b_24527, 1);
          V v_scopes_24530 = heff_take_field(v_b_24527, 2);
          V v_t_24531 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n1_2494_24EIfThen, v_binders_24524, v_binders_24528));
          V v_t_24532 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_uses_24525, v_uses_24529));
          V v_t_24533 = (g_prelude_2e_2b_2b(v_scopes_24526, v_scopes_24530));
          return ({ V rv_0 = v_t_24531; V rv_1 = v_t_24532; V rv_2 = v_t_24533; V rr_ = heff_rec_reuse_nf(v_b_24527, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EBreak: {
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EContinue: {
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return heff_dup(g_heff_2eelab_2elocals_2enone_get());
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EReturn: {
        V v_e_24538 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24538;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ENest: {
        V v_e_24541 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24541;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ELazy: {
        V v_e_24544 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481);
          V t_1 = v_env_241;
          V t_2 = v_x3_242;
          V t_3 = v_body_243;
          V t_4 = v_env_244;
          V t_5 = v_e_24544;
          v_tag_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_body_243 = t_3;
          v_env_244 = t_4;
          v_n_245 = t_5;
          goto top_TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481;
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETuple: {
        V v_es_24547 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          heff_take_n(v_n_245, 0ULL, 2);
          return ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6, 2, 1, (V[]){heff_dup(v_env_244)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_es_24547; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_es_24547); r_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_ETry: {
        V v_n11_24562 = heff_field(v_n1_2494, 0);
        heff_take_n(v_n1_2494, 1ULL, 1);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          switch (heff_tag_of(v_n11_24562)) {
          case TAG_MkTry: {
            V v_ty_24565 = heff_field(v_n11_24562, 0);
            V v_body_24566 = heff_field(v_n11_24562, 1);
            V v_c_24567 = heff_field(v_n11_24562, 2);
            heff_take_n(v_n11_24562, 7ULL, 3);
            V v_a_24569;
            switch (heff_tag_of(v_ty_24565)) {
            case TAG_Nothing: {
              v_a_24569 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
              break;
            }
            case TAG_Just: {
              V v_x_24568 = heff_field(v_ty_24565, 0);
              heff_take_n(v_ty_24565, 1ULL, 1);
              v_a_24569 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_x_24568));
              break;
            }
            default: heff_nomatch(v_ty_24565);
            }
            V v_binders_24570 = heff_take_field(v_a_24569, 0);
            V v_uses_24571 = heff_take_field(v_a_24569, 1);
            V v_scopes_24572 = heff_get_n(v_a_24569, 2, 3);
            V v_b_24573 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_dup(v_env_244), v_body_24566));
            V v_binders_24574 = heff_take_field(v_b_24573, 0);
            V v_uses_24575 = heff_take_field(v_b_24573, 1);
            V v_scopes_24576 = heff_take_field(v_b_24573, 2);
            V v_t_24577 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24570, v_binders_24574));
            V v_t_24578 = (g_prelude_2e_2b_2b(v_uses_24571, v_uses_24575));
            V v_t_24579 = (g_prelude_2e_2b_2b(v_scopes_24572, v_scopes_24576));
            HeffT3 v_t_24580 = (g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(heff_dup(v_env_244), v_c_24567));
            {
              V v_field_24581 = v_t_24580.f[0];
              V v_field_24582 = v_t_24580.f[1];
              V v_field_24583 = v_t_24580.f[2];
              V v_t_24584 = (g_prelude_2e_2b_2b(v_t_24577, v_field_24581));
              V v_t_24585 = (g_prelude_2e_2b_2b(v_t_24578, v_field_24582));
              V v_t_24586 = (g_prelude_2e_2b_2b(v_t_24579, v_field_24583));
              return ({ V rv_0 = v_t_24584; V rv_1 = v_t_24585; V rv_2 = v_t_24586; V rr_ = heff_rec_reuse_nf(v_b_24573, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
            }
          }
          default: return heff_nomatch(v_n11_24562);
          }
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWith: {
        V v_e_24587 = heff_field(v_n1_2494, 0);
        V v_x_24588 = heff_field(v_n1_2494, 1);
        V v_xsp_24589 = heff_field(v_n1_2494, 2);
        V v_body_24590 = heff_field(v_n1_2494, 3);
        heff_take_n(v_n1_2494, 15ULL, 4);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24593 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_244, v_e_24587));
          V v_binders_24594 = heff_take_field(v_a_24593, 0);
          V v_uses_24595 = heff_take_field(v_a_24593, 1);
          V v_scopes_24596 = heff_get_n(v_a_24593, 2, 3);
          V v_t_24597 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24588), heff_dup(v_xsp_24589), NTAG(TAG_False)});
          V v_b_24598 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24n_245_24At, TAG_Cons, 2, (V[]){v_t_24597, heff_dup(v_env_244)}), v_body_24590));
          V v_binders_24599 = heff_take_field(v_b_24598, 0);
          V v_uses_24600 = heff_take_field(v_b_24598, 1);
          V v_scopes_24601 = heff_take_field(v_b_24598, 2);
          V v_t_24602 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24588, v_xsp_24589, NTAG(TAG_False)});
          V v_t_24603 = (g_prelude_2e_2b_2b(v_binders_24594, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24602, v_binders_24599})));
          V v_t_24604 = (g_prelude_2e_2b_2b(v_uses_24595, v_uses_24600));
          V v_t_24605 = (g_prelude_2e_2b_2b(v_scopes_24596, v_scopes_24601));
          return ({ V rv_0 = v_t_24603; V rv_1 = v_t_24604; V rv_2 = v_t_24605; V rr_ = heff_rec_reuse_nf(v_b_24598, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      case TAG_EWithBound: {
        V v_bs_24606 = heff_field(v_n1_2494, 0);
        V v_p_24607 = heff_field(v_n1_2494, 1);
        V v_body_24608 = heff_field(v_n1_2494, 2);
        heff_take_n(v_n1_2494, 7ULL, 3);
        heff_drop(v_x3_242);
        heff_drop(v_body_243);
        switch (heff_tag_of(v_n_245)) {
        case TAG_At: {
          V v_ru_24n_245_24At = heff_take_reuse_n(v_n_245, 0ULL, 2);
          V v_a_24627 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam7, 2, 1, (V[]){heff_dup(v_env_244)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_bs_24606; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          V v_binders_24628 = heff_take_field(v_a_24627, 0);
          V v_uses_24629 = heff_take_field(v_a_24627, 1);
          V v_scopes_24630 = heff_get_n(v_a_24627, 2, 3);
          V v_t_24631 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_24606)));
          V v_bs_24632 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24631; V r_ = (g_list_2efoldl_24s884736396x2007513852(a_0, a_1)); heff_drop(v_t_24631); r_; });
          V v_a_24637;
          switch (heff_tag_of(v_p_24607)) {
          case TAG_Nothing: {
            v_a_24637 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
            break;
          }
          case TAG_Just: {
            V v_c_24633 = heff_field(v_p_24607, 0);
            heff_take_n(v_p_24607, 1ULL, 1);
            V v_t_24634 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_24606)));
            V v_bs_24635 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24634; V r_ = (g_list_2efoldl_24s884736396x2007513852(a_0, a_1)); heff_drop(v_t_24634); r_; });
            V v_env_24636 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_244), v_bs_24635));
            v_a_24637 = ({ V a_0 = v_env_24636; V a_1 = v_c_24633; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_24636); r_; });
            break;
          }
          default: heff_nomatch(v_p_24607);
          }
          V v_binders_24638 = heff_take_field(v_a_24637, 0);
          V v_uses_24639 = heff_take_field(v_a_24637, 1);
          V v_scopes_24640 = heff_get_n(v_a_24637, 2, 3);
          V v_t_24641 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_24606));
          V v_bs_24642 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24641; V r_ = (g_list_2efoldl_24s884736396x2007513852(a_0, a_1)); heff_drop(v_t_24641); r_; });
          V v_env_24643 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_244), v_bs_24642));
          V v_b_24644 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_24643, v_body_24608));
          V v_binders_24645 = heff_take_field(v_b_24644, 0);
          V v_uses_24646 = heff_take_field(v_b_24644, 1);
          V v_scopes_24647 = heff_take_field(v_b_24644, 2);
          V v_t_24648 = (g_prelude_2e_2b_2b_24tok2(v_ru_24n_245_24At, v_binders_24638, v_binders_24645));
          V v_t_24649 = (g_prelude_2e_2b_2b(v_uses_24639, v_uses_24646));
          V v_t_24650 = (g_prelude_2e_2b_2b(v_scopes_24640, v_scopes_24647));
          V v_t_24651 = (g_prelude_2e_2b_2b(v_bs_24632, v_t_24648));
          V v_t_24652 = (g_prelude_2e_2b_2b(v_binders_24628, v_t_24651));
          V v_t_24653 = (g_prelude_2e_2b_2b(v_uses_24629, v_t_24649));
          V v_t_24654 = (g_prelude_2e_2b_2b(v_scopes_24630, v_t_24650));
          return ({ V rv_0 = v_t_24652; V rv_1 = v_t_24653; V rv_2 = v_t_24654; V rr_ = heff_rec_reuse_nf(v_b_24644, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_n_245);
        }
      }
      default: return heff_nomatch(v_n1_2494);
      }
    }
    default: return heff_nomatch(v_n_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(a0, a1, a[2], a[3], a4, a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam0(V self, V *args) {
  V v_acc_24153 = args[0];
  V v_x_24154 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24155 = heff_take_field(v_acc_24153, 0);
  V v_uses_24156 = heff_take_field(v_acc_24153, 1);
  V v_scopes_24157 = heff_get_n(v_acc_24153, 2, 3);
  heff_clo_take(self, 1);
  V v_b_24158 = ({ V a_0 = v_env_244; V a_1 = v_x_24154; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
  V v_binders_24159 = heff_take_field(v_b_24158, 0);
  V v_uses_24160 = heff_take_field(v_b_24158, 1);
  V v_scopes_24161 = heff_take_field(v_b_24158, 2);
  V v_t_24162 = (g_prelude_2e_2b_2b(v_binders_24155, v_binders_24159));
  V v_t_24163 = (g_prelude_2e_2b_2b(v_uses_24156, v_uses_24160));
  V v_t_24164 = (g_prelude_2e_2b_2b(v_scopes_24157, v_scopes_24161));
  return ({ V rv_0 = v_t_24162; V rv_1 = v_t_24163; V rv_2 = v_t_24164; V rr_ = heff_rec_reuse_nf(v_b_24158, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2(V self, V *args) {
  V v_acc_24334 = args[0];
  V v_x_24335 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24336 = heff_take_field(v_acc_24334, 0);
  V v_uses_24337 = heff_take_field(v_acc_24334, 1);
  V v_scopes_24338 = heff_get_n(v_acc_24334, 2, 3);
  heff_clo_take(self, 1);
  V v_b_24339 = ({ V a_0 = v_env_244; V a_1 = v_x_24335; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
  V v_binders_24340 = heff_take_field(v_b_24339, 0);
  V v_uses_24341 = heff_take_field(v_b_24339, 1);
  V v_scopes_24342 = heff_take_field(v_b_24339, 2);
  V v_t_24343 = (g_prelude_2e_2b_2b(v_binders_24336, v_binders_24340));
  V v_t_24344 = (g_prelude_2e_2b_2b(v_uses_24337, v_uses_24341));
  V v_t_24345 = (g_prelude_2e_2b_2b(v_scopes_24338, v_scopes_24342));
  return ({ V rv_0 = v_t_24343; V rv_1 = v_t_24344; V rv_2 = v_t_24345; V rr_ = heff_rec_reuse_nf(v_b_24339, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam1(V self, V *args) {
  V v_acc_24324 = args[0];
  V v_v_24325 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24326 = heff_take_field(v_acc_24324, 0);
  V v_uses_24327 = heff_take_field(v_acc_24324, 1);
  V v_scopes_24328 = heff_get_n(v_acc_24324, 2, 3);
  V v_b_24347;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_24325)) {
  case TAG_At: {
    V v_it1_24329 = heff_field(v_v_24325, 0);
    heff_take_n(v_v_24325, 1ULL, 2);
    switch (heff_tag_of(v_it1_24329)) {
    case TAG_TagVariant: {
      V v_args_24333 = heff_field(v_it1_24329, 2);
      heff_take_n(v_it1_24329, 4ULL, 3);
      v_b_24347 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam2, 2, 1, (V[]){v_env_244}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24333; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_args_24333); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24346 = heff_field(v_it1_24329, 0);
      heff_take_n(v_it1_24329, 1ULL, 1);
      v_b_24347 = ({ V a_0 = v_env_244; V a_1 = v_e_24346; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
      break;
    }
    default: heff_nomatch(v_it1_24329);
    }
    break;
  }
  default: heff_nomatch(v_v_24325);
  }
  V v_binders_24348 = heff_take_field(v_b_24347, 0);
  V v_uses_24349 = heff_take_field(v_b_24347, 1);
  V v_scopes_24350 = heff_take_field(v_b_24347, 2);
  V v_t_24351 = (g_prelude_2e_2b_2b(v_binders_24326, v_binders_24348));
  V v_t_24352 = (g_prelude_2e_2b_2b(v_uses_24327, v_uses_24349));
  V v_t_24353 = (g_prelude_2e_2b_2b(v_scopes_24328, v_scopes_24350));
  return ({ V rv_0 = v_t_24351; V rv_1 = v_t_24352; V rv_2 = v_t_24353; V rr_ = heff_rec_reuse_nf(v_b_24347, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam3(V self, V *args) {
  V v_acc_24357 = args[0];
  V v_f_24358 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24359 = heff_take_field(v_acc_24357, 0);
  V v_uses_24360 = heff_take_field(v_acc_24357, 1);
  V v_scopes_24361 = heff_get_n(v_acc_24357, 2, 3);
  V v_b_24368;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24358)) {
  case TAG_At: {
    V v_x31_24362 = heff_field(v_f_24358, 0);
    heff_take_n(v_f_24358, 1ULL, 2);
    switch (heff_tag_of(v_x31_24362)) {
    case TAG_SetField: {
      V v_e_24366 = heff_field(v_x31_24362, 2);
      heff_take_n(v_x31_24362, 4ULL, 3);
      v_b_24368 = ({ V a_0 = v_env_244; V a_1 = v_e_24366; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24367 = heff_field(v_x31_24362, 0);
      heff_take_n(v_x31_24362, 1ULL, 1);
      v_b_24368 = ({ V a_0 = v_env_244; V a_1 = v_e_24367; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
      break;
    }
    default: heff_nomatch(v_x31_24362);
    }
    break;
  }
  default: heff_nomatch(v_f_24358);
  }
  V v_binders_24369 = heff_take_field(v_b_24368, 0);
  V v_uses_24370 = heff_take_field(v_b_24368, 1);
  V v_scopes_24371 = heff_take_field(v_b_24368, 2);
  V v_t_24372 = (g_prelude_2e_2b_2b(v_binders_24359, v_binders_24369));
  V v_t_24373 = (g_prelude_2e_2b_2b(v_uses_24360, v_uses_24370));
  V v_t_24374 = (g_prelude_2e_2b_2b(v_scopes_24361, v_scopes_24371));
  return ({ V rv_0 = v_t_24372; V rv_1 = v_t_24373; V rv_2 = v_t_24374; V rr_ = heff_rec_reuse_nf(v_b_24368, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam4(V self, V *args) {
  V v_acc_24380 = args[0];
  V v_f_24381 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24382 = heff_take_field(v_acc_24380, 0);
  V v_uses_24383 = heff_take_field(v_acc_24380, 1);
  V v_scopes_24384 = heff_get_n(v_acc_24380, 2, 3);
  switch (heff_tag_of(v_f_24381)) {
  case TAG_At: {
    V v_it1_24385 = heff_field(v_f_24381, 0);
    V v_ru_24f_24381_24At = heff_take_reuse_n(v_f_24381, 1ULL, 2);
    switch (heff_tag_of(v_it1_24385)) {
    case TAG_SetPath: {
      V v_e_24388 = heff_field(v_it1_24385, 1);
      V v_ru_24it1_24385_24SetPath = heff_take_reuse_n(v_it1_24385, 2ULL, 2);
      heff_clo_take(self, 1);
      V v_b_24389 = ({ V a_0 = v_env_244; V a_1 = v_e_24388; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
      V v_binders_24390 = heff_take_field(v_b_24389, 0);
      V v_uses_24391 = heff_take_field(v_b_24389, 1);
      V v_scopes_24392 = heff_take_field(v_b_24389, 2);
      V v_t_24393 = (g_prelude_2e_2b_2b_24tok2(v_ru_24f_24381_24At, v_binders_24382, v_binders_24390));
      V v_t_24394 = (g_prelude_2e_2b_2b_24tok2(v_ru_24it1_24385_24SetPath, v_uses_24383, v_uses_24391));
      V v_t_24395 = (g_prelude_2e_2b_2b(v_scopes_24384, v_scopes_24392));
      return ({ V rv_0 = v_t_24393; V rv_1 = v_t_24394; V rv_2 = v_t_24395; V rr_ = heff_rec_reuse_nf(v_b_24389, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    default: return heff_nomatch(v_it1_24385);
    }
  }
  default: return heff_nomatch(v_f_24381);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam5(V self, V *args) {
  V v_acc_24404 = args[0];
  V v_a_24405 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24406 = heff_take_field(v_acc_24404, 0);
  V v_uses_24407 = heff_take_field(v_acc_24404, 1);
  V v_scopes_24408 = heff_get_n(v_acc_24404, 2, 3);
  V v_b_24417;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24405)) {
  case TAG_At: {
    V v_x31_24409 = heff_field(v_a_24405, 0);
    V v_ru_24a_24405_24At = heff_take_reuse_n(v_a_24405, 1ULL, 2);
    switch (heff_tag_of(v_x31_24409)) {
    case TAG_MkAlt: {
      V v_p_24411 = heff_field(v_x31_24409, 0);
      V v_r_24412 = heff_field(v_x31_24409, 1);
      V v_ru_24x31_24409_24MkAlt = heff_take_reuse_n(v_x31_24409, 3ULL, 2);
      V v_bs_24413 = (g_heff_2eelab_2elocals_2epatternBinders_24tok2(v_ru_24a_24405_24At, v_p_24411));
      V v_env_24414 = (g_list_2efoldl_24s1370882877x364361272(v_env_244, heff_dup(v_bs_24413)));
      V v_b_24415 = ({ V a_0 = v_env_24414; V a_1 = v_r_24412; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_24414); r_; });
      V v_t_24416 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_24409_24MkAlt, v_bs_24413, heff_take_field(v_b_24415, 0)));
      v_b_24417 = ({ V rv_0 = v_t_24416; V rr_ = heff_rec_reuse_nf(v_b_24415, 6ULL, 3, shape_binders__uses__scopes, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_24409);
    }
    break;
  }
  default: heff_nomatch(v_a_24405);
  }
  V v_binders_24418 = heff_take_field(v_b_24417, 0);
  V v_uses_24419 = heff_take_field(v_b_24417, 1);
  V v_scopes_24420 = heff_take_field(v_b_24417, 2);
  V v_t_24421 = (g_prelude_2e_2b_2b(v_binders_24406, v_binders_24418));
  V v_t_24422 = (g_prelude_2e_2b_2b(v_uses_24407, v_uses_24419));
  V v_t_24423 = (g_prelude_2e_2b_2b(v_scopes_24408, v_scopes_24420));
  return ({ V rv_0 = v_t_24421; V rv_1 = v_t_24422; V rv_2 = v_t_24423; V rr_ = heff_rec_reuse_nf(v_b_24417, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam6(V self, V *args) {
  V v_acc_24550 = args[0];
  V v_x_24551 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24552 = heff_take_field(v_acc_24550, 0);
  V v_uses_24553 = heff_take_field(v_acc_24550, 1);
  V v_scopes_24554 = heff_get_n(v_acc_24550, 2, 3);
  heff_clo_take(self, 1);
  V v_b_24555 = ({ V a_0 = v_env_244; V a_1 = v_x_24551; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
  V v_binders_24556 = heff_take_field(v_b_24555, 0);
  V v_uses_24557 = heff_take_field(v_b_24555, 1);
  V v_scopes_24558 = heff_take_field(v_b_24555, 2);
  V v_t_24559 = (g_prelude_2e_2b_2b(v_binders_24552, v_binders_24556));
  V v_t_24560 = (g_prelude_2e_2b_2b(v_uses_24553, v_uses_24557));
  V v_t_24561 = (g_prelude_2e_2b_2b(v_scopes_24554, v_scopes_24558));
  return ({ V rv_0 = v_t_24559; V rv_1 = v_t_24560; V rv_2 = v_t_24561; V rr_ = heff_rec_reuse_nf(v_b_24555, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle_lam7(V self, V *args) {
  V v_acc_24611 = args[0];
  V v_b_24612 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_binders_24613 = heff_take_field(v_acc_24611, 0);
  V v_uses_24614 = heff_take_field(v_acc_24611, 1);
  V v_scopes_24615 = heff_get_n(v_acc_24611, 2, 3);
  switch (heff_tag_of(v_b_24612)) {
  case TAG_At: {
    V v_it1_24616 = heff_field(v_b_24612, 0);
    V v_ru_24b_24612_24At = heff_take_reuse_n(v_b_24612, 1ULL, 2);
    switch (heff_tag_of(v_it1_24616)) {
    case TAG_MkBinding: {
      V v_m_24619 = heff_field(v_it1_24616, 1);
      V v_ru_24it1_24616_24MkBinding = heff_take_reuse_n(v_it1_24616, 2ULL, 2);
      heff_clo_take(self, 1);
      V v_b_24620 = ({ V a_0 = v_env_244; V a_1 = v_m_24619; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
      V v_binders_24621 = heff_take_field(v_b_24620, 0);
      V v_uses_24622 = heff_take_field(v_b_24620, 1);
      V v_scopes_24623 = heff_take_field(v_b_24620, 2);
      V v_t_24624 = (g_prelude_2e_2b_2b_24tok2(v_ru_24b_24612_24At, v_binders_24613, v_binders_24621));
      V v_t_24625 = (g_prelude_2e_2b_2b_24tok2(v_ru_24it1_24616_24MkBinding, v_uses_24614, v_uses_24622));
      V v_t_24626 = (g_prelude_2e_2b_2b(v_scopes_24615, v_scopes_24623));
      return ({ V rv_0 = v_t_24624; V rv_1 = v_t_24625; V rv_2 = v_t_24626; V rr_ = heff_rec_reuse_nf(v_b_24620, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    default: return heff_nomatch(v_it1_24616);
    }
  }
  default: return heff_nomatch(v_b_24612);
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1, 0, "");
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry, 3, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2elocalsF_24s151542447x34979361), v_env_240, v_x3_241, v_body_242, ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str0), ((V)&g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_str1)));
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT3 g_heff_2eelab_2elocals_2ecatchF_24s1635544321x1313282354_24cpr(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkCatchArm: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ss_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkCatchArm = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_LamName: {
      V v_bs_246 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_247 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_248 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_247));
      V v_b_249 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_248, v_ss_243));
      V v_binders_2410 = heff_take_field(v_b_249, 0);
      V v_uses_2411 = heff_take_field(v_b_249, 1);
      V v_scopes_2412 = heff_get_n(v_b_249, 2, 3);
      V v_t_2413 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_246, v_binders_2410));
      V v_f_2414 = v_uses_2411;
      V v_f_2415 = v_scopes_2412;
      return ((HeffT3){{v_t_2413, v_f_2414, v_f_2415}});
    }
    case TAG_LamImplicit: {
      V v_bs_2418 = (g_heff_2eelab_2elocals_2elamBinders(heff_dup(v_x31_242)));
      V v_bs_2419 = (g_heff_2eelab_2elocals_2elamBinders(v_x31_242));
      V v_env_2420 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2419));
      V v_b_2421 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2420, v_ss_243));
      V v_binders_2422 = heff_take_field(v_b_2421, 0);
      V v_uses_2423 = heff_take_field(v_b_2421, 1);
      V v_scopes_2424 = heff_get_n(v_b_2421, 2, 3);
      V v_t_2425 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24MkCatchArm, v_bs_2418, v_binders_2422));
      V v_f_2426 = v_uses_2423;
      V v_f_2427 = v_scopes_2424;
      return ((HeffT3){{v_t_2425, v_f_2426, v_f_2427}});
    }
    case TAG_LamAnn: {
      V v_x_2428 = heff_field(v_x31_242, 0);
      V v_sp_2429 = heff_field(v_x31_242, 1);
      V v_t_2430 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_a_2431 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2430));
      V v_binders_2432 = heff_take_field(v_a_2431, 0);
      V v_uses_2433 = heff_take_field(v_a_2431, 1);
      V v_scopes_2434 = heff_get_n(v_a_2431, 2, 3);
      V v_t_2435 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2428), heff_dup(v_sp_2429), NTAG(TAG_False)});
      V v_b_2436 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_2435, v_env_240}), v_ss_243));
      V v_binders_2437 = heff_take_field(v_b_2436, 0);
      V v_uses_2438 = heff_take_field(v_b_2436, 1);
      V v_scopes_2439 = heff_get_n(v_b_2436, 2, 3);
      V v_t_2440 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2428, v_sp_2429, NTAG(TAG_False)});
      V v_t_2441 = (g_prelude_2e_2b_2b(v_binders_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_binders_2437})));
      V v_t_2442 = (g_prelude_2e_2b_2b(v_uses_2433, v_uses_2438));
      V v_t_2443 = (g_prelude_2e_2b_2b(v_scopes_2434, v_scopes_2439));
      return ((HeffT3){{v_t_2441, v_t_2442, v_t_2443}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2, 0, "");
Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry, 2, 0};

V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V v_env_240, V v_n_241) {
top: ;
  return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_24cycle(NTAG(TAG_Enter_24heff_2eelab_2elocals_2ewalkF_24s647638360x416151481), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str0), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str1), ((V)&g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_str2), v_env_240, v_n_241));
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry, 4, 0};

V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V v_lit_240, V v_lit_241, V v_env_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    V v_lit_244 = heff_dup(v_lit_240);
    V v_lit_245 = heff_dup(v_lit_241);
    V v_env_246 = v_env_242;
    V v_b_247 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_246, v_lit_244));
    V v_binders_248 = heff_take_field(v_b_247, 0);
    V v_uses_249 = heff_take_field(v_b_247, 1);
    V v_scopes_2410 = heff_get_n(v_b_247, 2, 3);
    V v_b_2411 = ({ V a_0 = v_env_246; V a_1 = v_lit_245; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_246); r_; });
    V v_binders_2412 = heff_take_field(v_b_2411, 0);
    V v_uses_2413 = heff_take_field(v_b_2411, 1);
    V v_scopes_2414 = heff_take_field(v_b_2411, 2);
    V v_t_2415 = (g_prelude_2e_2b_2b(v_binders_248, v_binders_2412));
    V v_t_2416 = (g_prelude_2e_2b_2b(v_uses_249, v_uses_2413));
    V v_t_2417 = (g_prelude_2e_2b_2b(v_scopes_2410, v_scopes_2414));
    V v_z_2418 = ({ V rv_0 = v_t_2415; V rv_1 = v_t_2416; V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_b_2411, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    return v_z_2418;
  }
  case TAG_Cons: {
    V v_x21_2419 = heff_field(v_x2_243, 0);
    V v_tl_2420 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x21_2419)) {
    case TAG_At: {
      V v_x211_2421 = heff_field(v_x21_2419, 0);
      V v_ru_24x21_2419_24At = heff_take_reuse_n(v_x21_2419, 1ULL, 2);
      switch (heff_tag_of(v_x211_2421)) {
      case TAG_ExplicitParam: {
        V v_x_2423 = heff_field(v_x211_2421, 0);
        V v_sp_2424 = heff_field(v_x211_2421, 1);
        V v_t_2425 = heff_field(v_x211_2421, 2);
        heff_take_n(v_x211_2421, 7ULL, 3);
        V v_a_2426 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_242, v_t_2425));
        V v_binders_2427 = heff_take_field(v_a_2426, 0);
        V v_uses_2428 = heff_take_field(v_a_2426, 1);
        V v_scopes_2429 = heff_get_n(v_a_2426, 2, 3);
        V v_t_2430 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2423), heff_dup(v_sp_2424), NTAG(TAG_False)});
        V v_b_2431 = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_lit_240, v_lit_241, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2430, v_env_242}), v_tl_2420));
        V v_binders_2432 = heff_take_field(v_b_2431, 0);
        V v_uses_2433 = heff_take_field(v_b_2431, 1);
        V v_scopes_2434 = heff_take_field(v_b_2431, 2);
        V v_t_2435 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
        V v_t_2436 = (g_prelude_2e_2b_2b(v_binders_2427, heff_tag_at_n(v_ru_24x21_2419_24At, TAG_Cons, 2, (V[]){v_t_2435, v_binders_2432})));
        V v_t_2437 = (g_prelude_2e_2b_2b(v_uses_2428, v_uses_2433));
        V v_t_2438 = (g_prelude_2e_2b_2b(v_scopes_2429, v_scopes_2434));
        return ({ V rv_0 = v_t_2436; V rv_1 = v_t_2437; V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_b_2431, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      case TAG_ImplicitParam: {
        V v_x_2439 = heff_field(v_x211_2421, 0);
        V v_sp_2440 = heff_field(v_x211_2421, 1);
        V v_t_2441 = heff_field(v_x211_2421, 2);
        heff_take_n(v_x211_2421, 7ULL, 3);
        V v_a_2442 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_242, v_t_2441));
        V v_binders_2443 = heff_take_field(v_a_2442, 0);
        V v_uses_2444 = heff_take_field(v_a_2442, 1);
        V v_scopes_2445 = heff_get_n(v_a_2442, 2, 3);
        V v_t_2446 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2439), heff_dup(v_sp_2440), NTAG(TAG_False)});
        V v_b_2447 = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_lit_240, v_lit_241, heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2446, v_env_242}), v_tl_2420));
        V v_binders_2448 = heff_take_field(v_b_2447, 0);
        V v_uses_2449 = heff_take_field(v_b_2447, 1);
        V v_scopes_2450 = heff_take_field(v_b_2447, 2);
        V v_t_2451 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2439, v_sp_2440, NTAG(TAG_False)});
        V v_t_2452 = (g_prelude_2e_2b_2b(v_binders_2443, heff_tag_at_n(v_ru_24x21_2419_24At, TAG_Cons, 2, (V[]){v_t_2451, v_binders_2448})));
        V v_t_2453 = (g_prelude_2e_2b_2b(v_uses_2444, v_uses_2449));
        V v_t_2454 = (g_prelude_2e_2b_2b(v_scopes_2445, v_scopes_2450));
        return ({ V rv_0 = v_t_2452; V rv_1 = v_t_2453; V rv_2 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_b_2447, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      default: return heff_nomatch(v_x211_2421);
      }
    }
    default: return heff_nomatch(v_x21_2419);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT3 g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(V v_lit_240, V v_env_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    V v_lit_243 = heff_dup(v_lit_240);
    V v_env_244 = v_env_241;
    V v_b_245 = ({ V a_0 = v_env_244; V a_1 = v_lit_243; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_244); r_; });
    V v_binders_246 = heff_take_field(v_b_245, 0);
    V v_uses_247 = heff_take_field(v_b_245, 1);
    V v_scopes_248 = heff_get_n(v_b_245, 2, 3);
    V v_f_249 = v_binders_246;
    V v_f_2410 = v_uses_247;
    V v_f_2411 = v_scopes_248;
    return ((HeffT3){{v_f_249, v_f_2410, v_f_2411}});
  }
  case TAG_Cons: {
    V v_x21_2412 = heff_field(v_x2_242, 0);
    V v_tl_2413 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_At: {
      V v_x211_2414 = heff_field(v_x21_2412, 0);
      V v_ru_24x21_2412_24At = heff_take_reuse_n(v_x21_2412, 1ULL, 2);
      switch (heff_tag_of(v_x211_2414)) {
      case TAG_ExplicitParam: {
        V v_x_2416 = heff_field(v_x211_2414, 0);
        V v_sp_2417 = heff_field(v_x211_2414, 1);
        V v_t_2418 = heff_field(v_x211_2414, 2);
        heff_take_n(v_x211_2414, 7ULL, 3);
        V v_a_2419 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_241, v_t_2418));
        V v_binders_2420 = heff_take_field(v_a_2419, 0);
        V v_uses_2421 = heff_take_field(v_a_2419, 1);
        V v_scopes_2422 = heff_get_n(v_a_2419, 2, 3);
        V v_t_2423 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2416), heff_dup(v_sp_2417), NTAG(TAG_False)});
        HeffT3 v_t_2424 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2423, v_env_241}), v_tl_2413));
        {
          V v_field_2425 = v_t_2424.f[0];
          V v_field_2426 = v_t_2424.f[1];
          V v_field_2427 = v_t_2424.f[2];
          V v_t_2428 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2416, v_sp_2417, NTAG(TAG_False)});
          V v_t_2429 = (g_prelude_2e_2b_2b(v_binders_2420, heff_tag_at_n(v_ru_24x21_2412_24At, TAG_Cons, 2, (V[]){v_t_2428, v_field_2425})));
          V v_t_2430 = (g_prelude_2e_2b_2b(v_uses_2421, v_field_2426));
          V v_t_2431 = (g_prelude_2e_2b_2b(v_scopes_2422, v_field_2427));
          return ((HeffT3){{v_t_2429, v_t_2430, v_t_2431}});
        }
      }
      case TAG_ImplicitParam: {
        V v_x_2432 = heff_field(v_x211_2414, 0);
        V v_sp_2433 = heff_field(v_x211_2414, 1);
        V v_t_2434 = heff_field(v_x211_2414, 2);
        heff_take_n(v_x211_2414, 7ULL, 3);
        V v_a_2435 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_241, v_t_2434));
        V v_binders_2436 = heff_take_field(v_a_2435, 0);
        V v_uses_2437 = heff_take_field(v_a_2435, 1);
        V v_scopes_2438 = heff_get_n(v_a_2435, 2, 3);
        V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2432), heff_dup(v_sp_2433), NTAG(TAG_False)});
        HeffT3 v_t_2440 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_2439, v_env_241}), v_tl_2413));
        {
          V v_field_2441 = v_t_2440.f[0];
          V v_field_2442 = v_t_2440.f[1];
          V v_field_2443 = v_t_2440.f[2];
          V v_t_2444 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2432, v_sp_2433, NTAG(TAG_False)});
          V v_t_2445 = (g_prelude_2e_2b_2b(v_binders_2436, heff_tag_at_n(v_ru_24x21_2412_24At, TAG_Cons, 2, (V[]){v_t_2444, v_field_2441})));
          V v_t_2446 = (g_prelude_2e_2b_2b(v_uses_2437, v_field_2442));
          V v_t_2447 = (g_prelude_2e_2b_2b(v_scopes_2438, v_field_2443));
          return ((HeffT3){{v_t_2445, v_t_2446, v_t_2447}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x211_2414)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_2412)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_242)}});
  }
}
Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry, 3, 0};

V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V v_lit_240, V v_env_241, V v_x2_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_24cpr(v_lit_240, v_env_241, v_x2_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    return heff_rec_n(3, shape_binders__uses__scopes, (V[]){v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclaration_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclaration_entry, 1, 0};

V g_heff_2eelab_2elocals_2edeclaration(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_eqs_247 = heff_field(v_x11_241, 4);
      V v_a_248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_ty_246)));
      V v_binders_249 = heff_take_field(v_a_248, 0);
      V v_uses_2410 = heff_take_field(v_a_248, 1);
      V v_scopes_2411 = heff_get_n(v_a_248, 2, 3);
      V v_b_2437 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclaration_lam0, 2, 1, (V[]){heff_dup(v_ty_246)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_247; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_binders_2438 = heff_take_field(v_b_2437, 0);
      V v_uses_2439 = heff_take_field(v_b_2437, 1);
      V v_scopes_2440 = heff_take_field(v_b_2437, 2);
      V v_t_2441 = (g_prelude_2e_2b_2b(v_binders_249, v_binders_2438));
      V v_t_2442 = (g_prelude_2e_2b_2b(v_uses_2410, v_uses_2439));
      V v_t_2443 = (g_prelude_2e_2b_2b(v_scopes_2411, v_scopes_2440));
      return ({ V rv_0 = v_t_2441; V rv_1 = v_t_2442; V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_b_2437, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    case TAG_DeclDefine: {
      V v_ps_2446 = heff_field(v_x11_241, 2);
      V v_ty_2447 = heff_field(v_x11_241, 3);
      V v_body_2448 = heff_field(v_x11_241, 4);
      return (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_ty_2447, v_body_2448, NTAG(TAG_Nil), heff_dup(v_ps_2446)));
    }
    case TAG_DeclTheory: {
      V v_ps_2451 = heff_field(v_x11_241, 2);
      V v_body_2452 = heff_field(v_x11_241, 3);
      return (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(v_body_2452, NTAG(TAG_Nil), heff_dup(v_ps_2451)));
    }
    case TAG_DeclPrimitive: {
      V v_t_2455 = heff_field(v_x11_241, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_t_2455)));
    }
    case TAG_DeclTest: {
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_DeclWatch: {
      V v_e_2458 = heff_field(v_x11_241, 0);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_e_2458)));
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2elocals_2edeclaration(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_eq_2413 = args[1];
  V v_ty_246 = heff_env(self)[0];
  V v_binders_2414 = heff_take_field(v_acc_2412, 0);
  V v_uses_2415 = heff_take_field(v_acc_2412, 1);
  V v_scopes_2416 = heff_get_n(v_acc_2412, 2, 3);
  heff_clo_take(self, 1);
  V v_env_2417 = (g_list_2efoldl_24f1488358745x465096512(NTAG(TAG_Nil), v_ty_246));
  V v_x3_2418 = v_eq_2413;
  V v_b_2430;
  switch (heff_tag_of(v_x3_2418)) {
  case TAG_At: {
    V v_x31_2419 = heff_field(v_x3_2418, 0);
    V v_ru_24x3_2418_24At = heff_take_reuse_n(v_x3_2418, 1ULL, 2);
    switch (heff_tag_of(v_x31_2419)) {
    case TAG_MkEquation: {
      V v_ps_2423 = heff_field(v_x31_2419, 2);
      V v_rhs_2424 = heff_field(v_x31_2419, 3);
      heff_take_n(v_x31_2419, 12ULL, 4);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2423));
      V v_bs_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_env_2427 = (g_list_2efoldl_24s1370882877x364361272(v_env_2417, heff_dup(v_bs_2426)));
      V v_b_2428 = ({ V a_0 = v_env_2427; V a_1 = v_rhs_2424; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_2427); r_; });
      V v_t_2429 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_2418_24At, v_bs_2426, heff_take_field(v_b_2428, 0)));
      v_b_2430 = ({ V rv_0 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_b_2428, 6ULL, 3, shape_binders__uses__scopes, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_2419);
    }
    break;
  }
  default: heff_nomatch(v_x3_2418);
  }
  V v_binders_2431 = heff_take_field(v_b_2430, 0);
  V v_uses_2432 = heff_take_field(v_b_2430, 1);
  V v_scopes_2433 = heff_take_field(v_b_2430, 2);
  V v_t_2434 = (g_prelude_2e_2b_2b(v_binders_2414, v_binders_2431));
  V v_t_2435 = (g_prelude_2e_2b_2b(v_uses_2415, v_uses_2432));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_scopes_2416, v_scopes_2433));
  return ({ V rv_0 = v_t_2434; V rv_1 = v_t_2435; V rv_2 = v_t_2436; V rr_ = heff_rec_reuse_nf(v_b_2430, 0ULL, 3, shape_binders__uses__scopes, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V v_found_240) {
top: ;
  V v_binders_241 = heff_take_field(v_found_240, 0);
  V v_uses_242 = heff_get_n(v_found_240, 1, 3);
  V v_t_243 = (g_list_2ekeepIf_24s1266148589x1647110933(v_binders_241));
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_uses_242)}), v_t_243));
  V v_t_247 = (g_list_2emap_24f565269645x1954016017(v_uses_242));
  return ((HeffT2){{v_t_246, v_t_247}});
}
V g_heff_2eelab_2elocals_2elocalsOf_24cpr_lam0(V self, V *args) {
  V v_b_244 = args[0];
  V v_uses_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_list_2emap_24f1213328022x1811586494(v_b_244, v_uses_242));
  return heff_rec_n(3, shape_name__binder__uses, (V[]){heff_dup(heff_rfield(v_b_244, 0)), heff_get_n(v_b_244, 1, 3), v_t_245});
}
Clo g_heff_2eelab_2elocals_2elocalsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsOf_entry, 1, 0};

V g_heff_2eelab_2elocals_2elocalsOf(V v_found_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_found_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_locals__fields, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsOf(a[0]);
}
Clo g_heff_2eelab_2elocals_2eunshadowed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2eunshadowed_entry, 2, 0};

V g_heff_2eelab_2elocals_2eunshadowed(V v_x1_240, V v_seen_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seen_241);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s166327466x268514900(v_b_242, v_seen_241));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_b_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_rest_243;
      V t_1 = v_seen_241;
      v_x1_240 = t_0;
      v_seen_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = v_rest_243;
      V t_1 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_b_242, v_seen_241});
      v_x1_240 = t_0;
      v_seen_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2eunshadowed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2eunshadowed(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24tok2(V v_tok_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_241, 0);
    V v_p2_243 = heff_field(v_p_241, 1);
    heff_take_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_244, ((V)&g_heff_2eelab_2elocals_2epatternBinders_24tok2_str0), 2)) {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_p2_243);
        heff_drop(v_x_244);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_p2_243, NTAG(TAG_False)});
        return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2420));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_p2_243);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_242, 0);
      V v_sp_2424 = heff_field(v_p1_242, 1);
      V v_q_2425 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_p2_243);
      V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
      V v_cell_2427 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2425, v_cell_2427));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24tok2(a[0], a[1]);
}