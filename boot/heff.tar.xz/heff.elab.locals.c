// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_field 298786068
#define LBL_fields 672433636
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_locals__fields[] = {LBL_locals, LBL_fields};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2eelab_2elocals_2earguments(V, V, V);
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_clo;
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V, V);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo;
V g_heff_2eelab_2elocals_2edeclaration(V);
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edeclaration_clo;
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V, V);
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo;
V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(V, V);
V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_clo;
V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(V, V);
V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_clo;
V g_heff_2eelab_2elocals_2efindBinder(V, V);
V g_heff_2eelab_2elocals_2efindBinder_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2efindBinder_clo;
V g_heff_2eelab_2elocals_2elamBinders(V);
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elamBinders_clo;
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V, V);
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo;
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V, V, V);
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(V, V);
V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_clo;
V g_heff_2eelab_2elocals_2epatternBinders(V);
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_clo;
V g_heff_2eelab_2elocals_2epatternBinders_24dps(V, V);
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo;
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V, V);
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo;
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_list_2efilter_24s2018073091x1385246979(V);
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1677743806x2032371213(V, V);
V g_list_2efoldl_24f1677743806x2032371213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1677743806x2032371213_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1133029339x682401273(V);
V g_list_2emap_24f1133029339x682401273_entry(V self, V *a);
extern Clo g_list_2emap_24f1133029339x682401273_clo;
V g_list_2emap_24f342794667x1308411312(V, V);
V g_list_2emap_24f342794667x1308411312_entry(V self, V *a);
extern Clo g_list_2emap_24f342794667x1308411312_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;

static V g_heff_2eelab_2elocals_2enone_val;
static HEFF_ONCE g_heff_2eelab_2elocals_2enone_st;
static V g_heff_2eelab_2elocals_2enone_init(void) {
  return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2elocals_2enone_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2elocals_2enone_st)) return g_heff_2eelab_2elocals_2enone_val;
  return heff_global(&g_heff_2eelab_2elocals_2enone_val, &g_heff_2eelab_2elocals_2enone_st, g_heff_2eelab_2elocals_2enone_init);
}
Clo g_heff_2eelab_2elocals_2efindBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2efindBinder_entry, 2, 0};

V g_heff_2eelab_2elocals_2efindBinder(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_b_242, 0)), heff_dup(v_x_240))) {
      heff_drop(v_x_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_b_242)});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2elocals_2efindBinder_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2efindBinder(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_sp_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_243), ((V)&g_heff_2eelab_2elocals_2epatternBinders_str0))) {
        heff_drop(v_sp_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_243, v_sp_242, NTAG(TAG_False)});
        return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2420));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_241, 0);
      V v_p12_2424 = heff_field(v_p1_241, 1);
      V v_q_2425 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop(v_sp_242);
      V v_t_2426 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_p12_2424, NTAG(TAG_False)});
      V v_cell_2427 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = (g_heff_2eelab_2elocals_2epatternBinders_24dps(v_q_2425, heff_dup(v_cell_2427)));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders(a[0]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2epatternBinders_24dps_str0, 1, "_");
Clo g_heff_2eelab_2elocals_2epatternBinders_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2epatternBinders_24dps_entry, 2, 0};

V g_heff_2eelab_2elocals_2epatternBinders_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_sp_243 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2eelab_2elocals_2epatternBinders_24dps_str0))) {
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_244);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      } else {
        V v_t_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_244, v_sp_243, NTAG(TAG_False)});
        V v_t_247 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
        return heff_setField(v_d_241, MK_INT(1LL), v_t_247);
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2411); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2412);
    }
    case TAG_PatOp: {
      V v_ps_2415 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2415));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2416); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2417);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatBinary: {
      V v_segs_2421 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2421));
      V v_t_2423 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2423);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatRecord: {
      V v_fs_2425 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2425));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2426); r_; });
      return heff_setField(v_d_241, MK_INT(1LL), v_t_2427);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_PatAs: {
      V v_x_2429 = heff_field(v_p1_242, 0);
      V v_p12_2430 = heff_field(v_p1_242, 1);
      V v_q_2431 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop(v_sp_243);
      V v_t_2432 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_p12_2430, NTAG(TAG_False)});
      V v_cell_2433 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2432, heff_hole()});
      V v_u_2434 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2433));
      heff_drop(v_u_2434);
      V t_0 = v_q_2431;
      V t_1 = v_cell_2433;
      v_p_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2elocals_2epatternBinders_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2epatternBinders_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2elocals_2elamBinders_str1, 1, "_");
Clo g_heff_2eelab_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2eelab_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_241), ((V)&g_heff_2eelab_2elocals_2elamBinders_str0))) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_245 = heff_field(v_x1_240, 0);
    V v_sp_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_245), ((V)&g_heff_2eelab_2elocals_2elamBinders_str1))) {
      heff_drop(v_x_245);
      heff_drop(v_sp_246);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_248 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_245, v_sp_246, NTAG(TAG_False)});
      return heff_tag_at_n(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_249 = heff_field(v_x1_240, 0);
    V v_sp_2410 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_249, v_sp_2410, NTAG(TAG_False)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry, 2, 0};

V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_248));
        V v_b_2412;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2412 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2411 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2412 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2411));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_t_2413 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2410, 0), heff_take_field(v_b_2412, 0)));
        V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2410, 1, 2), heff_get_n(v_b_2412, 1, 2)));
        V v_a_2415 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2413, v_t_2414});
        V v_t_2416 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2417 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_env_240}), v_rest_243));
        V v_t_2418 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2419 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, heff_take_field(v_b_2417, 0)));
        V v_t_2421 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2417, 1, 2)));
        V v_b_2422 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2420, v_t_2421});
        V v_t_2423 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2415, 0), heff_take_field(v_b_2422, 0)));
        V v_t_2424 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2415, 1, 2), heff_get_n(v_b_2422, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2423, v_t_2424});
      }
      case TAG_BadFieldDecl: {
        V v_f_2425 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2426 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_f_2425));
        V v_b_2427 = (g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_rest_243));
        V v_t_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2426, 0), heff_take_field(v_b_2427, 0)));
        V v_t_2429 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2426, 1, 2), heff_get_n(v_b_2427, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2428, v_t_2429});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry, 2, 0};

V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2eelab_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_248));
        V v_t_2410 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2411 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_env_240}), v_rest_243));
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2413 = heff_tag_at_n(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_take_field(v_b_2411, 0)));
        V v_t_2415 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
        V v_b_2416 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2414, v_t_2415});
        V v_t_2417 = (g_prelude_2e_2b_2b(heff_take_field(v_a_249, 0), heff_take_field(v_b_2416, 0)));
        V v_t_2418 = (g_prelude_2e_2b_2b(heff_get_n(v_a_249, 1, 2), heff_get_n(v_b_2416, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2417, v_t_2418});
      }
      case TAG_StmtLet: {
        V v_p_2419 = heff_field(v_x311_244, 0);
        V v_e_2420 = heff_field(v_x311_244, 1);
        heff_take_n(v_x311_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2421 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2420));
        V v_bs_2422 = (g_heff_2eelab_2elocals_2epatternBinders(heff_dup(v_p_2419)));
        V v_env_2423 = (g_list_2efoldl_24f1677743806x2032371213(v_env_240, v_p_2419));
        V v_b_2424 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_2423, v_rest_243));
        V v_t_2425 = (g_prelude_2e_2b_2b(v_bs_2422, heff_take_field(v_b_2424, 0)));
        V v_t_2426 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2424, 1, 2)));
        V v_b_2427 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2425, v_t_2426});
        V v_t_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2421, 0), heff_take_field(v_b_2427, 0)));
        V v_t_2429 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2421, 1, 2), heff_get_n(v_b_2427, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2428, v_t_2429});
      }
      case TAG_StmtExpr: {
        V v_e_2430 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2431 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_2430));
        V v_b_2432 = (g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_rest_243));
        V v_t_2433 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2431, 0), heff_take_field(v_b_2432, 0)));
        V v_t_2434 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2431, 1, 2), heff_get_n(v_b_2432, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2433, v_t_2434});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(a[0], a[1]);
}
Clo g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_entry, 2, 0};

V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_take_field(v_b_2411, 0)));
      V v_t_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_entry, 2, 0};

V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_t_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_247 = (g_heff_2eelab_2elocals_2efindBinder(v_x_244, v_env_240));
      V v_a_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_245);
        v_a_2410 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_249 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_248, v_xsp_245}), NTAG(TAG_Nil)});
        v_a_2410 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_249});
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_246));
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2410, 0), heff_take_field(v_b_2411, 0)));
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2410, 1, 2), heff_get_n(v_b_2411, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x31_242, 0);
      V v_xsp_2415 = heff_field(v_x31_242, 1);
      V v_t_2416 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_2417 = (g_heff_2eelab_2elocals_2efindBinder(v_x_2414, v_env_240));
      V v_a_2420;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2415);
        v_a_2420 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2418 = heff_field(v_t_2417, 0);
        heff_take_n(v_t_2417, 1ULL, 1);
        V v_t_2419 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2418, v_xsp_2415}), NTAG(TAG_Nil)});
        v_a_2420 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2419});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      V v_b_2421 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2416));
      V v_t_2422 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2420, 0), heff_take_field(v_b_2421, 0)));
      V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2420, 1, 2), heff_get_n(v_b_2421, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2422, v_t_2423});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry, 2, 0};

V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x31_242, 0);
      V v_fsp_245 = heff_field(v_x31_242, 1);
      V v_ty_247 = heff_field(v_x31_242, 3);
      V v_eqs_248 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 27ULL, 5);
      V v_t_249 = (g_heff_2eelab_2elocals_2efindBinder(v_f_244, v_env_240));
      V v_a_2412;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_fsp_245);
        v_a_2412 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2410, v_fsp_245}), NTAG(TAG_Nil)});
        v_a_2412 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2411});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_a_2413 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_ty_247));
      V v_b_2419 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_t_2420 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2413, 0), heff_take_field(v_b_2419, 0)));
      V v_t_2421 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2413, 1, 2), heff_get_n(v_b_2419, 1, 2)));
      V v_b_2422 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2420, v_t_2421});
      V v_t_2423 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2412, 0), heff_take_field(v_b_2422, 0)));
      V v_t_2424 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2412, 1, 2), heff_get_n(v_b_2422, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2423, v_t_2424});
    }
    case TAG_DeclDefine: {
      V v_x_2425 = heff_field(v_x31_242, 0);
      V v_xsp_2426 = heff_field(v_x31_242, 1);
      V v_ps_2427 = heff_field(v_x31_242, 2);
      V v_u_2428 = heff_field(v_x31_242, 3);
      V v_body_2429 = heff_field(v_x31_242, 4);
      heff_take_n(v_x31_242, 31ULL, 5);
      V v_t_2430 = (g_heff_2eelab_2elocals_2efindBinder(v_x_2425, v_env_240));
      V v_a_2433;
      switch (heff_tag_of(v_t_2430)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2426);
        v_a_2433 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2431 = heff_field(v_t_2430, 0);
        heff_take_n(v_t_2430, 1ULL, 1);
        V v_t_2432 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2431, v_xsp_2426}), NTAG(TAG_Nil)});
        v_a_2433 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2432});
        break;
      }
      default: heff_nomatch(v_t_2430);
      }
      V v_a_2439 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_ps_2427; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2427); r_; });
      V v_a_2440 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_u_2428));
      V v_b_2441 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2429));
      V v_t_2442 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2440, 0), heff_take_field(v_b_2441, 0)));
      V v_t_2443 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2440, 1, 2), heff_get_n(v_b_2441, 1, 2)));
      V v_b_2444 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2442, v_t_2443});
      V v_t_2445 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2439, 0), heff_take_field(v_b_2444, 0)));
      V v_t_2446 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2439, 1, 2), heff_get_n(v_b_2444, 1, 2)));
      V v_b_2447 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2445, v_t_2446});
      V v_t_2448 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2433, 0), heff_take_field(v_b_2447, 0)));
      V v_t_2449 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2433, 1, 2), heff_get_n(v_b_2447, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2448, v_t_2449});
    }
    case TAG_DeclTheory: {
      V v_body_2453 = heff_field(v_x31_242, 3);
      heff_take_n(v_x31_242, 8ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_2453);
    }
    case TAG_DeclPrimitive: {
      V v_x_2454 = heff_field(v_x31_242, 0);
      V v_xsp_2455 = heff_field(v_x31_242, 1);
      V v_t_2456 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_2457 = (g_heff_2eelab_2elocals_2efindBinder(v_x_2454, v_env_240));
      V v_a_2460;
      switch (heff_tag_of(v_t_2457)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2455);
        v_a_2460 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2458 = heff_field(v_t_2457, 0);
        heff_take_n(v_t_2457, 1ULL, 1);
        V v_t_2459 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2458, v_xsp_2455}), NTAG(TAG_Nil)});
        v_a_2460 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2459});
        break;
      }
      default: heff_nomatch(v_t_2457);
      }
      V v_b_2461 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_2456));
      V v_t_2462 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2460, 0), heff_take_field(v_b_2461, 0)));
      V v_t_2463 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2460, 1, 2), heff_get_n(v_b_2461, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2462, v_t_2463});
    }
    case TAG_DeclTest: {
      V v_x_2464 = heff_field(v_x31_242, 0);
      V v_xsp_2465 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_t_2466 = ({ V a_0 = v_x_2464; V a_1 = v_env_240; V r_ = (g_heff_2eelab_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
      switch (heff_tag_of(v_t_2466)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2465);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_Just: {
        V v_b_2467 = heff_field(v_t_2466, 0);
        heff_take_n(v_t_2466, 1ULL, 1);
        V v_t_2468 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2467, v_xsp_2465}), NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2468});
      }
      default: return heff_nomatch(v_t_2466);
      }
    }
    case TAG_DeclWatch: {
      V v_e_2469 = heff_field(v_x31_242, 0);
      heff_take_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_2469);
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_eq_2415 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2416 = ({ V a_0 = v_env_240; V a_1 = v_eq_2415; V r_ = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(a_0, a_1)); heff_drop(v_eq_2415); r_; });
  V v_t_2417 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2414, 0), heff_take_field(v_b_2416, 0)));
  V v_t_2418 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2414, 1, 2), heff_get_n(v_b_2416, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2417, v_t_2418});
}
V g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032_lam1(V self, V *args) {
  V v_acc_2434 = args[0];
  V v_m_2435 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2436 = (g_heff_2eelab_2elocals_2eparamWalk_24s1013204304x593489074(v_env_240, v_m_2435));
  V v_t_2437 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2434, 0), heff_take_field(v_b_2436, 0)));
  V v_t_2438 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2434, 1, 2), heff_get_n(v_b_2436, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2437, v_t_2438});
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry, 2, 0};

V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      heff_take_n(v_d1_242, 24ULL, 5);
      heff_drop_tag(v_d_241, 2);
      V v_a_249 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), heff_dup(v_ty_247)));
      V v_b_2429 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
      V v_t_2430 = (g_prelude_2e_2b_2b(heff_take_field(v_a_249, 0), heff_take_field(v_b_2429, 0)));
      V v_t_2431 = (g_prelude_2e_2b_2b(heff_get_n(v_a_249, 1, 2), heff_get_n(v_b_2429, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2430, v_t_2431});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_d1_242, 0ULL, 5);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_d1_242, 0ULL, 4);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_d1_242, 0ULL, 3);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_d1_242, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2elocals_2edeclF_24s1100947554x154813032(v_env_240, v_d_241);
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_eq_2411 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2421;
  switch (heff_tag_of(v_eq_2411)) {
  case TAG_At: {
    V v_x21_2412 = heff_dup(heff_field(v_eq_2411, 0));
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_fsp_2415 = heff_field(v_x21_2412, 1);
      heff_take_n(v_x21_2412, 3ULL, 4);
      V v_t_2418 = (g_heff_2eelab_2elocals_2efindBinder(v_f_2414, v_env_240));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        heff_drop(v_fsp_2415);
        v_a_2421 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2419 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_2419, v_fsp_2415}), NTAG(TAG_Nil)});
        v_a_2421 = heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2420});
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    default: heff_nomatch(v_x21_2412);
    }
    break;
  }
  default: heff_nomatch(v_eq_2411);
  }
  V v_t_2422 = (g_list_2efoldl_24f1488358745x465096512(v_env_240, v_ty_247));
  V v_b_2423 = ({ V a_0 = v_t_2422; V a_1 = v_eq_2411; V r_ = (g_heff_2eelab_2elocals_2eequationF_24s1955903863x698695251(a_0, a_1)); heff_drop(v_eq_2411); r_; });
  V v_t_2424 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2421, 0), heff_take_field(v_b_2423, 0)));
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2421, 1, 2), heff_get_n(v_b_2423, 1, 2)));
  V v_b_2426 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2424, v_t_2425});
  V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2410, 0), heff_take_field(v_b_2426, 0)));
  V v_t_2428 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2410, 1, 2), heff_get_n(v_b_2426, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2427, v_t_2428});
}
Clo g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry, 3, 0};

V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_body_242));
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x3_241, 0);
    V v_ds_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_d1_245 = heff_dup(heff_field(v_d_243, 0));
      switch (heff_tag_of(v_d1_245)) {
      case TAG_DeclEquations: {
        V v_f_247 = heff_field(v_d1_245, 0);
        V v_fsp_248 = heff_field(v_d1_245, 1);
        heff_take_n(v_d1_245, 3ULL, 5);
        V v_t_2412 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_247, v_fsp_248, NTAG(TAG_False)});
        v_t_2428 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_d1_245, 0ULL, 5);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_d1_245, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_d1_245, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_d1_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_d1_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2428 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_d1_245);
      }
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_a_2429 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2453;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_d1_2430 = heff_dup(heff_field(v_d_243, 0));
      switch (heff_tag_of(v_d1_2430)) {
      case TAG_DeclEquations: {
        V v_f_2432 = heff_field(v_d1_2430, 0);
        V v_fsp_2433 = heff_field(v_d1_2430, 1);
        heff_take_n(v_d1_2430, 3ULL, 5);
        V v_t_2437 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2432, v_fsp_2433, NTAG(TAG_False)});
        v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_d1_2430, 0ULL, 5);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_d1_2430, 0ULL, 4);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_d1_2430, 0ULL, 3);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_d1_2430, 0ULL, 2);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_d1_2430, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_d1_2430);
      }
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_240), v_t_2453));
    V v_a_2455 = (g_heff_2eelab_2elocals_2elocalDefF_24s907292999x913984634(v_t_2454, heff_dup(v_d_243)));
    V v_t_2479;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_d1_2456 = heff_field(v_d_243, 0);
      V v_ru_24d_243_24At = heff_take_reuse_n(v_d_243, 1ULL, 2);
      switch (heff_tag_of(v_d1_2456)) {
      case TAG_DeclEquations: {
        V v_f_2458 = heff_field(v_d1_2456, 0);
        V v_fsp_2459 = heff_field(v_d1_2456, 1);
        heff_take_n(v_d1_2456, 3ULL, 5);
        V v_t_2463 = heff_rec_n(3, shape_name__span__field, (V[]){v_f_2458, v_fsp_2459, NTAG(TAG_False)});
        v_t_2479 = heff_tag_at_n(v_ru_24d_243_24At, TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
        break;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_d1_2456, 0ULL, 5);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2479 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_d1_2456, 0ULL, 4);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2479 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_d1_2456, 0ULL, 3);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2479 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_d1_2456, 0ULL, 2);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2479 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_d1_2456, 0ULL, 1);
        heff_drop_cell(v_ru_24d_243_24At, 2);
        v_t_2479 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_d1_2456);
      }
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2479));
    V v_b_2481 = (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_t_2480, v_ds_244, v_body_242));
    V v_t_2482 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2455, 0), heff_take_field(v_b_2481, 0)));
    V v_t_2483 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2455, 1, 2), heff_get_n(v_b_2481, 1, 2)));
    V v_b_2484 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2482, v_t_2483});
    V v_t_2485 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2429, 0), heff_take_field(v_b_2484, 0)));
    V v_t_2486 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2429, 1, 2), heff_get_n(v_b_2484, 1, 2)));
    return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2485, v_t_2486});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(a[0], a[1], a[2]);
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam0(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam2(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam1(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam3(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam4(V self, V *args);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam5(V self, V *args);
Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry, 2, 0};

V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V v_env_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      V v_t_245 = ({ V a_0 = v_x_244; V a_1 = v_env_240; V r_ = (g_heff_2eelab_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        heff_drop_tag(v_n_241, 2);
        return heff_dup(g_heff_2eelab_2elocals_2enone_get());
      }
      case TAG_Just: {
        V v_b_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_n_241)) {
        case TAG_At: {
          V v_s_248 = heff_field(v_n_241, 1);
          heff_take_n(v_n_241, 2ULL, 2);
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_n_241);
        }
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_binder__use, (V[]){v_b_246, v_t_249}), NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2410});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_ETag: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EInt: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EFloat: {
      heff_take_na(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EString: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EBinary: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_ERune: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EWord: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_n1_242, 0);
      V v_args_2420 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_2421 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_h_2419));
      V v_b_2427 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_2420); r_; });
      V v_t_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2421, 0), heff_take_field(v_b_2427, 0)));
      V v_t_2429 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2421, 1, 2), heff_get_n(v_b_2427, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2428, v_t_2429});
    }
    case TAG_EProject: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_ENamed: {
      V v_e_2432 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 2ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V t_0 = v_env_240;
      V t_1 = v_e_2432;
      v_env_240 = t_0;
      v_n_241 = t_1;
      goto top;
    }
    case TAG_EPi: {
      V v_n11_2433 = heff_field(v_n1_242, 0);
      V v_r_2434 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24EPi = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      switch (heff_tag_of(v_n11_2433)) {
      case TAG_PiNamed: {
        V v_x_2435 = heff_field(v_n11_2433, 0);
        V v_sp_2436 = heff_field(v_n11_2433, 1);
        V v_a_2437 = heff_field(v_n11_2433, 2);
        heff_take_n(v_n11_2433, 7ULL, 3);
        V v_a_2438 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2437));
        V v_t_2439 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2435), heff_dup(v_sp_2436), NTAG(TAG_False)});
        V v_t_2440 = heff_tag_at_n(v_ru_24n1_242_24EPi, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
        V v_env_2441 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2440));
        V v_b_2442 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2441, v_r_2434));
        V v_t_2443 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2435, v_sp_2436, NTAG(TAG_False)});
        V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
        V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2444, heff_take_field(v_b_2442, 0)));
        V v_t_2446 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2442, 1, 2)));
        V v_b_2447 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2445, v_t_2446});
        V v_t_2448 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2438, 0), heff_take_field(v_b_2447, 0)));
        V v_t_2449 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2438, 1, 2), heff_get_n(v_b_2447, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2448, v_t_2449});
      }
      case TAG_PiImplicit: {
        V v_x_2450 = heff_field(v_n11_2433, 0);
        V v_sp_2451 = heff_field(v_n11_2433, 1);
        V v_a_2453 = heff_field(v_n11_2433, 3);
        V v_d_2454 = heff_field(v_n11_2433, 4);
        heff_take_n(v_n11_2433, 27ULL, 5);
        V v_a_2455 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2453));
        V v_b_2457;
        switch (heff_tag_of(v_d_2454)) {
        case TAG_Nothing: {
          v_b_2457 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2456 = heff_field(v_d_2454, 0);
          heff_take_n(v_d_2454, 1ULL, 1);
          v_b_2457 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_x_2456));
          break;
        }
        default: heff_nomatch(v_d_2454);
        }
        V v_t_2458 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2455, 0), heff_take_field(v_b_2457, 0)));
        V v_t_2459 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2455, 1, 2), heff_get_n(v_b_2457, 1, 2)));
        V v_a_2460 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2458, v_t_2459});
        V v_t_2461 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2450), heff_dup(v_sp_2451), NTAG(TAG_False)});
        V v_t_2462 = heff_tag_at_n(v_ru_24n1_242_24EPi, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
        V v_env_2463 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2462));
        V v_b_2464 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2463, v_r_2434));
        V v_t_2465 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2450, v_sp_2451, NTAG(TAG_False)});
        V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, NTAG(TAG_Nil)});
        V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2466, heff_take_field(v_b_2464, 0)));
        V v_t_2468 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2464, 1, 2)));
        V v_b_2469 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2467, v_t_2468});
        V v_t_2470 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2460, 0), heff_take_field(v_b_2469, 0)));
        V v_t_2471 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2460, 1, 2), heff_get_n(v_b_2469, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2470, v_t_2471});
      }
      case TAG_PiInstance: {
        V v_x_2472 = heff_field(v_n11_2433, 0);
        V v_sp_2473 = heff_field(v_n11_2433, 1);
        V v_a_2475 = heff_field(v_n11_2433, 3);
        heff_take_n(v_n11_2433, 11ULL, 4);
        V v_a_2476 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2475));
        V v_t_2477 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2472), heff_dup(v_sp_2473), NTAG(TAG_False)});
        V v_t_2478 = heff_tag_at_n(v_ru_24n1_242_24EPi, TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
        V v_env_2479 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2478));
        V v_b_2480 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2479, v_r_2434));
        V v_t_2481 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2472, v_sp_2473, NTAG(TAG_False)});
        V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
        V v_t_2483 = (g_prelude_2e_2b_2b(v_t_2482, heff_take_field(v_b_2480, 0)));
        V v_t_2484 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2480, 1, 2)));
        V v_b_2485 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2483, v_t_2484});
        V v_t_2486 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2476, 0), heff_take_field(v_b_2485, 0)));
        V v_t_2487 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2476, 1, 2), heff_get_n(v_b_2485, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2486, v_t_2487});
      }
      case TAG_PiAnon: {
        V v_a_2488 = heff_field(v_n11_2433, 0);
        heff_take_n(v_n11_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24n1_242_24EPi, 2);
        V v_a_2489 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_2488));
        V v_b_2490 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_r_2434));
        V v_t_2491 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2489, 0), heff_take_field(v_b_2490, 0)));
        V v_t_2492 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2489, 1, 2), heff_get_n(v_b_2490, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2491, v_t_2492});
      }
      default: return heff_nomatch(v_n11_2433);
      }
    }
    case TAG_ELam: {
      V v_n11_2493 = heff_field(v_n1_242, 0);
      V v_r_2494 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24ELam = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      switch (heff_tag_of(v_n11_2493)) {
      case TAG_LamName: {
        heff_drop_cell(v_ru_24n1_242_24ELam, 2);
        V v_bs_2497 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_2493));
        V v_env_2498 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_2497)));
        V v_b_2499 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2498, v_r_2494));
        V v_t_24100 = (g_prelude_2e_2b_2b(v_bs_2497, heff_take_field(v_b_2499, 0)));
        V v_t_24101 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2499, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24100, v_t_24101});
      }
      case TAG_LamImplicit: {
        heff_drop_cell(v_ru_24n1_242_24ELam, 2);
        V v_bs_24104 = (g_heff_2eelab_2elocals_2elamBinders(v_n11_2493));
        V v_env_24105 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24104)));
        V v_b_24106 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24105, v_r_2494));
        V v_t_24107 = (g_prelude_2e_2b_2b(v_bs_24104, heff_take_field(v_b_24106, 0)));
        V v_t_24108 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24106, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24107, v_t_24108});
      }
      case TAG_LamAnn: {
        V v_x_24109 = heff_field(v_n11_2493, 0);
        V v_sp_24110 = heff_field(v_n11_2493, 1);
        V v_a_24111 = heff_field(v_n11_2493, 2);
        heff_take_n(v_n11_2493, 7ULL, 3);
        V v_a_24112 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_24111));
        V v_t_24113 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_24109), heff_dup(v_sp_24110), NTAG(TAG_False)});
        V v_t_24114 = heff_tag_at_n(v_ru_24n1_242_24ELam, TAG_Cons, 2, (V[]){v_t_24113, NTAG(TAG_Nil)});
        V v_env_24115 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_24114));
        V v_b_24116 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24115, v_r_2494));
        V v_t_24117 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_24109, v_sp_24110, NTAG(TAG_False)});
        V v_t_24118 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, NTAG(TAG_Nil)});
        V v_t_24119 = (g_prelude_2e_2b_2b(v_t_24118, heff_take_field(v_b_24116, 0)));
        V v_t_24120 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24116, 1, 2)));
        V v_b_24121 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24119, v_t_24120});
        V v_t_24122 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24112, 0), heff_take_field(v_b_24121, 0)));
        V v_t_24123 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24112, 1, 2), heff_get_n(v_b_24121, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24122, v_t_24123});
      }
      default: return heff_nomatch(v_n11_2493);
      }
    }
    case TAG_EAnn: {
      V v_e_24124 = heff_field(v_n1_242, 0);
      V v_t_24125 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_24126 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_e_24124));
      V v_b_24127 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_t_24125));
      V v_t_24128 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24126, 0), heff_take_field(v_b_24127, 0)));
      V v_t_24129 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24126, 1, 2), heff_get_n(v_b_24127, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24128, v_t_24129});
    }
    case TAG_ESpec: {
      V v_acc_24130 = heff_field(v_n1_242, 0);
      V v_v_24133 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 9ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_a_24134 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_acc_24130));
      V v_b_24135 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_v_24133));
      V v_t_24136 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24134, 0), heff_take_field(v_b_24135, 0)));
      V v_t_24137 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24134, 1, 2), heff_get_n(v_b_24135, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24136, v_t_24137});
    }
    case TAG_ESig: {
      V v_fs_24138 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2esigBlockF_24s1559264453x97179686(v_env_240, v_fs_24138);
    }
    case TAG_ESum: {
      V v_vs_24139 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam1, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_vs_24139; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24139); r_; });
    }
    case TAG_EStruct: {
      V v_fs_24156 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam3, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_fs_24156; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24156); r_; });
    }
    case TAG_EUpdate: {
      V v_a_24168 = heff_field(v_n1_242, 0);
      V v_fs_24169 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_24170 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_a_24168));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam4, 2, 1, (V[]){v_env_240}); V a_1 = v_t_24170; V a_2 = v_fs_24169; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24169); r_; });
    }
    case TAG_EMatch: {
      V v_s_24180 = heff_field(v_n1_242, 0);
      V v_alts_24181 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_24182 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_s_24180));
      V v_b_24197 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam5, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_alts_24181; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24181); r_; });
      V v_t_24198 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24182, 0), heff_take_field(v_b_24197, 0)));
      V v_t_24199 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24182, 1, 2), heff_get_n(v_b_24197, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24198, v_t_24199});
    }
    case TAG_ELetIn: {
      V v_rhs_24200 = heff_field(v_n1_242, 0);
      V v_a_24201 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_a_24202 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_rhs_24200));
      V v_b_24212;
      switch (heff_tag_of(v_a_24201)) {
      case TAG_At: {
        V v_x31_24203 = heff_field(v_a_24201, 0);
        heff_take_n(v_a_24201, 1ULL, 2);
        switch (heff_tag_of(v_x31_24203)) {
        case TAG_MkAlt: {
          V v_p_24205 = heff_field(v_x31_24203, 0);
          V v_r_24206 = heff_field(v_x31_24203, 1);
          heff_take_n(v_x31_24203, 3ULL, 2);
          V v_bs_24207 = (g_heff_2eelab_2elocals_2epatternBinders(v_p_24205));
          V v_env_24208 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24207)));
          V v_b_24209 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24208, v_r_24206));
          V v_t_24210 = (g_prelude_2e_2b_2b(v_bs_24207, heff_take_field(v_b_24209, 0)));
          V v_t_24211 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24209, 1, 2)));
          v_b_24212 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24210, v_t_24211});
          break;
        }
        default: heff_nomatch(v_x31_24203);
        }
        break;
      }
      default: heff_nomatch(v_a_24201);
      }
      V v_t_24213 = (g_prelude_2e_2b_2b(heff_take_field(v_a_24202, 0), heff_take_field(v_b_24212, 0)));
      V v_t_24214 = (g_prelude_2e_2b_2b(heff_get_n(v_a_24202, 1, 2), heff_get_n(v_b_24212, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24213, v_t_24214});
    }
    case TAG_EDo: {
      V v_stmts_24215 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      HEFF_LAST return g_heff_2eelab_2elocals_2edoBlockF_24s941340744x884793370(v_env_240, v_stmts_24215);
    }
    case TAG_ELocal: {
      V v_body_24216 = heff_field(v_n1_242, 0);
      V v_defs_24217 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      return (g_heff_2eelab_2elocals_2elocalsF_24s151542447x34979361(v_env_240, v_defs_24217, v_body_24216));
    }
    case TAG_EInvalid: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop(v_env_240);
      heff_drop_tag(v_n_241, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a[0], a[1]);
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam0(V self, V *args) {
  V v_acc_2422 = args[0];
  V v_x_2423 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2424 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_2423));
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_2422, 0), heff_take_field(v_b_2424, 0)));
  V v_t_2426 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_2422, 1, 2), heff_get_n(v_b_2424, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2425, v_t_2426});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam2(V self, V *args) {
  V v_acc_24147 = args[0];
  V v_x_24148 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24149 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_24148));
  V v_t_24150 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24147, 0), heff_take_field(v_b_24149, 0)));
  V v_t_24151 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24147, 1, 2), heff_get_n(v_b_24149, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24150, v_t_24151});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam1(V self, V *args) {
  V v_acc_24140 = args[0];
  V v_v_24141 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24153;
  switch (heff_tag_of(v_v_24141)) {
  case TAG_At: {
    V v_it1_24142 = heff_field(v_v_24141, 0);
    heff_take_n(v_v_24141, 1ULL, 2);
    switch (heff_tag_of(v_it1_24142)) {
    case TAG_TagVariant: {
      V v_args_24146 = heff_field(v_it1_24142, 2);
      heff_take_n(v_it1_24142, 4ULL, 3);
      v_b_24153 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam2, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_args_24146; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24146); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24152 = heff_field(v_it1_24142, 0);
      heff_take_n(v_it1_24142, 1ULL, 1);
      v_b_24153 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24152));
      break;
    }
    default: heff_nomatch(v_it1_24142);
    }
    break;
  }
  default: heff_nomatch(v_v_24141);
  }
  V v_t_24154 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24140, 0), heff_take_field(v_b_24153, 0)));
  V v_t_24155 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24140, 1, 2), heff_get_n(v_b_24153, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24154, v_t_24155});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam3(V self, V *args) {
  V v_acc_24157 = args[0];
  V v_f_24158 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24165;
  switch (heff_tag_of(v_f_24158)) {
  case TAG_At: {
    V v_x31_24159 = heff_field(v_f_24158, 0);
    heff_take_n(v_f_24158, 1ULL, 2);
    switch (heff_tag_of(v_x31_24159)) {
    case TAG_SetField: {
      V v_e_24163 = heff_field(v_x31_24159, 2);
      heff_take_n(v_x31_24159, 4ULL, 3);
      v_b_24165 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24163));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24164 = heff_field(v_x31_24159, 0);
      heff_take_n(v_x31_24159, 1ULL, 1);
      v_b_24165 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24164));
      break;
    }
    default: heff_nomatch(v_x31_24159);
    }
    break;
  }
  default: heff_nomatch(v_f_24158);
  }
  V v_t_24166 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24157, 0), heff_take_field(v_b_24165, 0)));
  V v_t_24167 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24157, 1, 2), heff_get_n(v_b_24165, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24166, v_t_24167});
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam4(V self, V *args) {
  V v_acc_24171 = args[0];
  V v_f_24172 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24172)) {
  case TAG_At: {
    V v_it1_24173 = heff_field(v_f_24172, 0);
    heff_take_n(v_f_24172, 1ULL, 2);
    switch (heff_tag_of(v_it1_24173)) {
    case TAG_SetPath: {
      V v_e_24176 = heff_field(v_it1_24173, 1);
      heff_take_n(v_it1_24173, 2ULL, 2);
      V v_b_24177 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_e_24176));
      V v_t_24178 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24171, 0), heff_take_field(v_b_24177, 0)));
      V v_t_24179 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24171, 1, 2), heff_get_n(v_b_24177, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24178, v_t_24179});
    }
    default: return heff_nomatch(v_it1_24173);
    }
  }
  default: return heff_nomatch(v_f_24172);
  }
}
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_lam5(V self, V *args) {
  V v_acc_24183 = args[0];
  V v_a_24184 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24194;
  switch (heff_tag_of(v_a_24184)) {
  case TAG_At: {
    V v_x31_24185 = heff_field(v_a_24184, 0);
    heff_take_n(v_a_24184, 1ULL, 2);
    switch (heff_tag_of(v_x31_24185)) {
    case TAG_MkAlt: {
      V v_p_24187 = heff_field(v_x31_24185, 0);
      V v_r_24188 = heff_field(v_x31_24185, 1);
      heff_take_n(v_x31_24185, 3ULL, 2);
      V v_bs_24189 = (g_heff_2eelab_2elocals_2epatternBinders(v_p_24187));
      V v_env_24190 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24189)));
      V v_b_24191 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_24190, v_r_24188));
      V v_t_24192 = (g_prelude_2e_2b_2b(v_bs_24189, heff_take_field(v_b_24191, 0)));
      V v_t_24193 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_24191, 1, 2)));
      v_b_24194 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_24192, v_t_24193});
      break;
    }
    default: heff_nomatch(v_x31_24185);
    }
    break;
  }
  default: heff_nomatch(v_a_24184);
  }
  V v_t_24195 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_24183, 0), heff_take_field(v_b_24194, 0)));
  V v_t_24196 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_24183, 1, 2), heff_get_n(v_b_24194, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_24195, v_t_24196});
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2earguments_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2earguments_entry, 3, 0};

V g_heff_2eelab_2elocals_2earguments(V v_env_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2eelab_2elocals_2earguments_lam0, 2, 1, (V[]){v_env_240}), heff_dup(g_heff_2eelab_2elocals_2enone_get()), v_rest_242);
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_tl_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_x211_2410 = heff_field(v_x21_248, 0);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 1ULL, 2);
      switch (heff_tag_of(v_x211_2410)) {
      case TAG_ExplicitParam: {
        V v_x_2412 = heff_field(v_x211_2410, 0);
        V v_sp_2413 = heff_field(v_x211_2410, 1);
        V v_t_2414 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2415 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2414));
        V v_t_2416 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2412), heff_dup(v_sp_2413), NTAG(TAG_False)});
        V v_b_2417 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2418 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2412, v_sp_2413, NTAG(TAG_False)});
        V v_t_2419 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, heff_take_field(v_b_2417, 0)));
        V v_t_2421 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2417, 1, 2)));
        V v_b_2422 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2420, v_t_2421});
        V v_t_2423 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2415, 0), heff_take_field(v_b_2422, 0)));
        V v_t_2424 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2415, 1, 2), heff_get_n(v_b_2422, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2423, v_t_2424});
      }
      case TAG_ImplicitParam: {
        V v_x_2425 = heff_field(v_x211_2410, 0);
        V v_sp_2426 = heff_field(v_x211_2410, 1);
        V v_t_2427 = heff_field(v_x211_2410, 2);
        heff_take_n(v_x211_2410, 7ULL, 3);
        V v_a_2428 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(heff_dup(v_env_240), v_t_2427));
        V v_t_2429 = heff_rec_n(3, shape_name__span__field, (V[]){heff_dup(v_x_2425), heff_dup(v_sp_2426), NTAG(TAG_False)});
        V v_b_2430 = (g_heff_2eelab_2elocals_2earguments(heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2429, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2431 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2425, v_sp_2426, NTAG(TAG_False)});
        V v_t_2432 = heff_tag_at_n(v_ru_24x21_248_24At, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
        V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2432, heff_take_field(v_b_2430, 0)));
        V v_t_2434 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2430, 1, 2)));
        V v_b_2435 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2433, v_t_2434});
        V v_t_2436 = (g_prelude_2e_2b_2b(heff_take_field(v_a_2428, 0), heff_take_field(v_b_2435, 0)));
        V v_t_2437 = (g_prelude_2e_2b_2b(heff_get_n(v_a_2428, 1, 2), heff_get_n(v_b_2435, 1, 2)));
        return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2436, v_t_2437});
      }
      default: return heff_nomatch(v_x211_2410);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2elocals_2earguments_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2elocals_2earguments(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2elocals_2earguments_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_245 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_240, v_x_244));
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_243, 0), heff_take_field(v_b_245, 0)));
  V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_243, 1, 2), heff_get_n(v_b_245, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_246, v_t_247});
}
Clo g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_entry, 2, 0};

V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_take_field(v_b_2411, 0)));
      V v_t_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get_n(v_b_2411, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2edeclaration_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2edeclaration_entry, 1, 0};

V g_heff_2eelab_2elocals_2edeclaration(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_eqs_247 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 24ULL, 5);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_a_248 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_ty_246)));
      V v_b_2415 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2elocals_2edeclaration_lam0, 2, 1, (V[]){v_ty_246}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_247); r_; });
      V v_t_2416 = (g_prelude_2e_2b_2b(heff_take_field(v_a_248, 0), heff_take_field(v_b_2415, 0)));
      V v_t_2417 = (g_prelude_2e_2b_2b(heff_get_n(v_a_248, 1, 2), heff_get_n(v_b_2415, 1, 2)));
      return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2416, v_t_2417});
    }
    case TAG_DeclDefine: {
      V v_ps_2420 = heff_field(v_x11_241, 2);
      V v_ty_2421 = heff_field(v_x11_241, 3);
      V v_body_2422 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 28ULL, 5);
      V v_t_2423 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2422, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2420; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_ty_2421, v_t_2423}); V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    }
    case TAG_DeclTheory: {
      V v_ps_2426 = heff_field(v_x11_241, 2);
      V v_body_2427 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 12ULL, 4);
      V v_t_2428 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_body_2427, NTAG(TAG_Nil)});
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2426; V a_2 = v_t_2428; V r_ = (g_heff_2eelab_2elocals_2earguments(a_0, a_1, a_2)); heff_drop_tag(v_t_2428, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      V v_t_2431 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_t_2431));
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(g_heff_2eelab_2elocals_2enone_get());
    }
    case TAG_DeclWatch: {
      V v_e_2434 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_e_2434));
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2elocals_2edeclaration_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2edeclaration(a[0]);
}
V g_heff_2eelab_2elocals_2edeclaration_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_eq_2410 = args[1];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_list_2efoldl_24f1488358745x465096512(NTAG(TAG_Nil), v_ty_246));
  V v_b_2412 = ({ V a_0 = v_t_2411; V a_1 = v_eq_2410; V r_ = (g_heff_2eelab_2elocals_2eequationF_24s99800829x2054143988(a_0, a_1)); heff_drop(v_eq_2410); r_; });
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_take_field(v_acc_249, 0), heff_take_field(v_b_2412, 0)));
  V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_249, 1, 2), heff_get_n(v_b_2412, 1, 2)));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2413, v_t_2414});
}
V g_heff_2eelab_2elocals_2elocalsOf_lam0(V self, V *args);
Clo g_heff_2eelab_2elocals_2elocalsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2elocals_2elocalsOf_entry, 1, 0};

V g_heff_2eelab_2elocals_2elocalsOf(V v_found_240) {
top: ;
  V v_t_241 = (g_list_2efilter_24s2018073091x1385246979(heff_dup(heff_rfield(v_found_240, 0))));
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2elocals_2elocalsOf_lam0, 1, 1, (V[]){heff_dup(v_found_240)}), v_t_241));
  V v_t_245 = (g_list_2emap_24f1133029339x682401273(heff_get_n(v_found_240, 1, 2)));
  return heff_rec_n(2, shape_locals__fields, (V[]){v_t_244, v_t_245});
}
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2elocals_2elocalsOf(a[0]);
}
V g_heff_2eelab_2elocals_2elocalsOf_lam0(V self, V *args) {
  V v_b_242 = args[0];
  V v_found_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_list_2emap_24f342794667x1308411312(heff_dup(v_b_242), heff_get_n(v_found_240, 1, 2)));
  return heff_rec_n(3, shape_name__binder__uses, (V[]){heff_dup(heff_rfield(v_b_242, 0)), heff_get_n(v_b_242, 1, 3), v_t_243});
}