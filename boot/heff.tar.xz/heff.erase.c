// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eerase_2eextend_lam0(V self, V *args);
V g_heff_2eerase_2eextend_lam1(V self, V *args);
Clo g_heff_2eerase_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eextend_entry, 3, 0};

V g_heff_2eerase_2eextend(V v_c_240, V v_ir_241, V v_ty_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_146_351, (V[]){v_ir_241, heff_dup(v_ty_242)}), heff_get(heff_dup(v_c_240), LBL_locals)});
  V v_t_244 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
  V v_v_246 = (g_heff_2evalue_2emkNeu_24s10(v_t_244, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2eextend_lam0, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_t_248 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2eextend_lam1, 1, 1, (V[]){v_v_246})});
  V v_t_249 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
  return heff_rec(4, shape_179_87_168_115, (V[]){v_t_243, v_t_248, v_t_249, heff_get(v_c_240, LBL_globals)});
}
V g_heff_2eerase_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eextend(a[0], a[1], a[2]);
}
V g_heff_2eerase_2eextend_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_245);
  return v_ty_242;
}
V g_heff_2eerase_2eextend_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_246;
}
V g_heff_2eerase_2eisType_lam1(V self, V *args);
V g_heff_2eerase_2eisType_lam0(V self, V *args);
Clo g_heff_2eerase_2eisType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eisType_entry, 2, 0};

V g_heff_2eerase_2eisType(V v_lvl_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2evalue_2ebehavior(v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_True);
  }
  case TAG_LikeFunction: {
    V v_dom_245 = heff_field(v_t_242, 1);
    V v_cod_246 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 6ULL, 4);
    V v_x1_2414;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkClo: {
      V v_vs_249 = heff_field(v_cod_246, 1);
      V v_body_2410 = heff_field(v_cod_246, 2);
      heff_take_n(v_cod_246, 6ULL, 3);
      v_x1_2414 = heff_tr(heff_apply(v_body_2410, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo(g_heff_2eerase_2eisType_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_245})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2413 = heff_field(v_cod_246, 0);
      heff_take_n(v_cod_246, 1ULL, 1);
      heff_drop(v_dom_245);
      v_x1_2414 = v_body_2413;
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nom: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2415;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      v_t_2418 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2417 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V t_0 = heff_intAdd(v_lvl_240, MK_INT(1LL));
    V t_1 = v_t_2418;
    v_lvl_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eerase_2eisType_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eisType(a[0], a[1]);
}
V g_heff_2eerase_2eisType_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_245;
}
V g_heff_2eerase_2eisType_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2evalue_2emkNeu_24s10(heff_tag(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2eisType_lam1, 1, 1, (V[]){v_dom_245}), NTAG(TAG_Nothing)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str0 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str1 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eerase_2eprojTyInWith_str2 = {{0x80000000u, K_STR, 0}, 14, 14, {116, 104, 101, 32, 116, 121, 112, 101, 32, 111, 102, 32, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2eprojTyInWith_str3 = {{0x80000000u, K_STR, 0}, 36, 36, {96, 32, 100, 101, 112, 101, 110, 100, 115, 32, 111, 110, 32, 102, 105, 101, 108, 100, 115, 32, 110, 111, 116, 32, 105, 110, 32, 104, 97, 110, 100, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str4 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str5 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str6 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str7 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str8 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str9 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2eprojTyInWith_lam0(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam0, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam1(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam1, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam2(V self, V *args);
V g_heff_2eerase_2eprojTyInWith_lam3(V self, V *args);
V g_heff_2eerase_2eprojTyInWith_lam4(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam4, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam5(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam5, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam6(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam6, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam7(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam7, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam8(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam8, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam9(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam9, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam10(V self, V *args);
Clo g_heff_2eerase_2eprojTyInWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_entry, 4, 0};

V g_heff_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243) {
top: ;
  V v_t_244 = (g_heff_2evalue_2eprojTyWith(heff_dup(v_t_241), v_fs_242, heff_dup(v_l_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_LikeU: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam0_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_245, 0ULL, 4);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam1_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2414 = heff_field(v_t_245, 1);
      V v_fieldTypes_2415 = heff_field(v_t_245, 2);
      heff_take_n(v_t_245, 6ULL, 3);
      V v_t_2416 = ({ V a_0 = heff_dup(v_l_243); V b_1 = heff_get(heff_dup(v_fieldTypes_2415), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2418;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        v_t_2418 = heff_abandon();
        break;
      }
      case TAG_Just: {
        V v_i_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        v_t_2418 = v_i_2417;
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_t_2419 = (g_heff_2erules_2efieldTyAt(v_len_240, v_capture_2414, v_fieldTypes_2415, v_t_2418, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        return heff_clo(g_heff_2eerase_2eprojTyInWith_lam2, 1, 1, (V[]){v_l_243});
      }
      case TAG_Just: {
        V v_ty_2422 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        heff_drop(v_l_243);
        return heff_clo(g_heff_2eerase_2eprojTyInWith_lam3, 1, 1, (V[]){v_ty_2422});
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam4_clo);
    }
    case TAG_LikeInt: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam5_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam6_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam7_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam8_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam9_clo);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    V v_ty_2432 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_len_240);
    heff_drop(v_t_241);
    heff_drop(v_l_243);
    return heff_clo(g_heff_2eerase_2eprojTyInWith_lam10, 1, 1, (V[]){v_ty_2432});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eerase_2eprojTyInWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eprojTyInWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2eerase_2eprojTyInWith_lam0(V self, V *args) {
  V v_n_247 = args[0];
  heff_drop(v_n_247);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str0)});
}
V g_heff_2eerase_2eprojTyInWith_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str1)});
}
V g_heff_2eerase_2eprojTyInWith_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_l_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2420);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eerase_2eprojTyInWith_str2), heff_strAppend(v_l_243, ((V)&g_heff_2eerase_2eprojTyInWith_str3)));
  return heff_tag(TAG_Left, 1, (V[]){v_t_2421});
}
V g_heff_2eerase_2eprojTyInWith_lam3(V self, V *args) {
  V v_n_2423 = args[0];
  V v_ty_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_ty_2422, v_n_2423})});
}
V g_heff_2eerase_2eprojTyInWith_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  heff_drop(v_n_2425);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str4)});
}
V g_heff_2eerase_2eprojTyInWith_lam5(V self, V *args) {
  V v_n_2426 = args[0];
  heff_drop(v_n_2426);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str5)});
}
V g_heff_2eerase_2eprojTyInWith_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  heff_drop(v_n_2427);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str6)});
}
V g_heff_2eerase_2eprojTyInWith_lam7(V self, V *args) {
  V v_n_2428 = args[0];
  heff_drop(v_n_2428);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str7)});
}
V g_heff_2eerase_2eprojTyInWith_lam8(V self, V *args) {
  V v_n_2430 = args[0];
  heff_drop(v_n_2430);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str8)});
}
V g_heff_2eerase_2eprojTyInWith_lam9(V self, V *args) {
  V v_n_2431 = args[0];
  heff_drop(v_n_2431);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str9)});
}
V g_heff_2eerase_2eprojTyInWith_lam10(V self, V *args) {
  V v_n_2433 = args[0];
  V v_ty_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_ty_2432, v_n_2433})});
}
Clo g_heff_2eerase_2eprojWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojWith_entry, 3, 0};

V g_heff_2eerase_2eprojWith(V v_x1_240, V v_v_241, V v_l_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return (g_heff_2evalue_2eproj(v_v_241, v_l_242));
  }
  case TAG_Just: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    heff_drop(v_v_241);
    V v_t_244 = ({ V a_0 = v_l_242; V b_1 = heff_get(heff_dup(v_fs_243), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_xs_246 = heff_get(heff_dup(v_fs_243), LBL_values);
      V v_t_247 = heff_intLe(MK_INT(0LL), heff_dup(v_i_245));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_t_248 = heff_intLt(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          return v_v_249;
        }
        case TAG_False: {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      case TAG_False: {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2eprojWith_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eerase_2eprojWith(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str0 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str1 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str2 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str3 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str4 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str5 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str6 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str7 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2ematchVariants_lam0(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam0, 1, 0};
V g_heff_2eerase_2ematchVariants_lam1(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam1, 1, 0};
V g_heff_2eerase_2ematchVariants_lam2(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam2, 1, 0};
V g_heff_2eerase_2ematchVariants_lam3(V self, V *args);
V g_heff_2eerase_2ematchVariants_lam4(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam4, 1, 0};
V g_heff_2eerase_2ematchVariants_lam5(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam5, 1, 0};
V g_heff_2eerase_2ematchVariants_lam6(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam6, 1, 0};
V g_heff_2eerase_2ematchVariants_lam7(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam7, 1, 0};
V g_heff_2eerase_2ematchVariants_lam8(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam8, 1, 0};
Clo g_heff_2eerase_2ematchVariants_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_entry, 1, 0};

V g_heff_2eerase_2ematchVariants(V v_sty_240) {
top: ;
  V v_t_241 = (g_heff_2evalue_2ebehavior(v_sty_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_LikeU: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2eerase_2ematchVariants_lam0_clo);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_241, 0ULL, 4);
    return ((V)&g_heff_2eerase_2ematchVariants_lam1_clo);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_241, 0ULL, 3);
    return ((V)&g_heff_2eerase_2ematchVariants_lam2_clo);
  }
  case TAG_LikeSum: {
    V v_vs_2413 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    return heff_clo(g_heff_2eerase_2ematchVariants_lam3, 1, 1, (V[]){v_vs_2413});
  }
  case TAG_LikeInt: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam4_clo);
  }
  case TAG_LikeFloat: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam5_clo);
  }
  case TAG_LikeString: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam6_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2eerase_2ematchVariants_lam7_clo);
  }
  case TAG_NoRules: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam8_clo);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2ematchVariants_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2ematchVariants(a[0]);
}
V g_heff_2eerase_2ematchVariants_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str0)});
}
V g_heff_2eerase_2ematchVariants_lam1(V self, V *args) {
  V v_n_248 = args[0];
  heff_drop(v_n_248);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str1)});
}
V g_heff_2eerase_2ematchVariants_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str2)});
}
V g_heff_2eerase_2ematchVariants_lam3(V self, V *args) {
  V v_n_2414 = args[0];
  V v_vs_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_vs_2413, v_n_2414})});
}
V g_heff_2eerase_2ematchVariants_lam4(V self, V *args) {
  V v_n_2415 = args[0];
  heff_drop(v_n_2415);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str3)});
}
V g_heff_2eerase_2ematchVariants_lam5(V self, V *args) {
  V v_n_2416 = args[0];
  heff_drop(v_n_2416);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str4)});
}
V g_heff_2eerase_2ematchVariants_lam6(V self, V *args) {
  V v_n_2417 = args[0];
  heff_drop(v_n_2417);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str5)});
}
V g_heff_2eerase_2ematchVariants_lam7(V self, V *args) {
  V v_n_2419 = args[0];
  heff_drop(v_n_2419);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str6)});
}
V g_heff_2eerase_2ematchVariants_lam8(V self, V *args) {
  V v_n_2420 = args[0];
  heff_drop(v_n_2420);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str7)});
}
Clo g_heff_2eerase_2eargTysOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eargTysOf_entry, 2, 0};

V g_heff_2eerase_2eargTysOf(V v_vs_240, V v_tag_241) {
top: ;
  V v_t_242 = ({ V a_0 = v_tag_241; V b_1 = heff_get(heff_dup(v_vs_240), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_vs_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_i_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_xs_244 = heff_get(v_vs_240, LBL_values);
    V v_t_245 = heff_intLe(MK_INT(0LL), heff_dup(v_i_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intLt(heff_dup(v_i_243), heff_arrayLength(heff_dup(v_xs_244)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        V v_ts_247 = heff_arrayIndex(v_xs_244, v_i_243);
        return (g_prelude_2emap_24s431(heff_arrayToList(v_ts_247)));
      }
      case TAG_False: {
        heff_drop(v_i_243);
        heff_drop(v_xs_244);
        return NTAG(TAG_Nil);
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop(v_xs_244);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eerase_2eargTysOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eargTysOf(a[0], a[1]);
}
Clo g_heff_2eerase_2ezipE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ezipE_entry, 2, 0};

V g_heff_2eerase_2ezipE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eerase_2ezipE(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2ezipE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2ezipE(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
V g_heff_2eerase_2earmBindGo_lam0(V self, V *args);
V g_heff_2eerase_2earmBindGo_lam1(V self, V *args);
Clo g_heff_2eerase_2earmBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmBindGo_entry, 2, 0};

V g_heff_2eerase_2earmBindGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_vars)));
    V v_x_243 = heff_rec(2, shape_36_369, (V[]){heff_get(v_acc_240, LBL_c), v_t_242});
    return heff_clo(g_heff_2eerase_2earmBindGo_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x21_245, 0);
      V v_aty_248 = heff_field(v_x21_245, 1);
      heff_take_n(v_x21_245, 3ULL, 2);
      V v_t_249 = heff_get(heff_get(heff_dup(v_acc_240), LBL_c), LBL_len);
      V v_t_2410 = (g_heff_2eerase_2eisType(v_t_249, heff_dup(v_aty_248)));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_x_247);
        V v_t_2411 = (g_heff_2eerase_2eextend(heff_get(heff_dup(v_acc_240), LBL_c), NTAG(TAG_Nothing), v_aty_248));
        V v_t_2412 = heff_rec(2, shape_36_369, (V[]){v_t_2411, heff_get(v_acc_240, LBL_vars)});
        V t_0 = v_t_2412;
        V t_1 = v_rest_246;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_clo(g_heff_2eerase_2earmBindGo_lam1, 1, 4, (V[]){v_x_247, v_acc_240, v_aty_248, v_rest_246});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eerase_2earmBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2earmBindGo(a[0], a[1]);
}
V g_heff_2eerase_2earmBindGo_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_243, v_n_244})});
}
V g_heff_2eerase_2earmBindGo_lam1(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_aty_248 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_strEq(heff_dup(v_x_247), ((V)&g_heff_2eerase_2earmBindGo_str0));
  V v_base_2416;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop(v_x_247);
    v_base_2416 = ((V)&g_heff_2eerase_2earmBindGo_str1);
    break;
  }
  case TAG_False: {
    V v_t_2415 = heff_strEq(heff_dup(v_x_247), ((V)&g_heff_2eerase_2earmBindGo_str2));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      heff_drop(v_x_247);
      v_base_2416 = ((V)&g_heff_2eerase_2earmBindGo_str3);
      break;
    }
    case TAG_False: {
      v_base_2416 = v_x_247;
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2417 = heff_strAppend(v_base_2416, heff_strAppend(((V)&g_heff_2eerase_2earmBindGo_str4), heff_intShow(heff_dup(v_n_2413))));
  V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2417, heff_intAdd(v_n_2413, MK_INT(1LL))});
  V v_x2_2419 = heff_tag(TAG_Right, 1, (V[]){v_t_2418});
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Left: {
    V v_e_2420 = heff_field(v_x2_2419, 0);
    V v_ru_24x2_2419_24Left = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
    heff_drop(v_acc_240);
    heff_drop(v_aty_248);
    heff_drop(v_rest_246);
    return heff_tag_at(v_ru_24x2_2419_24Left, TAG_Left, 1, (V[]){v_e_2420});
  }
  case TAG_Right: {
    V v_x21_2421 = heff_field(v_x2_2419, 0);
    V v_ru_24x2_2419_24Right = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x21_2421, 0);
      V v_n_2423 = heff_field(v_x21_2421, 1);
      V v_ru_24x21_2421_24MkPair = heff_take_reuse_n(v_x21_2421, 3ULL, 2);
      V v_t_2424 = heff_tag_at(v_ru_24x2_2419_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2422)})});
      V v_t_2425 = (g_heff_2eerase_2eextend(heff_get(heff_dup(v_acc_240), LBL_c), v_t_2424, v_aty_248));
      V v_t_2426 = heff_tag_at(v_ru_24x21_2421_24MkPair, TAG_Cons, 2, (V[]){v_x_2422, heff_get(v_acc_240, LBL_vars)});
      V v_t_2427 = (g_heff_2eerase_2earmBindGo(heff_rec(2, shape_36_369, (V[]){v_t_2425, v_t_2426}), v_rest_246));
      V f_ = v_t_2427;
      args[0] = v_n_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
Clo g_heff_2eerase_2enthLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2enthLocal_entry, 2, 0};

V g_heff_2eerase_2enthLocal(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_l_242)});
    }
    case TAG_False: {
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2enthLocal_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eerase_2enthLocal(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eerase_2etraverseM_lam0(V self, V *args); static Clo g_heff_2eerase_2etraverseM_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2etraverseM_lam0, 1, 0};
V g_heff_2eerase_2etraverseM_lam1(V self, V *args);
Clo g_heff_2eerase_2etraverseM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2etraverseM_entry, 2, 0};

V g_heff_2eerase_2etraverseM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eerase_2etraverseM_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo(g_heff_2eerase_2etraverseM_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eerase_2etraverseM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2etraverseM(a[0], a[1]);
}
V g_heff_2eerase_2etraverseM_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
  return heff_tag(TAG_Right, 1, (V[]){v_t_243});
}
V g_heff_2eerase_2etraverseM_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_xs_245);
    return heff_tag_at(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_m_2413 = (g_heff_2eerase_2etraverseM(v_f_240, v_xs_245));
      V v_x2_2414 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_n_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24x21_2410_24MkPair, 2);
        return heff_tag_at(v_ru_24x2_248_24Right, TAG_Left, 1, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x21_2416 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        switch (heff_tag_of(v_x21_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x21_2416, 0);
          V v_n_2418 = heff_field(v_x21_2416, 1);
          heff_take_n(v_x21_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417}), v_n_2418});
          return heff_tag_at(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_x21_2416);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2eerase_2ecatMaybesE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ecatMaybesE_entry, 1, 0};

V g_heff_2eerase_2ecatMaybesE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eerase_2ecatMaybesE(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2ecatMaybesE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2ecatMaybesE(a[0]);
}
V g_heff_2eerase_2echkDField_24s536_lam0(V self, V *args);
Clo g_heff_2eerase_2echkDField_24s536_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkDField_24s536_entry, 5, 0};

V g_heff_2eerase_2echkDField_24s536(V v_c_240, V v_ty_241, V v_v_242, V v_fs_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkPair: {
    V v_l_245 = heff_field(v_x6_244, 0);
    V v_fe_246 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_m_247 = (g_heff_2eerase_2eprojTyInWith(heff_get(heff_dup(v_c_240), LBL_len), v_ty_241, heff_dup(v_fs_243), heff_dup(v_l_245)));
    return heff_clo(g_heff_2eerase_2echkDField_24s536_lam0, 1, 6, (V[]){v_m_247, v_c_240, v_fs_243, v_v_242, v_l_245, v_fe_246});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eerase_2echkDField_24s536_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkDField_24s536(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eerase_2echkDField_24s536_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fs_243 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_l_245 = heff_env(self)[4];
  V v_fe_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_fs_243);
    heff_drop(v_v_242);
    heff_drop(v_l_245);
    heff_drop(v_fe_246);
    return heff_tag_at(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_x_2412)));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop(v_c_240);
        heff_drop(v_fs_243);
        heff_drop(v_v_242);
        heff_drop(v_l_245);
        heff_drop(v_fe_246);
        heff_drop(v_x_2412);
        V v_t_2415 = heff_tag_at(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2413});
        return heff_tag_at(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){v_t_2415});
      }
      case TAG_False: {
        V v_x1_2416 = ({ V a_0 = v_fs_243; V a_1 = v_v_242; V a_2 = heff_dup(v_l_245); V r_ = (g_heff_2eerase_2eprojWith(a_0, a_1, a_2)); heff_drop(v_fs_243); r_; });
        V v_v_2420;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nom: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2417;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2416, 0ULL, 1);
          v_v_2420 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2419 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_m_2421 = (g_heff_2eerase_2echkDF_24s534(v_c_240, v_fe_246, v_x_2412, v_v_2420));
        V v_x2_2422 = heff_tr(heff_apply(v_m_2421, 1, (V[]){v_n_2413}));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_Left: {
          V v_e_2423 = heff_field(v_x2_2422, 0);
          heff_take_n(v_x2_2422, 1ULL, 1);
          heff_drop(v_l_245);
          heff_drop_cell(v_ru_24x21_2411_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_249_24Right, TAG_Left, 1, (V[]){v_e_2423});
        }
        case TAG_Right: {
          V v_x21_2424 = heff_field(v_x2_2422, 0);
          V v_ru_24x2_2422_24Right = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
          switch (heff_tag_of(v_x21_2424)) {
          case TAG_MkPair: {
            V v_x_2425 = heff_field(v_x21_2424, 0);
            V v_n_2426 = heff_field(v_x21_2424, 1);
            heff_take_n(v_x21_2424, 3ULL, 2);
            V v_t_2427 = heff_tag_at(v_ru_24x2_249_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_245, v_x_2425})});
            return heff_tag_at(v_ru_24x2_2422_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2427, v_n_2426})});
          }
          default: return heff_nomatch(v_x21_2424);
          }
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2eerase_2echkDFields_24s535_lam0(V self, V *args);
V g_heff_2eerase_2echkDFields_24s535_lam1(V self, V *args);
Clo g_heff_2eerase_2echkDFields_24s535_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkDFields_24s535_entry, 5, 0};

V g_heff_2eerase_2echkDFields_24s535(V v_c_240, V v_ty_241, V v_v_242, V v_ps_243, V v_fs_244) {
top: ;
  V v_m_246 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2echkDFields_24s535_lam0, 1, 4, (V[]){v_c_240, v_ty_241, v_v_242, v_fs_244}), v_ps_243));
  return heff_clo(g_heff_2eerase_2echkDFields_24s535_lam1, 1, 1, (V[]){v_m_246});
}
V g_heff_2eerase_2echkDFields_24s535_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkDFields_24s535(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eerase_2echkDFields_24s535_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ty_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_fs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eerase_2echkDField_24s536(v_c_240, v_ty_241, v_v_242, v_fs_244, v_p_245));
}
V g_heff_2eerase_2echkDFields_24s535_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_x_2413 = heff_tag_at(v_ru_24x2_248_24Right, TAG_ERecord, 1, (V[]){(g_heff_2eerase_2ecatMaybesE(v_x_2411))});
      return heff_tag(TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_n_2412})});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str0 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s538_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s538_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s538_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s538_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s538_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s538_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str7 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str8 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str9 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str10 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str11 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str12 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s538_str13 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2echkLam_24s538_lam0(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam0, 1, 0};
V g_heff_2eerase_2echkLam_24s538_lam1(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam2(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam4(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam3(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam6(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam7(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam9(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam8(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam5(V self, V *args);
V g_heff_2eerase_2echkLam_24s538_lam10(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam10, 1, 0};
V g_heff_2eerase_2echkLam_24s538_lam11(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam11, 1, 0};
V g_heff_2eerase_2echkLam_24s538_lam12(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam12, 1, 0};
V g_heff_2eerase_2echkLam_24s538_lam13(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam13, 1, 0};
V g_heff_2eerase_2echkLam_24s538_lam14(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam14, 1, 0};
V g_heff_2eerase_2echkLam_24s538_lam15(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam15, 1, 0};
V g_heff_2eerase_2echkLam_24s538_lam16(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s538_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_lam16, 1, 0};
Clo g_heff_2eerase_2echkLam_24s538_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s538_entry, 3, 0};

V g_heff_2eerase_2echkLam_24s538(V v_c_240, V v_abs_241, V v_ty_242) {
top: ;
  V v_t_243 = (g_heff_2evalue_2ebehavior(v_ty_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_LikeU: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam0_clo);
  }
  case TAG_LikeFunction: {
    V v_dom_247 = heff_field(v_t_243, 1);
    V v_cod_248 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 4);
    V v_it_2415;
    switch (heff_tag_of(v_abs_241)) {
    case TAG_MkAbs: {
      V v_n_2410 = heff_field(v_abs_241, 0);
      V v_b_2411 = heff_field(v_abs_241, 1);
      V v_ru_24abs_241_24MkAbs = heff_take_reuse_n(v_abs_241, 3ULL, 2);
      V v_t_2412 = heff_tag_at(v_ru_24abs_241_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2410, NTAG(TAG_True)});
      v_it_2415 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2412, v_b_2411});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_abs_241, 0);
      heff_take_n(v_abs_241, 1ULL, 1);
      V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str1), NTAG(TAG_False)});
      v_it_2415 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2414, v_b_2413});
      break;
    }
    default: heff_nomatch(v_abs_241);
    }
    switch (heff_tag_of(v_it_2415)) {
    case TAG_MkPair: {
      V v_it1_2416 = heff_field(v_it_2415, 0);
      V v_body_2417 = heff_field(v_it_2415, 1);
      V v_ru_24it_2415_24MkPair = heff_take_reuse_n(v_it_2415, 3ULL, 2);
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_MkPair: {
        V v_hint_2418 = heff_field(v_it1_2416, 0);
        V v_bound_2419 = heff_field(v_it1_2416, 1);
        V v_ru_24it1_2416_24MkPair = heff_take_reuse_n(v_it1_2416, 3ULL, 2);
        V v_t_2420 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_dom_247)));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_True: {
          heff_drop(v_hint_2418);
          V v_c_2429;
          switch (heff_tag_of(v_bound_2419)) {
          case TAG_True: {
            V v_t_2421 = heff_rec(2, shape_146_351, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_247)});
            V v_t_2422 = heff_tag_at(v_ru_24it_2415_24MkPair, TAG_Cons, 2, (V[]){v_t_2421, heff_get(heff_dup(v_c_240), LBL_locals)});
            V v_t_2423 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
            V v_v_2425 = (g_heff_2evalue_2emkNeu_24s10(v_t_2423, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s538_lam1, 1, 1, (V[]){heff_dup(v_dom_247)}), NTAG(TAG_Nothing)));
            V v_t_2427 = heff_tag_at(v_ru_24it1_2416_24MkPair, TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkLam_24s538_lam2, 1, 1, (V[]){v_v_2425})});
            V v_t_2428 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
            v_c_2429 = heff_rec(4, shape_179_87_168_115, (V[]){v_t_2422, v_t_2427, v_t_2428, heff_get(heff_dup(v_c_240), LBL_globals)});
            break;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24it_2415_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2416_24MkPair, 2);
            v_c_2429 = heff_dup(v_c_240);
            break;
          }
          default: heff_nomatch(v_bound_2419);
          }
          V v_x1_2437;
          switch (heff_tag_of(v_cod_248)) {
          case TAG_MkClo: {
            V v_vs_2431 = heff_field(v_cod_248, 1);
            V v_body_2432 = heff_field(v_cod_248, 2);
            heff_take_n(v_cod_248, 6ULL, 3);
            v_x1_2437 = heff_tr(heff_apply(v_body_2432, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo(g_heff_2eerase_2echkLam_24s538_lam3, 1, 2, (V[]){v_c_240, v_dom_247})})}));
            break;
          }
          case TAG_CloConst: {
            V v_body_2436 = heff_field(v_cod_248, 0);
            heff_take_n(v_cod_248, 1ULL, 1);
            heff_drop(v_c_240);
            heff_drop(v_dom_247);
            v_x1_2437 = v_body_2436;
            break;
          }
          default: heff_nomatch(v_cod_248);
          }
          V v_ty_2441;
          switch (heff_tag_of(v_x1_2437)) {
          case TAG_Nom: {
            V v_x_2438 = heff_field(v_x1_2437, 0);
            heff_take_n(v_x1_2437, 1ULL, 1);
            v_ty_2441 = v_x_2438;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2437, 0ULL, 1);
            v_ty_2441 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2440 = heff_field(v_x1_2437, 0);
            heff_take_n(v_x1_2437, 1ULL, 1);
            v_ty_2441 = v_x_2440;
            break;
          }
          default: heff_nomatch(v_x1_2437);
          }
          HEFF_LAST return g_heff_2eerase_2echkF_24s537(v_c_2429, v_body_2417, v_ty_2441);
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24it_2415_24MkPair, 2);
          heff_drop_cell(v_ru_24it1_2416_24MkPair, 2);
          return heff_clo(g_heff_2eerase_2echkLam_24s538_lam5, 1, 6, (V[]){v_hint_2418, v_bound_2419, v_dom_247, v_c_240, v_cod_248, v_body_2417});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      default: return heff_nomatch(v_it1_2416);
      }
    }
    default: return heff_nomatch(v_it_2415);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam10_clo);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam11_clo);
  }
  case TAG_LikeInt: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam12_clo);
  }
  case TAG_LikeFloat: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam13_clo);
  }
  case TAG_LikeString: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam14_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam15_clo);
  }
  case TAG_NoRules: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s538_lam16_clo);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eerase_2echkLam_24s538_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkLam_24s538(a[0], a[1], a[2]);
}
V g_heff_2eerase_2echkLam_24s538_lam0(V self, V *args) {
  V v_n_245 = args[0];
  heff_drop(v_n_245);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str0)});
}
V g_heff_2eerase_2echkLam_24s538_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s538_lam2(V self, V *args) {
  V v_u_2426 = args[0];
  V v_v_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2426);
  return v_v_2425;
}
V g_heff_2eerase_2echkLam_24s538_lam4(V self, V *args) {
  V v_u_2435 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2435);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s538_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2433);
  V v_t_2434 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s10(v_t_2434, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s538_lam4, 1, 1, (V[]){v_dom_247}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkLam_24s538_lam6(V self, V *args) {
  V v_u_2456 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s538_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_v_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  return v_v_2457;
}
V g_heff_2eerase_2echkLam_24s538_lam9(V self, V *args) {
  V v_u_2467 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s538_lam8(V self, V *args) {
  V v_u_2465 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2465);
  V v_t_2466 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s10(v_t_2466, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s538_lam9, 1, 1, (V[]){v_dom_247}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkLam_24s538_lam5(V self, V *args) {
  V v_n_2442 = args[0];
  V v_hint_2418 = heff_env(self)[0];
  V v_bound_2419 = heff_env(self)[1];
  V v_dom_247 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_cod_248 = heff_env(self)[4];
  V v_body_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443 = heff_strEq(heff_dup(v_hint_2418), ((V)&g_heff_2eerase_2echkLam_24s538_str2));
  V v_base_2445;
  switch (heff_tag_of(v_t_2443)) {
  case TAG_True: {
    heff_drop(v_hint_2418);
    v_base_2445 = ((V)&g_heff_2eerase_2echkLam_24s538_str3);
    break;
  }
  case TAG_False: {
    V v_t_2444 = heff_strEq(heff_dup(v_hint_2418), ((V)&g_heff_2eerase_2echkLam_24s538_str4));
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      heff_drop(v_hint_2418);
      v_base_2445 = ((V)&g_heff_2eerase_2echkLam_24s538_str5);
      break;
    }
    case TAG_False: {
      v_base_2445 = v_hint_2418;
      break;
    }
    default: heff_nomatch(v_t_2444);
    }
    break;
  }
  default: heff_nomatch(v_t_2443);
  }
  V v_t_2446 = heff_strAppend(v_base_2445, heff_strAppend(((V)&g_heff_2eerase_2echkLam_24s538_str6), heff_intShow(heff_dup(v_n_2442))));
  V v_t_2447 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2446, heff_intAdd(v_n_2442, MK_INT(1LL))});
  V v_x2_2448 = heff_tag(TAG_Right, 1, (V[]){v_t_2447});
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_Left: {
    V v_e_2449 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Left = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    heff_drop(v_bound_2419);
    heff_drop(v_dom_247);
    heff_drop(v_c_240);
    heff_drop(v_cod_248);
    heff_drop(v_body_2417);
    return heff_tag_at(v_ru_24x2_2448_24Left, TAG_Left, 1, (V[]){v_e_2449});
  }
  case TAG_Right: {
    V v_x21_2450 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Right = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    switch (heff_tag_of(v_x21_2450)) {
    case TAG_MkPair: {
      V v_x_2451 = heff_field(v_x21_2450, 0);
      V v_n_2452 = heff_field(v_x21_2450, 1);
      V v_ru_24x21_2450_24MkPair = heff_take_reuse_n(v_x21_2450, 3ULL, 2);
      V v_c_2461;
      switch (heff_tag_of(v_bound_2419)) {
      case TAG_True: {
        V v_t_2453 = heff_tag_at(v_ru_24x2_2448_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2451)})});
        V v_t_2454 = heff_tag_at(v_ru_24x21_2450_24MkPair, TAG_Cons, 2, (V[]){heff_rec(2, shape_146_351, (V[]){v_t_2453, heff_dup(v_dom_247)}), heff_get(heff_dup(v_c_240), LBL_locals)});
        V v_t_2455 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
        V v_v_2457 = (g_heff_2evalue_2emkNeu_24s10(v_t_2455, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s538_lam6, 1, 1, (V[]){heff_dup(v_dom_247)}), NTAG(TAG_Nothing)));
        V v_t_2459 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkLam_24s538_lam7, 1, 1, (V[]){v_v_2457})});
        V v_t_2460 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
        v_c_2461 = heff_rec(4, shape_179_87_168_115, (V[]){v_t_2454, v_t_2459, v_t_2460, heff_get(heff_dup(v_c_240), LBL_globals)});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_2448_24Right, 1);
        heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
        v_c_2461 = heff_dup(v_c_240);
        break;
      }
      default: heff_nomatch(v_bound_2419);
      }
      V v_x1_2469;
      switch (heff_tag_of(v_cod_248)) {
      case TAG_MkClo: {
        V v_vs_2463 = heff_field(v_cod_248, 1);
        V v_body_2464 = heff_field(v_cod_248, 2);
        heff_take_n(v_cod_248, 6ULL, 3);
        v_x1_2469 = heff_tr(heff_apply(v_body_2464, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2463, heff_clo(g_heff_2eerase_2echkLam_24s538_lam8, 1, 2, (V[]){v_c_240, v_dom_247})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2468 = heff_field(v_cod_248, 0);
        heff_take_n(v_cod_248, 1ULL, 1);
        heff_drop(v_dom_247);
        heff_drop(v_c_240);
        v_x1_2469 = v_body_2468;
        break;
      }
      default: heff_nomatch(v_cod_248);
      }
      V v_ty_2473;
      switch (heff_tag_of(v_x1_2469)) {
      case TAG_Nom: {
        V v_x_2470 = heff_field(v_x1_2469, 0);
        heff_take_n(v_x1_2469, 1ULL, 1);
        v_ty_2473 = v_x_2470;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2469, 0ULL, 1);
        v_ty_2473 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2472 = heff_field(v_x1_2469, 0);
        heff_take_n(v_x1_2469, 1ULL, 1);
        v_ty_2473 = v_x_2472;
        break;
      }
      default: heff_nomatch(v_x1_2469);
      }
      V v_m_2474 = (g_heff_2eerase_2echkF_24s537(v_c_2461, v_body_2417, v_ty_2473));
      V v_x2_2475 = heff_tr(heff_apply(v_m_2474, 1, (V[]){v_n_2452}));
      switch (heff_tag_of(v_x2_2475)) {
      case TAG_Left: {
        V v_e_2476 = heff_field(v_x2_2475, 0);
        V v_ru_24x2_2475_24Left = heff_take_reuse_n(v_x2_2475, 1ULL, 1);
        heff_drop(v_x_2451);
        return heff_tag_at(v_ru_24x2_2475_24Left, TAG_Left, 1, (V[]){v_e_2476});
      }
      case TAG_Right: {
        V v_x21_2477 = heff_field(v_x2_2475, 0);
        V v_ru_24x2_2475_24Right = heff_take_reuse_n(v_x2_2475, 1ULL, 1);
        switch (heff_tag_of(v_x21_2477)) {
        case TAG_MkPair: {
          V v_x_2478 = heff_field(v_x21_2477, 0);
          V v_n_2479 = heff_field(v_x21_2477, 1);
          V v_ru_24x21_2477_24MkPair = heff_take_reuse_n(v_x21_2477, 3ULL, 2);
          V v_t_2480 = heff_tag_at(v_ru_24x21_2477_24MkPair, TAG_Cons, 2, (V[]){v_x_2451, NTAG(TAG_Nil)});
          V v_t_2481 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2480, v_x_2478}), v_n_2479});
          return heff_tag_at(v_ru_24x2_2475_24Right, TAG_Right, 1, (V[]){v_t_2481});
        }
        default: return heff_nomatch(v_x21_2477);
        }
      }
      default: return heff_nomatch(v_x2_2475);
      }
    }
    default: return heff_nomatch(v_x21_2450);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2eerase_2echkLam_24s538_lam10(V self, V *args) {
  V v_n_2485 = args[0];
  heff_drop(v_n_2485);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str7)});
}
V g_heff_2eerase_2echkLam_24s538_lam11(V self, V *args) {
  V v_n_2487 = args[0];
  heff_drop(v_n_2487);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str8)});
}
V g_heff_2eerase_2echkLam_24s538_lam12(V self, V *args) {
  V v_n_2488 = args[0];
  heff_drop(v_n_2488);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str9)});
}
V g_heff_2eerase_2echkLam_24s538_lam13(V self, V *args) {
  V v_n_2489 = args[0];
  heff_drop(v_n_2489);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str10)});
}
V g_heff_2eerase_2echkLam_24s538_lam14(V self, V *args) {
  V v_n_2490 = args[0];
  heff_drop(v_n_2490);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str11)});
}
V g_heff_2eerase_2echkLam_24s538_lam15(V self, V *args) {
  V v_n_2492 = args[0];
  heff_drop(v_n_2492);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str12)});
}
V g_heff_2eerase_2echkLam_24s538_lam16(V self, V *args) {
  V v_n_2493 = args[0];
  heff_drop(v_n_2493);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s538_str13)});
}
V g_heff_2eerase_2echkFieldsGo_24s539_lam0(V self, V *args);
V g_heff_2eerase_2echkFieldsGo_24s539_lam1(V self, V *args);
Clo g_heff_2eerase_2echkFieldsGo_24s539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkFieldsGo_24s539_entry, 5, 0};

V g_heff_2eerase_2echkFieldsGo_24s539(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_capture_241);
    heff_drop(v_fieldTypes_242);
    V v_x_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(v_acc_243, LBL_out)));
    return heff_clo(g_heff_2eerase_2echkFieldsGo_24s539_lam0, 1, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_x61_247 = heff_field(v_x6_244, 0);
    V v_tail_248 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_247)) {
    case TAG_MkPair: {
      V v_l_249 = heff_field(v_x61_247, 0);
      V v_fe_2410 = heff_field(v_x61_247, 1);
      heff_take_n(v_x61_247, 3ULL, 2);
      V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_243), LBL_vs)));
      V v_t_2412 = heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_fieldTypes_242), LBL_keys), heff_get(heff_dup(v_fieldTypes_242), LBL_byName), heff_arrayFromList(v_t_2411)});
      V v_t_2413 = heff_tr(g_heff_2evalue_2etypeForProjection(heff_dup(v_capture_241), heff_dup(v_fieldTypes_242), heff_dup(v_l_249), v_t_2412));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_MkField: {
        V v_fty_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 2);
        V v_t_2416 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_fty_2414)));
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          heff_drop(v_l_249);
          heff_drop(v_fty_2414);
          V v_x1_2417 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_fe_2410, heff_get(heff_dup(v_c_240), LBL_env)));
          V v_t_2421;
          switch (heff_tag_of(v_x1_2417)) {
          case TAG_Nom: {
            V v_x_2418 = heff_field(v_x1_2417, 0);
            heff_take_n(v_x1_2417, 1ULL, 1);
            v_t_2421 = v_x_2418;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2417, 0ULL, 1);
            v_t_2421 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2420 = heff_field(v_x1_2417, 0);
            heff_take_n(v_x1_2417, 1ULL, 1);
            v_t_2421 = v_x_2420;
            break;
          }
          default: heff_nomatch(v_x1_2417);
          }
          V v_t_2422 = heff_tag_at(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_get(heff_dup(v_acc_243), LBL_vs)});
          V v_t_2423 = heff_rec(2, shape_371_223, (V[]){v_t_2422, heff_get(v_acc_243, LBL_out)});
          V t_0 = v_c_240;
          V t_1 = v_capture_241;
          V t_2 = v_fieldTypes_242;
          V t_3 = v_t_2423;
          V t_4 = v_tail_248;
          v_c_240 = t_0;
          v_capture_241 = t_1;
          v_fieldTypes_242 = t_2;
          v_acc_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          V v_m_2424 = (g_heff_2eerase_2echkF_24s537(heff_dup(v_c_240), heff_dup(v_fe_2410), v_fty_2414));
          return heff_clo(g_heff_2eerase_2echkFieldsGo_24s539_lam1, 1, 8, (V[]){v_m_2424, v_c_240, v_fe_2410, v_acc_243, v_l_249, v_capture_241, v_fieldTypes_242, v_tail_248});
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x61_247);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eerase_2echkFieldsGo_24s539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkFieldsGo_24s539(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eerase_2echkFieldsGo_24s539_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_245, v_n_246})});
}
V g_heff_2eerase_2echkFieldsGo_24s539_lam1(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fe_2410 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_l_249 = heff_env(self)[4];
  V v_capture_241 = heff_env(self)[5];
  V v_fieldTypes_242 = heff_env(self)[6];
  V v_tail_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2426 = heff_tr(heff_apply(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Left: {
    V v_e_2427 = heff_field(v_x2_2426, 0);
    V v_ru_24x2_2426_24Left = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_fe_2410);
    heff_drop(v_acc_243);
    heff_drop(v_l_249);
    heff_drop(v_capture_241);
    heff_drop(v_fieldTypes_242);
    heff_drop(v_tail_248);
    return heff_tag_at(v_ru_24x2_2426_24Left, TAG_Left, 1, (V[]){v_e_2427});
  }
  case TAG_Right: {
    V v_x21_2428 = heff_field(v_x2_2426, 0);
    heff_take_n(v_x2_2426, 1ULL, 1);
    switch (heff_tag_of(v_x21_2428)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_x21_2428, 0);
      V v_n_2430 = heff_field(v_x21_2428, 1);
      V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
      V v_x1_2431 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_fe_2410, heff_get(heff_dup(v_c_240), LBL_env)));
      V v_t_2435;
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_Nom: {
        V v_x_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        v_t_2435 = v_x_2432;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2431, 0ULL, 1);
        v_t_2435 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2434 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        v_t_2435 = v_x_2434;
        break;
      }
      default: heff_nomatch(v_x1_2431);
      }
      V v_t_2436 = heff_tag_at(v_ru_24x21_2428_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, heff_get(heff_dup(v_acc_243), LBL_vs)});
      V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_249, v_x_2429}), heff_get(v_acc_243, LBL_out)});
      V v_t_2438 = (g_heff_2eerase_2echkFieldsGo_24s539(v_c_240, v_capture_241, v_fieldTypes_242, heff_rec(2, shape_371_223, (V[]){v_t_2436, v_t_2437}), v_tail_248));
      V f_ = v_t_2438;
      args[0] = v_n_2430;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2428);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2eerase_2echkTagArg_24s540_lam0(V self, V *args); static Clo g_heff_2eerase_2echkTagArg_24s540_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkTagArg_24s540_lam0, 1, 0};
V g_heff_2eerase_2echkTagArg_24s540_lam1(V self, V *args);
Clo g_heff_2eerase_2echkTagArg_24s540_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkTagArg_24s540_entry, 2, 0};

V g_heff_2eerase_2echkTagArg_24s540(V v_c_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_a_242 = heff_field(v_x3_241, 0);
    V v_aty_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_aty_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_c_240);
      heff_drop(v_a_242);
      heff_drop(v_aty_243);
      return ((V)&g_heff_2eerase_2echkTagArg_24s540_lam0_clo);
    }
    case TAG_False: {
      V v_m_247 = (g_heff_2eerase_2echkF_24s537(v_c_240, v_a_242, v_aty_243));
      return heff_clo(g_heff_2eerase_2echkTagArg_24s540_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eerase_2echkTagArg_24s540_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkTagArg_24s540(a[0], a[1]);
}
V g_heff_2eerase_2echkTagArg_24s540_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_245});
  return heff_tag(TAG_Right, 1, (V[]){v_t_246});
}
V g_heff_2eerase_2echkTagArg_24s540_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = heff_tag_at(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x2_249_24Right, TAG_Just, 1, (V[]){v_x_2412}), v_n_2413});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2414});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2eerase_2earmOf_24s541_lam0(V self, V *args);
Clo g_heff_2eerase_2earmOf_24s541_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmOf_24s541_entry, 4, 0};

V g_heff_2eerase_2earmOf_24s541(V v_c_240, V v_vs_241, V v_ty_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_tag_244 = heff_field(v_x5_243, 0);
    V v_x52_245 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    switch (heff_tag_of(v_x52_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_x52_245, 0);
      V v_body_247 = heff_field(v_x52_245, 1);
      heff_take_n(v_x52_245, 3ULL, 2);
      V v_t_248 = heff_rec(2, shape_36_369, (V[]){v_c_240, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2eerase_2eargTysOf(v_vs_241, heff_dup(v_tag_244)));
      V v_t_2410 = (g_heff_2eerase_2ezipE(heff_arrayToList(v_xs_246), v_t_249));
      V v_m_2411 = (g_heff_2eerase_2earmBindGo(v_t_248, v_t_2410));
      return heff_clo(g_heff_2eerase_2earmOf_24s541_lam0, 1, 4, (V[]){v_m_2411, v_body_247, v_ty_242, v_tag_244});
    }
    default: return heff_nomatch(v_x52_245);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eerase_2earmOf_24s541_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2earmOf_24s541(a[0], a[1], a[2], a[3]);
}
V g_heff_2eerase_2earmOf_24s541_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_body_247 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_tag_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Left: {
    V v_e_2414 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Left = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    heff_drop(v_body_247);
    heff_drop(v_ty_242);
    heff_drop(v_tag_244);
    return heff_tag_at(v_ru_24x2_2413_24Left, TAG_Left, 1, (V[]){v_e_2414});
  }
  case TAG_Right: {
    V v_x21_2415 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Right = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    switch (heff_tag_of(v_x21_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x21_2415, 0);
      V v_n_2417 = heff_field(v_x21_2415, 1);
      heff_take_n(v_x21_2415, 3ULL, 2);
      V v_m_2418 = (g_heff_2eerase_2echkF_24s537(heff_get(heff_dup(v_x_2416), LBL_c), v_body_247, v_ty_242));
      V v_x2_2419 = heff_tr(heff_apply(v_m_2418, 1, (V[]){v_n_2417}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Left: {
        V v_e_2420 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        heff_drop(v_tag_244);
        heff_drop(v_x_2416);
        return heff_tag_at(v_ru_24x2_2413_24Right, TAG_Left, 1, (V[]){v_e_2420});
      }
      case TAG_Right: {
        V v_x21_2421 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        switch (heff_tag_of(v_x21_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x21_2421, 0);
          V v_n_2423 = heff_field(v_x21_2421, 1);
          heff_take_n(v_x21_2421, 3ULL, 2);
          V v_t_2424 = heff_tag(TAG_MkArm, 3, (V[]){v_tag_244, heff_get(v_x_2416, LBL_vars), v_x_2422});
          return heff_tag_at(v_ru_24x2_2413_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2424, v_n_2423})});
        }
        default: return heff_nomatch(v_x21_2421);
        }
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
    default: return heff_nomatch(v_x21_2415);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2earmsTy_24s543_str0 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2earmsTy_24s543_lam0(V self, V *args); static Clo g_heff_2eerase_2earmsTy_24s543_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmsTy_24s543_lam0, 1, 0};
V g_heff_2eerase_2earmsTy_24s543_lam2(V self, V *args);
V g_heff_2eerase_2earmsTy_24s543_lam1(V self, V *args);
Clo g_heff_2eerase_2earmsTy_24s543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmsTy_24s543_entry, 3, 0};

V g_heff_2eerase_2earmsTy_24s543(V v_c_240, V v_vs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    return ((V)&g_heff_2eerase_2earmsTy_24s543_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_tail_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_tag_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_MkPair: {
        V v_xs_248 = heff_field(v_x412_247, 0);
        V v_body_249 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        V v_t_2410 = heff_rec(2, shape_36_369, (V[]){heff_dup(v_c_240), NTAG(TAG_Nil)});
        V v_t_2411 = (g_heff_2eerase_2eargTysOf(heff_dup(v_vs_241), v_tag_246));
        V v_t_2412 = (g_heff_2eerase_2ezipE(heff_arrayToList(v_xs_248), v_t_2411));
        V v_m_2413 = (g_heff_2eerase_2earmBindGo(v_t_2410, v_t_2412));
        return heff_clo(g_heff_2eerase_2earmsTy_24s543_lam1, 1, 5, (V[]){v_m_2413, v_body_249, v_c_240, v_vs_241, v_tail_245});
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eerase_2earmsTy_24s543_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2earmsTy_24s543(a[0], a[1], a[2]);
}
V g_heff_2eerase_2earmsTy_24s543_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2earmsTy_24s543_str0)});
}
V g_heff_2eerase_2earmsTy_24s543_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2422 = heff_tr(heff_apply(v_m_2420, 1, (V[]){heff_dup(v_n_2421)}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_Left: {
    V v_ru_24x2_2422_24Left = heff_take_reuse_n(v_x2_2422, 0ULL, 1);
    V v_t_2424 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2421});
    return heff_tag_at(v_ru_24x2_2422_24Left, TAG_Right, 1, (V[]){v_t_2424});
  }
  case TAG_Right: {
    V v_x21_2425 = heff_field(v_x2_2422, 0);
    V v_ru_24x2_2422_24Right = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
    heff_drop(v_n_2421);
    switch (heff_tag_of(v_x21_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x21_2425, 0);
      V v_n_27_2427 = heff_field(v_x21_2425, 1);
      V v_ru_24x21_2425_24MkPair = heff_take_reuse_n(v_x21_2425, 3ULL, 2);
      V v_t_2428 = heff_tag_at(v_ru_24x21_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x2_2422_24Right, TAG_Just, 1, (V[]){v_x_2426}), v_n_27_2427});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2428});
    }
    default: return heff_nomatch(v_x21_2425);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2eerase_2earmsTy_24s543_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_body_249 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_tail_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Left: {
    V v_e_2416 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Left = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    heff_drop(v_body_249);
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    heff_drop(v_tail_245);
    return heff_tag_at(v_ru_24x2_2415_24Left, TAG_Left, 1, (V[]){v_e_2416});
  }
  case TAG_Right: {
    V v_x21_2417 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Right = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x21_2417, 0);
      V v_n_2419 = heff_field(v_x21_2417, 1);
      heff_take_n(v_x21_2417, 3ULL, 2);
      V v_m_2420 = (g_heff_2eerase_2esynF_24s542(heff_get(v_x_2418, LBL_c), v_body_249));
      V v_m_2429 = heff_clo(g_heff_2eerase_2earmsTy_24s543_lam2, 1, 1, (V[]){v_m_2420});
      V v_x2_2430 = heff_tr(heff_apply(v_m_2429, 1, (V[]){v_n_2419}));
      switch (heff_tag_of(v_x2_2430)) {
      case TAG_Left: {
        V v_e_2431 = heff_field(v_x2_2430, 0);
        heff_take_n(v_x2_2430, 1ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_vs_241);
        heff_drop(v_tail_245);
        return heff_tag_at(v_ru_24x2_2415_24Right, TAG_Left, 1, (V[]){v_e_2431});
      }
      case TAG_Right: {
        V v_x21_2432 = heff_field(v_x2_2430, 0);
        heff_take_n(v_x2_2430, 1ULL, 1);
        switch (heff_tag_of(v_x21_2432)) {
        case TAG_MkPair: {
          V v_x_2433 = heff_field(v_x21_2432, 0);
          V v_n_2434 = heff_field(v_x21_2432, 1);
          heff_take_n(v_x21_2432, 3ULL, 2);
          switch (heff_tag_of(v_x_2433)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_2415_24Right, 1);
            V v_t_2435 = (g_heff_2eerase_2earmsTy_24s543(v_c_240, v_vs_241, v_tail_245));
            V f_ = v_t_2435;
            args[0] = v_n_2434;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
          case TAG_Just: {
            V v_it1_2436 = heff_field(v_x_2433, 0);
            heff_take_n(v_x_2433, 1ULL, 1);
            heff_drop(v_c_240);
            heff_drop(v_vs_241);
            heff_drop(v_tail_245);
            switch (heff_tag_of(v_it1_2436)) {
            case TAG_MkPair: {
              V v_ty_2438 = heff_field(v_it1_2436, 1);
              heff_take_n(v_it1_2436, 2ULL, 2);
              return heff_tag_at(v_ru_24x2_2415_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_ty_2438, v_n_2434})});
            }
            default: return heff_nomatch(v_it1_2436);
            }
          }
          default: return heff_nomatch(v_x_2433);
          }
        }
        default: return heff_nomatch(v_x21_2432);
        }
      }
      default: return heff_nomatch(v_x2_2430);
      }
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eerase_2esynF_24s542_str0 = {{0x80000000u, K_STR, 0}, 16, 16, {97, 110, 32, 117, 110, 98, 111, 117, 110, 100, 32, 108, 111, 99, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eerase_2esynF_24s542_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 32, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eerase_2esynF_24s542_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 32, 103, 108, 111, 98, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eerase_2esynF_24s542_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {116, 104, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eerase_2esynF_24s542_str4 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 32, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str5 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str6 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str7 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str8 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str9 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str10 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str11 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str12 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s542_str13 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str14 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str15 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str16 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str17 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str18 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str19 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s542_str20 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2esynF_24s542_lam0(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam0, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam1(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam1, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam2(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam3(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam4(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam5(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam6(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam6, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam8(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam9(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam7(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam10(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam11(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam11, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam12(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam13(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam13, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam15(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam14(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam16(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam16, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam17(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam17, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam18(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam18, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam19(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam20(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam20, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam21(V self, V *args); static Clo g_heff_2eerase_2esynF_24s542_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_lam21, 1, 0};
V g_heff_2eerase_2esynF_24s542_lam22(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam23(V self, V *args);
V g_heff_2eerase_2esynF_24s542_lam24(V self, V *args);
Clo g_heff_2eerase_2esynF_24s542_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s542_entry, 2, 0};

V g_heff_2eerase_2esynF_24s542(V v_c_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_243 = ({ V b_0 = heff_get(v_c_240, LBL_locals); V a_1 = v_i_242; V r_ = (g_heff_2eerase_2enthLocal(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2eerase_2esynF_24s542_lam0_clo);
    }
    case TAG_Just: {
      V v_l_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_get(heff_dup(v_l_245), LBL_ir);
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop(v_l_245);
        return ((V)&g_heff_2eerase_2esynF_24s542_lam1_clo);
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        return heff_clo(g_heff_2eerase_2esynF_24s542_lam2, 1, 2, (V[]){v_x_248, v_l_245});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_SGlobal: {
    V v_x_2411 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_2412 = (g_heff_2eglobals_2elookupEntry(heff_get(v_c_240, LBL_globals), heff_dup(v_x_2411)));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      return heff_clo(g_heff_2eerase_2esynF_24s542_lam3, 1, 1, (V[]){v_x_2411});
    }
    case TAG_Just: {
      V v_e_2414 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_t_2415 = (g_heff_2eerase_2eisType(MK_INT(0LL), heff_get(heff_dup(v_e_2414), LBL_type_5f)));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_e_2414);
        return heff_clo(g_heff_2eerase_2esynF_24s542_lam4, 1, 1, (V[]){v_x_2411});
      }
      case TAG_False: {
        return heff_clo(g_heff_2eerase_2esynF_24s542_lam5, 1, 2, (V[]){v_x_2411, v_e_2414});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam6_clo);
  }
  case TAG_SApp: {
    V v_f_2422 = heff_field(v_t_241, 0);
    V v_a_2423 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_2424 = (g_heff_2eerase_2esynF_24s542(heff_dup(v_c_240), v_f_2422));
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam7, 1, 3, (V[]){v_m_2424, v_c_240, v_a_2423});
  }
  case TAG_SLam: {
    V v_ty_2482 = heff_field(v_t_241, 0);
    V v_abs_2483 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SLam = heff_take_reuse_n(v_t_241, 3ULL, 2);
    V v_x1_2484 = (g_heff_2eeval_2eevalTypeF_24s15(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), heff_dup(v_ty_2482), heff_get(heff_dup(v_c_240), LBL_env)));
    V v_ty_2488;
    switch (heff_tag_of(v_x1_2484)) {
    case TAG_Nom: {
      V v_x_2485 = heff_field(v_x1_2484, 0);
      heff_take_n(v_x1_2484, 1ULL, 1);
      v_ty_2488 = v_x_2485;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2484, 0ULL, 1);
      v_ty_2488 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2487 = heff_field(v_x1_2484, 0);
      heff_take_n(v_x1_2484, 1ULL, 1);
      v_ty_2488 = v_x_2487;
      break;
    }
    default: heff_nomatch(v_x1_2484);
    }
    V v_m_2489 = (g_heff_2eerase_2echkF_24s537(heff_dup(v_c_240), heff_tag_at(v_ru_24t_241_24SLam, TAG_SLam, 2, (V[]){heff_dup(v_ty_2482), v_abs_2483}), v_ty_2488));
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam10, 1, 3, (V[]){v_m_2489, v_c_240, v_ty_2482});
  }
  case TAG_SCons: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam11_clo);
  }
  case TAG_SProj: {
    V v_e_24104 = heff_field(v_t_241, 0);
    V v_l_24105 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24106 = (g_heff_2eerase_2esynF_24s542(heff_dup(v_c_240), heff_dup(v_e_24104)));
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam12, 1, 4, (V[]){v_m_24106, v_c_240, v_e_24104, v_l_24105});
  }
  case TAG_STag: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam13_clo);
  }
  case TAG_SMatch: {
    V v_scrut_24131 = heff_field(v_t_241, 0);
    V v_cases_24132 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24133 = (g_heff_2eerase_2esynF_24s542(heff_dup(v_c_240), v_scrut_24131));
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam14, 1, 3, (V[]){v_m_24133, v_cases_24132, v_c_240});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam16_clo);
  }
  case TAG_SIs: {
    V v_t2_24172 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24172;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam17_clo);
  }
  case TAG_SAbandon: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam18_clo);
  }
  case TAG_SRec: {
    V v_t2_24175 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24175;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_ty_24176 = heff_field(v_t_241, 0);
    V v_abs_24177 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SFix = heff_take_reuse_n(v_t_241, 3ULL, 2);
    V v_x1_24178 = (g_heff_2eeval_2eevalTypeF_24s15(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), heff_dup(v_ty_24176), heff_get(heff_dup(v_c_240), LBL_env)));
    V v_ty_24182;
    switch (heff_tag_of(v_x1_24178)) {
    case TAG_Nom: {
      V v_x_24179 = heff_field(v_x1_24178, 0);
      heff_take_n(v_x1_24178, 1ULL, 1);
      v_ty_24182 = v_x_24179;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24178, 0ULL, 1);
      v_ty_24182 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24181 = heff_field(v_x1_24178, 0);
      heff_take_n(v_x1_24178, 1ULL, 1);
      v_ty_24182 = v_x_24181;
      break;
    }
    default: heff_nomatch(v_x1_24178);
    }
    V v_m_24183 = (g_heff_2eerase_2echkF_24s537(heff_dup(v_c_240), heff_tag_at(v_ru_24t_241_24SFix, TAG_SFix, 2, (V[]){heff_dup(v_ty_24176), v_abs_24177}), v_ty_24182));
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam19, 1, 3, (V[]){v_m_24183, v_c_240, v_ty_24176});
  }
  case TAG_SImplicit: {
    V v_t2_24197 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t2_24197;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam20_clo);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s542_lam21_clo);
  }
  case TAG_SLitInt: {
    V v_i_24204 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam22, 1, 1, (V[]){v_i_24204});
  }
  case TAG_SLitFloat: {
    V v_x_24207 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam23, 1, 1, (V[]){v_x_24207});
  }
  case TAG_SLitString: {
    V v_s_24210 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s542_lam24, 1, 1, (V[]){v_s_24210});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2esynF_24s542_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2esynF_24s542(a[0], a[1]);
}
V g_heff_2eerase_2esynF_24s542_lam0(V self, V *args) {
  V v_n_244 = args[0];
  heff_drop(v_n_244);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str0)});
}
V g_heff_2eerase_2esynF_24s542_lam1(V self, V *args) {
  V v_n_247 = args[0];
  heff_drop(v_n_247);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str1)});
}
V g_heff_2eerase_2esynF_24s542_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_l_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){v_x_248, heff_get(v_l_245, LBL_ty)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_n_249})});
}
V g_heff_2eerase_2esynF_24s542_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2413);
  return heff_tag(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2eerase_2esynF_24s542_str2), v_x_2411)});
}
V g_heff_2eerase_2esynF_24s542_lam4(V self, V *args) {
  V v_n_2416 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2416);
  V v_t_2417 = heff_strAppend(((V)&g_heff_2eerase_2esynF_24s542_str3), heff_strAppend(v_x_2411, ((V)&g_heff_2eerase_2esynF_24s542_str4)));
  return heff_tag(TAG_Left, 1, (V[]){v_t_2417});
}
V g_heff_2eerase_2esynF_24s542_lam5(V self, V *args) {
  V v_n_2418 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_e_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_x_2411}), heff_get(v_e_2414, LBL_type_5f)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2419, v_n_2418})});
}
V g_heff_2eerase_2esynF_24s542_lam6(V self, V *args) {
  V v_n_2421 = args[0];
  heff_drop(v_n_2421);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str5)});
}
V g_heff_2eerase_2esynF_24s542_lam8(V self, V *args) {
  V v_u_2443 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2443);
  V v_x1_2444 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_a_2423, heff_get(v_c_240, LBL_env)));
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nom: {
    V v_x_2445 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    return v_x_2445;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2444, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2447 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    return v_x_2447;
  }
  default: return heff_nomatch(v_x1_2444);
  }
}
V g_heff_2eerase_2esynF_24s542_lam9(V self, V *args) {
  V v_u_2465 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2465);
  V v_x1_2466 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_a_2423, heff_get(v_c_240, LBL_env)));
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_Nom: {
    V v_x_2467 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    return v_x_2467;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2466, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2469 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    return v_x_2469;
  }
  default: return heff_nomatch(v_x1_2466);
  }
}
V g_heff_2eerase_2esynF_24s542_lam7(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_a_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2426 = heff_tr(heff_apply(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Left: {
    V v_e_2427 = heff_field(v_x2_2426, 0);
    V v_ru_24x2_2426_24Left = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_a_2423);
    return heff_tag_at(v_ru_24x2_2426_24Left, TAG_Left, 1, (V[]){v_e_2427});
  }
  case TAG_Right: {
    V v_x21_2428 = heff_field(v_x2_2426, 0);
    V v_ru_24x2_2426_24Right = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
    switch (heff_tag_of(v_x21_2428)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_x21_2428, 0);
      V v_n_2430 = heff_field(v_x21_2428, 1);
      V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
      switch (heff_tag_of(v_x_2429)) {
      case TAG_MkPair: {
        V v_f_27_2431 = heff_field(v_x_2429, 0);
        V v_fty_2432 = heff_field(v_x_2429, 1);
        V v_ru_24x_2429_24MkPair = heff_take_reuse_n(v_x_2429, 3ULL, 2);
        V v_t_2433 = (g_heff_2evalue_2ebehavior(v_fty_2432));
        switch (heff_tag_of(v_t_2433)) {
        case TAG_LikeU: {
          heff_take_n(v_t_2433, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str6)});
        }
        case TAG_LikeFunction: {
          V v_dom_2436 = heff_field(v_t_2433, 1);
          V v_cod_2437 = heff_field(v_t_2433, 2);
          heff_take_n(v_t_2433, 6ULL, 4);
          V v_t_2439 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_dom_2436)));
          switch (heff_tag_of(v_t_2439)) {
          case TAG_True: {
            heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
            heff_drop(v_dom_2436);
            V v_x1_2449;
            switch (heff_tag_of(v_cod_2437)) {
            case TAG_MkClo: {
              V v_vs_2441 = heff_field(v_cod_2437, 1);
              V v_body_2442 = heff_field(v_cod_2437, 2);
              heff_take_n(v_cod_2437, 6ULL, 3);
              v_x1_2449 = heff_tr(heff_apply(v_body_2442, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2441, heff_clo(g_heff_2eerase_2esynF_24s542_lam8, 1, 2, (V[]){v_c_240, v_a_2423})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2448 = heff_field(v_cod_2437, 0);
              heff_take_n(v_cod_2437, 1ULL, 1);
              heff_drop(v_c_240);
              heff_drop(v_a_2423);
              v_x1_2449 = v_body_2448;
              break;
            }
            default: heff_nomatch(v_cod_2437);
            }
            V v_t_2453;
            switch (heff_tag_of(v_x1_2449)) {
            case TAG_Nom: {
              V v_x_2450 = heff_field(v_x1_2449, 0);
              heff_take_n(v_x1_2449, 1ULL, 1);
              v_t_2453 = v_x_2450;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2449, 0ULL, 1);
              v_t_2453 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2452 = heff_field(v_x1_2449, 0);
              heff_take_n(v_x1_2449, 1ULL, 1);
              v_t_2453 = v_x_2452;
              break;
            }
            default: heff_nomatch(v_x1_2449);
            }
            V v_x_2454 = heff_tag_at(v_ru_24x21_2428_24MkPair, TAG_MkPair, 2, (V[]){v_f_27_2431, v_t_2453});
            return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2454, v_n_2430})});
          }
          case TAG_False: {
            V v_m_2455 = (g_heff_2eerase_2echkF_24s537(heff_dup(v_c_240), heff_dup(v_a_2423), v_dom_2436));
            V v_x2_2456 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_n_2430}));
            switch (heff_tag_of(v_x2_2456)) {
            case TAG_Left: {
              V v_e_2457 = heff_field(v_x2_2456, 0);
              heff_take_n(v_x2_2456, 1ULL, 1);
              heff_drop(v_c_240);
              heff_drop(v_a_2423);
              heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
              heff_drop(v_f_27_2431);
              heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
              heff_drop(v_cod_2437);
              return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){v_e_2457});
            }
            case TAG_Right: {
              V v_x21_2458 = heff_field(v_x2_2456, 0);
              heff_take_n(v_x2_2456, 1ULL, 1);
              switch (heff_tag_of(v_x21_2458)) {
              case TAG_MkPair: {
                V v_x_2459 = heff_field(v_x21_2458, 0);
                V v_n_2460 = heff_field(v_x21_2458, 1);
                heff_take_n(v_x21_2458, 3ULL, 2);
                V v_t_2461 = heff_tag_at(v_ru_24x21_2428_24MkPair, TAG_Cons, 2, (V[]){v_x_2459, NTAG(TAG_Nil)});
                V v_x1_2471;
                switch (heff_tag_of(v_cod_2437)) {
                case TAG_MkClo: {
                  V v_vs_2463 = heff_field(v_cod_2437, 1);
                  V v_body_2464 = heff_field(v_cod_2437, 2);
                  heff_take_n(v_cod_2437, 6ULL, 3);
                  v_x1_2471 = heff_tr(heff_apply(v_body_2464, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2463, heff_clo(g_heff_2eerase_2esynF_24s542_lam9, 1, 2, (V[]){v_c_240, v_a_2423})})}));
                  break;
                }
                case TAG_CloConst: {
                  V v_body_2470 = heff_field(v_cod_2437, 0);
                  heff_take_n(v_cod_2437, 1ULL, 1);
                  heff_drop(v_c_240);
                  heff_drop(v_a_2423);
                  v_x1_2471 = v_body_2470;
                  break;
                }
                default: heff_nomatch(v_cod_2437);
                }
                V v_t_2475;
                switch (heff_tag_of(v_x1_2471)) {
                case TAG_Nom: {
                  V v_x_2472 = heff_field(v_x1_2471, 0);
                  heff_take_n(v_x1_2471, 1ULL, 1);
                  v_t_2475 = v_x_2472;
                  break;
                }
                case TAG_Describe: {
                  heff_take_n(v_x1_2471, 0ULL, 1);
                  v_t_2475 = heff_abandon();
                  break;
                }
                case TAG_Become: {
                  V v_x_2474 = heff_field(v_x1_2471, 0);
                  heff_take_n(v_x1_2471, 1ULL, 1);
                  v_t_2475 = v_x_2474;
                  break;
                }
                default: heff_nomatch(v_x1_2471);
                }
                V v_x_2476 = heff_tag_at(v_ru_24x_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_27_2431, v_t_2461}), v_t_2475});
                return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2476, v_n_2460})});
              }
              default: return heff_nomatch(v_x21_2458);
              }
            }
            default: return heff_nomatch(v_x2_2456);
            }
          }
          default: return heff_nomatch(v_t_2439);
          }
        }
        case TAG_LikeRecord: {
          heff_take_n(v_t_2433, 0ULL, 3);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str7)});
        }
        case TAG_LikeSum: {
          heff_take_n(v_t_2433, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str8)});
        }
        case TAG_LikeInt: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str9)});
        }
        case TAG_LikeFloat: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str10)});
        }
        case TAG_LikeString: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str11)});
        }
        case TAG_LikeArray: {
          heff_take_n(v_t_2433, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str12)});
        }
        case TAG_NoRules: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str13)});
        }
        default: return heff_nomatch(v_t_2433);
        }
      }
      default: return heff_nomatch(v_x_2429);
      }
    }
    default: return heff_nomatch(v_x21_2428);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2eerase_2esynF_24s542_lam10(V self, V *args) {
  V v_n_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_2482 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2491 = heff_tr(heff_apply(v_m_2489, 1, (V[]){v_n_2490}));
  switch (heff_tag_of(v_x2_2491)) {
  case TAG_Left: {
    V v_e_2492 = heff_field(v_x2_2491, 0);
    V v_ru_24x2_2491_24Left = heff_take_reuse_n(v_x2_2491, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_2482);
    return heff_tag_at(v_ru_24x2_2491_24Left, TAG_Left, 1, (V[]){v_e_2492});
  }
  case TAG_Right: {
    V v_x21_2493 = heff_field(v_x2_2491, 0);
    V v_ru_24x2_2491_24Right = heff_take_reuse_n(v_x2_2491, 1ULL, 1);
    switch (heff_tag_of(v_x21_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x21_2493, 0);
      V v_n_2495 = heff_field(v_x21_2493, 1);
      V v_ru_24x21_2493_24MkPair = heff_take_reuse_n(v_x21_2493, 3ULL, 2);
      V v_x1_2496 = (g_heff_2eeval_2eevalTypeF_24s15(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_ty_2482, heff_get(v_c_240, LBL_env)));
      V v_t_24100;
      switch (heff_tag_of(v_x1_2496)) {
      case TAG_Nom: {
        V v_x_2497 = heff_field(v_x1_2496, 0);
        heff_take_n(v_x1_2496, 1ULL, 1);
        v_t_24100 = v_x_2497;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2496, 0ULL, 1);
        v_t_24100 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2499 = heff_field(v_x1_2496, 0);
        heff_take_n(v_x1_2496, 1ULL, 1);
        v_t_24100 = v_x_2499;
        break;
      }
      default: heff_nomatch(v_x1_2496);
      }
      V v_x_24101 = heff_tag_at(v_ru_24x21_2493_24MkPair, TAG_MkPair, 2, (V[]){v_x_2494, v_t_24100});
      return heff_tag_at(v_ru_24x2_2491_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_24101, v_n_2495})});
    }
    default: return heff_nomatch(v_x21_2493);
    }
  }
  default: return heff_nomatch(v_x2_2491);
  }
}
V g_heff_2eerase_2esynF_24s542_lam11(V self, V *args) {
  V v_n_24103 = args[0];
  heff_drop(v_n_24103);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str14)});
}
V g_heff_2eerase_2esynF_24s542_lam12(V self, V *args) {
  V v_n_24107 = args[0];
  V v_m_24106 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_24104 = heff_env(self)[2];
  V v_l_24105 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24108 = heff_tr(heff_apply(v_m_24106, 1, (V[]){v_n_24107}));
  switch (heff_tag_of(v_x2_24108)) {
  case TAG_Left: {
    V v_e_24109 = heff_field(v_x2_24108, 0);
    V v_ru_24x2_24108_24Left = heff_take_reuse_n(v_x2_24108, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_e_24104);
    heff_drop(v_l_24105);
    return heff_tag_at(v_ru_24x2_24108_24Left, TAG_Left, 1, (V[]){v_e_24109});
  }
  case TAG_Right: {
    V v_x21_24110 = heff_field(v_x2_24108, 0);
    V v_ru_24x2_24108_24Right = heff_take_reuse_n(v_x2_24108, 1ULL, 1);
    switch (heff_tag_of(v_x21_24110)) {
    case TAG_MkPair: {
      V v_x_24111 = heff_field(v_x21_24110, 0);
      V v_n_24112 = heff_field(v_x21_24110, 1);
      V v_ru_24x21_24110_24MkPair = heff_take_reuse_n(v_x21_24110, 3ULL, 2);
      switch (heff_tag_of(v_x_24111)) {
      case TAG_MkPair: {
        V v_e_27_24113 = heff_field(v_x_24111, 0);
        V v_ety_24114 = heff_field(v_x_24111, 1);
        heff_take_n(v_x_24111, 3ULL, 2);
        V v_x1_24115 = heff_tr(g_heff_2eeval_2eevalTermF_24s14(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_e_24104, heff_get(heff_dup(v_c_240), LBL_env)));
        V v_v_24119;
        switch (heff_tag_of(v_x1_24115)) {
        case TAG_Nom: {
          V v_x_24116 = heff_field(v_x1_24115, 0);
          heff_take_n(v_x1_24115, 1ULL, 1);
          v_v_24119 = v_x_24116;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24115, 0ULL, 1);
          v_v_24119 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24118 = heff_field(v_x1_24115, 0);
          heff_take_n(v_x1_24115, 1ULL, 1);
          v_v_24119 = v_x_24118;
          break;
        }
        default: heff_nomatch(v_x1_24115);
        }
        V v_t_24120 = (g_heff_2evalue_2ecoerceToFieldsMaybe(v_v_24119));
        V v_m_24121 = (g_heff_2eerase_2eprojTyInWith(heff_get(v_c_240, LBL_len), v_ety_24114, v_t_24120, heff_dup(v_l_24105)));
        V v_x2_24122 = heff_tr(heff_apply(v_m_24121, 1, (V[]){v_n_24112}));
        switch (heff_tag_of(v_x2_24122)) {
        case TAG_Left: {
          V v_e_24123 = heff_field(v_x2_24122, 0);
          heff_take_n(v_x2_24122, 1ULL, 1);
          heff_drop(v_l_24105);
          heff_drop_cell(v_ru_24x21_24110_24MkPair, 2);
          heff_drop(v_e_27_24113);
          return heff_tag_at(v_ru_24x2_24108_24Right, TAG_Left, 1, (V[]){v_e_24123});
        }
        case TAG_Right: {
          V v_x21_24124 = heff_field(v_x2_24122, 0);
          heff_take_n(v_x2_24122, 1ULL, 1);
          switch (heff_tag_of(v_x21_24124)) {
          case TAG_MkPair: {
            V v_x_24125 = heff_field(v_x21_24124, 0);
            V v_n_24126 = heff_field(v_x21_24124, 1);
            heff_take_n(v_x21_24124, 3ULL, 2);
            V v_t_24127 = heff_tag_at(v_ru_24x21_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_27_24113, v_l_24105}), v_x_24125});
            return heff_tag_at(v_ru_24x2_24108_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24127, v_n_24126})});
          }
          default: return heff_nomatch(v_x21_24124);
          }
        }
        default: return heff_nomatch(v_x2_24122);
        }
      }
      default: return heff_nomatch(v_x_24111);
      }
    }
    default: return heff_nomatch(v_x21_24110);
    }
  }
  default: return heff_nomatch(v_x2_24108);
  }
}
V g_heff_2eerase_2esynF_24s542_lam13(V self, V *args) {
  V v_n_24130 = args[0];
  heff_drop(v_n_24130);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str15)});
}
V g_heff_2eerase_2esynF_24s542_lam15(V self, V *args) {
  V v_p_24160 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24146 = heff_env(self)[1];
  V v_x_24155 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eerase_2earmOf_24s541(v_c_240, v_x_24146, v_x_24155, v_p_24160));
}
V g_heff_2eerase_2esynF_24s542_lam14(V self, V *args) {
  V v_n_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_cases_24132 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24135 = heff_tr(heff_apply(v_m_24133, 1, (V[]){v_n_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_Left: {
    V v_e_24136 = heff_field(v_x2_24135, 0);
    V v_ru_24x2_24135_24Left = heff_take_reuse_n(v_x2_24135, 1ULL, 1);
    heff_drop(v_cases_24132);
    heff_drop(v_c_240);
    return heff_tag_at(v_ru_24x2_24135_24Left, TAG_Left, 1, (V[]){v_e_24136});
  }
  case TAG_Right: {
    V v_x21_24137 = heff_field(v_x2_24135, 0);
    V v_ru_24x2_24135_24Right = heff_take_reuse_n(v_x2_24135, 1ULL, 1);
    switch (heff_tag_of(v_x21_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x21_24137, 0);
      V v_n_24139 = heff_field(v_x21_24137, 1);
      V v_ru_24x21_24137_24MkPair = heff_take_reuse_n(v_x21_24137, 3ULL, 2);
      switch (heff_tag_of(v_x_24138)) {
      case TAG_MkPair: {
        V v_s_27_24140 = heff_field(v_x_24138, 0);
        V v_sty_24141 = heff_field(v_x_24138, 1);
        heff_take_n(v_x_24138, 3ULL, 2);
        V v_m_24142 = (g_heff_2eerase_2ematchVariants(v_sty_24141));
        V v_x2_24143 = heff_tr(heff_apply(v_m_24142, 1, (V[]){v_n_24139}));
        switch (heff_tag_of(v_x2_24143)) {
        case TAG_Left: {
          V v_e_24144 = heff_field(v_x2_24143, 0);
          heff_take_n(v_x2_24143, 1ULL, 1);
          heff_drop(v_cases_24132);
          heff_drop(v_c_240);
          heff_drop_cell(v_ru_24x21_24137_24MkPair, 2);
          heff_drop(v_s_27_24140);
          return heff_tag_at(v_ru_24x2_24135_24Right, TAG_Left, 1, (V[]){v_e_24144});
        }
        case TAG_Right: {
          V v_x21_24145 = heff_field(v_x2_24143, 0);
          heff_take_n(v_x2_24143, 1ULL, 1);
          switch (heff_tag_of(v_x21_24145)) {
          case TAG_MkPair: {
            V v_x_24146 = heff_field(v_x21_24145, 0);
            V v_n_24147 = heff_field(v_x21_24145, 1);
            heff_take_n(v_x21_24145, 3ULL, 2);
            V v_t_24148 = heff_arrayToList(heff_get(heff_dup(v_cases_24132), LBL_keys));
            V v_t_24149 = heff_arrayToList(heff_get(heff_dup(v_cases_24132), LBL_values));
            V v_t_24150 = (g_heff_2edict_2ezipKV(v_t_24148, v_t_24149));
            V v_m_24151 = (g_heff_2eerase_2earmsTy_24s543(heff_dup(v_c_240), heff_dup(v_x_24146), v_t_24150));
            V v_x2_24152 = heff_tr(heff_apply(v_m_24151, 1, (V[]){v_n_24147}));
            switch (heff_tag_of(v_x2_24152)) {
            case TAG_Left: {
              V v_e_24153 = heff_field(v_x2_24152, 0);
              heff_take_n(v_x2_24152, 1ULL, 1);
              heff_drop(v_cases_24132);
              heff_drop(v_c_240);
              heff_drop_cell(v_ru_24x21_24137_24MkPair, 2);
              heff_drop(v_s_27_24140);
              heff_drop(v_x_24146);
              return heff_tag_at(v_ru_24x2_24135_24Right, TAG_Left, 1, (V[]){v_e_24153});
            }
            case TAG_Right: {
              V v_x21_24154 = heff_field(v_x2_24152, 0);
              heff_take_n(v_x2_24152, 1ULL, 1);
              switch (heff_tag_of(v_x21_24154)) {
              case TAG_MkPair: {
                V v_x_24155 = heff_field(v_x21_24154, 0);
                V v_n_24156 = heff_field(v_x21_24154, 1);
                heff_take_n(v_x21_24154, 3ULL, 2);
                V v_t_24157 = heff_arrayToList(heff_get(heff_dup(v_cases_24132), LBL_keys));
                V v_t_24158 = heff_arrayToList(heff_get(v_cases_24132, LBL_values));
                V v_t_24159 = (g_heff_2edict_2ezipKV(v_t_24157, v_t_24158));
                V v_m_24161 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2esynF_24s542_lam15, 1, 3, (V[]){v_c_240, v_x_24146, heff_dup(v_x_24155)}), v_t_24159));
                V v_x2_24162 = heff_tr(heff_apply(v_m_24161, 1, (V[]){v_n_24156}));
                switch (heff_tag_of(v_x2_24162)) {
                case TAG_Left: {
                  V v_e_24163 = heff_field(v_x2_24162, 0);
                  heff_take_n(v_x2_24162, 1ULL, 1);
                  heff_drop_cell(v_ru_24x21_24137_24MkPair, 2);
                  heff_drop(v_s_27_24140);
                  heff_drop(v_x_24155);
                  return heff_tag_at(v_ru_24x2_24135_24Right, TAG_Left, 1, (V[]){v_e_24163});
                }
                case TAG_Right: {
                  V v_x21_24164 = heff_field(v_x2_24162, 0);
                  heff_take_n(v_x2_24162, 1ULL, 1);
                  switch (heff_tag_of(v_x21_24164)) {
                  case TAG_MkPair: {
                    V v_x_24165 = heff_field(v_x21_24164, 0);
                    V v_n_24166 = heff_field(v_x21_24164, 1);
                    heff_take_n(v_x21_24164, 3ULL, 2);
                    V v_t_24167 = heff_tag_at(v_ru_24x21_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_27_24140, v_x_24165}), v_x_24155});
                    return heff_tag_at(v_ru_24x2_24135_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24167, v_n_24166})});
                  }
                  default: return heff_nomatch(v_x21_24164);
                  }
                }
                default: return heff_nomatch(v_x2_24162);
                }
              }
              default: return heff_nomatch(v_x21_24154);
              }
            }
            default: return heff_nomatch(v_x2_24152);
            }
          }
          default: return heff_nomatch(v_x21_24145);
          }
        }
        default: return heff_nomatch(v_x2_24143);
        }
      }
      default: return heff_nomatch(v_x_24138);
      }
    }
    default: return heff_nomatch(v_x21_24137);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2eerase_2esynF_24s542_lam16(V self, V *args) {
  V v_n_24171 = args[0];
  heff_drop(v_n_24171);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str16)});
}
V g_heff_2eerase_2esynF_24s542_lam17(V self, V *args) {
  V v_n_24173 = args[0];
  heff_drop(v_n_24173);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str17)});
}
V g_heff_2eerase_2esynF_24s542_lam18(V self, V *args) {
  V v_n_24174 = args[0];
  heff_drop(v_n_24174);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str18)});
}
V g_heff_2eerase_2esynF_24s542_lam19(V self, V *args) {
  V v_n_24184 = args[0];
  V v_m_24183 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_24176 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24185 = heff_tr(heff_apply(v_m_24183, 1, (V[]){v_n_24184}));
  switch (heff_tag_of(v_x2_24185)) {
  case TAG_Left: {
    V v_e_24186 = heff_field(v_x2_24185, 0);
    V v_ru_24x2_24185_24Left = heff_take_reuse_n(v_x2_24185, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_24176);
    return heff_tag_at(v_ru_24x2_24185_24Left, TAG_Left, 1, (V[]){v_e_24186});
  }
  case TAG_Right: {
    V v_x21_24187 = heff_field(v_x2_24185, 0);
    V v_ru_24x2_24185_24Right = heff_take_reuse_n(v_x2_24185, 1ULL, 1);
    switch (heff_tag_of(v_x21_24187)) {
    case TAG_MkPair: {
      V v_x_24188 = heff_field(v_x21_24187, 0);
      V v_n_24189 = heff_field(v_x21_24187, 1);
      V v_ru_24x21_24187_24MkPair = heff_take_reuse_n(v_x21_24187, 3ULL, 2);
      V v_x1_24190 = (g_heff_2eeval_2eevalTypeF_24s15(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_ty_24176, heff_get(v_c_240, LBL_env)));
      V v_t_24194;
      switch (heff_tag_of(v_x1_24190)) {
      case TAG_Nom: {
        V v_x_24191 = heff_field(v_x1_24190, 0);
        heff_take_n(v_x1_24190, 1ULL, 1);
        v_t_24194 = v_x_24191;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24190, 0ULL, 1);
        v_t_24194 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24193 = heff_field(v_x1_24190, 0);
        heff_take_n(v_x1_24190, 1ULL, 1);
        v_t_24194 = v_x_24193;
        break;
      }
      default: heff_nomatch(v_x1_24190);
      }
      V v_x_24195 = heff_tag_at(v_ru_24x21_24187_24MkPair, TAG_MkPair, 2, (V[]){v_x_24188, v_t_24194});
      return heff_tag_at(v_ru_24x2_24185_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_24195, v_n_24189})});
    }
    default: return heff_nomatch(v_x21_24187);
    }
  }
  default: return heff_nomatch(v_x2_24185);
  }
}
V g_heff_2eerase_2esynF_24s542_lam20(V self, V *args) {
  V v_n_24199 = args[0];
  heff_drop(v_n_24199);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str19)});
}
V g_heff_2eerase_2esynF_24s542_lam21(V self, V *args) {
  V v_n_24203 = args[0];
  heff_drop(v_n_24203);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s542_str20)});
}
V g_heff_2eerase_2esynF_24s542_lam22(V self, V *args) {
  V v_n_24205 = args[0];
  V v_i_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24206 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EInt, 1, (V[]){v_i_24204}), NTAG(TAG_VPrimInt)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24206, v_n_24205})});
}
V g_heff_2eerase_2esynF_24s542_lam23(V self, V *args) {
  V v_n_24208 = args[0];
  V v_x_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24209 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EFloat, 1, (V[]){v_x_24207}), NTAG(TAG_VPrimFloat)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24209, v_n_24208})});
}
V g_heff_2eerase_2esynF_24s542_lam24(V self, V *args) {
  V v_n_24211 = args[0];
  V v_s_24210 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24212 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EStr, 1, (V[]){v_s_24210}), NTAG(TAG_VPrimString)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24212, v_n_24211})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2eerase_2echkF_24s537_str0 = {{0x80000000u, K_STR, 0}, 26, 26, {97, 32, 116, 121, 112, 101, 32, 105, 110, 32, 97, 32, 118, 97, 108, 117, 101, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str1 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str2 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str3 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str4 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str5 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str6 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str7 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s537_str8 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str9 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str10 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str11 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eerase_2echkF_24s537_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 111, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str13 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str14 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str15 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str16 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s537_str17 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eerase_2echkF_24s537_str18 = {{0x80000000u, K_STR, 0}, 14, 14, {97, 110, 32, 111, 112, 97, 113, 117, 101, 32, 116, 101, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s537_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s537_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s537_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s537_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s537_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
V g_heff_2eerase_2echkF_24s537_lam0(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam1(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam2(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam2, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam3(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam4(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam4, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam5(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam5, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam6(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam7(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam7, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam8(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam8, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam9(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam9, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam10(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam10, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam11(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam11, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam12(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam12, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam13(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam14(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam14, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam15(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam15, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam16(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam16, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam17(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam18(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam19(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam20(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam20, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam21(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam21, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam22(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam22, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam23(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam23, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam24(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam24, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam26(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam25(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam27(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam28(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam28, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam29(V self, V *args); static Clo g_heff_2eerase_2echkF_24s537_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_lam29, 1, 0};
V g_heff_2eerase_2echkF_24s537_lam31(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam32(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam30(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam33(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam34(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam35(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam36(V self, V *args);
V g_heff_2eerase_2echkF_24s537_lam37(V self, V *args);
Clo g_heff_2eerase_2echkF_24s537_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s537_entry, 3, 0};

V g_heff_2eerase_2echkF_24s537(V v_c_240, V v_t_241, V v_ty_242) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_ty_242);
    V v_m_244 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam0, 1, 1, (V[]){v_m_244});
  }
  case TAG_SGlobal: {
    heff_drop(v_ty_242);
    V v_m_2414 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2eerase_2echkF_24s537_lam2_clo);
  }
  case TAG_SApp: {
    heff_drop(v_ty_242);
    V v_m_2427 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam3, 1, 1, (V[]){v_m_2427});
  }
  case TAG_SLam: {
    V v_abs_2437 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    HEFF_LAST return g_heff_2eerase_2echkLam_24s538(v_c_240, v_abs_2437, v_ty_242);
  }
  case TAG_SCons: {
    V v_d_2438 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_2439 = (g_heff_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam4_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2439, 0ULL, 4);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam5_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2448 = heff_field(v_t_2439, 1);
      V v_fieldTypes_2449 = heff_field(v_t_2439, 2);
      heff_take_n(v_t_2439, 6ULL, 3);
      V v_t_2450 = heff_rec(2, shape_371_223, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2451 = heff_arrayToList(heff_get(heff_dup(v_d_2438), LBL_keys));
      V v_t_2452 = heff_arrayToList(heff_get(v_d_2438, LBL_values));
      V v_t_2453 = (g_heff_2edict_2ezipKV(v_t_2451, v_t_2452));
      V v_m_2454 = (g_heff_2eerase_2echkFieldsGo_24s539(v_c_240, v_capture_2448, v_fieldTypes_2449, v_t_2450, v_t_2453));
      return heff_clo(g_heff_2eerase_2echkF_24s537_lam6, 1, 1, (V[]){v_m_2454});
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam7_clo);
    }
    case TAG_LikeInt: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam8_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam9_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam10_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam11_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam12_clo);
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_SProj: {
    heff_drop(v_ty_242);
    V v_m_2472 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam13, 1, 1, (V[]){v_m_2472});
  }
  case TAG_STag: {
    V v_x_2481 = heff_field(v_t_241, 0);
    V v_args_2482 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_t_2483 = (g_heff_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2483)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2483, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam14_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2483, 0ULL, 4);
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam15_clo);
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2483, 0ULL, 3);
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam16_clo);
    }
    case TAG_LikeSum: {
      V v_vs_2495 = heff_field(v_t_2483, 0);
      V v_ru_24t_2483_24LikeSum = heff_take_reuse_n(v_t_2483, 1ULL, 1);
      V v_t_2496 = ({ V a_0 = heff_dup(v_x_2481); V b_1 = heff_get(heff_dup(v_vs_2495), LBL_byName); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24102;
      switch (heff_tag_of(v_t_2496)) {
      case TAG_Nothing: {
        heff_drop(v_vs_2495);
        heff_drop_cell(v_ru_24t_2483_24LikeSum, 1);
        v_t_24102 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_i_2497 = heff_field(v_t_2496, 0);
        heff_take_n(v_t_2496, 1ULL, 1);
        V v_xs_2498 = heff_get(v_vs_2495, LBL_values);
        V v_t_2499 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2497));
        switch (heff_tag_of(v_t_2499)) {
        case TAG_True: {
          V v_t_24100 = heff_intLt(heff_dup(v_i_2497), heff_arrayLength(heff_dup(v_xs_2498)));
          switch (heff_tag_of(v_t_24100)) {
          case TAG_True: {
            V v_t_24101 = heff_arrayIndex(v_xs_2498, v_i_2497);
            v_t_24102 = heff_tag_at(v_ru_24t_2483_24LikeSum, TAG_Just, 1, (V[]){v_t_24101});
            break;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24t_2483_24LikeSum, 1);
            heff_drop(v_i_2497);
            heff_drop(v_xs_2498);
            v_t_24102 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_24100);
          }
          break;
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_2483_24LikeSum, 1);
          heff_drop(v_i_2497);
          heff_drop(v_xs_2498);
          v_t_24102 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2499);
        }
        break;
      }
      default: heff_nomatch(v_t_2496);
      }
      switch (heff_tag_of(v_t_24102)) {
      case TAG_Nothing: {
        heff_drop(v_c_240);
        heff_drop(v_args_2482);
        return heff_clo(g_heff_2eerase_2echkF_24s537_lam17, 1, 1, (V[]){v_x_2481});
      }
      case TAG_Just: {
        V v_ts_24104 = heff_field(v_t_24102, 0);
        heff_take_n(v_t_24102, 1ULL, 1);
        V v_t_24105 = (g_prelude_2emap_24s431(heff_arrayToList(v_ts_24104)));
        V v_t_24106 = (g_heff_2eerase_2ezipE(heff_arrayToList(v_args_2482), v_t_24105));
        V v_m_24108 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2echkF_24s537_lam18, 1, 1, (V[]){v_c_240}), v_t_24106));
        return heff_clo(g_heff_2eerase_2echkF_24s537_lam19, 1, 2, (V[]){v_m_24108, v_x_2481});
      }
      default: return heff_nomatch(v_t_24102);
      }
    }
    case TAG_LikeInt: {
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam20_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam21_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam22_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2483, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam23_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_c_240);
      heff_drop(v_x_2481);
      heff_drop(v_args_2482);
      return ((V)&g_heff_2eerase_2echkF_24s537_lam24_clo);
    }
    default: return heff_nomatch(v_t_2483);
    }
  }
  case TAG_SMatch: {
    V v_scrut_24122 = heff_field(v_t_241, 0);
    V v_cases_24123 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24124 = (g_heff_2eerase_2esynF_24s542(heff_dup(v_c_240), v_scrut_24122));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam25, 1, 4, (V[]){v_m_24124, v_cases_24123, v_c_240, v_ty_242});
  }
  case TAG_SSpecialize: {
    heff_drop(v_ty_242);
    V v_m_24153 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam27, 1, 1, (V[]){v_m_24153});
  }
  case TAG_SIs: {
    V v_t_27_24162 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24162;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2eerase_2echkF_24s537_lam28_clo);
  }
  case TAG_SAbandon: {
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2eerase_2echkF_24s537_lam29_clo);
  }
  case TAG_SRec: {
    V v_t_27_24166 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24166;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_it2_24168 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    switch (heff_tag_of(v_it2_24168)) {
    case TAG_MkAbs: {
      V v_x_24169 = heff_field(v_it2_24168, 0);
      V v_body_24170 = heff_field(v_it2_24168, 1);
      heff_take_n(v_it2_24168, 3ULL, 2);
      return heff_clo(g_heff_2eerase_2echkF_24s537_lam30, 1, 4, (V[]){v_x_24169, v_ty_242, v_c_240, v_body_24170});
    }
    case TAG_AbsConst: {
      V v_body_24198 = heff_field(v_it2_24168, 0);
      heff_take_n(v_it2_24168, 1ULL, 1);
      V t_0 = v_c_240;
      V t_1 = v_body_24198;
      V t_2 = v_ty_242;
      v_c_240 = t_0;
      v_t_241 = t_1;
      v_ty_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_it2_24168);
    }
  }
  case TAG_SImplicit: {
    V v_t_27_24200 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24200;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_24201 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam33, 1, 1, (V[]){v_x_24201});
  }
  case TAG_SMetaApp: {
    heff_drop(v_ty_242);
    V v_m_24207 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam34, 1, 1, (V[]){v_m_24207});
  }
  case TAG_SLitInt: {
    heff_drop(v_ty_242);
    V v_m_24217 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam35, 1, 1, (V[]){v_m_24217});
  }
  case TAG_SLitFloat: {
    heff_drop(v_ty_242);
    V v_m_24227 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam36, 1, 1, (V[]){v_m_24227});
  }
  case TAG_SLitString: {
    heff_drop(v_ty_242);
    V v_m_24237 = (g_heff_2eerase_2esynF_24s542(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s537_lam37, 1, 1, (V[]){v_m_24237});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2echkF_24s537_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkF_24s537(a[0], a[1], a[2]);
}
V g_heff_2eerase_2echkF_24s537_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Left: {
    V v_e_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Left = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_246_24Left, TAG_Left, 1, (V[]){v_e_247});
  }
  case TAG_Right: {
    V v_x21_248 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Right = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x21_248, 0);
      V v_n_2410 = heff_field(v_x21_248, 1);
      heff_take_n(v_x21_248, 3ULL, 2);
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_t_27_2411 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_246_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2411, v_n_2410})});
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eerase_2echkF_24s537_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2416 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Left: {
    V v_e_2417 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Left = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2416_24Left, TAG_Left, 1, (V[]){v_e_2417});
  }
  case TAG_Right: {
    V v_x21_2418 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Right = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    switch (heff_tag_of(v_x21_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x21_2418, 0);
      V v_n_2420 = heff_field(v_x21_2418, 1);
      heff_take_n(v_x21_2418, 3ULL, 2);
      switch (heff_tag_of(v_x_2419)) {
      case TAG_MkPair: {
        V v_t_27_2421 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_2416_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2421, v_n_2420})});
      }
      default: return heff_nomatch(v_x_2419);
      }
    }
    default: return heff_nomatch(v_x21_2418);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2eerase_2echkF_24s537_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  heff_drop(v_n_2424);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str0)});
}
V g_heff_2eerase_2echkF_24s537_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2429 = heff_tr(heff_apply(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Left: {
    V v_e_2430 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Left = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2429_24Left, TAG_Left, 1, (V[]){v_e_2430});
  }
  case TAG_Right: {
    V v_x21_2431 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Right = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x21_2431, 0);
      V v_n_2433 = heff_field(v_x21_2431, 1);
      heff_take_n(v_x21_2431, 3ULL, 2);
      switch (heff_tag_of(v_x_2432)) {
      case TAG_MkPair: {
        V v_t_27_2434 = heff_field(v_x_2432, 0);
        heff_take_n(v_x_2432, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_2429_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2434, v_n_2433})});
      }
      default: return heff_nomatch(v_x_2432);
      }
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2eerase_2echkF_24s537_lam4(V self, V *args) {
  V v_n_2441 = args[0];
  heff_drop(v_n_2441);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str1)});
}
V g_heff_2eerase_2echkF_24s537_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  heff_drop(v_n_2446);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str2)});
}
V g_heff_2eerase_2echkF_24s537_lam6(V self, V *args) {
  V v_n_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_Left: {
    V v_e_2457 = heff_field(v_x2_2456, 0);
    V v_ru_24x2_2456_24Left = heff_take_reuse_n(v_x2_2456, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2456_24Left, TAG_Left, 1, (V[]){v_e_2457});
  }
  case TAG_Right: {
    V v_x21_2458 = heff_field(v_x2_2456, 0);
    V v_ru_24x2_2456_24Right = heff_take_reuse_n(v_x2_2456, 1ULL, 1);
    switch (heff_tag_of(v_x21_2458)) {
    case TAG_MkPair: {
      V v_x_2459 = heff_field(v_x21_2458, 0);
      V v_n_2460 = heff_field(v_x21_2458, 1);
      V v_ru_24x21_2458_24MkPair = heff_take_reuse_n(v_x21_2458, 3ULL, 2);
      V v_t_2461 = heff_tag_at(v_ru_24x21_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x2_2456_24Right, TAG_ERecord, 1, (V[]){v_x_2459}), v_n_2460});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2461});
    }
    default: return heff_nomatch(v_x21_2458);
    }
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2eerase_2echkF_24s537_lam7(V self, V *args) {
  V v_n_2463 = args[0];
  heff_drop(v_n_2463);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str3)});
}
V g_heff_2eerase_2echkF_24s537_lam8(V self, V *args) {
  V v_n_2464 = args[0];
  heff_drop(v_n_2464);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str4)});
}
V g_heff_2eerase_2echkF_24s537_lam9(V self, V *args) {
  V v_n_2465 = args[0];
  heff_drop(v_n_2465);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str5)});
}
V g_heff_2eerase_2echkF_24s537_lam10(V self, V *args) {
  V v_n_2466 = args[0];
  heff_drop(v_n_2466);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str6)});
}
V g_heff_2eerase_2echkF_24s537_lam11(V self, V *args) {
  V v_n_2468 = args[0];
  heff_drop(v_n_2468);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str7)});
}
V g_heff_2eerase_2echkF_24s537_lam12(V self, V *args) {
  V v_n_2469 = args[0];
  heff_drop(v_n_2469);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str8)});
}
V g_heff_2eerase_2echkF_24s537_lam13(V self, V *args) {
  V v_n_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2474 = heff_tr(heff_apply(v_m_2472, 1, (V[]){v_n_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_Left: {
    V v_e_2475 = heff_field(v_x2_2474, 0);
    V v_ru_24x2_2474_24Left = heff_take_reuse_n(v_x2_2474, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2474_24Left, TAG_Left, 1, (V[]){v_e_2475});
  }
  case TAG_Right: {
    V v_x21_2476 = heff_field(v_x2_2474, 0);
    V v_ru_24x2_2474_24Right = heff_take_reuse_n(v_x2_2474, 1ULL, 1);
    switch (heff_tag_of(v_x21_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x21_2476, 0);
      V v_n_2478 = heff_field(v_x21_2476, 1);
      heff_take_n(v_x21_2476, 3ULL, 2);
      switch (heff_tag_of(v_x_2477)) {
      case TAG_MkPair: {
        V v_t_27_2479 = heff_field(v_x_2477, 0);
        heff_take_n(v_x_2477, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_2474_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2479, v_n_2478})});
      }
      default: return heff_nomatch(v_x_2477);
      }
    }
    default: return heff_nomatch(v_x21_2476);
    }
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2eerase_2echkF_24s537_lam14(V self, V *args) {
  V v_n_2485 = args[0];
  heff_drop(v_n_2485);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str9)});
}
V g_heff_2eerase_2echkF_24s537_lam15(V self, V *args) {
  V v_n_2490 = args[0];
  heff_drop(v_n_2490);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str10)});
}
V g_heff_2eerase_2echkF_24s537_lam16(V self, V *args) {
  V v_n_2494 = args[0];
  heff_drop(v_n_2494);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str11)});
}
V g_heff_2eerase_2echkF_24s537_lam17(V self, V *args) {
  V v_n_24103 = args[0];
  V v_x_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24103);
  return heff_tag(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2eerase_2echkF_24s537_str12), v_x_2481)});
}
V g_heff_2eerase_2echkF_24s537_lam18(V self, V *args) {
  V v_p_24107 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eerase_2echkTagArg_24s540(v_c_240, v_p_24107));
}
V g_heff_2eerase_2echkF_24s537_lam19(V self, V *args) {
  V v_n_24109 = args[0];
  V v_m_24108 = heff_env(self)[0];
  V v_x_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24110 = heff_tr(heff_apply(v_m_24108, 1, (V[]){v_n_24109}));
  switch (heff_tag_of(v_x2_24110)) {
  case TAG_Left: {
    V v_e_24111 = heff_field(v_x2_24110, 0);
    V v_ru_24x2_24110_24Left = heff_take_reuse_n(v_x2_24110, 1ULL, 1);
    heff_drop(v_x_2481);
    return heff_tag_at(v_ru_24x2_24110_24Left, TAG_Left, 1, (V[]){v_e_24111});
  }
  case TAG_Right: {
    V v_x21_24112 = heff_field(v_x2_24110, 0);
    V v_ru_24x2_24110_24Right = heff_take_reuse_n(v_x2_24110, 1ULL, 1);
    switch (heff_tag_of(v_x21_24112)) {
    case TAG_MkPair: {
      V v_x_24113 = heff_field(v_x21_24112, 0);
      V v_n_24114 = heff_field(v_x21_24112, 1);
      V v_ru_24x21_24112_24MkPair = heff_take_reuse_n(v_x21_24112, 3ULL, 2);
      V v_x_24115 = heff_tag_at(v_ru_24x21_24112_24MkPair, TAG_ETag, 2, (V[]){v_x_2481, (g_heff_2eerase_2ecatMaybesE(v_x_24113))});
      return heff_tag_at(v_ru_24x2_24110_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_24115, v_n_24114})});
    }
    default: return heff_nomatch(v_x21_24112);
    }
  }
  default: return heff_nomatch(v_x2_24110);
  }
}
V g_heff_2eerase_2echkF_24s537_lam20(V self, V *args) {
  V v_n_24116 = args[0];
  heff_drop(v_n_24116);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str13)});
}
V g_heff_2eerase_2echkF_24s537_lam21(V self, V *args) {
  V v_n_24117 = args[0];
  heff_drop(v_n_24117);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str14)});
}
V g_heff_2eerase_2echkF_24s537_lam22(V self, V *args) {
  V v_n_24118 = args[0];
  heff_drop(v_n_24118);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str15)});
}
V g_heff_2eerase_2echkF_24s537_lam23(V self, V *args) {
  V v_n_24120 = args[0];
  heff_drop(v_n_24120);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str16)});
}
V g_heff_2eerase_2echkF_24s537_lam24(V self, V *args) {
  V v_n_24121 = args[0];
  heff_drop(v_n_24121);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str17)});
}
V g_heff_2eerase_2echkF_24s537_lam26(V self, V *args) {
  V v_p_24142 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24137 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eerase_2earmOf_24s541(v_c_240, v_x_24137, v_ty_242, v_p_24142));
}
V g_heff_2eerase_2echkF_24s537_lam25(V self, V *args) {
  V v_n_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  V v_cases_24123 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24126 = heff_tr(heff_apply(v_m_24124, 1, (V[]){v_n_24125}));
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_Left: {
    V v_e_24127 = heff_field(v_x2_24126, 0);
    V v_ru_24x2_24126_24Left = heff_take_reuse_n(v_x2_24126, 1ULL, 1);
    heff_drop(v_cases_24123);
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return heff_tag_at(v_ru_24x2_24126_24Left, TAG_Left, 1, (V[]){v_e_24127});
  }
  case TAG_Right: {
    V v_x21_24128 = heff_field(v_x2_24126, 0);
    V v_ru_24x2_24126_24Right = heff_take_reuse_n(v_x2_24126, 1ULL, 1);
    switch (heff_tag_of(v_x21_24128)) {
    case TAG_MkPair: {
      V v_x_24129 = heff_field(v_x21_24128, 0);
      V v_n_24130 = heff_field(v_x21_24128, 1);
      V v_ru_24x21_24128_24MkPair = heff_take_reuse_n(v_x21_24128, 3ULL, 2);
      switch (heff_tag_of(v_x_24129)) {
      case TAG_MkPair: {
        V v_s_27_24131 = heff_field(v_x_24129, 0);
        V v_sty_24132 = heff_field(v_x_24129, 1);
        heff_take_n(v_x_24129, 3ULL, 2);
        V v_m_24133 = (g_heff_2eerase_2ematchVariants(v_sty_24132));
        V v_x2_24134 = heff_tr(heff_apply(v_m_24133, 1, (V[]){v_n_24130}));
        switch (heff_tag_of(v_x2_24134)) {
        case TAG_Left: {
          V v_e_24135 = heff_field(v_x2_24134, 0);
          heff_take_n(v_x2_24134, 1ULL, 1);
          heff_drop(v_cases_24123);
          heff_drop(v_c_240);
          heff_drop(v_ty_242);
          heff_drop_cell(v_ru_24x21_24128_24MkPair, 2);
          heff_drop(v_s_27_24131);
          return heff_tag_at(v_ru_24x2_24126_24Right, TAG_Left, 1, (V[]){v_e_24135});
        }
        case TAG_Right: {
          V v_x21_24136 = heff_field(v_x2_24134, 0);
          heff_take_n(v_x2_24134, 1ULL, 1);
          switch (heff_tag_of(v_x21_24136)) {
          case TAG_MkPair: {
            V v_x_24137 = heff_field(v_x21_24136, 0);
            V v_n_24138 = heff_field(v_x21_24136, 1);
            heff_take_n(v_x21_24136, 3ULL, 2);
            V v_t_24139 = heff_arrayToList(heff_get(heff_dup(v_cases_24123), LBL_keys));
            V v_t_24140 = heff_arrayToList(heff_get(v_cases_24123, LBL_values));
            V v_t_24141 = (g_heff_2edict_2ezipKV(v_t_24139, v_t_24140));
            V v_m_24143 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2echkF_24s537_lam26, 1, 3, (V[]){v_c_240, v_x_24137, v_ty_242}), v_t_24141));
            V v_x2_24144 = heff_tr(heff_apply(v_m_24143, 1, (V[]){v_n_24138}));
            switch (heff_tag_of(v_x2_24144)) {
            case TAG_Left: {
              V v_e_24145 = heff_field(v_x2_24144, 0);
              heff_take_n(v_x2_24144, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_24128_24MkPair, 2);
              heff_drop(v_s_27_24131);
              return heff_tag_at(v_ru_24x2_24126_24Right, TAG_Left, 1, (V[]){v_e_24145});
            }
            case TAG_Right: {
              V v_x21_24146 = heff_field(v_x2_24144, 0);
              heff_take_n(v_x2_24144, 1ULL, 1);
              switch (heff_tag_of(v_x21_24146)) {
              case TAG_MkPair: {
                V v_x_24147 = heff_field(v_x21_24146, 0);
                V v_n_24148 = heff_field(v_x21_24146, 1);
                heff_take_n(v_x21_24146, 3ULL, 2);
                V v_t_24149 = heff_tag_at(v_ru_24x21_24128_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_27_24131, v_x_24147}), v_n_24148});
                return heff_tag_at(v_ru_24x2_24126_24Right, TAG_Right, 1, (V[]){v_t_24149});
              }
              default: return heff_nomatch(v_x21_24146);
              }
            }
            default: return heff_nomatch(v_x2_24144);
            }
          }
          default: return heff_nomatch(v_x21_24136);
          }
        }
        default: return heff_nomatch(v_x2_24134);
        }
      }
      default: return heff_nomatch(v_x_24129);
      }
    }
    default: return heff_nomatch(v_x21_24128);
    }
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2eerase_2echkF_24s537_lam27(V self, V *args) {
  V v_n_24154 = args[0];
  V v_m_24153 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24155 = heff_tr(heff_apply(v_m_24153, 1, (V[]){v_n_24154}));
  switch (heff_tag_of(v_x2_24155)) {
  case TAG_Left: {
    V v_e_24156 = heff_field(v_x2_24155, 0);
    V v_ru_24x2_24155_24Left = heff_take_reuse_n(v_x2_24155, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24155_24Left, TAG_Left, 1, (V[]){v_e_24156});
  }
  case TAG_Right: {
    V v_x21_24157 = heff_field(v_x2_24155, 0);
    V v_ru_24x2_24155_24Right = heff_take_reuse_n(v_x2_24155, 1ULL, 1);
    switch (heff_tag_of(v_x21_24157)) {
    case TAG_MkPair: {
      V v_x_24158 = heff_field(v_x21_24157, 0);
      V v_n_24159 = heff_field(v_x21_24157, 1);
      heff_take_n(v_x21_24157, 3ULL, 2);
      switch (heff_tag_of(v_x_24158)) {
      case TAG_MkPair: {
        V v_t_27_24160 = heff_field(v_x_24158, 0);
        heff_take_n(v_x_24158, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24155_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24160, v_n_24159})});
      }
      default: return heff_nomatch(v_x_24158);
      }
    }
    default: return heff_nomatch(v_x21_24157);
    }
  }
  default: return heff_nomatch(v_x2_24155);
  }
}
V g_heff_2eerase_2echkF_24s537_lam28(V self, V *args) {
  V v_n_24163 = args[0];
  heff_drop(v_n_24163);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s537_str18)});
}
V g_heff_2eerase_2echkF_24s537_lam29(V self, V *args) {
  V v_n_24164 = args[0];
  V v_t_24165 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_n_24164});
  return heff_tag(TAG_Right, 1, (V[]){v_t_24165});
}
V g_heff_2eerase_2echkF_24s537_lam31(V self, V *args) {
  V v_u_24185 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24185);
  return v_ty_242;
}
V g_heff_2eerase_2echkF_24s537_lam32(V self, V *args) {
  V v_u_24187 = args[0];
  V v_v_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24187);
  return v_v_24186;
}
V g_heff_2eerase_2echkF_24s537_lam30(V self, V *args) {
  V v_n_24171 = args[0];
  V v_x_24169 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_body_24170 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24172 = heff_strEq(heff_dup(v_x_24169), ((V)&g_heff_2eerase_2echkF_24s537_str19));
  V v_base_24174;
  switch (heff_tag_of(v_t_24172)) {
  case TAG_True: {
    heff_drop(v_x_24169);
    v_base_24174 = ((V)&g_heff_2eerase_2echkF_24s537_str20);
    break;
  }
  case TAG_False: {
    V v_t_24173 = heff_strEq(heff_dup(v_x_24169), ((V)&g_heff_2eerase_2echkF_24s537_str21));
    switch (heff_tag_of(v_t_24173)) {
    case TAG_True: {
      heff_drop(v_x_24169);
      v_base_24174 = ((V)&g_heff_2eerase_2echkF_24s537_str22);
      break;
    }
    case TAG_False: {
      v_base_24174 = v_x_24169;
      break;
    }
    default: heff_nomatch(v_t_24173);
    }
    break;
  }
  default: heff_nomatch(v_t_24172);
  }
  V v_t_24175 = heff_strAppend(v_base_24174, heff_strAppend(((V)&g_heff_2eerase_2echkF_24s537_str23), heff_intShow(heff_dup(v_n_24171))));
  V v_t_24176 = heff_tag(TAG_MkPair, 2, (V[]){v_t_24175, heff_intAdd(v_n_24171, MK_INT(1LL))});
  V v_x2_24177 = heff_tag(TAG_Right, 1, (V[]){v_t_24176});
  switch (heff_tag_of(v_x2_24177)) {
  case TAG_Left: {
    V v_e_24178 = heff_field(v_x2_24177, 0);
    V v_ru_24x2_24177_24Left = heff_take_reuse_n(v_x2_24177, 1ULL, 1);
    heff_drop(v_ty_242);
    heff_drop(v_c_240);
    heff_drop(v_body_24170);
    return heff_tag_at(v_ru_24x2_24177_24Left, TAG_Left, 1, (V[]){v_e_24178});
  }
  case TAG_Right: {
    V v_x21_24179 = heff_field(v_x2_24177, 0);
    V v_ru_24x2_24177_24Right = heff_take_reuse_n(v_x2_24177, 1ULL, 1);
    switch (heff_tag_of(v_x21_24179)) {
    case TAG_MkPair: {
      V v_x_24180 = heff_field(v_x21_24179, 0);
      V v_n_24181 = heff_field(v_x21_24179, 1);
      V v_ru_24x21_24179_24MkPair = heff_take_reuse_n(v_x21_24179, 3ULL, 2);
      V v_t_24182 = heff_tag_at(v_ru_24x2_24177_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24180)})});
      V v_t_24183 = heff_tag_at(v_ru_24x21_24179_24MkPair, TAG_Cons, 2, (V[]){heff_rec(2, shape_146_351, (V[]){v_t_24182, heff_dup(v_ty_242)}), heff_get(heff_dup(v_c_240), LBL_locals)});
      V v_t_24184 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
      V v_v_24186 = (g_heff_2evalue_2emkNeu_24s10(v_t_24184, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkF_24s537_lam31, 1, 1, (V[]){heff_dup(v_ty_242)}), NTAG(TAG_Nothing)));
      V v_t_24188 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkF_24s537_lam32, 1, 1, (V[]){v_v_24186})});
      V v_t_24189 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
      V v_c_24190 = heff_rec(4, shape_179_87_168_115, (V[]){v_t_24183, v_t_24188, v_t_24189, heff_get(v_c_240, LBL_globals)});
      V v_m_24191 = (g_heff_2eerase_2echkF_24s537(v_c_24190, v_body_24170, v_ty_242));
      V v_x2_24192 = heff_tr(heff_apply(v_m_24191, 1, (V[]){v_n_24181}));
      switch (heff_tag_of(v_x2_24192)) {
      case TAG_Left: {
        V v_e_24193 = heff_field(v_x2_24192, 0);
        V v_ru_24x2_24192_24Left = heff_take_reuse_n(v_x2_24192, 1ULL, 1);
        heff_drop(v_x_24180);
        return heff_tag_at(v_ru_24x2_24192_24Left, TAG_Left, 1, (V[]){v_e_24193});
      }
      case TAG_Right: {
        V v_x21_24194 = heff_field(v_x2_24192, 0);
        V v_ru_24x2_24192_24Right = heff_take_reuse_n(v_x2_24192, 1ULL, 1);
        switch (heff_tag_of(v_x21_24194)) {
        case TAG_MkPair: {
          V v_x_24195 = heff_field(v_x21_24194, 0);
          V v_n_24196 = heff_field(v_x21_24194, 1);
          V v_ru_24x21_24194_24MkPair = heff_take_reuse_n(v_x21_24194, 3ULL, 2);
          V v_t_24197 = heff_tag_at(v_ru_24x21_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EFix, 2, (V[]){v_x_24180, v_x_24195}), v_n_24196});
          return heff_tag_at(v_ru_24x2_24192_24Right, TAG_Right, 1, (V[]){v_t_24197});
        }
        default: return heff_nomatch(v_x21_24194);
        }
      }
      default: return heff_nomatch(v_x2_24192);
      }
    }
    default: return heff_nomatch(v_x21_24179);
    }
  }
  default: return heff_nomatch(v_x2_24177);
  }
}
V g_heff_2eerase_2echkF_24s537_lam33(V self, V *args) {
  V v_n_24202 = args[0];
  V v_x_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24203 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrim, 1, (V[]){v_x_24201}), v_n_24202});
  return heff_tag(TAG_Right, 1, (V[]){v_t_24203});
}
V g_heff_2eerase_2echkF_24s537_lam34(V self, V *args) {
  V v_n_24208 = args[0];
  V v_m_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24209 = heff_tr(heff_apply(v_m_24207, 1, (V[]){v_n_24208}));
  switch (heff_tag_of(v_x2_24209)) {
  case TAG_Left: {
    V v_e_24210 = heff_field(v_x2_24209, 0);
    V v_ru_24x2_24209_24Left = heff_take_reuse_n(v_x2_24209, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24209_24Left, TAG_Left, 1, (V[]){v_e_24210});
  }
  case TAG_Right: {
    V v_x21_24211 = heff_field(v_x2_24209, 0);
    V v_ru_24x2_24209_24Right = heff_take_reuse_n(v_x2_24209, 1ULL, 1);
    switch (heff_tag_of(v_x21_24211)) {
    case TAG_MkPair: {
      V v_x_24212 = heff_field(v_x21_24211, 0);
      V v_n_24213 = heff_field(v_x21_24211, 1);
      heff_take_n(v_x21_24211, 3ULL, 2);
      switch (heff_tag_of(v_x_24212)) {
      case TAG_MkPair: {
        V v_t_27_24214 = heff_field(v_x_24212, 0);
        heff_take_n(v_x_24212, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24209_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24214, v_n_24213})});
      }
      default: return heff_nomatch(v_x_24212);
      }
    }
    default: return heff_nomatch(v_x21_24211);
    }
  }
  default: return heff_nomatch(v_x2_24209);
  }
}
V g_heff_2eerase_2echkF_24s537_lam35(V self, V *args) {
  V v_n_24218 = args[0];
  V v_m_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24219 = heff_tr(heff_apply(v_m_24217, 1, (V[]){v_n_24218}));
  switch (heff_tag_of(v_x2_24219)) {
  case TAG_Left: {
    V v_e_24220 = heff_field(v_x2_24219, 0);
    V v_ru_24x2_24219_24Left = heff_take_reuse_n(v_x2_24219, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24219_24Left, TAG_Left, 1, (V[]){v_e_24220});
  }
  case TAG_Right: {
    V v_x21_24221 = heff_field(v_x2_24219, 0);
    V v_ru_24x2_24219_24Right = heff_take_reuse_n(v_x2_24219, 1ULL, 1);
    switch (heff_tag_of(v_x21_24221)) {
    case TAG_MkPair: {
      V v_x_24222 = heff_field(v_x21_24221, 0);
      V v_n_24223 = heff_field(v_x21_24221, 1);
      heff_take_n(v_x21_24221, 3ULL, 2);
      switch (heff_tag_of(v_x_24222)) {
      case TAG_MkPair: {
        V v_t_27_24224 = heff_field(v_x_24222, 0);
        heff_take_n(v_x_24222, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24219_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24224, v_n_24223})});
      }
      default: return heff_nomatch(v_x_24222);
      }
    }
    default: return heff_nomatch(v_x21_24221);
    }
  }
  default: return heff_nomatch(v_x2_24219);
  }
}
V g_heff_2eerase_2echkF_24s537_lam36(V self, V *args) {
  V v_n_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24229 = heff_tr(heff_apply(v_m_24227, 1, (V[]){v_n_24228}));
  switch (heff_tag_of(v_x2_24229)) {
  case TAG_Left: {
    V v_e_24230 = heff_field(v_x2_24229, 0);
    V v_ru_24x2_24229_24Left = heff_take_reuse_n(v_x2_24229, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24229_24Left, TAG_Left, 1, (V[]){v_e_24230});
  }
  case TAG_Right: {
    V v_x21_24231 = heff_field(v_x2_24229, 0);
    V v_ru_24x2_24229_24Right = heff_take_reuse_n(v_x2_24229, 1ULL, 1);
    switch (heff_tag_of(v_x21_24231)) {
    case TAG_MkPair: {
      V v_x_24232 = heff_field(v_x21_24231, 0);
      V v_n_24233 = heff_field(v_x21_24231, 1);
      heff_take_n(v_x21_24231, 3ULL, 2);
      switch (heff_tag_of(v_x_24232)) {
      case TAG_MkPair: {
        V v_t_27_24234 = heff_field(v_x_24232, 0);
        heff_take_n(v_x_24232, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24229_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24234, v_n_24233})});
      }
      default: return heff_nomatch(v_x_24232);
      }
    }
    default: return heff_nomatch(v_x21_24231);
    }
  }
  default: return heff_nomatch(v_x2_24229);
  }
}
V g_heff_2eerase_2echkF_24s537_lam37(V self, V *args) {
  V v_n_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24239 = heff_tr(heff_apply(v_m_24237, 1, (V[]){v_n_24238}));
  switch (heff_tag_of(v_x2_24239)) {
  case TAG_Left: {
    V v_e_24240 = heff_field(v_x2_24239, 0);
    V v_ru_24x2_24239_24Left = heff_take_reuse_n(v_x2_24239, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24239_24Left, TAG_Left, 1, (V[]){v_e_24240});
  }
  case TAG_Right: {
    V v_x21_24241 = heff_field(v_x2_24239, 0);
    V v_ru_24x2_24239_24Right = heff_take_reuse_n(v_x2_24239, 1ULL, 1);
    switch (heff_tag_of(v_x21_24241)) {
    case TAG_MkPair: {
      V v_x_24242 = heff_field(v_x21_24241, 0);
      V v_n_24243 = heff_field(v_x21_24241, 1);
      heff_take_n(v_x21_24241, 3ULL, 2);
      switch (heff_tag_of(v_x_24242)) {
      case TAG_MkPair: {
        V v_t_27_24244 = heff_field(v_x_24242, 0);
        heff_take_n(v_x_24242, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24239_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24244, v_n_24243})});
      }
      default: return heff_nomatch(v_x_24242);
      }
    }
    default: return heff_nomatch(v_x21_24241);
    }
  }
  default: return heff_nomatch(v_x2_24239);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s534_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s534_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s534_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s534_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s534_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s534_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
V g_heff_2eerase_2echkDF_24s534_lam0(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam1(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam3(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam2(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam5(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam4(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam7(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam8(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam10(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam9(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam12(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam11(V self, V *args);
V g_heff_2eerase_2echkDF_24s534_lam6(V self, V *args);
Clo g_heff_2eerase_2echkDF_24s534_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkDF_24s534_entry, 4, 0};

V g_heff_2eerase_2echkDF_24s534(V v_c_240, V v_t_241, V v_ty_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SGlobal: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SCode: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SApp: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLam: {
    V v_abs_2410 = heff_dup(heff_field(v_t_241, 1));
    V v_t_2411 = (g_heff_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      V v_dom_2414 = heff_field(v_t_2411, 1);
      V v_cod_2415 = heff_field(v_t_2411, 2);
      heff_take_n(v_t_2411, 6ULL, 4);
      heff_drop_tag(v_t_241, 2);
      heff_drop(v_ty_242);
      V v_it_2422;
      switch (heff_tag_of(v_abs_2410)) {
      case TAG_MkAbs: {
        V v_n_2417 = heff_field(v_abs_2410, 0);
        V v_b_2418 = heff_field(v_abs_2410, 1);
        V v_ru_24abs_2410_24MkAbs = heff_take_reuse_n(v_abs_2410, 3ULL, 2);
        V v_t_2419 = heff_tag_at(v_ru_24abs_2410_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2417, NTAG(TAG_True)});
        v_it_2422 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2419, v_b_2418});
        break;
      }
      case TAG_AbsConst: {
        V v_b_2420 = heff_field(v_abs_2410, 0);
        heff_take_n(v_abs_2410, 1ULL, 1);
        V v_t_2421 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eerase_2echkDF_24s534_str0), NTAG(TAG_False)});
        v_it_2422 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2421, v_b_2420});
        break;
      }
      default: heff_nomatch(v_abs_2410);
      }
      switch (heff_tag_of(v_it_2422)) {
      case TAG_MkPair: {
        V v_it1_2423 = heff_field(v_it_2422, 0);
        V v_body_2424 = heff_field(v_it_2422, 1);
        V v_ru_24it_2422_24MkPair = heff_take_reuse_n(v_it_2422, 3ULL, 2);
        switch (heff_tag_of(v_it1_2423)) {
        case TAG_MkPair: {
          V v_hint_2425 = heff_field(v_it1_2423, 0);
          V v_bound_2426 = heff_field(v_it1_2423, 1);
          V v_ru_24it1_2423_24MkPair = heff_take_reuse_n(v_it1_2423, 3ULL, 2);
          V v_t_2427 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_dom_2414)));
          switch (heff_tag_of(v_t_2427)) {
          case TAG_True: {
            heff_drop(v_hint_2425);
            V v_c_2436;
            switch (heff_tag_of(v_bound_2426)) {
            case TAG_True: {
              V v_t_2428 = heff_rec(2, shape_146_351, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_2414)});
              V v_t_2429 = heff_tag_at(v_ru_24it_2422_24MkPair, TAG_Cons, 2, (V[]){v_t_2428, heff_get(heff_dup(v_c_240), LBL_locals)});
              V v_t_2430 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
              V v_v_2432 = (g_heff_2evalue_2emkNeu_24s10(v_t_2430, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s534_lam0, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
              V v_t_2434 = heff_tag_at(v_ru_24it1_2423_24MkPair, TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkDF_24s534_lam1, 1, 1, (V[]){v_v_2432})});
              V v_t_2435 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
              v_c_2436 = heff_rec(4, shape_179_87_168_115, (V[]){v_t_2429, v_t_2434, v_t_2435, heff_get(heff_dup(v_c_240), LBL_globals)});
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_2422_24MkPair, 2);
              heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
              v_c_2436 = heff_dup(v_c_240);
              break;
            }
            default: heff_nomatch(v_bound_2426);
            }
            V v_x1_2444;
            switch (heff_tag_of(v_cod_2415)) {
            case TAG_MkClo: {
              V v_vs_2438 = heff_field(v_cod_2415, 1);
              V v_body_2439 = heff_field(v_cod_2415, 2);
              heff_take_n(v_cod_2415, 6ULL, 3);
              v_x1_2444 = heff_tr(heff_apply(v_body_2439, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2438, heff_clo(g_heff_2eerase_2echkDF_24s534_lam2, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2443 = heff_field(v_cod_2415, 0);
              heff_take_n(v_cod_2415, 1ULL, 1);
              v_x1_2444 = v_body_2443;
              break;
            }
            default: heff_nomatch(v_cod_2415);
            }
            V v_ty_2448;
            switch (heff_tag_of(v_x1_2444)) {
            case TAG_Nom: {
              V v_x_2445 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2445;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2444, 0ULL, 1);
              v_ty_2448 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2447 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2447;
              break;
            }
            default: heff_nomatch(v_x1_2444);
            }
            V v_x1_2452 = heff_tr(g_heff_2evalue_2eapp(v_v_243, heff_clo(g_heff_2eerase_2echkDF_24s534_lam4, 1, 2, (V[]){v_c_240, v_dom_2414})));
            V v_v_2456;
            switch (heff_tag_of(v_x1_2452)) {
            case TAG_Nom: {
              V v_x_2453 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2453;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2452, 0ULL, 1);
              v_v_2456 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2455 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2455;
              break;
            }
            default: heff_nomatch(v_x1_2452);
            }
            V t_0 = v_c_2436;
            V t_1 = v_body_2424;
            V t_2 = v_ty_2448;
            V t_3 = v_v_2456;
            v_c_240 = t_0;
            v_t_241 = t_1;
            v_ty_242 = t_2;
            v_v_243 = t_3;
            goto top;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24it_2422_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
            return heff_clo(g_heff_2eerase_2echkDF_24s534_lam6, 1, 7, (V[]){v_hint_2425, v_bound_2426, v_dom_2414, v_c_240, v_cod_2415, v_v_243, v_body_2424});
          }
          default: return heff_nomatch(v_t_2427);
          }
        }
        default: return heff_nomatch(v_it1_2423);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2411, 0ULL, 3);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_SCons: {
    V v_d_24110 = heff_dup(heff_field(v_t_241, 0));
    V v_t_24111 = (g_heff_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_24111)) {
    case TAG_LikeU: {
      heff_take_n(v_t_24111, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_24111, 0ULL, 4);
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_24111, 0ULL, 3);
      heff_drop_tag(v_t_241, 1);
      V v_t_24120 = heff_arrayToList(heff_get(heff_dup(v_d_24110), LBL_keys));
      V v_t_24121 = heff_arrayToList(heff_get(v_d_24110, LBL_values));
      V v_t_24122 = (g_heff_2edict_2ezipKV(v_t_24120, v_t_24121));
      V v_t_24123 = (g_heff_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_243)));
      return (g_heff_2eerase_2echkDFields_24s535(v_c_240, v_ty_242, v_v_243, v_t_24122, v_t_24123));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_24111, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_24111, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_d_24110);
      return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_24111);
    }
  }
  case TAG_SProj: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_STag: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMatch: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SSpecialize: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SIs: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SOpaque: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SAbandon: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SRec: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SFix: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SImplicit: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SPrim: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMetaApp: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitInt: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFloat: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitString: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s537(v_c_240, v_t_241, v_ty_242));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2echkDF_24s534_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkDF_24s534(a[0], a[1], a[2], a[3]);
}
V g_heff_2eerase_2echkDF_24s534_lam0(V self, V *args) {
  V v_u_2431 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s534_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_v_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_v_2432;
}
V g_heff_2eerase_2echkDF_24s534_lam3(V self, V *args) {
  V v_u_2442 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s534_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2440);
  V v_t_2441 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s10(v_t_2441, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s534_lam3, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s534_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2451);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s534_lam4(V self, V *args) {
  V v_u_2449 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2449);
  V v_t_2450 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s10(v_t_2450, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s534_lam5, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s534_lam7(V self, V *args) {
  V v_u_2471 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2471);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s534_lam8(V self, V *args) {
  V v_u_2473 = args[0];
  V v_v_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return v_v_2472;
}
V g_heff_2eerase_2echkDF_24s534_lam10(V self, V *args) {
  V v_u_2482 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2482);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s534_lam9(V self, V *args) {
  V v_u_2480 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2480);
  V v_t_2481 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s10(v_t_2481, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s534_lam10, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s534_lam12(V self, V *args) {
  V v_u_2491 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s534_lam11(V self, V *args) {
  V v_u_2489 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2489);
  V v_t_2490 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s10(v_t_2490, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s534_lam12, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s534_lam6(V self, V *args) {
  V v_n_2457 = args[0];
  V v_hint_2425 = heff_env(self)[0];
  V v_bound_2426 = heff_env(self)[1];
  V v_dom_2414 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_cod_2415 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_body_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2458 = heff_strEq(heff_dup(v_hint_2425), ((V)&g_heff_2eerase_2echkDF_24s534_str1));
  V v_base_2460;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_True: {
    heff_drop(v_hint_2425);
    v_base_2460 = ((V)&g_heff_2eerase_2echkDF_24s534_str2);
    break;
  }
  case TAG_False: {
    V v_t_2459 = heff_strEq(heff_dup(v_hint_2425), ((V)&g_heff_2eerase_2echkDF_24s534_str3));
    switch (heff_tag_of(v_t_2459)) {
    case TAG_True: {
      heff_drop(v_hint_2425);
      v_base_2460 = ((V)&g_heff_2eerase_2echkDF_24s534_str4);
      break;
    }
    case TAG_False: {
      v_base_2460 = v_hint_2425;
      break;
    }
    default: heff_nomatch(v_t_2459);
    }
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  V v_t_2461 = heff_strAppend(v_base_2460, heff_strAppend(((V)&g_heff_2eerase_2echkDF_24s534_str5), heff_intShow(heff_dup(v_n_2457))));
  V v_t_2462 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2461, heff_intAdd(v_n_2457, MK_INT(1LL))});
  V v_x2_2463 = heff_tag(TAG_Right, 1, (V[]){v_t_2462});
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_Left: {
    V v_e_2464 = heff_field(v_x2_2463, 0);
    V v_ru_24x2_2463_24Left = heff_take_reuse_n(v_x2_2463, 1ULL, 1);
    heff_drop(v_bound_2426);
    heff_drop(v_dom_2414);
    heff_drop(v_c_240);
    heff_drop(v_cod_2415);
    heff_drop(v_v_243);
    heff_drop(v_body_2424);
    return heff_tag_at(v_ru_24x2_2463_24Left, TAG_Left, 1, (V[]){v_e_2464});
  }
  case TAG_Right: {
    V v_x21_2465 = heff_field(v_x2_2463, 0);
    V v_ru_24x2_2463_24Right = heff_take_reuse_n(v_x2_2463, 1ULL, 1);
    switch (heff_tag_of(v_x21_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x21_2465, 0);
      V v_n_2467 = heff_field(v_x21_2465, 1);
      V v_ru_24x21_2465_24MkPair = heff_take_reuse_n(v_x21_2465, 3ULL, 2);
      V v_c_2476;
      switch (heff_tag_of(v_bound_2426)) {
      case TAG_True: {
        V v_t_2468 = heff_tag_at(v_ru_24x2_2463_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2466)})});
        V v_t_2469 = heff_tag_at(v_ru_24x21_2465_24MkPair, TAG_Cons, 2, (V[]){heff_rec(2, shape_146_351, (V[]){v_t_2468, heff_dup(v_dom_2414)}), heff_get(heff_dup(v_c_240), LBL_locals)});
        V v_t_2470 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
        V v_v_2472 = (g_heff_2evalue_2emkNeu_24s10(v_t_2470, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s534_lam7, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
        V v_t_2474 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkDF_24s534_lam8, 1, 1, (V[]){v_v_2472})});
        V v_t_2475 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
        v_c_2476 = heff_rec(4, shape_179_87_168_115, (V[]){v_t_2469, v_t_2474, v_t_2475, heff_get(heff_dup(v_c_240), LBL_globals)});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_2463_24Right, 1);
        heff_drop_cell(v_ru_24x21_2465_24MkPair, 2);
        v_c_2476 = heff_dup(v_c_240);
        break;
      }
      default: heff_nomatch(v_bound_2426);
      }
      V v_x1_2484;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_vs_2478 = heff_field(v_cod_2415, 1);
        V v_body_2479 = heff_field(v_cod_2415, 2);
        heff_take_n(v_cod_2415, 6ULL, 3);
        v_x1_2484 = heff_tr(heff_apply(v_body_2479, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2478, heff_clo(g_heff_2eerase_2echkDF_24s534_lam9, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2483 = heff_field(v_cod_2415, 0);
        heff_take_n(v_cod_2415, 1ULL, 1);
        v_x1_2484 = v_body_2483;
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_ty_2488;
      switch (heff_tag_of(v_x1_2484)) {
      case TAG_Nom: {
        V v_x_2485 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        v_ty_2488 = v_x_2485;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2484, 0ULL, 1);
        v_ty_2488 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2487 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        v_ty_2488 = v_x_2487;
        break;
      }
      default: heff_nomatch(v_x1_2484);
      }
      V v_x1_2492 = heff_tr(g_heff_2evalue_2eapp(v_v_243, heff_clo(g_heff_2eerase_2echkDF_24s534_lam11, 1, 2, (V[]){v_c_240, v_dom_2414})));
      V v_v_2496;
      switch (heff_tag_of(v_x1_2492)) {
      case TAG_Nom: {
        V v_x_2493 = heff_field(v_x1_2492, 0);
        heff_take_n(v_x1_2492, 1ULL, 1);
        v_v_2496 = v_x_2493;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2492, 0ULL, 1);
        v_v_2496 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2495 = heff_field(v_x1_2492, 0);
        heff_take_n(v_x1_2492, 1ULL, 1);
        v_v_2496 = v_x_2495;
        break;
      }
      default: heff_nomatch(v_x1_2492);
      }
      V v_m_2497 = (g_heff_2eerase_2echkDF_24s534(v_c_2476, v_body_2424, v_ty_2488, v_v_2496));
      V v_x2_2498 = heff_tr(heff_apply(v_m_2497, 1, (V[]){v_n_2467}));
      switch (heff_tag_of(v_x2_2498)) {
      case TAG_Left: {
        V v_e_2499 = heff_field(v_x2_2498, 0);
        V v_ru_24x2_2498_24Left = heff_take_reuse_n(v_x2_2498, 1ULL, 1);
        heff_drop(v_x_2466);
        return heff_tag_at(v_ru_24x2_2498_24Left, TAG_Left, 1, (V[]){v_e_2499});
      }
      case TAG_Right: {
        V v_x21_24100 = heff_field(v_x2_2498, 0);
        V v_ru_24x2_2498_24Right = heff_take_reuse_n(v_x2_2498, 1ULL, 1);
        switch (heff_tag_of(v_x21_24100)) {
        case TAG_MkPair: {
          V v_x_24101 = heff_field(v_x21_24100, 0);
          V v_n_24102 = heff_field(v_x21_24100, 1);
          V v_ru_24x21_24100_24MkPair = heff_take_reuse_n(v_x21_24100, 3ULL, 2);
          V v_t_24103 = heff_tag_at(v_ru_24x21_24100_24MkPair, TAG_Cons, 2, (V[]){v_x_2466, NTAG(TAG_Nil)});
          V v_t_24104 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_24103, v_x_24101}), v_n_24102});
          return heff_tag_at(v_ru_24x2_2498_24Right, TAG_Right, 1, (V[]){v_t_24104});
        }
        default: return heff_nomatch(v_x21_24100);
        }
      }
      default: return heff_nomatch(v_x2_2498);
      }
    }
    default: return heff_nomatch(v_x21_2465);
    }
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eerase_2eeraseOne_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2eerase_2eeraseOne_lam0(V self, V *args);
Clo g_heff_2eerase_2eeraseOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eeraseOne_entry, 3, 0};

V g_heff_2eerase_2eeraseOne(V v_g_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2eerase_2eisType(MK_INT(0LL), heff_get(heff_dup(v_e_244), LBL_type_5f)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_g_240);
      heff_drop(v_key_243);
      heff_drop(v_e_244);
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      return v_acc_241;
    }
    case TAG_False: {
      V v_t_246 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){heff_dup(v_key_243)})});
      V v_t_247 = heff_rec(2, shape_146_351, (V[]){v_t_246, heff_get(heff_dup(v_e_244), LBL_type_5f)});
      V v_t_248 = heff_tag_at(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo(g_heff_2eerase_2eeraseOne_lam0, 1, 1, (V[]){heff_dup(v_e_244)})});
      V v_t_2411 = (g_heff_2eerase_2echkDF_24s534(heff_rec(4, shape_179_87_168_115, (V[]){v_t_248, v_t_2410, MK_INT(1LL), v_g_240}), heff_get(heff_dup(v_e_244), LBL_syntax), heff_get(heff_dup(v_e_244), LBL_type_5f), heff_get(v_e_244, LBL_value)));
      V v_it_2412 = heff_tr(heff_apply(v_t_2411, 1, (V[]){heff_get(heff_dup(v_acc_241), LBL_supply)}));
      switch (heff_tag_of(v_it_2412)) {
      case TAG_Left: {
        V v_err_2413 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        V v_t_2414 = heff_strAppend(v_key_243, heff_strAppend(((V)&g_heff_2eerase_2eeraseOne_str0), v_err_2413));
        V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, heff_get(heff_dup(v_acc_241), LBL_errors)});
        return heff_rec(3, shape_59_89_328, (V[]){heff_get(heff_dup(v_acc_241), LBL_defs), v_t_2415, heff_get(v_acc_241, LBL_supply)});
      }
      case TAG_Right: {
        V v_it1_2416 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        switch (heff_tag_of(v_it1_2416)) {
        case TAG_MkPair: {
          V v_body_2417 = heff_field(v_it1_2416, 0);
          V v_n_2418 = heff_field(v_it1_2416, 1);
          V v_ru_24it1_2416_24MkPair = heff_take_reuse_n(v_it1_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at(v_ru_24it1_2416_24MkPair, TAG_Cons, 2, (V[]){heff_rec(3, shape_152_198_28, (V[]){heff_dup(v_key_243), v_key_243, v_body_2417}), heff_get(heff_dup(v_acc_241), LBL_defs)});
          return heff_rec(3, shape_59_89_328, (V[]){v_t_2419, heff_get(v_acc_241, LBL_errors), v_n_2418});
        }
        default: return heff_nomatch(v_it1_2416);
        }
      }
      default: return heff_nomatch(v_it_2412);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eerase_2eeraseOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eeraseOne(a[0], a[1], a[2]);
}
V g_heff_2eerase_2eeraseOne_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return heff_get(v_e_244, LBL_value);
}
V g_heff_2eerase_2eeraseProgram_lam0(V self, V *args);
V g_heff_2eerase_2eeraseProgram_lam1(V self, V *args);
Clo g_heff_2eerase_2eeraseProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eeraseProgram_entry, 1, 0};

V g_heff_2eerase_2eeraseProgram(V v_g_240) {
top: ;
  V v_t_241 = heff_rec(3, shape_59_89_328, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_246 = ({ V a_0 = heff_clo(g_heff_2eerase_2eeraseProgram_lam0, 2, 1, (V[]){heff_dup(v_g_240)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get(heff_dup(v_g_240), LBL_order); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_acc_249 = ({ V a_0 = heff_clo(g_heff_2eerase_2eeraseProgram_lam1, 2, 1, (V[]){v_g_240}); V a_1 = v_t_241; V a_2 = v_t_246; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2410 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_249), LBL_defs)));
  V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_249), LBL_errors)));
  return heff_rec(3, shape_59_89_328, (V[]){v_t_2410, v_t_2411, heff_get(v_acc_249, LBL_supply)});
}
V g_heff_2eerase_2eeraseProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eeraseProgram(a[0]);
}
V g_heff_2eerase_2eeraseProgram_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get(v_g_240, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eerase_2eeraseProgram_lam1(V self, V *args) {
  V v_acc_247 = args[0];
  V v_p_248 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eerase_2eeraseOne(v_g_240, v_acc_247, v_p_248));
}