// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_HLocal 25864
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkArm 55352
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define TAG_VFixed 12623
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimString 23215
#define LBL_body 9524841
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_supply 1056026650
#define LBL_syntax 1059664654
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_vars 10107635
#define LBL_vs 10532
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
static uint32_t shape_vs__out[] = {LBL_vs, LBL_out};
V g_array_2eempty_get(void);
V g_heff_2edict_2ezipKV(V, V);
V g_heff_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2edict_2ezipKV_clo;
V g_heff_2eerase_2eargTysOf(V, V);
V g_heff_2eerase_2eargTysOf_entry(V self, V *a);
extern Clo g_heff_2eerase_2eargTysOf_clo;
V g_heff_2eerase_2earmBindGo(V, V);
V g_heff_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2eerase_2earmBindGo_clo;
V g_heff_2eerase_2earmOf_24s627775745x609415035(V, V, V, V);
V g_heff_2eerase_2earmOf_24s627775745x609415035_entry(V self, V *a);
extern Clo g_heff_2eerase_2earmOf_24s627775745x609415035_clo;
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579(V, V, V);
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_entry(V self, V *a);
extern Clo g_heff_2eerase_2earmsTy_24s1202361547x1799531579_clo;
V g_heff_2eerase_2ecatMaybesE(V);
V g_heff_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2eerase_2ecatMaybesE_clo;
V g_heff_2eerase_2echkDF_24s1365578804x1792227807(V, V, V, V);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkDF_24s1365578804x1792227807_clo;
V g_heff_2eerase_2echkDField_24s1687259509x1664563092(V, V, V, V, V);
V g_heff_2eerase_2echkDField_24s1687259509x1664563092_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkDField_24s1687259509x1664563092_clo;
V g_heff_2eerase_2echkDFields_24s67152714x898921336(V, V, V, V, V);
V g_heff_2eerase_2echkDFields_24s67152714x898921336_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkDFields_24s67152714x898921336_clo;
V g_heff_2eerase_2echkF_24s2078926067x1185053013(V, V, V);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_clo;
V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788(V, V, V, V, V);
V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_clo;
V g_heff_2eerase_2echkLam_24s2015454573x196455732(V, V, V);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_clo;
V g_heff_2eerase_2echkTagArg_24s761456356x1112072901(V, V);
V g_heff_2eerase_2echkTagArg_24s761456356x1112072901_entry(V self, V *a);
extern Clo g_heff_2eerase_2echkTagArg_24s761456356x1112072901_clo;
V g_heff_2eerase_2eeraseOne(V, V, V);
V g_heff_2eerase_2eeraseOne_entry(V self, V *a);
extern Clo g_heff_2eerase_2eeraseOne_clo;
V g_heff_2eerase_2eeraseProgram(V);
V g_heff_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2eerase_2eeraseProgram_clo;
V g_heff_2eerase_2eextend(V, V, V);
V g_heff_2eerase_2eextend_entry(V self, V *a);
extern Clo g_heff_2eerase_2eextend_clo;
V g_heff_2eerase_2eisType(V, V);
V g_heff_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2eerase_2eisType_clo;
V g_heff_2eerase_2ematchVariants(V);
V g_heff_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2eerase_2ematchVariants_clo;
V g_heff_2eerase_2enthLocal(V, V);
V g_heff_2eerase_2enthLocal_entry(V self, V *a);
extern Clo g_heff_2eerase_2enthLocal_clo;
V g_heff_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2eerase_2eprojTyInWith_clo;
V g_heff_2eerase_2eprojWith(V, V, V);
V g_heff_2eerase_2eprojWith_entry(V self, V *a);
extern Clo g_heff_2eerase_2eprojWith_clo;
V g_heff_2eerase_2esynF_24s1264824444x261991683(V, V);
V g_heff_2eerase_2esynF_24s1264824444x261991683_entry(V self, V *a);
extern Clo g_heff_2eerase_2esynF_24s1264824444x261991683_clo;
V g_heff_2eerase_2etraverseM(V, V);
V g_heff_2eerase_2etraverseM_entry(V self, V *a);
extern Clo g_heff_2eerase_2etraverseM_clo;
V g_heff_2eerase_2ezipE(V, V);
V g_heff_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2eerase_2ezipE_clo;
V g_heff_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTermF_clo;
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(V, V, V, V);
V g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_entry(V self, V *a);
extern Clo g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000_clo;
V g_heff_2eeval_2eevaluator_get(void);
V g_heff_2eglobals_2elookupEntry(V, V);
V g_heff_2eglobals_2elookupEntry_entry(V self, V *a);
extern Clo g_heff_2eglobals_2elookupEntry_clo;
V g_heff_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2erules_2efieldTyAt_clo;
V g_heff_2evalue_2eapp(V, V);
V g_heff_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2evalue_2eapp_clo;
V g_heff_2evalue_2ebehavior(V);
V g_heff_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2evalue_2ebehavior_clo;
V g_heff_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694(V, V, V, V);
V g_heff_2evalue_2emkNeu_24s1912479565x1511825694_entry(V self, V *a);
extern Clo g_heff_2evalue_2emkNeu_24s1912479565x1511825694_clo;
V g_heff_2evalue_2eproj(V, V);
V g_heff_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2evalue_2eproj_clo;
V g_heff_2evalue_2eprojTyWith(V, V, V);
V g_heff_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2evalue_2eprojTyWith_clo;
V g_heff_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2evalue_2etypeForProjection_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2emap_24s751962069x1815060025(V);
V g_prelude_2emap_24s751962069x1815060025_entry(V self, V *a);
extern Clo g_prelude_2emap_24s751962069x1815060025_clo;
V g_heff_2eerase_2eextend_lam0(V self, V *args);
V g_heff_2eerase_2eextend_lam1(V self, V *args);
Clo g_heff_2eerase_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eextend_entry, 3, 0};

V g_heff_2eerase_2eextend(V v_c_240, V v_ir_241, V v_ty_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_ir__ty, (V[]){v_ir_241, heff_dup(v_ty_242)}), heff_get(heff_dup(v_c_240), LBL_locals)});
  V v_t_244 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
  V v_v_246 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_244, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2eextend_lam0, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_t_248 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2eextend_lam1, 1, 1, (V[]){v_v_246})});
  V v_t_249 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
  return heff_rec(4, shape_locals__env__len__globals, (V[]){v_t_243, v_t_248, v_t_249, heff_get(v_c_240, LBL_globals)});
}
V g_heff_2eerase_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eextend(a[0], a[1], a[2]);
}
V g_heff_2eerase_2eextend_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_245);
  return v_ty_242;
}
V g_heff_2eerase_2eextend_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_246;
}
V g_heff_2eerase_2eisType_lam1(V self, V *args);
V g_heff_2eerase_2eisType_lam0(V self, V *args);
Clo g_heff_2eerase_2eisType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eisType_entry, 2, 0};

V g_heff_2eerase_2eisType(V v_lvl_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2evalue_2ebehavior(v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_True);
  }
  case TAG_LikeFunction: {
    V v_dom_245 = heff_field(v_t_242, 1);
    V v_cod_246 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 6ULL, 4);
    V v_x1_2414;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkClo: {
      V v_vs_249 = heff_field(v_cod_246, 1);
      V v_body_2410 = heff_field(v_cod_246, 2);
      heff_take_n(v_cod_246, 6ULL, 3);
      v_x1_2414 = heff_tr(heff_apply(v_body_2410, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo(g_heff_2eerase_2eisType_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_245})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2413 = heff_field(v_cod_246, 0);
      heff_take_n(v_cod_246, 1ULL, 1);
      heff_drop(v_dom_245);
      v_x1_2414 = v_body_2413;
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nom: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2415;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      v_t_2418 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2417 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V t_0 = heff_intAdd(v_lvl_240, MK_INT(1LL));
    V t_1 = v_t_2418;
    v_lvl_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eerase_2eisType_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eisType(a[0], a[1]);
}
V g_heff_2eerase_2eisType_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_245;
}
V g_heff_2eerase_2eisType_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(heff_tag(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2eisType_lam1, 1, 1, (V[]){v_dom_245}), NTAG(TAG_Nothing)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str0 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str1 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eerase_2eprojTyInWith_str2 = {{0x80000000u, K_STR, 0}, 14, 14, {116, 104, 101, 32, 116, 121, 112, 101, 32, 111, 102, 32, 96, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2eprojTyInWith_str3 = {{0x80000000u, K_STR, 0}, 36, 36, {96, 32, 100, 101, 112, 101, 110, 100, 115, 32, 111, 110, 32, 102, 105, 101, 108, 100, 115, 32, 110, 111, 116, 32, 105, 110, 32, 104, 97, 110, 100, 32, 104, 101, 114, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str4 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str5 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str6 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str7 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str8 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str9 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_heff_2eerase_2eprojTyInWith_str10 = {{0x80000000u, K_STR, 0}, 54, 54, {112, 114, 111, 106, 101, 99, 116, 105, 110, 103, 32, 102, 114, 111, 109, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2eprojTyInWith_lam0(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam0, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam1(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam1, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam2(V self, V *args);
V g_heff_2eerase_2eprojTyInWith_lam3(V self, V *args);
V g_heff_2eerase_2eprojTyInWith_lam4(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam4, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam5(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam5, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam6(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam6, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam7(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam7, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam8(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam8, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam9(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam9, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam10(V self, V *args); static Clo g_heff_2eerase_2eprojTyInWith_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_lam10, 1, 0};
V g_heff_2eerase_2eprojTyInWith_lam11(V self, V *args);
Clo g_heff_2eerase_2eprojTyInWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojTyInWith_entry, 4, 0};

V g_heff_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243) {
top: ;
  V v_t_244 = (g_heff_2evalue_2eprojTyWith(heff_dup(v_t_241), v_fs_242, heff_dup(v_l_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_LikeU: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam0_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_245, 0ULL, 4);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam1_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2414 = heff_field(v_t_245, 1);
      V v_fieldTypes_2415 = heff_field(v_t_245, 2);
      heff_take_n(v_t_245, 6ULL, 3);
      V v_t_2416 = ({ V a_0 = heff_dup(v_l_243); V b_1 = heff_get(heff_dup(v_fieldTypes_2415), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2418;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        v_t_2418 = heff_abandon();
        break;
      }
      case TAG_Just: {
        V v_i_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        v_t_2418 = v_i_2417;
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_t_2419 = (g_heff_2erules_2efieldTyAt(v_len_240, v_capture_2414, v_fieldTypes_2415, v_t_2418, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        return heff_clo(g_heff_2eerase_2eprojTyInWith_lam2, 1, 1, (V[]){v_l_243});
      }
      case TAG_Just: {
        V v_ty_2422 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        heff_drop(v_l_243);
        return heff_clo(g_heff_2eerase_2eprojTyInWith_lam3, 1, 1, (V[]){v_ty_2422});
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam4_clo);
    }
    case TAG_LikeInt: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam5_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam6_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam7_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam8_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam9_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2eerase_2eprojTyInWith_lam10_clo);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    V v_ty_2434 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_len_240);
    heff_drop(v_t_241);
    heff_drop(v_l_243);
    return heff_clo(g_heff_2eerase_2eprojTyInWith_lam11, 1, 1, (V[]){v_ty_2434});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eerase_2eprojTyInWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eprojTyInWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2eerase_2eprojTyInWith_lam0(V self, V *args) {
  V v_n_247 = args[0];
  heff_drop(v_n_247);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str0)});
}
V g_heff_2eerase_2eprojTyInWith_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str1)});
}
V g_heff_2eerase_2eprojTyInWith_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_l_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2420);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eerase_2eprojTyInWith_str2), heff_strAppend(v_l_243, ((V)&g_heff_2eerase_2eprojTyInWith_str3)));
  return heff_tag(TAG_Left, 1, (V[]){v_t_2421});
}
V g_heff_2eerase_2eprojTyInWith_lam3(V self, V *args) {
  V v_n_2423 = args[0];
  V v_ty_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_ty_2422, v_n_2423})});
}
V g_heff_2eerase_2eprojTyInWith_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  heff_drop(v_n_2425);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str4)});
}
V g_heff_2eerase_2eprojTyInWith_lam5(V self, V *args) {
  V v_n_2426 = args[0];
  heff_drop(v_n_2426);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str5)});
}
V g_heff_2eerase_2eprojTyInWith_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  heff_drop(v_n_2427);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str6)});
}
V g_heff_2eerase_2eprojTyInWith_lam7(V self, V *args) {
  V v_n_2428 = args[0];
  heff_drop(v_n_2428);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str7)});
}
V g_heff_2eerase_2eprojTyInWith_lam8(V self, V *args) {
  V v_n_2430 = args[0];
  heff_drop(v_n_2430);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str8)});
}
V g_heff_2eerase_2eprojTyInWith_lam9(V self, V *args) {
  V v_n_2432 = args[0];
  heff_drop(v_n_2432);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str9)});
}
V g_heff_2eerase_2eprojTyInWith_lam10(V self, V *args) {
  V v_n_2433 = args[0];
  heff_drop(v_n_2433);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2eprojTyInWith_str10)});
}
V g_heff_2eerase_2eprojTyInWith_lam11(V self, V *args) {
  V v_n_2435 = args[0];
  V v_ty_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_ty_2434, v_n_2435})});
}
Clo g_heff_2eerase_2eprojWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eprojWith_entry, 3, 0};

V g_heff_2eerase_2eprojWith(V v_x1_240, V v_v_241, V v_l_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return (g_heff_2evalue_2eproj(v_v_241, v_l_242));
  }
  case TAG_Just: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    heff_drop(v_v_241);
    V v_t_244 = ({ V a_0 = v_l_242; V b_1 = heff_get(heff_dup(v_fs_243), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_xs_246 = heff_get(heff_dup(v_fs_243), LBL_values);
      V v_t_247 = heff_intLe(MK_INT(0LL), heff_dup(v_i_245));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_t_248 = heff_intLt(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          return v_v_249;
        }
        case TAG_False: {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      case TAG_False: {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        return heff_abandon();
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2eprojWith_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eerase_2eprojWith(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str0 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str1 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str2 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str3 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str4 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str5 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str6 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str7 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eerase_2ematchVariants_str8 = {{0x80000000u, K_STR, 0}, 47, 47, {109, 97, 116, 99, 104, 105, 110, 103, 32, 111, 110, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 111, 102, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2ematchVariants_lam0(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam0, 1, 0};
V g_heff_2eerase_2ematchVariants_lam1(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam1, 1, 0};
V g_heff_2eerase_2ematchVariants_lam2(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam2, 1, 0};
V g_heff_2eerase_2ematchVariants_lam3(V self, V *args);
V g_heff_2eerase_2ematchVariants_lam4(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam4, 1, 0};
V g_heff_2eerase_2ematchVariants_lam5(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam5, 1, 0};
V g_heff_2eerase_2ematchVariants_lam6(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam6, 1, 0};
V g_heff_2eerase_2ematchVariants_lam7(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam7, 1, 0};
V g_heff_2eerase_2ematchVariants_lam8(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam8, 1, 0};
V g_heff_2eerase_2ematchVariants_lam9(V self, V *args); static Clo g_heff_2eerase_2ematchVariants_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_lam9, 1, 0};
Clo g_heff_2eerase_2ematchVariants_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ematchVariants_entry, 1, 0};

V g_heff_2eerase_2ematchVariants(V v_sty_240) {
top: ;
  V v_t_241 = (g_heff_2evalue_2ebehavior(v_sty_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_LikeU: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2eerase_2ematchVariants_lam0_clo);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_241, 0ULL, 4);
    return ((V)&g_heff_2eerase_2ematchVariants_lam1_clo);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_241, 0ULL, 3);
    return ((V)&g_heff_2eerase_2ematchVariants_lam2_clo);
  }
  case TAG_LikeSum: {
    V v_vs_2413 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    return heff_clo(g_heff_2eerase_2ematchVariants_lam3, 1, 1, (V[]){v_vs_2413});
  }
  case TAG_LikeInt: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam4_clo);
  }
  case TAG_LikeFloat: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam5_clo);
  }
  case TAG_LikeString: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam6_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2eerase_2ematchVariants_lam7_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2eerase_2ematchVariants_lam8_clo);
  }
  case TAG_NoRules: {
    return ((V)&g_heff_2eerase_2ematchVariants_lam9_clo);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2ematchVariants_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2ematchVariants(a[0]);
}
V g_heff_2eerase_2ematchVariants_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str0)});
}
V g_heff_2eerase_2ematchVariants_lam1(V self, V *args) {
  V v_n_248 = args[0];
  heff_drop(v_n_248);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str1)});
}
V g_heff_2eerase_2ematchVariants_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str2)});
}
V g_heff_2eerase_2ematchVariants_lam3(V self, V *args) {
  V v_n_2414 = args[0];
  V v_vs_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_vs_2413, v_n_2414})});
}
V g_heff_2eerase_2ematchVariants_lam4(V self, V *args) {
  V v_n_2415 = args[0];
  heff_drop(v_n_2415);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str3)});
}
V g_heff_2eerase_2ematchVariants_lam5(V self, V *args) {
  V v_n_2416 = args[0];
  heff_drop(v_n_2416);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str4)});
}
V g_heff_2eerase_2ematchVariants_lam6(V self, V *args) {
  V v_n_2417 = args[0];
  heff_drop(v_n_2417);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str5)});
}
V g_heff_2eerase_2ematchVariants_lam7(V self, V *args) {
  V v_n_2419 = args[0];
  heff_drop(v_n_2419);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str6)});
}
V g_heff_2eerase_2ematchVariants_lam8(V self, V *args) {
  V v_n_2421 = args[0];
  heff_drop(v_n_2421);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str7)});
}
V g_heff_2eerase_2ematchVariants_lam9(V self, V *args) {
  V v_n_2422 = args[0];
  heff_drop(v_n_2422);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2ematchVariants_str8)});
}
Clo g_heff_2eerase_2eargTysOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eargTysOf_entry, 2, 0};

V g_heff_2eerase_2eargTysOf(V v_vs_240, V v_tag_241) {
top: ;
  V v_t_242 = ({ V a_0 = v_tag_241; V b_1 = heff_get(heff_dup(v_vs_240), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_vs_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_i_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_xs_244 = heff_get(v_vs_240, LBL_values);
    V v_t_245 = heff_intLe(MK_INT(0LL), heff_dup(v_i_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = heff_intLt(heff_dup(v_i_243), heff_arrayLength(heff_dup(v_xs_244)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        V v_ts_247 = heff_arrayIndex(v_xs_244, v_i_243);
        return (g_prelude_2emap_24s751962069x1815060025(heff_arrayToList(v_ts_247)));
      }
      case TAG_False: {
        heff_drop(v_i_243);
        heff_drop(v_xs_244);
        return NTAG(TAG_Nil);
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_False: {
      heff_drop(v_i_243);
      heff_drop(v_xs_244);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eerase_2eargTysOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eargTysOf(a[0], a[1]);
}
Clo g_heff_2eerase_2ezipE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ezipE_entry, 2, 0};

V g_heff_2eerase_2ezipE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eerase_2ezipE(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2ezipE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2ezipE(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2earmBindGo_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
V g_heff_2eerase_2earmBindGo_lam0(V self, V *args);
V g_heff_2eerase_2earmBindGo_lam1(V self, V *args);
Clo g_heff_2eerase_2earmBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmBindGo_entry, 2, 0};

V g_heff_2eerase_2earmBindGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_240), LBL_vars)));
    V v_x_243 = heff_rec(2, shape_c__vars, (V[]){heff_get(v_acc_240, LBL_c), v_t_242});
    return heff_clo(g_heff_2eerase_2earmBindGo_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x21_245, 0);
      V v_aty_248 = heff_field(v_x21_245, 1);
      heff_take_n(v_x21_245, 3ULL, 2);
      V v_t_249 = heff_get(heff_get(heff_dup(v_acc_240), LBL_c), LBL_len);
      V v_t_2410 = (g_heff_2eerase_2eisType(v_t_249, heff_dup(v_aty_248)));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_x_247);
        V v_t_2411 = (g_heff_2eerase_2eextend(heff_get(heff_dup(v_acc_240), LBL_c), NTAG(TAG_Nothing), v_aty_248));
        V v_t_2412 = heff_rec(2, shape_c__vars, (V[]){v_t_2411, heff_get(v_acc_240, LBL_vars)});
        V t_0 = v_t_2412;
        V t_1 = v_rest_246;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_clo(g_heff_2eerase_2earmBindGo_lam1, 1, 4, (V[]){v_x_247, v_acc_240, v_aty_248, v_rest_246});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eerase_2earmBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2earmBindGo(a[0], a[1]);
}
V g_heff_2eerase_2earmBindGo_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_243, v_n_244})});
}
V g_heff_2eerase_2earmBindGo_lam1(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_aty_248 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_strEq(heff_dup(v_x_247), ((V)&g_heff_2eerase_2earmBindGo_str0));
  V v_base_2416;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop(v_x_247);
    v_base_2416 = ((V)&g_heff_2eerase_2earmBindGo_str1);
    break;
  }
  case TAG_False: {
    V v_t_2415 = heff_strEq(heff_dup(v_x_247), ((V)&g_heff_2eerase_2earmBindGo_str2));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      heff_drop(v_x_247);
      v_base_2416 = ((V)&g_heff_2eerase_2earmBindGo_str3);
      break;
    }
    case TAG_False: {
      v_base_2416 = v_x_247;
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2417 = heff_strAppend(v_base_2416, heff_strAppend(((V)&g_heff_2eerase_2earmBindGo_str4), heff_intShow(heff_dup(v_n_2413))));
  V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2417, heff_intAdd(v_n_2413, MK_INT(1LL))});
  V v_x2_2419 = heff_tag(TAG_Right, 1, (V[]){v_t_2418});
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Left: {
    V v_e_2420 = heff_field(v_x2_2419, 0);
    V v_ru_24x2_2419_24Left = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
    heff_drop(v_acc_240);
    heff_drop(v_aty_248);
    heff_drop(v_rest_246);
    return heff_tag_at(v_ru_24x2_2419_24Left, TAG_Left, 1, (V[]){v_e_2420});
  }
  case TAG_Right: {
    V v_x21_2421 = heff_field(v_x2_2419, 0);
    V v_ru_24x2_2419_24Right = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x21_2421, 0);
      V v_n_2423 = heff_field(v_x21_2421, 1);
      V v_ru_24x21_2421_24MkPair = heff_take_reuse_n(v_x21_2421, 3ULL, 2);
      V v_t_2424 = heff_tag_at(v_ru_24x2_2419_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2422)})});
      V v_t_2425 = (g_heff_2eerase_2eextend(heff_get(heff_dup(v_acc_240), LBL_c), v_t_2424, v_aty_248));
      V v_t_2426 = heff_tag_at(v_ru_24x21_2421_24MkPair, TAG_Cons, 2, (V[]){v_x_2422, heff_get(v_acc_240, LBL_vars)});
      V v_t_2427 = (g_heff_2eerase_2earmBindGo(heff_rec(2, shape_c__vars, (V[]){v_t_2425, v_t_2426}), v_rest_246));
      V f_ = v_t_2427;
      args[0] = v_n_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
Clo g_heff_2eerase_2enthLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2enthLocal_entry, 2, 0};

V g_heff_2eerase_2enthLocal(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_l_242)});
    }
    case TAG_False: {
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2enthLocal_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eerase_2enthLocal(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eerase_2etraverseM_lam0(V self, V *args); static Clo g_heff_2eerase_2etraverseM_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2etraverseM_lam0, 1, 0};
V g_heff_2eerase_2etraverseM_lam1(V self, V *args);
Clo g_heff_2eerase_2etraverseM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2etraverseM_entry, 2, 0};

V g_heff_2eerase_2etraverseM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eerase_2etraverseM_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo(g_heff_2eerase_2etraverseM_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eerase_2etraverseM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2etraverseM(a[0], a[1]);
}
V g_heff_2eerase_2etraverseM_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
  return heff_tag(TAG_Right, 1, (V[]){v_t_243});
}
V g_heff_2eerase_2etraverseM_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_xs_245);
    return heff_tag_at(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_m_2413 = (g_heff_2eerase_2etraverseM(v_f_240, v_xs_245));
      V v_x2_2414 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_n_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24x21_2410_24MkPair, 2);
        return heff_tag_at(v_ru_24x2_248_24Right, TAG_Left, 1, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x21_2416 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        switch (heff_tag_of(v_x21_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x21_2416, 0);
          V v_n_2418 = heff_field(v_x21_2416, 1);
          heff_take_n(v_x21_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417}), v_n_2418});
          return heff_tag_at(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_x21_2416);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2eerase_2ecatMaybesE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2ecatMaybesE_entry, 1, 0};

V g_heff_2eerase_2ecatMaybesE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eerase_2ecatMaybesE(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eerase_2ecatMaybesE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2ecatMaybesE(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2earmsTy_24s1202361547x1799531579_str0 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam0(V self, V *args); static Clo g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam0, 1, 0};
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam2(V self, V *args);
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam1(V self, V *args);
Clo g_heff_2eerase_2earmsTy_24s1202361547x1799531579_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmsTy_24s1202361547x1799531579_entry, 3, 0};

V g_heff_2eerase_2earmsTy_24s1202361547x1799531579(V v_c_240, V v_vs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    return ((V)&g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_tail_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_tag_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_MkPair: {
        V v_xs_248 = heff_field(v_x412_247, 0);
        V v_body_249 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        V v_t_2410 = heff_rec(2, shape_c__vars, (V[]){heff_dup(v_c_240), NTAG(TAG_Nil)});
        V v_t_2411 = (g_heff_2eerase_2eargTysOf(heff_dup(v_vs_241), v_tag_246));
        V v_t_2412 = (g_heff_2eerase_2ezipE(heff_arrayToList(v_xs_248), v_t_2411));
        V v_m_2413 = (g_heff_2eerase_2earmBindGo(v_t_2410, v_t_2412));
        return heff_clo(g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam1, 1, 5, (V[]){v_m_2413, v_body_249, v_c_240, v_vs_241, v_tail_245});
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2earmsTy_24s1202361547x1799531579(a[0], a[1], a[2]);
}
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2earmsTy_24s1202361547x1799531579_str0)});
}
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2422 = heff_tr(heff_apply(v_m_2420, 1, (V[]){heff_dup(v_n_2421)}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_Left: {
    V v_ru_24x2_2422_24Left = heff_take_reuse_n(v_x2_2422, 0ULL, 1);
    V v_t_2424 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2421});
    return heff_tag_at(v_ru_24x2_2422_24Left, TAG_Right, 1, (V[]){v_t_2424});
  }
  case TAG_Right: {
    V v_x21_2425 = heff_field(v_x2_2422, 0);
    V v_ru_24x2_2422_24Right = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
    heff_drop(v_n_2421);
    switch (heff_tag_of(v_x21_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x21_2425, 0);
      V v_n_27_2427 = heff_field(v_x21_2425, 1);
      V v_ru_24x21_2425_24MkPair = heff_take_reuse_n(v_x21_2425, 3ULL, 2);
      V v_t_2428 = heff_tag_at(v_ru_24x21_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x2_2422_24Right, TAG_Just, 1, (V[]){v_x_2426}), v_n_27_2427});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2428});
    }
    default: return heff_nomatch(v_x21_2425);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_body_249 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_tail_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Left: {
    V v_e_2416 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Left = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    heff_drop(v_body_249);
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    heff_drop(v_tail_245);
    return heff_tag_at(v_ru_24x2_2415_24Left, TAG_Left, 1, (V[]){v_e_2416});
  }
  case TAG_Right: {
    V v_x21_2417 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Right = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x21_2417, 0);
      V v_n_2419 = heff_field(v_x21_2417, 1);
      heff_take_n(v_x21_2417, 3ULL, 2);
      V v_m_2420 = (g_heff_2eerase_2esynF_24s1264824444x261991683(heff_get(v_x_2418, LBL_c), v_body_249));
      V v_m_2429 = heff_clo(g_heff_2eerase_2earmsTy_24s1202361547x1799531579_lam2, 1, 1, (V[]){v_m_2420});
      V v_x2_2430 = heff_tr(heff_apply(v_m_2429, 1, (V[]){v_n_2419}));
      switch (heff_tag_of(v_x2_2430)) {
      case TAG_Left: {
        V v_e_2431 = heff_field(v_x2_2430, 0);
        heff_take_n(v_x2_2430, 1ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_vs_241);
        heff_drop(v_tail_245);
        return heff_tag_at(v_ru_24x2_2415_24Right, TAG_Left, 1, (V[]){v_e_2431});
      }
      case TAG_Right: {
        V v_x21_2432 = heff_field(v_x2_2430, 0);
        heff_take_n(v_x2_2430, 1ULL, 1);
        switch (heff_tag_of(v_x21_2432)) {
        case TAG_MkPair: {
          V v_x_2433 = heff_field(v_x21_2432, 0);
          V v_n_2434 = heff_field(v_x21_2432, 1);
          heff_take_n(v_x21_2432, 3ULL, 2);
          switch (heff_tag_of(v_x_2433)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_2415_24Right, 1);
            V v_t_2435 = (g_heff_2eerase_2earmsTy_24s1202361547x1799531579(v_c_240, v_vs_241, v_tail_245));
            V f_ = v_t_2435;
            args[0] = v_n_2434;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
          case TAG_Just: {
            V v_it1_2436 = heff_field(v_x_2433, 0);
            heff_take_n(v_x_2433, 1ULL, 1);
            heff_drop(v_c_240);
            heff_drop(v_vs_241);
            heff_drop(v_tail_245);
            switch (heff_tag_of(v_it1_2436)) {
            case TAG_MkPair: {
              V v_ty_2438 = heff_field(v_it1_2436, 1);
              heff_take_n(v_it1_2436, 2ULL, 2);
              return heff_tag_at(v_ru_24x2_2415_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_ty_2438, v_n_2434})});
            }
            default: return heff_nomatch(v_it1_2436);
            }
          }
          default: return heff_nomatch(v_x_2433);
          }
        }
        default: return heff_nomatch(v_x21_2432);
        }
      }
      default: return heff_nomatch(v_x2_2430);
      }
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2eerase_2earmOf_24s627775745x609415035_lam0(V self, V *args);
Clo g_heff_2eerase_2earmOf_24s627775745x609415035_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2earmOf_24s627775745x609415035_entry, 4, 0};

V g_heff_2eerase_2earmOf_24s627775745x609415035(V v_c_240, V v_vs_241, V v_ty_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_tag_244 = heff_field(v_x5_243, 0);
    V v_x52_245 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    switch (heff_tag_of(v_x52_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_x52_245, 0);
      V v_body_247 = heff_field(v_x52_245, 1);
      heff_take_n(v_x52_245, 3ULL, 2);
      V v_t_248 = heff_rec(2, shape_c__vars, (V[]){v_c_240, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2eerase_2eargTysOf(v_vs_241, heff_dup(v_tag_244)));
      V v_t_2410 = (g_heff_2eerase_2ezipE(heff_arrayToList(v_xs_246), v_t_249));
      V v_m_2411 = (g_heff_2eerase_2earmBindGo(v_t_248, v_t_2410));
      return heff_clo(g_heff_2eerase_2earmOf_24s627775745x609415035_lam0, 1, 4, (V[]){v_m_2411, v_body_247, v_ty_242, v_tag_244});
    }
    default: return heff_nomatch(v_x52_245);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eerase_2earmOf_24s627775745x609415035_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2earmOf_24s627775745x609415035(a[0], a[1], a[2], a[3]);
}
V g_heff_2eerase_2earmOf_24s627775745x609415035_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_body_247 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_tag_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Left: {
    V v_e_2414 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Left = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    heff_drop(v_body_247);
    heff_drop(v_ty_242);
    heff_drop(v_tag_244);
    return heff_tag_at(v_ru_24x2_2413_24Left, TAG_Left, 1, (V[]){v_e_2414});
  }
  case TAG_Right: {
    V v_x21_2415 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Right = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    switch (heff_tag_of(v_x21_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x21_2415, 0);
      V v_n_2417 = heff_field(v_x21_2415, 1);
      heff_take_n(v_x21_2415, 3ULL, 2);
      V v_m_2418 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(heff_get(heff_dup(v_x_2416), LBL_c), v_body_247, v_ty_242));
      V v_x2_2419 = heff_tr(heff_apply(v_m_2418, 1, (V[]){v_n_2417}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Left: {
        V v_e_2420 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        heff_drop(v_tag_244);
        heff_drop(v_x_2416);
        return heff_tag_at(v_ru_24x2_2413_24Right, TAG_Left, 1, (V[]){v_e_2420});
      }
      case TAG_Right: {
        V v_x21_2421 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        switch (heff_tag_of(v_x21_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x21_2421, 0);
          V v_n_2423 = heff_field(v_x21_2421, 1);
          heff_take_n(v_x21_2421, 3ULL, 2);
          V v_t_2424 = heff_tag(TAG_MkArm, 3, (V[]){v_tag_244, heff_get(v_x_2416, LBL_vars), v_x_2422});
          return heff_tag_at(v_ru_24x2_2413_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2424, v_n_2423})});
        }
        default: return heff_nomatch(v_x21_2421);
        }
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
    default: return heff_nomatch(v_x21_2415);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str0 = {{0x80000000u, K_STR, 0}, 16, 16, {97, 110, 32, 117, 110, 98, 111, 117, 110, 100, 32, 108, 111, 99, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str1 = {{0x80000000u, K_STR, 0}, 22, 22, {97, 32, 116, 121, 112, 101, 32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 32, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {110, 111, 32, 103, 108, 111, 98, 97, 108, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {116, 104, 101, 32, 116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str4 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 117, 115, 101, 100, 32, 97, 115, 32, 97, 32, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str5 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str6 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str7 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str8 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str9 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str10 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str11 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str12 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str13 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str14 = {{0x80000000u, K_STR, 0}, 41, 41, {97, 112, 112, 108, 121, 105, 110, 103, 32, 115, 111, 109, 101, 116, 104, 105, 110, 103, 32, 116, 104, 97, 116, 32, 105, 115, 32, 110, 111, 116, 32, 97, 32, 102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str15 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str16 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str17 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str18 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str19 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str20 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[27]; } g_heff_2eerase_2esynF_24s1264824444x261991683_str21 = {{0x80000000u, K_STR, 0}, 27, 27, {116, 104, 105, 115, 32, 110, 101, 101, 100, 115, 32, 97, 110, 32, 101, 120, 112, 101, 99, 116, 101, 100, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam0(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam0, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam1(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam1, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam2(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam3(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam4(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam5(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam6(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam6, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam8(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam9(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam7(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam10(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam11(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam11, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam12(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam13(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam13, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam15(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam14(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam16(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam16, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam17(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam17, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam18(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam18, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam19(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam20(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam20, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam21(V self, V *args); static Clo g_heff_2eerase_2esynF_24s1264824444x261991683_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_lam21, 1, 0};
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam22(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam23(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam24(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam25(V self, V *args);
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam26(V self, V *args);
Clo g_heff_2eerase_2esynF_24s1264824444x261991683_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2esynF_24s1264824444x261991683_entry, 2, 0};

V g_heff_2eerase_2esynF_24s1264824444x261991683(V v_c_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_243 = ({ V b_0 = heff_get(v_c_240, LBL_locals); V a_1 = v_i_242; V r_ = (g_heff_2eerase_2enthLocal(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam0_clo);
    }
    case TAG_Just: {
      V v_l_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_get(heff_dup(v_l_245), LBL_ir);
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop(v_l_245);
        return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam1_clo);
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam2, 1, 2, (V[]){v_x_248, v_l_245});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_SGlobal: {
    V v_x_2411 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_2412 = (g_heff_2eglobals_2elookupEntry(heff_get(v_c_240, LBL_globals), heff_dup(v_x_2411)));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam3, 1, 1, (V[]){v_x_2411});
    }
    case TAG_Just: {
      V v_e_2414 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_t_2415 = (g_heff_2eerase_2eisType(MK_INT(0LL), heff_get(heff_dup(v_e_2414), LBL_type_5f)));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_e_2414);
        return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam4, 1, 1, (V[]){v_x_2411});
      }
      case TAG_False: {
        return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam5, 1, 2, (V[]){v_x_2411, v_e_2414});
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam6_clo);
  }
  case TAG_SApp: {
    V v_f_2422 = heff_field(v_t_241, 0);
    V v_a_2423 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_2424 = (g_heff_2eerase_2esynF_24s1264824444x261991683(heff_dup(v_c_240), v_f_2422));
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam7, 1, 3, (V[]){v_m_2424, v_c_240, v_a_2423});
  }
  case TAG_SLam: {
    V v_ty_2483 = heff_field(v_t_241, 0);
    V v_abs_2484 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SLam = heff_take_reuse_n(v_t_241, 3ULL, 2);
    V v_x1_2485 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), heff_dup(v_ty_2483), heff_get(heff_dup(v_c_240), LBL_env)));
    V v_ty_2489;
    switch (heff_tag_of(v_x1_2485)) {
    case TAG_Nom: {
      V v_x_2486 = heff_field(v_x1_2485, 0);
      heff_take_n(v_x1_2485, 1ULL, 1);
      v_ty_2489 = v_x_2486;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2485, 0ULL, 1);
      v_ty_2489 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2488 = heff_field(v_x1_2485, 0);
      heff_take_n(v_x1_2485, 1ULL, 1);
      v_ty_2489 = v_x_2488;
      break;
    }
    default: heff_nomatch(v_x1_2485);
    }
    V v_m_2490 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(heff_dup(v_c_240), heff_tag_at(v_ru_24t_241_24SLam, TAG_SLam, 2, (V[]){heff_dup(v_ty_2483), v_abs_2484}), v_ty_2489));
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam10, 1, 3, (V[]){v_m_2490, v_c_240, v_ty_2483});
  }
  case TAG_SCons: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam11_clo);
  }
  case TAG_SProj: {
    V v_e_24105 = heff_field(v_t_241, 0);
    V v_l_24106 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24107 = (g_heff_2eerase_2esynF_24s1264824444x261991683(heff_dup(v_c_240), heff_dup(v_e_24105)));
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam12, 1, 4, (V[]){v_m_24107, v_c_240, v_e_24105, v_l_24106});
  }
  case TAG_STag: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam13_clo);
  }
  case TAG_SMatch: {
    V v_scrut_24132 = heff_field(v_t_241, 0);
    V v_cases_24133 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24134 = (g_heff_2eerase_2esynF_24s1264824444x261991683(heff_dup(v_c_240), v_scrut_24132));
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam14, 1, 3, (V[]){v_m_24134, v_cases_24133, v_c_240});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam16_clo);
  }
  case TAG_SIs: {
    V v_t2_24173 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24173;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam17_clo);
  }
  case TAG_SAbandon: {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam18_clo);
  }
  case TAG_SRec: {
    V v_t2_24176 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24176;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_ty_24177 = heff_field(v_t_241, 0);
    V v_abs_24178 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SFix = heff_take_reuse_n(v_t_241, 3ULL, 2);
    V v_x1_24179 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), heff_dup(v_ty_24177), heff_get(heff_dup(v_c_240), LBL_env)));
    V v_ty_24183;
    switch (heff_tag_of(v_x1_24179)) {
    case TAG_Nom: {
      V v_x_24180 = heff_field(v_x1_24179, 0);
      heff_take_n(v_x1_24179, 1ULL, 1);
      v_ty_24183 = v_x_24180;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24179, 0ULL, 1);
      v_ty_24183 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24182 = heff_field(v_x1_24179, 0);
      heff_take_n(v_x1_24179, 1ULL, 1);
      v_ty_24183 = v_x_24182;
      break;
    }
    default: heff_nomatch(v_x1_24179);
    }
    V v_m_24184 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(heff_dup(v_c_240), heff_tag_at(v_ru_24t_241_24SFix, TAG_SFix, 2, (V[]){heff_dup(v_ty_24177), v_abs_24178}), v_ty_24183));
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam19, 1, 3, (V[]){v_m_24184, v_c_240, v_ty_24177});
  }
  case TAG_SImplicit: {
    V v_t2_24198 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t2_24198;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam20_clo);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop(v_c_240);
    return ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_lam21_clo);
  }
  case TAG_SLitInt: {
    V v_i_24205 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam22, 1, 1, (V[]){v_i_24205});
  }
  case TAG_SLitFloat: {
    V v_x_24208 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam23, 1, 1, (V[]){v_x_24208});
  }
  case TAG_SLitString: {
    V v_s_24211 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam24, 1, 1, (V[]){v_s_24211});
  }
  case TAG_SLitFixed: {
    V v_w_24214 = heff_field(v_t_241, 0);
    V v_n_24215 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam25, 1, 2, (V[]){v_w_24214, v_n_24215});
  }
  case TAG_SLitFloat32: {
    V v_x_24218 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    return heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam26, 1, 1, (V[]){v_x_24218});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2esynF_24s1264824444x261991683(a[0], a[1]);
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam0(V self, V *args) {
  V v_n_244 = args[0];
  heff_drop(v_n_244);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str0)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam1(V self, V *args) {
  V v_n_247 = args[0];
  heff_drop(v_n_247);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str1)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_l_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){v_x_248, heff_get(v_l_245, LBL_ty)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2410, v_n_249})});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2413);
  return heff_tag(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str2), v_x_2411)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam4(V self, V *args) {
  V v_n_2416 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2416);
  V v_t_2417 = heff_strAppend(((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str3), heff_strAppend(v_x_2411, ((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str4)));
  return heff_tag(TAG_Left, 1, (V[]){v_t_2417});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam5(V self, V *args) {
  V v_n_2418 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_e_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_x_2411}), heff_get(v_e_2414, LBL_type_5f)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2419, v_n_2418})});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam6(V self, V *args) {
  V v_n_2421 = args[0];
  heff_drop(v_n_2421);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str5)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam8(V self, V *args) {
  V v_u_2443 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2443);
  V v_x1_2444 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_a_2423, heff_get(v_c_240, LBL_env)));
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nom: {
    V v_x_2445 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    return v_x_2445;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2444, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2447 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    return v_x_2447;
  }
  default: return heff_nomatch(v_x1_2444);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam9(V self, V *args) {
  V v_u_2465 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2465);
  V v_x1_2466 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_a_2423, heff_get(v_c_240, LBL_env)));
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_Nom: {
    V v_x_2467 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    return v_x_2467;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2466, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2469 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    return v_x_2469;
  }
  default: return heff_nomatch(v_x1_2466);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam7(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_a_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2426 = heff_tr(heff_apply(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Left: {
    V v_e_2427 = heff_field(v_x2_2426, 0);
    V v_ru_24x2_2426_24Left = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_a_2423);
    return heff_tag_at(v_ru_24x2_2426_24Left, TAG_Left, 1, (V[]){v_e_2427});
  }
  case TAG_Right: {
    V v_x21_2428 = heff_field(v_x2_2426, 0);
    V v_ru_24x2_2426_24Right = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
    switch (heff_tag_of(v_x21_2428)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_x21_2428, 0);
      V v_n_2430 = heff_field(v_x21_2428, 1);
      V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
      switch (heff_tag_of(v_x_2429)) {
      case TAG_MkPair: {
        V v_f_27_2431 = heff_field(v_x_2429, 0);
        V v_fty_2432 = heff_field(v_x_2429, 1);
        V v_ru_24x_2429_24MkPair = heff_take_reuse_n(v_x_2429, 3ULL, 2);
        V v_t_2433 = (g_heff_2evalue_2ebehavior(v_fty_2432));
        switch (heff_tag_of(v_t_2433)) {
        case TAG_LikeU: {
          heff_take_n(v_t_2433, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str6)});
        }
        case TAG_LikeFunction: {
          V v_dom_2436 = heff_field(v_t_2433, 1);
          V v_cod_2437 = heff_field(v_t_2433, 2);
          heff_take_n(v_t_2433, 6ULL, 4);
          V v_t_2439 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_dom_2436)));
          switch (heff_tag_of(v_t_2439)) {
          case TAG_True: {
            heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
            heff_drop(v_dom_2436);
            V v_x1_2449;
            switch (heff_tag_of(v_cod_2437)) {
            case TAG_MkClo: {
              V v_vs_2441 = heff_field(v_cod_2437, 1);
              V v_body_2442 = heff_field(v_cod_2437, 2);
              heff_take_n(v_cod_2437, 6ULL, 3);
              v_x1_2449 = heff_tr(heff_apply(v_body_2442, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2441, heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam8, 1, 2, (V[]){v_c_240, v_a_2423})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2448 = heff_field(v_cod_2437, 0);
              heff_take_n(v_cod_2437, 1ULL, 1);
              heff_drop(v_c_240);
              heff_drop(v_a_2423);
              v_x1_2449 = v_body_2448;
              break;
            }
            default: heff_nomatch(v_cod_2437);
            }
            V v_t_2453;
            switch (heff_tag_of(v_x1_2449)) {
            case TAG_Nom: {
              V v_x_2450 = heff_field(v_x1_2449, 0);
              heff_take_n(v_x1_2449, 1ULL, 1);
              v_t_2453 = v_x_2450;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2449, 0ULL, 1);
              v_t_2453 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2452 = heff_field(v_x1_2449, 0);
              heff_take_n(v_x1_2449, 1ULL, 1);
              v_t_2453 = v_x_2452;
              break;
            }
            default: heff_nomatch(v_x1_2449);
            }
            V v_x_2454 = heff_tag_at(v_ru_24x21_2428_24MkPair, TAG_MkPair, 2, (V[]){v_f_27_2431, v_t_2453});
            return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2454, v_n_2430})});
          }
          case TAG_False: {
            V v_m_2455 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(heff_dup(v_c_240), heff_dup(v_a_2423), v_dom_2436));
            V v_x2_2456 = heff_tr(heff_apply(v_m_2455, 1, (V[]){v_n_2430}));
            switch (heff_tag_of(v_x2_2456)) {
            case TAG_Left: {
              V v_e_2457 = heff_field(v_x2_2456, 0);
              heff_take_n(v_x2_2456, 1ULL, 1);
              heff_drop(v_c_240);
              heff_drop(v_a_2423);
              heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
              heff_drop(v_f_27_2431);
              heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
              heff_drop(v_cod_2437);
              return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){v_e_2457});
            }
            case TAG_Right: {
              V v_x21_2458 = heff_field(v_x2_2456, 0);
              heff_take_n(v_x2_2456, 1ULL, 1);
              switch (heff_tag_of(v_x21_2458)) {
              case TAG_MkPair: {
                V v_x_2459 = heff_field(v_x21_2458, 0);
                V v_n_2460 = heff_field(v_x21_2458, 1);
                heff_take_n(v_x21_2458, 3ULL, 2);
                V v_t_2461 = heff_tag_at(v_ru_24x21_2428_24MkPair, TAG_Cons, 2, (V[]){v_x_2459, NTAG(TAG_Nil)});
                V v_x1_2471;
                switch (heff_tag_of(v_cod_2437)) {
                case TAG_MkClo: {
                  V v_vs_2463 = heff_field(v_cod_2437, 1);
                  V v_body_2464 = heff_field(v_cod_2437, 2);
                  heff_take_n(v_cod_2437, 6ULL, 3);
                  v_x1_2471 = heff_tr(heff_apply(v_body_2464, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2463, heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam9, 1, 2, (V[]){v_c_240, v_a_2423})})}));
                  break;
                }
                case TAG_CloConst: {
                  V v_body_2470 = heff_field(v_cod_2437, 0);
                  heff_take_n(v_cod_2437, 1ULL, 1);
                  heff_drop(v_c_240);
                  heff_drop(v_a_2423);
                  v_x1_2471 = v_body_2470;
                  break;
                }
                default: heff_nomatch(v_cod_2437);
                }
                V v_t_2475;
                switch (heff_tag_of(v_x1_2471)) {
                case TAG_Nom: {
                  V v_x_2472 = heff_field(v_x1_2471, 0);
                  heff_take_n(v_x1_2471, 1ULL, 1);
                  v_t_2475 = v_x_2472;
                  break;
                }
                case TAG_Describe: {
                  heff_take_n(v_x1_2471, 0ULL, 1);
                  v_t_2475 = heff_abandon();
                  break;
                }
                case TAG_Become: {
                  V v_x_2474 = heff_field(v_x1_2471, 0);
                  heff_take_n(v_x1_2471, 1ULL, 1);
                  v_t_2475 = v_x_2474;
                  break;
                }
                default: heff_nomatch(v_x1_2471);
                }
                V v_x_2476 = heff_tag_at(v_ru_24x_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_27_2431, v_t_2461}), v_t_2475});
                return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_2476, v_n_2460})});
              }
              default: return heff_nomatch(v_x21_2458);
              }
            }
            default: return heff_nomatch(v_x2_2456);
            }
          }
          default: return heff_nomatch(v_t_2439);
          }
        }
        case TAG_LikeRecord: {
          heff_take_n(v_t_2433, 0ULL, 3);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str7)});
        }
        case TAG_LikeSum: {
          heff_take_n(v_t_2433, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str8)});
        }
        case TAG_LikeInt: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str9)});
        }
        case TAG_LikeFloat: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str10)});
        }
        case TAG_LikeString: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str11)});
        }
        case TAG_LikeArray: {
          heff_take_n(v_t_2433, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str12)});
        }
        case TAG_LikeFixed: {
          heff_take_n(v_t_2433, 0ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str13)});
        }
        case TAG_NoRules: {
          heff_drop(v_c_240);
          heff_drop(v_a_2423);
          heff_drop(v_n_2430);
          heff_drop_cell(v_ru_24x21_2428_24MkPair, 2);
          heff_drop(v_f_27_2431);
          heff_drop_cell(v_ru_24x_2429_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_2426_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str14)});
        }
        default: return heff_nomatch(v_t_2433);
        }
      }
      default: return heff_nomatch(v_x_2429);
      }
    }
    default: return heff_nomatch(v_x21_2428);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam10(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_2483 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2492 = heff_tr(heff_apply(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_Left: {
    V v_e_2493 = heff_field(v_x2_2492, 0);
    V v_ru_24x2_2492_24Left = heff_take_reuse_n(v_x2_2492, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_2483);
    return heff_tag_at(v_ru_24x2_2492_24Left, TAG_Left, 1, (V[]){v_e_2493});
  }
  case TAG_Right: {
    V v_x21_2494 = heff_field(v_x2_2492, 0);
    V v_ru_24x2_2492_24Right = heff_take_reuse_n(v_x2_2492, 1ULL, 1);
    switch (heff_tag_of(v_x21_2494)) {
    case TAG_MkPair: {
      V v_x_2495 = heff_field(v_x21_2494, 0);
      V v_n_2496 = heff_field(v_x21_2494, 1);
      V v_ru_24x21_2494_24MkPair = heff_take_reuse_n(v_x21_2494, 3ULL, 2);
      V v_x1_2497 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_ty_2483, heff_get(v_c_240, LBL_env)));
      V v_t_24101;
      switch (heff_tag_of(v_x1_2497)) {
      case TAG_Nom: {
        V v_x_2498 = heff_field(v_x1_2497, 0);
        heff_take_n(v_x1_2497, 1ULL, 1);
        v_t_24101 = v_x_2498;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2497, 0ULL, 1);
        v_t_24101 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24100 = heff_field(v_x1_2497, 0);
        heff_take_n(v_x1_2497, 1ULL, 1);
        v_t_24101 = v_x_24100;
        break;
      }
      default: heff_nomatch(v_x1_2497);
      }
      V v_x_24102 = heff_tag_at(v_ru_24x21_2494_24MkPair, TAG_MkPair, 2, (V[]){v_x_2495, v_t_24101});
      return heff_tag_at(v_ru_24x2_2492_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_24102, v_n_2496})});
    }
    default: return heff_nomatch(v_x21_2494);
    }
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam11(V self, V *args) {
  V v_n_24104 = args[0];
  heff_drop(v_n_24104);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str15)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam12(V self, V *args) {
  V v_n_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_24105 = heff_env(self)[2];
  V v_l_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24109 = heff_tr(heff_apply(v_m_24107, 1, (V[]){v_n_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_Left: {
    V v_e_24110 = heff_field(v_x2_24109, 0);
    V v_ru_24x2_24109_24Left = heff_take_reuse_n(v_x2_24109, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_e_24105);
    heff_drop(v_l_24106);
    return heff_tag_at(v_ru_24x2_24109_24Left, TAG_Left, 1, (V[]){v_e_24110});
  }
  case TAG_Right: {
    V v_x21_24111 = heff_field(v_x2_24109, 0);
    V v_ru_24x2_24109_24Right = heff_take_reuse_n(v_x2_24109, 1ULL, 1);
    switch (heff_tag_of(v_x21_24111)) {
    case TAG_MkPair: {
      V v_x_24112 = heff_field(v_x21_24111, 0);
      V v_n_24113 = heff_field(v_x21_24111, 1);
      V v_ru_24x21_24111_24MkPair = heff_take_reuse_n(v_x21_24111, 3ULL, 2);
      switch (heff_tag_of(v_x_24112)) {
      case TAG_MkPair: {
        V v_e_27_24114 = heff_field(v_x_24112, 0);
        V v_ety_24115 = heff_field(v_x_24112, 1);
        heff_take_n(v_x_24112, 3ULL, 2);
        V v_x1_24116 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_e_24105, heff_get(heff_dup(v_c_240), LBL_env)));
        V v_v_24120;
        switch (heff_tag_of(v_x1_24116)) {
        case TAG_Nom: {
          V v_x_24117 = heff_field(v_x1_24116, 0);
          heff_take_n(v_x1_24116, 1ULL, 1);
          v_v_24120 = v_x_24117;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24116, 0ULL, 1);
          v_v_24120 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24119 = heff_field(v_x1_24116, 0);
          heff_take_n(v_x1_24116, 1ULL, 1);
          v_v_24120 = v_x_24119;
          break;
        }
        default: heff_nomatch(v_x1_24116);
        }
        V v_t_24121 = (g_heff_2evalue_2ecoerceToFieldsMaybe(v_v_24120));
        V v_m_24122 = (g_heff_2eerase_2eprojTyInWith(heff_get(v_c_240, LBL_len), v_ety_24115, v_t_24121, heff_dup(v_l_24106)));
        V v_x2_24123 = heff_tr(heff_apply(v_m_24122, 1, (V[]){v_n_24113}));
        switch (heff_tag_of(v_x2_24123)) {
        case TAG_Left: {
          V v_e_24124 = heff_field(v_x2_24123, 0);
          heff_take_n(v_x2_24123, 1ULL, 1);
          heff_drop(v_l_24106);
          heff_drop_cell(v_ru_24x21_24111_24MkPair, 2);
          heff_drop(v_e_27_24114);
          return heff_tag_at(v_ru_24x2_24109_24Right, TAG_Left, 1, (V[]){v_e_24124});
        }
        case TAG_Right: {
          V v_x21_24125 = heff_field(v_x2_24123, 0);
          heff_take_n(v_x2_24123, 1ULL, 1);
          switch (heff_tag_of(v_x21_24125)) {
          case TAG_MkPair: {
            V v_x_24126 = heff_field(v_x21_24125, 0);
            V v_n_24127 = heff_field(v_x21_24125, 1);
            heff_take_n(v_x21_24125, 3ULL, 2);
            V v_t_24128 = heff_tag_at(v_ru_24x21_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_27_24114, v_l_24106}), v_x_24126});
            return heff_tag_at(v_ru_24x2_24109_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24128, v_n_24127})});
          }
          default: return heff_nomatch(v_x21_24125);
          }
        }
        default: return heff_nomatch(v_x2_24123);
        }
      }
      default: return heff_nomatch(v_x_24112);
      }
    }
    default: return heff_nomatch(v_x21_24111);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam13(V self, V *args) {
  V v_n_24131 = args[0];
  heff_drop(v_n_24131);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str16)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam15(V self, V *args) {
  V v_p_24161 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24147 = heff_env(self)[1];
  V v_x_24156 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eerase_2earmOf_24s627775745x609415035(v_c_240, v_x_24147, v_x_24156, v_p_24161));
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam14(V self, V *args) {
  V v_n_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_cases_24133 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24136 = heff_tr(heff_apply(v_m_24134, 1, (V[]){v_n_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_Left: {
    V v_e_24137 = heff_field(v_x2_24136, 0);
    V v_ru_24x2_24136_24Left = heff_take_reuse_n(v_x2_24136, 1ULL, 1);
    heff_drop(v_cases_24133);
    heff_drop(v_c_240);
    return heff_tag_at(v_ru_24x2_24136_24Left, TAG_Left, 1, (V[]){v_e_24137});
  }
  case TAG_Right: {
    V v_x21_24138 = heff_field(v_x2_24136, 0);
    V v_ru_24x2_24136_24Right = heff_take_reuse_n(v_x2_24136, 1ULL, 1);
    switch (heff_tag_of(v_x21_24138)) {
    case TAG_MkPair: {
      V v_x_24139 = heff_field(v_x21_24138, 0);
      V v_n_24140 = heff_field(v_x21_24138, 1);
      V v_ru_24x21_24138_24MkPair = heff_take_reuse_n(v_x21_24138, 3ULL, 2);
      switch (heff_tag_of(v_x_24139)) {
      case TAG_MkPair: {
        V v_s_27_24141 = heff_field(v_x_24139, 0);
        V v_sty_24142 = heff_field(v_x_24139, 1);
        heff_take_n(v_x_24139, 3ULL, 2);
        V v_m_24143 = (g_heff_2eerase_2ematchVariants(v_sty_24142));
        V v_x2_24144 = heff_tr(heff_apply(v_m_24143, 1, (V[]){v_n_24140}));
        switch (heff_tag_of(v_x2_24144)) {
        case TAG_Left: {
          V v_e_24145 = heff_field(v_x2_24144, 0);
          heff_take_n(v_x2_24144, 1ULL, 1);
          heff_drop(v_cases_24133);
          heff_drop(v_c_240);
          heff_drop_cell(v_ru_24x21_24138_24MkPair, 2);
          heff_drop(v_s_27_24141);
          return heff_tag_at(v_ru_24x2_24136_24Right, TAG_Left, 1, (V[]){v_e_24145});
        }
        case TAG_Right: {
          V v_x21_24146 = heff_field(v_x2_24144, 0);
          heff_take_n(v_x2_24144, 1ULL, 1);
          switch (heff_tag_of(v_x21_24146)) {
          case TAG_MkPair: {
            V v_x_24147 = heff_field(v_x21_24146, 0);
            V v_n_24148 = heff_field(v_x21_24146, 1);
            heff_take_n(v_x21_24146, 3ULL, 2);
            V v_t_24149 = heff_arrayToList(heff_get(heff_dup(v_cases_24133), LBL_keys));
            V v_t_24150 = heff_arrayToList(heff_get(heff_dup(v_cases_24133), LBL_values));
            V v_t_24151 = (g_heff_2edict_2ezipKV(v_t_24149, v_t_24150));
            V v_m_24152 = (g_heff_2eerase_2earmsTy_24s1202361547x1799531579(heff_dup(v_c_240), heff_dup(v_x_24147), v_t_24151));
            V v_x2_24153 = heff_tr(heff_apply(v_m_24152, 1, (V[]){v_n_24148}));
            switch (heff_tag_of(v_x2_24153)) {
            case TAG_Left: {
              V v_e_24154 = heff_field(v_x2_24153, 0);
              heff_take_n(v_x2_24153, 1ULL, 1);
              heff_drop(v_cases_24133);
              heff_drop(v_c_240);
              heff_drop_cell(v_ru_24x21_24138_24MkPair, 2);
              heff_drop(v_s_27_24141);
              heff_drop(v_x_24147);
              return heff_tag_at(v_ru_24x2_24136_24Right, TAG_Left, 1, (V[]){v_e_24154});
            }
            case TAG_Right: {
              V v_x21_24155 = heff_field(v_x2_24153, 0);
              heff_take_n(v_x2_24153, 1ULL, 1);
              switch (heff_tag_of(v_x21_24155)) {
              case TAG_MkPair: {
                V v_x_24156 = heff_field(v_x21_24155, 0);
                V v_n_24157 = heff_field(v_x21_24155, 1);
                heff_take_n(v_x21_24155, 3ULL, 2);
                V v_t_24158 = heff_arrayToList(heff_get(heff_dup(v_cases_24133), LBL_keys));
                V v_t_24159 = heff_arrayToList(heff_get(v_cases_24133, LBL_values));
                V v_t_24160 = (g_heff_2edict_2ezipKV(v_t_24158, v_t_24159));
                V v_m_24162 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2esynF_24s1264824444x261991683_lam15, 1, 3, (V[]){v_c_240, v_x_24147, heff_dup(v_x_24156)}), v_t_24160));
                V v_x2_24163 = heff_tr(heff_apply(v_m_24162, 1, (V[]){v_n_24157}));
                switch (heff_tag_of(v_x2_24163)) {
                case TAG_Left: {
                  V v_e_24164 = heff_field(v_x2_24163, 0);
                  heff_take_n(v_x2_24163, 1ULL, 1);
                  heff_drop_cell(v_ru_24x21_24138_24MkPair, 2);
                  heff_drop(v_s_27_24141);
                  heff_drop(v_x_24156);
                  return heff_tag_at(v_ru_24x2_24136_24Right, TAG_Left, 1, (V[]){v_e_24164});
                }
                case TAG_Right: {
                  V v_x21_24165 = heff_field(v_x2_24163, 0);
                  heff_take_n(v_x2_24163, 1ULL, 1);
                  switch (heff_tag_of(v_x21_24165)) {
                  case TAG_MkPair: {
                    V v_x_24166 = heff_field(v_x21_24165, 0);
                    V v_n_24167 = heff_field(v_x21_24165, 1);
                    heff_take_n(v_x21_24165, 3ULL, 2);
                    V v_t_24168 = heff_tag_at(v_ru_24x21_24138_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_27_24141, v_x_24166}), v_x_24156});
                    return heff_tag_at(v_ru_24x2_24136_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24168, v_n_24167})});
                  }
                  default: return heff_nomatch(v_x21_24165);
                  }
                }
                default: return heff_nomatch(v_x2_24163);
                }
              }
              default: return heff_nomatch(v_x21_24155);
              }
            }
            default: return heff_nomatch(v_x2_24153);
            }
          }
          default: return heff_nomatch(v_x21_24146);
          }
        }
        default: return heff_nomatch(v_x2_24144);
        }
      }
      default: return heff_nomatch(v_x_24139);
      }
    }
    default: return heff_nomatch(v_x21_24138);
    }
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam16(V self, V *args) {
  V v_n_24172 = args[0];
  heff_drop(v_n_24172);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str17)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam17(V self, V *args) {
  V v_n_24174 = args[0];
  heff_drop(v_n_24174);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str18)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam18(V self, V *args) {
  V v_n_24175 = args[0];
  heff_drop(v_n_24175);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str19)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam19(V self, V *args) {
  V v_n_24185 = args[0];
  V v_m_24184 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_24177 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24186 = heff_tr(heff_apply(v_m_24184, 1, (V[]){v_n_24185}));
  switch (heff_tag_of(v_x2_24186)) {
  case TAG_Left: {
    V v_e_24187 = heff_field(v_x2_24186, 0);
    V v_ru_24x2_24186_24Left = heff_take_reuse_n(v_x2_24186, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_24177);
    return heff_tag_at(v_ru_24x2_24186_24Left, TAG_Left, 1, (V[]){v_e_24187});
  }
  case TAG_Right: {
    V v_x21_24188 = heff_field(v_x2_24186, 0);
    V v_ru_24x2_24186_24Right = heff_take_reuse_n(v_x2_24186, 1ULL, 1);
    switch (heff_tag_of(v_x21_24188)) {
    case TAG_MkPair: {
      V v_x_24189 = heff_field(v_x21_24188, 0);
      V v_n_24190 = heff_field(v_x21_24188, 1);
      V v_ru_24x21_24188_24MkPair = heff_take_reuse_n(v_x21_24188, 3ULL, 2);
      V v_x1_24191 = (g_heff_2eeval_2eevalTypeF_24s2027500405x1019539000(heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_ty_24177, heff_get(v_c_240, LBL_env)));
      V v_t_24195;
      switch (heff_tag_of(v_x1_24191)) {
      case TAG_Nom: {
        V v_x_24192 = heff_field(v_x1_24191, 0);
        heff_take_n(v_x1_24191, 1ULL, 1);
        v_t_24195 = v_x_24192;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24191, 0ULL, 1);
        v_t_24195 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24194 = heff_field(v_x1_24191, 0);
        heff_take_n(v_x1_24191, 1ULL, 1);
        v_t_24195 = v_x_24194;
        break;
      }
      default: heff_nomatch(v_x1_24191);
      }
      V v_x_24196 = heff_tag_at(v_ru_24x21_24188_24MkPair, TAG_MkPair, 2, (V[]){v_x_24189, v_t_24195});
      return heff_tag_at(v_ru_24x2_24186_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_24196, v_n_24190})});
    }
    default: return heff_nomatch(v_x21_24188);
    }
  }
  default: return heff_nomatch(v_x2_24186);
  }
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam20(V self, V *args) {
  V v_n_24200 = args[0];
  heff_drop(v_n_24200);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str20)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam21(V self, V *args) {
  V v_n_24204 = args[0];
  heff_drop(v_n_24204);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2esynF_24s1264824444x261991683_str21)});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam22(V self, V *args) {
  V v_n_24206 = args[0];
  V v_i_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24207 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EInt, 1, (V[]){v_i_24205}), NTAG(TAG_VPrimInt)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24207, v_n_24206})});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam23(V self, V *args) {
  V v_n_24209 = args[0];
  V v_x_24208 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24210 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EFloat, 1, (V[]){v_x_24208}), NTAG(TAG_VPrimFloat)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24210, v_n_24209})});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam24(V self, V *args) {
  V v_n_24212 = args[0];
  V v_s_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24213 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EStr, 1, (V[]){v_s_24211}), NTAG(TAG_VPrimString)});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24213, v_n_24212})});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam25(V self, V *args) {
  V v_n_24216 = args[0];
  V v_w_24214 = heff_env(self)[0];
  V v_n_24215 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24217 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EFixed, 2, (V[]){heff_dup(v_w_24214), v_n_24215}), heff_tag(TAG_VFixed, 1, (V[]){v_w_24214})});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24217, v_n_24216})});
}
V g_heff_2eerase_2esynF_24s1264824444x261991683_lam26(V self, V *args) {
  V v_n_24219 = args[0];
  V v_x_24218 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24220 = heff_tag(TAG_VFixed, 1, (V[]){NTAG(TAG_F32)});
  V v_t_24221 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EFloat32, 1, (V[]){v_x_24218}), v_t_24220});
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24221, v_n_24219})});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str0 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str7 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str8 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str9 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str10 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str11 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str12 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str13 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eerase_2echkLam_24s2015454573x196455732_str14 = {{0x80000000u, K_STR, 0}, 46, 46, {97, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101}};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam0(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam0, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam1(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam2(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam4(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam3(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam6(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam7(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam9(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam8(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam5(V self, V *args);
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam10(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam10, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam11(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam11, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam12(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam12, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam13(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam13, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam14(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam14, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam15(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam15, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam16(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam16, 1, 0};
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam17(V self, V *args); static Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_lam17, 1, 0};
Clo g_heff_2eerase_2echkLam_24s2015454573x196455732_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkLam_24s2015454573x196455732_entry, 3, 0};

V g_heff_2eerase_2echkLam_24s2015454573x196455732(V v_c_240, V v_abs_241, V v_ty_242) {
top: ;
  V v_t_243 = (g_heff_2evalue_2ebehavior(v_ty_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_LikeU: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam0_clo);
  }
  case TAG_LikeFunction: {
    V v_dom_247 = heff_field(v_t_243, 1);
    V v_cod_248 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 4);
    V v_it_2415;
    switch (heff_tag_of(v_abs_241)) {
    case TAG_MkAbs: {
      V v_n_2410 = heff_field(v_abs_241, 0);
      V v_b_2411 = heff_field(v_abs_241, 1);
      V v_ru_24abs_241_24MkAbs = heff_take_reuse_n(v_abs_241, 3ULL, 2);
      V v_t_2412 = heff_tag_at(v_ru_24abs_241_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2410, NTAG(TAG_True)});
      v_it_2415 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2412, v_b_2411});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_abs_241, 0);
      heff_take_n(v_abs_241, 1ULL, 1);
      V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str1), NTAG(TAG_False)});
      v_it_2415 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2414, v_b_2413});
      break;
    }
    default: heff_nomatch(v_abs_241);
    }
    switch (heff_tag_of(v_it_2415)) {
    case TAG_MkPair: {
      V v_it1_2416 = heff_field(v_it_2415, 0);
      V v_body_2417 = heff_field(v_it_2415, 1);
      V v_ru_24it_2415_24MkPair = heff_take_reuse_n(v_it_2415, 3ULL, 2);
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_MkPair: {
        V v_hint_2418 = heff_field(v_it1_2416, 0);
        V v_bound_2419 = heff_field(v_it1_2416, 1);
        V v_ru_24it1_2416_24MkPair = heff_take_reuse_n(v_it1_2416, 3ULL, 2);
        V v_t_2420 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_dom_247)));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_True: {
          heff_drop(v_hint_2418);
          V v_c_2429;
          switch (heff_tag_of(v_bound_2419)) {
          case TAG_True: {
            V v_t_2421 = heff_rec(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_247)});
            V v_t_2422 = heff_tag_at(v_ru_24it_2415_24MkPair, TAG_Cons, 2, (V[]){v_t_2421, heff_get(heff_dup(v_c_240), LBL_locals)});
            V v_t_2423 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
            V v_v_2425 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2423, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam1, 1, 1, (V[]){heff_dup(v_dom_247)}), NTAG(TAG_Nothing)));
            V v_t_2427 = heff_tag_at(v_ru_24it1_2416_24MkPair, TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam2, 1, 1, (V[]){v_v_2425})});
            V v_t_2428 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
            v_c_2429 = heff_rec(4, shape_locals__env__len__globals, (V[]){v_t_2422, v_t_2427, v_t_2428, heff_get(heff_dup(v_c_240), LBL_globals)});
            break;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24it_2415_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2416_24MkPair, 2);
            v_c_2429 = heff_dup(v_c_240);
            break;
          }
          default: heff_nomatch(v_bound_2419);
          }
          V v_x1_2437;
          switch (heff_tag_of(v_cod_248)) {
          case TAG_MkClo: {
            V v_vs_2431 = heff_field(v_cod_248, 1);
            V v_body_2432 = heff_field(v_cod_248, 2);
            heff_take_n(v_cod_248, 6ULL, 3);
            v_x1_2437 = heff_tr(heff_apply(v_body_2432, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam3, 1, 2, (V[]){v_c_240, v_dom_247})})}));
            break;
          }
          case TAG_CloConst: {
            V v_body_2436 = heff_field(v_cod_248, 0);
            heff_take_n(v_cod_248, 1ULL, 1);
            heff_drop(v_c_240);
            heff_drop(v_dom_247);
            v_x1_2437 = v_body_2436;
            break;
          }
          default: heff_nomatch(v_cod_248);
          }
          V v_ty_2441;
          switch (heff_tag_of(v_x1_2437)) {
          case TAG_Nom: {
            V v_x_2438 = heff_field(v_x1_2437, 0);
            heff_take_n(v_x1_2437, 1ULL, 1);
            v_ty_2441 = v_x_2438;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2437, 0ULL, 1);
            v_ty_2441 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2440 = heff_field(v_x1_2437, 0);
            heff_take_n(v_x1_2437, 1ULL, 1);
            v_ty_2441 = v_x_2440;
            break;
          }
          default: heff_nomatch(v_x1_2437);
          }
          HEFF_LAST return g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_2429, v_body_2417, v_ty_2441);
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24it_2415_24MkPair, 2);
          heff_drop_cell(v_ru_24it1_2416_24MkPair, 2);
          return heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam5, 1, 6, (V[]){v_hint_2418, v_bound_2419, v_dom_247, v_c_240, v_cod_248, v_body_2417});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      default: return heff_nomatch(v_it1_2416);
      }
    }
    default: return heff_nomatch(v_it_2415);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam10_clo);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam11_clo);
  }
  case TAG_LikeInt: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam12_clo);
  }
  case TAG_LikeFloat: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam13_clo);
  }
  case TAG_LikeString: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam14_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam15_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam16_clo);
  }
  case TAG_NoRules: {
    heff_drop(v_c_240);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_lam17_clo);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkLam_24s2015454573x196455732(a[0], a[1], a[2]);
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam0(V self, V *args) {
  V v_n_245 = args[0];
  heff_drop(v_n_245);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str0)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam2(V self, V *args) {
  V v_u_2426 = args[0];
  V v_v_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2426);
  return v_v_2425;
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam4(V self, V *args) {
  V v_u_2435 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2435);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2433);
  V v_t_2434 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2434, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam4, 1, 1, (V[]){v_dom_247}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam6(V self, V *args) {
  V v_u_2456 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_v_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  return v_v_2457;
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam9(V self, V *args) {
  V v_u_2467 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  return v_dom_247;
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam8(V self, V *args) {
  V v_u_2465 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2465);
  V v_t_2466 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2466, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam9, 1, 1, (V[]){v_dom_247}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam5(V self, V *args) {
  V v_n_2442 = args[0];
  V v_hint_2418 = heff_env(self)[0];
  V v_bound_2419 = heff_env(self)[1];
  V v_dom_247 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_cod_248 = heff_env(self)[4];
  V v_body_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443 = heff_strEq(heff_dup(v_hint_2418), ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str2));
  V v_base_2445;
  switch (heff_tag_of(v_t_2443)) {
  case TAG_True: {
    heff_drop(v_hint_2418);
    v_base_2445 = ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str3);
    break;
  }
  case TAG_False: {
    V v_t_2444 = heff_strEq(heff_dup(v_hint_2418), ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str4));
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      heff_drop(v_hint_2418);
      v_base_2445 = ((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str5);
      break;
    }
    case TAG_False: {
      v_base_2445 = v_hint_2418;
      break;
    }
    default: heff_nomatch(v_t_2444);
    }
    break;
  }
  default: heff_nomatch(v_t_2443);
  }
  V v_t_2446 = heff_strAppend(v_base_2445, heff_strAppend(((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str6), heff_intShow(heff_dup(v_n_2442))));
  V v_t_2447 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2446, heff_intAdd(v_n_2442, MK_INT(1LL))});
  V v_x2_2448 = heff_tag(TAG_Right, 1, (V[]){v_t_2447});
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_Left: {
    V v_e_2449 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Left = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    heff_drop(v_bound_2419);
    heff_drop(v_dom_247);
    heff_drop(v_c_240);
    heff_drop(v_cod_248);
    heff_drop(v_body_2417);
    return heff_tag_at(v_ru_24x2_2448_24Left, TAG_Left, 1, (V[]){v_e_2449});
  }
  case TAG_Right: {
    V v_x21_2450 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Right = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    switch (heff_tag_of(v_x21_2450)) {
    case TAG_MkPair: {
      V v_x_2451 = heff_field(v_x21_2450, 0);
      V v_n_2452 = heff_field(v_x21_2450, 1);
      V v_ru_24x21_2450_24MkPair = heff_take_reuse_n(v_x21_2450, 3ULL, 2);
      V v_c_2461;
      switch (heff_tag_of(v_bound_2419)) {
      case TAG_True: {
        V v_t_2453 = heff_tag_at(v_ru_24x2_2448_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2451)})});
        V v_t_2454 = heff_tag_at(v_ru_24x21_2450_24MkPair, TAG_Cons, 2, (V[]){heff_rec(2, shape_ir__ty, (V[]){v_t_2453, heff_dup(v_dom_247)}), heff_get(heff_dup(v_c_240), LBL_locals)});
        V v_t_2455 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
        V v_v_2457 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2455, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam6, 1, 1, (V[]){heff_dup(v_dom_247)}), NTAG(TAG_Nothing)));
        V v_t_2459 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam7, 1, 1, (V[]){v_v_2457})});
        V v_t_2460 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
        v_c_2461 = heff_rec(4, shape_locals__env__len__globals, (V[]){v_t_2454, v_t_2459, v_t_2460, heff_get(heff_dup(v_c_240), LBL_globals)});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_2448_24Right, 1);
        heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
        v_c_2461 = heff_dup(v_c_240);
        break;
      }
      default: heff_nomatch(v_bound_2419);
      }
      V v_x1_2469;
      switch (heff_tag_of(v_cod_248)) {
      case TAG_MkClo: {
        V v_vs_2463 = heff_field(v_cod_248, 1);
        V v_body_2464 = heff_field(v_cod_248, 2);
        heff_take_n(v_cod_248, 6ULL, 3);
        v_x1_2469 = heff_tr(heff_apply(v_body_2464, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2463, heff_clo(g_heff_2eerase_2echkLam_24s2015454573x196455732_lam8, 1, 2, (V[]){v_c_240, v_dom_247})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2468 = heff_field(v_cod_248, 0);
        heff_take_n(v_cod_248, 1ULL, 1);
        heff_drop(v_dom_247);
        heff_drop(v_c_240);
        v_x1_2469 = v_body_2468;
        break;
      }
      default: heff_nomatch(v_cod_248);
      }
      V v_ty_2473;
      switch (heff_tag_of(v_x1_2469)) {
      case TAG_Nom: {
        V v_x_2470 = heff_field(v_x1_2469, 0);
        heff_take_n(v_x1_2469, 1ULL, 1);
        v_ty_2473 = v_x_2470;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2469, 0ULL, 1);
        v_ty_2473 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2472 = heff_field(v_x1_2469, 0);
        heff_take_n(v_x1_2469, 1ULL, 1);
        v_ty_2473 = v_x_2472;
        break;
      }
      default: heff_nomatch(v_x1_2469);
      }
      V v_m_2474 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_2461, v_body_2417, v_ty_2473));
      V v_x2_2475 = heff_tr(heff_apply(v_m_2474, 1, (V[]){v_n_2452}));
      switch (heff_tag_of(v_x2_2475)) {
      case TAG_Left: {
        V v_e_2476 = heff_field(v_x2_2475, 0);
        V v_ru_24x2_2475_24Left = heff_take_reuse_n(v_x2_2475, 1ULL, 1);
        heff_drop(v_x_2451);
        return heff_tag_at(v_ru_24x2_2475_24Left, TAG_Left, 1, (V[]){v_e_2476});
      }
      case TAG_Right: {
        V v_x21_2477 = heff_field(v_x2_2475, 0);
        V v_ru_24x2_2475_24Right = heff_take_reuse_n(v_x2_2475, 1ULL, 1);
        switch (heff_tag_of(v_x21_2477)) {
        case TAG_MkPair: {
          V v_x_2478 = heff_field(v_x21_2477, 0);
          V v_n_2479 = heff_field(v_x21_2477, 1);
          V v_ru_24x21_2477_24MkPair = heff_take_reuse_n(v_x21_2477, 3ULL, 2);
          V v_t_2480 = heff_tag_at(v_ru_24x21_2477_24MkPair, TAG_Cons, 2, (V[]){v_x_2451, NTAG(TAG_Nil)});
          V v_t_2481 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2480, v_x_2478}), v_n_2479});
          return heff_tag_at(v_ru_24x2_2475_24Right, TAG_Right, 1, (V[]){v_t_2481});
        }
        default: return heff_nomatch(v_x21_2477);
        }
      }
      default: return heff_nomatch(v_x2_2475);
      }
    }
    default: return heff_nomatch(v_x21_2450);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam10(V self, V *args) {
  V v_n_2485 = args[0];
  heff_drop(v_n_2485);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str7)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam11(V self, V *args) {
  V v_n_2487 = args[0];
  heff_drop(v_n_2487);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str8)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam12(V self, V *args) {
  V v_n_2488 = args[0];
  heff_drop(v_n_2488);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str9)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam13(V self, V *args) {
  V v_n_2489 = args[0];
  heff_drop(v_n_2489);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str10)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam14(V self, V *args) {
  V v_n_2490 = args[0];
  heff_drop(v_n_2490);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str11)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam15(V self, V *args) {
  V v_n_2492 = args[0];
  heff_drop(v_n_2492);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str12)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam16(V self, V *args) {
  V v_n_2494 = args[0];
  heff_drop(v_n_2494);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str13)});
}
V g_heff_2eerase_2echkLam_24s2015454573x196455732_lam17(V self, V *args) {
  V v_n_2495 = args[0];
  heff_drop(v_n_2495);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkLam_24s2015454573x196455732_str14)});
}
V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_lam0(V self, V *args);
V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_lam1(V self, V *args);
Clo g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_entry, 5, 0};

V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_capture_241);
    heff_drop(v_fieldTypes_242);
    V v_x_245 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(v_acc_243, LBL_out)));
    return heff_clo(g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_lam0, 1, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_x61_247 = heff_field(v_x6_244, 0);
    V v_tail_248 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_247)) {
    case TAG_MkPair: {
      V v_l_249 = heff_field(v_x61_247, 0);
      V v_fe_2410 = heff_field(v_x61_247, 1);
      heff_take_n(v_x61_247, 3ULL, 2);
      V v_t_2411 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_243), LBL_vs)));
      V v_t_2412 = heff_rec(3, shape_keys__byName__values, (V[]){heff_get(heff_dup(v_fieldTypes_242), LBL_keys), heff_get(heff_dup(v_fieldTypes_242), LBL_byName), heff_arrayFromList(v_t_2411)});
      V v_t_2413 = heff_tr(g_heff_2evalue_2etypeForProjection(heff_dup(v_capture_241), heff_dup(v_fieldTypes_242), heff_dup(v_l_249), v_t_2412));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_MkField: {
        V v_fty_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 2);
        V v_t_2416 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_fty_2414)));
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          heff_drop(v_l_249);
          heff_drop(v_fty_2414);
          V v_x1_2417 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_fe_2410, heff_get(heff_dup(v_c_240), LBL_env)));
          V v_t_2421;
          switch (heff_tag_of(v_x1_2417)) {
          case TAG_Nom: {
            V v_x_2418 = heff_field(v_x1_2417, 0);
            heff_take_n(v_x1_2417, 1ULL, 1);
            v_t_2421 = v_x_2418;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2417, 0ULL, 1);
            v_t_2421 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2420 = heff_field(v_x1_2417, 0);
            heff_take_n(v_x1_2417, 1ULL, 1);
            v_t_2421 = v_x_2420;
            break;
          }
          default: heff_nomatch(v_x1_2417);
          }
          V v_t_2422 = heff_tag_at(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_get(heff_dup(v_acc_243), LBL_vs)});
          V v_t_2423 = heff_rec(2, shape_vs__out, (V[]){v_t_2422, heff_get(v_acc_243, LBL_out)});
          V t_0 = v_c_240;
          V t_1 = v_capture_241;
          V t_2 = v_fieldTypes_242;
          V t_3 = v_t_2423;
          V t_4 = v_tail_248;
          v_c_240 = t_0;
          v_capture_241 = t_1;
          v_fieldTypes_242 = t_2;
          v_acc_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          V v_m_2424 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(heff_dup(v_c_240), heff_dup(v_fe_2410), v_fty_2414));
          return heff_clo(g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_lam1, 1, 8, (V[]){v_m_2424, v_c_240, v_fe_2410, v_acc_243, v_l_249, v_capture_241, v_fieldTypes_242, v_tail_248});
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x61_247);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkFieldsGo_24s746484600x246289788(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_245, v_n_246})});
}
V g_heff_2eerase_2echkFieldsGo_24s746484600x246289788_lam1(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fe_2410 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_l_249 = heff_env(self)[4];
  V v_capture_241 = heff_env(self)[5];
  V v_fieldTypes_242 = heff_env(self)[6];
  V v_tail_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2426 = heff_tr(heff_apply(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Left: {
    V v_e_2427 = heff_field(v_x2_2426, 0);
    V v_ru_24x2_2426_24Left = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_fe_2410);
    heff_drop(v_acc_243);
    heff_drop(v_l_249);
    heff_drop(v_capture_241);
    heff_drop(v_fieldTypes_242);
    heff_drop(v_tail_248);
    return heff_tag_at(v_ru_24x2_2426_24Left, TAG_Left, 1, (V[]){v_e_2427});
  }
  case TAG_Right: {
    V v_x21_2428 = heff_field(v_x2_2426, 0);
    heff_take_n(v_x2_2426, 1ULL, 1);
    switch (heff_tag_of(v_x21_2428)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_x21_2428, 0);
      V v_n_2430 = heff_field(v_x21_2428, 1);
      V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
      V v_x1_2431 = heff_tr(g_heff_2eeval_2eevalTermF(heff_dup(g_heff_2eeval_2eevaluator_get()), heff_get(heff_dup(v_c_240), LBL_globals), NTAG(TAG_N), v_fe_2410, heff_get(heff_dup(v_c_240), LBL_env)));
      V v_t_2435;
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_Nom: {
        V v_x_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        v_t_2435 = v_x_2432;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2431, 0ULL, 1);
        v_t_2435 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2434 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        v_t_2435 = v_x_2434;
        break;
      }
      default: heff_nomatch(v_x1_2431);
      }
      V v_t_2436 = heff_tag_at(v_ru_24x21_2428_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, heff_get(heff_dup(v_acc_243), LBL_vs)});
      V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_249, v_x_2429}), heff_get(v_acc_243, LBL_out)});
      V v_t_2438 = (g_heff_2eerase_2echkFieldsGo_24s746484600x246289788(v_c_240, v_capture_241, v_fieldTypes_242, heff_rec(2, shape_vs__out, (V[]){v_t_2436, v_t_2437}), v_tail_248));
      V f_ = v_t_2438;
      args[0] = v_n_2430;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2428);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam0(V self, V *args); static Clo g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam0, 1, 0};
V g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam1(V self, V *args);
Clo g_heff_2eerase_2echkTagArg_24s761456356x1112072901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkTagArg_24s761456356x1112072901_entry, 2, 0};

V g_heff_2eerase_2echkTagArg_24s761456356x1112072901(V v_c_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_a_242 = heff_field(v_x3_241, 0);
    V v_aty_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_aty_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_c_240);
      heff_drop(v_a_242);
      heff_drop(v_aty_243);
      return ((V)&g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam0_clo);
    }
    case TAG_False: {
      V v_m_247 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_a_242, v_aty_243));
      return heff_clo(g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eerase_2echkTagArg_24s761456356x1112072901_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkTagArg_24s761456356x1112072901(a[0], a[1]);
}
V g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_245});
  return heff_tag(TAG_Right, 1, (V[]){v_t_246});
}
V g_heff_2eerase_2echkTagArg_24s761456356x1112072901_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = heff_tag_at(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x2_249_24Right, TAG_Just, 1, (V[]){v_x_2412}), v_n_2413});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2414});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str0 = {{0x80000000u, K_STR, 0}, 26, 26, {97, 32, 116, 121, 112, 101, 32, 105, 110, 32, 97, 32, 118, 97, 108, 117, 101, 32, 112, 111, 115, 105, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str1 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str2 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str3 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str4 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str5 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str6 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str7 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str8 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str9 = {{0x80000000u, K_STR, 0}, 42, 42, {97, 32, 114, 101, 99, 111, 114, 100, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 114, 101, 99, 111, 114, 100, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str10 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str11 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str12 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {110, 111, 32, 116, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str14 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str15 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str16 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str17 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str18 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str19 = {{0x80000000u, K_STR, 0}, 36, 36, {97, 32, 116, 97, 103, 32, 99, 104, 101, 99, 107, 101, 100, 32, 97, 103, 97, 105, 110, 115, 116, 32, 97, 32, 110, 111, 110, 45, 115, 117, 109, 32, 116, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str20 = {{0x80000000u, K_STR, 0}, 14, 14, {97, 110, 32, 111, 112, 97, 113, 117, 101, 32, 116, 101, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkF_24s2078926067x1185053013_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam0(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam1(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam2(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam2, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam3(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam4(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam4, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam5(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam5, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam6(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam7(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam7, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam8(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam8, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam9(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam9, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam10(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam10, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam11(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam11, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam12(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam12, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam13(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam13, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam14(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam15(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam15, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam16(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam16, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam17(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam17, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam18(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam19(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam20(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam21(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam21, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam22(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam22, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam23(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam23, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam24(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam24, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam25(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam25, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam26(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam26, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam28(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam27(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam29(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam30(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam30, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam31(V self, V *args); static Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_lam31, 1, 0};
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam33(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam34(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam32(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam35(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam36(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam37(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam38(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam39(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam40(V self, V *args);
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam41(V self, V *args);
Clo g_heff_2eerase_2echkF_24s2078926067x1185053013_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkF_24s2078926067x1185053013_entry, 3, 0};

V g_heff_2eerase_2echkF_24s2078926067x1185053013(V v_c_240, V v_t_241, V v_ty_242) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_ty_242);
    V v_m_244 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam0, 1, 1, (V[]){v_m_244});
  }
  case TAG_SGlobal: {
    heff_drop(v_ty_242);
    V v_m_2414 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam2_clo);
  }
  case TAG_SApp: {
    heff_drop(v_ty_242);
    V v_m_2427 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam3, 1, 1, (V[]){v_m_2427});
  }
  case TAG_SLam: {
    V v_abs_2437 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    HEFF_LAST return g_heff_2eerase_2echkLam_24s2015454573x196455732(v_c_240, v_abs_2437, v_ty_242);
  }
  case TAG_SCons: {
    V v_d_2438 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_2439 = (g_heff_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam4_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2439, 0ULL, 4);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam5_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2448 = heff_field(v_t_2439, 1);
      V v_fieldTypes_2449 = heff_field(v_t_2439, 2);
      heff_take_n(v_t_2439, 6ULL, 3);
      V v_t_2450 = heff_rec(2, shape_vs__out, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2451 = heff_arrayToList(heff_get(heff_dup(v_d_2438), LBL_keys));
      V v_t_2452 = heff_arrayToList(heff_get(v_d_2438, LBL_values));
      V v_t_2453 = (g_heff_2edict_2ezipKV(v_t_2451, v_t_2452));
      V v_m_2454 = (g_heff_2eerase_2echkFieldsGo_24s746484600x246289788(v_c_240, v_capture_2448, v_fieldTypes_2449, v_t_2450, v_t_2453));
      return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam6, 1, 1, (V[]){v_m_2454});
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam7_clo);
    }
    case TAG_LikeInt: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam8_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam9_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam10_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam11_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam12_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_c_240);
      heff_drop(v_d_2438);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam13_clo);
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_SProj: {
    heff_drop(v_ty_242);
    V v_m_2474 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam14, 1, 1, (V[]){v_m_2474});
  }
  case TAG_STag: {
    V v_x_2483 = heff_field(v_t_241, 0);
    V v_args_2484 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_t_2485 = (g_heff_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2485)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2485, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam15_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2485, 0ULL, 4);
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam16_clo);
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2485, 0ULL, 3);
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam17_clo);
    }
    case TAG_LikeSum: {
      V v_vs_2497 = heff_field(v_t_2485, 0);
      V v_ru_24t_2485_24LikeSum = heff_take_reuse_n(v_t_2485, 1ULL, 1);
      V v_t_2498 = ({ V a_0 = heff_dup(v_x_2483); V b_1 = heff_get(heff_dup(v_vs_2497), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24104;
      switch (heff_tag_of(v_t_2498)) {
      case TAG_Nothing: {
        heff_drop(v_vs_2497);
        heff_drop_cell(v_ru_24t_2485_24LikeSum, 1);
        v_t_24104 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_i_2499 = heff_field(v_t_2498, 0);
        heff_take_n(v_t_2498, 1ULL, 1);
        V v_xs_24100 = heff_get(v_vs_2497, LBL_values);
        V v_t_24101 = heff_intLe(MK_INT(0LL), heff_dup(v_i_2499));
        switch (heff_tag_of(v_t_24101)) {
        case TAG_True: {
          V v_t_24102 = heff_intLt(heff_dup(v_i_2499), heff_arrayLength(heff_dup(v_xs_24100)));
          switch (heff_tag_of(v_t_24102)) {
          case TAG_True: {
            V v_t_24103 = heff_arrayIndex(v_xs_24100, v_i_2499);
            v_t_24104 = heff_tag_at(v_ru_24t_2485_24LikeSum, TAG_Just, 1, (V[]){v_t_24103});
            break;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24t_2485_24LikeSum, 1);
            heff_drop(v_i_2499);
            heff_drop(v_xs_24100);
            v_t_24104 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_24102);
          }
          break;
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24t_2485_24LikeSum, 1);
          heff_drop(v_i_2499);
          heff_drop(v_xs_24100);
          v_t_24104 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        break;
      }
      default: heff_nomatch(v_t_2498);
      }
      switch (heff_tag_of(v_t_24104)) {
      case TAG_Nothing: {
        heff_drop(v_c_240);
        heff_drop(v_args_2484);
        return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam18, 1, 1, (V[]){v_x_2483});
      }
      case TAG_Just: {
        V v_ts_24106 = heff_field(v_t_24104, 0);
        heff_take_n(v_t_24104, 1ULL, 1);
        V v_t_24107 = (g_prelude_2emap_24s751962069x1815060025(heff_arrayToList(v_ts_24106)));
        V v_t_24108 = (g_heff_2eerase_2ezipE(heff_arrayToList(v_args_2484), v_t_24107));
        V v_m_24110 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam19, 1, 1, (V[]){v_c_240}), v_t_24108));
        return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam20, 1, 2, (V[]){v_m_24110, v_x_2483});
      }
      default: return heff_nomatch(v_t_24104);
      }
    }
    case TAG_LikeInt: {
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam21_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam22_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam23_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2485, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam24_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2485, 0ULL, 1);
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam25_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_c_240);
      heff_drop(v_x_2483);
      heff_drop(v_args_2484);
      return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam26_clo);
    }
    default: return heff_nomatch(v_t_2485);
    }
  }
  case TAG_SMatch: {
    V v_scrut_24126 = heff_field(v_t_241, 0);
    V v_cases_24127 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24128 = (g_heff_2eerase_2esynF_24s1264824444x261991683(heff_dup(v_c_240), v_scrut_24126));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam27, 1, 4, (V[]){v_m_24128, v_cases_24127, v_c_240, v_ty_242});
  }
  case TAG_SSpecialize: {
    heff_drop(v_ty_242);
    V v_m_24157 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam29, 1, 1, (V[]){v_m_24157});
  }
  case TAG_SIs: {
    V v_t_27_24166 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24166;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam30_clo);
  }
  case TAG_SAbandon: {
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_lam31_clo);
  }
  case TAG_SRec: {
    V v_t_27_24170 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24170;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_it2_24172 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    switch (heff_tag_of(v_it2_24172)) {
    case TAG_MkAbs: {
      V v_x_24173 = heff_field(v_it2_24172, 0);
      V v_body_24174 = heff_field(v_it2_24172, 1);
      heff_take_n(v_it2_24172, 3ULL, 2);
      return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam32, 1, 4, (V[]){v_x_24173, v_ty_242, v_c_240, v_body_24174});
    }
    case TAG_AbsConst: {
      V v_body_24202 = heff_field(v_it2_24172, 0);
      heff_take_n(v_it2_24172, 1ULL, 1);
      V t_0 = v_c_240;
      V t_1 = v_body_24202;
      V t_2 = v_ty_242;
      v_c_240 = t_0;
      v_t_241 = t_1;
      v_ty_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_it2_24172);
    }
  }
  case TAG_SImplicit: {
    V v_t_27_24204 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24204;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_24205 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam35, 1, 1, (V[]){v_x_24205});
  }
  case TAG_SMetaApp: {
    heff_drop(v_ty_242);
    V v_m_24211 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam36, 1, 1, (V[]){v_m_24211});
  }
  case TAG_SLitInt: {
    heff_drop(v_ty_242);
    V v_m_24221 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam37, 1, 1, (V[]){v_m_24221});
  }
  case TAG_SLitFloat: {
    heff_drop(v_ty_242);
    V v_m_24231 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam38, 1, 1, (V[]){v_m_24231});
  }
  case TAG_SLitString: {
    heff_drop(v_ty_242);
    V v_m_24241 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam39, 1, 1, (V[]){v_m_24241});
  }
  case TAG_SLitFixed: {
    heff_drop(v_ty_242);
    V v_m_24252 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam40, 1, 1, (V[]){v_m_24252});
  }
  case TAG_SLitFloat32: {
    heff_drop(v_ty_242);
    V v_m_24262 = (g_heff_2eerase_2esynF_24s1264824444x261991683(v_c_240, v_t_241));
    return heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam41, 1, 1, (V[]){v_m_24262});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkF_24s2078926067x1185053013(a[0], a[1], a[2]);
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Left: {
    V v_e_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Left = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_246_24Left, TAG_Left, 1, (V[]){v_e_247});
  }
  case TAG_Right: {
    V v_x21_248 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Right = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x21_248, 0);
      V v_n_2410 = heff_field(v_x21_248, 1);
      heff_take_n(v_x21_248, 3ULL, 2);
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_t_27_2411 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_246_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2411, v_n_2410})});
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2416 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Left: {
    V v_e_2417 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Left = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2416_24Left, TAG_Left, 1, (V[]){v_e_2417});
  }
  case TAG_Right: {
    V v_x21_2418 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Right = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    switch (heff_tag_of(v_x21_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x21_2418, 0);
      V v_n_2420 = heff_field(v_x21_2418, 1);
      heff_take_n(v_x21_2418, 3ULL, 2);
      switch (heff_tag_of(v_x_2419)) {
      case TAG_MkPair: {
        V v_t_27_2421 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_2416_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2421, v_n_2420})});
      }
      default: return heff_nomatch(v_x_2419);
      }
    }
    default: return heff_nomatch(v_x21_2418);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  heff_drop(v_n_2424);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str0)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2429 = heff_tr(heff_apply(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Left: {
    V v_e_2430 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Left = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2429_24Left, TAG_Left, 1, (V[]){v_e_2430});
  }
  case TAG_Right: {
    V v_x21_2431 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Right = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x21_2431, 0);
      V v_n_2433 = heff_field(v_x21_2431, 1);
      heff_take_n(v_x21_2431, 3ULL, 2);
      switch (heff_tag_of(v_x_2432)) {
      case TAG_MkPair: {
        V v_t_27_2434 = heff_field(v_x_2432, 0);
        heff_take_n(v_x_2432, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_2429_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2434, v_n_2433})});
      }
      default: return heff_nomatch(v_x_2432);
      }
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam4(V self, V *args) {
  V v_n_2441 = args[0];
  heff_drop(v_n_2441);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str1)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  heff_drop(v_n_2446);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str2)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam6(V self, V *args) {
  V v_n_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_Left: {
    V v_e_2457 = heff_field(v_x2_2456, 0);
    V v_ru_24x2_2456_24Left = heff_take_reuse_n(v_x2_2456, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2456_24Left, TAG_Left, 1, (V[]){v_e_2457});
  }
  case TAG_Right: {
    V v_x21_2458 = heff_field(v_x2_2456, 0);
    V v_ru_24x2_2456_24Right = heff_take_reuse_n(v_x2_2456, 1ULL, 1);
    switch (heff_tag_of(v_x21_2458)) {
    case TAG_MkPair: {
      V v_x_2459 = heff_field(v_x21_2458, 0);
      V v_n_2460 = heff_field(v_x21_2458, 1);
      V v_ru_24x21_2458_24MkPair = heff_take_reuse_n(v_x21_2458, 3ULL, 2);
      V v_t_2461 = heff_tag_at(v_ru_24x21_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24x2_2456_24Right, TAG_ERecord, 1, (V[]){v_x_2459}), v_n_2460});
      return heff_tag(TAG_Right, 1, (V[]){v_t_2461});
    }
    default: return heff_nomatch(v_x21_2458);
    }
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam7(V self, V *args) {
  V v_n_2463 = args[0];
  heff_drop(v_n_2463);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str3)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam8(V self, V *args) {
  V v_n_2464 = args[0];
  heff_drop(v_n_2464);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str4)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam9(V self, V *args) {
  V v_n_2465 = args[0];
  heff_drop(v_n_2465);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str5)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam10(V self, V *args) {
  V v_n_2466 = args[0];
  heff_drop(v_n_2466);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str6)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam11(V self, V *args) {
  V v_n_2468 = args[0];
  heff_drop(v_n_2468);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str7)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam12(V self, V *args) {
  V v_n_2470 = args[0];
  heff_drop(v_n_2470);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str8)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam13(V self, V *args) {
  V v_n_2471 = args[0];
  heff_drop(v_n_2471);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str9)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam14(V self, V *args) {
  V v_n_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2476 = heff_tr(heff_apply(v_m_2474, 1, (V[]){v_n_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_Left: {
    V v_e_2477 = heff_field(v_x2_2476, 0);
    V v_ru_24x2_2476_24Left = heff_take_reuse_n(v_x2_2476, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_2476_24Left, TAG_Left, 1, (V[]){v_e_2477});
  }
  case TAG_Right: {
    V v_x21_2478 = heff_field(v_x2_2476, 0);
    V v_ru_24x2_2476_24Right = heff_take_reuse_n(v_x2_2476, 1ULL, 1);
    switch (heff_tag_of(v_x21_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x21_2478, 0);
      V v_n_2480 = heff_field(v_x21_2478, 1);
      heff_take_n(v_x21_2478, 3ULL, 2);
      switch (heff_tag_of(v_x_2479)) {
      case TAG_MkPair: {
        V v_t_27_2481 = heff_field(v_x_2479, 0);
        heff_take_n(v_x_2479, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_2476_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_2481, v_n_2480})});
      }
      default: return heff_nomatch(v_x_2479);
      }
    }
    default: return heff_nomatch(v_x21_2478);
    }
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam15(V self, V *args) {
  V v_n_2487 = args[0];
  heff_drop(v_n_2487);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str10)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam16(V self, V *args) {
  V v_n_2492 = args[0];
  heff_drop(v_n_2492);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str11)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam17(V self, V *args) {
  V v_n_2496 = args[0];
  heff_drop(v_n_2496);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str12)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam18(V self, V *args) {
  V v_n_24105 = args[0];
  V v_x_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24105);
  return heff_tag(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str13), v_x_2483)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam19(V self, V *args) {
  V v_p_24109 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eerase_2echkTagArg_24s761456356x1112072901(v_c_240, v_p_24109));
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam20(V self, V *args) {
  V v_n_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  V v_x_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24112 = heff_tr(heff_apply(v_m_24110, 1, (V[]){v_n_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_Left: {
    V v_e_24113 = heff_field(v_x2_24112, 0);
    V v_ru_24x2_24112_24Left = heff_take_reuse_n(v_x2_24112, 1ULL, 1);
    heff_drop(v_x_2483);
    return heff_tag_at(v_ru_24x2_24112_24Left, TAG_Left, 1, (V[]){v_e_24113});
  }
  case TAG_Right: {
    V v_x21_24114 = heff_field(v_x2_24112, 0);
    V v_ru_24x2_24112_24Right = heff_take_reuse_n(v_x2_24112, 1ULL, 1);
    switch (heff_tag_of(v_x21_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x21_24114, 0);
      V v_n_24116 = heff_field(v_x21_24114, 1);
      V v_ru_24x21_24114_24MkPair = heff_take_reuse_n(v_x21_24114, 3ULL, 2);
      V v_x_24117 = heff_tag_at(v_ru_24x21_24114_24MkPair, TAG_ETag, 2, (V[]){v_x_2483, (g_heff_2eerase_2ecatMaybesE(v_x_24115))});
      return heff_tag_at(v_ru_24x2_24112_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_x_24117, v_n_24116})});
    }
    default: return heff_nomatch(v_x21_24114);
    }
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam21(V self, V *args) {
  V v_n_24118 = args[0];
  heff_drop(v_n_24118);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str14)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam22(V self, V *args) {
  V v_n_24119 = args[0];
  heff_drop(v_n_24119);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str15)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam23(V self, V *args) {
  V v_n_24120 = args[0];
  heff_drop(v_n_24120);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str16)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam24(V self, V *args) {
  V v_n_24122 = args[0];
  heff_drop(v_n_24122);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str17)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam25(V self, V *args) {
  V v_n_24124 = args[0];
  heff_drop(v_n_24124);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str18)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam26(V self, V *args) {
  V v_n_24125 = args[0];
  heff_drop(v_n_24125);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str19)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam28(V self, V *args) {
  V v_p_24146 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24141 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eerase_2earmOf_24s627775745x609415035(v_c_240, v_x_24141, v_ty_242, v_p_24146));
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam27(V self, V *args) {
  V v_n_24129 = args[0];
  V v_m_24128 = heff_env(self)[0];
  V v_cases_24127 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24130 = heff_tr(heff_apply(v_m_24128, 1, (V[]){v_n_24129}));
  switch (heff_tag_of(v_x2_24130)) {
  case TAG_Left: {
    V v_e_24131 = heff_field(v_x2_24130, 0);
    V v_ru_24x2_24130_24Left = heff_take_reuse_n(v_x2_24130, 1ULL, 1);
    heff_drop(v_cases_24127);
    heff_drop(v_c_240);
    heff_drop(v_ty_242);
    return heff_tag_at(v_ru_24x2_24130_24Left, TAG_Left, 1, (V[]){v_e_24131});
  }
  case TAG_Right: {
    V v_x21_24132 = heff_field(v_x2_24130, 0);
    V v_ru_24x2_24130_24Right = heff_take_reuse_n(v_x2_24130, 1ULL, 1);
    switch (heff_tag_of(v_x21_24132)) {
    case TAG_MkPair: {
      V v_x_24133 = heff_field(v_x21_24132, 0);
      V v_n_24134 = heff_field(v_x21_24132, 1);
      V v_ru_24x21_24132_24MkPair = heff_take_reuse_n(v_x21_24132, 3ULL, 2);
      switch (heff_tag_of(v_x_24133)) {
      case TAG_MkPair: {
        V v_s_27_24135 = heff_field(v_x_24133, 0);
        V v_sty_24136 = heff_field(v_x_24133, 1);
        heff_take_n(v_x_24133, 3ULL, 2);
        V v_m_24137 = (g_heff_2eerase_2ematchVariants(v_sty_24136));
        V v_x2_24138 = heff_tr(heff_apply(v_m_24137, 1, (V[]){v_n_24134}));
        switch (heff_tag_of(v_x2_24138)) {
        case TAG_Left: {
          V v_e_24139 = heff_field(v_x2_24138, 0);
          heff_take_n(v_x2_24138, 1ULL, 1);
          heff_drop(v_cases_24127);
          heff_drop(v_c_240);
          heff_drop(v_ty_242);
          heff_drop_cell(v_ru_24x21_24132_24MkPair, 2);
          heff_drop(v_s_27_24135);
          return heff_tag_at(v_ru_24x2_24130_24Right, TAG_Left, 1, (V[]){v_e_24139});
        }
        case TAG_Right: {
          V v_x21_24140 = heff_field(v_x2_24138, 0);
          heff_take_n(v_x2_24138, 1ULL, 1);
          switch (heff_tag_of(v_x21_24140)) {
          case TAG_MkPair: {
            V v_x_24141 = heff_field(v_x21_24140, 0);
            V v_n_24142 = heff_field(v_x21_24140, 1);
            heff_take_n(v_x21_24140, 3ULL, 2);
            V v_t_24143 = heff_arrayToList(heff_get(heff_dup(v_cases_24127), LBL_keys));
            V v_t_24144 = heff_arrayToList(heff_get(v_cases_24127, LBL_values));
            V v_t_24145 = (g_heff_2edict_2ezipKV(v_t_24143, v_t_24144));
            V v_m_24147 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam28, 1, 3, (V[]){v_c_240, v_x_24141, v_ty_242}), v_t_24145));
            V v_x2_24148 = heff_tr(heff_apply(v_m_24147, 1, (V[]){v_n_24142}));
            switch (heff_tag_of(v_x2_24148)) {
            case TAG_Left: {
              V v_e_24149 = heff_field(v_x2_24148, 0);
              heff_take_n(v_x2_24148, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_24132_24MkPair, 2);
              heff_drop(v_s_27_24135);
              return heff_tag_at(v_ru_24x2_24130_24Right, TAG_Left, 1, (V[]){v_e_24149});
            }
            case TAG_Right: {
              V v_x21_24150 = heff_field(v_x2_24148, 0);
              heff_take_n(v_x2_24148, 1ULL, 1);
              switch (heff_tag_of(v_x21_24150)) {
              case TAG_MkPair: {
                V v_x_24151 = heff_field(v_x21_24150, 0);
                V v_n_24152 = heff_field(v_x21_24150, 1);
                heff_take_n(v_x21_24150, 3ULL, 2);
                V v_t_24153 = heff_tag_at(v_ru_24x21_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_27_24135, v_x_24151}), v_n_24152});
                return heff_tag_at(v_ru_24x2_24130_24Right, TAG_Right, 1, (V[]){v_t_24153});
              }
              default: return heff_nomatch(v_x21_24150);
              }
            }
            default: return heff_nomatch(v_x2_24148);
            }
          }
          default: return heff_nomatch(v_x21_24140);
          }
        }
        default: return heff_nomatch(v_x2_24138);
        }
      }
      default: return heff_nomatch(v_x_24133);
      }
    }
    default: return heff_nomatch(v_x21_24132);
    }
  }
  default: return heff_nomatch(v_x2_24130);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam29(V self, V *args) {
  V v_n_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24159 = heff_tr(heff_apply(v_m_24157, 1, (V[]){v_n_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_Left: {
    V v_e_24160 = heff_field(v_x2_24159, 0);
    V v_ru_24x2_24159_24Left = heff_take_reuse_n(v_x2_24159, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24159_24Left, TAG_Left, 1, (V[]){v_e_24160});
  }
  case TAG_Right: {
    V v_x21_24161 = heff_field(v_x2_24159, 0);
    V v_ru_24x2_24159_24Right = heff_take_reuse_n(v_x2_24159, 1ULL, 1);
    switch (heff_tag_of(v_x21_24161)) {
    case TAG_MkPair: {
      V v_x_24162 = heff_field(v_x21_24161, 0);
      V v_n_24163 = heff_field(v_x21_24161, 1);
      heff_take_n(v_x21_24161, 3ULL, 2);
      switch (heff_tag_of(v_x_24162)) {
      case TAG_MkPair: {
        V v_t_27_24164 = heff_field(v_x_24162, 0);
        heff_take_n(v_x_24162, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24159_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24164, v_n_24163})});
      }
      default: return heff_nomatch(v_x_24162);
      }
    }
    default: return heff_nomatch(v_x21_24161);
    }
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam30(V self, V *args) {
  V v_n_24167 = args[0];
  heff_drop(v_n_24167);
  return heff_tag(TAG_Left, 1, (V[]){((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str20)});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam31(V self, V *args) {
  V v_n_24168 = args[0];
  V v_t_24169 = heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_n_24168});
  return heff_tag(TAG_Right, 1, (V[]){v_t_24169});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam33(V self, V *args) {
  V v_u_24189 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24189);
  return v_ty_242;
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam34(V self, V *args) {
  V v_u_24191 = args[0];
  V v_v_24190 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24191);
  return v_v_24190;
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam32(V self, V *args) {
  V v_n_24175 = args[0];
  V v_x_24173 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_body_24174 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24176 = heff_strEq(heff_dup(v_x_24173), ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str21));
  V v_base_24178;
  switch (heff_tag_of(v_t_24176)) {
  case TAG_True: {
    heff_drop(v_x_24173);
    v_base_24178 = ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str22);
    break;
  }
  case TAG_False: {
    V v_t_24177 = heff_strEq(heff_dup(v_x_24173), ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str23));
    switch (heff_tag_of(v_t_24177)) {
    case TAG_True: {
      heff_drop(v_x_24173);
      v_base_24178 = ((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str24);
      break;
    }
    case TAG_False: {
      v_base_24178 = v_x_24173;
      break;
    }
    default: heff_nomatch(v_t_24177);
    }
    break;
  }
  default: heff_nomatch(v_t_24176);
  }
  V v_t_24179 = heff_strAppend(v_base_24178, heff_strAppend(((V)&g_heff_2eerase_2echkF_24s2078926067x1185053013_str25), heff_intShow(heff_dup(v_n_24175))));
  V v_t_24180 = heff_tag(TAG_MkPair, 2, (V[]){v_t_24179, heff_intAdd(v_n_24175, MK_INT(1LL))});
  V v_x2_24181 = heff_tag(TAG_Right, 1, (V[]){v_t_24180});
  switch (heff_tag_of(v_x2_24181)) {
  case TAG_Left: {
    V v_e_24182 = heff_field(v_x2_24181, 0);
    V v_ru_24x2_24181_24Left = heff_take_reuse_n(v_x2_24181, 1ULL, 1);
    heff_drop(v_ty_242);
    heff_drop(v_c_240);
    heff_drop(v_body_24174);
    return heff_tag_at(v_ru_24x2_24181_24Left, TAG_Left, 1, (V[]){v_e_24182});
  }
  case TAG_Right: {
    V v_x21_24183 = heff_field(v_x2_24181, 0);
    V v_ru_24x2_24181_24Right = heff_take_reuse_n(v_x2_24181, 1ULL, 1);
    switch (heff_tag_of(v_x21_24183)) {
    case TAG_MkPair: {
      V v_x_24184 = heff_field(v_x21_24183, 0);
      V v_n_24185 = heff_field(v_x21_24183, 1);
      V v_ru_24x21_24183_24MkPair = heff_take_reuse_n(v_x21_24183, 3ULL, 2);
      V v_t_24186 = heff_tag_at(v_ru_24x2_24181_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24184)})});
      V v_t_24187 = heff_tag_at(v_ru_24x21_24183_24MkPair, TAG_Cons, 2, (V[]){heff_rec(2, shape_ir__ty, (V[]){v_t_24186, heff_dup(v_ty_242)}), heff_get(heff_dup(v_c_240), LBL_locals)});
      V v_t_24188 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
      V v_v_24190 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_24188, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam33, 1, 1, (V[]){heff_dup(v_ty_242)}), NTAG(TAG_Nothing)));
      V v_t_24192 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkF_24s2078926067x1185053013_lam34, 1, 1, (V[]){v_v_24190})});
      V v_t_24193 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
      V v_c_24194 = heff_rec(4, shape_locals__env__len__globals, (V[]){v_t_24187, v_t_24192, v_t_24193, heff_get(v_c_240, LBL_globals)});
      V v_m_24195 = (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_24194, v_body_24174, v_ty_242));
      V v_x2_24196 = heff_tr(heff_apply(v_m_24195, 1, (V[]){v_n_24185}));
      switch (heff_tag_of(v_x2_24196)) {
      case TAG_Left: {
        V v_e_24197 = heff_field(v_x2_24196, 0);
        V v_ru_24x2_24196_24Left = heff_take_reuse_n(v_x2_24196, 1ULL, 1);
        heff_drop(v_x_24184);
        return heff_tag_at(v_ru_24x2_24196_24Left, TAG_Left, 1, (V[]){v_e_24197});
      }
      case TAG_Right: {
        V v_x21_24198 = heff_field(v_x2_24196, 0);
        V v_ru_24x2_24196_24Right = heff_take_reuse_n(v_x2_24196, 1ULL, 1);
        switch (heff_tag_of(v_x21_24198)) {
        case TAG_MkPair: {
          V v_x_24199 = heff_field(v_x21_24198, 0);
          V v_n_24200 = heff_field(v_x21_24198, 1);
          V v_ru_24x21_24198_24MkPair = heff_take_reuse_n(v_x21_24198, 3ULL, 2);
          V v_t_24201 = heff_tag_at(v_ru_24x21_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EFix, 2, (V[]){v_x_24184, v_x_24199}), v_n_24200});
          return heff_tag_at(v_ru_24x2_24196_24Right, TAG_Right, 1, (V[]){v_t_24201});
        }
        default: return heff_nomatch(v_x21_24198);
        }
      }
      default: return heff_nomatch(v_x2_24196);
      }
    }
    default: return heff_nomatch(v_x21_24183);
    }
  }
  default: return heff_nomatch(v_x2_24181);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam35(V self, V *args) {
  V v_n_24206 = args[0];
  V v_x_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24207 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrim, 1, (V[]){v_x_24205}), v_n_24206});
  return heff_tag(TAG_Right, 1, (V[]){v_t_24207});
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam36(V self, V *args) {
  V v_n_24212 = args[0];
  V v_m_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24213 = heff_tr(heff_apply(v_m_24211, 1, (V[]){v_n_24212}));
  switch (heff_tag_of(v_x2_24213)) {
  case TAG_Left: {
    V v_e_24214 = heff_field(v_x2_24213, 0);
    V v_ru_24x2_24213_24Left = heff_take_reuse_n(v_x2_24213, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24213_24Left, TAG_Left, 1, (V[]){v_e_24214});
  }
  case TAG_Right: {
    V v_x21_24215 = heff_field(v_x2_24213, 0);
    V v_ru_24x2_24213_24Right = heff_take_reuse_n(v_x2_24213, 1ULL, 1);
    switch (heff_tag_of(v_x21_24215)) {
    case TAG_MkPair: {
      V v_x_24216 = heff_field(v_x21_24215, 0);
      V v_n_24217 = heff_field(v_x21_24215, 1);
      heff_take_n(v_x21_24215, 3ULL, 2);
      switch (heff_tag_of(v_x_24216)) {
      case TAG_MkPair: {
        V v_t_27_24218 = heff_field(v_x_24216, 0);
        heff_take_n(v_x_24216, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24213_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24218, v_n_24217})});
      }
      default: return heff_nomatch(v_x_24216);
      }
    }
    default: return heff_nomatch(v_x21_24215);
    }
  }
  default: return heff_nomatch(v_x2_24213);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam37(V self, V *args) {
  V v_n_24222 = args[0];
  V v_m_24221 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24223 = heff_tr(heff_apply(v_m_24221, 1, (V[]){v_n_24222}));
  switch (heff_tag_of(v_x2_24223)) {
  case TAG_Left: {
    V v_e_24224 = heff_field(v_x2_24223, 0);
    V v_ru_24x2_24223_24Left = heff_take_reuse_n(v_x2_24223, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24223_24Left, TAG_Left, 1, (V[]){v_e_24224});
  }
  case TAG_Right: {
    V v_x21_24225 = heff_field(v_x2_24223, 0);
    V v_ru_24x2_24223_24Right = heff_take_reuse_n(v_x2_24223, 1ULL, 1);
    switch (heff_tag_of(v_x21_24225)) {
    case TAG_MkPair: {
      V v_x_24226 = heff_field(v_x21_24225, 0);
      V v_n_24227 = heff_field(v_x21_24225, 1);
      heff_take_n(v_x21_24225, 3ULL, 2);
      switch (heff_tag_of(v_x_24226)) {
      case TAG_MkPair: {
        V v_t_27_24228 = heff_field(v_x_24226, 0);
        heff_take_n(v_x_24226, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24223_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24228, v_n_24227})});
      }
      default: return heff_nomatch(v_x_24226);
      }
    }
    default: return heff_nomatch(v_x21_24225);
    }
  }
  default: return heff_nomatch(v_x2_24223);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam38(V self, V *args) {
  V v_n_24232 = args[0];
  V v_m_24231 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24233 = heff_tr(heff_apply(v_m_24231, 1, (V[]){v_n_24232}));
  switch (heff_tag_of(v_x2_24233)) {
  case TAG_Left: {
    V v_e_24234 = heff_field(v_x2_24233, 0);
    V v_ru_24x2_24233_24Left = heff_take_reuse_n(v_x2_24233, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24233_24Left, TAG_Left, 1, (V[]){v_e_24234});
  }
  case TAG_Right: {
    V v_x21_24235 = heff_field(v_x2_24233, 0);
    V v_ru_24x2_24233_24Right = heff_take_reuse_n(v_x2_24233, 1ULL, 1);
    switch (heff_tag_of(v_x21_24235)) {
    case TAG_MkPair: {
      V v_x_24236 = heff_field(v_x21_24235, 0);
      V v_n_24237 = heff_field(v_x21_24235, 1);
      heff_take_n(v_x21_24235, 3ULL, 2);
      switch (heff_tag_of(v_x_24236)) {
      case TAG_MkPair: {
        V v_t_27_24238 = heff_field(v_x_24236, 0);
        heff_take_n(v_x_24236, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24233_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24238, v_n_24237})});
      }
      default: return heff_nomatch(v_x_24236);
      }
    }
    default: return heff_nomatch(v_x21_24235);
    }
  }
  default: return heff_nomatch(v_x2_24233);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam39(V self, V *args) {
  V v_n_24242 = args[0];
  V v_m_24241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24243 = heff_tr(heff_apply(v_m_24241, 1, (V[]){v_n_24242}));
  switch (heff_tag_of(v_x2_24243)) {
  case TAG_Left: {
    V v_e_24244 = heff_field(v_x2_24243, 0);
    V v_ru_24x2_24243_24Left = heff_take_reuse_n(v_x2_24243, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24243_24Left, TAG_Left, 1, (V[]){v_e_24244});
  }
  case TAG_Right: {
    V v_x21_24245 = heff_field(v_x2_24243, 0);
    V v_ru_24x2_24243_24Right = heff_take_reuse_n(v_x2_24243, 1ULL, 1);
    switch (heff_tag_of(v_x21_24245)) {
    case TAG_MkPair: {
      V v_x_24246 = heff_field(v_x21_24245, 0);
      V v_n_24247 = heff_field(v_x21_24245, 1);
      heff_take_n(v_x21_24245, 3ULL, 2);
      switch (heff_tag_of(v_x_24246)) {
      case TAG_MkPair: {
        V v_t_27_24248 = heff_field(v_x_24246, 0);
        heff_take_n(v_x_24246, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24243_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24248, v_n_24247})});
      }
      default: return heff_nomatch(v_x_24246);
      }
    }
    default: return heff_nomatch(v_x21_24245);
    }
  }
  default: return heff_nomatch(v_x2_24243);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam40(V self, V *args) {
  V v_n_24253 = args[0];
  V v_m_24252 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24254 = heff_tr(heff_apply(v_m_24252, 1, (V[]){v_n_24253}));
  switch (heff_tag_of(v_x2_24254)) {
  case TAG_Left: {
    V v_e_24255 = heff_field(v_x2_24254, 0);
    V v_ru_24x2_24254_24Left = heff_take_reuse_n(v_x2_24254, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24254_24Left, TAG_Left, 1, (V[]){v_e_24255});
  }
  case TAG_Right: {
    V v_x21_24256 = heff_field(v_x2_24254, 0);
    V v_ru_24x2_24254_24Right = heff_take_reuse_n(v_x2_24254, 1ULL, 1);
    switch (heff_tag_of(v_x21_24256)) {
    case TAG_MkPair: {
      V v_x_24257 = heff_field(v_x21_24256, 0);
      V v_n_24258 = heff_field(v_x21_24256, 1);
      heff_take_n(v_x21_24256, 3ULL, 2);
      switch (heff_tag_of(v_x_24257)) {
      case TAG_MkPair: {
        V v_t_27_24259 = heff_field(v_x_24257, 0);
        heff_take_n(v_x_24257, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24254_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24259, v_n_24258})});
      }
      default: return heff_nomatch(v_x_24257);
      }
    }
    default: return heff_nomatch(v_x21_24256);
    }
  }
  default: return heff_nomatch(v_x2_24254);
  }
}
V g_heff_2eerase_2echkF_24s2078926067x1185053013_lam41(V self, V *args) {
  V v_n_24263 = args[0];
  V v_m_24262 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24264 = heff_tr(heff_apply(v_m_24262, 1, (V[]){v_n_24263}));
  switch (heff_tag_of(v_x2_24264)) {
  case TAG_Left: {
    V v_e_24265 = heff_field(v_x2_24264, 0);
    V v_ru_24x2_24264_24Left = heff_take_reuse_n(v_x2_24264, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_24264_24Left, TAG_Left, 1, (V[]){v_e_24265});
  }
  case TAG_Right: {
    V v_x21_24266 = heff_field(v_x2_24264, 0);
    V v_ru_24x2_24264_24Right = heff_take_reuse_n(v_x2_24264, 1ULL, 1);
    switch (heff_tag_of(v_x21_24266)) {
    case TAG_MkPair: {
      V v_x_24267 = heff_field(v_x21_24266, 0);
      V v_n_24268 = heff_field(v_x21_24266, 1);
      heff_take_n(v_x21_24266, 3ULL, 2);
      switch (heff_tag_of(v_x_24267)) {
      case TAG_MkPair: {
        V v_t_27_24269 = heff_field(v_x_24267, 0);
        heff_take_n(v_x_24267, 1ULL, 2);
        return heff_tag_at(v_ru_24x2_24264_24Right, TAG_Right, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_27_24269, v_n_24268})});
      }
      default: return heff_nomatch(v_x_24267);
      }
    }
    default: return heff_nomatch(v_x21_24266);
    }
  }
  default: return heff_nomatch(v_x2_24264);
  }
}
V g_heff_2eerase_2echkDField_24s1687259509x1664563092_lam0(V self, V *args);
Clo g_heff_2eerase_2echkDField_24s1687259509x1664563092_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkDField_24s1687259509x1664563092_entry, 5, 0};

V g_heff_2eerase_2echkDField_24s1687259509x1664563092(V v_c_240, V v_ty_241, V v_v_242, V v_fs_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkPair: {
    V v_l_245 = heff_field(v_x6_244, 0);
    V v_fe_246 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_m_247 = (g_heff_2eerase_2eprojTyInWith(heff_get(heff_dup(v_c_240), LBL_len), v_ty_241, heff_dup(v_fs_243), heff_dup(v_l_245)));
    return heff_clo(g_heff_2eerase_2echkDField_24s1687259509x1664563092_lam0, 1, 6, (V[]){v_m_247, v_c_240, v_fs_243, v_v_242, v_l_245, v_fe_246});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eerase_2echkDField_24s1687259509x1664563092_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkDField_24s1687259509x1664563092(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eerase_2echkDField_24s1687259509x1664563092_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fs_243 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_l_245 = heff_env(self)[4];
  V v_fe_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_fs_243);
    heff_drop(v_v_242);
    heff_drop(v_l_245);
    heff_drop(v_fe_246);
    return heff_tag_at(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_x_2412)));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop(v_c_240);
        heff_drop(v_fs_243);
        heff_drop(v_v_242);
        heff_drop(v_l_245);
        heff_drop(v_fe_246);
        heff_drop(v_x_2412);
        V v_t_2415 = heff_tag_at(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2413});
        return heff_tag_at(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){v_t_2415});
      }
      case TAG_False: {
        V v_x1_2416 = ({ V a_0 = v_fs_243; V a_1 = v_v_242; V a_2 = heff_dup(v_l_245); V r_ = (g_heff_2eerase_2eprojWith(a_0, a_1, a_2)); heff_drop(v_fs_243); r_; });
        V v_v_2420;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nom: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2417;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2416, 0ULL, 1);
          v_v_2420 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2419 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_m_2421 = (g_heff_2eerase_2echkDF_24s1365578804x1792227807(v_c_240, v_fe_246, v_x_2412, v_v_2420));
        V v_x2_2422 = heff_tr(heff_apply(v_m_2421, 1, (V[]){v_n_2413}));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_Left: {
          V v_e_2423 = heff_field(v_x2_2422, 0);
          heff_take_n(v_x2_2422, 1ULL, 1);
          heff_drop(v_l_245);
          heff_drop_cell(v_ru_24x21_2411_24MkPair, 2);
          return heff_tag_at(v_ru_24x2_249_24Right, TAG_Left, 1, (V[]){v_e_2423});
        }
        case TAG_Right: {
          V v_x21_2424 = heff_field(v_x2_2422, 0);
          V v_ru_24x2_2422_24Right = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
          switch (heff_tag_of(v_x21_2424)) {
          case TAG_MkPair: {
            V v_x_2425 = heff_field(v_x21_2424, 0);
            V v_n_2426 = heff_field(v_x21_2424, 1);
            heff_take_n(v_x21_2424, 3ULL, 2);
            V v_t_2427 = heff_tag_at(v_ru_24x2_249_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_245, v_x_2425})});
            return heff_tag_at(v_ru_24x2_2422_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2427, v_n_2426})});
          }
          default: return heff_nomatch(v_x21_2424);
          }
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2eerase_2echkDFields_24s67152714x898921336_lam0(V self, V *args);
V g_heff_2eerase_2echkDFields_24s67152714x898921336_lam1(V self, V *args);
Clo g_heff_2eerase_2echkDFields_24s67152714x898921336_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkDFields_24s67152714x898921336_entry, 5, 0};

V g_heff_2eerase_2echkDFields_24s67152714x898921336(V v_c_240, V v_ty_241, V v_v_242, V v_ps_243, V v_fs_244) {
top: ;
  V v_m_246 = (g_heff_2eerase_2etraverseM(heff_clo(g_heff_2eerase_2echkDFields_24s67152714x898921336_lam0, 1, 4, (V[]){v_c_240, v_ty_241, v_v_242, v_fs_244}), v_ps_243));
  return heff_clo(g_heff_2eerase_2echkDFields_24s67152714x898921336_lam1, 1, 1, (V[]){v_m_246});
}
V g_heff_2eerase_2echkDFields_24s67152714x898921336_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkDFields_24s67152714x898921336(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eerase_2echkDFields_24s67152714x898921336_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ty_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_fs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eerase_2echkDField_24s1687259509x1664563092(v_c_240, v_ty_241, v_v_242, v_fs_244, v_p_245));
}
V g_heff_2eerase_2echkDFields_24s67152714x898921336_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    return heff_tag_at(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_x_2413 = heff_tag_at(v_ru_24x2_248_24Right, TAG_ERecord, 1, (V[]){(g_heff_2eerase_2ecatMaybesE(v_x_2411))});
      return heff_tag(TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_n_2412})});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s1365578804x1792227807_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s1365578804x1792227807_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s1365578804x1792227807_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s1365578804x1792227807_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s1365578804x1792227807_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eerase_2echkDF_24s1365578804x1792227807_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam0(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam1(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam3(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam2(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam5(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam4(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam7(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam8(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam10(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam9(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam12(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam11(V self, V *args);
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam6(V self, V *args);
Clo g_heff_2eerase_2echkDF_24s1365578804x1792227807_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2echkDF_24s1365578804x1792227807_entry, 4, 0};

V g_heff_2eerase_2echkDF_24s1365578804x1792227807(V v_c_240, V v_t_241, V v_ty_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SGlobal: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SCode: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SApp: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLam: {
    V v_abs_2410 = heff_dup(heff_field(v_t_241, 1));
    V v_t_2411 = (g_heff_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      V v_dom_2414 = heff_field(v_t_2411, 1);
      V v_cod_2415 = heff_field(v_t_2411, 2);
      heff_take_n(v_t_2411, 6ULL, 4);
      heff_drop_tag(v_t_241, 2);
      heff_drop(v_ty_242);
      V v_it_2422;
      switch (heff_tag_of(v_abs_2410)) {
      case TAG_MkAbs: {
        V v_n_2417 = heff_field(v_abs_2410, 0);
        V v_b_2418 = heff_field(v_abs_2410, 1);
        V v_ru_24abs_2410_24MkAbs = heff_take_reuse_n(v_abs_2410, 3ULL, 2);
        V v_t_2419 = heff_tag_at(v_ru_24abs_2410_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2417, NTAG(TAG_True)});
        v_it_2422 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2419, v_b_2418});
        break;
      }
      case TAG_AbsConst: {
        V v_b_2420 = heff_field(v_abs_2410, 0);
        heff_take_n(v_abs_2410, 1ULL, 1);
        V v_t_2421 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eerase_2echkDF_24s1365578804x1792227807_str0), NTAG(TAG_False)});
        v_it_2422 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2421, v_b_2420});
        break;
      }
      default: heff_nomatch(v_abs_2410);
      }
      switch (heff_tag_of(v_it_2422)) {
      case TAG_MkPair: {
        V v_it1_2423 = heff_field(v_it_2422, 0);
        V v_body_2424 = heff_field(v_it_2422, 1);
        V v_ru_24it_2422_24MkPair = heff_take_reuse_n(v_it_2422, 3ULL, 2);
        switch (heff_tag_of(v_it1_2423)) {
        case TAG_MkPair: {
          V v_hint_2425 = heff_field(v_it1_2423, 0);
          V v_bound_2426 = heff_field(v_it1_2423, 1);
          V v_ru_24it1_2423_24MkPair = heff_take_reuse_n(v_it1_2423, 3ULL, 2);
          V v_t_2427 = (g_heff_2eerase_2eisType(heff_get(heff_dup(v_c_240), LBL_len), heff_dup(v_dom_2414)));
          switch (heff_tag_of(v_t_2427)) {
          case TAG_True: {
            heff_drop(v_hint_2425);
            V v_c_2436;
            switch (heff_tag_of(v_bound_2426)) {
            case TAG_True: {
              V v_t_2428 = heff_rec(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_2414)});
              V v_t_2429 = heff_tag_at(v_ru_24it_2422_24MkPair, TAG_Cons, 2, (V[]){v_t_2428, heff_get(heff_dup(v_c_240), LBL_locals)});
              V v_t_2430 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
              V v_v_2432 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2430, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam0, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
              V v_t_2434 = heff_tag_at(v_ru_24it1_2423_24MkPair, TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam1, 1, 1, (V[]){v_v_2432})});
              V v_t_2435 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
              v_c_2436 = heff_rec(4, shape_locals__env__len__globals, (V[]){v_t_2429, v_t_2434, v_t_2435, heff_get(heff_dup(v_c_240), LBL_globals)});
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_2422_24MkPair, 2);
              heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
              v_c_2436 = heff_dup(v_c_240);
              break;
            }
            default: heff_nomatch(v_bound_2426);
            }
            V v_x1_2444;
            switch (heff_tag_of(v_cod_2415)) {
            case TAG_MkClo: {
              V v_vs_2438 = heff_field(v_cod_2415, 1);
              V v_body_2439 = heff_field(v_cod_2415, 2);
              heff_take_n(v_cod_2415, 6ULL, 3);
              v_x1_2444 = heff_tr(heff_apply(v_body_2439, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2438, heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam2, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2443 = heff_field(v_cod_2415, 0);
              heff_take_n(v_cod_2415, 1ULL, 1);
              v_x1_2444 = v_body_2443;
              break;
            }
            default: heff_nomatch(v_cod_2415);
            }
            V v_ty_2448;
            switch (heff_tag_of(v_x1_2444)) {
            case TAG_Nom: {
              V v_x_2445 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2445;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2444, 0ULL, 1);
              v_ty_2448 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2447 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2447;
              break;
            }
            default: heff_nomatch(v_x1_2444);
            }
            V v_x1_2452 = heff_tr(g_heff_2evalue_2eapp(v_v_243, heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam4, 1, 2, (V[]){v_c_240, v_dom_2414})));
            V v_v_2456;
            switch (heff_tag_of(v_x1_2452)) {
            case TAG_Nom: {
              V v_x_2453 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2453;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2452, 0ULL, 1);
              v_v_2456 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2455 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2455;
              break;
            }
            default: heff_nomatch(v_x1_2452);
            }
            V t_0 = v_c_2436;
            V t_1 = v_body_2424;
            V t_2 = v_ty_2448;
            V t_3 = v_v_2456;
            v_c_240 = t_0;
            v_t_241 = t_1;
            v_ty_242 = t_2;
            v_v_243 = t_3;
            goto top;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24it_2422_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
            return heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam6, 1, 7, (V[]){v_hint_2425, v_bound_2426, v_dom_2414, v_c_240, v_cod_2415, v_v_243, v_body_2424});
          }
          default: return heff_nomatch(v_t_2427);
          }
        }
        default: return heff_nomatch(v_it1_2423);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2411, 0ULL, 3);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_SCons: {
    V v_d_24111 = heff_dup(heff_field(v_t_241, 0));
    V v_t_24112 = (g_heff_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_24112)) {
    case TAG_LikeU: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_24112, 0ULL, 4);
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_24112, 0ULL, 3);
      heff_drop_tag(v_t_241, 1);
      V v_t_24121 = heff_arrayToList(heff_get(heff_dup(v_d_24111), LBL_keys));
      V v_t_24122 = heff_arrayToList(heff_get(v_d_24111, LBL_values));
      V v_t_24123 = (g_heff_2edict_2ezipKV(v_t_24121, v_t_24122));
      V v_t_24124 = (g_heff_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_243)));
      return (g_heff_2eerase_2echkDFields_24s67152714x898921336(v_c_240, v_ty_242, v_v_243, v_t_24123, v_t_24124));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_d_24111);
      return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_24112);
    }
  }
  case TAG_SProj: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_STag: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMatch: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SSpecialize: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SIs: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SOpaque: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SAbandon: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SRec: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SFix: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SImplicit: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SPrim: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMetaApp: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitInt: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFloat: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitString: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFixed: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFloat32: {
    heff_drop(v_v_243);
    return (g_heff_2eerase_2echkF_24s2078926067x1185053013(v_c_240, v_t_241, v_ty_242));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2echkDF_24s1365578804x1792227807(a[0], a[1], a[2], a[3]);
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam0(V self, V *args) {
  V v_u_2431 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_v_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_v_2432;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam3(V self, V *args) {
  V v_u_2442 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2440);
  V v_t_2441 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2441, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam3, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2451);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam4(V self, V *args) {
  V v_u_2449 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2449);
  V v_t_2450 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2450, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam5, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam7(V self, V *args) {
  V v_u_2471 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2471);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam8(V self, V *args) {
  V v_u_2473 = args[0];
  V v_v_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return v_v_2472;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam10(V self, V *args) {
  V v_u_2482 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2482);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam9(V self, V *args) {
  V v_u_2480 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2480);
  V v_t_2481 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2481, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam10, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam12(V self, V *args) {
  V v_u_2491 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  return v_dom_2414;
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam11(V self, V *args) {
  V v_u_2489 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2489);
  V v_t_2490 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(v_c_240, LBL_len)});
  return (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2490, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam12, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam6(V self, V *args) {
  V v_n_2457 = args[0];
  V v_hint_2425 = heff_env(self)[0];
  V v_bound_2426 = heff_env(self)[1];
  V v_dom_2414 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_cod_2415 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_body_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2458 = heff_strEq(heff_dup(v_hint_2425), ((V)&g_heff_2eerase_2echkDF_24s1365578804x1792227807_str1));
  V v_base_2460;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_True: {
    heff_drop(v_hint_2425);
    v_base_2460 = ((V)&g_heff_2eerase_2echkDF_24s1365578804x1792227807_str2);
    break;
  }
  case TAG_False: {
    V v_t_2459 = heff_strEq(heff_dup(v_hint_2425), ((V)&g_heff_2eerase_2echkDF_24s1365578804x1792227807_str3));
    switch (heff_tag_of(v_t_2459)) {
    case TAG_True: {
      heff_drop(v_hint_2425);
      v_base_2460 = ((V)&g_heff_2eerase_2echkDF_24s1365578804x1792227807_str4);
      break;
    }
    case TAG_False: {
      v_base_2460 = v_hint_2425;
      break;
    }
    default: heff_nomatch(v_t_2459);
    }
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  V v_t_2461 = heff_strAppend(v_base_2460, heff_strAppend(((V)&g_heff_2eerase_2echkDF_24s1365578804x1792227807_str5), heff_intShow(heff_dup(v_n_2457))));
  V v_t_2462 = heff_tag(TAG_MkPair, 2, (V[]){v_t_2461, heff_intAdd(v_n_2457, MK_INT(1LL))});
  V v_x2_2463 = heff_tag(TAG_Right, 1, (V[]){v_t_2462});
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_Left: {
    V v_e_2464 = heff_field(v_x2_2463, 0);
    V v_ru_24x2_2463_24Left = heff_take_reuse_n(v_x2_2463, 1ULL, 1);
    heff_drop(v_bound_2426);
    heff_drop(v_dom_2414);
    heff_drop(v_c_240);
    heff_drop(v_cod_2415);
    heff_drop(v_v_243);
    heff_drop(v_body_2424);
    return heff_tag_at(v_ru_24x2_2463_24Left, TAG_Left, 1, (V[]){v_e_2464});
  }
  case TAG_Right: {
    V v_x21_2465 = heff_field(v_x2_2463, 0);
    V v_ru_24x2_2463_24Right = heff_take_reuse_n(v_x2_2463, 1ULL, 1);
    switch (heff_tag_of(v_x21_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x21_2465, 0);
      V v_n_2467 = heff_field(v_x21_2465, 1);
      V v_ru_24x21_2465_24MkPair = heff_take_reuse_n(v_x21_2465, 3ULL, 2);
      V v_c_2476;
      switch (heff_tag_of(v_bound_2426)) {
      case TAG_True: {
        V v_t_2468 = heff_tag_at(v_ru_24x2_2463_24Right, TAG_Just, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2466)})});
        V v_t_2469 = heff_tag_at(v_ru_24x21_2465_24MkPair, TAG_Cons, 2, (V[]){heff_rec(2, shape_ir__ty, (V[]){v_t_2468, heff_dup(v_dom_2414)}), heff_get(heff_dup(v_c_240), LBL_locals)});
        V v_t_2470 = heff_tag(TAG_HLocal, 1, (V[]){heff_get(heff_dup(v_c_240), LBL_len)});
        V v_v_2472 = (g_heff_2evalue_2emkNeu_24s1912479565x1511825694(v_t_2470, NTAG(TAG_SpId), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam7, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
        V v_t_2474 = heff_tag(TAG_LSnoc, 2, (V[]){heff_get(heff_dup(v_c_240), LBL_env), heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam8, 1, 1, (V[]){v_v_2472})});
        V v_t_2475 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_len), MK_INT(1LL));
        v_c_2476 = heff_rec(4, shape_locals__env__len__globals, (V[]){v_t_2469, v_t_2474, v_t_2475, heff_get(heff_dup(v_c_240), LBL_globals)});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_2463_24Right, 1);
        heff_drop_cell(v_ru_24x21_2465_24MkPair, 2);
        v_c_2476 = heff_dup(v_c_240);
        break;
      }
      default: heff_nomatch(v_bound_2426);
      }
      V v_x1_2484;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_vs_2478 = heff_field(v_cod_2415, 1);
        V v_body_2479 = heff_field(v_cod_2415, 2);
        heff_take_n(v_cod_2415, 6ULL, 3);
        v_x1_2484 = heff_tr(heff_apply(v_body_2479, 1, (V[]){heff_tag(TAG_LSnoc, 2, (V[]){v_vs_2478, heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam9, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2483 = heff_field(v_cod_2415, 0);
        heff_take_n(v_cod_2415, 1ULL, 1);
        v_x1_2484 = v_body_2483;
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_ty_2488;
      switch (heff_tag_of(v_x1_2484)) {
      case TAG_Nom: {
        V v_x_2485 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        v_ty_2488 = v_x_2485;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2484, 0ULL, 1);
        v_ty_2488 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2487 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        v_ty_2488 = v_x_2487;
        break;
      }
      default: heff_nomatch(v_x1_2484);
      }
      V v_x1_2492 = heff_tr(g_heff_2evalue_2eapp(v_v_243, heff_clo(g_heff_2eerase_2echkDF_24s1365578804x1792227807_lam11, 1, 2, (V[]){v_c_240, v_dom_2414})));
      V v_v_2496;
      switch (heff_tag_of(v_x1_2492)) {
      case TAG_Nom: {
        V v_x_2493 = heff_field(v_x1_2492, 0);
        heff_take_n(v_x1_2492, 1ULL, 1);
        v_v_2496 = v_x_2493;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2492, 0ULL, 1);
        v_v_2496 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2495 = heff_field(v_x1_2492, 0);
        heff_take_n(v_x1_2492, 1ULL, 1);
        v_v_2496 = v_x_2495;
        break;
      }
      default: heff_nomatch(v_x1_2492);
      }
      V v_m_2497 = (g_heff_2eerase_2echkDF_24s1365578804x1792227807(v_c_2476, v_body_2424, v_ty_2488, v_v_2496));
      V v_x2_2498 = heff_tr(heff_apply(v_m_2497, 1, (V[]){v_n_2467}));
      switch (heff_tag_of(v_x2_2498)) {
      case TAG_Left: {
        V v_e_2499 = heff_field(v_x2_2498, 0);
        V v_ru_24x2_2498_24Left = heff_take_reuse_n(v_x2_2498, 1ULL, 1);
        heff_drop(v_x_2466);
        return heff_tag_at(v_ru_24x2_2498_24Left, TAG_Left, 1, (V[]){v_e_2499});
      }
      case TAG_Right: {
        V v_x21_24100 = heff_field(v_x2_2498, 0);
        V v_ru_24x2_2498_24Right = heff_take_reuse_n(v_x2_2498, 1ULL, 1);
        switch (heff_tag_of(v_x21_24100)) {
        case TAG_MkPair: {
          V v_x_24101 = heff_field(v_x21_24100, 0);
          V v_n_24102 = heff_field(v_x21_24100, 1);
          V v_ru_24x21_24100_24MkPair = heff_take_reuse_n(v_x21_24100, 3ULL, 2);
          V v_t_24103 = heff_tag_at(v_ru_24x21_24100_24MkPair, TAG_Cons, 2, (V[]){v_x_2466, NTAG(TAG_Nil)});
          V v_t_24104 = heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_24103, v_x_24101}), v_n_24102});
          return heff_tag_at(v_ru_24x2_2498_24Right, TAG_Right, 1, (V[]){v_t_24104});
        }
        default: return heff_nomatch(v_x21_24100);
        }
      }
      default: return heff_nomatch(v_x2_2498);
      }
    }
    default: return heff_nomatch(v_x21_2465);
    }
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eerase_2eeraseOne_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
V g_heff_2eerase_2eeraseOne_lam0(V self, V *args);
Clo g_heff_2eerase_2eeraseOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eeraseOne_entry, 3, 0};

V g_heff_2eerase_2eeraseOne(V v_g_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2eerase_2eisType(MK_INT(0LL), heff_get(heff_dup(v_e_244), LBL_type_5f)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_g_240);
      heff_drop(v_key_243);
      heff_drop(v_e_244);
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      return v_acc_241;
    }
    case TAG_False: {
      V v_t_246 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){heff_dup(v_key_243)})});
      V v_t_247 = heff_rec(2, shape_ir__ty, (V[]){v_t_246, heff_get(heff_dup(v_e_244), LBL_type_5f)});
      V v_t_248 = heff_tag_at(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo(g_heff_2eerase_2eeraseOne_lam0, 1, 1, (V[]){heff_dup(v_e_244)})});
      V v_t_2411 = (g_heff_2eerase_2echkDF_24s1365578804x1792227807(heff_rec(4, shape_locals__env__len__globals, (V[]){v_t_248, v_t_2410, MK_INT(1LL), v_g_240}), heff_get(heff_dup(v_e_244), LBL_syntax), heff_get(heff_dup(v_e_244), LBL_type_5f), heff_get(v_e_244, LBL_value)));
      V v_it_2412 = heff_tr(heff_apply(v_t_2411, 1, (V[]){heff_get(heff_dup(v_acc_241), LBL_supply)}));
      switch (heff_tag_of(v_it_2412)) {
      case TAG_Left: {
        V v_err_2413 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        V v_t_2414 = heff_strAppend(v_key_243, heff_strAppend(((V)&g_heff_2eerase_2eeraseOne_str0), v_err_2413));
        V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, heff_get(heff_dup(v_acc_241), LBL_errors)});
        return heff_rec(3, shape_defs__errors__supply, (V[]){heff_get(heff_dup(v_acc_241), LBL_defs), v_t_2415, heff_get(v_acc_241, LBL_supply)});
      }
      case TAG_Right: {
        V v_it1_2416 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        switch (heff_tag_of(v_it1_2416)) {
        case TAG_MkPair: {
          V v_body_2417 = heff_field(v_it1_2416, 0);
          V v_n_2418 = heff_field(v_it1_2416, 1);
          V v_ru_24it1_2416_24MkPair = heff_take_reuse_n(v_it1_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at(v_ru_24it1_2416_24MkPair, TAG_Cons, 2, (V[]){heff_rec(3, shape_key__name__body, (V[]){heff_dup(v_key_243), v_key_243, v_body_2417}), heff_get(heff_dup(v_acc_241), LBL_defs)});
          return heff_rec(3, shape_defs__errors__supply, (V[]){v_t_2419, heff_get(v_acc_241, LBL_errors), v_n_2418});
        }
        default: return heff_nomatch(v_it1_2416);
        }
      }
      default: return heff_nomatch(v_it_2412);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eerase_2eeraseOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eeraseOne(a[0], a[1], a[2]);
}
V g_heff_2eerase_2eeraseOne_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return heff_get(v_e_244, LBL_value);
}
V g_heff_2eerase_2eeraseProgram_lam0(V self, V *args);
V g_heff_2eerase_2eeraseProgram_lam1(V self, V *args);
Clo g_heff_2eerase_2eeraseProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eerase_2eeraseProgram_entry, 1, 0};

V g_heff_2eerase_2eeraseProgram(V v_g_240) {
top: ;
  V v_t_241 = heff_rec(3, shape_defs__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_246 = ({ V a_0 = heff_clo(g_heff_2eerase_2eeraseProgram_lam0, 2, 1, (V[]){heff_dup(v_g_240)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get(heff_dup(v_g_240), LBL_order); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_acc_249 = ({ V a_0 = heff_clo(g_heff_2eerase_2eeraseProgram_lam1, 2, 1, (V[]){v_g_240}); V a_1 = v_t_241; V a_2 = v_t_246; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2410 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_249), LBL_defs)));
  V v_t_2411 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_get(heff_dup(v_acc_249), LBL_errors)));
  return heff_rec(3, shape_defs__errors__supply, (V[]){v_t_2410, v_t_2411, heff_get(v_acc_249, LBL_supply)});
}
V g_heff_2eerase_2eeraseProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2eerase_2eeraseProgram(a[0]);
}
V g_heff_2eerase_2eeraseProgram_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get(v_g_240, LBL_entries); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eerase_2eeraseProgram_lam1(V self, V *args) {
  V v_acc_247 = args[0];
  V v_p_248 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eerase_2eeraseOne(v_g_240, v_acc_247, v_p_248));
}