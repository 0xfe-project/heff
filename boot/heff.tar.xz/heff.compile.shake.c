// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eshake_2eappendK(V, V);
V g_heff_2ecompile_2eshake_2eappendK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2eappendK_clo;
V g_heff_2ecompile_2eshake_2ereachBy(V, V, V);
V g_heff_2ecompile_2eshake_2ereachBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachBy_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
Clo g_heff_2ecompile_2eshake_2eappendK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eshake_2eappendK_entry, 2, 0};

V g_heff_2ecompile_2eshake_2eappendK(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ecompile_2eshake_2eappendK(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eshake_2eappendK_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eshake_2eappendK(a[0], a[1]);
}
Clo g_heff_2ecompile_2eshake_2ereachGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eshake_2ereachGo_entry, 3, 0};

V g_heff_2ecompile_2eshake_2ereachGo(V v_bodies_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_head_243 = heff_field(v_x3_242, 0);
    V v_tail_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_head_243), v_seen_241));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_head_243), NTAG(TAG_MkUnit), v_seen_241));
      V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(v_head_243, v_bodies_240));
      V v_t_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        v_t_2410 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_b_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_249 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_248));
        v_t_2410 = (g_heff_2ecompile_2eir_2enubI(v_t_249));
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_t_2411 = (g_heff_2ecompile_2eshake_2eappendK(v_t_2410, v_tail_244));
      V t_0 = v_bodies_240;
      V t_1 = v_t_246;
      V t_2 = v_t_2411;
      v_bodies_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      heff_drop(v_head_243);
      V t_0 = v_bodies_240;
      V t_1 = v_seen_241;
      V t_2 = v_tail_244;
      v_bodies_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eshake_2ereachGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eshake_2ereachBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eshake_2ereachBy_entry, 3, 0};

V g_heff_2ecompile_2eshake_2ereachBy(V v_refs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_head_243 = heff_field(v_x3_242, 0);
    V v_tail_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_head_243), v_seen_241));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_head_243), NTAG(TAG_MkUnit), v_seen_241));
      V v_x2_247 = (g_map_2elookup_24s1546226666x2146984184(v_head_243, v_refs_240));
      V v_t_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_t_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2410 = (g_heff_2ecompile_2eshake_2eappendK(v_t_249, v_tail_244));
      V t_0 = v_refs_240;
      V t_1 = v_t_246;
      V t_2 = v_t_2410;
      v_refs_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      heff_drop(v_head_243);
      V t_0 = v_refs_240;
      V t_1 = v_seen_241;
      V t_2 = v_tail_244;
      v_refs_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eshake_2ereachBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eshake_2ereachBy(a0, a[1], a[2]); heff_drop(a0); return r;
}