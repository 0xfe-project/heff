// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eshake_2eappendK(V, V);
V g_heff_2ecompile_2eshake_2eappendK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2eappendK_clo;
V g_heff_2ecompile_2eshake_2eappendK_24dps(V, V, V);
V g_heff_2ecompile_2eshake_2eappendK_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2eappendK_24dps_clo;
V g_heff_2ecompile_2eshake_2ereachBy(V, V, V);
V g_heff_2ecompile_2eshake_2ereachBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachBy_clo;
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eshake_2eappendK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eshake_2eappendK_entry, 2, 0};

V g_heff_2ecompile_2eshake_2eappendK(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eshake_2eappendK_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eshake_2eappendK_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eshake_2eappendK(a[0], a[1]);
}
Clo g_heff_2ecompile_2eshake_2eappendK_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eshake_2eappendK_24dps_entry, 3, 0};

V g_heff_2ecompile_2eshake_2eappendK_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eshake_2eappendK_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eshake_2eappendK_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eshake_2ereachGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eshake_2ereachGo_entry, 3, 0};

V g_heff_2ecompile_2eshake_2ereachGo(V v_bodies_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_head_243 = heff_field(v_x3_242, 0);
    V v_tail_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_241, v_head_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_head_243);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_bodies_240;
        V t_1 = v_seen_241;
        V t_2 = v_tail_244;
        v_bodies_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_241, heff_dup(v_head_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2410 = ({ V a_0 = v_bodies_240; V a_1 = v_head_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_head_243); r_; });
        V v_t_2415;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_b_2413 = v_field_2412;
            V v_t_2414 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2413));
            v_t_2415 = (g_heff_2ecompile_2eir_2enubI(v_t_2414));
          } else {
            heff_drop(v_field_2412);
            v_t_2415 = NTAG(TAG_Nil);
          }
        }
        V v_t_2416 = (g_heff_2ecompile_2eshake_2eappendK(v_t_2415, v_tail_244));
        V t_0 = v_bodies_240;
        V t_1 = v_t_249;
        V t_2 = v_t_2416;
        v_bodies_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eshake_2ereachGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eshake_2ereachBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eshake_2ereachBy_entry, 3, 0};

V g_heff_2ecompile_2eshake_2ereachBy(V v_refs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_head_243 = heff_field(v_x3_242, 0);
    V v_tail_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_241, v_head_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_head_243);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_refs_240;
        V t_1 = v_seen_241;
        V t_2 = v_tail_244;
        v_refs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_241, heff_dup(v_head_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2410 = ({ V a_0 = v_refs_240; V a_1 = v_head_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_head_243); r_; });
        V v_t_2414;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2412;
            v_t_2414 = v_x_2413;
          } else {
            heff_drop(v_field_2412);
            v_t_2414 = NTAG(TAG_Nil);
          }
        }
        V v_t_2415 = (g_heff_2ecompile_2eshake_2eappendK(v_t_2414, v_tail_244));
        V t_0 = v_refs_240;
        V t_1 = v_t_249;
        V t_2 = v_t_2415;
        v_refs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eshake_2ereachBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eshake_2ereachBy(a0, a[1], a[2]); heff_drop(a0); return r;
}