// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Asked 63168
#define TAG_Catch 6517
#define TAG_Done 47505
#define TAG_Ended 63166
#define TAG_HeadAt 24796
#define TAG_HeadEnded 64500
#define TAG_HeadTooLong 4872
#define TAG_Left 13886
#define TAG_Length 531
#define TAG_MkWith 3751
#define TAG_NewKey 33294
#define TAG_Next 8500
#define TAG_Park 64043
#define TAG_Peer 1965
#define TAG_Read 61409
#define TAG_Refuse 3461
#define TAG_Refused 41566
#define TAG_Right 62770
#define TAG_Shutdown 48081
#define TAG_Spawn 10053
#define TAG_Wake 10253
#define TAG_Write 36323
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_headers 1027165638
#define LBL_malg 9839318
#define LBL_method 869586956
#define LBL_peer 9932329
#define LBL_ret 322331
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_version 583465758
static uint32_t shape_method__target__version__headers__body__peer[] = {LBL_method, LBL_target, LBL_version, LBL_headers, LBL_body, LBL_peer};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
V g_bytes_2eempty_get(void);
V g_co_2e_3c_2b_3e_24s1404263853x1546533042(V);
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1404263853x1546533042_clo;
V g_co_2e_3c_2b_3e_24s1585861108x1258949188(V);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1585861108x1258949188_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1511444646x1476348587(V, V);
V g_list_2efoldl_24s1511444646x1476348587_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1511444646x1476348587_clo;
V g_list_2ekeepIf_24s280149390x2003255054(V);
V g_list_2ekeepIf_24s280149390x2003255054_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s280149390x2003255054_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_std_2ehttp_2eheaderIn_24cpr(V, V);
V g_std_2ehttp_2esameName_2esameFrom_240(V, V, V);
V g_std_2ehttp_2esameName_2esameFrom_240_entry(V self, V *a);
extern Clo g_std_2ehttp_2esameName_2esameFrom_240_clo;
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325(V, V, V, V, V);
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_clo;
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803(V, V, V, V, V);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_clo;
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818(V, V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818_clo;
V g_std_2ehttp_2eserver_2econnectionSays(V, V);
V g_std_2ehttp_2eserver_2econnectionSays_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2econnectionSays_clo;
V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498(V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_clo;
V g_std_2ehttp_2eserver_2eheadEnd(V, V);
V g_std_2ehttp_2eserver_2eheadEnd_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheadEnd_clo;
V g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118(V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_clo;
HeffT2 g_std_2ehttp_2eserver_2eheaderLines_24cpr(V);
V g_std_2ehttp_2eserver_2eownHeader(V);
V g_std_2ehttp_2eserver_2eownHeader_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eownHeader_clo;
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268(V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_clo;
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419(V, V, V, V, V);
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_clo;
V g_std_2ehttp_2eserver_2ereason(V);
V g_std_2ehttp_2eserver_2ereason_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereason_clo;
V g_std_2ehttp_2eserver_2eresponseBytes(V, V, V);
V g_std_2ehttp_2eserver_2eresponseBytes_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eresponseBytes_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550(V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_clo;
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967(V, V, V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_clo;
V g_std_2enet_2eaccept_24s1720705717x1901582490(V, V, V, V, V);
V g_std_2enet_2eaccept_24s1720705717x1901582490_entry(V self, V *a);
extern Clo g_std_2enet_2eaccept_24s1720705717x1901582490_clo;
Clo g_std_2ehttp_2eserver_2eheadEnd_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eheadEnd_entry, 2, 0};

V g_std_2ehttp_2eserver_2eheadEnd(V v_b_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_bytesLength(heff_dup(v_b_240)), heff_intAdd(heff_dup(v_i_241), MK_INT(4LL)))) {
    heff_drop(v_b_240);
    heff_drop(v_i_241);
    return MK_INT(-1LL);
  } else {
    V v_t_242 = heff_box_u8(heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_dup(v_i_241))));
    if ((heff_intEq_c_lent(v_t_242, MK_INT(13LL), 2) && ({ uint8_t v_t_243 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))); int c_ = ({ V v_t_246 = heff_box_u8(v_t_243); int c_ = (heff_intEq_c_lent(v_t_246, MK_INT(10LL), 2) && ({ uint8_t v_t_244 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)))); int c_ = ({ V v_t_247 = heff_box_u8(v_t_244); int c_ = (heff_intEq_c_lent(v_t_247, MK_INT(13LL), 2) && ({ uint8_t v_t_245 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(3LL)))); int c_ = ({ V v_t_248 = heff_box_u8(v_t_245); int c_ = heff_intEq_c_lent(v_t_248, MK_INT(10LL), 2); heff_drop(v_t_248); c_; }); c_; })); heff_drop(v_t_247); c_; }); c_; })); heff_drop(v_t_246); c_; }); c_; }))) {
      heff_drop(v_b_240);
      heff_drop(v_t_242);
      return v_i_241;
    } else {
      heff_drop(v_t_242);
      V t_0 = v_b_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_b_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_std_2ehttp_2eserver_2eheadEnd_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eheadEnd(a[0], a[1]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderLines_24cpr_str0, 1, ":");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderLines_24cpr_str1, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderLines_24cpr_str2, 1, "\011");

HeffT2 g_std_2ehttp_2eserver_2eheaderLines_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_l_243 = heff_dup(v_l_241);
    V v_j_244 = heff_strFind(((V)&g_std_2ehttp_2eserver_2eheaderLines_24cpr_str0), v_l_241, MK_INT(0LL));
    V v_x1_245;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_x1_245 = NTAG(TAG_Nothing);
    } else {
      v_x1_245 = heff_tag_n(TAG_Just, 1, (V[]){v_j_244});
    }
    V v_x1_2413;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nothing: {
      heff_drop(v_l_243);
      v_x1_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24Just = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_name_247 = heff_strSlice_lent(v_l_243, MK_INT(0LL), v_i_246, 2);
      if ((heff_intEq_c_lent(v_i_246, MK_INT(0LL), 2) || (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaderLines_24cpr_str1), v_name_247, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaderLines_24cpr_str2), v_name_247, MK_INT(0LL), 5))))) {
        heff_drop(v_l_243);
        heff_drop(v_i_246);
        heff_drop_cell(v_ru_24x1_245_24Just, 1);
        heff_drop(v_name_247);
        v_x1_2413 = NTAG(TAG_Nothing);
      } else {
        V v_s_248 = heff_strSlice(heff_dup(v_l_243), heff_intAdd(v_i_246, MK_INT(1LL)), heff_strLength(v_l_243));
        V v_t_249 = (g_prelude_2eskipSpaces(v_s_248, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_s_248, 0)) - ((int64_t)1ULL));
        V v_t_2411 = (g_prelude_2eskipSpaces(v_s_248, heff_box_word(v_t_2410), MK_INT(-1LL)));
        V v_t_2412 = heff_strSlice(v_s_248, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
        v_x1_2413 = heff_tag_at_n(v_ru_24x1_245_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_247, v_t_2412})});
      }
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    HeffT2 v_t_2414 = (g_std_2ehttp_2eserver_2eheaderLines_24cpr(v_rest_242));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_field_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x_2417 = heff_field(v_x1_2413, 0);
        heff_take_n(v_x1_2413, 1ULL, 1);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_xs_2418 = v_field_2416;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2417, v_xs_2418})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_field_2416);
          heff_drop(v_x_2417);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str0, 8, "Continue");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str1, 19, "Switching Protocols");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str2, 2, "OK");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str3, 7, "Created");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str4, 8, "Accepted");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str5, 10, "No Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str6, 15, "Partial Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str7, 17, "Moved Permanently");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str8, 5, "Found");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str9, 9, "See Other");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str10, 12, "Not Modified");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str11, 18, "Temporary Redirect");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str12, 18, "Permanent Redirect");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str13, 11, "Bad Request");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str14, 12, "Unauthorized");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str15, 9, "Forbidden");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str16, 9, "Not Found");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str17, 18, "Method Not Allowed");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str18, 15, "Request Timeout");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str19, 8, "Conflict");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str20, 4, "Gone");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str21, 15, "Length Required");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str22, 17, "Content Too Large");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str23, 12, "URI Too Long");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str24, 22, "Unsupported Media Type");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str25, 21, "Unprocessable Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str26, 17, "Too Many Requests");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str27, 31, "Request Header Fields Too Large");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str28, 21, "Internal Server Error");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str29, 15, "Not Implemented");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str30, 11, "Bad Gateway");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str31, 19, "Service Unavailable");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str32, 15, "Gateway Timeout");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str33, 26, "HTTP Version Not Supported");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str34, 0, "");
Clo g_std_2ehttp_2eserver_2ereason_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereason_entry, 1, 0};

V g_std_2ehttp_2eserver_2ereason(V v_x1_240) {
top: ;
  if (heff_intEq_c_lent(v_x1_240, MK_INT(100LL), 2)) {
    heff_drop(v_x1_240);
    return ((V)&g_std_2ehttp_2eserver_2ereason_str0);
  } else {
    if (heff_intEq_c_lent(v_x1_240, MK_INT(101LL), 2)) {
      heff_drop(v_x1_240);
      return ((V)&g_std_2ehttp_2eserver_2ereason_str1);
    } else {
      if (heff_intEq_c_lent(v_x1_240, MK_INT(200LL), 2)) {
        heff_drop(v_x1_240);
        return ((V)&g_std_2ehttp_2eserver_2ereason_str2);
      } else {
        if (heff_intEq_c_lent(v_x1_240, MK_INT(201LL), 2)) {
          heff_drop(v_x1_240);
          return ((V)&g_std_2ehttp_2eserver_2ereason_str3);
        } else {
          if (heff_intEq_c_lent(v_x1_240, MK_INT(202LL), 2)) {
            heff_drop(v_x1_240);
            return ((V)&g_std_2ehttp_2eserver_2ereason_str4);
          } else {
            if (heff_intEq_c_lent(v_x1_240, MK_INT(204LL), 2)) {
              heff_drop(v_x1_240);
              return ((V)&g_std_2ehttp_2eserver_2ereason_str5);
            } else {
              if (heff_intEq_c_lent(v_x1_240, MK_INT(206LL), 2)) {
                heff_drop(v_x1_240);
                return ((V)&g_std_2ehttp_2eserver_2ereason_str6);
              } else {
                if (heff_intEq_c_lent(v_x1_240, MK_INT(301LL), 2)) {
                  heff_drop(v_x1_240);
                  return ((V)&g_std_2ehttp_2eserver_2ereason_str7);
                } else {
                  if (heff_intEq_c_lent(v_x1_240, MK_INT(302LL), 2)) {
                    heff_drop(v_x1_240);
                    return ((V)&g_std_2ehttp_2eserver_2ereason_str8);
                  } else {
                    if (heff_intEq_c_lent(v_x1_240, MK_INT(303LL), 2)) {
                      heff_drop(v_x1_240);
                      return ((V)&g_std_2ehttp_2eserver_2ereason_str9);
                    } else {
                      if (heff_intEq_c_lent(v_x1_240, MK_INT(304LL), 2)) {
                        heff_drop(v_x1_240);
                        return ((V)&g_std_2ehttp_2eserver_2ereason_str10);
                      } else {
                        if (heff_intEq_c_lent(v_x1_240, MK_INT(307LL), 2)) {
                          heff_drop(v_x1_240);
                          return ((V)&g_std_2ehttp_2eserver_2ereason_str11);
                        } else {
                          if (heff_intEq_c_lent(v_x1_240, MK_INT(308LL), 2)) {
                            heff_drop(v_x1_240);
                            return ((V)&g_std_2ehttp_2eserver_2ereason_str12);
                          } else {
                            if (heff_intEq_c_lent(v_x1_240, MK_INT(400LL), 2)) {
                              heff_drop(v_x1_240);
                              return ((V)&g_std_2ehttp_2eserver_2ereason_str13);
                            } else {
                              if (heff_intEq_c_lent(v_x1_240, MK_INT(401LL), 2)) {
                                heff_drop(v_x1_240);
                                return ((V)&g_std_2ehttp_2eserver_2ereason_str14);
                              } else {
                                if (heff_intEq_c_lent(v_x1_240, MK_INT(403LL), 2)) {
                                  heff_drop(v_x1_240);
                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str15);
                                } else {
                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(404LL), 2)) {
                                    heff_drop(v_x1_240);
                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str16);
                                  } else {
                                    if (heff_intEq_c_lent(v_x1_240, MK_INT(405LL), 2)) {
                                      heff_drop(v_x1_240);
                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str17);
                                    } else {
                                      if (heff_intEq_c_lent(v_x1_240, MK_INT(408LL), 2)) {
                                        heff_drop(v_x1_240);
                                        return ((V)&g_std_2ehttp_2eserver_2ereason_str18);
                                      } else {
                                        if (heff_intEq_c_lent(v_x1_240, MK_INT(409LL), 2)) {
                                          heff_drop(v_x1_240);
                                          return ((V)&g_std_2ehttp_2eserver_2ereason_str19);
                                        } else {
                                          if (heff_intEq_c_lent(v_x1_240, MK_INT(410LL), 2)) {
                                            heff_drop(v_x1_240);
                                            return ((V)&g_std_2ehttp_2eserver_2ereason_str20);
                                          } else {
                                            if (heff_intEq_c_lent(v_x1_240, MK_INT(411LL), 2)) {
                                              heff_drop(v_x1_240);
                                              return ((V)&g_std_2ehttp_2eserver_2ereason_str21);
                                            } else {
                                              if (heff_intEq_c_lent(v_x1_240, MK_INT(413LL), 2)) {
                                                heff_drop(v_x1_240);
                                                return ((V)&g_std_2ehttp_2eserver_2ereason_str22);
                                              } else {
                                                if (heff_intEq_c_lent(v_x1_240, MK_INT(414LL), 2)) {
                                                  heff_drop(v_x1_240);
                                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str23);
                                                } else {
                                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(415LL), 2)) {
                                                    heff_drop(v_x1_240);
                                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str24);
                                                  } else {
                                                    if (heff_intEq_c_lent(v_x1_240, MK_INT(422LL), 2)) {
                                                      heff_drop(v_x1_240);
                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str25);
                                                    } else {
                                                      if (heff_intEq_c_lent(v_x1_240, MK_INT(429LL), 2)) {
                                                        heff_drop(v_x1_240);
                                                        return ((V)&g_std_2ehttp_2eserver_2ereason_str26);
                                                      } else {
                                                        if (heff_intEq_c_lent(v_x1_240, MK_INT(431LL), 2)) {
                                                          heff_drop(v_x1_240);
                                                          return ((V)&g_std_2ehttp_2eserver_2ereason_str27);
                                                        } else {
                                                          if (heff_intEq_c_lent(v_x1_240, MK_INT(500LL), 2)) {
                                                            heff_drop(v_x1_240);
                                                            return ((V)&g_std_2ehttp_2eserver_2ereason_str28);
                                                          } else {
                                                            if (heff_intEq_c_lent(v_x1_240, MK_INT(501LL), 2)) {
                                                              heff_drop(v_x1_240);
                                                              return ((V)&g_std_2ehttp_2eserver_2ereason_str29);
                                                            } else {
                                                              if (heff_intEq_c_lent(v_x1_240, MK_INT(502LL), 2)) {
                                                                heff_drop(v_x1_240);
                                                                return ((V)&g_std_2ehttp_2eserver_2ereason_str30);
                                                              } else {
                                                                if (heff_intEq_c_lent(v_x1_240, MK_INT(503LL), 2)) {
                                                                  heff_drop(v_x1_240);
                                                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str31);
                                                                } else {
                                                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(504LL), 2)) {
                                                                    heff_drop(v_x1_240);
                                                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str32);
                                                                  } else {
                                                                    if (heff_intEq_c(v_x1_240, MK_INT(505LL))) {
                                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str33);
                                                                    } else {
                                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str34);
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2ehttp_2eserver_2ereason_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2ereason(a[0]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str0, 14, "Content-Length");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str1, 17, "Transfer-Encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str2, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str3, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str4, 17, "Transfer-Encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str5, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str6, 10, "Connection");
Clo g_std_2ehttp_2eserver_2eownHeader_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eownHeader_entry, 1, 0};

V g_std_2ehttp_2eserver_2eownHeader(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_n_241 = heff_field(v_x1_240, 0);
    if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)14ULL))) {
      V v_t_243 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str0); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
        heff_drop(v_t_243);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_243);
        if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)17ULL))) {
          V v_t_244 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str1); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
            heff_drop(v_t_244);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_244);
            if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
              return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str2); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
            } else {
              return NTAG(TAG_False);
            }
          }
        } else {
          if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
            return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str3); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          } else {
            return NTAG(TAG_False);
          }
        }
      }
    } else {
      if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)17ULL))) {
        V v_t_245 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str4); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
          heff_drop(v_t_245);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_245);
          if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
            return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str5); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          } else {
            return NTAG(TAG_False);
          }
        }
      } else {
        if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
          return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str6); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        } else {
          return NTAG(TAG_False);
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ehttp_2eserver_2eownHeader_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2eownHeader(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str0, 9, "HTTP/1.1 ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str1, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str2, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str3, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str4, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str5, 16, "Content-Length: ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str6, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str7, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str8, 12, "Connection: ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str9, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str10, 2, "\015\012");
Clo g_std_2ehttp_2eserver_2eresponseBytes_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eresponseBytes_entry, 3, 0};

V g_std_2ehttp_2eserver_2eresponseBytes(V v_connection_240, V v_withBody_241, V v_res_242) {
top: ;
  V v_status_243 = heff_take_field(v_res_242, 0);
  V v_headers_244 = heff_take_field(v_res_242, 1);
  V v_body_245 = heff_get_n(v_res_242, 2, 3);
  V v_s_246 = heff_dup(v_status_243);
  V v_t_247 = heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str0), heff_intShow(heff_dup(v_status_243)));
  V v_t_248 = (g_std_2ehttp_2eserver_2ereason(v_status_243));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str1)), v_t_248);
  V v_t_2410 = (g_list_2ekeepIf_24s280149390x2003255054(v_headers_244));
  V v_t_2411 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str2); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1511444646x1476348587(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str3)), v_t_2411);
  V v_t_2414;
  if ((heff_intLt_c_lent(v_s_246, MK_INT(200LL), 2) || (heff_intEq_c_lent(v_s_246, MK_INT(204LL), 2) || heff_intEq_c_lent(v_s_246, MK_INT(304LL), 2)))) {
    v_t_2414 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str4);
  } else {
    V v_t_2413 = heff_intShow(heff_bytesLength(heff_dup(v_body_245)));
    v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str5), v_t_2413), ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str6));
  }
  V v_t_2415;
  if ((heff_unbox_word(heff_strLength_lent(v_connection_240, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_connection_240);
    v_t_2415 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str7);
  } else {
    v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str8), v_connection_240), ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str9));
  }
  V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2414), v_t_2415);
  V v_head_2417 = heff_strAppend(v_t_2416, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str10));
  if (((heff_dup(v_withBody_241) == NTAG(TAG_True)) && (heff_intLt_c_lent(v_s_246, MK_INT(200LL), 2) ? 0 : (heff_intEq_c_lent(v_s_246, MK_INT(204LL), 2) ? 0 : !heff_intEq_c_lent(v_s_246, MK_INT(304LL), 2))))) {
    heff_drop(v_s_246);
    return heff_bytesAppend(heff_bytesFromString(v_head_2417), v_body_245);
  } else {
    heff_drop(v_body_245);
    heff_drop(v_s_246);
    return heff_bytesFromString(v_head_2417);
  }
}
V g_std_2ehttp_2eserver_2eresponseBytes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2eresponseBytes(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str0, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str1, 1, ",");
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str2, 1, ",");
V g_std_2ehttp_2eserver_2econnectionSays_lam0(V self, V *args);
Clo g_std_2ehttp_2eserver_2econnectionSays_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2econnectionSays_entry, 2, 0};

V g_std_2ehttp_2eserver_2econnectionSays(V v_token_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if ((heff_unbox_word(heff_strLength_lent(v_n_244, 0)) == ((int64_t)10ULL))) {
        V v_t_246 = ({ V a_0 = v_n_244; V b_1 = ((V)&g_std_2ehttp_2eserver_2econnectionSays_str0); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          V v_t_247 = ({ V a_0 = v_v_245; V b_1 = ((V)&g_std_2ehttp_2eserver_2econnectionSays_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2econnectionSays_str2), v_v_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
          V v_t_2413 = ({ V a_0 = heff_clo_n(g_std_2ehttp_2eserver_2econnectionSays_lam0, 1, 1, (V[]){heff_dup(v_token_240)}); V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_247); r_; });
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2413);
            V t_0 = v_token_240;
            V t_1 = v_rest_243;
            v_token_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop(v_t_246);
          V t_0 = v_token_240;
          V t_1 = v_rest_243;
          v_token_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_token_240;
        V t_1 = v_rest_243;
        v_token_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ehttp_2eserver_2econnectionSays_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ehttp_2eserver_2econnectionSays(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2econnectionSays_lam0(V self, V *args) {
  V v_t_248 = args[0];
  V v_token_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_prelude_2eskipSpaces(v_t_248, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_t_248, 0)) - ((int64_t)1ULL));
  V v_t_2411 = (g_prelude_2eskipSpaces(v_t_248, heff_box_word(v_t_2410), MK_INT(-1LL)));
  V v_a_2412 = heff_strSlice(v_t_248, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
  if ((heff_unbox_word(heff_strLength_lent(v_a_2412, 0)) == heff_unbox_word(heff_strLength_lent(v_token_240, 0)))) {
    return ({ V a_0 = v_a_2412; V a_1 = v_token_240; V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, a_1, a_2)); heff_drop(v_a_2412); heff_drop(v_token_240); r_; });
  } else {
    heff_drop(v_token_240);
    heff_drop(v_a_2412);
    return NTAG(TAG_False);
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam1(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam1, 2, 0};
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam3(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam3, 1, 0};
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam2(V self, V *args);
Clo g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_entry, 5, 0};

V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419(V v_e_240, V v_idle_241, V v_c_242, V v_buf_243, V v_from_244) {
top: ;
  V v_i_245 = (g_std_2ehttp_2eserver_2eheadEnd(heff_dup(v_buf_243), v_from_244));
  if (heff_intLe_c_lent(MK_INT(0LL), v_i_245, 1)) {
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam0, 2, 2, (V[]){v_buf_243, v_i_245});
  } else {
    heff_drop(v_i_245);
    if ((((int64_t)65536ULL) < heff_unbox_word(heff_bytesLength(heff_dup(v_buf_243))))) {
      heff_drop(v_e_240);
      heff_drop(v_idle_241);
      heff_drop(v_buf_243);
      return ((V)&g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam1_clo);
    } else {
      V v_t_2411;
      switch (heff_tag_of(v_c_242)) {
      case TAG_MkWith: {
        V v_x_2410 = heff_field(v_c_242, 0);
        v_t_2411 = heff_dup(v_x_2410);
        break;
      }
      default: heff_nomatch(v_c_242);
      }
      return heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam2, 2, 5, (V[]){v_t_2411, v_idle_241, v_e_240, v_buf_243, heff_dup(v_c_242)});
    }
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_buf_243 = heff_env(self)[0];
  V v_i_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_HeadAt, 2, (V[]){v_buf_243, v_i_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_HeadTooLong);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam3(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_buf_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_idle_241 = heff_env(self)[3];
  V v_c_242 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_drop(v_buf_243);
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_c_242);
    heff_drop(v_hd_2412);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_HeadEnded);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2421))) == ((int64_t)0ULL))) {
      heff_drop(v_buf_243);
      heff_drop(v_e_240);
      heff_drop(v_idle_241);
      heff_drop(v_c_242);
      heff_drop(v_hd_2412);
      heff_drop(v_b_2421);
      V f_ = v_k_2413;
      args[0] = NTAG(TAG_HeadEnded);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      int64_t v_t_2422;
      if ((((int64_t)3ULL) < heff_unbox_word(heff_bytesLength(heff_dup(v_buf_243))))) {
        v_t_2422 = (heff_unbox_word(heff_bytesLength(heff_dup(v_buf_243))) - ((int64_t)3ULL));
      } else {
        v_t_2422 = ((int64_t)0ULL);
      }
      V v_t_2423 = ({ V a_0 = v_e_240; V a_1 = v_idle_241; V a_2 = v_c_242; V a_3 = heff_bytesAppend(v_buf_243, v_b_2421); V a_4 = heff_box_word(v_t_2422); V r_ = (g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_c_242); r_; });
      V f_ = v_t_2423;
      heff_room[0] = v_hd_2412;
      heff_room[1] = v_k_2413;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_buf_243 = heff_env(self)[3];
  V v_c_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Read, 4, (V[]){v_t_2411, MK_INT(65536LL), heff_dup(v_idle_241), ((V)&g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam3_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_hd_2412), heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s1162341237x738799419_lam4, 1, 6, (V[]){v_k_2413, v_buf_243, v_e_240, v_idle_241, v_c_242, v_hd_2412})));
}
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam2, 1, 0};
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_entry, 6, 0};

V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268(V v_e_240, V v_idle_241, V v_c_242, V v_n_243, V v_got_244, V v_parts_245) {
top: ;
  if (heff_intLe_c_lent(v_n_243, v_got_244, 0)) {
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_n_243);
    heff_drop(v_got_244);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_parts_245));
    V v_x_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_bytesConcat(v_t_246)});
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam0, 2, 1, (V[]){v_x_247});
  } else {
    V v_t_2411;
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkWith: {
      V v_x_2410 = heff_field(v_c_242, 0);
      v_t_2411 = heff_dup(v_x_2410);
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_2412 = heff_intSub(heff_dup(v_n_243), heff_dup(v_got_244));
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam1, 2, 8, (V[]){v_t_2411, v_t_2412, v_idle_241, v_e_240, v_got_244, heff_dup(v_c_242), v_n_243, v_parts_245});
  }
}
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam2(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_got_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_idle_241 = heff_env(self)[3];
  V v_c_242 = heff_env(self)[4];
  V v_n_243 = heff_env(self)[5];
  V v_parts_245 = heff_env(self)[6];
  V v_hd_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    heff_take_n(v_x_2420, 0ULL, 1);
    heff_drop(v_got_244);
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_c_242);
    heff_drop(v_n_243);
    heff_drop(v_parts_245);
    heff_drop(v_hd_2413);
    V f_ = v_k_2414;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2422 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2422))) == ((int64_t)0ULL))) {
      heff_drop(v_got_244);
      heff_drop(v_e_240);
      heff_drop(v_idle_241);
      heff_drop(v_c_242);
      heff_drop(v_n_243);
      heff_drop(v_parts_245);
      heff_drop(v_hd_2413);
      heff_drop(v_b_2422);
      V f_ = v_k_2414;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_t_2423 = heff_intAdd(v_got_244, heff_bytesLength(heff_dup(v_b_2422)));
      V v_t_2424 = ({ V a_0 = v_e_240; V a_1 = v_idle_241; V a_2 = v_c_242; V a_3 = v_n_243; V a_4 = v_t_2423; V a_5 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2422, v_parts_245}); V r_ = (g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_242); r_; });
      V f_ = v_t_2424;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  V v_idle_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_got_244 = heff_env(self)[4];
  V v_c_242 = heff_env(self)[5];
  V v_n_243 = heff_env(self)[6];
  V v_parts_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Read, 4, (V[]){v_t_2411, v_t_2412, heff_dup(v_idle_241), ((V)&g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_2413), heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268_lam3, 1, 8, (V[]){v_k_2414, v_got_244, v_e_240, v_idle_241, v_c_242, v_n_243, v_parts_245, v_hd_2413})));
}
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str0, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str1, 6, "expect");
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str2, 12, "100-continue");
HEFF_BYTES(g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str3, 25, "HTTP/1.1 100 Continue\015\012\015\012");
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam0, 1, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam1(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam1, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam2, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam3(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam3, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam4(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam4, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam5(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam5, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam7(V self, V *args);
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam6(V self, V *args);
Clo g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_entry, 9, 0};

V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967(V v_e_240, V v_idle_241, V v_c_242, V v_buf_243, V v_i_244, V v_r_245, V v_x6_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Length: {
    V v_n_249 = heff_field(v_x6_246, 0);
    V v_ru_24x6_246_24Length = heff_take_reuse_n(v_x6_246, 1ULL, 1);
    V v_rest_2410 = heff_bytesSlice(heff_dup(v_buf_243), heff_intAdd(v_i_244, MK_INT(4LL)), heff_bytesLength(v_buf_243));
    V v_c_2438;
    if (heff_intLt_c(heff_bytesLength(heff_dup(v_rest_2410)), heff_dup(v_n_249))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_245, 2)), ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str0))) {
        HeffT2 v_t_2411 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str1); V a_1 = heff_rfield(v_r_245, 3); HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2414 = v_field_2413;
            if ((heff_unbox_word(heff_strLength_lent(v_x_2414, 0)) == ((int64_t)12ULL))) {
              V v_t_2415 = ({ V a_0 = v_x_2414; V b_1 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str2); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameName_2esameFrom_240(a_0, b_1, a_2)); heff_drop(v_x_2414); heff_drop(b_1); r_; });
              if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                heff_drop(v_t_2415);
                V v_t_2417;
                switch (heff_tag_of(v_c_242)) {
                case TAG_MkWith: {
                  V v_x_2416 = heff_field(v_c_242, 0);
                  v_t_2417 = heff_dup(v_x_2416);
                  break;
                }
                default: heff_nomatch(v_c_242);
                }
                V v_t_2419 = heff_tag_at_n(v_ru_24x6_246_24Length, TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 4, (V[]){v_t_2417, ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_str3), heff_dup(v_idle_241), ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam0_clo)})});
                V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
                V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
                V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
                v_c_2438 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
              } else {
                heff_drop_cell(v_ru_24x6_246_24Length, 1);
                heff_drop(v_t_2415);
                v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam1_clo);
              }
            } else {
              heff_drop_cell(v_ru_24x6_246_24Length, 1);
              heff_drop(v_x_2414);
              v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam2_clo);
            }
          } else {
            heff_drop_cell(v_ru_24x6_246_24Length, 1);
            heff_drop(v_field_2413);
            v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam3_clo);
          }
        }
      } else {
        heff_drop_cell(v_ru_24x6_246_24Length, 1);
        v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam4_clo);
      }
    } else {
      heff_drop_cell(v_ru_24x6_246_24Length, 1);
      v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam5_clo);
    }
    return heff_tail(v_c_2438, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam6, 1, 8, (V[]){v_rest_2410, v_e_240, v_idle_241, heff_dup(v_c_242), v_n_249, v_z_247, v_r_245, v_z_248})});
  }
  case TAG_Refuse: {
    V v_status_2447 = heff_field(v_x6_246, 0);
    heff_take_n(v_x6_246, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_buf_243);
    heff_drop(v_i_244);
    heff_drop_rec(v_r_245, 6);
    heff_drop(v_z_247);
    return heff_tail(v_z_248, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){v_status_2447})});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam0(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V v_t_2425 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2424;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V v_t_2428 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2427;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V v_t_2431 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2430;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  heff_drop(v_hd_2432);
  V v_t_2434 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2433;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam5(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V v_t_2437 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2436;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_r_245 = heff_env(self)[0];
  V v_n_249 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2446;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_245, 6);
    heff_drop(v_n_249);
    v_t_2446 = NTAG(TAG_Ended);
    break;
  }
  case TAG_Just: {
    V v_b_2443 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    V v_t_2444 = ({ V rv_4 = heff_bytesSlice(heff_dup(v_b_2443), MK_INT(0LL), heff_dup(v_n_249)); V rr_ = heff_rec_reuse_nf(v_r_245, 47ULL, 6, shape_method__target__version__headers__body__peer, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_2445 = heff_bytesSlice(heff_dup(v_b_2443), v_n_249, heff_bytesLength(v_b_2443));
    v_t_2446 = heff_tag_n(TAG_Asked, 2, (V[]){v_t_2444, v_t_2445});
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V f_ = v_z_248;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_rest_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_idle_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_n_249 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_r_245 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_rest_2410), NTAG(TAG_Nil)});
  V v_c_2441 = ({ V a_0 = v_e_240; V a_1 = v_idle_241; V a_2 = v_c_242; V a_3 = heff_dup(v_n_249); V a_4 = heff_bytesLength(v_rest_2410); V a_5 = v_t_2440; V r_ = (g_std_2ehttp_2eserver_2ereadBody_24s1410442514x863645268(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_242); r_; });
  V f_ = v_c_2441;
  heff_room[0] = v_z_247;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967_lam7, 1, 3, (V[]){v_r_245, v_n_249, v_z_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str0, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str1, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str2, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str3, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str4, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str5, 8, "HTTP/1.0");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str6, 5, "HTTP/");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str7, 17, "transfer-encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str8, 14, "content-length");
Clo g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_entry, 7, 0};

V g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118(V v_e_240, V v_idle_241, V v_c_242, V v_peer_243, V v_x4_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_HeadAt: {
    V v_buf_247 = heff_field(v_x4_244, 0);
    V v_i_248 = heff_field(v_x4_244, 1);
    V v_text_249 = heff_bytesToString(heff_bytesSlice(heff_dup(v_buf_247), MK_INT(0LL), heff_dup(v_i_248)));
    V v_peer_2410 = v_peer_243;
    V v_x2_2411 = ({ V a_0 = v_text_249; V b_1 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str1), v_text_249, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_text_249); heff_drop(b_1); r_; });
    V v_x5_2427;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      heff_drop(v_peer_2410);
      v_x5_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_l_2412 = heff_field(v_x2_2411, 0);
      V v_rest_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      V v_x2_2414 = ({ V a_0 = v_l_2412; V b_1 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str2); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str3), v_l_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_l_2412); heff_drop(b_1); r_; });
      HeffT2 v_t_2415 = (g_std_2ehttp_2eserver_2eheaderLines_24cpr(v_rest_2413));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_Nil: {
          heff_drop(v_peer_2410);
          heff_drop(v_field_2417);
          v_x5_2427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_m_2418 = heff_field(v_x2_2414, 0);
          V v_x22_2419 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          switch (heff_tag_of(v_x22_2419)) {
          case TAG_Nil: {
            heff_drop(v_peer_2410);
            heff_drop(v_field_2417);
            heff_drop(v_m_2418);
            v_x5_2427 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_t_2420 = heff_field(v_x22_2419, 0);
            V v_x222_2421 = heff_field(v_x22_2419, 1);
            heff_take_n(v_x22_2419, 3ULL, 2);
            switch (heff_tag_of(v_x222_2421)) {
            case TAG_Nil: {
              heff_drop(v_peer_2410);
              heff_drop(v_field_2417);
              heff_drop(v_m_2418);
              heff_drop(v_t_2420);
              v_x5_2427 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Cons: {
              V v_v_2422 = heff_field(v_x222_2421, 0);
              V v_x2222_2423 = heff_field(v_x222_2421, 1);
              heff_take_n(v_x222_2421, 3ULL, 2);
              switch (heff_tag_of(v_x2222_2423)) {
              case TAG_Nil: {
                if ((v_tag_2416 == ((int64_t)0ULL))) {
                  V v_hs_2424 = v_field_2417;
                  if (((heff_unbox_word(heff_strLength_lent(v_m_2418, 0)) == ((int64_t)0ULL)) || (heff_unbox_word(heff_strLength_lent(v_t_2420, 0)) == ((int64_t)0ULL)))) {
                    heff_drop(v_peer_2410);
                    heff_drop(v_m_2418);
                    heff_drop(v_t_2420);
                    heff_drop(v_v_2422);
                    heff_drop(v_hs_2424);
                    v_x5_2427 = NTAG(TAG_Nothing);
                  } else {
                    v_x5_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(6, shape_method__target__version__headers__body__peer, (V[]){v_m_2418, v_t_2420, v_v_2422, v_hs_2424, heff_dup(g_bytes_2eempty_get()), v_peer_2410})});
                  }
                } else {
                  heff_drop(v_peer_2410);
                  heff_drop(v_field_2417);
                  heff_drop(v_m_2418);
                  heff_drop(v_t_2420);
                  heff_drop(v_v_2422);
                  v_x5_2427 = NTAG(TAG_Nothing);
                }
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_x2222_2423, 0ULL, 2);
                heff_drop(v_peer_2410);
                heff_drop(v_field_2417);
                heff_drop(v_m_2418);
                heff_drop(v_t_2420);
                heff_drop(v_v_2422);
                v_x5_2427 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_x2222_2423);
              }
              break;
            }
            default: heff_nomatch(v_x222_2421);
            }
            break;
          }
          default: heff_nomatch(v_x22_2419);
          }
          break;
        }
        default: heff_nomatch(v_x2_2414);
        }
      }
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    switch (heff_tag_of(v_x5_2427)) {
    case TAG_Nothing: {
      heff_drop(v_e_240);
      heff_drop(v_idle_241);
      heff_drop(v_z_245);
      return heff_tail(v_z_246, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){MK_INT(400LL)})});
    }
    case TAG_Just: {
      V v_r_2428 = heff_field(v_x5_2427, 0);
      V v_ru_24x5_2427_24Just = heff_take_reuse_n(v_x5_2427, 1ULL, 1);
      V v_r_2429 = heff_dup(v_r_2428);
      V v_version_2430 = heff_take_field(v_r_2429, 2);
      V v_headers_2431 = heff_get_n(v_r_2429, 3, 6);
      V v_t_2445;
      if ((heff_strEq_c_lent(v_version_2430, ((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str4), 2) ? 0 : !heff_strEq_c_lent(v_version_2430, ((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str5), 2))) {
        heff_drop(v_headers_2431);
        V v_t_2432;
        if (heff_strEq_c(heff_strSlice(v_version_2430, MK_INT(0LL), MK_INT(5LL)), ((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str6))) {
          v_t_2432 = MK_INT(505LL);
        } else {
          v_t_2432 = MK_INT(400LL);
        }
        v_t_2445 = heff_tag_at_n(v_ru_24x5_2427_24Just, TAG_Refuse, 1, (V[]){v_t_2432});
      } else {
        heff_drop(v_version_2430);
        HeffT2 v_t_2433 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str7); V a_1 = v_headers_2431; HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2435 = v_t_2433.f[1];
          int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
          if ((v_tag_2434 == ((int64_t)0ULL))) {
            heff_drop(v_headers_2431);
            V v_x_2436 = v_field_2435;
            heff_drop(v_x_2436);
            v_t_2445 = heff_tag_at_n(v_ru_24x5_2427_24Just, TAG_Refuse, 1, (V[]){MK_INT(501LL)});
          } else {
            heff_drop(v_field_2435);
            HeffT2 v_t_2437 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_str8); V a_1 = v_headers_2431; HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_headers_2431); r_; });
            {
              V v_field_2439 = v_t_2437.f[1];
              int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
              if ((v_tag_2438 == ((int64_t)0ULL))) {
                V v_s_2440 = v_field_2439;
                HeffT2 v_t_2441 = ({ V a_0 = v_s_2440; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2440); r_; });
                {
                  V v_field_2443 = v_t_2441.f[1];
                  int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                  if ((v_tag_2442 == ((int64_t)0ULL))) {
                    V v_n_2444 = v_field_2443;
                    if (heff_intLt_c_lent(v_n_2444, MK_INT(0LL), 2)) {
                      heff_drop(v_n_2444);
                      v_t_2445 = heff_tag_at_n(v_ru_24x5_2427_24Just, TAG_Refuse, 1, (V[]){MK_INT(400LL)});
                    } else {
                      if (heff_intLt_c_lent(MK_INT(67108864LL), v_n_2444, 1)) {
                        heff_drop(v_n_2444);
                        v_t_2445 = heff_tag_at_n(v_ru_24x5_2427_24Just, TAG_Refuse, 1, (V[]){MK_INT(413LL)});
                      } else {
                        v_t_2445 = heff_tag_at_n(v_ru_24x5_2427_24Just, TAG_Length, 1, (V[]){v_n_2444});
                      }
                    }
                  } else {
                    heff_drop(v_field_2443);
                    v_t_2445 = heff_tag_at_n(v_ru_24x5_2427_24Just, TAG_Refuse, 1, (V[]){MK_INT(400LL)});
                  }
                }
              } else {
                heff_drop(v_field_2439);
                v_t_2445 = heff_tag_at_n(v_ru_24x5_2427_24Just, TAG_Length, 1, (V[]){MK_INT(0LL)});
              }
            }
          }
        }
      }
      return (g_std_2ehttp_2eserver_2ewithBody_24s297310400x52366967(v_e_240, v_idle_241, v_c_242, heff_dup(v_buf_247), heff_dup(v_i_248), v_r_2428, v_t_2445, v_z_245, v_z_246));
    }
    default: return heff_nomatch(v_x5_2427);
    }
  }
  case TAG_HeadTooLong: {
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_peer_243);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){MK_INT(431LL)})});
  }
  case TAG_HeadEnded: {
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_peer_243);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Ended)});
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_std_2ehttp_2eserver_2eheaded_24s1391255259x1353019118(a[0], a[1], a2, a[3], a4, a[5], a[6]); heff_drop(a2); heff_drop(a4); return r;
}
V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam0, 1, 0};
V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_entry, 6, 0};

V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498(V v_e_240, V v_idle_241, V v_c_242, V v_got_243, V v_p_244, V v_p_245) {
top: ;
  if ((((int64_t)1048576ULL) <= heff_peek_word(v_got_243))) {
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_got_243);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_MkUnit)});
  } else {
    V v_t_247;
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkWith: {
      V v_x_246 = heff_field(v_c_242, 0);
      v_t_247 = heff_dup(v_x_246);
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Read, 4, (V[]){v_t_247, MK_INT(65536LL), heff_dup(v_idle_241), ((V)&g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_244), heff_clo_n(g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam1, 1, 6, (V[]){v_p_245, v_got_243, v_e_240, v_idle_241, heff_dup(v_c_242), v_p_244})));
  }
}
V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_got_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_idle_241 = heff_env(self)[3];
  V v_c_242 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    heff_drop(v_got_243);
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_c_242);
    heff_drop(v_p_244);
    V f_ = v_p_245;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2415 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2415))) == ((int64_t)0ULL))) {
      heff_drop(v_got_243);
      heff_drop(v_e_240);
      heff_drop(v_idle_241);
      heff_drop(v_c_242);
      heff_drop(v_p_244);
      heff_drop(v_b_2415);
      V f_ = v_p_245;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      int64_t v_t_2416 = (heff_unbox_word(v_got_243) + heff_unbox_word(heff_bytesLength(v_b_2415)));
      return ({ V a_0 = v_e_240; V a_1 = v_idle_241; V a_2 = v_c_242; V a_3 = heff_box_word(v_t_2416); V a_4 = v_p_244; V a_5 = v_p_245; V r_ = (g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_242); r_; });
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str0, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str1, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str2, 10, "keep-alive");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str3, 4, "HEAD");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str4, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str5, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str6, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str7, 8, "HTTP/1.0");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str8, 10, "keep-alive");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str9, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str10, 4, "HEAD");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str11, 1, "\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str12, 12, "Content-Type");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str13, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str14, 5, "close");
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam2, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam4(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam4, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam5(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam7(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam7, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam9(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam9, 2, 0};
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam11(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam11_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam11, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam12(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam10(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam13(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam8(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam6(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam14(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam14_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam14, 2, 0};
Clo g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_entry, 5, 0};

V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803(V v_e_240, V v_idle_241, V v_c_242, V v_handle_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Asked: {
    V v_r_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_c_247 = heff_tr(heff_call(v_handle_243, 1, (V[]){heff_dup(v_r_245)}));
    return heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam0, 2, 6, (V[]){v_c_247, v_r_245, heff_dup(v_c_242), v_idle_241, v_e_240, v_rest_246});
  }
  case TAG_Refused: {
    V v_status_2441 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    heff_drop(v_handle_243);
    V v_t_2442 = (g_std_2ehttp_2eserver_2ereason(heff_dup(v_status_2441)));
    V v_t_2443 = heff_strAppend(v_t_2442, ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str11));
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str12), ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str13)}), NTAG(TAG_Nil)});
    V v_t_2445 = heff_rec_n(3, shape_status__headers__body, (V[]){v_status_2441, v_t_2444, heff_bytesFromString(v_t_2443)});
    V v_b_2446 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str14); V b_1 = NTAG(TAG_True); V a_2 = v_t_2445; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2448;
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkWith: {
      V v_x_2447 = heff_field(v_c_242, 0);
      v_t_2448 = heff_dup(v_x_2447);
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    return heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam6, 2, 5, (V[]){v_t_2448, v_b_2446, v_idle_241, v_e_240, heff_dup(v_c_242)});
  }
  case TAG_Ended: {
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    heff_drop(v_handle_243);
    return ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam14_clo);
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam2(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 0ULL, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2422_24Right = heff_take_reuse_n(v_x_2422, 0ULL, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_249;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam4(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_close_2426 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2440;
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    V v_ru_24x_2437_24Left = heff_take_reuse_n(v_x_2437, 0ULL, 1);
    heff_drop(v_close_2426);
    heff_drop(v_rest_246);
    v_t_2440 = heff_tag_at_n(v_ru_24x_2437_24Left, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2437_24Right = heff_take_reuse_n(v_x_2437, 0ULL, 1);
    if ((heff_dup(v_close_2426) == NTAG(TAG_True))) {
      heff_drop(v_close_2426);
      heff_drop(v_rest_246);
      v_t_2440 = heff_tag_at_n(v_ru_24x_2437_24Right, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    } else {
      heff_drop(v_close_2426);
      v_t_2440 = heff_tag_at_n(v_ru_24x_2437_24Right, TAG_Next, 1, (V[]){v_rest_246});
    }
    break;
  }
  default: heff_nomatch(v_x_2437);
  }
  V f_ = v_k_249;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_r_245 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_idle_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  V v_rest_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2412;
  if (heff_strEq_c(heff_dup(heff_rfield(v_r_245, 2)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str0))) {
    V v_x1_2411 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str1); V a_1 = heff_rfield(v_r_245, 3); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    v_x1_2412 = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
    heff_drop(v_x1_2411);
  } else {
    v_x1_2412 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str2); V a_1 = heff_rfield(v_r_245, 3); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
  }
  if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
    heff_drop(v_rest_246);
    heff_drop(v_x1_2412);
    V v_t_2413 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_r_245, 0)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str3)));
    heff_drop_rec(v_r_245, 6);
    V v_b_2414 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str4); V a_1 = v_t_2413; V a_2 = v_x_2410; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    V v_t_2416;
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkWith: {
      V v_x_2415 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 4, (V[]){v_t_2416, v_b_2414, v_idle_241, ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam2_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_hd_248, heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam3, 1, 1, (V[]){v_k_249})));
  } else {
    heff_drop(v_x1_2412);
    V v_close_2426 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str5); V a_1 = heff_rfield(v_x_2410, 1); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2427;
    if ((heff_dup(v_close_2426) == NTAG(TAG_True))) {
      v_t_2427 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str6);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_245, 2)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str7))) {
        v_t_2427 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str8);
      } else {
        v_t_2427 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str9);
      }
    }
    V v_t_2428 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_r_245, 0)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_str10)));
    heff_drop_rec(v_r_245, 6);
    V v_b_2429 = ({ V a_0 = v_t_2427; V a_1 = v_t_2428; V a_2 = v_x_2410; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
    V v_t_2431;
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkWith: {
      V v_x_2430 = heff_field(v_c_242, 0);
      heff_take_n(v_c_242, 1ULL, 1);
      v_t_2431 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 4, (V[]){v_t_2431, v_b_2429, v_idle_241, ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam4_clo)})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_248, heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam5, 1, 3, (V[]){v_close_2426, v_rest_246, v_k_249})));
  }
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_r_245 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_idle_241 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam1, 1, 7, (V[]){v_r_245, v_c_242, v_idle_241, v_e_240, v_hd_248, v_k_249, v_rest_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam7(V self, V *args) {
  V v_r_2451 = args[0];
  return v_r_2451;
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam9(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam11(V self, V *args) {
  V v_r_2465 = args[0];
  return v_r_2465;
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam12(V self, V *args) {
  V v_x_2470 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_hd_2463 = heff_env(self)[3];
  V v_k_2464 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2470);
  return ({ V a_0 = v_e_240; V a_1 = v_idle_241; V a_2 = v_c_242; V a_3 = MK_INT(0LL); V a_4 = v_hd_2463; V a_5 = v_k_2464; V r_ = (g_std_2ehttp_2eserver_2edrain_24s1517838098x1137777498(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_242); r_; });
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam10(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_t_2462 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_idle_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Shutdown, 2, (V[]){v_t_2462, ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam11_clo)})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), heff_dup(v_hd_2463), heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam12, 1, 5, (V[]){v_e_240, v_idle_241, v_c_242, v_hd_2463, v_k_2464})));
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam13(V self, V *args) {
  V v_x_2472 = args[0];
  V v_k_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2472);
  V v_t_2473 = heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_False)});
  V f_ = v_k_2450;
  args[0] = v_t_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_idle_241 = heff_env(self)[2];
  V v_hd_2449 = heff_env(self)[3];
  V v_k_2450 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2471;
  switch (heff_tag_of(v_x_2456)) {
  case TAG_Left: {
    heff_take_n(v_x_2456, 0ULL, 1);
    heff_drop(v_c_242);
    heff_drop(v_e_240);
    heff_drop(v_idle_241);
    v_t_2471 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam9_clo);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2456, 0ULL, 1);
    V v_t_2462;
    switch (heff_tag_of(v_c_242)) {
    case TAG_MkWith: {
      V v_x_2461 = heff_dup(heff_field(v_c_242, 0));
      v_t_2462 = v_x_2461;
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    v_t_2471 = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam10, 2, 4, (V[]){v_t_2462, v_e_240, v_idle_241, v_c_242});
    break;
  }
  default: heff_nomatch(v_x_2456);
  }
  V f_ = v_t_2471;
  heff_room[0] = v_hd_2449;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam13, 1, 1, (V[]){v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_t_2448 = heff_env(self)[0];
  V v_b_2446 = heff_env(self)[1];
  V v_idle_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_c_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 4, (V[]){v_t_2448, v_b_2446, heff_dup(v_idle_241), ((V)&g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam7_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), heff_dup(v_hd_2449), heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam8, 1, 5, (V[]){v_c_242, v_e_240, v_idle_241, v_hd_2449, v_k_2450})));
}
V g_std_2ehttp_2eserver_2eanswered_24s1693742119x400914803_lam14(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  heff_drop(v_hd_2474);
  V v_t_2476 = heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_False)});
  V f_ = v_k_2475;
  args[0] = v_t_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam4(V self, V *args); static Clo g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam4, 1, 0};
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam5(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam6(V self, V *args);
Clo g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_entry, 5, 0};

V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325(V v_lit_240, V v_idle_241, V v_stopped_242, V v_l_243, V v_handle_244) {
top: ;
  V v_t_245 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(heff_dup(v_lit_240)));
  V v_t_246 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_245));
  V v_t_247 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(heff_dup(v_lit_240)));
  V v_t_248 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_247));
  V v_t_2437 = heff_tr(heff_call(((V)&g_std_2enet_2eaccept_24s1720705717x1901582490_clo), 3, (V[]){v_t_246, heff_dup(v_l_243), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam0, 1, 5, (V[]){heff_dup(v_lit_240), v_idle_241, heff_dup(v_stopped_242), v_l_243, v_handle_244})}));
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2437, heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam6, 1, 2, (V[]){v_lit_240, v_stopped_242})})});
  return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_t_248, v_t_2443});
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325(a[0], a[1], a[2], a[3], a[4]);
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2425);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam4(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_p_2426 = heff_env(self)[0];
  V v_e_2420 = heff_env(self)[1];
  V v_idle_2421 = heff_env(self)[2];
  V v_c_2423 = heff_env(self)[3];
  V v_handle_2422 = heff_env(self)[4];
  V v_p_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    heff_take_n(v_x_2434, 0ULL, 1);
    heff_drop(v_e_2420);
    heff_drop(v_idle_2421);
    heff_drop(v_c_2423);
    heff_drop(v_handle_2422);
    heff_drop(v_p_2424);
    V f_ = v_p_2426;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_peer_2436 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 1);
    return ({ V a_0 = v_e_2420; V a_1 = v_idle_2421; V a_2 = v_c_2423; V a_3 = v_peer_2436; V a_4 = v_handle_2422; V a_5 = heff_dup(g_bytes_2eempty_get()); V a_6 = v_p_2424; V a_7 = v_p_2426; V r_ = (g_std_2ehttp_2eserver_2eclosedWith_2eserveFrom_240_24s1600448022x963820818(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2423); r_; });
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_handle_244 = heff_env(self)[2];
  V v_c_249 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  V v_t_2418 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(v_lit_240));
  V v_t_2419 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_2418));
  V v_e_2420 = v_t_2419;
  V v_idle_2421 = v_idle_241;
  V v_handle_2422 = v_handle_244;
  V v_c_2423 = v_c_249;
  V v_p_2424 = v_hd_2411;
  V v_p_2426 = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam3, 1, 1, (V[]){v_k_2412});
  V v_t_2428;
  switch (heff_tag_of(v_c_2423)) {
  case TAG_MkWith: {
    V v_x_2427 = heff_dup(heff_field(v_c_2423, 0));
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_c_2423);
  }
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Peer, 2, (V[]){v_t_2428, ((V)&g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam4_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_2420), heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_p_2424), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam5, 1, 6, (V[]){v_p_2426, v_e_2420, v_idle_2421, v_c_2423, v_handle_2422, v_p_2424})));
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_c_2410 = heff_env(self)[1];
  V v_idle_241 = heff_env(self)[2];
  V v_handle_244 = heff_env(self)[3];
  V v_c_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(heff_dup(v_lit_240)));
  V v_t_2414 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_2413));
  V v_t_2415 = heff_tag_n(TAG_Spawn, 2, (V[]){v_c_2410, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s310169282x2049378029(v_t_2414, v_t_2416, heff_dup(v_hd_2411), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam2, 1, 6, (V[]){v_lit_240, v_idle_241, v_handle_244, v_c_249, v_hd_2411, v_k_2412})));
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam0(V self, V *args) {
  V v_c_249 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_stopped_242 = heff_env(self)[2];
  V v_l_243 = heff_env(self)[3];
  V v_handle_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = heff_tr(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325(heff_dup(v_lit_240), heff_dup(v_idle_241), v_stopped_242, v_l_243, heff_dup(v_handle_244)));
  return heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam1, 2, 5, (V[]){v_lit_240, v_c_2410, v_idle_241, v_handle_244, v_c_249});
}
V g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325_lam6(V self, V *args) {
  V v_err_2438 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_stopped_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(v_lit_240));
  V v_t_2440 = (g_co_2e_3c_2b_3e_24s1585861108x1258949188(v_t_2439));
  V v_t_2441 = heff_tag_n(TAG_Wake, 3, (V[]){v_stopped_242, heff_get_n(v_err_2438, 0, 4), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V f_ = ((V)&g_co_2eop_24s310169282x2049378029_clo);
  heff_room[0] = v_t_2440;
  heff_room[1] = v_t_2442;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam0, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam5(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam5, 3, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam6(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam8(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam8, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam9(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam7(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_entry, 6, 0};

V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550(V v_lit_240, V v_idle_241, V v_l_242, V v_handle_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_NewKey, 1, (V[]){((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam0_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam1, 1, 6, (V[]){v_lit_240, v_idle_241, v_l_242, v_handle_243, v_hd_244, v_k_245})});
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam0(V self, V *args) {
  V v_n_246 = args[0];
  return v_n_246;
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam4(V self, V *args) {
  V v_p_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_2412, 2, 3);
  args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_p_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam3(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_kont_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V rv_2 = heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam4, 1, 1, (V[]){heff_dup(v_hd_2412)}); V rr_ = heff_rec_reuse_nf(v_hd_2412, 3ULL, 3, shape_ret__bind__malg, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_c_2411;
  args[0] = v_t_2415;
  args[1] = v_kont_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam2(V self, V *args) {
  V v_r_2410 = args[0];
  V v_handle_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2411 = heff_tr(heff_call(v_handle_243, 1, (V[]){v_r_2410}));
  return heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam3, 2, 1, (V[]){v_c_2411});
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2425 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    V v_t_2426 = heff_tag_n(TAG_Wake, 3, (V[]){v_x_249, heff_get_n(v_err_2425, 0, 4), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2427;
    heff_room[1] = v_k_2423;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    heff_drop(v_x_249);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_2423;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam8(V self, V *args) {
  V v_v_2433 = args[0];
  return v_v_2433;
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2436);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Park, 2, (V[]){v_x_249, ((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam8_clo)})});
  V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2434}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam9, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_idle_241 = heff_env(self)[1];
  V v_l_242 = heff_env(self)[2];
  V v_handle_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2416 = heff_tr(g_std_2ehttp_2eserver_2eacceptor_24s371401622x1024439325(heff_dup(v_lit_240), v_idle_241, heff_dup(v_x_249), v_l_242, heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam2, 1, 1, (V[]){v_handle_243})));
  V v_t_2417 = (g_co_2e_3c_2b_3e_24s1404263853x1546533042(v_lit_240));
  V v_t_2418 = (g_exception_2eattempted(v_t_2417));
  V v_c_2422 = heff_tr(heff_call(v_c_2416, 2, (V[]){v_t_2418, ((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam5_clo)}));
  V v_k_2423 = heff_dup(heff_rfield(v_hd_244, 0));
  V v_t_2429 = heff_tr(heff_call(v_c_2422, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam6, 1, 3, (V[]){heff_dup(v_x_249), heff_dup(v_hd_244), v_k_2423})}));
  V v_t_2430 = heff_tag_n(TAG_Spawn, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s2096376552x1738046550_lam7, 1, 3, (V[]){v_x_249, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}