// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Accept 48933
#define TAG_Asked 63168
#define TAG_Done 47505
#define TAG_Ended 63166
#define TAG_HeadAt 24796
#define TAG_HeadEnded 64500
#define TAG_HeadTooLong 4872
#define TAG_Left 13886
#define TAG_Length 531
#define TAG_MkWith 3751
#define TAG_NewChan 9424
#define TAG_Next 8500
#define TAG_Peer 1965
#define TAG_Read 61409
#define TAG_Recv 61489
#define TAG_Refuse 3461
#define TAG_Refused 41566
#define TAG_Release 43671
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Shutdown 48081
#define TAG_Spawn 10053
#define TAG_Write 36323
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_headers 1027165638
#define LBL_malg 9839318
#define LBL_method 869586956
#define LBL_peer 9932329
#define LBL_ret 322331
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_version 583465758
static uint32_t shape_method__target__version__headers__body__peer[] = {LBL_method, LBL_target, LBL_version, LBL_headers, LBL_body, LBL_peer};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
V g_bytes_2eempty_get(void);
V g_co_2eop_24s1703844634x634335703(V, V, V);
V g_co_2eop_24s1703844634x634335703_entry(V self, V *a);
extern Clo g_co_2eop_24s1703844634x634335703_clo;
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s1979766345x1806196139(V, V, V);
V g_co_2eop_24s1979766345x1806196139_entry(V self, V *a);
extern Clo g_co_2eop_24s1979766345x1806196139_clo;
V g_co_2eop_24s979864723x1871992405(V, V);
V g_co_2eop_24s979864723x1871992405_entry(V self, V *a);
extern Clo g_co_2eop_24s979864723x1871992405_clo;
V g_exception_2eattempted_24s1991057797x762774998_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1511444646x1476348587(V, V);
V g_list_2efoldl_24s1511444646x1476348587_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1511444646x1476348587_clo;
V g_list_2ekeepIf_24s280149390x2003255054(V);
V g_list_2ekeepIf_24s280149390x2003255054_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s280149390x2003255054_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_std_2ehttp_2eheaderIn_24cpr(V, V);
V g_std_2ehttp_2esameFrom(V, V, V);
V g_std_2ehttp_2esameFrom_entry(V self, V *a);
extern Clo g_std_2ehttp_2esameFrom_clo;
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130(V, V, V);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_clo;
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468(V, V, V);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_clo;
V g_std_2ehttp_2eserver_2econnectionSays(V, V);
V g_std_2ehttp_2eserver_2econnectionSays_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2econnectionSays_clo;
V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506(V, V, V, V);
V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_clo;
V g_std_2ehttp_2eserver_2eheadEnd(V, V);
V g_std_2ehttp_2eserver_2eheadEnd_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheadEnd_clo;
V g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815(V, V, V, V, V);
V g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_clo;
HeffT2 g_std_2ehttp_2eserver_2eheaderLines_24cpr(V);
V g_std_2ehttp_2eserver_2eownHeader(V);
V g_std_2ehttp_2eserver_2eownHeader_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eownHeader_clo;
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553(V, V, V, V);
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_clo;
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988(V, V, V);
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_clo;
V g_std_2ehttp_2eserver_2ereason(V);
V g_std_2ehttp_2eserver_2ereason_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereason_clo;
V g_std_2ehttp_2eserver_2eresponseBytes(V, V, V);
V g_std_2ehttp_2eserver_2eresponseBytes_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eresponseBytes_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023(V, V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_clo;
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743(V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_clo;
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412(V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_clo;
Clo g_std_2ehttp_2eserver_2eheadEnd_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eheadEnd_entry, 2, 0};

V g_std_2ehttp_2eserver_2eheadEnd(V v_b_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_bytesLength(heff_dup(v_b_240)), heff_intAdd(heff_dup(v_i_241), MK_INT(4LL)))) {
    heff_drop(v_b_240);
    heff_drop(v_i_241);
    return MK_INT(-1LL);
  } else {
    V v_t_242 = heff_box_u8(heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_dup(v_i_241))));
    if ((heff_intEq_c_lent(v_t_242, MK_INT(13LL), 2) && ({ uint8_t v_t_243 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))); int c_ = ({ V v_t_246 = heff_box_u8(v_t_243); int c_ = (heff_intEq_c_lent(v_t_246, MK_INT(10LL), 2) && ({ uint8_t v_t_244 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL)))); int c_ = ({ V v_t_247 = heff_box_u8(v_t_244); int c_ = (heff_intEq_c_lent(v_t_247, MK_INT(13LL), 2) && ({ uint8_t v_t_245 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(3LL)))); int c_ = ({ V v_t_248 = heff_box_u8(v_t_245); int c_ = heff_intEq_c_lent(v_t_248, MK_INT(10LL), 2); heff_drop(v_t_248); c_; }); c_; })); heff_drop(v_t_247); c_; }); c_; })); heff_drop(v_t_246); c_; }); c_; }))) {
      heff_drop(v_b_240);
      heff_drop(v_t_242);
      return v_i_241;
    } else {
      heff_drop(v_t_242);
      V t_0 = v_b_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_b_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_std_2ehttp_2eserver_2eheadEnd_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eheadEnd(a[0], a[1]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderLines_24cpr_str0, 1, ":");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderLines_24cpr_str1, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderLines_24cpr_str2, 1, "\011");

HeffT2 g_std_2ehttp_2eserver_2eheaderLines_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_l_243 = heff_dup(v_l_241);
    V v_j_244 = heff_strFind(((V)&g_std_2ehttp_2eserver_2eheaderLines_24cpr_str0), v_l_241, MK_INT(0LL));
    V v_x2_245;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_x2_245 = NTAG(TAG_Nothing);
    } else {
      v_x2_245 = heff_tag_n(TAG_Just, 1, (V[]){v_j_244});
    }
    V v_x1_2413;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      heff_drop(v_l_243);
      v_x1_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_246 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24Just = heff_take_reuse_n(v_x2_245, 1ULL, 1);
      V v_name_247 = heff_strSlice_lent(v_l_243, MK_INT(0LL), v_i_246, 2);
      if ((heff_intEq_c_lent(v_i_246, MK_INT(0LL), 2) || (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaderLines_24cpr_str1), v_name_247, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaderLines_24cpr_str2), v_name_247, MK_INT(0LL), 5))))) {
        heff_drop(v_l_243);
        heff_drop(v_i_246);
        heff_drop_cell(v_ru_24x2_245_24Just, 1);
        heff_drop(v_name_247);
        v_x1_2413 = NTAG(TAG_Nothing);
      } else {
        V v_s_248 = heff_strSlice(heff_dup(v_l_243), heff_intAdd(v_i_246, MK_INT(1LL)), heff_strLength(v_l_243));
        V v_t_249 = (g_prelude_2eskipSpaces(v_s_248, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_s_248, 0)) - ((int64_t)1ULL));
        V v_t_2411 = (g_prelude_2eskipSpaces(v_s_248, heff_box_word(v_t_2410), MK_INT(-1LL)));
        V v_t_2412 = heff_strSlice(v_s_248, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
        v_x1_2413 = heff_tag_at_n(v_ru_24x2_245_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_247, v_t_2412})});
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    HeffT2 v_t_2414 = (g_std_2ehttp_2eserver_2eheaderLines_24cpr(v_rest_242));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_field_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x_2417 = heff_field(v_x1_2413, 0);
        heff_take_n(v_x1_2413, 1ULL, 1);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_xs_2418 = v_field_2416;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2417, v_xs_2418})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_field_2416);
          heff_drop(v_x_2417);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str0, 8, "Continue");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str1, 19, "Switching Protocols");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str2, 2, "OK");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str3, 7, "Created");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str4, 8, "Accepted");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str5, 10, "No Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str6, 15, "Partial Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str7, 17, "Moved Permanently");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str8, 5, "Found");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str9, 9, "See Other");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str10, 12, "Not Modified");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str11, 18, "Temporary Redirect");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str12, 18, "Permanent Redirect");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str13, 11, "Bad Request");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str14, 12, "Unauthorized");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str15, 9, "Forbidden");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str16, 9, "Not Found");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str17, 18, "Method Not Allowed");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str18, 15, "Request Timeout");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str19, 8, "Conflict");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str20, 4, "Gone");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str21, 15, "Length Required");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str22, 17, "Content Too Large");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str23, 12, "URI Too Long");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str24, 22, "Unsupported Media Type");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str25, 21, "Unprocessable Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str26, 17, "Too Many Requests");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str27, 31, "Request Header Fields Too Large");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str28, 21, "Internal Server Error");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str29, 15, "Not Implemented");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str30, 11, "Bad Gateway");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str31, 19, "Service Unavailable");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str32, 15, "Gateway Timeout");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str33, 26, "HTTP Version Not Supported");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str34, 0, "");
Clo g_std_2ehttp_2eserver_2ereason_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereason_entry, 1, 0};

V g_std_2ehttp_2eserver_2ereason(V v_x1_240) {
top: ;
  if (heff_intEq_c_lent(v_x1_240, MK_INT(100LL), 2)) {
    heff_drop(v_x1_240);
    return ((V)&g_std_2ehttp_2eserver_2ereason_str0);
  } else {
    if (heff_intEq_c_lent(v_x1_240, MK_INT(101LL), 2)) {
      heff_drop(v_x1_240);
      return ((V)&g_std_2ehttp_2eserver_2ereason_str1);
    } else {
      if (heff_intEq_c_lent(v_x1_240, MK_INT(200LL), 2)) {
        heff_drop(v_x1_240);
        return ((V)&g_std_2ehttp_2eserver_2ereason_str2);
      } else {
        if (heff_intEq_c_lent(v_x1_240, MK_INT(201LL), 2)) {
          heff_drop(v_x1_240);
          return ((V)&g_std_2ehttp_2eserver_2ereason_str3);
        } else {
          if (heff_intEq_c_lent(v_x1_240, MK_INT(202LL), 2)) {
            heff_drop(v_x1_240);
            return ((V)&g_std_2ehttp_2eserver_2ereason_str4);
          } else {
            if (heff_intEq_c_lent(v_x1_240, MK_INT(204LL), 2)) {
              heff_drop(v_x1_240);
              return ((V)&g_std_2ehttp_2eserver_2ereason_str5);
            } else {
              if (heff_intEq_c_lent(v_x1_240, MK_INT(206LL), 2)) {
                heff_drop(v_x1_240);
                return ((V)&g_std_2ehttp_2eserver_2ereason_str6);
              } else {
                if (heff_intEq_c_lent(v_x1_240, MK_INT(301LL), 2)) {
                  heff_drop(v_x1_240);
                  return ((V)&g_std_2ehttp_2eserver_2ereason_str7);
                } else {
                  if (heff_intEq_c_lent(v_x1_240, MK_INT(302LL), 2)) {
                    heff_drop(v_x1_240);
                    return ((V)&g_std_2ehttp_2eserver_2ereason_str8);
                  } else {
                    if (heff_intEq_c_lent(v_x1_240, MK_INT(303LL), 2)) {
                      heff_drop(v_x1_240);
                      return ((V)&g_std_2ehttp_2eserver_2ereason_str9);
                    } else {
                      if (heff_intEq_c_lent(v_x1_240, MK_INT(304LL), 2)) {
                        heff_drop(v_x1_240);
                        return ((V)&g_std_2ehttp_2eserver_2ereason_str10);
                      } else {
                        if (heff_intEq_c_lent(v_x1_240, MK_INT(307LL), 2)) {
                          heff_drop(v_x1_240);
                          return ((V)&g_std_2ehttp_2eserver_2ereason_str11);
                        } else {
                          if (heff_intEq_c_lent(v_x1_240, MK_INT(308LL), 2)) {
                            heff_drop(v_x1_240);
                            return ((V)&g_std_2ehttp_2eserver_2ereason_str12);
                          } else {
                            if (heff_intEq_c_lent(v_x1_240, MK_INT(400LL), 2)) {
                              heff_drop(v_x1_240);
                              return ((V)&g_std_2ehttp_2eserver_2ereason_str13);
                            } else {
                              if (heff_intEq_c_lent(v_x1_240, MK_INT(401LL), 2)) {
                                heff_drop(v_x1_240);
                                return ((V)&g_std_2ehttp_2eserver_2ereason_str14);
                              } else {
                                if (heff_intEq_c_lent(v_x1_240, MK_INT(403LL), 2)) {
                                  heff_drop(v_x1_240);
                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str15);
                                } else {
                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(404LL), 2)) {
                                    heff_drop(v_x1_240);
                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str16);
                                  } else {
                                    if (heff_intEq_c_lent(v_x1_240, MK_INT(405LL), 2)) {
                                      heff_drop(v_x1_240);
                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str17);
                                    } else {
                                      if (heff_intEq_c_lent(v_x1_240, MK_INT(408LL), 2)) {
                                        heff_drop(v_x1_240);
                                        return ((V)&g_std_2ehttp_2eserver_2ereason_str18);
                                      } else {
                                        if (heff_intEq_c_lent(v_x1_240, MK_INT(409LL), 2)) {
                                          heff_drop(v_x1_240);
                                          return ((V)&g_std_2ehttp_2eserver_2ereason_str19);
                                        } else {
                                          if (heff_intEq_c_lent(v_x1_240, MK_INT(410LL), 2)) {
                                            heff_drop(v_x1_240);
                                            return ((V)&g_std_2ehttp_2eserver_2ereason_str20);
                                          } else {
                                            if (heff_intEq_c_lent(v_x1_240, MK_INT(411LL), 2)) {
                                              heff_drop(v_x1_240);
                                              return ((V)&g_std_2ehttp_2eserver_2ereason_str21);
                                            } else {
                                              if (heff_intEq_c_lent(v_x1_240, MK_INT(413LL), 2)) {
                                                heff_drop(v_x1_240);
                                                return ((V)&g_std_2ehttp_2eserver_2ereason_str22);
                                              } else {
                                                if (heff_intEq_c_lent(v_x1_240, MK_INT(414LL), 2)) {
                                                  heff_drop(v_x1_240);
                                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str23);
                                                } else {
                                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(415LL), 2)) {
                                                    heff_drop(v_x1_240);
                                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str24);
                                                  } else {
                                                    if (heff_intEq_c_lent(v_x1_240, MK_INT(422LL), 2)) {
                                                      heff_drop(v_x1_240);
                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str25);
                                                    } else {
                                                      if (heff_intEq_c_lent(v_x1_240, MK_INT(429LL), 2)) {
                                                        heff_drop(v_x1_240);
                                                        return ((V)&g_std_2ehttp_2eserver_2ereason_str26);
                                                      } else {
                                                        if (heff_intEq_c_lent(v_x1_240, MK_INT(431LL), 2)) {
                                                          heff_drop(v_x1_240);
                                                          return ((V)&g_std_2ehttp_2eserver_2ereason_str27);
                                                        } else {
                                                          if (heff_intEq_c_lent(v_x1_240, MK_INT(500LL), 2)) {
                                                            heff_drop(v_x1_240);
                                                            return ((V)&g_std_2ehttp_2eserver_2ereason_str28);
                                                          } else {
                                                            if (heff_intEq_c_lent(v_x1_240, MK_INT(501LL), 2)) {
                                                              heff_drop(v_x1_240);
                                                              return ((V)&g_std_2ehttp_2eserver_2ereason_str29);
                                                            } else {
                                                              if (heff_intEq_c_lent(v_x1_240, MK_INT(502LL), 2)) {
                                                                heff_drop(v_x1_240);
                                                                return ((V)&g_std_2ehttp_2eserver_2ereason_str30);
                                                              } else {
                                                                if (heff_intEq_c_lent(v_x1_240, MK_INT(503LL), 2)) {
                                                                  heff_drop(v_x1_240);
                                                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str31);
                                                                } else {
                                                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(504LL), 2)) {
                                                                    heff_drop(v_x1_240);
                                                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str32);
                                                                  } else {
                                                                    if (heff_intEq_c(v_x1_240, MK_INT(505LL))) {
                                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str33);
                                                                    } else {
                                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str34);
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2ehttp_2eserver_2ereason_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2ereason(a[0]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str0, 14, "Content-Length");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str1, 17, "Transfer-Encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str2, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str3, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str4, 17, "Transfer-Encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str5, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str6, 10, "Connection");
Clo g_std_2ehttp_2eserver_2eownHeader_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eownHeader_entry, 1, 0};

V g_std_2ehttp_2eserver_2eownHeader(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_n_241 = heff_field(v_x1_240, 0);
    if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)14ULL))) {
      V v_t_243 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str0); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
        heff_drop(v_t_243);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_243);
        if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)17ULL))) {
          V v_t_244 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str1); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
            heff_drop(v_t_244);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_244);
            if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
              return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str2); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
            } else {
              return NTAG(TAG_False);
            }
          }
        } else {
          if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
            return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str3); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          } else {
            return NTAG(TAG_False);
          }
        }
      }
    } else {
      if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)17ULL))) {
        V v_t_245 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str4); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
          heff_drop(v_t_245);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_245);
          if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
            return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str5); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          } else {
            return NTAG(TAG_False);
          }
        }
      } else {
        if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
          return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str6); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        } else {
          return NTAG(TAG_False);
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ehttp_2eserver_2eownHeader_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2eownHeader(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str0, 9, "HTTP/1.1 ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str1, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str2, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str3, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str4, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str5, 16, "Content-Length: ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str6, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str7, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str8, 12, "Connection: ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str9, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str10, 2, "\015\012");
Clo g_std_2ehttp_2eserver_2eresponseBytes_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eresponseBytes_entry, 3, 0};

V g_std_2ehttp_2eserver_2eresponseBytes(V v_connection_240, V v_withBody_241, V v_res_242) {
top: ;
  V v_status_243 = heff_take_field(v_res_242, 0);
  V v_headers_244 = heff_take_field(v_res_242, 1);
  V v_body_245 = heff_get_n(v_res_242, 2, 3);
  V v_s_246 = heff_dup(v_status_243);
  V v_t_247 = heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str0), heff_intShow(heff_dup(v_status_243)));
  V v_t_248 = (g_std_2ehttp_2eserver_2ereason(v_status_243));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str1)), v_t_248);
  V v_t_2410 = (g_list_2ekeepIf_24s280149390x2003255054(v_headers_244));
  V v_t_2411 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str2); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1511444646x1476348587(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str3)), v_t_2411);
  V v_t_2414;
  if ((heff_intLt_c_lent(v_s_246, MK_INT(200LL), 2) || (heff_intEq_c_lent(v_s_246, MK_INT(204LL), 2) || heff_intEq_c_lent(v_s_246, MK_INT(304LL), 2)))) {
    v_t_2414 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str4);
  } else {
    V v_t_2413 = heff_intShow(heff_bytesLength(heff_dup(v_body_245)));
    v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str5), v_t_2413), ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str6));
  }
  V v_t_2415;
  if ((heff_unbox_word(heff_strLength_lent(v_connection_240, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_connection_240);
    v_t_2415 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str7);
  } else {
    v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str8), v_connection_240), ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str9));
  }
  V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2414), v_t_2415);
  V v_head_2417 = heff_strAppend(v_t_2416, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str10));
  if (((heff_dup(v_withBody_241) == NTAG(TAG_True)) && (heff_intLt_c_lent(v_s_246, MK_INT(200LL), 2) ? 0 : (heff_intEq_c_lent(v_s_246, MK_INT(204LL), 2) ? 0 : !heff_intEq_c_lent(v_s_246, MK_INT(304LL), 2))))) {
    heff_drop(v_s_246);
    return heff_bytesAppend(heff_bytesFromString(v_head_2417), v_body_245);
  } else {
    heff_drop(v_body_245);
    heff_drop(v_s_246);
    return heff_bytesFromString(v_head_2417);
  }
}
V g_std_2ehttp_2eserver_2eresponseBytes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2eresponseBytes(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str0, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str1, 1, ",");
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str2, 1, ",");
V g_std_2ehttp_2eserver_2econnectionSays_lam0(V self, V *args);
Clo g_std_2ehttp_2eserver_2econnectionSays_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2econnectionSays_entry, 2, 0};

V g_std_2ehttp_2eserver_2econnectionSays(V v_token_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if ((heff_unbox_word(heff_strLength_lent(v_n_244, 0)) == ((int64_t)10ULL))) {
        V v_t_246 = ({ V a_0 = v_n_244; V b_1 = ((V)&g_std_2ehttp_2eserver_2econnectionSays_str0); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          V v_t_247 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2econnectionSays_str1); V a_1 = v_v_245; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2econnectionSays_str2), v_v_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2413 = ({ V a_0 = heff_clo_n(g_std_2ehttp_2eserver_2econnectionSays_lam0, 1, 1, (V[]){heff_dup(v_token_240)}); V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_247); r_; });
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2413);
            V t_0 = v_token_240;
            V t_1 = v_rest_243;
            v_token_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop(v_t_246);
          V t_0 = v_token_240;
          V t_1 = v_rest_243;
          v_token_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_token_240;
        V t_1 = v_rest_243;
        v_token_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ehttp_2eserver_2econnectionSays_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ehttp_2eserver_2econnectionSays(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2econnectionSays_lam0(V self, V *args) {
  V v_t_248 = args[0];
  V v_token_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_prelude_2eskipSpaces(v_t_248, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_t_248, 0)) - ((int64_t)1ULL));
  V v_t_2411 = (g_prelude_2eskipSpaces(v_t_248, heff_box_word(v_t_2410), MK_INT(-1LL)));
  V v_a_2412 = heff_strSlice(v_t_248, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
  if ((heff_unbox_word(heff_strLength_lent(v_a_2412, 0)) == heff_unbox_word(heff_strLength_lent(v_token_240, 0)))) {
    return ({ V a_0 = v_a_2412; V a_1 = v_token_240; V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, a_1, a_2)); heff_drop(v_a_2412); heff_drop(v_token_240); r_; });
  } else {
    heff_drop(v_token_240);
    heff_drop(v_a_2412);
    return NTAG(TAG_False);
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam1(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam1, 2, 0};
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam3(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam3, 1, 0};
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam2(V self, V *args);
Clo g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_entry, 3, 0};

V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988(V v_c_240, V v_buf_241, V v_from_242) {
top: ;
  V v_i_243 = (g_std_2ehttp_2eserver_2eheadEnd(heff_dup(v_buf_241), v_from_242));
  if (heff_intLe_c_lent(MK_INT(0LL), v_i_243, 1)) {
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam0, 2, 2, (V[]){v_buf_241, v_i_243});
  } else {
    heff_drop(v_i_243);
    if ((((int64_t)65536ULL) < heff_unbox_word(heff_bytesLength(heff_dup(v_buf_241))))) {
      heff_drop(v_buf_241);
      return ((V)&g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam1_clo);
    } else {
      V v_t_249;
      switch (heff_tag_of(v_c_240)) {
      case TAG_MkWith: {
        V v_x_248 = heff_field(v_c_240, 0);
        v_t_249 = heff_dup(v_x_248);
        break;
      }
      default: heff_nomatch(v_c_240);
      }
      return heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam2, 2, 3, (V[]){v_t_249, v_buf_241, heff_dup(v_c_240)});
    }
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_buf_241 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_HeadAt, 2, (V[]){v_buf_241, v_i_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_HeadTooLong);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam3(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_buf_241 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_drop(v_buf_241);
    heff_drop(v_c_240);
    heff_drop_rec(v_hd_2410, 3);
    V f_ = v_k_2411;
    args[0] = NTAG(TAG_HeadEnded);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2420 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2420))) == ((int64_t)0ULL))) {
      heff_drop(v_buf_241);
      heff_drop(v_c_240);
      heff_drop_rec(v_hd_2410, 3);
      heff_drop(v_b_2420);
      V f_ = v_k_2411;
      args[0] = NTAG(TAG_HeadEnded);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      int64_t v_t_2421;
      if ((((int64_t)3ULL) < heff_unbox_word(heff_bytesLength(heff_dup(v_buf_241))))) {
        v_t_2421 = (heff_unbox_word(heff_bytesLength(heff_dup(v_buf_241))) - ((int64_t)3ULL));
      } else {
        v_t_2421 = ((int64_t)0ULL);
      }
      V v_t_2422 = ({ V a_0 = v_c_240; V a_1 = heff_bytesAppend(v_buf_241, v_b_2420); V a_2 = heff_box_word(v_t_2421); V r_ = (g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988(a_0, a_1, a_2)); heff_drop(v_c_240); r_; });
      V f_ = v_t_2422;
      heff_room[0] = v_hd_2410;
      heff_room[1] = v_k_2411;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_t_249 = heff_env(self)[0];
  V v_buf_241 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Read, 3, (V[]){v_t_249, MK_INT(65536LL), ((V)&g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam3_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})}));
  V f_ = heff_dup(heff_rfield(v_hd_2410, 1));
  args[0] = v_t_2417;
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988_lam4, 1, 4, (V[]){v_k_2411, v_buf_241, v_c_240, v_hd_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam2, 1, 0};
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_entry, 4, 0};

V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553(V v_c_240, V v_n_241, V v_got_242, V v_parts_243) {
top: ;
  if (heff_intLe_c_lent(v_n_241, v_got_242, 0)) {
    heff_drop(v_n_241);
    heff_drop(v_got_242);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_parts_243));
    V v_x_245 = heff_tag_n(TAG_Just, 1, (V[]){heff_bytesConcat(v_t_244)});
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam0, 2, 1, (V[]){v_x_245});
  } else {
    V v_t_249;
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkWith: {
      V v_x_248 = heff_field(v_c_240, 0);
      v_t_249 = heff_dup(v_x_248);
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2410 = heff_intSub(heff_dup(v_n_241), heff_dup(v_got_242));
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam1, 2, 6, (V[]){v_t_249, v_t_2410, v_got_242, heff_dup(v_c_240), v_n_241, v_parts_243});
  }
}
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam2(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_got_242 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_n_241 = heff_env(self)[3];
  V v_parts_243 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_drop(v_got_242);
    heff_drop(v_c_240);
    heff_drop(v_n_241);
    heff_drop(v_parts_243);
    heff_drop_rec(v_hd_2411, 3);
    V f_ = v_k_2412;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2421))) == ((int64_t)0ULL))) {
      heff_drop(v_got_242);
      heff_drop(v_c_240);
      heff_drop(v_n_241);
      heff_drop(v_parts_243);
      heff_drop_rec(v_hd_2411, 3);
      heff_drop(v_b_2421);
      V f_ = v_k_2412;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_t_2422 = heff_intAdd(v_got_242, heff_bytesLength(heff_dup(v_b_2421)));
      V v_t_2423 = ({ V a_0 = v_c_240; V a_1 = v_n_241; V a_2 = v_t_2422; V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2421, v_parts_243}); V r_ = (g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553(a_0, a_1, a_2, a_3)); heff_drop(v_c_240); r_; });
      V f_ = v_t_2423;
      heff_room[0] = v_hd_2411;
      heff_room[1] = v_k_2412;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_249 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_got_242 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_n_241 = heff_env(self)[4];
  V v_parts_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Read, 3, (V[]){v_t_249, v_t_2410, ((V)&g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam2_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
  V f_ = heff_dup(heff_rfield(v_hd_2411, 1));
  args[0] = v_t_2418;
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553_lam3, 1, 6, (V[]){v_k_2412, v_got_242, v_c_240, v_n_241, v_parts_243, v_hd_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str0, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str1, 6, "expect");
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str2, 12, "100-continue");
HEFF_BYTES(g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str3, 25, "HTTP/1.1 100 Continue\015\012\015\012");
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam0, 1, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam1(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam1, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam2, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam3(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam3, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam4(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam4, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam5(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam5, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam7(V self, V *args);
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam6(V self, V *args);
Clo g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_entry, 7, 0};

V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412(V v_c_240, V v_buf_241, V v_i_242, V v_r_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Length: {
    V v_n_247 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Length = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    V v_rest_248 = heff_bytesSlice(heff_dup(v_buf_241), heff_intAdd(v_i_242, MK_INT(4LL)), heff_bytesLength(v_buf_241));
    V v_c_2436;
    if (heff_intLt_c(heff_bytesLength(heff_dup(v_rest_248)), heff_dup(v_n_247))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_243, 2)), ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str0))) {
        HeffT2 v_t_249 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str1); V a_1 = heff_rfield(v_r_243, 3); HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2412 = v_field_2411;
            if ((heff_unbox_word(heff_strLength_lent(v_x_2412, 0)) == ((int64_t)12ULL))) {
              V v_t_2413 = ({ V a_0 = v_x_2412; V b_1 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str2); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(v_x_2412); heff_drop(b_1); r_; });
              if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
                heff_drop(v_t_2413);
                V v_t_2415;
                switch (heff_tag_of(v_c_240)) {
                case TAG_MkWith: {
                  V v_x_2414 = heff_field(v_c_240, 0);
                  v_t_2415 = heff_dup(v_x_2414);
                  break;
                }
                default: heff_nomatch(v_c_240);
                }
                V v_t_2417 = heff_tag_at_n(v_ru_24x5_244_24Length, TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 3, (V[]){v_t_2415, ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_str3), ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam0_clo)})});
                V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
                V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
                V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
                v_c_2436 = heff_tr(heff_call(((V)&g_co_2eop_24s1979766345x1806196139_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
              } else {
                heff_drop_cell(v_ru_24x5_244_24Length, 1);
                heff_drop(v_t_2413);
                v_c_2436 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam1_clo);
              }
            } else {
              heff_drop_cell(v_ru_24x5_244_24Length, 1);
              heff_drop(v_x_2412);
              v_c_2436 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam2_clo);
            }
          } else {
            heff_drop_cell(v_ru_24x5_244_24Length, 1);
            heff_drop(v_field_2411);
            v_c_2436 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam3_clo);
          }
        }
      } else {
        heff_drop_cell(v_ru_24x5_244_24Length, 1);
        v_c_2436 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam4_clo);
      }
    } else {
      heff_drop_cell(v_ru_24x5_244_24Length, 1);
      v_c_2436 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam5_clo);
    }
    return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam6, 1, 6, (V[]){v_rest_248, heff_dup(v_c_240), v_n_247, v_z_245, v_r_243, v_z_246})});
  }
  case TAG_Refuse: {
    V v_status_2445 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    heff_drop(v_buf_241);
    heff_drop(v_i_242);
    heff_drop_rec(v_r_243, 6);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){v_status_2445})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam0(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V v_t_2423 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2422;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V v_t_2426 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2425;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  heff_drop(v_hd_2427);
  V v_t_2429 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2428;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V v_t_2432 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2431;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam5(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V v_t_2435 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2434;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_n_247 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2444;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_243, 6);
    heff_drop(v_n_247);
    v_t_2444 = NTAG(TAG_Ended);
    break;
  }
  case TAG_Just: {
    V v_b_2441 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    V v_t_2442 = ({ V rv_4 = heff_bytesSlice(heff_dup(v_b_2441), MK_INT(0LL), heff_dup(v_n_247)); V rr_ = heff_rec_reuse_nf(v_r_243, 47ULL, 6, shape_method__target__version__headers__body__peer, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_2443 = heff_bytesSlice(heff_dup(v_b_2441), v_n_247, heff_bytesLength(v_b_2441));
    v_t_2444 = heff_tag_n(TAG_Asked, 2, (V[]){v_t_2442, v_t_2443});
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V f_ = v_z_246;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_rest_248 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_n_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_rest_248), NTAG(TAG_Nil)});
  V v_c_2439 = ({ V a_0 = v_c_240; V a_1 = heff_dup(v_n_247); V a_2 = heff_bytesLength(v_rest_248); V a_3 = v_t_2438; V r_ = (g_std_2ehttp_2eserver_2ereadBody_24s1113221429x1382543553(a_0, a_1, a_2, a_3)); heff_drop(v_c_240); r_; });
  V f_ = v_c_2439;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412_lam7, 1, 3, (V[]){v_r_243, v_n_247, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str0, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str1, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str2, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str3, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str4, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str5, 8, "HTTP/1.0");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str6, 5, "HTTP/");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str7, 17, "transfer-encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str8, 14, "content-length");
Clo g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_entry, 5, 0};

V g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815(V v_c_240, V v_peer_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_HeadAt: {
    V v_buf_245 = heff_field(v_x3_242, 0);
    V v_i_246 = heff_field(v_x3_242, 1);
    V v_text_247 = heff_bytesToString(heff_bytesSlice(heff_dup(v_buf_245), MK_INT(0LL), heff_dup(v_i_246)));
    V v_peer_248 = v_peer_241;
    V v_x2_249 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str0); V a_1 = v_text_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str1), v_text_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_247); r_; });
    V v_x4_2425;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nil: {
      heff_drop(v_peer_248);
      v_x4_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_l_2410 = heff_field(v_x2_249, 0);
      V v_rest_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      V v_x2_2412 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str2); V a_1 = v_l_2410; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str3), v_l_2410, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_l_2410); r_; });
      HeffT2 v_t_2413 = (g_std_2ehttp_2eserver_2eheaderLines_24cpr(v_rest_2411));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        switch (heff_tag_of(v_x2_2412)) {
        case TAG_Nil: {
          heff_drop(v_peer_248);
          heff_drop(v_field_2415);
          v_x4_2425 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_m_2416 = heff_field(v_x2_2412, 0);
          V v_x22_2417 = heff_field(v_x2_2412, 1);
          heff_take_n(v_x2_2412, 3ULL, 2);
          switch (heff_tag_of(v_x22_2417)) {
          case TAG_Nil: {
            heff_drop(v_peer_248);
            heff_drop(v_field_2415);
            heff_drop(v_m_2416);
            v_x4_2425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_t_2418 = heff_field(v_x22_2417, 0);
            V v_x222_2419 = heff_field(v_x22_2417, 1);
            heff_take_n(v_x22_2417, 3ULL, 2);
            switch (heff_tag_of(v_x222_2419)) {
            case TAG_Nil: {
              heff_drop(v_peer_248);
              heff_drop(v_field_2415);
              heff_drop(v_m_2416);
              heff_drop(v_t_2418);
              v_x4_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Cons: {
              V v_v_2420 = heff_field(v_x222_2419, 0);
              V v_x2222_2421 = heff_field(v_x222_2419, 1);
              heff_take_n(v_x222_2419, 3ULL, 2);
              switch (heff_tag_of(v_x2222_2421)) {
              case TAG_Nil: {
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  V v_hs_2422 = v_field_2415;
                  if (((heff_unbox_word(heff_strLength_lent(v_m_2416, 0)) == ((int64_t)0ULL)) || (heff_unbox_word(heff_strLength_lent(v_t_2418, 0)) == ((int64_t)0ULL)))) {
                    heff_drop(v_peer_248);
                    heff_drop(v_m_2416);
                    heff_drop(v_t_2418);
                    heff_drop(v_v_2420);
                    heff_drop(v_hs_2422);
                    v_x4_2425 = NTAG(TAG_Nothing);
                  } else {
                    v_x4_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(6, shape_method__target__version__headers__body__peer, (V[]){v_m_2416, v_t_2418, v_v_2420, v_hs_2422, heff_dup(g_bytes_2eempty_get()), v_peer_248})});
                  }
                } else {
                  heff_drop(v_peer_248);
                  heff_drop(v_field_2415);
                  heff_drop(v_m_2416);
                  heff_drop(v_t_2418);
                  heff_drop(v_v_2420);
                  v_x4_2425 = NTAG(TAG_Nothing);
                }
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_x2222_2421, 0ULL, 2);
                heff_drop(v_peer_248);
                heff_drop(v_field_2415);
                heff_drop(v_m_2416);
                heff_drop(v_t_2418);
                heff_drop(v_v_2420);
                v_x4_2425 = NTAG(TAG_Nothing);
                break;
              }
              default: heff_nomatch(v_x2222_2421);
              }
              break;
            }
            default: heff_nomatch(v_x222_2419);
            }
            break;
          }
          default: heff_nomatch(v_x22_2417);
          }
          break;
        }
        default: heff_nomatch(v_x2_2412);
        }
      }
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    switch (heff_tag_of(v_x4_2425)) {
    case TAG_Nothing: {
      heff_drop(v_z_243);
      return heff_tail(v_z_244, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){MK_INT(400LL)})});
    }
    case TAG_Just: {
      V v_r_2426 = heff_field(v_x4_2425, 0);
      V v_ru_24x4_2425_24Just = heff_take_reuse_n(v_x4_2425, 1ULL, 1);
      V v_r_2427 = heff_dup(v_r_2426);
      V v_version_2428 = heff_take_field(v_r_2427, 2);
      V v_headers_2429 = heff_get_n(v_r_2427, 3, 6);
      V v_t_2443;
      if ((heff_strEq_c_lent(v_version_2428, ((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str4), 2) ? 0 : !heff_strEq_c_lent(v_version_2428, ((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str5), 2))) {
        heff_drop(v_headers_2429);
        V v_t_2430;
        if (heff_strEq_c(heff_strSlice(v_version_2428, MK_INT(0LL), MK_INT(5LL)), ((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str6))) {
          v_t_2430 = MK_INT(505LL);
        } else {
          v_t_2430 = MK_INT(400LL);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x4_2425_24Just, TAG_Refuse, 1, (V[]){v_t_2430});
      } else {
        heff_drop(v_version_2428);
        HeffT2 v_t_2431 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str7); V a_1 = v_headers_2429; HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2433 = v_t_2431.f[1];
          int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
          if ((v_tag_2432 == ((int64_t)0ULL))) {
            heff_drop(v_headers_2429);
            V v_x_2434 = v_field_2433;
            heff_drop(v_x_2434);
            v_t_2443 = heff_tag_at_n(v_ru_24x4_2425_24Just, TAG_Refuse, 1, (V[]){MK_INT(501LL)});
          } else {
            heff_drop(v_field_2433);
            HeffT2 v_t_2435 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_str8); V a_1 = v_headers_2429; HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_headers_2429); r_; });
            {
              V v_field_2437 = v_t_2435.f[1];
              int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
              if ((v_tag_2436 == ((int64_t)0ULL))) {
                V v_s_2438 = v_field_2437;
                HeffT2 v_t_2439 = ({ V a_0 = v_s_2438; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2438); r_; });
                {
                  V v_field_2441 = v_t_2439.f[1];
                  int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                  if ((v_tag_2440 == ((int64_t)0ULL))) {
                    V v_n_2442 = v_field_2441;
                    if (heff_intLt_c_lent(v_n_2442, MK_INT(0LL), 2)) {
                      heff_drop(v_n_2442);
                      v_t_2443 = heff_tag_at_n(v_ru_24x4_2425_24Just, TAG_Refuse, 1, (V[]){MK_INT(400LL)});
                    } else {
                      if (heff_intLt_c_lent(MK_INT(67108864LL), v_n_2442, 1)) {
                        heff_drop(v_n_2442);
                        v_t_2443 = heff_tag_at_n(v_ru_24x4_2425_24Just, TAG_Refuse, 1, (V[]){MK_INT(413LL)});
                      } else {
                        v_t_2443 = heff_tag_at_n(v_ru_24x4_2425_24Just, TAG_Length, 1, (V[]){v_n_2442});
                      }
                    }
                  } else {
                    heff_drop(v_field_2441);
                    v_t_2443 = heff_tag_at_n(v_ru_24x4_2425_24Just, TAG_Refuse, 1, (V[]){MK_INT(400LL)});
                  }
                }
              } else {
                heff_drop(v_field_2437);
                v_t_2443 = heff_tag_at_n(v_ru_24x4_2425_24Just, TAG_Length, 1, (V[]){MK_INT(0LL)});
              }
            }
          }
        }
      }
      return (g_std_2ehttp_2eserver_2ewithBody_24s160458746x706390412(v_c_240, heff_dup(v_buf_245), heff_dup(v_i_246), v_r_2426, v_t_2443, v_z_243, v_z_244));
    }
    default: return heff_nomatch(v_x4_2425);
    }
  }
  case TAG_HeadTooLong: {
    heff_drop(v_peer_241);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){MK_INT(431LL)})});
  }
  case TAG_HeadEnded: {
    heff_drop(v_peer_241);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Ended)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815(a0, a[1], a2, a[3], a[4]); heff_drop(a0); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam0, 1, 0};
V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_entry, 4, 0};

V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506(V v_c_240, V v_got_241, V v_p_242, V v_p_243) {
top: ;
  if ((((int64_t)1048576ULL) <= heff_peek_word(v_got_241))) {
    heff_drop(v_got_241);
    heff_drop_rec(v_p_242, 3);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  } else {
    V v_t_245;
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkWith: {
      V v_x_244 = heff_field(v_c_240, 0);
      v_t_245 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Read, 3, (V[]){v_t_245, MK_INT(65536LL), ((V)&g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam0_clo)})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
    return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam1, 1, 4, (V[]){v_p_243, v_got_241, heff_dup(v_c_240), v_p_242})});
  }
}
V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_got_241 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_drop(v_got_241);
    heff_drop(v_c_240);
    heff_drop_rec(v_p_242, 3);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2414 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2414))) == ((int64_t)0ULL))) {
      heff_drop(v_got_241);
      heff_drop(v_c_240);
      heff_drop_rec(v_p_242, 3);
      heff_drop(v_b_2414);
      V f_ = v_p_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      int64_t v_t_2415 = (heff_unbox_word(v_got_241) + heff_unbox_word(heff_bytesLength(v_b_2414)));
      return ({ V a_0 = v_c_240; V a_1 = heff_box_word(v_t_2415); V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506(a_0, a_1, a_2, a_3)); heff_drop(v_c_240); r_; });
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str0, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str1, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str2, 10, "keep-alive");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str3, 4, "HEAD");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str4, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str5, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str6, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str7, 8, "HTTP/1.0");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str8, 10, "keep-alive");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str9, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str10, 4, "HEAD");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str11, 1, "\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str12, 12, "Content-Type");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str13, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str14, 5, "close");
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam2, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam4(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam4, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam5(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam7(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam7, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam9(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam9, 2, 0};
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam11(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam11_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam11, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam12(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam10(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam13(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam8(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam6(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam14(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam14_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam14, 2, 0};
Clo g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_entry, 3, 0};

V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468(V v_c_240, V v_handle_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Asked: {
    V v_r_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_c_245 = heff_tr(heff_call(v_handle_241, 1, (V[]){heff_dup(v_r_243)}));
    return heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam0, 2, 4, (V[]){v_c_245, v_r_243, heff_dup(v_c_240), v_rest_244});
  }
  case TAG_Refused: {
    V v_status_2441 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    heff_drop(v_handle_241);
    V v_t_2442 = (g_std_2ehttp_2eserver_2ereason(heff_dup(v_status_2441)));
    V v_t_2443 = heff_strAppend(v_t_2442, ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str11));
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str12), ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str13)}), NTAG(TAG_Nil)});
    V v_t_2445 = heff_rec_n(3, shape_status__headers__body, (V[]){v_status_2441, v_t_2444, heff_bytesFromString(v_t_2443)});
    V v_b_2446 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str14); V b_1 = NTAG(TAG_True); V a_2 = v_t_2445; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2448;
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkWith: {
      V v_x_2447 = heff_field(v_c_240, 0);
      v_t_2448 = heff_dup(v_x_2447);
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam6, 2, 3, (V[]){v_t_2448, v_b_2446, heff_dup(v_c_240)});
  }
  case TAG_Ended: {
    heff_drop(v_handle_241);
    return ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam14_clo);
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam2(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 0ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24x_2421_24Left, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 0ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V f_ = v_k_247;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam4(V self, V *args) {
  V v_r_2431 = args[0];
  return v_r_2431;
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_close_2425 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2440;
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    V v_ru_24x_2437_24Left = heff_take_reuse_n(v_x_2437, 0ULL, 1);
    heff_drop(v_close_2425);
    heff_drop(v_rest_244);
    v_t_2440 = heff_tag_at_n(v_ru_24x_2437_24Left, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2437_24Right = heff_take_reuse_n(v_x_2437, 0ULL, 1);
    if ((heff_dup(v_close_2425) == NTAG(TAG_True))) {
      heff_drop(v_close_2425);
      heff_drop(v_rest_244);
      v_t_2440 = heff_tag_at_n(v_ru_24x_2437_24Right, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    } else {
      heff_drop(v_close_2425);
      v_t_2440 = heff_tag_at_n(v_ru_24x_2437_24Right, TAG_Next, 1, (V[]){v_rest_244});
    }
    break;
  }
  default: heff_nomatch(v_x_2437);
  }
  V f_ = v_k_247;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_rest_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410;
  if (heff_strEq_c(heff_dup(heff_rfield(v_r_243, 2)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str0))) {
    V v_x1_249 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str1); V a_1 = heff_rfield(v_r_243, 3); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    v_x1_2410 = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
    heff_drop(v_x1_249);
  } else {
    v_x1_2410 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str2); V a_1 = heff_rfield(v_r_243, 3); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
  }
  if (!(heff_dup(v_x1_2410) == NTAG(TAG_True))) {
    heff_drop(v_rest_244);
    heff_drop(v_x1_2410);
    V v_t_2411 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_r_243, 0)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str3)));
    heff_drop_rec(v_r_243, 6);
    V v_b_2412 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str4); V a_1 = v_t_2411; V a_2 = v_x_248; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    V v_t_2414;
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkWith: {
      V v_x_2413 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 3, (V[]){v_t_2414, v_b_2412, ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam2_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam3, 1, 1, (V[]){v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x1_2410);
    V v_close_2425 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str5); V a_1 = heff_rfield(v_x_248, 1); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2426;
    if ((heff_dup(v_close_2425) == NTAG(TAG_True))) {
      v_t_2426 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str6);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_243, 2)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str7))) {
        v_t_2426 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str8);
      } else {
        v_t_2426 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str9);
      }
    }
    V v_t_2427 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_r_243, 0)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_str10)));
    heff_drop_rec(v_r_243, 6);
    V v_b_2428 = ({ V a_0 = v_t_2426; V a_1 = v_t_2427; V a_2 = v_x_248; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
    V v_t_2430;
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkWith: {
      V v_x_2429 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      v_t_2430 = v_x_2429;
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 3, (V[]){v_t_2430, v_b_2428, ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam4_clo)})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2436;
    heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam5, 1, 3, (V[]){v_close_2425, v_rest_244, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_rest_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam1, 1, 5, (V[]){v_r_243, v_c_240, v_hd_246, v_k_247, v_rest_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam7(V self, V *args) {
  V v_r_2451 = args[0];
  return v_r_2451;
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam9(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  heff_drop(v_hd_2459);
  V f_ = v_k_2460;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam11(V self, V *args) {
  V v_r_2466 = args[0];
  return v_r_2466;
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam12(V self, V *args) {
  V v_x_2472 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_hd_2464 = heff_env(self)[1];
  V v_k_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2472);
  return ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_hd_2464; V a_3 = v_k_2465; V r_ = (g_std_2ehttp_2eserver_2edrain_24s1374012566x1798895506(a_0, a_1, a_2, a_3)); heff_drop(v_c_240); r_; });
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam10(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_t_2463 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Shutdown, 2, (V[]){v_t_2463, ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam11_clo)})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2464, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})}));
  V f_ = heff_dup(heff_rfield(v_hd_2464, 1));
  args[0] = v_t_2471;
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam12, 1, 3, (V[]){v_c_240, v_hd_2464, v_k_2465});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam13(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2474);
  V v_t_2475 = heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_False)});
  V f_ = v_k_2450;
  args[0] = v_t_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam8(V self, V *args) {
  V v_x_2457 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_hd_2449 = heff_env(self)[1];
  V v_k_2450 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2473;
  switch (heff_tag_of(v_x_2457)) {
  case TAG_Left: {
    heff_take_n(v_x_2457, 0ULL, 1);
    heff_drop(v_c_240);
    v_t_2473 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam9_clo);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2457, 0ULL, 1);
    V v_t_2463;
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkWith: {
      V v_x_2462 = heff_dup(heff_field(v_c_240, 0));
      v_t_2463 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    v_t_2473 = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam10, 2, 2, (V[]){v_t_2463, v_c_240});
    break;
  }
  default: heff_nomatch(v_x_2457);
  }
  V f_ = v_t_2473;
  heff_room[0] = v_hd_2449;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam13, 1, 1, (V[]){v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_t_2448 = heff_env(self)[0];
  V v_b_2446 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Write, 3, (V[]){v_t_2448, v_b_2446, ((V)&g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam7_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
  V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
  args[0] = v_t_2456;
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam8, 1, 3, (V[]){v_c_240, v_hd_2449, v_k_2450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468_lam14(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  heff_drop(v_hd_2476);
  V v_t_2478 = heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_False)});
  V f_ = v_k_2477;
  args[0] = v_t_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam0(V self, V *args);
Clo g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_entry, 6, 0};

V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743(V v_handle_240, V v_c_241, V v_peer_242, V v_buf_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = (g_std_2ehttp_2eserver_2ereadHead_24s3733524x1231507988(v_c_241, v_buf_243, MK_INT(0LL)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam0, 1, 5, (V[]){heff_dup(v_c_241), v_peer_242, v_z_244, v_handle_240, v_z_245})});
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_handle_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_peer_242 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Next: {
    V v_rest_2411 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    return ({ V a_0 = v_handle_240; V a_1 = v_c_241; V a_2 = v_peer_242; V a_3 = v_rest_2411; V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_241); r_; });
  }
  case TAG_Done: {
    V v_stop_2412 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    heff_drop(v_handle_240);
    heff_drop(v_c_241);
    heff_drop(v_peer_242);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = v_stop_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_handle_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_peer_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_249 = (g_std_2ehttp_2eserver_2eanswered_24s145638418x1481030468(v_c_241, heff_dup(v_handle_240), v_x_248));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam2, 1, 5, (V[]){v_handle_240, v_c_241, v_peer_242, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_peer_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_handle_240 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_c_241; V a_1 = heff_dup(v_peer_242); V a_2 = v_x_247; V a_3 = heff_dup(v_z_244); V a_4 = heff_clo_n(g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743_lam1, 1, 5, (V[]){heff_dup(v_c_241), v_handle_240, v_z_244, v_peer_242, v_z_245}); V r_ = (g_std_2ehttp_2eserver_2eheaded_24s338860617x534664815(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_c_241); heff_drop(v_x_247); r_; });
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam6(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam5(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam8(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam7(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam9(V self, V *args); static Clo g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam9, 1, 0};
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam10(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam11(V self, V *args); static Clo g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam11_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam11, 1, 0};
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam14(V self, V *args); static Clo g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam14_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam14, 1, 0};
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam16(V self, V *args); static Clo g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam16_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam16, 3, 0};
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam15(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam13(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam12(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam18(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam17(V self, V *args);
Clo g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_entry, 3, 0};

V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130(V v_stopped_240, V v_l_241, V v_handle_242) {
top: ;
  V v_l_243 = heff_dup(v_l_241);
  V v_body_2441 = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam0, 1, 3, (V[]){heff_dup(v_stopped_240), v_l_241, v_handle_242});
  V v_t_2443;
  switch (heff_tag_of(v_l_243)) {
  case TAG_MkWith: {
    V v_x_2442 = heff_field(v_l_243, 0);
    heff_take_n(v_l_243, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_l_243);
  }
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Accept, 2, (V[]){v_t_2443, ((V)&g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam11_clo)})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_c_2470 = (g_co_2eop_24s979864723x1871992405(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam12, 3, 1, (V[]){v_body_2441})));
  return heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam17, 2, 2, (V[]){v_c_2470, v_stopped_240});
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130(a[0], a[1], a[2]);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam2(V self, V *args) {
  V v_p_249 = args[0];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_246, 2, 3);
  args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_p_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam6(V self, V *args) {
  V v_p_2420 = args[0];
  V v_hd_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_2418, 2, 3);
  args[0] = heff_tag_n(TAG_InR, 1, (V[]){v_p_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_kont_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = ({ V rv_2 = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam6, 1, 1, (V[]){heff_dup(v_hd_2418)}); V rr_ = heff_rec_reuse_nf(v_hd_2418, 3ULL, 3, shape_ret__bind__malg, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_c_2417;
  args[0] = v_t_2421;
  args[1] = v_kont_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam4(V self, V *args) {
  V v_r_2416 = args[0];
  V v_handle_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2417 = heff_tr(heff_call(v_handle_242, 1, (V[]){v_r_2416}));
  return heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam5, 2, 1, (V[]){v_c_2417});
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2426);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_247;
  args[0] = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam8, 3, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam9(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam10(V self, V *args) {
  V v_x_2438 = args[0];
  V v_p_2429 = heff_env(self)[0];
  V v_handle_2422 = heff_env(self)[1];
  V v_c_2423 = heff_env(self)[2];
  V v_p_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    heff_drop_clo(v_handle_2422, 1);
    heff_drop(v_c_2423);
    heff_drop_rec(v_p_2424, 3);
    V f_ = v_p_2429;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_peer_2440 = heff_field(v_x_2438, 0);
    heff_take_n(v_x_2438, 1ULL, 1);
    return ({ V a_0 = v_handle_2422; V a_1 = v_c_2423; V a_2 = v_peer_2440; V a_3 = heff_dup(g_bytes_2eempty_get()); V a_4 = v_p_2424; V a_5 = v_p_2429; V r_ = (g_std_2ehttp_2eserver_2eserveFrom_24s1916109523x2069654743(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_2423); r_; });
  }
  default: return heff_nomatch(v_x_2438);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_handle_242 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  V v_handle_2422 = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam4, 1, 1, (V[]){v_handle_242});
  V v_c_2423 = v_c_244;
  V v_p_2424 = v_hd_246;
  V v_p_2429 = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam7, 1, 1, (V[]){v_k_247});
  V v_t_2431;
  switch (heff_tag_of(v_c_2423)) {
  case TAG_MkWith: {
    V v_x_2430 = heff_dup(heff_field(v_c_2423, 0));
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_c_2423);
  }
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Peer, 2, (V[]){v_t_2431, ((V)&g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam9_clo)})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_2424, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  V f_ = heff_dup(heff_rfield(v_p_2424, 1));
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam10, 1, 4, (V[]){v_p_2429, v_handle_2422, v_c_2423, v_p_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_handle_242 = heff_env(self)[1];
  V v_c_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_kont_248 = heff_dup(heff_rfield(v_hd_246, 0));
  V v_t_2410 = heff_rec_n(3, shape_ret__bind__malg, (V[]){heff_dup(heff_rfield(v_hd_246, 0)), heff_dup(heff_rfield(v_hd_246, 1)), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam2, 1, 1, (V[]){heff_dup(v_hd_246)})});
  V v_t_2411 = heff_tr(heff_call(v_c_245, 2, (V[]){v_t_2410, v_kont_248}));
  V v_t_2412 = heff_tag_n(TAG_Spawn, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2414;
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam3, 1, 4, (V[]){v_handle_242, v_c_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam0(V self, V *args) {
  V v_c_244 = args[0];
  V v_stopped_240 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_handle_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130(v_stopped_240, v_l_241, heff_dup(v_handle_242)));
  return heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam1, 2, 3, (V[]){v_c_245, v_handle_242, v_c_244});
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam11(V self, V *args) {
  V v_r_2444 = args[0];
  return v_r_2444;
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam14(V self, V *args) {
  V v_r_2457 = args[0];
  return v_r_2457;
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam16(V self, V *args) {
  V v_a_2467 = args[0];
  V v_a_2468 = args[1];
  V v_a_2469 = args[2];
  heff_drop(v_a_2468);
  V f_ = v_a_2469;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_a_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam15(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2456 = heff_env(self)[0];
  V v_x_2454 = heff_env(self)[1];
  V v_hd_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Left: {
    V v_x_2463 = heff_field(v_x_2462, 0);
    heff_take_n(v_x_2462, 1ULL, 1);
    heff_drop(v_x_2454);
    heff_drop(v_hd_2455);
    V f_ = v_k_2456;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2463});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2464 = heff_field(v_x_2462, 0);
    heff_take_n(v_x_2462, 1ULL, 1);
    switch (heff_tag_of(v_y_2464)) {
    case TAG_Left: {
      V v_err_2465 = heff_field(v_y_2464, 0);
      heff_take_n(v_y_2464, 1ULL, 1);
      heff_drop(v_x_2454);
      heff_drop(v_hd_2455);
      V f_ = v_k_2456;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2465});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2464, 0ULL, 1);
      return heff_tail(v_x_2454, 5, (V[]){NTAG(TAG_MkUnit), heff_dup(g_exception_2eattempted_24s1991057797x762774998_get()), ((V)&g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam16_clo), v_hd_2455, v_k_2456});
    }
    default: return heff_nomatch(v_y_2464);
    }
  }
  default: return heff_nomatch(v_x_2462);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam13(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2455 = args[1];
  V v_k_2456 = args[2];
  V v_x_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_2453, ((V)&g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam14_clo)})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s1703844634x634335703(v_t_2461, heff_dup(v_hd_2455), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam15, 1, 3, (V[]){v_k_2456, v_x_2454, v_hd_2455})));
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam12(V self, V *args) {
  V v_x_2449 = args[0];
  V v_z_2450 = args[1];
  V v_z_2451 = args[2];
  V v_body_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Left: {
    V v_err_2452 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    heff_drop(v_z_2450);
    heff_drop_clo(v_body_2441, 3);
    V f_ = v_z_2451;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2452});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_x_2453 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    return heff_tail(v_body_2441, 5, (V[]){heff_tag_n(TAG_MkWith, 1, (V[]){heff_dup(v_x_2453)}), heff_dup(g_exception_2eattempted_24s1991057797x762774998_get()), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam13, 3, 1, (V[]){v_x_2453}), v_z_2450, v_z_2451});
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam18(V self, V *args) {
  V v_x_2473 = args[0];
  V v_stopped_240 = heff_env(self)[0];
  V v_hd_2471 = heff_env(self)[1];
  V v_k_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2473)) {
  case TAG_Left: {
    V v_err_2474 = heff_field(v_x_2473, 0);
    V v_ru_24x_2473_24Left = heff_take_reuse_n(v_x_2473, 1ULL, 1);
    V v_t_2475 = heff_tag_n(TAG_Send, 3, (V[]){v_stopped_240, heff_get_n(v_err_2474, 0, 3), NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s1876960293x1282655859(heff_tag_at_n(v_ru_24x_2473_24Left, TAG_InL, 1, (V[]){v_t_2475}), v_hd_2471, v_k_2472));
  }
  case TAG_Right: {
    heff_take_n(v_x_2473, 0ULL, 1);
    heff_drop(v_stopped_240);
    heff_drop(v_hd_2471);
    V f_ = v_k_2472;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2473);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam17(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  V v_stopped_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2470;
  args[0] = heff_dup(v_hd_2471);
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130_lam18, 1, 3, (V[]){v_stopped_240, v_hd_2471, v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam0, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam3(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam3, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_entry, 4, 0};

V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023(V v_l_240, V v_handle_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_NewChan, 1, (V[]){((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam0_clo)})});
  return (g_co_2eop_24s1876960293x1282655859(v_t_245, heff_dup(v_hd_242), heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam1, 1, 4, (V[]){v_l_240, v_handle_241, v_hd_242, v_k_243})));
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023(a[0], a[1], a[2], a[3]);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return v_n_244;
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam3(V self, V *args) {
  V v_v_2410 = args[0];
  return v_v_2410;
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2412);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Recv, 2, (V[]){v_x_246, ((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam3_clo)})});
  return (g_co_2eop_24s1876960293x1282655859(v_t_2411, v_hd_242, heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam4, 1, 1, (V[]){v_k_243})));
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_handle_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_247 = (g_std_2ehttp_2eserver_2eacceptor_24s1024033832x1272692130(heff_dup(v_x_246), v_l_240, v_handle_241));
  V v_t_248 = heff_tag_n(TAG_Spawn, 2, (V[]){v_c_247, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1876960293x1282655859(heff_tag_n(TAG_InL, 1, (V[]){v_t_248}), heff_dup(v_hd_242), heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s1845374103x772353023_lam2, 1, 3, (V[]){v_x_246, v_hd_242, v_k_243})));
}