// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Accept 48933
#define TAG_Asked 63168
#define TAG_Done 47505
#define TAG_Ended 63166
#define TAG_HeadAt 24796
#define TAG_HeadEnded 64500
#define TAG_HeadTooLong 4872
#define TAG_Left 13886
#define TAG_Length 531
#define TAG_MkWith 3751
#define TAG_NewChan 9424
#define TAG_Next 8500
#define TAG_Peer 1965
#define TAG_RDone 16778
#define TAG_Read 61409
#define TAG_Recv 61489
#define TAG_Refuse 3461
#define TAG_Refused 41566
#define TAG_Release 43671
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Shutdown 48081
#define TAG_Spawn 10053
#define TAG_Write 36323
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_headers 1027165638
#define LBL_malg 9839318
#define LBL_method 869586956
#define LBL_peer 9932329
#define LBL_ret 322331
#define LBL_status 1054660381
#define LBL_target 1066236092
#define LBL_version 583465758
static uint32_t shape_method__target__version__headers__body__peer[] = {LBL_method, LBL_target, LBL_version, LBL_headers, LBL_body, LBL_peer};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_status__headers__body[] = {LBL_status, LBL_headers, LBL_body};
V g_bytes_2eempty_get(void);
V g_co_2eop_24s162716155x1210144019(V, V, V);
V g_co_2eop_24s162716155x1210144019_entry(V self, V *a);
extern Clo g_co_2eop_24s162716155x1210144019_clo;
V g_co_2eop_24s279158732x359344659(V, V, V, V, V, V, V);
V g_co_2eop_24s279158732x359344659_entry(V self, V *a);
extern Clo g_co_2eop_24s279158732x359344659_clo;
V g_co_2eop_24s459815859x1387532636(V, V, V);
V g_co_2eop_24s459815859x1387532636_entry(V self, V *a);
extern Clo g_co_2eop_24s459815859x1387532636_clo;
V g_co_2eop_24s728204878x155198609(V, V, V, V, V, V, V);
V g_co_2eop_24s728204878x155198609_entry(V self, V *a);
extern Clo g_co_2eop_24s728204878x155198609_clo;
V g_green_2egreenAlg_24s1477571606x442912311(V);
V g_green_2egreenAlg_24s1477571606x442912311_entry(V self, V *a);
extern Clo g_green_2egreenAlg_24s1477571606x442912311_clo;
V g_green_2ethenRes_24s1747913378x1698907254(V, V);
V g_green_2ethenRes_24s1747913378x1698907254_entry(V self, V *a);
extern Clo g_green_2ethenRes_24s1747913378x1698907254_clo;
V g_green_2ethenRes_24s352754375x1842358360(V);
V g_green_2ethenRes_24s352754375x1842358360_entry(V self, V *a);
extern Clo g_green_2ethenRes_24s352754375x1842358360_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s93534634x1143141184(V);
V g_list_2efilter_24s93534634x1143141184_entry(V self, V *a);
extern Clo g_list_2efilter_24s93534634x1143141184_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1511444646x1476348587(V, V);
V g_list_2efoldl_24s1511444646x1476348587_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1511444646x1476348587_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2ehttp_2eheaderIn(V, V);
V g_std_2ehttp_2eheaderIn_entry(V self, V *a);
extern Clo g_std_2ehttp_2eheaderIn_clo;
HeffT2 g_std_2ehttp_2eheaderIn_24cpr(V, V);
V g_std_2ehttp_2esameFrom(V, V, V);
V g_std_2ehttp_2esameFrom_entry(V self, V *a);
extern Clo g_std_2ehttp_2esameFrom_clo;
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196(V, V, V, V);
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_clo;
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186(V, V, V, V);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_clo;
V g_std_2ehttp_2eserver_2ebodyOf(V);
V g_std_2ehttp_2eserver_2ebodyOf_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ebodyOf_clo;
V g_std_2ehttp_2eserver_2econnectionSays(V, V);
V g_std_2ehttp_2eserver_2econnectionSays_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2econnectionSays_clo;
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361(V, V, V, V, V);
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_clo;
V g_std_2ehttp_2eserver_2eheadEnd(V, V);
V g_std_2ehttp_2eserver_2eheadEnd_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheadEnd_clo;
V g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425(V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425_clo;
HeffT2 g_std_2ehttp_2eserver_2eheaderAt_24cpr(V, V);
V g_std_2ehttp_2eserver_2eheaderLines(V);
V g_std_2ehttp_2eserver_2eheaderLines_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eheaderLines_clo;
HeffT2 g_std_2ehttp_2eserver_2eheaderLines_24cpr(V);
V g_std_2ehttp_2eserver_2elengthOf(V);
V g_std_2ehttp_2eserver_2elengthOf_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2elengthOf_clo;
V g_std_2ehttp_2eserver_2eownHeader(V);
V g_std_2ehttp_2eserver_2eownHeader_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eownHeader_clo;
HeffT2 g_std_2ehttp_2eserver_2eparseHead_24cpr(V, V);
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608(V, V, V, V, V);
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_clo;
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735(V, V, V, V);
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_clo;
V g_std_2ehttp_2eserver_2ereason(V);
V g_std_2ehttp_2eserver_2ereason_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ereason_clo;
HeffT2 g_std_2ehttp_2eserver_2erequestOf_24cpr(V, V, V);
V g_std_2ehttp_2eserver_2eresponseBytes(V, V, V);
V g_std_2ehttp_2eserver_2eresponseBytes_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eresponseBytes_clo;
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777(V, V, V);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_clo;
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551(V, V, V, V, V);
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_clo;
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480(V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_clo;
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756(V, V, V, V, V, V, V, V);
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_clo;
Clo g_std_2ehttp_2eserver_2eheadEnd_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eheadEnd_entry, 2, 0};

V g_std_2ehttp_2eserver_2eheadEnd(V v_b_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_bytesLength(heff_dup(v_b_240)), heff_intAdd(heff_dup(v_i_241), MK_INT(4LL)))) {
    heff_drop(v_b_240);
    heff_drop(v_i_241);
    return MK_INT(-1LL);
  } else {
    V v_t_243 = heff_box_u8(heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_dup(v_i_241))));
    if (heff_intEq_c(v_t_243, MK_INT(13LL))) {
      uint8_t v_t_245 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL))));
      if (heff_intEq_c(heff_box_u8(v_t_245), MK_INT(10LL))) {
        uint8_t v_t_247 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
        if (heff_intEq_c(heff_box_u8(v_t_247), MK_INT(13LL))) {
          uint8_t v_t_249 = heff_unbox_u8(heff_bytesAt(heff_dup(v_b_240), heff_intAdd(heff_dup(v_i_241), MK_INT(3LL))));
          if (heff_intEq_c(heff_box_u8(v_t_249), MK_INT(10LL))) {
            heff_drop(v_b_240);
            return v_i_241;
          } else {
            V t_0 = v_b_240;
            V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
            v_b_240 = t_0;
            v_i_241 = t_1;
            goto top;
          }
        } else {
          V t_0 = v_b_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_b_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_b_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_b_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    } else {
      V t_0 = v_b_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_b_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_std_2ehttp_2eserver_2eheadEnd_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eheadEnd(a[0], a[1]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderAt_24cpr_str0, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderAt_24cpr_str1, 1, "\011");

HeffT2 g_std_2ehttp_2eserver_2eheaderAt_24cpr(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_i_242 = heff_field(v_x2_241, 0);
    V v_name_243 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_i_242, 2);
    if (heff_intEq_c_lent(v_i_242, MK_INT(0LL), 2)) {
      heff_drop(v_name_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaderAt_24cpr_str0), v_name_243, MK_INT(0LL), 5))) {
        heff_drop(v_name_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaderAt_24cpr_str1), v_name_243, MK_INT(0LL), 5))) {
          heff_drop(v_name_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          V v_s_247 = heff_strSlice(heff_dup(v_l_240), heff_intAdd(heff_dup(v_i_242), MK_INT(1LL)), heff_strLength_lent(v_l_240, 0));
          V v_t_248 = (g_prelude_2eskipSpaces(v_s_247, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_247, 0)) - ((int64_t)1ULL));
          V v_t_2410 = (g_prelude_2eskipSpaces(v_s_247, heff_box_word(v_t_249), MK_INT(-1LL)));
          V v_t_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
          V v_f_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_name_243, v_t_2411});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_std_2ehttp_2eserver_2eheaderLines_24cpr_str0, 1, ":");

HeffT2 g_std_2ehttp_2eserver_2eheaderLines_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_j_243 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eheaderLines_24cpr_str0), v_l_241, MK_INT(0LL), 5);
    V v_t_245;
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      v_t_245 = NTAG(TAG_Nothing);
    } else {
      v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_j_243});
    }
    HeffT2 v_t_246 = ({ V a_0 = v_l_241; V a_1 = v_t_245; HeffT2 r_ = (g_std_2ehttp_2eserver_2eheaderAt_24cpr(a_0, a_1)); heff_drop(v_l_241); heff_drop(v_t_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      HeffT2 v_t_249 = (g_std_2ehttp_2eserver_2eheaderLines_24cpr(v_rest_242));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_248;
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_xs_2415 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2413, v_xs_2415})}});
          } else {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_field_2411);
            heff_drop(v_x_2413);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_field_248);
          heff_drop(v_field_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2ehttp_2eserver_2eheaderLines_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eheaderLines_entry, 1, 0};

V g_std_2ehttp_2eserver_2eheaderLines(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_std_2ehttp_2eserver_2eheaderLines_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2ehttp_2eserver_2eheaderLines_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2eheaderLines(a[0]);
}

HeffT2 g_std_2ehttp_2eserver_2erequestOf_24cpr(V v_peer_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_peer_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_244)) {
    case TAG_Nil: {
      heff_drop(v_peer_240);
      heff_drop(v_m_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_t_245 = heff_field(v_x22_244, 0);
      V v_x222_246 = heff_field(v_x22_244, 1);
      heff_take_n(v_x22_244, 3ULL, 2);
      switch (heff_tag_of(v_x222_246)) {
      case TAG_Nil: {
        heff_drop(v_peer_240);
        heff_drop(v_m_243);
        heff_drop(v_t_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_v_247 = heff_field(v_x222_246, 0);
        V v_x2222_248 = heff_field(v_x222_246, 1);
        heff_take_n(v_x222_246, 3ULL, 2);
        switch (heff_tag_of(v_x2222_248)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x3_242)) {
          case TAG_Nothing: {
            heff_drop(v_peer_240);
            heff_drop(v_m_243);
            heff_drop(v_t_245);
            heff_drop(v_v_247);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_hs_249 = heff_field(v_x3_242, 0);
            if ((heff_unbox_word(heff_strLength_lent(v_m_243, 0)) == ((int64_t)0ULL))) {
              heff_drop(v_peer_240);
              heff_drop(v_m_243);
              heff_drop(v_t_245);
              heff_drop(v_v_247);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            } else {
              if ((heff_unbox_word(heff_strLength_lent(v_t_245, 0)) == ((int64_t)0ULL))) {
                heff_drop(v_peer_240);
                heff_drop(v_m_243);
                heff_drop(v_t_245);
                heff_drop(v_v_247);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              } else {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(6, shape_method__target__version__headers__body__peer, (V[]){v_m_243, v_t_245, v_v_247, heff_dup(v_hs_249), heff_dup(g_bytes_2eempty_get()), v_peer_240})}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x2222_248, 0ULL, 2);
          heff_drop(v_peer_240);
          heff_drop(v_m_243);
          heff_drop(v_t_245);
          heff_drop(v_v_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2222_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x222_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_std_2ehttp_2eserver_2eparseHead_24cpr_str0, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eparseHead_24cpr_str1, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eparseHead_24cpr_str2, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eparseHead_24cpr_str3, 1, " ");

HeffT2 g_std_2ehttp_2eserver_2eparseHead_24cpr(V v_peer_240, V v_text_241) {
top: ;
  V v_x2_242 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eparseHead_24cpr_str0); V a_1 = v_text_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eparseHead_24cpr_str1), v_text_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_peer_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x2_242, 0);
    V v_rest_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_t_245 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eparseHead_24cpr_str2); V a_1 = v_l_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2eparseHead_24cpr_str3), v_l_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_l_243); r_; });
    V v_t_246 = (g_std_2ehttp_2eserver_2eheaderLines(v_rest_244));
    return ({ V a_0 = v_peer_240; V a_1 = v_t_245; V a_2 = v_t_246; HeffT2 r_ = (g_std_2ehttp_2eserver_2erequestOf_24cpr(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}
Clo g_std_2ehttp_2eserver_2elengthOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2elengthOf_entry, 1, 0};

V g_std_2ehttp_2eserver_2elengthOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Length, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_Just: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_242 = ({ V a_0 = v_s_241; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_241); r_; });
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_n_246 = v_field_244;
        if (heff_intLt_c_lent(v_n_246, MK_INT(0LL), 2)) {
          heff_drop(v_n_246);
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Refuse, 1, (V[]){MK_INT(400LL)});
        } else {
          if (heff_intLt_c_lent(MK_INT(67108864LL), v_n_246, 1)) {
            heff_drop(v_n_246);
            return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Refuse, 1, (V[]){MK_INT(413LL)});
          } else {
            return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Length, 1, (V[]){v_n_246});
          }
        }
      } else {
        heff_drop(v_field_244);
        return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Refuse, 1, (V[]){MK_INT(400LL)});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ehttp_2eserver_2elengthOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2elengthOf(a[0]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2ebodyOf_str0, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2ebodyOf_str1, 17, "transfer-encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2ebodyOf_str2, 14, "content-length");
HEFF_LIT(g_std_2ehttp_2eserver_2ebodyOf_str3, 8, "HTTP/1.0");
HEFF_LIT(g_std_2ehttp_2eserver_2ebodyOf_str4, 17, "transfer-encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2ebodyOf_str5, 14, "content-length");
HEFF_LIT(g_std_2ehttp_2eserver_2ebodyOf_str6, 5, "HTTP/");
Clo g_std_2ehttp_2eserver_2ebodyOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ebodyOf_entry, 1, 0};

V g_std_2ehttp_2eserver_2ebodyOf(V v_r_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 2)), ((V)&g_std_2ehttp_2eserver_2ebodyOf_str0))) {
    HeffT2 v_t_242 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2ebodyOf_str1); V a_1 = heff_dup(heff_rfield(v_r_240, 3)); HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        heff_drop_rec(v_r_240, 6);
        V v_x_246 = v_field_244;
        heff_drop(v_x_246);
        return heff_tag_n(TAG_Refuse, 1, (V[]){MK_INT(501LL)});
      } else {
        heff_drop(v_field_244);
        V v_t_247 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2ebodyOf_str2); V a_1 = heff_get_n(v_r_240, 3, 6); V r_ = (g_std_2ehttp_2eheaderIn(b_0, a_1)); heff_drop(b_0); r_; });
        HEFF_LAST return g_std_2ehttp_2eserver_2elengthOf(v_t_247);
      }
    }
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 2)), ((V)&g_std_2ehttp_2eserver_2ebodyOf_str3))) {
      HeffT2 v_t_249 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2ebodyOf_str4); V a_1 = heff_dup(heff_rfield(v_r_240, 3)); HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop_rec(v_r_240, 6);
          V v_x_2413 = v_field_2411;
          heff_drop(v_x_2413);
          return heff_tag_n(TAG_Refuse, 1, (V[]){MK_INT(501LL)});
        } else {
          heff_drop(v_field_2411);
          V v_t_2414 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2ebodyOf_str5); V a_1 = heff_get_n(v_r_240, 3, 6); V r_ = (g_std_2ehttp_2eheaderIn(b_0, a_1)); heff_drop(b_0); r_; });
          HEFF_LAST return g_std_2ehttp_2eserver_2elengthOf(v_t_2414);
        }
      }
    } else {
      V v_t_2415 = heff_strSlice(heff_get_n(v_r_240, 2, 6), MK_INT(0LL), MK_INT(5LL));
      V v_t_2417;
      if (heff_strEq_c(v_t_2415, ((V)&g_std_2ehttp_2eserver_2ebodyOf_str6))) {
        v_t_2417 = MK_INT(505LL);
      } else {
        v_t_2417 = MK_INT(400LL);
      }
      return heff_tag_n(TAG_Refuse, 1, (V[]){v_t_2417});
    }
  }
}
V g_std_2ehttp_2eserver_2ebodyOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2ebodyOf(a[0]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str0, 8, "Continue");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str1, 19, "Switching Protocols");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str2, 2, "OK");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str3, 7, "Created");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str4, 8, "Accepted");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str5, 10, "No Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str6, 15, "Partial Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str7, 17, "Moved Permanently");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str8, 5, "Found");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str9, 9, "See Other");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str10, 12, "Not Modified");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str11, 18, "Temporary Redirect");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str12, 18, "Permanent Redirect");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str13, 11, "Bad Request");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str14, 12, "Unauthorized");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str15, 9, "Forbidden");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str16, 9, "Not Found");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str17, 18, "Method Not Allowed");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str18, 15, "Request Timeout");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str19, 8, "Conflict");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str20, 4, "Gone");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str21, 15, "Length Required");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str22, 17, "Content Too Large");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str23, 12, "URI Too Long");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str24, 22, "Unsupported Media Type");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str25, 21, "Unprocessable Content");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str26, 17, "Too Many Requests");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str27, 31, "Request Header Fields Too Large");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str28, 21, "Internal Server Error");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str29, 15, "Not Implemented");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str30, 11, "Bad Gateway");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str31, 19, "Service Unavailable");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str32, 15, "Gateway Timeout");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str33, 26, "HTTP Version Not Supported");
HEFF_LIT(g_std_2ehttp_2eserver_2ereason_str34, 0, "");
Clo g_std_2ehttp_2eserver_2ereason_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereason_entry, 1, 0};

V g_std_2ehttp_2eserver_2ereason(V v_x1_240) {
top: ;
  if (heff_intEq_c_lent(v_x1_240, MK_INT(100LL), 2)) {
    heff_drop(v_x1_240);
    return ((V)&g_std_2ehttp_2eserver_2ereason_str0);
  } else {
    if (heff_intEq_c_lent(v_x1_240, MK_INT(101LL), 2)) {
      heff_drop(v_x1_240);
      return ((V)&g_std_2ehttp_2eserver_2ereason_str1);
    } else {
      if (heff_intEq_c_lent(v_x1_240, MK_INT(200LL), 2)) {
        heff_drop(v_x1_240);
        return ((V)&g_std_2ehttp_2eserver_2ereason_str2);
      } else {
        if (heff_intEq_c_lent(v_x1_240, MK_INT(201LL), 2)) {
          heff_drop(v_x1_240);
          return ((V)&g_std_2ehttp_2eserver_2ereason_str3);
        } else {
          if (heff_intEq_c_lent(v_x1_240, MK_INT(202LL), 2)) {
            heff_drop(v_x1_240);
            return ((V)&g_std_2ehttp_2eserver_2ereason_str4);
          } else {
            if (heff_intEq_c_lent(v_x1_240, MK_INT(204LL), 2)) {
              heff_drop(v_x1_240);
              return ((V)&g_std_2ehttp_2eserver_2ereason_str5);
            } else {
              if (heff_intEq_c_lent(v_x1_240, MK_INT(206LL), 2)) {
                heff_drop(v_x1_240);
                return ((V)&g_std_2ehttp_2eserver_2ereason_str6);
              } else {
                if (heff_intEq_c_lent(v_x1_240, MK_INT(301LL), 2)) {
                  heff_drop(v_x1_240);
                  return ((V)&g_std_2ehttp_2eserver_2ereason_str7);
                } else {
                  if (heff_intEq_c_lent(v_x1_240, MK_INT(302LL), 2)) {
                    heff_drop(v_x1_240);
                    return ((V)&g_std_2ehttp_2eserver_2ereason_str8);
                  } else {
                    if (heff_intEq_c_lent(v_x1_240, MK_INT(303LL), 2)) {
                      heff_drop(v_x1_240);
                      return ((V)&g_std_2ehttp_2eserver_2ereason_str9);
                    } else {
                      if (heff_intEq_c_lent(v_x1_240, MK_INT(304LL), 2)) {
                        heff_drop(v_x1_240);
                        return ((V)&g_std_2ehttp_2eserver_2ereason_str10);
                      } else {
                        if (heff_intEq_c_lent(v_x1_240, MK_INT(307LL), 2)) {
                          heff_drop(v_x1_240);
                          return ((V)&g_std_2ehttp_2eserver_2ereason_str11);
                        } else {
                          if (heff_intEq_c_lent(v_x1_240, MK_INT(308LL), 2)) {
                            heff_drop(v_x1_240);
                            return ((V)&g_std_2ehttp_2eserver_2ereason_str12);
                          } else {
                            if (heff_intEq_c_lent(v_x1_240, MK_INT(400LL), 2)) {
                              heff_drop(v_x1_240);
                              return ((V)&g_std_2ehttp_2eserver_2ereason_str13);
                            } else {
                              if (heff_intEq_c_lent(v_x1_240, MK_INT(401LL), 2)) {
                                heff_drop(v_x1_240);
                                return ((V)&g_std_2ehttp_2eserver_2ereason_str14);
                              } else {
                                if (heff_intEq_c_lent(v_x1_240, MK_INT(403LL), 2)) {
                                  heff_drop(v_x1_240);
                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str15);
                                } else {
                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(404LL), 2)) {
                                    heff_drop(v_x1_240);
                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str16);
                                  } else {
                                    if (heff_intEq_c_lent(v_x1_240, MK_INT(405LL), 2)) {
                                      heff_drop(v_x1_240);
                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str17);
                                    } else {
                                      if (heff_intEq_c_lent(v_x1_240, MK_INT(408LL), 2)) {
                                        heff_drop(v_x1_240);
                                        return ((V)&g_std_2ehttp_2eserver_2ereason_str18);
                                      } else {
                                        if (heff_intEq_c_lent(v_x1_240, MK_INT(409LL), 2)) {
                                          heff_drop(v_x1_240);
                                          return ((V)&g_std_2ehttp_2eserver_2ereason_str19);
                                        } else {
                                          if (heff_intEq_c_lent(v_x1_240, MK_INT(410LL), 2)) {
                                            heff_drop(v_x1_240);
                                            return ((V)&g_std_2ehttp_2eserver_2ereason_str20);
                                          } else {
                                            if (heff_intEq_c_lent(v_x1_240, MK_INT(411LL), 2)) {
                                              heff_drop(v_x1_240);
                                              return ((V)&g_std_2ehttp_2eserver_2ereason_str21);
                                            } else {
                                              if (heff_intEq_c_lent(v_x1_240, MK_INT(413LL), 2)) {
                                                heff_drop(v_x1_240);
                                                return ((V)&g_std_2ehttp_2eserver_2ereason_str22);
                                              } else {
                                                if (heff_intEq_c_lent(v_x1_240, MK_INT(414LL), 2)) {
                                                  heff_drop(v_x1_240);
                                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str23);
                                                } else {
                                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(415LL), 2)) {
                                                    heff_drop(v_x1_240);
                                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str24);
                                                  } else {
                                                    if (heff_intEq_c_lent(v_x1_240, MK_INT(422LL), 2)) {
                                                      heff_drop(v_x1_240);
                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str25);
                                                    } else {
                                                      if (heff_intEq_c_lent(v_x1_240, MK_INT(429LL), 2)) {
                                                        heff_drop(v_x1_240);
                                                        return ((V)&g_std_2ehttp_2eserver_2ereason_str26);
                                                      } else {
                                                        if (heff_intEq_c_lent(v_x1_240, MK_INT(431LL), 2)) {
                                                          heff_drop(v_x1_240);
                                                          return ((V)&g_std_2ehttp_2eserver_2ereason_str27);
                                                        } else {
                                                          if (heff_intEq_c_lent(v_x1_240, MK_INT(500LL), 2)) {
                                                            heff_drop(v_x1_240);
                                                            return ((V)&g_std_2ehttp_2eserver_2ereason_str28);
                                                          } else {
                                                            if (heff_intEq_c_lent(v_x1_240, MK_INT(501LL), 2)) {
                                                              heff_drop(v_x1_240);
                                                              return ((V)&g_std_2ehttp_2eserver_2ereason_str29);
                                                            } else {
                                                              if (heff_intEq_c_lent(v_x1_240, MK_INT(502LL), 2)) {
                                                                heff_drop(v_x1_240);
                                                                return ((V)&g_std_2ehttp_2eserver_2ereason_str30);
                                                              } else {
                                                                if (heff_intEq_c_lent(v_x1_240, MK_INT(503LL), 2)) {
                                                                  heff_drop(v_x1_240);
                                                                  return ((V)&g_std_2ehttp_2eserver_2ereason_str31);
                                                                } else {
                                                                  if (heff_intEq_c_lent(v_x1_240, MK_INT(504LL), 2)) {
                                                                    heff_drop(v_x1_240);
                                                                    return ((V)&g_std_2ehttp_2eserver_2ereason_str32);
                                                                  } else {
                                                                    if (heff_intEq_c(v_x1_240, MK_INT(505LL))) {
                                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str33);
                                                                    } else {
                                                                      return ((V)&g_std_2ehttp_2eserver_2ereason_str34);
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2ehttp_2eserver_2ereason_entry(V self, V *a) {
  (void)self;
  return g_std_2ehttp_2eserver_2ereason(a[0]);
}
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str0, 14, "Content-Length");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str1, 17, "Transfer-Encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str2, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str3, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str4, 17, "Transfer-Encoding");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str5, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2eownHeader_str6, 10, "Connection");
Clo g_std_2ehttp_2eserver_2eownHeader_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eownHeader_entry, 1, 0};

V g_std_2ehttp_2eserver_2eownHeader(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_n_241 = heff_field(v_x1_240, 0);
    if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)14ULL))) {
      V v_t_244 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str0); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_244);
        if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)17ULL))) {
          V v_t_246 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str1); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
            heff_drop(v_t_246);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_246);
            if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
              return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str2); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
            } else {
              return NTAG(TAG_False);
            }
          }
        } else {
          if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
            return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str3); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          } else {
            return NTAG(TAG_False);
          }
        }
      }
    } else {
      if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)17ULL))) {
        V v_t_2410 = ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str4); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2410);
          if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
            return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str5); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
          } else {
            return NTAG(TAG_False);
          }
        }
      } else {
        if ((heff_unbox_word(heff_strLength_lent(v_n_241, 0)) == ((int64_t)10ULL))) {
          return ({ V a_0 = v_n_241; V b_1 = ((V)&g_std_2ehttp_2eserver_2eownHeader_str6); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        } else {
          return NTAG(TAG_False);
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ehttp_2eserver_2eownHeader_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ehttp_2eserver_2eownHeader(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str0, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str1, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str2, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str3, 16, "Content-Length: ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str4, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str5, 12, "Connection: ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str6, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str7, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str8, 2, "\015\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str9, 1, " ");
HEFF_LIT(g_std_2ehttp_2eserver_2eresponseBytes_str10, 9, "HTTP/1.1 ");
Clo g_std_2ehttp_2eserver_2eresponseBytes_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eresponseBytes_entry, 3, 0};

V g_std_2ehttp_2eserver_2eresponseBytes(V v_connection_240, V v_withBody_241, V v_res_242) {
top: ;
  V v_s_243 = heff_dup(heff_rfield(v_res_242, 0));
  V v_none_246 = heff_bool((heff_intLt_c_lent(v_s_243, MK_INT(200LL), 2) || (heff_intEq_c_lent(v_s_243, MK_INT(204LL), 2) || heff_intEq_c_lent(v_s_243, MK_INT(304LL), 2))));
  heff_drop(v_s_243);
  V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_res_242, 0)));
  V v_t_248 = (g_std_2ehttp_2eserver_2ereason(heff_take_field(v_res_242, 0)));
  V v_t_249 = (g_list_2efilter_24s93534634x1143141184(heff_take_field(v_res_242, 1)));
  V v_t_2410 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str0); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1511444646x1476348587(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2413;
  if ((heff_dup(v_none_246) == NTAG(TAG_True))) {
    v_t_2413 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str1);
  } else {
    V v_t_2411 = heff_bytesLength(heff_dup(heff_rfield(v_res_242, 2)));
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_2411), ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str2));
    v_t_2413 = heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str3), v_t_2412);
  }
  V v_t_2415;
  if ((heff_unbox_word(heff_strLength_lent(v_connection_240, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_connection_240);
    v_t_2415 = ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str4);
  } else {
    v_t_2415 = heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str5), heff_strAppend(v_connection_240, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str6)));
  }
  V v_t_2416 = heff_strAppend(v_t_2413, heff_strAppend(v_t_2415, ((V)&g_std_2ehttp_2eserver_2eresponseBytes_str7)));
  V v_t_2417 = heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str8), heff_strAppend(v_t_2410, v_t_2416));
  V v_t_2418 = heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str9), heff_strAppend(v_t_248, v_t_2417));
  V v_head_2419 = heff_strAppend(((V)&g_std_2ehttp_2eserver_2eresponseBytes_str10), heff_strAppend(v_t_247, v_t_2418));
  if ((heff_dup(v_withBody_241) == NTAG(TAG_True))) {
    if ((heff_dup(v_none_246) == NTAG(TAG_True))) {
      heff_drop_rec(v_res_242, 3);
      heff_drop(v_none_246);
      return heff_bytesFromString(v_head_2419);
    } else {
      heff_drop(v_none_246);
      return heff_bytesAppend(heff_bytesFromString(v_head_2419), heff_get_n(v_res_242, 2, 3));
    }
  } else {
    heff_drop_rec(v_res_242, 3);
    heff_drop(v_none_246);
    return heff_bytesFromString(v_head_2419);
  }
}
V g_std_2ehttp_2eserver_2eresponseBytes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2eresponseBytes(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str0, 10, "Connection");
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str1, 1, ",");
HEFF_LIT(g_std_2ehttp_2eserver_2econnectionSays_str2, 1, ",");
V g_std_2ehttp_2eserver_2econnectionSays_lam0(V self, V *args);
Clo g_std_2ehttp_2eserver_2econnectionSays_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2econnectionSays_entry, 2, 0};

V g_std_2ehttp_2eserver_2econnectionSays(V v_token_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if ((heff_unbox_word(heff_strLength_lent(v_n_244, 0)) == ((int64_t)10ULL))) {
        V v_t_247 = ({ V a_0 = v_n_244; V b_1 = ((V)&g_std_2ehttp_2eserver_2econnectionSays_str0); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
          heff_drop(v_t_247);
          V v_t_248 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2econnectionSays_str1); V a_1 = v_v_245; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ehttp_2eserver_2econnectionSays_str2), v_v_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2415 = ({ V a_0 = heff_clo_n(g_std_2ehttp_2eserver_2econnectionSays_lam0, 1, 1, (V[]){heff_dup(v_token_240)}); V a_1 = v_t_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_248); r_; });
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_t_2415);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2415);
            V t_0 = v_token_240;
            V t_1 = v_rest_243;
            v_token_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        } else {
          heff_drop(v_t_247);
          V t_0 = v_token_240;
          V t_1 = v_rest_243;
          v_token_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_token_240;
        V t_1 = v_rest_243;
        v_token_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ehttp_2eserver_2econnectionSays_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ehttp_2eserver_2econnectionSays(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2econnectionSays_lam0(V self, V *args) {
  V v_t_249 = args[0];
  V v_token_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_prelude_2eskipSpaces(v_t_249, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_t_249, 0)) - ((int64_t)1ULL));
  V v_t_2412 = (g_prelude_2eskipSpaces(v_t_249, heff_box_word(v_t_2411), MK_INT(-1LL)));
  V v_a_2413 = heff_strSlice(v_t_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
  if ((heff_unbox_word(heff_strLength_lent(v_a_2413, 0)) == heff_unbox_word(heff_strLength_lent(v_token_240, 0)))) {
    return ({ V a_0 = v_a_2413; V a_1 = v_token_240; V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, a_1, a_2)); heff_drop(v_a_2413); heff_drop(v_token_240); r_; });
  } else {
    heff_drop(v_token_240);
    heff_drop(v_a_2413);
    return NTAG(TAG_False);
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam1(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam1, 2, 0};
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam2, 1, 0};
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam3(V self, V *args);
Clo g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_entry, 4, 0};

V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735(V v_nt_240, V v_c_241, V v_buf_242, V v_from_243) {
top: ;
  V v_i_244 = (g_std_2ehttp_2eserver_2eheadEnd(heff_dup(v_buf_242), v_from_243));
  if (heff_intLe_c_lent(MK_INT(0LL), v_i_244, 1)) {
    heff_drop(v_nt_240);
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam0, 2, 2, (V[]){v_buf_242, v_i_244});
  } else {
    heff_drop(v_i_244);
    if ((((int64_t)65536ULL) < heff_unbox_word(heff_bytesLength(heff_dup(v_buf_242))))) {
      heff_drop(v_nt_240);
      heff_drop(v_buf_242);
      return ((V)&g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam1_clo);
    } else {
      V v_t_2412;
      switch (heff_tag_of(v_c_241)) {
      case TAG_MkWith: {
        V v_x_2411 = heff_field(v_c_241, 0);
        v_t_2412 = heff_dup(v_x_2411);
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      V v_t_2414 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Read, 3, (V[]){v_t_2412, MK_INT(65536LL), ((V)&g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam2_clo)})}));
      return heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam3, 2, 4, (V[]){v_t_2414, v_buf_242, v_nt_240, heff_dup(v_c_241)});
    }
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_buf_242 = heff_env(self)[0];
  V v_i_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_HeadAt, 2, (V[]){v_buf_242, v_i_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_HeadTooLong);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam2(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_buf_242 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  V v_c_241 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    heff_take_n(v_x_2417, 0ULL, 1);
    heff_drop(v_buf_242);
    heff_drop(v_nt_240);
    heff_drop(v_c_241);
    heff_drop(v_hd_2415);
    V f_ = v_k_2416;
    args[0] = NTAG(TAG_HeadEnded);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2419 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2419))) == ((int64_t)0ULL))) {
      heff_drop(v_buf_242);
      heff_drop(v_nt_240);
      heff_drop(v_c_241);
      heff_drop(v_hd_2415);
      heff_drop(v_b_2419);
      V f_ = v_k_2416;
      args[0] = NTAG(TAG_HeadEnded);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      int64_t v_t_2422;
      if ((((int64_t)3ULL) < heff_unbox_word(heff_bytesLength(heff_dup(v_buf_242))))) {
        v_t_2422 = (heff_unbox_word(heff_bytesLength(heff_dup(v_buf_242))) - ((int64_t)3ULL));
      } else {
        v_t_2422 = ((int64_t)0ULL);
      }
      V v_t_2423 = ({ V a_0 = v_nt_240; V a_1 = v_c_241; V a_2 = heff_bytesAppend(v_buf_242, v_b_2419); V a_3 = heff_box_word(v_t_2422); V r_ = (g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735(a_0, a_1, a_2, a_3)); heff_drop(v_c_241); r_; });
      V f_ = v_t_2423;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_buf_242 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  V v_c_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_co_2eop_24s162716155x1210144019(v_t_2414, heff_dup(v_hd_2415), heff_clo_n(g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735_lam4, 1, 5, (V[]){v_k_2416, v_buf_242, v_nt_240, v_c_241, v_hd_2415})));
}
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam1(V self, V *args); static Clo g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam1, 1, 0};
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam2(V self, V *args);
Clo g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_entry, 5, 0};

V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608(V v_nt_240, V v_c_241, V v_n_242, V v_got_243, V v_parts_244) {
top: ;
  if (heff_intLe_c_lent(v_n_242, v_got_243, 0)) {
    heff_drop(v_nt_240);
    heff_drop(v_n_242);
    heff_drop(v_got_243);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_parts_244));
    V v_x_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_bytesConcat(v_t_246)});
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam0, 2, 1, (V[]){v_x_247});
  } else {
    V v_t_2411;
    switch (heff_tag_of(v_c_241)) {
    case TAG_MkWith: {
      V v_x_2410 = heff_field(v_c_241, 0);
      v_t_2411 = heff_dup(v_x_2410);
      break;
    }
    default: heff_nomatch(v_c_241);
    }
    V v_t_2413 = heff_tag_n(TAG_Read, 3, (V[]){v_t_2411, heff_intSub(heff_dup(v_n_242), heff_dup(v_got_243)), ((V)&g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam1_clo)});
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){v_t_2413}));
    return heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam2, 2, 6, (V[]){v_t_2414, v_got_243, v_nt_240, heff_dup(v_c_241), v_n_242, v_parts_244});
  }
}
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam1(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_got_243 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  V v_c_241 = heff_env(self)[3];
  V v_n_242 = heff_env(self)[4];
  V v_parts_244 = heff_env(self)[5];
  V v_hd_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    heff_take_n(v_x_2417, 0ULL, 1);
    heff_drop(v_got_243);
    heff_drop(v_nt_240);
    heff_drop(v_c_241);
    heff_drop(v_n_242);
    heff_drop(v_parts_244);
    heff_drop(v_hd_2415);
    V f_ = v_k_2416;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2419 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2419))) == ((int64_t)0ULL))) {
      heff_drop(v_got_243);
      heff_drop(v_nt_240);
      heff_drop(v_c_241);
      heff_drop(v_n_242);
      heff_drop(v_parts_244);
      heff_drop(v_hd_2415);
      heff_drop(v_b_2419);
      V f_ = v_k_2416;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_t_2421 = heff_intAdd(v_got_243, heff_bytesLength(heff_dup(v_b_2419)));
      V v_t_2422 = ({ V a_0 = v_nt_240; V a_1 = v_c_241; V a_2 = v_n_242; V a_3 = v_t_2421; V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2419, v_parts_244}); V r_ = (g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_c_241); r_; });
      V f_ = v_t_2422;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_got_243 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  V v_c_241 = heff_env(self)[3];
  V v_n_242 = heff_env(self)[4];
  V v_parts_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s162716155x1210144019(v_t_2414, heff_dup(v_hd_2415), heff_clo_n(g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608_lam3, 1, 7, (V[]){v_k_2416, v_got_243, v_nt_240, v_c_241, v_n_242, v_parts_244, v_hd_2415})));
}
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str0, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str1, 6, "expect");
HEFF_LIT(g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str2, 12, "100-continue");
HEFF_BYTES(g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str3, 25, "HTTP/1.1 100 Continue\015\012\015\012");
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam0, 1, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam1(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam1, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam2, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam3(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam3, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam4(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam4, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam5(V self, V *args); static Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam5, 2, 0};
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam7(V self, V *args);
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam6(V self, V *args);
Clo g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_entry, 8, 0};

V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756(V v_nt_240, V v_c_241, V v_buf_242, V v_i_243, V v_r_244, V v_x5_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Length: {
    V v_n_248 = heff_field(v_x5_245, 0);
    heff_take_n(v_x5_245, 1ULL, 1);
    V v_rest_249 = heff_bytesSlice(heff_dup(v_buf_242), heff_intAdd(v_i_243, MK_INT(4LL)), heff_bytesLength(v_buf_242));
    V v_c_2438;
    if (heff_intLt_c(heff_bytesLength(heff_dup(v_rest_249)), heff_dup(v_n_248))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_244, 2)), ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str0))) {
        HeffT2 v_t_2412 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str1); V a_1 = heff_dup(heff_rfield(v_r_244, 3)); HeffT2 r_ = (g_std_2ehttp_2eheaderIn_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            if ((heff_unbox_word(heff_strLength_lent(v_x_2416, 0)) == ((int64_t)12ULL))) {
              V v_t_2418 = ({ V a_0 = v_x_2416; V b_1 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str2); V a_2 = MK_INT(0LL); V r_ = (g_std_2ehttp_2esameFrom(a_0, b_1, a_2)); heff_drop(v_x_2416); heff_drop(b_1); r_; });
              if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
                heff_drop(v_t_2418);
                V v_t_2420;
                switch (heff_tag_of(v_c_241)) {
                case TAG_MkWith: {
                  V v_x_2419 = heff_field(v_c_241, 0);
                  v_t_2420 = heff_dup(v_x_2419);
                  break;
                }
                default: heff_nomatch(v_c_241);
                }
                V v_t_2422 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Write, 3, (V[]){v_t_2420, ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_str3), ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam0_clo)})}));
                v_c_2438 = heff_tr(heff_call(((V)&g_co_2eop_24s459815859x1387532636_clo), 1, (V[]){v_t_2422}));
              } else {
                heff_drop(v_t_2418);
                v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam1_clo);
              }
            } else {
              heff_drop(v_x_2416);
              v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam2_clo);
            }
          } else {
            heff_drop(v_field_2414);
            v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam3_clo);
          }
        }
      } else {
        v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam4_clo);
      }
    } else {
      v_c_2438 = ((V)&g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam5_clo);
    }
    return heff_tail(v_c_2438, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam6, 1, 7, (V[]){v_rest_249, v_nt_240, heff_dup(v_c_241), v_n_248, v_z_246, v_r_244, v_z_247})});
  }
  case TAG_Refuse: {
    V v_status_2447 = heff_field(v_x5_245, 0);
    heff_take_n(v_x5_245, 1ULL, 1);
    heff_drop(v_nt_240);
    heff_drop(v_buf_242);
    heff_drop(v_i_243);
    heff_drop_rec(v_r_244, 6);
    heff_drop(v_z_246);
    return heff_tail(v_z_247, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){v_status_2447})});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam0(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V v_t_2425 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2424;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam2(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V v_t_2428 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2427;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V v_t_2431 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2430;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  heff_drop(v_hd_2432);
  V v_t_2434 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2433;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam5(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V v_t_2437 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_2436;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_n_248 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2446;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_244, 6);
    heff_drop(v_n_248);
    v_t_2446 = NTAG(TAG_Ended);
    break;
  }
  case TAG_Just: {
    V v_b_2443 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    V v_t_2444 = ({ V rv_4 = heff_bytesSlice(heff_dup(v_b_2443), MK_INT(0LL), heff_dup(v_n_248)); V rr_ = heff_rec_reuse_nf(v_r_244, 47ULL, 6, shape_method__target__version__headers__body__peer, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_2445 = heff_bytesSlice(heff_dup(v_b_2443), v_n_248, heff_bytesLength(v_b_2443));
    v_t_2446 = heff_tag_n(TAG_Asked, 2, (V[]){v_t_2444, v_t_2445});
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V f_ = v_z_247;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_rest_249 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_n_248 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_r_244 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_rest_249), NTAG(TAG_Nil)});
  V v_c_2441 = ({ V a_0 = v_nt_240; V a_1 = v_c_241; V a_2 = heff_dup(v_n_248); V a_3 = heff_bytesLength(v_rest_249); V a_4 = v_t_2440; V r_ = (g_std_2ehttp_2eserver_2ereadBody_24s2133384547x979088608(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_c_241); r_; });
  V f_ = v_c_2441;
  heff_room[0] = v_z_246;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756_lam7, 1, 3, (V[]){v_r_244, v_n_248, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425_entry, 6, 0};

V g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425(V v_nt_240, V v_c_241, V v_peer_242, V v_x3_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_HeadAt: {
    V v_buf_246 = heff_field(v_x3_243, 0);
    V v_i_247 = heff_field(v_x3_243, 1);
    V v_t_248 = heff_bytesToString(heff_bytesSlice(heff_dup(v_buf_246), MK_INT(0LL), heff_dup(v_i_247)));
    HeffT2 v_t_249 = ({ V a_0 = v_peer_242; V a_1 = v_t_248; HeffT2 r_ = (g_std_2ehttp_2eserver_2eparseHead_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_r_2413 = v_field_2411;
        V v_t_2414 = (g_std_2ehttp_2eserver_2ebodyOf(heff_dup(v_r_2413)));
        return (g_std_2ehttp_2eserver_2ewithBody_24s1375180685x751830756(v_nt_240, v_c_241, heff_dup(v_buf_246), heff_dup(v_i_247), v_r_2413, v_t_2414, v_z_244, v_z_245));
      } else {
        heff_drop(v_nt_240);
        heff_drop(v_z_244);
        heff_drop(v_field_2411);
        return heff_tail(v_z_245, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){MK_INT(400LL)})});
      }
    }
  }
  case TAG_HeadTooLong: {
    heff_drop(v_nt_240);
    heff_drop(v_peer_242);
    heff_drop(v_z_244);
    return heff_tail(v_z_245, 1, (V[]){heff_tag_n(TAG_Refused, 1, (V[]){MK_INT(431LL)})});
  }
  case TAG_HeadEnded: {
    heff_drop(v_nt_240);
    heff_drop(v_peer_242);
    heff_drop(v_z_244);
    return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_Ended)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425(a[0], a1, a[2], a3, a[4], a[5]); heff_drop(a1); heff_drop(a3); return r;
}
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam0, 1, 0};
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_entry, 5, 0};

V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361(V v_nt_240, V v_c_241, V v_got_242, V v_z_243, V v_z_244) {
top: ;
  if (heff_intLe_c_lent(MK_INT(1048576LL), v_got_242, 1)) {
    heff_drop(v_nt_240);
    heff_drop(v_got_242);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_MkUnit)});
  } else {
    V v_t_247;
    switch (heff_tag_of(v_c_241)) {
    case TAG_MkWith: {
      V v_x_246 = heff_field(v_c_241, 0);
      v_t_247 = heff_dup(v_x_246);
      break;
    }
    default: heff_nomatch(v_c_241);
    }
    V v_t_249 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Read, 3, (V[]){v_t_247, MK_INT(65536LL), ((V)&g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam0_clo)})}));
    return (g_co_2eop_24s162716155x1210144019(v_t_249, heff_dup(v_z_243), heff_clo_n(g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam1, 1, 5, (V[]){v_z_244, v_got_242, v_nt_240, heff_dup(v_c_241), v_z_243})));
  }
}
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_got_242 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  V v_c_241 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    heff_take_n(v_x_2410, 0ULL, 1);
    heff_drop(v_got_242);
    heff_drop(v_nt_240);
    heff_drop(v_c_241);
    heff_drop(v_z_243);
    V f_ = v_z_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_b_2412 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    if ((heff_unbox_word(heff_bytesLength(heff_dup(v_b_2412))) == ((int64_t)0ULL))) {
      heff_drop(v_got_242);
      heff_drop(v_nt_240);
      heff_drop(v_c_241);
      heff_drop(v_z_243);
      heff_drop(v_b_2412);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_t_2414 = heff_intAdd(v_got_242, heff_bytesLength(v_b_2412));
      return ({ V a_0 = v_nt_240; V a_1 = v_c_241; V a_2 = v_t_2414; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_c_241); r_; });
    }
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str0, 8, "HTTP/1.1");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str1, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str2, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str3, 10, "keep-alive");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str4, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str5, 5, "close");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str6, 8, "HTTP/1.0");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str7, 10, "keep-alive");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str8, 0, "");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str9, 4, "HEAD");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str10, 1, "\012");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str11, 12, "Content-Type");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str12, 25, "text/plain; charset=utf-8");
HEFF_LIT(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str13, 5, "close");
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam2, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam0(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam4(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam4, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam7(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam7, 2, 0};
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam8(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam8, 1, 0};
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam9(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam10(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam6(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam5(V self, V *args);
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam11(V self, V *args); static Clo g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam11_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam11, 2, 0};
Clo g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_entry, 4, 0};

V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186(V v_nt_240, V v_c_241, V v_handle_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Asked: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(v_handle_242, 1, (V[]){heff_dup(v_r_244)}));
    return heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam0, 2, 5, (V[]){v_c_246, v_r_244, heff_dup(v_c_241), v_nt_240, v_rest_245});
  }
  case TAG_Refused: {
    V v_status_2427 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    heff_drop(v_handle_242);
    V v_t_2428 = (g_std_2ehttp_2eserver_2ereason(heff_dup(v_status_2427)));
    V v_t_2429 = heff_strAppend(v_t_2428, ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str10));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str11), ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str12)}), NTAG(TAG_Nil)});
    V v_t_2431 = heff_rec_n(3, shape_status__headers__body, (V[]){v_status_2427, v_t_2430, heff_bytesFromString(v_t_2429)});
    V v_b_2432 = ({ V a_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str13); V b_1 = NTAG(TAG_True); V a_2 = v_t_2431; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2434;
    switch (heff_tag_of(v_c_241)) {
    case TAG_MkWith: {
      V v_x_2433 = heff_field(v_c_241, 0);
      v_t_2434 = heff_dup(v_x_2433);
      break;
    }
    default: heff_nomatch(v_c_241);
    }
    V v_t_2436 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Write, 3, (V[]){v_t_2434, v_b_2432, ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam4_clo)})}));
    return heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam5, 2, 3, (V[]){v_t_2436, heff_dup(v_c_241), v_nt_240});
  }
  case TAG_Ended: {
    heff_drop(v_nt_240);
    heff_drop(v_handle_242);
    return ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam11_clo);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam2(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_close_2413 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    heff_drop(v_close_2413);
    heff_drop(v_rest_245);
    v_t_2426 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    if ((heff_dup(v_close_2413) == NTAG(TAG_True))) {
      heff_drop(v_close_2413);
      heff_drop(v_rest_245);
      v_t_2426 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_Done, 1, (V[]){NTAG(TAG_False)});
    } else {
      heff_drop(v_close_2413);
      v_t_2426 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_Next, 1, (V[]){v_rest_245});
    }
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_248;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_r_244 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_close_2413;
  if (heff_strEq_c(heff_dup(heff_rfield(v_r_244, 2)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str0))) {
    V v_x1_2411 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str1); V a_1 = heff_rfield(v_r_244, 3); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
      heff_drop(v_x1_2411);
      v_close_2413 = NTAG(TAG_True);
    } else {
      heff_drop(v_x1_2411);
      v_close_2413 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str2); V a_1 = heff_rfield(v_x_249, 1); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    }
  } else {
    V v_x1_2412 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str3); V a_1 = heff_rfield(v_r_244, 3); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
      heff_drop(v_x1_2412);
      v_close_2413 = ({ V b_0 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str4); V a_1 = heff_rfield(v_x_249, 1); V r_ = (g_std_2ehttp_2eserver_2econnectionSays(b_0, a_1)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_x1_2412);
      v_close_2413 = NTAG(TAG_True);
    }
  }
  V v_t_2415;
  if ((heff_dup(v_close_2413) == NTAG(TAG_True))) {
    v_t_2415 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str5);
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_r_244, 2)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str6))) {
      v_t_2415 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str7);
    } else {
      v_t_2415 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str8);
    }
  }
  V v_t_2417 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_r_244, 0)), ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_str9)));
  heff_drop_rec(v_r_244, 6);
  V v_b_2418 = ({ V a_0 = v_t_2415; V a_1 = v_t_2417; V a_2 = v_x_249; V r_ = (g_std_2ehttp_2eserver_2eresponseBytes(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_c_241)) {
  case TAG_MkWith: {
    V v_x_2419 = heff_field(v_c_241, 0);
    heff_take_n(v_c_241, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  V v_t_2422 = heff_tr(heff_call(v_nt_240, 1, (V[]){heff_tag_n(TAG_Write, 3, (V[]){v_t_2420, v_b_2418, ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam2_clo)})}));
  return (g_co_2eop_24s162716155x1210144019(v_t_2422, v_hd_247, heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam3, 1, 3, (V[]){v_close_2413, v_rest_245, v_k_248})));
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_r_244 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_nt_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam1, 1, 6, (V[]){v_r_244, v_c_241, v_nt_240, v_hd_247, v_rest_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam4(V self, V *args) {
  V v_r_2435 = args[0];
  return v_r_2435;
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam8(V self, V *args) {
  V v_r_2446 = args[0];
  return v_r_2446;
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam9(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_nt_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_t_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_nt_240; V a_1 = v_c_241; V a_2 = MK_INT(0LL); V a_3 = heff_dup(v_hd_2448); V a_4 = v_k_2449; V a_5 = v_t_2447; V a_6 = v_hd_2448; V r_ = (g_co_2eop_24s279158732x359344659(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_241); r_; });
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam10(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_False)});
  V f_ = v_k_2438;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_hd_2437 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2450;
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    heff_take_n(v_x_2439, 0ULL, 1);
    heff_drop(v_c_241);
    heff_drop(v_nt_240);
    v_c_2450 = ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam7_clo);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2439, 0ULL, 1);
    V v_t_2445;
    switch (heff_tag_of(v_c_241)) {
    case TAG_MkWith: {
      V v_x_2444 = heff_dup(heff_field(v_c_241, 0));
      v_t_2445 = v_x_2444;
      break;
    }
    default: heff_nomatch(v_c_241);
    }
    V v_t_2447 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Shutdown, 2, (V[]){v_t_2445, ((V)&g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam8_clo)})}));
    v_c_2450 = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam9, 2, 3, (V[]){v_nt_240, v_c_241, v_t_2447});
    break;
  }
  default: heff_nomatch(v_x_2439);
  }
  V f_ = v_c_2450;
  heff_room[0] = v_hd_2437;
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam10, 1, 1, (V[]){v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_t_2436 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s162716155x1210144019(v_t_2436, heff_dup(v_hd_2437), heff_clo_n(g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam6, 1, 4, (V[]){v_c_241, v_nt_240, v_hd_2437, v_k_2438})));
}
V g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186_lam11(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  heff_drop(v_hd_2453);
  V v_t_2455 = heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_False)});
  V f_ = v_k_2454;
  args[0] = v_t_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam1(V self, V *args);
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam0(V self, V *args);
Clo g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_entry, 7, 0};

V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480(V v_nt_240, V v_handle_241, V v_c_242, V v_peer_243, V v_buf_244, V v_z_245, V v_z_246) {
top: ;
  V v_c_247 = (g_std_2ehttp_2eserver_2ereadHead_24s1300824583x652193735(heff_dup(v_nt_240), v_c_242, v_buf_244, MK_INT(0LL)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam0, 1, 6, (V[]){v_nt_240, heff_dup(v_c_242), v_peer_243, v_z_245, v_handle_241, v_z_246})});
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_nt_240 = heff_env(self)[0];
  V v_handle_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_peer_243 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Next: {
    V v_rest_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    return ({ V a_0 = v_nt_240; V a_1 = v_handle_241; V a_2 = v_c_242; V a_3 = v_peer_243; V a_4 = v_rest_2412; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_242); r_; });
  }
  case TAG_Done: {
    V v_stop_2413 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop(v_nt_240);
    heff_drop(v_handle_241);
    heff_drop(v_c_242);
    heff_drop(v_peer_243);
    heff_drop(v_z_245);
    V f_ = v_z_246;
    args[0] = v_stop_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_nt_240 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_handle_241 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_peer_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2410 = (g_std_2ehttp_2eserver_2eanswered_24s772784760x977419186(heff_dup(v_nt_240), v_c_242, heff_dup(v_handle_241), v_x_249));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam2, 1, 6, (V[]){v_nt_240, v_handle_241, v_c_242, v_peer_243, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_nt_240 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_peer_243 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_handle_241 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = heff_dup(v_nt_240); V a_1 = v_c_242; V a_2 = heff_dup(v_peer_243); V a_3 = v_x_248; V a_4 = heff_dup(v_z_245); V a_5 = heff_clo_n(g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480_lam1, 1, 6, (V[]){v_nt_240, heff_dup(v_c_242), v_handle_241, v_z_245, v_peer_243, v_z_246}); V r_ = (g_std_2ehttp_2eserver_2eheaded_24s226474130x1570658425(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_242); heff_drop(v_x_248); r_; });
}
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam0, 1, 0};
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_entry, 5, 0};

V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551(V v_nt_240, V v_handle_241, V v_c_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_c_242)) {
  case TAG_MkWith: {
    V v_x_245 = heff_field(v_c_242, 0);
    v_t_246 = heff_dup(v_x_245);
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  V v_t_248 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Peer, 2, (V[]){v_t_246, ((V)&g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam0_clo)})}));
  return (g_co_2eop_24s162716155x1210144019(v_t_248, heff_dup(v_z_243), heff_clo_n(g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam1, 1, 5, (V[]){v_z_244, v_nt_240, v_handle_241, heff_dup(v_c_242), v_z_243})));
}
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_handle_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    heff_take_n(v_x_249, 0ULL, 1);
    heff_drop(v_nt_240);
    heff_drop(v_handle_241);
    heff_drop(v_c_242);
    heff_drop(v_z_243);
    V f_ = v_z_244;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_peer_2411 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return ({ V a_0 = v_nt_240; V a_1 = v_handle_241; V a_2 = v_c_242; V a_3 = v_peer_2411; V a_4 = heff_dup(g_bytes_2eempty_get()); V a_5 = v_z_243; V a_6 = v_z_244; V r_ = (g_std_2ehttp_2eserver_2eserveFrom_24s1932181596x953889480(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_242); r_; });
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam0, 1, 0};
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam2(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam5(V self, V *args); static Clo g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam5, 1, 0};
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam6(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam3(V self, V *args);
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_entry, 4, 0};

V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196(V v_nt_240, V v_stopped_241, V v_l_242, V v_handle_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_l_242)) {
  case TAG_MkWith: {
    V v_x_244 = heff_field(v_l_242, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_l_242);
  }
  V v_t_247 = heff_tr(heff_call(heff_dup(v_nt_240), 1, (V[]){heff_tag_n(TAG_Accept, 2, (V[]){v_t_245, ((V)&g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam0_clo)})}));
  return heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam1, 2, 5, (V[]){v_stopped_241, v_t_247, v_nt_240, heff_dup(v_l_242), v_handle_243});
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_stopped_241 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_err_2411 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_t_2412 = heff_tag_n(TAG_Send, 3, (V[]){v_stopped_241, heff_get_n(v_err_2411, 0, 3), NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s162716155x1210144019(heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InL, 1, (V[]){v_t_2412}), v_hd_248, v_k_249));
  }
  case TAG_Right: {
    heff_take_n(v_x_2410, 0ULL, 1);
    heff_drop(v_stopped_241);
    heff_drop(v_hd_248);
    V f_ = v_k_249;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam5(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_err_2424 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    heff_drop(v_x_2420);
    v_t_2426 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_Left, 1, (V[]){v_err_2424});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    v_t_2426 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_Right, 1, (V[]){v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_2414;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_nt_240 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = heff_tr(heff_call(v_nt_240, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_2417, ((V)&g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam5_clo)})}));
  return (g_co_2eop_24s459815859x1387532636(v_t_2422, v_hd_248, heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam6, 1, 2, (V[]){v_x_2420, v_k_2414})));
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_nt_240 = heff_env(self)[1];
  V v_stopped_241 = heff_env(self)[2];
  V v_l_242 = heff_env(self)[3];
  V v_handle_243 = heff_env(self)[4];
  V v_hd_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_err_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    heff_drop(v_nt_240);
    heff_drop(v_stopped_241);
    heff_drop(v_l_242);
    heff_drop(v_handle_243);
    heff_drop(v_hd_248);
    V f_ = v_k_2414;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2416});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_c_2418 = ({ V a_0 = heff_dup(v_nt_240); V a_1 = v_stopped_241; V a_2 = v_l_242; V a_3 = heff_dup(v_handle_243); V r_ = (g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196(a_0, a_1, a_2, a_3)); heff_drop(v_l_242); r_; });
    V v_t_2419 = heff_tag_n(TAG_Spawn, 2, (V[]){v_c_2418, NTAG(TAG_MkUnit)});
    return ({ V a_0 = heff_dup(v_nt_240); V a_1 = v_handle_243; V b_2 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_MkWith, 1, (V[]){heff_dup(v_x_2417)}); V a_3 = heff_dup(v_hd_248); V a_4 = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam4, 1, 4, (V[]){v_nt_240, v_x_2417, heff_dup(v_hd_248), v_k_2414}); V a_5 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2419}); V a_6 = v_hd_248; V r_ = (g_co_2eop_24s728204878x155198609(a_0, a_1, b_2, a_3, a_4, a_5, a_6)); heff_drop(b_2); r_; });
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_stopped_241 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_nt_240 = heff_env(self)[2];
  V v_l_242 = heff_env(self)[3];
  V v_handle_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_k_2414 = heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam2, 1, 3, (V[]){heff_dup(v_stopped_241), heff_dup(v_hd_248), v_k_249});
  return (g_co_2eop_24s459815859x1387532636(v_t_247, heff_dup(v_hd_248), heff_clo_n(g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196_lam3, 1, 6, (V[]){v_k_2414, v_nt_240, v_stopped_241, v_l_242, v_handle_243, v_hd_248})));
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam0(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam0, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam2(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam2, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam3(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam3, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam5(V self, V *args); static Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam5, 1, 0};
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam4(V self, V *args);
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam1(V self, V *args);
Clo g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_entry, 3, 0};

V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777(V v_nt_240, V v_l_241, V v_handle_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_NewChan, 1, (V[]){((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam0_clo)})});
  V v_a_245 = (g_green_2egreenAlg_24s1477571606x442912311(v_t_244));
  return (g_green_2ethenRes_24s1747913378x1698907254(v_a_245, heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam1, 1, 3, (V[]){v_nt_240, heff_dup(v_l_241), v_handle_242})));
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam0(V self, V *args) {
  V v_n_243 = args[0];
  return v_n_243;
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam2(V self, V *args) {
  V v_a_248 = args[0];
  return heff_tag_n(TAG_RDone, 1, (V[]){v_a_248});
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam3(V self, V *args) {
  V v_a_249 = args[0];
  return heff_tag_n(TAG_RDone, 1, (V[]){v_a_249});
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam5(V self, V *args) {
  V v_v_2415 = args[0];
  return v_v_2415;
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Recv, 2, (V[]){v_x_246, ((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam5_clo)})});
  V v_a_2417 = (g_green_2egreenAlg_24s1477571606x442912311(v_t_2416));
  return (g_green_2ethenRes_24s352754375x1842358360(v_a_2417));
}
V g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_nt_240 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_handle_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_247 = ({ V a_0 = v_nt_240; V a_1 = heff_dup(v_x_246); V a_2 = v_l_241; V a_3 = v_handle_242; V r_ = (g_std_2ehttp_2eserver_2eacceptor_24s1943743487x1127315196(a_0, a_1, a_2, a_3)); heff_drop(v_l_241); r_; });
  V v_t_2410 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam2_clo), ((V)&g_green_2ethenRes_24s1747913378x1698907254_clo), ((V)&g_green_2egreenAlg_24s1477571606x442912311_clo)}), ((V)&g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam3_clo)}));
  V v_t_2411 = heff_tag_n(TAG_Spawn, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
  V v_a_2412 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2411});
  V v_a_2413 = (g_green_2egreenAlg_24s1477571606x442912311(v_a_2412));
  return (g_green_2ethenRes_24s1747913378x1698907254(v_a_2413, heff_clo_n(g_std_2ehttp_2eserver_2eserveConcurrently_24s1918427418x1918444777_lam4, 1, 1, (V[]){v_x_246})));
}