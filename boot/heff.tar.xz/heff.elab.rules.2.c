// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CUndelay 45232
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940 61712
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135 24780
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_depth 296830685
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_hole 9703815
#define LBL_instances 1653559473
#define LBL_instantiated 552850723
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_state 311115947
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_wantedBy 1134124532
#define LBL_witness 1587180415
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_depth__wantedBy[] = {LBL_depth, LBL_wantedBy};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_name__goal[] = {LBL_name, LBL_goal};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimString_get(void);
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2ebrokenInstanceIn(V);
V g_heff_2eelab_2erules_2ebrokenInstanceIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebrokenInstanceIn_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2ecommitted(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecommitted_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2eeachSubgoal(V, V);
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeachSubgoal_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
V g_heff_2eelab_2erules_2eelimPlain(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimPlain_clo;
V g_heff_2eelab_2erules_2eeqTyStr(V, V, V);
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqTyStr_clo;
V g_heff_2eelab_2erules_2eerrorOf_get(void);
V g_heff_2eelab_2erules_2efieldIdxs_24dps(V, V, V);
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo;
V g_heff_2eelab_2erules_2efits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efits_clo;
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2egivenTwice(V, V);
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenTwice_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V);
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2elitBytes(V, V);
V g_heff_2eelab_2erules_2elitBytes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitBytes_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V, V, V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2emisfit(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo;
V g_heff_2eelab_2erules_2enestedField(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enestedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enestedField_clo;
V g_heff_2eelab_2erules_2enotAFunction(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotAFunction_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2enumLitDefault(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitDefault_clo;
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2eplacesGo(V, V);
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_clo;
V g_heff_2eelab_2erules_2eplacesGo_24dps(V, V, V);
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo;
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordFormation(V);
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordFormation_clo;
V g_heff_2eelab_2erules_2erecordNameOf(V, V, V, V);
V g_heff_2eelab_2erules_2erecordNameOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordNameOf_clo;
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordUpdate(V, V, V, V);
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordUpdate_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2esumIntro(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntro_clo;
V g_heff_2eelab_2erules_2esumIntroNow(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntroNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_clo;
HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2etooDeep(V, V, V, V);
V g_heff_2eelab_2erules_2etooDeep_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooDeep_clo;
HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V);
V g_heff_2eelab_2erules_2eupdateOf(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateOf_clo;
V g_heff_2eelab_2erules_2eupdateSetting(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateSetting_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2erules_2ewitnessMatches(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewitnessMatches_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eimplicitDefault(V);
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efilter_24s1966236437x1225976932(V, V);
V g_list_2efilter_24s1966236437x1225976932_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966236437x1225976932_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1292210741x1158835606(V, V, V);
V g_list_2emap_24s1292210741x1158835606_entry(V self, V *a);
extern Clo g_list_2emap_24s1292210741x1158835606_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str9, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str10, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str11, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str13, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str14, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str15, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str16, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str17, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str18, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str19, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str20, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str21, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str22, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str23, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str24, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str25, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str26, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str27, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str28, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str29, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str30, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str31, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str32, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str33, 0, "");
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam4(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry, 5, 0};

V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V v_tag_240, V v_d_241, V v_t_242, V v_d_243, V v_t_244) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940: {
    top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940: ;
    heff_drop(v_d_243);
    heff_drop(v_t_244);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SLocal: {
      V v_i_245 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      return heff_intLe(v_d_241, v_i_245);
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      V v_a_247 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str1);
      V t_3 = v_d_241;
      V t_4 = v_a_247;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SApp: {
      V v_f_248 = heff_field(v_t_242, 0);
      V v_a_249 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_241), v_f_248));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_a_249);
        heff_drop(v_t_2410);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2410);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
        V t_1 = v_d_241;
        V t_2 = v_a_249;
        V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str2);
        V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str3);
        v_tag_240 = t_0;
        v_d_241 = t_1;
        v_t_242 = t_2;
        v_d_243 = t_3;
        v_t_244 = t_4;
        goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
      }
    }
    case TAG_SLam: {
      V v_dd_2411 = heff_field(v_t_242, 0);
      V v_t2_2412 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      switch (heff_tag_of(v_t2_2412)) {
      case TAG_MkAbs: {
        V v_b_2414 = heff_field(v_t2_2412, 1);
        heff_take_n(v_t2_2412, 2ULL, 2);
        V v_t_2415 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2411));
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_b_2414);
          heff_drop(v_t_2415);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2415);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = heff_intAdd(v_d_241, MK_INT(1LL));
          V t_2 = v_b_2414;
          V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str4);
          V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str5);
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      case TAG_AbsConst: {
        V v_b_2416 = heff_field(v_t2_2412, 0);
        heff_take_n(v_t2_2412, 1ULL, 1);
        V v_t_2417 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2411));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_b_2416);
          heff_drop(v_t_2417);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2417);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = v_d_241;
          V t_2 = v_b_2416;
          V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str6);
          V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str7);
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      default: return heff_nomatch(v_t2_2412);
      }
    }
    case TAG_SCons: {
      V v_dct_2418 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_2419 = heff_arrayToList(heff_take_field(v_dct_2418, 0));
      V v_t_2420 = heff_arrayToList(heff_get_n(v_dct_2418, 2, 3));
      V v_t_2421 = (g_heff_2eutil_2edict_2ezipKV(v_t_2419, v_t_2420));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam0, 1, 1, (V[]){v_d_241}); V a_1 = v_t_2421; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_SProj: {
      V v_e_2425 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2425;
      V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str8);
      V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str9);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_STag: {
      V v_as_2428 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam1, 1, 1, (V[]){v_d_241}); V b_1 = heff_arrayToList(v_as_2428); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
    }
    case TAG_SMatch: {
      V v_e_2430 = heff_field(v_t_242, 0);
      V v_cs_2431 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_t_2432 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_241), v_e_2430));
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop_rec(v_cs_2431, 3);
        heff_drop(v_t_2432);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2432);
        V v_t_2433 = heff_arrayToList(heff_take_field(v_cs_2431, 0));
        V v_t_2434 = heff_arrayToList(heff_get_n(v_cs_2431, 2, 3));
        V v_t_2435 = (g_heff_2eutil_2edict_2ezipKV(v_t_2433, v_t_2434));
        return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam2, 1, 1, (V[]){v_d_241}); V a_1 = v_t_2435; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2435); r_; });
      }
    }
    case TAG_SSpecialize: {
      V v_e_2442 = heff_field(v_t_242, 0);
      V v_v_2444 = heff_field(v_t_242, 2);
      heff_take_n(v_t_242, 5ULL, 3);
      V v_t_2445 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_241), v_e_2442));
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_v_2444);
        heff_drop(v_t_2445);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2445);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
        V t_1 = v_d_241;
        V t_2 = v_v_2444;
        V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str10);
        V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str11);
        v_tag_240 = t_0;
        v_d_241 = t_1;
        v_t_242 = t_2;
        v_d_243 = t_3;
        v_t_244 = t_4;
        goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
      }
    }
    case TAG_SIs: {
      V v_e_2446 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2446;
      V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str12);
      V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str13);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SOpaque: {
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      V v_e_2447 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2447;
      V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str14);
      V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str15);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SFix: {
      V v_dd_2448 = heff_field(v_t_242, 0);
      V v_t2_2449 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      switch (heff_tag_of(v_t2_2449)) {
      case TAG_MkAbs: {
        V v_b_2451 = heff_field(v_t2_2449, 1);
        heff_take_n(v_t2_2449, 2ULL, 2);
        V v_t_2452 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2448));
        if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_b_2451);
          heff_drop(v_t_2452);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2452);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = heff_intAdd(v_d_241, MK_INT(1LL));
          V t_2 = v_b_2451;
          V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str16);
          V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str17);
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      case TAG_AbsConst: {
        V v_b_2453 = heff_field(v_t2_2449, 0);
        heff_take_n(v_t2_2449, 1ULL, 1);
        V v_t_2454 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2448));
        if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_b_2453);
          heff_drop(v_t_2454);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2454);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = v_d_241;
          V t_2 = v_b_2453;
          V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str18);
          V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str19);
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      default: return heff_nomatch(v_t2_2449);
      }
    }
    case TAG_SImplicit: {
      V v_e_2456 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2456;
      V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str20);
      V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str21);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SPrim: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      V v_ty_2460 = heff_field(v_t_242, 2);
      heff_take_n(v_t_242, 4ULL, 3);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str22);
      V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str23);
      V t_3 = v_d_241;
      V t_4 = v_ty_2460;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_242, 0ULL, 2);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135: {
    top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135: ;
    heff_drop(v_d_241);
    heff_drop(v_t_242);
    switch (heff_tag_of(v_t_244)) {
    case TAG_SU: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      V v_e_2470 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_243;
      V t_2 = v_e_2470;
      V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str24);
      V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str25);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SFunction: {
      V v_dom_2472 = heff_field(v_t_244, 1);
      V v_t3_2473 = heff_field(v_t_244, 2);
      heff_take_n(v_t_244, 6ULL, 5);
      switch (heff_tag_of(v_t3_2473)) {
      case TAG_MkAbs: {
        V v_b_2477 = heff_field(v_t3_2473, 1);
        heff_take_n(v_t3_2473, 2ULL, 2);
        V v_t_2478 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_243), v_dom_2472));
        if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
          heff_drop(v_d_243);
          heff_drop(v_b_2477);
          heff_drop(v_t_2478);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2478);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
          V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str26);
          V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str27);
          V t_3 = heff_intAdd(v_d_243, MK_INT(1LL));
          V t_4 = v_b_2477;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
        }
      }
      case TAG_AbsConst: {
        V v_b_2479 = heff_field(v_t3_2473, 0);
        heff_take_n(v_t3_2473, 1ULL, 1);
        V v_t_2480 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_243), v_dom_2472));
        if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
          heff_drop(v_d_243);
          heff_drop(v_b_2479);
          heff_drop(v_t_2480);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2480);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
          V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str28);
          V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str29);
          V t_3 = v_d_243;
          V t_4 = v_b_2479;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
        }
      }
      default: return heff_nomatch(v_t3_2473);
      }
    }
    case TAG_SRecord: {
      V v_ft_2482 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 2ULL, 3);
      V v_t_2484 = heff_arrayToList(heff_get_n(v_ft_2482, 2, 3));
      return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam3, 2, 1, (V[]){v_d_243}); V a_2 = v_t_2484; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2484); r_; });
    }
    case TAG_SSum: {
      V v_vs_2487 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_2488 = heff_arrayToList(heff_take_field(v_vs_2487, 0));
      V v_t_2489 = heff_arrayToList(heff_get_n(v_vs_2487, 2, 3));
      V v_t_2490 = (g_heff_2eutil_2edict_2ezipKV(v_t_2488, v_t_2489));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam4, 1, 1, (V[]){v_d_243}); V a_1 = v_t_2490; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2490); r_; });
    }
    case TAG_SIsTy: {
      V v_a_2495 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str30);
      V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str31);
      V t_3 = v_d_243;
      V t_4 = v_a_2495;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SPrimInt: {
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      V v_a_2496 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str32);
      V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str33);
      V t_3 = v_d_243;
      V t_4 = v_a_2496;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SFixed: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam0(V self, V *args) {
  V v_x3_2422 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2422)) {
  case TAG_MkPair: {
    V v_v_2424 = heff_field(v_x3_2422, 1);
    heff_take_n(v_x3_2422, 2ULL, 2);
    return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_d_241, v_v_2424));
  }
  default: return heff_nomatch(v_x3_2422);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam1(V self, V *args) {
  V v_t_2429 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_d_241, v_t_2429));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam2(V self, V *args) {
  V v_x3_2436 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2436)) {
  case TAG_MkPair: {
    V v_x32_2438 = heff_field(v_x3_2436, 1);
    heff_take_n(v_x3_2436, 2ULL, 2);
    switch (heff_tag_of(v_x32_2438)) {
    case TAG_MkPair: {
      V v_xs_2439 = heff_field(v_x32_2438, 0);
      V v_b_2440 = heff_field(v_x32_2438, 1);
      heff_take_n(v_x32_2438, 3ULL, 2);
      V v_t_2441 = heff_intAdd(v_d_241, heff_arrayLength(v_xs_2439));
      return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_t_2441, v_b_2440));
    }
    default: return heff_nomatch(v_x32_2438);
    }
  }
  default: return heff_nomatch(v_x3_2436);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam3(V self, V *args) {
  V v_i_2485 = args[0];
  V v_ty_2486 = args[1];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_intAdd(v_d_243, v_i_2485), v_ty_2486));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam5(V self, V *args) {
  V v_t_2494 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(v_d_243, v_t_2494));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam4(V self, V *args) {
  V v_x3_2491 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2491)) {
  case TAG_MkPair: {
    V v_args_2493 = heff_field(v_x3_2491, 1);
    heff_take_n(v_x3_2491, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam5, 1, 1, (V[]){v_d_243}); V b_1 = heff_arrayToList(v_args_2493); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2491);
  }
}
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqTyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqTyStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqTyStr(V v_g_240, V v_cs_241, V v_t_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_take_field(v_cs_241, 0), v_t_242));
  V v_t_2412 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqTyStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_t_2413 = heff_tr(heff_call(heff_get_n(v_t_2412, 1, 2), 1, (V[]){v_t_243}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_cs_241, 1, 2); V a_3 = v_t_2413; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); r_; });
}
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqTyStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_247 = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(v_t_246, v_x_244));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_d_245);
      V v_x_2411 = v_field_249;
      return v_x_2411;
    } else {
      heff_drop(v_field_249);
      return v_d_245;
    }
  }
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitArg_entry, 5, 0};

V g_heff_2eelab_2erules_2eimplicitArg(V v_e_240, V v_sp_241, V v_ty_242, V v_dom_243, V v_x_244) {
top: ;
  V v_t_245 = (g_heff_2eelab_2evalue_2eimplicitDefault(v_ty_242));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam0, 2, 4, (V[]){v_e_240, v_dom_243, v_x_244, v_sp_241});
  }
  case TAG_Just: {
    V v_d_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop(v_sp_241);
    heff_drop(v_dom_243);
    heff_drop(v_x_244);
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam3, 2, 2, (V[]){v_d_2413, v_e_240});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitArg(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam2, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_nf(v_x_2410, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_dom_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_249 = heff_get_n(heff_get_n(v_e_240, 0, 6), 2, 4);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = v_dom_243; V a_3 = v_x_244; V a_4 = v_sp_241; V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam1, 1, 1, (V[]){v_k_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args) {
  V v_u_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_d_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_get_n(v_e_240, 1, 6), NTAG(TAG_N), v_d_2413, NTAG(TAG_LNil)));
}
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_2413), heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam4, 1, 2, (V[]){v_e_240, v_d_2413})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ewitnessMatches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewitnessMatches_entry, 6, 0};

V g_heff_2eelab_2erules_2ewitnessMatches(V v_e_240, V v_sp_241, V v_goal_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_goal_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_w_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    HEFF_LAST return g_heff_2eelab_2erules_2efits(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_goal_242), v_w_246, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam0, 1, 6, (V[]){v_e_240, v_sp_241, v_goal_242, v_rest_247, v_p_244, v_p_245}));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewitnessMatches(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = v_x_2410;
    break;
  }
  case TAG_Just: {
    V v_f_2411 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2411, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V f_ = v_p_245;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_249 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ewitnessMatches_clo), 4, (V[]){v_e_240, v_sp_241, v_goal_242, v_rest_247}));
  V f_ = v_c_249;
  heff_room[0] = v_p_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam1, 1, 2, (V[]){v_x_248, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str1, 3, " : ");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str2, 6, "found ");
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ecommitted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_lam0, 1, 0};
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecommitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_entry, 8, 0};

V g_heff_2eelab_2erules_2ecommitted(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_fit_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2ecommitted_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam1, 1, 8, (V[]){v_fit_245, v_hd_246, v_e_240, v_hm_242, v_holeVal_243, v_sp_241, v_k_247, v_goal_244})});
}
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecommitted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args) {
  V v_u_2429 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2429);
  V v_t_2430 = heff_get_n(heff_get_n(v_fit_245, 0, 3), 0, 6);
  V v_t_2431 = heff_tr(heff_call(v_t_2430, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2432 = ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  V v_t_2433 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2eelab_2erules_2ecommitted_str1), v_t_2432));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2ecommitted_str2), v_t_2433);
}
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_fit_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V f_ = v_k_247;
  args[0] = heff_get_n(v_fit_245, 1, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_fit_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_goal_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_err_2427 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_goal_244);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = heff_get_n(v_fit_245, 0, 3); V a_3 = v_err_2427; V a_4 = v_hd_246; V a_5 = v_k_247; V r_ = (g_heff_2eelab_2erules_2emisfit(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_err_2427); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2426, 0ULL, 1);
    V v_t_2434 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2ecommitted_str0), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam4, 1, 4, (V[]){heff_dup(v_fit_245), v_e_240, v_x_2412, v_goal_244})}), NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2435;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam5, 1, 2, (V[]){v_k_247, v_fit_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hm_242 = heff_env(self)[2];
  V v_holeVal_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_goal_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_fit_245, 1)), 0, 3);
  V v_x1_2418 = heff_tr(heff_call(heff_get_n(v_t_2417, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_t_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_c_2423 = heff_dup(heff_rfield(v_e_240, 0));
  V v_t_2424 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2423, 0), heff_get_n(v_c_2423, 1, 4)});
  V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_fit_245, 1)), 0, 3);
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), v_t_2424, v_hm_242, v_holeVal_243, heff_get_n(v_t_2425, 0, 2), v_t_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam3, 1, 7, (V[]){v_e_240, v_sp_241, v_fit_245, v_hd_246, v_k_247, v_x_2412, v_goal_244})));
}
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hm_242 = heff_env(self)[3];
  V v_holeVal_243 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_goal_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_Put, 2, (V[]){heff_dup(heff_rfield(v_fit_245, 2)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam2, 1, 9, (V[]){v_fit_245, v_e_240, v_hm_242, v_holeVal_243, v_hd_246, v_sp_241, v_k_247, v_x_2412, v_goal_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str0, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str1, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str4, 52, "an instance argument's type is not determined here: ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str5, 79, "give the argument explicitly, or annotate so the implicits around it are solved");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str6, 201, "an instance's instance arguments are found by searches of their own, and one that wants an instance of a type no smaller than its own may want them without end: give the argument explicitly, `(x := e)`");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str7, 20, "an instance argument");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str8, 16, "no instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str9, 39, ", where one in scope does not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str10, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str11, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str13, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str14, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str15, 16, "no instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str16, 103, "declare one, `instance x : T`, bind one, `{{x : T}} -> ...`, where this is used, or give it: `(x := e)`");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str17, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str18, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str19, 1, "]");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str20, 6, "  [by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str21, 7, "wanted ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str22, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str23, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str24, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str25, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str26, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str27, 1, ")");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str28, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str29, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str30, 2, ": ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str31, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str32, 27, "more than one instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str33, 100, "they cannot be told apart by type (small values are statically opaque): give the argument explicitly");
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam0, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam10, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eresolveWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_entry, 9, 0};

V g_heff_2eelab_2erules_2eresolveWanted(V v_e_240, V v_sp_241, V v_search_242, V v_hm_243, V v_holeVal_244, V v_goal_245, V v_final_246, V v_hd_247, V v_k_248) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_247, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam1, 1, 9, (V[]){v_e_240, v_goal_245, v_final_246, v_search_242, v_sp_241, v_hd_247, v_k_248, v_hm_243, v_holeVal_244})});
}
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eresolveWanted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 8);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args) {
  V v_w_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = heff_take_field(v_w_2421, 1); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2423 = heff_strAppend(heff_get_n(v_w_2421, 0, 2), heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str0), v_t_2422));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str1), v_t_2423);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args) {
  V v_u_2442 = args[0];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return heff_get_n(v_c_2439, 0, 3);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args) {
  V v_c_2439 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_stx_2441 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_t_2440, heff_dup(heff_rfield(v_c_2439, 2))));
  return heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam4, 1, 1, (V[]){heff_dup(v_c_2439)}), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str7), NTAG(TAG_False), heff_dup(heff_rfield(v_c_2439, 1)), v_stx_2441, heff_get_n(v_c_2439, 2, 3)});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args) {
  V v_i_2446 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2einstGlobal(v_e_240, v_i_2446));
}
V g_heff_2eelab_2erules_2eresolveWanted_lam7(V self, V *args) {
  V v_w_2459 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2460 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = heff_take_field(v_w_2459, 1); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2461 = heff_strAppend(heff_get_n(v_w_2459, 0, 2), heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str10), v_t_2460));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str11), v_t_2461);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam10(V self, V *args) {
  V v_c_2478 = args[0];
  return heff_get_n(v_c_2478, 3, 8);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam12(V self, V *args) {
  V v_u_2483 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2482 = heff_env(self)[1];
  V v_sg_2475 = heff_env(self)[2];
  V v_one_2472 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_goal_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2483);
  V v_t_2484 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_x_2482; V a_2 = heff_get_n(v_sg_2475, 1, 2); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2482); r_; });
  V v_t_2485 = heff_get_n(heff_get_n(v_one_2472, 0, 3), 0, 6);
  V v_t_2486 = heff_tr(heff_call(v_t_2485, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2487 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2488 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str18), heff_strAppend(v_t_2487, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str19)));
  V v_t_2489 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str20), heff_strAppend(v_t_2486, v_t_2488));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str21), heff_strAppend(v_t_2484, v_t_2489));
}
V g_heff_2eelab_2erules_2eresolveWanted_lam15(V self, V *args) {
  V v_b_24137 = args[0];
  V v_search_242 = heff_env(self)[0];
  V v_one_2472 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_sg_2475 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_hd_2476 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24138 = heff_intAdd(heff_take_field(v_search_242, 0), MK_INT(1LL));
  V v_t_24139 = heff_get_n(heff_get_n(v_one_2472, 0, 3), 0, 6);
  V v_t_24140 = heff_tr(heff_call(v_t_24139, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24141 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_24140, v_goal_245}), heff_get_n(v_search_242, 1, 2)});
  V v_t_24142 = heff_get_n(heff_dup(heff_rfield(v_sg_2475, 0)), 0, 2);
  V v_t_24178;
  switch (heff_tag_of(v_t_24142)) {
  case TAG_SLocal: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_24142, 0ULL, 3);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_24167 = heff_field(v_t_24142, 0);
    heff_take_n(v_t_24142, 1ULL, 3);
    v_t_24178 = v_k_24167;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_24142, 0ULL, 2);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_24142, 0ULL, 1);
    v_t_24178 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_24142);
  }
  V v_t_24179 = heff_get_n(heff_dup(heff_rfield(v_sg_2475, 0)), 1, 2);
  V v_c_24180 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 7, (V[]){v_e_240, v_sp_241, heff_rec_n(2, shape_depth__wantedBy, (V[]){v_t_24138, v_t_24141}), v_t_24178, v_t_24179, heff_get_n(v_sg_2475, 1, 2), v_b_24137}));
  V f_ = v_c_24180;
  heff_room[0] = heff_dup(v_hd_2476);
  heff_room[1] = heff_get_n(v_hd_2476, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam14(V self, V *args) {
  V v_x_24136 = args[0];
  V v_k_2477 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_search_242 = heff_env(self)[2];
  V v_one_2472 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_sg_2475 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_hd_2476 = heff_env(self)[7];
  heff_clo_take(self, 8);
  if ((heff_dup(v_x_24136) == NTAG(TAG_True))) {
    heff_drop(v_x_24136);
    heff_drop(v_sp_241);
    heff_drop_rec(v_search_242, 2);
    heff_drop_rec(v_one_2472, 3);
    heff_drop(v_goal_245);
    heff_drop_rec(v_sg_2475, 2);
    heff_drop_rec(v_e_240, 6);
    heff_drop_rec(v_hd_2476, 3);
    V f_ = v_k_2477;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24136);
    V v_t_24181 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam15, 1, 7, (V[]){v_search_242, v_one_2472, v_goal_245, v_sg_2475, v_e_240, v_sp_241, heff_dup(v_hd_2476)}), NTAG(TAG_MkUnit)});
    V v_t_24182 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24181})});
    V v_t_24183 = heff_tr(heff_call(heff_take_field(v_hd_2476, 2), 1, (V[]){v_t_24182}));
    V f_ = heff_get_n(v_hd_2476, 1, 3);
    heff_room[0] = v_t_24183;
    heff_room[1] = v_k_2477;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam13(V self, V *args) {
  V v_x_2492 = args[0];
  V v_search_242 = heff_env(self)[0];
  V v_one_2472 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_sg_2475 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  V v_hd_2476 = heff_env(self)[7];
  V v_k_2477 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2492);
  V v_t_2493 = heff_intAdd(heff_dup(heff_rfield(v_search_242, 0)), MK_INT(1LL));
  V v_t_2494 = heff_get_n(heff_dup(heff_rfield(v_one_2472, 0)), 0, 6);
  V v_t_2495 = heff_tr(heff_call(v_t_2494, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_2495, heff_dup(v_goal_245)}), heff_dup(heff_rfield(v_search_242, 1))});
  V v_t_2497 = heff_get_n(heff_dup(heff_rfield(v_sg_2475, 0)), 0, 2);
  V v_t_24133;
  switch (heff_tag_of(v_t_2497)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2497, 0ULL, 3);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_24122 = heff_field(v_t_2497, 0);
    heff_take_n(v_t_2497, 1ULL, 3);
    v_t_24133 = v_k_24122;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2497, 0ULL, 2);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2497, 0ULL, 1);
    v_t_24133 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2497);
  }
  V v_t_24134 = heff_get_n(heff_dup(heff_rfield(v_sg_2475, 0)), 1, 2);
  V v_c_24135 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 7, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_rec_n(2, shape_depth__wantedBy, (V[]){v_t_2493, v_t_2496}), v_t_24133, v_t_24134, heff_dup(heff_rfield(v_sg_2475, 1)), v_final_246}));
  V f_ = v_c_24135;
  heff_room[0] = heff_dup(v_hd_2476);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam14, 1, 8, (V[]){v_k_2477, v_sp_241, v_search_242, v_one_2472, v_goal_245, v_sg_2475, v_e_240, v_hd_2476});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam11(V self, V *args) {
  V v_x_2482 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sg_2475 = heff_env(self)[2];
  V v_one_2472 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_goal_245 = heff_env(self)[5];
  V v_hd_2476 = heff_env(self)[6];
  V v_search_242 = heff_env(self)[7];
  V v_final_246 = heff_env(self)[8];
  V v_k_2477 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2490 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str17), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam12, 1, 6, (V[]){heff_dup(v_e_240), v_x_2482, heff_dup(v_sg_2475), heff_dup(v_one_2472), v_x_2413, heff_dup(v_goal_245)})}), NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2476, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
  V f_ = heff_dup(heff_rfield(v_hd_2476, 1));
  heff_room[0] = v_t_2491;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam13, 1, 9, (V[]){v_search_242, v_one_2472, v_goal_245, v_sg_2475, v_e_240, v_sp_241, v_final_246, v_hd_2476, v_k_2477});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam9(V self, V *args) {
  V v_sg_2475 = args[0];
  V v_hd_2476 = args[1];
  V v_k_2477 = args[2];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_2472 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_search_242 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam10_clo)})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2476, 2)), 1, (V[]){v_t_2480}));
  V f_ = heff_dup(heff_rfield(v_hd_2476, 1));
  args[0] = v_t_2481;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam11, 1, 10, (V[]){v_sp_241, v_e_240, v_sg_2475, v_one_2472, v_x_2413, v_goal_245, v_hd_2476, v_search_242, v_final_246, v_k_2477});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam16(V self, V *args) {
  V v_x_24185 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24185);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam8(V self, V *args) {
  V v_x_2474 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_2472 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_search_242 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  V v_hd_247 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_24184 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam9, 3, 7, (V[]){v_sp_241, v_e_240, v_one_2472, v_x_2413, v_goal_245, v_search_242, v_final_246}); V b_1 = heff_get_n(v_x_2474, 2, 3); V r_ = (g_heff_2eelab_2erules_2eeachSubgoal(a_0, b_1)); heff_drop(b_1); r_; });
  V f_ = v_c_24184;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam16, 1, 1, (V[]){v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam17(V self, V *args) {
  V v_w_24189 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24190 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = heff_take_field(v_w_24189, 1); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_24191 = heff_strAppend(heff_get_n(v_w_24189, 0, 2), heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str22), v_t_24190));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str23), v_t_24191);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_search_242 = heff_env(self)[6];
  V v_hm_243 = heff_env(self)[7];
  V v_holeVal_244 = heff_env(self)[8];
  V v_final_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Nil: {
    heff_drop(v_hm_243);
    heff_drop(v_holeVal_244);
    heff_drop(v_final_246);
    V v_t_2451 = (g_heff_2eelab_2erules_2ebrokenInstanceIn(heff_dup(v_e_240)));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop_rec(v_search_242, 2);
      heff_drop(v_t_2451);
      V v_t_2452 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
      V v_msg_2453 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str8), heff_strAppend(v_t_2452, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str9)));
      V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_msg_2453, v_sp_241, NTAG(TAG_Nothing)});
      V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2456}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2457;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2451);
      V v_t_2458 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
      V v_x2_2462 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam7, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
      V v_t_2465;
      switch (heff_tag_of(v_x2_2462)) {
      case TAG_Nil: {
        v_t_2465 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_field(v_x2_2462, 0);
        V v_xs_2464 = heff_field(v_x2_2462, 1);
        heff_take_n(v_x2_2462, 3ULL, 2);
        v_t_2465 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str13); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2462);
      }
      V v_t_2466 = heff_strAppend(v_t_2458, heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str14), v_t_2465));
      V v_msg_2467 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str15), v_t_2466);
      V v_t_2468 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(341LL), NTAG(TAG_SError), v_msg_2467, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str16)})});
      V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2468})});
      V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2470}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2471;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Cons: {
    V v_one_2472 = heff_dup(heff_field(v_x_2450, 0));
    V v_it2_2473 = heff_dup(heff_field(v_x_2450, 1));
    switch (heff_tag_of(v_it2_2473)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2450, 2);
      return (g_heff_2eelab_2erules_2ecommitted(heff_dup(v_e_240), heff_dup(v_sp_241), v_hm_243, v_holeVal_244, heff_dup(v_goal_245), heff_dup(v_one_2472), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam8, 1, 9, (V[]){v_sp_241, v_e_240, v_one_2472, v_x_2413, v_goal_245, v_search_242, v_final_246, v_hd_247, v_k_248})));
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2473, 0ULL, 2);
      heff_drop(v_hm_243);
      heff_drop(v_holeVal_244);
      heff_drop(v_final_246);
      heff_drop_rec(v_one_2472, 3);
      V v_t_24188 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
      V v_x2_24192 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam17, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
      V v_t_24195;
      switch (heff_tag_of(v_x2_24192)) {
      case TAG_Nil: {
        v_t_24195 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str24);
        break;
      }
      case TAG_Cons: {
        V v_x_24193 = heff_field(v_x2_24192, 0);
        V v_xs_24194 = heff_field(v_x2_24192, 1);
        heff_take_n(v_x2_24192, 3ULL, 2);
        v_t_24195 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str25); V a_1 = v_x_24193; V a_2 = v_xs_24194; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24194); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24192);
      }
      V v_x2_24196 = (g_list_2emap_24s1292210741x1158835606(((V)&g_heff_2eelab_2erules_2eresolveWanted_str26), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str27), v_x_2450));
      V v_t_24199;
      switch (heff_tag_of(v_x2_24196)) {
      case TAG_Nil: {
        v_t_24199 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str28);
        break;
      }
      case TAG_Cons: {
        V v_x_24197 = heff_field(v_x2_24196, 0);
        V v_xs_24198 = heff_field(v_x2_24196, 1);
        heff_take_n(v_x2_24196, 3ULL, 2);
        v_t_24199 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str29); V a_1 = v_x_24197; V a_2 = v_xs_24198; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24198); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24196);
      }
      V v_t_24200 = heff_strAppend(v_t_24195, heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str30), v_t_24199));
      V v_t_24201 = heff_strAppend(v_t_24188, heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str31), v_t_24200));
      V v_msg_24202 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str32), v_t_24201);
      V v_t_24203 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(342LL), NTAG(TAG_SError), v_msg_24202, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str33)})});
      V v_t_24204 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24203})});
      V v_t_24205 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24204})});
      V v_t_24206 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24205}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24206;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it2_2473);
    }
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_245 = heff_env(self)[1];
  V v_final_246 = heff_env(self)[2];
  V v_search_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_hm_243 = heff_env(self)[7];
  V v_holeVal_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = (g_heff_2eelab_2eunify_2emetasK(v_x_2413));
  V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_x1_2416 = heff_tr(heff_call(heff_get_n(v_t_2414, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2415, heff_dup(v_goal_245)}));
  V v_t_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nil: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2416, 0ULL, 2);
    v_t_2419 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_hm_243);
    heff_drop(v_holeVal_244);
    heff_drop(v_t_2419);
    if ((heff_dup(v_final_246) == NTAG(TAG_True))) {
      heff_drop(v_final_246);
      V v_t_2420 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
      V v_x2_2424 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam2, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
      V v_t_2427;
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_Nil: {
        v_t_2427 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2425 = heff_field(v_x2_2424, 0);
        V v_xs_2426 = heff_field(v_x2_2424, 1);
        heff_take_n(v_x2_2424, 3ULL, 2);
        v_t_2427 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str3); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2424);
      }
      V v_msg_2428 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str4), heff_strAppend(v_t_2420, v_t_2427));
      V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(340LL), NTAG(TAG_SError), v_msg_2428, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str5)})});
      V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2431}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2432;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_2413);
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_goal_245);
      heff_drop(v_final_246);
      heff_drop_rec(v_search_242, 2);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_247, 3);
      V f_ = v_k_248;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_t_2419);
    if (heff_intLt_c(MK_INT(32LL), heff_dup(heff_rfield(v_search_242, 0)))) {
      heff_drop(v_final_246);
      heff_drop(v_hm_243);
      heff_drop(v_holeVal_244);
      V v_msg_2434 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_search_242; V a_3 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2etooDeep(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
      V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(349LL), NTAG(TAG_SError), v_msg_2434, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str6)})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2437}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2438;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_t_2443 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam3, 1, 1, (V[]){heff_dup(v_e_240)}), heff_dup(heff_rfield(v_e_240, 5))));
      V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 6, 7);
      V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2444));
      V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam5, 1, 1, (V[]){heff_dup(v_e_240)}), v_t_2445));
      V v_t_2448 = (g_heff_2eelab_2erules_2ecatMaybesR(v_t_2447));
      V v_t_2449 = (g_prelude_2e_2b_2b(v_t_2443, v_t_2448));
      return (g_heff_2eelab_2erules_2ewitnessMatches(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_goal_245), v_t_2449, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam6, 1, 10, (V[]){v_e_240, v_x_2413, v_goal_245, v_sp_241, v_hd_247, v_k_248, v_search_242, v_hm_243, v_holeVal_244, v_final_246})));
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_24cpr_str2, 1, "_");
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V v_c_240) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam0, 4, 1, (V[]){heff_dup(v_c_240)})}});
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam1(V self, V *args) {
  V v_c_245 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_245, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam4(V self, V *args) {
  V v_u_2431 = args[0];
  V v_v_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_v_2424;
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam7(V self, V *args) {
  V v_u_2466 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2466);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_249});
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam6(V self, V *args) {
  V v_x_2453 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_cod_2415 = heff_env(self)[2];
  V v_k_2452 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2454 = heff_take_field(v_e_241, 2);
  V v_t_2457;
  switch (heff_tag_of(v_t_2454)) {
  case TAG_ForNominative: {
    v_t_2457 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2454, 0ULL, 2);
    v_t_2457 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2454);
  }
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 4);
  V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 0, 4);
  V v_t_2460 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2459, heff_dup(v_x_249)));
  V v_t_2465;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2461 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 3);
    v_t_2465 = v_n_2461;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2415, 0ULL, 1);
    v_t_2465 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_24cpr_str2);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_x_2467 = (g_heff_2eelab_2ememoed_2elam(v_t_2457, heff_get_n(v_e_241, 1, 6), v_t_2458, heff_rec_n(2, shape_stx__val, (V[]){v_t_2460, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam7, 1, 1, (V[]){v_x_249})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_2465, v_x_2453})));
  V f_ = v_k_2452;
  args[0] = v_x_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam5(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_c_2450 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_cod_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2450;
  args[0] = v_hd_2451;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam6, 1, 4, (V[]){v_e_241, v_x_249, v_cod_2415, v_k_2452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam3(V self, V *args) {
  V v_v_2424 = args[0];
  V v_scope_27_2425 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_cod_2415 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_implicit_2416 = heff_env(self)[3];
  V v_dom_2414 = heff_env(self)[4];
  V v_x_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT1 v_t_2426 = ({ V a_0 = v_c_240; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_c_240); r_; });
  {
    V v_field_2427 = v_t_2426.f[0];
    V v_x1_2433;
    switch (heff_tag_of(v_cod_2415)) {
    case TAG_MkClo: {
      V v_vs_2429 = heff_dup(heff_field(v_cod_2415, 1));
      V v_body_2430 = heff_dup(heff_field(v_cod_2415, 2));
      v_x1_2433 = heff_tr(heff_call(v_body_2430, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2429, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam4, 1, 1, (V[]){heff_dup(v_v_2424)})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2432 = heff_dup(heff_field(v_cod_2415, 0));
      v_x1_2433 = v_body_2432;
      break;
    }
    default: heff_nomatch(v_cod_2415);
    }
    V v_a_2437;
    switch (heff_tag_of(v_x1_2433)) {
    case TAG_Nom: {
      V v_x_2434 = heff_field(v_x1_2433, 0);
      heff_take_n(v_x1_2433, 1ULL, 1);
      v_a_2437 = v_x_2434;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2433, 0ULL, 1);
      v_a_2437 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2436 = heff_field(v_x1_2433, 0);
      heff_take_n(v_x1_2433, 1ULL, 1);
      v_a_2437 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_x1_2433);
    }
    V v_f_2438 = v_field_2427;
    V v_t_2439 = heff_dup(heff_rfield(v_e_241, 2));
    V v_t_2442;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_ForNominative: {
      v_t_2442 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2440 = heff_field(v_t_2439, 0);
      V v_sp_2441 = heff_field(v_t_2439, 1);
      V v_ru_24t_2439_24ForDescriptive = heff_take_reuse_n(v_t_2439, 3ULL, 2);
      v_t_2442 = heff_tag_at_n(v_ru_24t_2439_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2440, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2441, heff_dup(v_v_2424)})});
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    V v_t_2448;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      heff_drop(v_v_2424);
      heff_drop(v_dom_2414);
      v_t_2448 = heff_dup(heff_rfield(v_e_241, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2424);
      heff_drop(v_dom_2414);
      v_t_2448 = heff_dup(heff_rfield(v_e_241, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_2447;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2443 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2447 = v_n_2443;
        break;
      }
      case TAG_CloConst: {
        v_t_2447 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_24cpr_str1);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_2447, v_dom_2414, v_v_2424}), heff_dup(heff_rfield(v_e_241, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    V v_t_2449 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2425, heff_dup(heff_rfield(v_e_241, 1)), v_t_2442, heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), v_t_2448});
    V v_c_2450 = heff_tr(heff_call(v_f_2438, 2, (V[]){v_t_2449, v_a_2437}));
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam5, 2, 4, (V[]){v_c_2450, v_e_241, v_x_249, v_cod_2415});
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_249)));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2412 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2412;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_t_2410, 1);
    V v_cod_2415 = heff_field(v_t_2410, 2);
    V v_implicit_2416 = heff_field(v_t_2410, 3);
    heff_take_n(v_t_2410, 14ULL, 4);
    V v_t_2417;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      v_t_2417 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      heff_drop(v_implicit_2416);
      heff_drop(v_t_2417);
      switch (heff_tag_of(v_c_240)) {
      case TAG_MkChk: {
        V v_f_2418 = heff_field(v_c_240, 0);
        heff_take_n(v_c_240, 1ULL, 1);
        V f_ = v_f_2418;
        heff_room[0] = v_e_241;
        heff_room[1] = v_x_249;
        heff_room[2] = v_hd_243;
        heff_room[3] = v_k_244;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_c_240);
      }
    } else {
      heff_drop(v_t_2417);
      V v_t_2423;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2419 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2423 = v_n_2419;
        break;
      }
      case TAG_CloConst: {
        v_t_2423 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_24cpr_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_t_2468 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2423, heff_dup(v_dom_2414), heff_dup(heff_rfield(v_e_241, 0)), heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam3, 2, 6, (V[]){v_c_240, v_cod_2415, v_e_241, v_implicit_2416, v_dom_2414, v_x_249})));
      V f_ = v_t_2468;
      heff_room[0] = v_hd_243;
      heff_room[1] = v_k_244;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2410, 0ULL, 3);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2472 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2472;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2474 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2474;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeInt: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2475 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2475;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFloat: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2476 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2476;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeString: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2477 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2477;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeRune: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2478 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2478;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2480 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2480;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2482 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2482;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_NoRules: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2483 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2483;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a0_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam1, 1, 1, (V[]){v_a0_242})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam2, 1, 4, (V[]){v_c_240, v_e_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroAnn_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionIntroAnn(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(v_sp_240, v_x_241, v_dom_242, v_body_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_245});
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2efunctionIntroAnn(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str3, 1, "_");
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedGo_entry, 8, 0};

V g_heff_2eelab_2erules_2enamedGo(V v_sp_240, V v_x_241, V v_arg_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam0, 1, 1, (V[]){v_ty0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam1, 1, 7, (V[]){v_sp_240, v_x_241, v_hd_246, v_k_247, heff_dup(v_arg_242), v_e_243, v_m_244})});
}
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2enamedGo(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_ty0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_ty0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args) {
  V v_u_2431 = args[0];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  V v_x1_2432 = heff_tr(heff_call(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    return v_x_2433;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2432, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    return v_x_2435;
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_implicit_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_cod_2417 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2427;
  switch (heff_tag_of(v_implicit_2418)) {
  case TAG_Expl: {
    heff_drop(v_x_241);
    v_t_2427 = (g_heff_2eelab_2ememoed_2eapp(v_m_244, heff_dup(v_x_2426)));
    break;
  }
  case TAG_Impl: {
    v_t_2427 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2426)));
    break;
  }
  case TAG_Inst: {
    v_t_2427 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2426)));
    break;
  }
  default: heff_nomatch(v_implicit_2418);
  }
  V v_x1_2437;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2429 = heff_field(v_cod_2417, 1);
    V v_body_2430 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2437 = heff_tr(heff_call(v_body_2430, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2429, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam3, 1, 1, (V[]){v_x_2426})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2436 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2426, 2);
    v_x1_2437 = v_body_2436;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2441;
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nom: {
    V v_x_2438 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_t_2441 = v_x_2438;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2441 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2440 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_t_2441 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_x1_2437);
  }
  V v_x_2442 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_t_2441});
  V f_ = v_k_247;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args) {
  V v_u_2460 = args[0];
  V v_x_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2460);
  V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_x_2450, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_Nom: {
    V v_x_2462 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    return v_x_2462;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2464 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    return v_x_2464;
  }
  default: return heff_nomatch(v_x1_2461);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args) {
  V v_x_2450 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2455;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2451 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2455 = v_n_2451;
    break;
  }
  case TAG_CloConst: {
    v_t_2455 = ((V)&g_heff_2eelab_2erules_2enamedGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2456 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2455, v_m_244, heff_dup(v_x_2450)));
  V v_x1_2466;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2458 = heff_field(v_cod_2417, 1);
    V v_body_2459 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2466 = heff_tr(heff_call(v_body_2459, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2458, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam5, 1, 1, (V[]){v_x_2450})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2465 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2450, 2);
    v_x1_2466 = v_body_2465;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2470;
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_Nom: {
    V v_x_2467 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    v_t_2470 = v_x_2467;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2466, 0ULL, 1);
    v_t_2470 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2469 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    v_t_2470 = v_x_2469;
    break;
  }
  default: heff_nomatch(v_x1_2466);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2456; V a_5 = v_t_2470; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args) {
  V v_u_2487 = args[0];
  V v_x_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2487);
  V v_x1_2488 = heff_tr(heff_call(heff_get_n(v_x_2477, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2488)) {
  case TAG_Nom: {
    V v_x_2489 = heff_field(v_x1_2488, 0);
    heff_take_n(v_x1_2488, 1ULL, 1);
    return v_x_2489;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2488, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2491 = heff_field(v_x1_2488, 0);
    heff_take_n(v_x1_2488, 1ULL, 1);
    return v_x_2491;
  }
  default: return heff_nomatch(v_x1_2488);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args) {
  V v_x_2477 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2482;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2478 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2482 = v_n_2478;
    break;
  }
  case TAG_CloConst: {
    v_t_2482 = ((V)&g_heff_2eelab_2erules_2enamedGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2483 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2482, v_m_244, heff_dup(v_x_2477)));
  V v_x1_2493;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2485 = heff_field(v_cod_2417, 1);
    V v_body_2486 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2493 = heff_tr(heff_call(v_body_2486, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2485, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam7, 1, 1, (V[]){v_x_2477})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2492 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2477, 2);
    v_x1_2493 = v_body_2492;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2497;
  switch (heff_tag_of(v_x1_2493)) {
  case TAG_Nom: {
    V v_x_2494 = heff_field(v_x1_2493, 0);
    heff_take_n(v_x1_2493, 1ULL, 1);
    v_t_2497 = v_x_2494;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2493, 0ULL, 1);
    v_t_2497 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2496 = heff_field(v_x1_2493, 0);
    heff_take_n(v_x1_2493, 1ULL, 1);
    v_t_2497 = v_x_2496;
    break;
  }
  default: heff_nomatch(v_x1_2493);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2483; V a_5 = v_t_2497; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2413, 1);
    V v_cod_2417 = heff_field(v_t_2413, 2);
    V v_implicit_2418 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_cod_2417)) {
    case TAG_MkClo: {
      V v_n_2419 = heff_dup(heff_field(v_cod_2417, 0));
      v_t_2423 = heff_strEq_lent(v_n_2419, v_x_241, 1);
      break;
    }
    case TAG_CloConst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_cod_2417);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_sp_240);
      heff_drop(v_t_2423);
      V v_c_2425;
      switch (heff_tag_of(v_arg_242)) {
      case TAG_MkChk: {
        V v_f_2424 = heff_field(v_arg_242, 0);
        heff_take_n(v_arg_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_call(v_f_2424, 2, (V[]){v_e_243, v_dom_2416}));
        break;
      }
      default: heff_nomatch(v_arg_242);
      }
      V f_ = v_c_2425;
      heff_room[0] = v_hd_246;
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam2, 1, 5, (V[]){v_implicit_2418, v_m_244, v_x_241, v_cod_2417, v_k_247});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2423);
      V v_t_2443;
      switch (heff_tag_of(v_implicit_2418)) {
      case TAG_Expl: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      case TAG_Impl: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_Inst: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_implicit_2418);
      }
      if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
        heff_drop(v_implicit_2418);
        heff_drop(v_t_2443);
        V v_t_2448;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2444 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2448 = v_n_2444;
          break;
        }
        case TAG_CloConst: {
          v_t_2448 = ((V)&g_heff_2eelab_2erules_2enamedGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2449 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_243), heff_dup(v_sp_240), v_x_2412, v_dom_2416, v_t_2448));
        V f_ = v_c_2449;
        heff_room[0] = heff_dup(v_hd_246);
        heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam4, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_x_2412);
        heff_drop(v_t_2443);
        V v_t_2471;
        switch (heff_tag_of(v_implicit_2418)) {
        case TAG_Expl: {
          v_t_2471 = NTAG(TAG_False);
          break;
        }
        case TAG_Impl: {
          v_t_2471 = NTAG(TAG_False);
          break;
        }
        case TAG_Inst: {
          v_t_2471 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_implicit_2418);
        }
        if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
          heff_drop(v_t_2471);
          V v_t_2476;
          switch (heff_tag_of(v_cod_2417)) {
          case TAG_MkClo: {
            V v_n_2472 = heff_dup(heff_field(v_cod_2417, 0));
            v_t_2476 = v_n_2472;
            break;
          }
          case TAG_CloConst: {
            v_t_2476 = ((V)&g_heff_2eelab_2erules_2enamedGo_str2);
            break;
          }
          default: heff_nomatch(v_cod_2417);
          }
          return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_243), heff_dup(v_sp_240), v_dom_2416, v_t_2476, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam6, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247})));
        } else {
          heff_drop(v_arg_242);
          heff_drop(v_e_243);
          heff_drop(v_m_244);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          heff_drop(v_t_2471);
          return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
      }
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eelimGo_str0, 8, "argument");
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam20(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam21(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam19(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam23(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam24(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam22(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam26(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam27(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam25(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam29(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam30(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam28(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam32(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam33(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam31(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimGo_entry, 7, 0};

V g_heff_2eelab_2erules_2eelimGo(V v_checksOnly_240, V v_sp_241, V v_arg_242, V v_e_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_ecallee_247 = heff_field(v_x5_244, 0);
    V v_a_248 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_t_249 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_248)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_LikeU: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam0, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeFunction: {
      V v_dom_2418 = heff_field(v_t_249, 1);
      V v_cod_2419 = heff_field(v_t_249, 2);
      heff_take_n(v_t_249, 6ULL, 4);
      heff_drop(v_a_248);
      if ((heff_dup(v_checksOnly_240) == NTAG(TAG_True))) {
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam3, 1, 1, (V[]){heff_dup(v_dom_2418)})})});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2423}));
        return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2424, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam4, 1, 8, (V[]){v_e_243, v_ecallee_247, v_dom_2418, v_cod_2419, heff_dup(v_arg_242), v_z_245, v_z_246, v_sp_241})});
      } else {
        heff_drop(v_sp_241);
        return ({ V a_0 = v_e_243; V a_1 = v_ecallee_247; V a_2 = v_dom_2418; V a_3 = v_cod_2419; V a_4 = v_arg_242; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_cod_2419); r_; });
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_249, 0ULL, 3);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam7, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam10, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeInt: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam13, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeFloat: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam16, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeString: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam19, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeRune: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam22, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam25, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam28, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_NoRules: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam31, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eelimGo(a0, a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args) {
  V v_c_2412 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2412, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2416, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
    heff_drop(v_x_2411);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2411);
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam1, 1, 1, (V[]){v_a_248})})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2414}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam2, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args) {
  V v_c_2421 = args[0];
  V v_dom_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2421, 3, 8); V a_1 = v_dom_2418; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args) {
  V v_u_2453 = args[0];
  V v_x_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  V v_x1_2454 = heff_tr(heff_call(heff_get_n(v_x_2448, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_Nom: {
    V v_x_2455 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    return v_x_2455;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2454, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2457 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    return v_x_2457;
  }
  default: return heff_nomatch(v_x1_2454);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_ecallee_247 = heff_env(self)[0];
  V v_cod_2419 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2449 = (g_heff_2eelab_2ememoed_2eapp(v_ecallee_247, heff_dup(v_x_2448)));
  V v_x1_2459;
  switch (heff_tag_of(v_cod_2419)) {
  case TAG_MkClo: {
    V v_vs_2451 = heff_field(v_cod_2419, 1);
    V v_body_2452 = heff_field(v_cod_2419, 2);
    heff_take_n(v_cod_2419, 6ULL, 3);
    v_x1_2459 = heff_tr(heff_call(v_body_2452, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2451, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam6, 1, 1, (V[]){v_x_2448})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2458 = heff_field(v_cod_2419, 0);
    heff_take_n(v_cod_2419, 1ULL, 1);
    heff_drop_rec(v_x_2448, 2);
    v_x1_2459 = v_body_2458;
    break;
  }
  default: heff_nomatch(v_cod_2419);
  }
  V v_t_2463;
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_Nom: {
    V v_x_2460 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    v_t_2463 = v_x_2460;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2459, 0ULL, 1);
    v_t_2463 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2462 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    v_t_2463 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_x1_2459);
  }
  V v_x_2464 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2449, v_t_2463});
  V f_ = v_z_246;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_ecallee_247 = heff_env(self)[1];
  V v_dom_2418 = heff_env(self)[2];
  V v_cod_2419 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2447;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_VU: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2427 = heff_dup(heff_field(v_x_2425, 0));
    switch (heff_tag_of(v_t1_2427)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2427, 0ULL, 1);
      v_t_2447 = NTAG(TAG_True);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2427, 0ULL, 1);
      v_t_2447 = NTAG(TAG_True);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2427, 0ULL, 1);
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2447 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t1_2427);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VRecord: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VSum: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimString: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  case TAG_VFixed: {
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    heff_drop(v_sp_241);
    heff_drop(v_t_2447);
    return ({ V a_0 = v_e_243; V a_1 = v_ecallee_247; V a_2 = v_dom_2418; V a_3 = v_cod_2419; V a_4 = v_arg_242; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_cod_2419); heff_drop(v_arg_242); r_; });
  } else {
    heff_drop(v_dom_2418);
    heff_drop(v_t_2447);
    return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2eelimGo_str0); V a_3 = v_arg_242; V a_4 = heff_dup(v_x_2425); V a_5 = v_x_2425; V a_6 = v_z_245; V a_7 = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam5, 1, 3, (V[]){v_ecallee_247, v_cod_2419, v_z_246}); V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args) {
  V v_c_2469 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2469, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args) {
  V v_x_2473 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2473, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args) {
  V v_x_2468 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2468) == NTAG(TAG_True))) {
    heff_drop(v_x_2468);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2468);
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam8, 1, 1, (V[]){v_a_248})})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2471}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2472;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam9, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args) {
  V v_c_2476 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2476, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args) {
  V v_x_2480 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2480, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args) {
  V v_x_2475 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2475) == NTAG(TAG_True))) {
    heff_drop(v_x_2475);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2475);
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam11, 1, 1, (V[]){v_a_248})})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2478}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2479;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam12, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args) {
  V v_c_2482 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2482, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam15(V self, V *args) {
  V v_x_2486 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2486, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args) {
  V v_x_2481 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2481) == NTAG(TAG_True))) {
    heff_drop(v_x_2481);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2481);
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam14, 1, 1, (V[]){v_a_248})})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2484}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2485;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam15, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam17(V self, V *args) {
  V v_c_2488 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2488, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam18(V self, V *args) {
  V v_x_2492 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2492, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam16(V self, V *args) {
  V v_x_2487 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2487) == NTAG(TAG_True))) {
    heff_drop(v_x_2487);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2487);
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam17, 1, 1, (V[]){v_a_248})})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2490}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2491;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam18, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam20(V self, V *args) {
  V v_c_2494 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2494, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam21(V self, V *args) {
  V v_x_2498 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2498, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam19(V self, V *args) {
  V v_x_2493 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2493) == NTAG(TAG_True))) {
    heff_drop(v_x_2493);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2493);
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam20, 1, 1, (V[]){v_a_248})})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2496}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2497;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam21, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam23(V self, V *args) {
  V v_c_24100 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24100, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam24(V self, V *args) {
  V v_x_24104 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24104, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam22(V self, V *args) {
  V v_x_2499 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2499) == NTAG(TAG_True))) {
    heff_drop(v_x_2499);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2499);
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam23, 1, 1, (V[]){v_a_248})})});
    V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24102}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24103;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam24, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam26(V self, V *args) {
  V v_c_24107 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24107, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam27(V self, V *args) {
  V v_x_24111 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24111, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam25(V self, V *args) {
  V v_x_24106 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24106) == NTAG(TAG_True))) {
    heff_drop(v_x_24106);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24106);
    V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam26, 1, 1, (V[]){v_a_248})})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24109}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24110;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam27, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam29(V self, V *args) {
  V v_c_24114 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24114, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam30(V self, V *args) {
  V v_x_24118 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24118, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam28(V self, V *args) {
  V v_x_24113 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24113) == NTAG(TAG_True))) {
    heff_drop(v_x_24113);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24113);
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam29, 1, 1, (V[]){v_a_248})})});
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
    V v_t_24117 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24116}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24117;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam30, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam32(V self, V *args) {
  V v_c_24120 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24120, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam33(V self, V *args) {
  V v_x_24124 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24124, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam31(V self, V *args) {
  V v_x_24119 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24119) == NTAG(TAG_True))) {
    heff_drop(v_x_24119);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24119);
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam32, 1, 1, (V[]){v_a_248})})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24122}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24123;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam33, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimString_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimString_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimString_st;
static V g_heff_2eelab_2erules_2eprimString_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimString_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimString_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimString_st)) return g_heff_2eelab_2erules_2eprimString_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimString_val, &g_heff_2eelab_2erules_2eprimString_st, g_heff_2eelab_2erules_2eprimString_init);
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2elitBytes_str0, 13, "prelude.Bytes");
HEFF_LIT(g_heff_2eelab_2erules_2elitBytes_str1, 64, "a binary is of the prelude's `Bytes`, which is not in scope here");
V g_heff_2eelab_2erules_2elitBytes_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2elitBytes_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitBytes_lam1, 1, 0};
V g_heff_2eelab_2erules_2elitBytes_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elitBytes_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elitBytes_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elitBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitBytes_entry, 2, 0};

V g_heff_2eelab_2erules_2elitBytes(V v_sp_240, V v_s_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitBytes_lam0, 1, 2, (V[]){v_s_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2elitBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elitBytes(a[0], a[1]);
}
V g_heff_2eelab_2erules_2elitBytes_lam1(V self, V *args) {
  V v_u_249 = args[0];
  heff_drop(v_u_249);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2elitBytes_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elitBytes_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2elitBytes_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_2415, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2415, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elitBytes_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_get_n(v_e_242, 1, 6), 1, 7);
  HeffT2 v_t_244 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2elitBytes_str0); V a_1 = v_t_243; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_sp_240);
      V v_e_248 = v_field_246;
      V v_t_2410 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_s_241}), ((V)&g_heff_2eelab_2erules_2elitBytes_lam1_clo)});
      V v_t_2411 = (g_heff_2eelab_2evalue_2edecodeN(heff_get_n(v_e_248, 2, 4)));
      V v_x_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2411});
      return heff_clo_n(g_heff_2eelab_2erules_2elitBytes_lam2, 2, 1, (V[]){v_x_2412});
    } else {
      heff_drop(v_s_241);
      heff_drop(v_field_246);
      return heff_clo_n(g_heff_2eelab_2erules_2elitBytes_lam3, 2, 1, (V[]){v_sp_240});
    }
  }
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam3, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitDefault(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    HeffT1 v_t_2413 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam0, 3, 1, (V[]){v_i_246})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_f_2415 = v_field_2414;
      return heff_tail(v_f_2415, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
  }
  case TAG_FracNum: {
    V v_x_2416 = heff_tget_v(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    HeffT1 v_t_2423 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam2, 3, 1, (V[]){v_x_2416})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_f_2425 = v_field_2424;
      return heff_tail(v_f_2425, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitDefault(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  V v_i_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_247);
  heff_drop(v_hd_248);
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam1_clo)});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, NTAG(TAG_VPrimInt)});
  V f_ = v_k_249;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args) {
  V v_e_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2417);
  heff_drop(v_hd_2418);
  V v_t_2421 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2416))}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam3_clo)});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, NTAG(TAG_VPrimFloat)});
  V f_ = v_k_2419;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitWait_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitWait_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_entry, 3, 0};

V g_heff_2eelab_2erules_2enumLitWait(V v_n_240, V v_sp_241, V v_lit_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam0, 4, 3, (V[]){v_sp_241, v_lit_242, v_n_240})});
}
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitWait(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_n_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2433;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2413 = heff_dup(heff_field(v_x_2411, 0));
    switch (heff_tag_of(v_t1_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t1_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_n_240);
    heff_drop(v_t_2433);
    return (g_heff_2eelab_2erules_2enumLitAt(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
  } else {
    heff_drop(v_t_2433);
    if ((((int64_t)0ULL) < heff_peek_word(v_n_240))) {
      switch (heff_tag_of(v_lit_242)) {
      case TAG_IntNum: {
        V v_c_2436 = (g_heff_2eelab_2erules_2enumLitWait(heff_box_word((heff_unbox_word(v_n_240) - ((int64_t)1ULL))), heff_dup(v_sp_241), v_lit_242));
        return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2enumLitWait_str0); V a_3 = v_c_2436; V a_4 = heff_dup(v_x_2411); V a_5 = v_x_2411; V a_6 = v_hd_245; V a_7 = v_k_246; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2436); r_; });
      }
      case TAG_FracNum: {
        heff_drop(v_n_240);
        return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
      }
      default: return heff_nomatch(v_lit_242);
      }
    } else {
      heff_drop(v_n_240);
      return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
    }
  }
}
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_241 = heff_env(self)[0];
  V v_lit_242 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam2, 1, 6, (V[]){v_sp_241, v_e_243, v_lit_242, v_hd_245, v_k_246, v_n_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordFormation_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordFormation_entry, 1, 0};

V g_heff_2eelab_2erules_2erecordFormation(V v_fieldTyps_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam0, 1, 1, (V[]){v_fieldTyps_240})});
}
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordFormation(a[0]);
}
V g_heff_2eelab_2erules_2erecordFormation_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = (g_heff_2eelab_2erules_2erecordOf(v_e_241, v_x_249));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam2, 1, 2, (V[]){v_e_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_fieldTyps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sd_242 = heff_dup(heff_rfield(v_e_241, 0));
  V v_t_243 = heff_tag_n(TAG_CUndelay, 1, (V[]){heff_take_field(v_sd_242, 3)});
  V v_t_244 = ({ V rv_3 = v_t_243; V rr_ = heff_rec_reuse_nf(v_sd_242, 7ULL, 4, shape_len__names__locals__ctx, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_245 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_t_244, heff_dup(heff_rfield(v_e_241, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), heff_dup(heff_rfield(v_e_241, 5))});
  V v_c_246 = (g_heff_2eelab_2erules_2eformGo(v_t_245, MK_INT(0LL), v_fieldTyps_240));
  return heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam1, 2, 2, (V[]){v_c_246, v_e_241});
}
Clo g_heff_2eelab_2erules_2eappendP_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eappendP_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2erules_2eplacesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesGo_entry, 2, 0};

V g_heff_2eelab_2erules_2eplacesGo(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if ((heff_dup(v_b_242) == NTAG(TAG_True))) {
      heff_drop(v_b_242);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_241)}), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2eplacesGo_24dps(v_rest_243, heff_box_word((heff_unbox_word(v_k_241) + ((int64_t)1ULL))), heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_b_242);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2erules_2eplacesGo_24dps(v_rest_243, v_k_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eplacesGo(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldIdxs_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2efieldIdxs_24dps(V v_at_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){MK_INT(0LL), heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_at_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_245;
      v_at_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_p_247 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      V v_t_248 = heff_intSub(heff_intSub(heff_dup(v_at_240), MK_INT(1LL)), v_p_247);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_at_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_249;
      v_at_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldIdxs_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumIntro_str0, 3, "tag");
V g_heff_2eelab_2erules_2esumIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntro_entry, 4, 0};

V g_heff_2eelab_2erules_2esumIntro(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam0, 4, 4, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243})});
}
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumIntro(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2esumIntro_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntro_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2434;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_VU: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2414 = heff_dup(heff_field(v_x_2412, 0));
    switch (heff_tag_of(v_t1_2414)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2414);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_t_2434);
    V v_t_2435 = (g_heff_2eelab_2erules_2esumIntroNow(heff_dup(v_sp_240), v_tsp_241, v_x_242, v_cs_243));
    return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumIntro_str0); V a_3 = v_t_2435; V a_4 = heff_dup(v_x_2412); V a_5 = v_x_2412; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2435); r_; });
  } else {
    heff_drop(v_t_2434);
    HeffT1 v_t_2436 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_240, v_tsp_241, v_x_242, v_cs_243));
    {
      V v_field_2437 = v_t_2436.f[0];
      V v_f_2438 = v_field_2437;
      V f_ = v_f_2438;
      heff_room[0] = v_e_244;
      heff_room[1] = v_x_2412;
      heff_room[2] = v_hd_246;
      heff_room[3] = v_k_247;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
  }
}
V g_heff_2eelab_2erules_2esumIntro_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam2, 1, 7, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243, v_e_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdateSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_entry, 8, 0};

V g_heff_2eelab_2erules_2eupdateSetting(V v_upd_240, V v_e_241, V v_sp_242, V v_r_243, V v_g_244, V v_a_245, V v_fs_246, V v_x_247) {
top: ;
  V v_it_248 = (g_list_2efilter_24s1966236437x1225976932(heff_dup(v_x_247), heff_dup(v_fs_246)));
  switch (heff_tag_of(v_it_248)) {
  case TAG_Nil: {
    heff_drop(v_upd_240);
    heff_drop(v_e_241);
    heff_drop(v_fs_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam0, 2, 5, (V[]){v_x_247, v_sp_242, v_r_243, v_g_244, v_a_245});
  }
  case TAG_Cons: {
    V v_it1_2420 = heff_field(v_it_248, 0);
    V v_it2_2421 = heff_field(v_it_248, 1);
    heff_take_n(v_it_248, 3ULL, 2);
    heff_drop(v_sp_242);
    switch (heff_tag_of(v_it1_2420)) {
    case TAG_UpdateTo: {
      V v_xsp_2423 = heff_field(v_it1_2420, 1);
      V v_fsp_2424 = heff_field(v_it1_2420, 2);
      V v_c_2425 = heff_field(v_it1_2420, 3);
      heff_take_n(v_it1_2420, 14ULL, 4);
      heff_drop(v_upd_240);
      heff_drop(v_e_241);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_a_245);
      switch (heff_tag_of(v_it2_2421)) {
      case TAG_Nil: {
        heff_drop(v_fs_246);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam4, 2, 4, (V[]){v_x_247, v_c_2425, v_fsp_2424, v_xsp_2423});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_2421, 0ULL, 2);
        heff_drop(v_xsp_2423);
        heff_drop(v_fsp_2424);
        heff_drop(v_c_2425);
        return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
      }
      default: return heff_nomatch(v_it2_2421);
      }
    }
    case TAG_UpdateIn: {
      V v_xsp_2431 = heff_field(v_it1_2420, 1);
      V v_fsp_2432 = heff_field(v_it1_2420, 2);
      V v_inner_2433 = heff_field(v_it1_2420, 3);
      heff_take_n(v_it1_2420, 14ULL, 4);
      HeffT2 v_t_2434 = (g_heff_2eelab_2erules_2eupdateInner_24cpr(v_it2_2421));
      {
        V v_field_2436 = v_t_2434.f[1];
        int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
        if ((v_tag_2435 == ((int64_t)0ULL))) {
          heff_drop(v_fs_246);
          V v_rest_2438 = v_field_2436;
          V v_c_2439 = heff_tr(g_heff_2eelab_2erules_2erecordNameOf(v_e_241, heff_dup(v_a_245), heff_dup(v_x_247), v_xsp_2431));
          return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam5, 2, 9, (V[]){v_c_2439, v_inner_2433, v_rest_2438, v_upd_240, v_fsp_2432, v_r_243, v_g_244, v_a_245, v_x_247});
        } else {
          heff_drop(v_upd_240);
          heff_drop(v_e_241);
          heff_drop(v_r_243);
          heff_drop(v_g_244);
          heff_drop(v_a_245);
          heff_drop(v_xsp_2431);
          heff_drop(v_fsp_2432);
          heff_drop(v_inner_2433);
          heff_drop(v_field_2436);
          return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
        }
      }
    }
    default: return heff_nomatch(v_it1_2420);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdateSetting(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_e_2411 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_fty_2412 = heff_env(self)[3];
  V v_hd_2414 = heff_env(self)[4];
  V v_k_2415 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_m_2417 = heff_field(v_x_2416, 0);
    V v_t_2418 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    return (g_heff_2eelab_2erules_2esameField(v_sp_242, v_e_2411, v_x_247, v_fty_2412, v_m_2417, v_t_2418, v_hd_2414, v_k_2415));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_e_2411 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_fty_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam3, 1, 6, (V[]){v_sp_242, v_e_2411, v_x_247, v_fty_2412, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args) {
  V v_e_2411 = args[0];
  V v_fty_2412 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  V v_g_244 = heff_env(self)[2];
  V v_a_245 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2413 = (g_heff_2eelab_2erules_2eupdatedField(heff_dup(v_sp_242), heff_dup(v_e_2411), v_r_243, v_g_244, v_a_245, heff_dup(v_x_247)));
  return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam2, 2, 5, (V[]){v_c_2413, v_sp_242, v_e_2411, v_x_247, v_fty_2412});
}
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_r_243 = heff_env(self)[2];
  V v_g_244 = heff_env(self)[3];
  V v_a_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_hd_249);
  V v_t_2419 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){heff_dup(v_x_247), heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam1, 2, 5, (V[]){heff_dup(v_sp_242), v_r_243, v_g_244, v_a_245, v_x_247})}), v_sp_242, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2410;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_c_2425 = heff_env(self)[1];
  V v_fsp_2424 = heff_env(self)[2];
  V v_xsp_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, v_c_2425, v_fsp_2424, v_xsp_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_inner_2433 = heff_env(self)[0];
  V v_rest_2438 = heff_env(self)[1];
  V v_upd_240 = heff_env(self)[2];
  V v_fsp_2432 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_a_245 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_k_2441 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2442);
  V v_t_2443 = (g_heff_2eelab_2erules_2eappendP(v_inner_2433, v_rest_2438));
  V v_t_2444 = (g_heff_2eelab_2erules_2enestedField(v_upd_240, heff_dup(v_fsp_2432), v_r_243, v_g_244, v_a_245, heff_dup(v_x_247), v_t_2443));
  V v_x_2445 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, v_t_2444, v_fsp_2432, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2441;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  V v_inner_2433 = heff_env(self)[1];
  V v_rest_2438 = heff_env(self)[2];
  V v_upd_240 = heff_env(self)[3];
  V v_fsp_2432 = heff_env(self)[4];
  V v_r_243 = heff_env(self)[5];
  V v_g_244 = heff_env(self)[6];
  V v_a_245 = heff_env(self)[7];
  V v_x_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2439;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam6, 1, 9, (V[]){v_inner_2433, v_rest_2438, v_upd_240, v_fsp_2432, v_r_243, v_g_244, v_a_245, v_x_247, v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordUpdate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordUpdate_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordUpdate(V v_sp_240, V v_s_241, V v_r_242, V v_fs_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_r_242, v_fs_243})});
}
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordUpdate(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordUpdate_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_a_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_a_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_r_242 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_fs_243 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_g_2417 = heff_field(v_x_2416, 0);
    V v_a_2418 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    return (g_heff_2eelab_2erules_2eupdateOf(v_sp_240, v_r_242, v_e_244, v_g_2417, heff_dup(v_a_2418), v_fs_243, v_hd_247, heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam4, 1, 2, (V[]){v_k_248, v_a_2418})));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2erecordUpdate_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_fs_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_dup(heff_field(v_x_249, 0));
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_y_2414 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 2ULL, 2);
    v_t_2415 = v_y_2414;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_240), v_t_2412, v_t_2415, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam3, 1, 6, (V[]){v_sp_240, v_r_242, v_e_244, v_fs_243, v_hd_247, v_k_248})));
}
V g_heff_2eelab_2erules_2erecordUpdate_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_fs_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam2, 1, 6, (V[]){v_e_244, v_sp_240, v_hd_247, v_r_242, v_fs_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  V v_fs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_240, v_r_242, v_fs_243});
}