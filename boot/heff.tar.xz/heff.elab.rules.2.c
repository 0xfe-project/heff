// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940 61712
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135 24780
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Record 39342
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_depth 296830685
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_hole 9703815
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_places 961367927
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_v 336
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_wantedBy 1134124532
#define LBL_witness 1587180415
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_depth__wantedBy[] = {LBL_depth, LBL_wantedBy};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_name__goal[] = {LBL_name, LBL_goal};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eenvironment_2ecanGuess(V, V);
V g_heff_2eelab_2eenvironment_2ecanGuess_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ecanGuess_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2eglobals_2eplacesSaid(V);
V g_heff_2eelab_2eglobals_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eplacesSaid_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimString_get(void);
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eanyIdxGo(V, V, V);
V g_heff_2eelab_2erules_2eanyIdxGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyIdxGo_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672(V, V);
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_clo;
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2echeckSettings(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckSettings_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSettings_clo;
V g_heff_2eelab_2erules_2ecommitted(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecommitted_clo;
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
V g_heff_2eelab_2erules_2edelayLambda(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayLambda_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayLambda_clo;
V g_heff_2eelab_2erules_2eeachSubgoal(V, V);
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeachSubgoal_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
V g_heff_2eelab_2erules_2eelimPlain(V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimPlain_clo;
V g_heff_2eelab_2erules_2eeqTyStr(V, V, V);
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqTyStr_clo;
V g_heff_2eelab_2erules_2efieldIdxs_24dps(V, V, V);
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo;
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
HeffT1 g_heff_2eelab_2erules_2efindOr_24cpr(V, V, V);
V g_heff_2eelab_2erules_2efits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efits_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V);
HeffT2 g_heff_2eelab_2erules_2eindexOfName_24cpr(V, V, V);
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2einstLocals(V);
V g_heff_2eelab_2erules_2einstLocals_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstLocals_clo;
V g_heff_2eelab_2erules_2eisEvidence(V, V);
V g_heff_2eelab_2erules_2eisEvidence_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eisEvidence_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V, V, V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2emetaOf(V);
V g_heff_2eelab_2erules_2emetaOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOf_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo;
V g_heff_2eelab_2erules_2enotAFunction(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotAFunction_clo;
HeffT1 g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_clo;
V g_heff_2eelab_2erules_2eplacesGo(V, V);
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_clo;
V g_heff_2eelab_2erules_2eplacesGo_24dps(V, V, V);
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo;
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2esumFormation_24map0(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map0_clo;
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2erules_2eunspecForced(V);
V g_heff_2eelab_2erules_2eunspecForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunspecForced_clo;
HeffT3 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewitnessMatches(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewitnessMatches_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edecodeNeuOf(V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_clo;
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_clo;
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eimplicitDefault(V);
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2especializations(V, V);
V g_heff_2eelab_2evalue_2especializations_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especializations_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s170737852x2114895588(V, V, V);
V g_list_2emap_24s170737852x2114895588_entry(V self, V *a);
extern Clo g_list_2emap_24s170737852x2114895588_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str5, 0, "");
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam4(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry, 5, 0};

V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V v_tag_240, V v_d_241, V v_t_242, V v_d_243, V v_t_244) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940: {
    top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940: ;
    switch (heff_tag_of(v_t_242)) {
    case TAG_SLocal: {
      V v_i_245 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      V v_ret_24bool = heff_bool(heff_intLe_c_lent(v_d_241, v_i_245, 0));
      heff_drop(v_d_241);
      heff_drop(v_i_245);
      return v_ret_24bool;
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      V v_a_247 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str0);
      V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str1);
      V t_3 = v_d_241;
      V t_4 = v_a_247;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SApp: {
      V v_f_248 = heff_field(v_t_242, 0);
      V v_a_249 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_241), v_f_248));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_d_243);
        heff_drop(v_t_244);
        heff_drop(v_a_249);
        heff_drop(v_t_2410);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2410);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
        V t_1 = v_d_241;
        V t_2 = v_a_249;
        V t_3 = v_d_243;
        V t_4 = v_t_244;
        v_tag_240 = t_0;
        v_d_241 = t_1;
        v_t_242 = t_2;
        v_d_243 = t_3;
        v_t_244 = t_4;
        goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
      }
    }
    case TAG_SLam: {
      V v_dd_2411 = heff_field(v_t_242, 0);
      V v_t2_2412 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      switch (heff_tag_of(v_t2_2412)) {
      case TAG_MkAbs: {
        V v_b_2414 = heff_field(v_t2_2412, 1);
        heff_take_n(v_t2_2412, 2ULL, 2);
        V v_t_2415 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2411));
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_d_243);
          heff_drop(v_t_244);
          heff_drop(v_b_2414);
          heff_drop(v_t_2415);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2415);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = heff_intAdd(v_d_241, MK_INT(1LL));
          V t_2 = v_b_2414;
          V t_3 = v_d_243;
          V t_4 = v_t_244;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      case TAG_AbsConst: {
        V v_b_2416 = heff_field(v_t2_2412, 0);
        heff_take_n(v_t2_2412, 1ULL, 1);
        V v_t_2417 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2411));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_d_243);
          heff_drop(v_t_244);
          heff_drop(v_b_2416);
          heff_drop(v_t_2417);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2417);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = v_d_241;
          V t_2 = v_b_2416;
          V t_3 = v_d_243;
          V t_4 = v_t_244;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      default: return heff_nomatch(v_t2_2412);
      }
    }
    case TAG_SCons: {
      V v_dct_2418 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      V v_keys_2419 = heff_take_field(v_dct_2418, 0);
      V v_values_2420 = heff_get_n(v_dct_2418, 2, 3);
      V v_t_2421 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2419), heff_arrayToList(v_values_2420)));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam0, 1, 1, (V[]){v_d_241}); V a_1 = v_t_2421; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2421); r_; });
    }
    case TAG_SProj: {
      V v_e_2425 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2425;
      V t_3 = v_d_243;
      V t_4 = v_t_244;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_STag: {
      V v_argv_2428 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam1, 1, 1, (V[]){v_d_241}); V b_1 = heff_arrayToList(v_argv_2428); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
    }
    case TAG_SMatch: {
      V v_e_2430 = heff_field(v_t_242, 0);
      V v_cs_2431 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      V v_keys_2432 = heff_take_field(v_cs_2431, 0);
      V v_values_2433 = heff_get_n(v_cs_2431, 2, 3);
      V v_t_2434 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_241), v_e_2430));
      if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_keys_2432);
        heff_drop(v_values_2433);
        heff_drop(v_t_2434);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2434);
        V v_t_2435 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2432), heff_arrayToList(v_values_2433)));
        return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam2, 1, 1, (V[]){v_d_241}); V a_1 = v_t_2435; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2435); r_; });
      }
    }
    case TAG_SSpecialize: {
      V v_e_2442 = heff_field(v_t_242, 0);
      V v_v_2444 = heff_field(v_t_242, 2);
      heff_take_n(v_t_242, 5ULL, 3);
      V v_t_2445 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_241), v_e_2442));
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_d_241);
        heff_drop(v_d_243);
        heff_drop(v_t_244);
        heff_drop(v_v_2444);
        heff_drop(v_t_2445);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2445);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
        V t_1 = v_d_241;
        V t_2 = v_v_2444;
        V t_3 = v_d_243;
        V t_4 = v_t_244;
        v_tag_240 = t_0;
        v_d_241 = t_1;
        v_t_242 = t_2;
        v_d_243 = t_3;
        v_t_244 = t_4;
        goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
      }
    }
    case TAG_SIs: {
      V v_e_2446 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2446;
      V t_3 = v_d_243;
      V t_4 = v_t_244;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SOpaque: {
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      V v_e_2447 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2447;
      V t_3 = v_d_243;
      V t_4 = v_t_244;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SFix: {
      V v_dd_2448 = heff_field(v_t_242, 0);
      V v_t2_2449 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      switch (heff_tag_of(v_t2_2449)) {
      case TAG_MkAbs: {
        V v_b_2451 = heff_field(v_t2_2449, 1);
        heff_take_n(v_t2_2449, 2ULL, 2);
        V v_t_2452 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2448));
        if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_d_243);
          heff_drop(v_t_244);
          heff_drop(v_b_2451);
          heff_drop(v_t_2452);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2452);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = heff_intAdd(v_d_241, MK_INT(1LL));
          V t_2 = v_b_2451;
          V t_3 = v_d_243;
          V t_4 = v_t_244;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      case TAG_AbsConst: {
        V v_b_2453 = heff_field(v_t2_2449, 0);
        heff_take_n(v_t2_2449, 1ULL, 1);
        V v_t_2454 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_241), v_dd_2448));
        if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_d_243);
          heff_drop(v_t_244);
          heff_drop(v_b_2453);
          heff_drop(v_t_2454);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2454);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
          V t_1 = v_d_241;
          V t_2 = v_b_2453;
          V t_3 = v_d_243;
          V t_4 = v_t_244;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
        }
      }
      default: return heff_nomatch(v_t2_2449);
      }
    }
    case TAG_SImplicit: {
      V v_e_2456 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_241;
      V t_2 = v_e_2456;
      V t_3 = v_d_243;
      V t_4 = v_t_244;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SPrim: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      V v_ty_2460 = heff_field(v_t_242, 2);
      heff_take_n(v_t_242, 4ULL, 3);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str2);
      V t_2 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str3);
      V t_3 = v_d_241;
      V t_4 = v_ty_2460;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_t_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_d_243);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135: {
    top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135: ;
    switch (heff_tag_of(v_t_244)) {
    case TAG_SU: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      V v_e_2470 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940);
      V t_1 = v_d_243;
      V t_2 = v_e_2470;
      V t_3 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str4);
      V t_4 = ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_str5);
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940;
    }
    case TAG_SFunction: {
      V v_dom_2472 = heff_field(v_t_244, 1);
      V v_t3_2473 = heff_field(v_t_244, 2);
      heff_take_n(v_t_244, 6ULL, 5);
      switch (heff_tag_of(v_t3_2473)) {
      case TAG_MkAbs: {
        V v_b_2477 = heff_field(v_t3_2473, 1);
        heff_take_n(v_t3_2473, 2ULL, 2);
        V v_t_2478 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_243), v_dom_2472));
        if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_t_242);
          heff_drop(v_d_243);
          heff_drop(v_b_2477);
          heff_drop(v_t_2478);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2478);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
          V t_1 = v_d_241;
          V t_2 = v_t_242;
          V t_3 = heff_intAdd(v_d_243, MK_INT(1LL));
          V t_4 = v_b_2477;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
        }
      }
      case TAG_AbsConst: {
        V v_b_2479 = heff_field(v_t3_2473, 0);
        heff_take_n(v_t3_2473, 1ULL, 1);
        V v_t_2480 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_243), v_dom_2472));
        if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_t_242);
          heff_drop(v_d_243);
          heff_drop(v_b_2479);
          heff_drop(v_t_2480);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2480);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
          V t_1 = v_d_241;
          V t_2 = v_t_242;
          V t_3 = v_d_243;
          V t_4 = v_b_2479;
          v_tag_240 = t_0;
          v_d_241 = t_1;
          v_t_242 = t_2;
          v_d_243 = t_3;
          v_t_244 = t_4;
          goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
        }
      }
      default: return heff_nomatch(v_t3_2473);
      }
    }
    case TAG_SRecord: {
      V v_ft_2482 = heff_field(v_t_244, 1);
      heff_take_n(v_t_244, 2ULL, 3);
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      V v_t_2484 = heff_arrayToList(heff_get_n(v_ft_2482, 2, 3));
      return ({ V a_0 = MK_INT(0LL); V a_1 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam3, 2, 1, (V[]){v_d_243}); V a_2 = v_t_2484; V r_ = (g_heff_2eelab_2erules_2eanyIdxGo(a_0, a_1, a_2)); heff_drop(v_t_2484); r_; });
    }
    case TAG_SSum: {
      V v_vs_2487 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      V v_keys_2488 = heff_take_field(v_vs_2487, 0);
      V v_values_2489 = heff_get_n(v_vs_2487, 2, 3);
      V v_t_2490 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2488), heff_arrayToList(v_values_2489)));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam4, 1, 1, (V[]){v_d_243}); V a_1 = v_t_2490; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2490); r_; });
    }
    case TAG_SIsTy: {
      V v_a_2495 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = v_d_241;
      V t_2 = v_t_242;
      V t_3 = v_d_243;
      V t_4 = v_a_2495;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SPrimInt: {
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      V v_a_2496 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135);
      V t_1 = v_d_241;
      V t_2 = v_t_242;
      V t_3 = v_d_243;
      V t_4 = v_a_2496;
      v_tag_240 = t_0;
      v_d_241 = t_1;
      v_t_242 = t_2;
      v_d_243 = t_3;
      v_t_244 = t_4;
      goto top_TAG_Enter_24heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135;
    }
    case TAG_SFixed: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_t_242);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam0(V self, V *args) {
  V v_x3_2422 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2422)) {
  case TAG_MkPair: {
    V v_v_2424 = heff_field(v_x3_2422, 1);
    heff_take_n(v_x3_2422, 2ULL, 2);
    return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_d_241, v_v_2424));
  }
  default: return heff_nomatch(v_x3_2422);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam1(V self, V *args) {
  V v_t_2429 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_d_241, v_t_2429));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam2(V self, V *args) {
  V v_x3_2436 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2436)) {
  case TAG_MkPair: {
    V v_x32_2438 = heff_field(v_x3_2436, 1);
    heff_take_n(v_x3_2436, 2ULL, 2);
    switch (heff_tag_of(v_x32_2438)) {
    case TAG_MkPair: {
      V v_xs_2439 = heff_field(v_x32_2438, 0);
      V v_b_2440 = heff_field(v_x32_2438, 1);
      heff_take_n(v_x32_2438, 3ULL, 2);
      V v_t_2441 = heff_intAdd(v_d_241, heff_arrayLength(v_xs_2439));
      return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_t_2441, v_b_2440));
    }
    default: return heff_nomatch(v_x32_2438);
    }
  }
  default: return heff_nomatch(v_x3_2436);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam3(V self, V *args) {
  V v_i_2485 = args[0];
  V v_ty_2486 = args[1];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_intAdd(v_d_243, v_i_2485), v_ty_2486));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam5(V self, V *args) {
  V v_t_2494 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(v_d_243, v_t_2494));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam4(V self, V *args) {
  V v_x3_2491 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2491)) {
  case TAG_MkPair: {
    V v_args_2493 = heff_field(v_x3_2491, 1);
    heff_take_n(v_x3_2491, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_lam5, 1, 1, (V[]){v_d_243}); V b_1 = heff_arrayToList(v_args_2493); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_x3_2491);
  }
}
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqTyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqTyStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqTyStr(V v_g_240, V v_cs_241, V v_t_242) {
top: ;
  V v_len_243 = heff_take_field(v_cs_241, 0);
  V v_names_244 = heff_get_n(v_cs_241, 1, 2);
  V v_t_2424;
  switch (heff_tag_of(v_t_242)) {
  case TAG_VU: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2416 = heff_dup(heff_field(v_t_242, 5));
    v_t_2424 = v_folded_2416;
    break;
  }
  case TAG_VRecord: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_2425 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(v_len_243, v_t_242, v_t_2424));
  V v_t_2433 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqTyStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_t_2434 = heff_tr(heff_call(heff_get_n(v_t_2433, 1, 2), 1, (V[]){v_t_2425}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_names_244; V a_3 = v_t_2434; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2434); r_; });
}
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqTyStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2427 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2426)));
  V v_t_2428 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_x_2426; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2428); heff_drop(v_x_2426); r_; });
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      heff_drop(v_d_2427);
      V v_x_2432 = v_field_2431;
      return v_x_2432;
    } else {
      heff_drop(v_field_2431);
      return v_d_2427;
    }
  }
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitArg_entry, 5, 0};

V g_heff_2eelab_2erules_2eimplicitArg(V v_e_240, V v_sp_241, V v_ty_242, V v_dom_243, V v_x_244) {
top: ;
  V v_scope_245 = heff_take_field(v_e_240, 0);
  V v_globals_246 = heff_get_n(v_e_240, 1, 6);
  V v_t_247 = (g_heff_2eelab_2evalue_2eimplicitDefault(v_ty_242));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_globals_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam0, 2, 4, (V[]){v_scope_245, v_dom_243, v_x_244, v_sp_241});
  }
  case TAG_Just: {
    V v_d_2413 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_sp_241);
    heff_drop(v_dom_243);
    heff_drop(v_x_244);
    heff_drop_rec(v_scope_245, 5);
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam3, 2, 2, (V[]){v_d_2413, v_globals_246});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitArg(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam2, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_nf(v_x_2410, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_249;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_scope_245 = heff_env(self)[0];
  V v_dom_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = heff_dup(heff_rfield(v_scope_245, 0)); V b_1 = heff_get_n(v_scope_245, 2, 5); V a_2 = v_dom_243; V a_3 = v_x_244; V a_4 = v_sp_241; V a_5 = v_hd_248; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam1, 1, 1, (V[]){v_k_249}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args) {
  V v_u_2416 = args[0];
  V v_globals_246 = heff_env(self)[0];
  V v_d_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_globals_246, NTAG(TAG_N), v_d_2413, NTAG(TAG_LNil)));
}
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  V v_globals_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_2413), heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam4, 1, 2, (V[]){v_globals_246, v_d_2413})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2einstLocals_str0, 20, "an instance argument");
V g_heff_2eelab_2erules_2einstLocals_lam1(V self, V *args);
V g_heff_2eelab_2erules_2einstLocals_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einstLocals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstLocals_entry, 1, 0};

V g_heff_2eelab_2erules_2einstLocals(V v_e_240) {
top: ;
  V v_scope_241 = heff_take_field(v_e_240, 0);
  V v_insts_242 = heff_get_n(v_e_240, 5, 6);
  return (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2einstLocals_lam0, 1, 1, (V[]){v_scope_241}), v_insts_242));
}
V g_heff_2eelab_2erules_2einstLocals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstLocals(a[0]);
}
V g_heff_2eelab_2erules_2einstLocals_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_name_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_name_246;
}
V g_heff_2eelab_2erules_2einstLocals_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_scope_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ty_244 = heff_take_field(v_c_243, 1);
  V v_v_245 = heff_take_field(v_c_243, 2);
  V v_name_246 = heff_get_n(v_c_243, 0, 3);
  V v_ty_247 = v_ty_244;
  V v_stx_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_get_n(v_scope_241, 0, 5), heff_dup(v_v_245)));
  V v_val_249 = v_v_245;
  return heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einstLocals_lam1, 1, 1, (V[]){v_name_246}), ((V)&g_heff_2eelab_2erules_2einstLocals_str0), NTAG(TAG_False), v_ty_247, v_stx_248, v_val_249});
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ewitnessMatches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewitnessMatches_entry, 6, 0};

V g_heff_2eelab_2erules_2ewitnessMatches(V v_e_240, V v_sp_241, V v_goal_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_goal_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_w_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    HEFF_LAST return g_heff_2eelab_2erules_2efits(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_goal_242), v_w_246, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam0, 1, 6, (V[]){v_e_240, v_sp_241, v_goal_242, v_rest_247, v_p_244, v_p_245}));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewitnessMatches(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = v_x_2410;
    break;
  }
  case TAG_Just: {
    V v_f_2411 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2411, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V f_ = v_p_245;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_249 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ewitnessMatches_clo), 4, (V[]){v_e_240, v_sp_241, v_goal_242, v_rest_247}));
  V f_ = v_c_249;
  heff_room[0] = v_p_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam1, 1, 2, (V[]){v_x_248, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str0, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str1, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str4, 52, "an instance argument's type is not determined here: ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str5, 79, "give the argument explicitly, or annotate so the implicits around it are solved");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str6, 67, "an instance argument's type is left undetermined by an error before");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str7, 30, "the search for an instance of ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str8, 14, " goes too deep");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str9, 30, "the search for an instance of ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str10, 16, " goes more than ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str11, 2, "32");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str12, 17, " instances deep: ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str13, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str14, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str15, 7, ", then ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str16, 8, ", and on");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str17, 201, "an instance's instance arguments are found by searches of their own, and one that wants an instance of a type no smaller than its own may want them without end: give the argument explicitly, `(x := e)`");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str18, 16, "no instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str19, 39, ", where one in scope does not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str20, 16, "no instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str21, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str22, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str23, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str24, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str25, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str26, 103, "declare one, `instance x : T`, bind one, `{{x : T}} -> ...`, where this is used, or give it: `(x := e)`");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str27, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str28, 7, "wanted ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str29, 6, "  [by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str30, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str31, 1, "]");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str32, 27, "more than one instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str33, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str34, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str35, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str36, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str37, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str38, 2, ": ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str39, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str40, 1, ")");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str41, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str42, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str43, 100, "they cannot be told apart by type (small values are statically opaque): give the argument explicitly");
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam0, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam2, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam4, 2, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam9, 2, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam17(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam17, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam19(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam22(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam21(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam20(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam24(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam24, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam26(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam25(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam23(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam27(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eresolveWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_entry, 9, 0};

V g_heff_2eelab_2erules_2eresolveWanted(V v_e_240, V v_sp_241, V v_search_242, V v_hm_243, V v_holeVal_244, V v_goal_245, V v_final_246, V v_hd_247, V v_k_248) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_247, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam1, 1, 9, (V[]){v_hd_247, v_goal_245, v_e_240, v_final_246, v_search_242, v_sp_241, v_k_248, v_hm_243, v_holeVal_244})});
}
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eresolveWanted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 9);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_t_2415 = heff_get_n(v_c_2414, 1, 9);
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2415, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam7(V self, V *args) {
  V v_w_2438 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_name_2439 = heff_take_field(v_w_2438, 0);
  V v_goal_2440 = heff_get_n(v_w_2438, 1, 2);
  V v_t_2441 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_2440; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2442 = heff_strAppend(heff_strAppend(v_name_2439, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str0)), v_t_2441);
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str1), v_t_2442);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam8(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k2_2449 = args[1];
  V v_msg_2447 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2450 = heff_take_field(v_hd_2448, 1);
  V v_malg_2451 = heff_get_n(v_hd_2448, 2, 3);
  V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(340LL), NTAG(TAG_SError), v_msg_2447, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str5)})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(v_malg_2451, 1, (V[]){v_t_2454}));
  V f_ = v_bind_2450;
  args[0] = v_t_2455;
  args[1] = v_k2_2449;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam9(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args) {
  V v_u_2436 = args[0];
  V v_final_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_goal_245 = heff_env(self)[3];
  V v_search_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2436);
  if ((heff_dup(v_final_246) == NTAG(TAG_True))) {
    heff_drop(v_final_246);
    V v_t_2437 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
    V v_x2_2443 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam7, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
    V v_t_2446;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      v_t_2446 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      v_t_2446 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str3); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    V v_msg_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str4), v_t_2437), v_t_2446);
    return heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam8, 2, 2, (V[]){v_msg_2447, v_sp_241});
  } else {
    heff_drop(v_final_246);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_x_2413);
    heff_drop(v_goal_245);
    heff_drop_rec(v_search_242, 2);
    heff_drop(v_sp_241);
    return ((V)&g_heff_2eelab_2erules_2eresolveWanted_lam9_clo);
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam10(V self, V *args) {
  V v_w_2476 = args[0];
  V v_e_2463 = heff_env(self)[0];
  V v_mc_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_name_2477 = heff_take_field(v_w_2476, 0);
  V v_goal_2478 = heff_get_n(v_w_2476, 1, 2);
  V v_t_2479 = ({ V a_0 = v_e_2463; V a_1 = v_mc_2464; V a_2 = v_goal_2478; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_mc_2464); r_; });
  return heff_strAppend(heff_strAppend(v_name_2477, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str13)), v_t_2479);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam11(V self, V *args) {
  V v_i_2494 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2einstGlobal(v_e_240, v_i_2494));
}
V g_heff_2eelab_2erules_2eresolveWanted_lam13(V self, V *args) {
  V v_i_24102 = args[0];
  V v_e_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_24103 = heff_get_n(v_e_2499, 1, 6);
  V v_entries_24104 = heff_take_field(v_g_24103, 1);
  V v_aliases_24105 = heff_get_n(v_g_24103, 2, 8);
  V v_k_24106 = heff_get_n(v_i_24102, 0, 2);
  HeffT2 v_t_24107 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_24104, v_k_24106));
  {
    V v_field_24109 = v_t_24107.f[1];
    int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
    if ((v_tag_24108 == ((int64_t)0ULL))) {
      heff_drop(v_entries_24104);
      heff_drop(v_aliases_24105);
      heff_drop(v_k_24106);
      V v_e_24110 = v_field_24109;
      heff_drop(v_e_24110);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_field_24109);
      HeffT2 v_t_24111 = ({ V a_0 = v_aliases_24105; V a_1 = v_k_24106; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_24105); heff_drop(v_k_24106); r_; });
      {
        V v_field_24113 = v_t_24111.f[1];
        int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
        if ((v_tag_24112 == ((int64_t)0ULL))) {
          V v_k2_24114 = v_field_24113;
          HeffT2 v_t_24115 = ({ V a_0 = v_entries_24104; V a_1 = v_k2_24114; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_24104); heff_drop(v_k2_24114); r_; });
          {
            V v_field_24117 = v_t_24115.f[1];
            int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
            V v_ret_24bool = heff_bool(((v_tag_24116 == ((int64_t)0ULL)) ? ({ V v_x_24118 = heff_dup(v_field_24117); int c_ = 0; heff_drop(v_x_24118); c_; }) : 1));
            heff_drop(v_field_24117);
            return v_ret_24bool;
          }
        } else {
          heff_drop(v_entries_24104);
          heff_drop(v_field_24113);
          return NTAG(TAG_True);
        }
      }
    }
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam14(V self, V *args) {
  V v_w_24128 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_name_24129 = heff_take_field(v_w_24128, 0);
  V v_goal_24130 = heff_get_n(v_w_24128, 1, 2);
  V v_t_24131 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_24130; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_24132 = heff_strAppend(heff_strAppend(v_name_24129, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str22)), v_t_24131);
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str23), v_t_24132);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam17(V self, V *args) {
  V v_c_24154 = args[0];
  return heff_get_n(v_c_24154, 3, 9);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam19(V self, V *args) {
  V v_u_24159 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_24158 = heff_env(self)[1];
  V v_goal_24152 = heff_env(self)[2];
  V v_one_24144 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_goal_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_24159);
  V v_t_24160 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_x_24158; V a_2 = v_goal_24152; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_24158); r_; });
  V v_t_24161 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str28), v_t_24160), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str29));
  V v_t_24162 = heff_get_n(heff_get_n(v_one_24144, 0, 3), 0, 6);
  V v_t_24163 = heff_tr(heff_call(v_t_24162, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24164 = heff_strAppend(heff_strAppend(v_t_24161, v_t_24163), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str30));
  V v_t_24165 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  return heff_strAppend(heff_strAppend(v_t_24164, v_t_24165), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str31));
}
V g_heff_2eelab_2erules_2eresolveWanted_lam22(V self, V *args) {
  V v_b_24176 = args[0];
  V v_search_242 = heff_env(self)[0];
  V v_one_24144 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_hole_24153 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_goal_24152 = heff_env(self)[6];
  V v_hd_24150 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24177 = heff_intAdd(heff_take_field(v_search_242, 0), MK_INT(1LL));
  V v_t_24178 = heff_get_n(heff_get_n(v_one_24144, 0, 3), 0, 6);
  V v_t_24179 = heff_tr(heff_call(v_t_24178, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24180 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_24179, v_goal_245}), heff_get_n(v_search_242, 1, 2)});
  V v_t_24181 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_hole_24153, 0)));
  V v_c_24182 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 7, (V[]){v_e_240, v_sp_241, heff_rec_n(2, shape_depth__wantedBy, (V[]){v_t_24177, v_t_24180}), v_t_24181, heff_get_n(v_hole_24153, 1, 2), v_goal_24152, v_b_24176}));
  V f_ = v_c_24182;
  heff_room[0] = heff_dup(v_hd_24150);
  heff_room[1] = heff_get_n(v_hd_24150, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam21(V self, V *args) {
  V v_x_24175 = args[0];
  V v_k_24151 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_search_242 = heff_env(self)[2];
  V v_one_24144 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_hole_24153 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_goal_24152 = heff_env(self)[7];
  V v_hd_24150 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24175) == NTAG(TAG_True))) {
    heff_drop(v_x_24175);
    heff_drop(v_sp_241);
    heff_drop_rec(v_search_242, 2);
    heff_drop_rec(v_one_24144, 3);
    heff_drop(v_goal_245);
    heff_drop_rec(v_hole_24153, 2);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_goal_24152);
    heff_drop_rec(v_hd_24150, 3);
    V f_ = v_k_24151;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24175);
    V v_t_24183 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam22, 1, 8, (V[]){v_search_242, v_one_24144, v_goal_245, v_hole_24153, v_e_240, v_sp_241, v_goal_24152, heff_dup(v_hd_24150)}), NTAG(TAG_MkUnit)});
    V v_t_24184 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24183})});
    V v_t_24185 = heff_tr(heff_call(heff_take_field(v_hd_24150, 2), 1, (V[]){v_t_24184}));
    V f_ = heff_get_n(v_hd_24150, 1, 3);
    heff_room[0] = v_t_24185;
    heff_room[1] = v_k_24151;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam20(V self, V *args) {
  V v_x_24168 = args[0];
  V v_search_242 = heff_env(self)[0];
  V v_one_24144 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_hole_24153 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_goal_24152 = heff_env(self)[6];
  V v_final_246 = heff_env(self)[7];
  V v_hd_24150 = heff_env(self)[8];
  V v_k_24151 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_24168);
  V v_t_24169 = heff_intAdd(heff_dup(heff_rfield(v_search_242, 0)), MK_INT(1LL));
  V v_t_24170 = heff_get_n(heff_dup(heff_rfield(v_one_24144, 0)), 0, 6);
  V v_t_24171 = heff_tr(heff_call(v_t_24170, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24172 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_24171, heff_dup(v_goal_245)}), heff_dup(heff_rfield(v_search_242, 1))});
  V v_t_24173 = (g_heff_2eelab_2erules_2emetaOf(heff_rfield(v_hole_24153, 0)));
  V v_c_24174 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 7, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_rec_n(2, shape_depth__wantedBy, (V[]){v_t_24169, v_t_24172}), v_t_24173, heff_dup(heff_rfield(v_hole_24153, 1)), heff_dup(v_goal_24152), v_final_246}));
  V f_ = v_c_24174;
  heff_room[0] = heff_dup(v_hd_24150);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam21, 1, 9, (V[]){v_k_24151, v_sp_241, v_search_242, v_one_24144, v_goal_245, v_hole_24153, v_e_240, v_goal_24152, v_hd_24150});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam18(V self, V *args) {
  V v_x_24158 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_24152 = heff_env(self)[2];
  V v_one_24144 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_goal_245 = heff_env(self)[5];
  V v_hd_24150 = heff_env(self)[6];
  V v_search_242 = heff_env(self)[7];
  V v_hole_24153 = heff_env(self)[8];
  V v_final_246 = heff_env(self)[9];
  V v_k_24151 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_24166 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str27), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam19, 1, 6, (V[]){heff_dup(v_e_240), v_x_24158, heff_dup(v_goal_24152), heff_dup(v_one_24144), v_x_2413, heff_dup(v_goal_245)})}), NTAG(TAG_MkUnit)});
  V v_t_24167 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24150, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24166})}));
  V f_ = heff_dup(heff_rfield(v_hd_24150, 1));
  heff_room[0] = v_t_24167;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam20, 1, 10, (V[]){v_search_242, v_one_24144, v_goal_245, v_hole_24153, v_e_240, v_sp_241, v_goal_24152, v_final_246, v_hd_24150, v_k_24151});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam16(V self, V *args) {
  V v_sg_24149 = args[0];
  V v_hd_24150 = args[1];
  V v_k_24151 = args[2];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_24144 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_search_242 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_goal_24152 = heff_take_field(v_sg_24149, 1);
  V v_hole_24153 = heff_get_n(v_sg_24149, 0, 2);
  V v_t_24155 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam17_clo)})});
  V v_t_24156 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24155})});
  V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24150, 2)), 1, (V[]){v_t_24156}));
  V f_ = heff_dup(heff_rfield(v_hd_24150, 1));
  args[0] = v_t_24157;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam18, 1, 11, (V[]){v_sp_241, v_e_240, v_goal_24152, v_one_24144, v_x_2413, v_goal_245, v_hd_24150, v_search_242, v_hole_24153, v_final_246, v_k_24151});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam24(V self, V *args) {
  V v_c_24188 = args[0];
  return heff_get_n(v_c_24188, 3, 9);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam26(V self, V *args) {
  V v_x_24219 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24219);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam25(V self, V *args) {
  V v_x_24192 = args[0];
  V v_applied_24148 = heff_env(self)[0];
  V v_goal_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_one_24144 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_24193 = heff_tr(heff_call(heff_get_n(v_applied_24148, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24197;
  switch (heff_tag_of(v_x1_24193)) {
  case TAG_Nom: {
    V v_x_24194 = heff_field(v_x1_24193, 0);
    heff_take_n(v_x1_24193, 1ULL, 1);
    v_t_24197 = v_x_24194;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24193, 0ULL, 1);
    v_t_24197 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24196 = heff_field(v_x1_24193, 0);
    heff_take_n(v_x1_24193, 1ULL, 1);
    v_t_24197 = v_x_24196;
    break;
  }
  default: heff_nomatch(v_x1_24193);
  }
  V v_t_24198 = ({ V a_0 = v_x_24192; V a_1 = heff_dup(v_goal_245); V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_x_24192); r_; });
  V v_t_24218;
  switch (heff_tag_of(v_t_24198)) {
  case TAG_VU: {
    heff_take_n(v_t_24198, 0ULL, 1);
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VDecode: {
    V v_sp_24201 = heff_field(v_t_24198, 1);
    heff_take_n(v_t_24198, 2ULL, 5);
    v_t_24218 = ({ V a_0 = v_sp_24201; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2eelab_2evalue_2especializations(a_0, a_1)); heff_drop(v_sp_24201); r_; });
    break;
  }
  case TAG_VFunction: {
    heff_take_n(v_t_24198, 0ULL, 6);
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRecord: {
    heff_take_n(v_t_24198, 0ULL, 4);
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VSum: {
    heff_take_n(v_t_24198, 0ULL, 1);
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimInt: {
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimString: {
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimRune: {
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VPrimArray: {
    heff_take_n(v_t_24198, 0ULL, 1);
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFixed: {
    heff_take_n(v_t_24198, 0ULL, 1);
    v_t_24218 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_24198);
  }
  return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = heff_get_n(v_one_24144, 0, 3); V a_3 = v_goal_245; V a_4 = v_t_24197; V a_5 = v_t_24218; V a_6 = v_hd_247; V a_7 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam26, 1, 1, (V[]){v_k_248}); V r_ = (g_heff_2eelab_2erules_2echeckSettings(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24218); r_; });
}
V g_heff_2eelab_2erules_2eresolveWanted_lam23(V self, V *args) {
  V v_x_24187 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_applied_24148 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_one_24144 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24187);
  V v_t_24189 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam24_clo)})});
  V v_t_24190 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24189})});
  V v_t_24191 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_24190}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_24191;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam25, 1, 7, (V[]){v_applied_24148, v_goal_245, v_e_240, v_sp_241, v_one_24144, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam15(V self, V *args) {
  V v_x_24146 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_24144 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_search_242 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  V v_hd_247 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_subgoals_24147 = heff_take_field(v_x_24146, 2);
  V v_applied_24148 = heff_get_n(v_x_24146, 0, 3);
  V v_c_24186 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam16, 3, 7, (V[]){heff_dup(v_sp_241), heff_dup(v_e_240), heff_dup(v_one_24144), v_x_2413, heff_dup(v_goal_245), v_search_242, v_final_246}); V a_1 = v_subgoals_24147; V r_ = (g_heff_2eelab_2erules_2eeachSubgoal(a_0, a_1)); heff_drop(v_subgoals_24147); r_; });
  V f_ = v_c_24186;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam23, 1, 7, (V[]){v_hd_247, v_applied_24148, v_goal_245, v_e_240, v_sp_241, v_one_24144, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam27(V self, V *args) {
  V v_w_24224 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_name_24225 = heff_take_field(v_w_24224, 0);
  V v_goal_24226 = heff_get_n(v_w_24224, 1, 2);
  V v_t_24227 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_24226; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_24228 = heff_strAppend(heff_strAppend(v_name_24225, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str34)), v_t_24227);
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str35), v_t_24228);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam12(V self, V *args) {
  V v_x_2498 = args[0];
  V v_undetermined_2429 = heff_env(self)[0];
  V v_undecided_2458 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_goal_245 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  V v_search_242 = heff_env(self)[8];
  V v_hm_243 = heff_env(self)[9];
  V v_holeVal_244 = heff_env(self)[10];
  V v_final_246 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2498)) {
  case TAG_Nil: {
    heff_drop(v_hm_243);
    heff_drop(v_holeVal_244);
    heff_drop(v_final_246);
    if ((heff_dup(v_undetermined_2429) == NTAG(TAG_True))) {
      heff_drop(v_undetermined_2429);
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_x_2413);
      heff_drop(v_goal_245);
      heff_drop(v_sp_241);
      heff_drop_rec(v_search_242, 2);
      V f_ = v_undecided_2458;
      heff_room[0] = NTAG(TAG_MkUnit);
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_undetermined_2429);
      heff_drop_clo(v_undecided_2458, 6);
      V v_e_2499 = heff_dup(v_e_240);
      V v_t_24100 = heff_get_n(heff_dup(heff_rfield(v_e_2499, 1)), 7, 8);
      V v_t_24101 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_24100));
      V v_t_24119 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam13, 1, 1, (V[]){v_e_2499}); V a_1 = v_t_24101; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24101); r_; });
      if ((heff_dup(v_t_24119) == NTAG(TAG_True))) {
        heff_drop_rec(v_search_242, 2);
        heff_drop(v_t_24119);
        V v_t_24120 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
        V v_msg_24121 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str18), v_t_24120), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str19));
        V v_t_24122 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_msg_24121, v_sp_241, NTAG(TAG_Nothing)});
        V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24122})});
        V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
        V v_t_24125 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24124}));
        V f_ = heff_get_n(v_hd_247, 1, 3);
        heff_room[0] = v_t_24125;
        heff_room[1] = v_k_248;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_24119);
        V v_t_24126 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
        V v_t_24127 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str20), v_t_24126), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str21));
        V v_x2_24133 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam14, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
        V v_t_24136;
        switch (heff_tag_of(v_x2_24133)) {
        case TAG_Nil: {
          v_t_24136 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str24);
          break;
        }
        case TAG_Cons: {
          V v_x_24134 = heff_field(v_x2_24133, 0);
          V v_xs_24135 = heff_field(v_x2_24133, 1);
          heff_take_n(v_x2_24133, 3ULL, 2);
          v_t_24136 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str25); V a_1 = v_x_24134; V a_2 = v_xs_24135; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24135); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24133);
        }
        V v_msg_24137 = heff_strAppend(v_t_24127, v_t_24136);
        V v_t_24138 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(341LL), NTAG(TAG_SError), v_msg_24137, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str26)})});
        V v_t_24139 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24138})});
        V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
        V v_t_24141 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24140}));
        V f_ = heff_get_n(v_hd_247, 1, 3);
        heff_room[0] = v_t_24141;
        heff_room[1] = v_k_248;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  case TAG_Cons: {
    V v_it2_24143 = heff_dup(heff_field(v_x_2498, 1));
    switch (heff_tag_of(v_it2_24143)) {
    case TAG_Nil: {
      heff_drop(v_undetermined_2429);
      heff_drop_clo(v_undecided_2458, 6);
      switch (heff_tag_of(v_x_2498)) {
      case TAG_Cons: {
        V v_one_24144 = heff_field(v_x_2498, 0);
        heff_take_n(v_x_2498, 1ULL, 2);
        return (g_heff_2eelab_2erules_2ecommitted(heff_dup(v_e_240), heff_dup(v_sp_241), v_hm_243, v_holeVal_244, heff_dup(v_goal_245), heff_dup(v_one_24144), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam15, 1, 9, (V[]){v_sp_241, v_e_240, v_one_24144, v_x_2413, v_goal_245, v_search_242, v_final_246, v_hd_247, v_k_248})));
      }
      default: return heff_nomatch(v_x_2498);
      }
    }
    case TAG_Cons: {
      V v_ru_24it2_24143_24Cons = heff_take_reuse_n(v_it2_24143, 0ULL, 2);
      heff_drop(v_hm_243);
      heff_drop(v_holeVal_244);
      heff_drop(v_final_246);
      if ((heff_dup(v_undetermined_2429) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2498, 2);
        heff_drop(v_undetermined_2429);
        heff_drop_rec(v_e_240, 6);
        heff_drop(v_x_2413);
        heff_drop(v_goal_245);
        heff_drop(v_sp_241);
        heff_drop_rec(v_search_242, 2);
        heff_drop_cell(v_ru_24it2_24143_24Cons, 2);
        V f_ = v_undecided_2458;
        heff_room[0] = NTAG(TAG_MkUnit);
        heff_room[1] = v_hd_247;
        heff_room[2] = v_k_248;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      } else {
        heff_drop(v_undetermined_2429);
        heff_drop_clo(v_undecided_2458, 6);
        V v_t_24222 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
        V v_t_24223 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str32), v_t_24222), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str33));
        V v_x2_24229 = (g_list_2emap_24tok2(v_ru_24it2_24143_24Cons, heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam27, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
        V v_t_24232;
        switch (heff_tag_of(v_x2_24229)) {
        case TAG_Nil: {
          v_t_24232 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str36);
          break;
        }
        case TAG_Cons: {
          V v_x_24230 = heff_field(v_x2_24229, 0);
          V v_xs_24231 = heff_field(v_x2_24229, 1);
          heff_take_n(v_x2_24229, 3ULL, 2);
          v_t_24232 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str37); V a_1 = v_x_24230; V a_2 = v_xs_24231; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24231); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24229);
        }
        V v_t_24233 = heff_strAppend(heff_strAppend(v_t_24223, v_t_24232), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str38));
        V v_x2_24234 = (g_list_2emap_24s170737852x2114895588(((V)&g_heff_2eelab_2erules_2eresolveWanted_str39), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str40), v_x_2498));
        V v_t_24237;
        switch (heff_tag_of(v_x2_24234)) {
        case TAG_Nil: {
          v_t_24237 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str41);
          break;
        }
        case TAG_Cons: {
          V v_x_24235 = heff_field(v_x2_24234, 0);
          V v_xs_24236 = heff_field(v_x2_24234, 1);
          heff_take_n(v_x2_24234, 3ULL, 2);
          v_t_24237 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str42); V a_1 = v_x_24235; V a_2 = v_xs_24236; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24236); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24234);
        }
        V v_msg_24238 = heff_strAppend(v_t_24233, v_t_24237);
        V v_t_24239 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(342LL), NTAG(TAG_SError), v_msg_24238, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str43)})});
        V v_t_24240 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24239})});
        V v_t_24241 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24240})});
        V v_t_24242 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24241}));
        V f_ = heff_get_n(v_hd_247, 1, 3);
        heff_room[0] = v_t_24242;
        heff_room[1] = v_k_248;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_it2_24143);
    }
  }
  default: return heff_nomatch(v_x_2498);
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_goal_245 = heff_env(self)[1];
  V v_final_246 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_search_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_undetermined_2429 = heff_env(self)[6];
  V v_x_2421 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  V v_hm_243 = heff_env(self)[10];
  V v_holeVal_244 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2434 = (g_heff_2eelab_2erules_2eisEvidence(v_x_2413, heff_dup(v_goal_245)));
  V v_eager_2435 = heff_bool(((heff_dup(v_t_2434) == NTAG(TAG_True)) || ((heff_dup(v_final_246) == NTAG(TAG_True)) && !(heff_dup(v_x_2433) == NTAG(TAG_True)))));
  heff_drop(v_x_2433);
  heff_drop(v_t_2434);
  V v_undecided_2458 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam6, 1, 6, (V[]){heff_dup(v_final_246), heff_dup(v_e_240), heff_dup(v_x_2413), heff_dup(v_goal_245), heff_dup(v_search_242), heff_dup(v_sp_241)});
  if (((heff_dup(v_undetermined_2429) == NTAG(TAG_True)) && ((heff_dup(v_x_2421) == NTAG(TAG_True)) && (heff_dup(v_final_246) == NTAG(TAG_True))))) {
    heff_drop(v_x_2413);
    heff_drop(v_goal_245);
    heff_drop(v_final_246);
    heff_drop_rec(v_e_240, 6);
    heff_drop_rec(v_search_242, 2);
    heff_drop(v_undetermined_2429);
    heff_drop(v_x_2421);
    heff_drop(v_hm_243);
    heff_drop(v_holeVal_244);
    heff_drop(v_eager_2435);
    heff_drop_clo(v_undecided_2458, 6);
    V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str6), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2461}));
    V f_ = heff_get_n(v_hd_247, 1, 3);
    heff_room[0] = v_t_2462;
    heff_room[1] = v_k_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2421);
    if (((heff_dup(v_undetermined_2429) == NTAG(TAG_True)) && !(heff_dup(v_eager_2435) == NTAG(TAG_True)))) {
      heff_drop(v_x_2413);
      heff_drop(v_goal_245);
      heff_drop(v_final_246);
      heff_drop_rec(v_e_240, 6);
      heff_drop_rec(v_search_242, 2);
      heff_drop(v_sp_241);
      heff_drop(v_undetermined_2429);
      heff_drop(v_hm_243);
      heff_drop(v_holeVal_244);
      heff_drop(v_eager_2435);
      V f_ = v_undecided_2458;
      heff_room[0] = NTAG(TAG_MkUnit);
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_eager_2435);
      if (heff_intLt_c(MK_INT(32LL), heff_dup(heff_rfield(v_search_242, 0)))) {
        heff_drop(v_final_246);
        heff_drop(v_undetermined_2429);
        heff_drop(v_hm_243);
        heff_drop(v_holeVal_244);
        heff_drop_clo(v_undecided_2458, 6);
        V v_e_2463 = v_e_240;
        V v_mc_2464 = v_x_2413;
        V v_s_2465 = v_search_242;
        V v_goal_2466 = v_goal_245;
        V v_t_2467 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_2465, 1))));
        V v_msg_2484;
        switch (heff_tag_of(v_t_2467)) {
        case TAG_Nil: {
          heff_drop_rec(v_s_2465, 2);
          V v_t_2468 = ({ V a_0 = v_e_2463; V a_1 = v_mc_2464; V a_2 = v_goal_2466; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_mc_2464); r_; });
          v_msg_2484 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str7), v_t_2468), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str8));
          break;
        }
        case TAG_Cons: {
          V v_outermost_2469 = heff_field(v_t_2467, 0);
          V v_ru_24t_2467_24Cons = heff_take_reuse_n(v_t_2467, 1ULL, 2);
          heff_drop(v_goal_2466);
          V v_t_2471 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_2463), v_mc_2464, heff_get_n(v_outermost_2469, 1, 2)));
          V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str9), v_t_2471), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str10));
          V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2472, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str11)), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str12));
          V v_t_2474 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_s_2465, 1, 2)));
          V v_t_2475 = (g_list_2etake(MK_INT(3LL), v_t_2474));
          V v_x2_2480 = (g_list_2emap_24tok2(v_ru_24t_2467_24Cons, heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam10, 1, 2, (V[]){v_e_2463, v_mc_2464}), v_t_2475));
          V v_t_2483;
          switch (heff_tag_of(v_x2_2480)) {
          case TAG_Nil: {
            v_t_2483 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str14);
            break;
          }
          case TAG_Cons: {
            V v_x_2481 = heff_field(v_x2_2480, 0);
            V v_xs_2482 = heff_field(v_x2_2480, 1);
            heff_take_n(v_x2_2480, 3ULL, 2);
            v_t_2483 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str15); V a_1 = v_x_2481; V a_2 = v_xs_2482; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2482); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2480);
          }
          v_msg_2484 = heff_strAppend(heff_strAppend(v_t_2473, v_t_2483), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str16));
          break;
        }
        default: heff_nomatch(v_t_2467);
        }
        V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(349LL), NTAG(TAG_SError), v_msg_2484, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str17)})});
        V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
        V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
        V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2487}));
        V f_ = heff_get_n(v_hd_247, 1, 3);
        heff_room[0] = v_t_2488;
        heff_room[1] = v_k_248;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        V v_t_2489 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2413, heff_dup(v_goal_245)));
        V v_t_2490 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2489));
        V v_t_2491 = (g_heff_2eelab_2erules_2einstLocals(heff_dup(v_e_240)));
        V v_t_2492 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 7, 8);
        V v_t_2493 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2492));
        V v_t_2495 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam11, 1, 1, (V[]){heff_dup(v_e_240)}), v_t_2493));
        V v_t_2496 = (g_heff_2eelab_2erules_2ecatMaybesR(v_t_2495));
        V v_t_2497 = (g_prelude_2e_2b_2b(v_t_2491, v_t_2496));
        return (g_heff_2eelab_2erules_2ewitnessMatches(heff_dup(v_e_240), heff_dup(v_sp_241), v_t_2490, v_t_2497, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam12, 1, 12, (V[]){v_undetermined_2429, v_undecided_2458, v_hd_247, v_k_248, v_e_240, v_x_2413, v_goal_245, v_sp_241, v_search_242, v_hm_243, v_holeVal_244, v_final_246})));
      }
    }
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_goal_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_final_246 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_search_242 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  V v_hm_243 = heff_env(self)[8];
  V v_holeVal_244 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2422 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2413, heff_dup(v_goal_245)));
  V v_goal_2423 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2422));
  V v_t_2424 = (g_heff_2eelab_2eunify_2emetasK(heff_dup(v_x_2413)));
  V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
  V v_x1_2426 = heff_tr(heff_call(heff_get_n(v_t_2424, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2425, v_goal_2423}));
  V v_undetermined_2429;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nil: {
    v_undetermined_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2426, 0ULL, 2);
    v_undetermined_2429 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_t_2432;
  if (((heff_dup(v_undetermined_2429) == NTAG(TAG_True)) && (heff_dup(v_final_246) == NTAG(TAG_True)))) {
    v_t_2432 = ((V)&g_heff_2eelab_2eenvironment_2ecanGuess_clo);
  } else {
    v_t_2432 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_lam4_clo);
  }
  V f_ = v_t_2432;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam5, 1, 12, (V[]){v_x_2413, v_goal_245, v_final_246, v_e_240, v_search_242, v_sp_241, v_undetermined_2429, v_x_2421, v_hd_247, v_k_248, v_hm_243, v_holeVal_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_goal_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_final_246 = heff_env(self)[3];
  V v_search_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_hm_243 = heff_env(self)[7];
  V v_holeVal_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam2_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2419}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2420;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam3, 1, 10, (V[]){v_x_2413, v_goal_245, v_e_240, v_final_246, v_hd_247, v_search_242, v_sp_241, v_k_248, v_hm_243, v_holeVal_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_24cpr_str2, 1, "_");
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V v_c_240) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam0, 4, 1, (V[]){heff_dup(v_c_240)})}});
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam1(V self, V *args) {
  V v_c_245 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_245, 3, 9); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam4(V self, V *args) {
  V v_u_2431 = args[0];
  V v_v_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_v_2424;
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam7(V self, V *args) {
  V v_u_2466 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2466);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_249});
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam6(V self, V *args) {
  V v_x_2453 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_cod_2415 = heff_env(self)[2];
  V v_k_2452 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2454 = heff_take_field(v_e_241, 2);
  V v_t_2457;
  switch (heff_tag_of(v_t_2454)) {
  case TAG_ForNominative: {
    v_t_2457 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2454, 0ULL, 2);
    v_t_2457 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2454);
  }
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 5);
  V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 0, 5);
  V v_t_2460 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2459, heff_dup(v_x_249)));
  V v_t_2465;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2461 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 3);
    v_t_2465 = v_n_2461;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2415, 0ULL, 1);
    v_t_2465 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_24cpr_str2);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_x_2467 = (g_heff_2eelab_2ememoed_2elam(v_t_2457, heff_get_n(v_e_241, 1, 6), v_t_2458, heff_rec_n(2, shape_stx__val, (V[]){v_t_2460, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam7, 1, 1, (V[]){v_x_249})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_2465, v_x_2453})));
  V f_ = v_k_2452;
  args[0] = v_x_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam5(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_c_2450 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_cod_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2450;
  args[0] = v_hd_2451;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam6, 1, 4, (V[]){v_e_241, v_x_249, v_cod_2415, v_k_2452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam3(V self, V *args) {
  V v_v_2424 = args[0];
  V v_scope_27_2425 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_cod_2415 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_implicit_2416 = heff_env(self)[3];
  V v_dom_2414 = heff_env(self)[4];
  V v_x_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT1 v_t_2426 = ({ V a_0 = v_c_240; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_c_240); r_; });
  {
    V v_field_2427 = v_t_2426.f[0];
    V v_x1_2433;
    switch (heff_tag_of(v_cod_2415)) {
    case TAG_MkClo: {
      V v_vs_2429 = heff_dup(heff_field(v_cod_2415, 1));
      V v_body_2430 = heff_dup(heff_field(v_cod_2415, 2));
      v_x1_2433 = heff_tr(heff_call(v_body_2430, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2429, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam4, 1, 1, (V[]){heff_dup(v_v_2424)})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2432 = heff_dup(heff_field(v_cod_2415, 0));
      v_x1_2433 = v_body_2432;
      break;
    }
    default: heff_nomatch(v_cod_2415);
    }
    V v_a_2437;
    switch (heff_tag_of(v_x1_2433)) {
    case TAG_Nom: {
      V v_x_2434 = heff_field(v_x1_2433, 0);
      heff_take_n(v_x1_2433, 1ULL, 1);
      v_a_2437 = v_x_2434;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2433, 0ULL, 1);
      v_a_2437 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2436 = heff_field(v_x1_2433, 0);
      heff_take_n(v_x1_2433, 1ULL, 1);
      v_a_2437 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_x1_2433);
    }
    V v_f_2438 = v_field_2427;
    V v_t_2439 = heff_dup(heff_rfield(v_e_241, 2));
    V v_t_2442;
    switch (heff_tag_of(v_t_2439)) {
    case TAG_ForNominative: {
      v_t_2442 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2440 = heff_field(v_t_2439, 0);
      V v_sp_2441 = heff_field(v_t_2439, 1);
      V v_ru_24t_2439_24ForDescriptive = heff_take_reuse_n(v_t_2439, 3ULL, 2);
      v_t_2442 = heff_tag_at_n(v_ru_24t_2439_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2440, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2441, heff_dup(v_v_2424)})});
      break;
    }
    default: heff_nomatch(v_t_2439);
    }
    V v_t_2448;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      heff_drop(v_v_2424);
      heff_drop(v_dom_2414);
      v_t_2448 = heff_dup(heff_rfield(v_e_241, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2424);
      heff_drop(v_dom_2414);
      v_t_2448 = heff_dup(heff_rfield(v_e_241, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_2447;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2443 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2447 = v_n_2443;
        break;
      }
      case TAG_CloConst: {
        v_t_2447 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_24cpr_str1);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_2447, v_dom_2414, v_v_2424}), heff_dup(heff_rfield(v_e_241, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    V v_t_2449 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2425, heff_dup(heff_rfield(v_e_241, 1)), v_t_2442, heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), v_t_2448});
    V v_c_2450 = heff_tr(heff_call(v_f_2438, 2, (V[]){v_t_2449, v_a_2437}));
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam5, 2, 4, (V[]){v_c_2450, v_e_241, v_x_249, v_cod_2415});
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_249)));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2412 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2412;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_t_2410, 1);
    V v_cod_2415 = heff_field(v_t_2410, 2);
    V v_implicit_2416 = heff_field(v_t_2410, 3);
    heff_take_n(v_t_2410, 14ULL, 4);
    V v_t_2417;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      v_t_2417 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      heff_drop(v_implicit_2416);
      heff_drop(v_t_2417);
      switch (heff_tag_of(v_c_240)) {
      case TAG_MkChk: {
        V v_f_2418 = heff_field(v_c_240, 0);
        heff_take_n(v_c_240, 1ULL, 1);
        V f_ = v_f_2418;
        heff_room[0] = v_e_241;
        heff_room[1] = v_x_249;
        heff_room[2] = v_hd_243;
        heff_room[3] = v_k_244;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_c_240);
      }
    } else {
      heff_drop(v_t_2417);
      V v_t_2423;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2419 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2423 = v_n_2419;
        break;
      }
      case TAG_CloConst: {
        v_t_2423 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_24cpr_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_t_2468 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2423, heff_dup(v_dom_2414), heff_dup(heff_rfield(v_e_241, 0)), heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam3, 2, 6, (V[]){v_c_240, v_cod_2415, v_e_241, v_implicit_2416, v_dom_2414, v_x_249})));
      V f_ = v_t_2468;
      heff_room[0] = v_hd_243;
      heff_room[1] = v_k_244;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2410, 0ULL, 3);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2472 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2472;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2474 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2474;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeInt: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2475 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2475;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFloat: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2476 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2476;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeString: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2477 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2477;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeRune: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2478 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2478;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2480 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2480;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2482 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2482;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_NoRules: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2483 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2483;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a0_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam1, 1, 1, (V[]){v_a0_242})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_24cpr_lam2, 1, 4, (V[]){v_c_240, v_e_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str3, 1, "_");
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedGo_entry, 8, 0};

V g_heff_2eelab_2erules_2enamedGo(V v_sp_240, V v_x_241, V v_arg_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam0, 1, 1, (V[]){v_ty0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam1, 1, 7, (V[]){v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247, heff_dup(v_arg_242), v_e_243})});
}
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2enamedGo(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_ty0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_ty0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args) {
  V v_u2_2431 = args[0];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2431);
  V v_x1_2432 = heff_tr(heff_call(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    return v_x_2433;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2432, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    return v_x_2435;
  }
  default: return heff_nomatch(v_x1_2432);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args) {
  V v_f_2430 = args[0];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2430, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam5, 1, 1, (V[]){v_x_2426})));
}
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args) {
  V v_u_2428 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2428);
  V v_t_2429 = heff_tr(heff_call(heff_get_n(v_m_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam4, 1, 1, (V[]){v_x_2426}), v_t_2429));
}
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args) {
  V v_u_2440 = args[0];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2440);
  V v_x1_2441 = heff_tr(heff_call(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    return v_x_2442;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    return v_x_2444;
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_implicit_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_cod_2417 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2436;
  switch (heff_tag_of(v_implicit_2418)) {
  case TAG_Expl: {
    heff_drop(v_x_241);
    V v_t_2427 = heff_tag_n(TAG_SApp, 2, (V[]){heff_dup(heff_rfield(v_m_244, 0)), heff_dup(heff_rfield(v_x_2426, 0))});
    v_t_2436 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2427, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam3, 1, 2, (V[]){v_m_244, heff_dup(v_x_2426)})});
    break;
  }
  case TAG_Impl: {
    v_t_2436 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2426)));
    break;
  }
  case TAG_Inst: {
    v_t_2436 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2426)));
    break;
  }
  default: heff_nomatch(v_implicit_2418);
  }
  V v_x1_2446;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2438 = heff_field(v_cod_2417, 1);
    V v_body_2439 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2446 = heff_tr(heff_call(v_body_2439, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2438, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam6, 1, 1, (V[]){v_x_2426})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2445 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2426, 2);
    v_x1_2446 = v_body_2445;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2450;
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_Nom: {
    V v_x_2447 = heff_field(v_x1_2446, 0);
    heff_take_n(v_x1_2446, 1ULL, 1);
    v_t_2450 = v_x_2447;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2446, 0ULL, 1);
    v_t_2450 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2449 = heff_field(v_x1_2446, 0);
    heff_take_n(v_x1_2446, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x1_2446);
  }
  V v_x_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_t_2450});
  V f_ = v_k_247;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enamedGo_lam8(V self, V *args) {
  V v_u_2469 = args[0];
  V v_x_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2469);
  V v_x1_2470 = heff_tr(heff_call(heff_get_n(v_x_2459, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_Nom: {
    V v_x_2471 = heff_field(v_x1_2470, 0);
    heff_take_n(v_x1_2470, 1ULL, 1);
    return v_x_2471;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2470, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2473 = heff_field(v_x1_2470, 0);
    heff_take_n(v_x1_2470, 1ULL, 1);
    return v_x_2473;
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args) {
  V v_x_2459 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2464;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2460 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2464 = v_n_2460;
    break;
  }
  case TAG_CloConst: {
    v_t_2464 = ((V)&g_heff_2eelab_2erules_2enamedGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2465 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2464, v_m_244, heff_dup(v_x_2459)));
  V v_x1_2475;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2467 = heff_field(v_cod_2417, 1);
    V v_body_2468 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2475 = heff_tr(heff_call(v_body_2468, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2467, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam8, 1, 1, (V[]){v_x_2459})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2474 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2459, 2);
    v_x1_2475 = v_body_2474;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2479;
  switch (heff_tag_of(v_x1_2475)) {
  case TAG_Nom: {
    V v_x_2476 = heff_field(v_x1_2475, 0);
    heff_take_n(v_x1_2475, 1ULL, 1);
    v_t_2479 = v_x_2476;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2475, 0ULL, 1);
    v_t_2479 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2478 = heff_field(v_x1_2475, 0);
    heff_take_n(v_x1_2475, 1ULL, 1);
    v_t_2479 = v_x_2478;
    break;
  }
  default: heff_nomatch(v_x1_2475);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2465; V a_5 = v_t_2479; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam10(V self, V *args) {
  V v_u_2495 = args[0];
  V v_x_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2495);
  V v_x1_2496 = heff_tr(heff_call(heff_get_n(v_x_2485, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_Nom: {
    V v_x_2497 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    return v_x_2497;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2496, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2499 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    return v_x_2499;
  }
  default: return heff_nomatch(v_x1_2496);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam9(V self, V *args) {
  V v_x_2485 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2490;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2486 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2490 = v_n_2486;
    break;
  }
  case TAG_CloConst: {
    v_t_2490 = ((V)&g_heff_2eelab_2erules_2enamedGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2491 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2490, v_m_244, heff_dup(v_x_2485)));
  V v_x1_24101;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2493 = heff_field(v_cod_2417, 1);
    V v_body_2494 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_24101 = heff_tr(heff_call(v_body_2494, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2493, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam10, 1, 1, (V[]){v_x_2485})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24100 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2485, 2);
    v_x1_24101 = v_body_24100;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_24105;
  switch (heff_tag_of(v_x1_24101)) {
  case TAG_Nom: {
    V v_x_24102 = heff_field(v_x1_24101, 0);
    heff_take_n(v_x1_24101, 1ULL, 1);
    v_t_24105 = v_x_24102;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24105 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24104 = heff_field(v_x1_24101, 0);
    heff_take_n(v_x1_24101, 1ULL, 1);
    v_t_24105 = v_x_24104;
    break;
  }
  default: heff_nomatch(v_x1_24101);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2491; V a_5 = v_t_24105; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_m_244 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_arg_242 = heff_env(self)[5];
  V v_e_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2413, 1);
    V v_cod_2417 = heff_field(v_t_2413, 2);
    V v_implicit_2418 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_cod_2417)) {
    case TAG_MkClo: {
      V v_n_2419 = heff_dup(heff_field(v_cod_2417, 0));
      v_t_2423 = heff_bool(heff_strEq_c_lent(v_n_2419, v_x_241, 0));
      heff_drop(v_n_2419);
      break;
    }
    case TAG_CloConst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_cod_2417);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_sp_240);
      heff_drop(v_t_2423);
      V v_c_2425;
      switch (heff_tag_of(v_arg_242)) {
      case TAG_MkChk: {
        V v_f_2424 = heff_field(v_arg_242, 0);
        heff_take_n(v_arg_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_call(v_f_2424, 2, (V[]){v_e_243, v_dom_2416}));
        break;
      }
      default: heff_nomatch(v_arg_242);
      }
      V f_ = v_c_2425;
      heff_room[0] = v_hd_246;
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam2, 1, 5, (V[]){v_implicit_2418, v_m_244, v_x_241, v_cod_2417, v_k_247});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2423);
      V v_t_2452;
      switch (heff_tag_of(v_implicit_2418)) {
      case TAG_Expl: {
        v_t_2452 = NTAG(TAG_False);
        break;
      }
      case TAG_Impl: {
        v_t_2452 = NTAG(TAG_True);
        break;
      }
      case TAG_Inst: {
        v_t_2452 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_implicit_2418);
      }
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_implicit_2418);
        heff_drop(v_t_2452);
        V v_t_2457;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2453 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2457 = v_n_2453;
          break;
        }
        case TAG_CloConst: {
          v_t_2457 = ((V)&g_heff_2eelab_2erules_2enamedGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2458 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_243), heff_dup(v_sp_240), v_x_2412, v_dom_2416, v_t_2457));
        V f_ = v_c_2458;
        heff_room[0] = heff_dup(v_hd_246);
        heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam7, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_x_2412);
        heff_drop(v_t_2452);
        switch (heff_tag_of(v_implicit_2418)) {
        case TAG_Expl: {
          heff_drop(v_arg_242);
          heff_drop(v_e_243);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
        }
        case TAG_Impl: {
          heff_drop(v_arg_242);
          heff_drop(v_e_243);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
        }
        case TAG_Inst: {
          V v_t_2484;
          switch (heff_tag_of(v_cod_2417)) {
          case TAG_MkClo: {
            V v_n_2480 = heff_dup(heff_field(v_cod_2417, 0));
            v_t_2484 = v_n_2480;
            break;
          }
          case TAG_CloConst: {
            v_t_2484 = ((V)&g_heff_2eelab_2erules_2enamedGo_str2);
            break;
          }
          default: heff_nomatch(v_cod_2417);
          }
          return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_243), heff_dup(v_sp_240), v_dom_2416, v_t_2484, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam9, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247})));
        }
        default: return heff_nomatch(v_implicit_2418);
        }
      }
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_m_244, v_hd_246, v_k_247));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eelimGo_str0, 8, "argument");
HEFF_LIT(g_heff_2eelab_2erules_2eelimGo_str1, 8, "argument");
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2eelimGo_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimGo_lam10, 1, 0};
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args); static Clo g_heff_2eelab_2erules_2eelimGo_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimGo_lam11, 1, 0};
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args); static Clo g_heff_2eelab_2erules_2eelimGo_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimGo_lam12, 1, 0};
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimGo_entry, 8, 0};

V g_heff_2eelab_2erules_2eelimGo(V v_checksOnly_240, V v_lambda_241, V v_sp_242, V v_arg_243, V v_e_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ecallee_248 = heff_field(v_x6_245, 0);
    V v_a_249 = heff_field(v_x6_245, 1);
    heff_take_n(v_x6_245, 3ULL, 2);
    V v_t_2410 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_249)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_LikeFunction: {
      V v_dom_2412 = heff_field(v_t_2410, 1);
      V v_cod_2413 = heff_field(v_t_2410, 2);
      heff_take_n(v_t_2410, 6ULL, 4);
      heff_drop(v_a_249);
      if ((heff_dup(v_checksOnly_240) == NTAG(TAG_True))) {
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam0, 1, 1, (V[]){heff_dup(v_dom_2412)})})});
        V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
        V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_246, 2)), 1, (V[]){v_t_2417}));
        return heff_tail(heff_dup(heff_rfield(v_z_246, 1)), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam1, 1, 9, (V[]){v_e_244, v_ecallee_248, v_dom_2412, v_cod_2413, v_arg_243, v_z_246, v_z_247, heff_dup(v_lambda_241), v_sp_242})});
      } else {
        heff_drop(v_sp_242);
        V v_t_2481 = ({ V a_0 = v_e_244; V a_1 = v_ecallee_248; V a_2 = v_dom_2412; V a_3 = v_cod_2413; V a_4 = v_arg_243; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_cod_2413); heff_drop(v_arg_243); r_; });
        return heff_tail(v_t_2481, 2, (V[]){v_z_246, v_z_247});
      }
    }
    default: {
      heff_drop(v_arg_243);
      heff_drop(v_t_2410);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_249), heff_dup(v_z_246), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam9, 1, 6, (V[]){v_z_247, v_a_249, v_z_246, v_e_244, v_sp_242, v_ecallee_248})));
    }
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eelimGo(a0, a1, a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args) {
  V v_c_2415 = args[0];
  V v_dom_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2415, 3, 9); V a_1 = v_dom_2412; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args) {
  V v_chk_2446 = args[0];
  V v_hd_2447 = args[1];
  V v_k2_2448 = args[2];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tr(heff_call(v_chk_2446, 2, (V[]){heff_dup(v_hd_2447), heff_dup(heff_rfield(v_hd_2447, 0))}));
  V v_t_2450 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2419, v_t_2449, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_2447, 2), 1, (V[]){v_t_2451}));
  V f_ = heff_get_n(v_hd_2447, 1, 3);
  args[0] = v_t_2452;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args) {
  V v_p_2444 = args[0];
  V v_p_2445 = args[1];
  V v_x_2419 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam3, 3, 1, (V[]){heff_dup(v_x_2419)}); V a_1 = v_e_244; V a_2 = v_sp_242; V a_3 = ((V)&g_heff_2eelab_2erules_2eelimGo_str1); V a_4 = v_arg_243; V a_5 = v_x_2419; V a_6 = v_p_2444; V a_7 = v_p_2445; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_243); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args) {
  V v_u_2461 = args[0];
  V v_val_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2461);
  V v_x1_2462 = heff_tr(heff_call(v_val_2456, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2462)) {
  case TAG_Nom: {
    V v_x_2463 = heff_field(v_x1_2462, 0);
    heff_take_n(v_x1_2462, 1ULL, 1);
    return v_x_2463;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2462, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2465 = heff_field(v_x1_2462, 0);
    heff_take_n(v_x1_2462, 1ULL, 1);
    return v_x_2465;
  }
  default: return heff_nomatch(v_x1_2462);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args) {
  V v_u2_2475 = args[0];
  V v_val_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2475);
  V v_x1_2476 = heff_tr(heff_call(v_val_2456, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2476)) {
  case TAG_Nom: {
    V v_x_2477 = heff_field(v_x1_2476, 0);
    heff_take_n(v_x1_2476, 1ULL, 1);
    return v_x_2477;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2476, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2479 = heff_field(v_x1_2476, 0);
    heff_take_n(v_x1_2476, 1ULL, 1);
    return v_x_2479;
  }
  default: return heff_nomatch(v_x1_2476);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args) {
  V v_f_2474 = args[0];
  V v_val_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2474, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam8, 1, 1, (V[]){v_val_2456})));
}
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args) {
  V v_u_2472 = args[0];
  V v_ecallee_248 = heff_env(self)[0];
  V v_val_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2472);
  V v_t_2473 = heff_tr(heff_call(heff_get_n(v_ecallee_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam7, 1, 1, (V[]){v_val_2456}), v_t_2473));
}
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args) {
  V v_x_2454 = args[0];
  V v_ecallee_248 = heff_env(self)[0];
  V v_cod_2413 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_stx_2455 = heff_take_field(v_x_2454, 0);
  V v_val_2456 = heff_get_n(v_x_2454, 1, 2);
  V v_t_2457 = heff_tag_n(TAG_SApp, 2, (V[]){heff_dup(heff_rfield(v_ecallee_248, 0)), v_stx_2455});
  V v_x1_2467;
  switch (heff_tag_of(v_cod_2413)) {
  case TAG_MkClo: {
    V v_vs_2459 = heff_field(v_cod_2413, 1);
    V v_body_2460 = heff_field(v_cod_2413, 2);
    heff_take_n(v_cod_2413, 6ULL, 3);
    v_x1_2467 = heff_tr(heff_call(v_body_2460, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2459, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam5, 1, 1, (V[]){heff_dup(v_val_2456)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2466 = heff_field(v_cod_2413, 0);
    heff_take_n(v_cod_2413, 1ULL, 1);
    v_x1_2467 = v_body_2466;
    break;
  }
  default: heff_nomatch(v_cod_2413);
  }
  V v_t_2471;
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_Nom: {
    V v_x_2468 = heff_field(v_x1_2467, 0);
    heff_take_n(v_x1_2467, 1ULL, 1);
    v_t_2471 = v_x_2468;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2467, 0ULL, 1);
    v_t_2471 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2470 = heff_field(v_x1_2467, 0);
    heff_take_n(v_x1_2467, 1ULL, 1);
    v_t_2471 = v_x_2470;
    break;
  }
  default: heff_nomatch(v_x1_2467);
  }
  V v_x_2480 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2457, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam6, 1, 2, (V[]){v_ecallee_248, v_val_2456})}), v_t_2471});
  V f_ = v_z_247;
  args[0] = v_x_2480;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_ecallee_248 = heff_env(self)[1];
  V v_dom_2412 = heff_env(self)[2];
  V v_cod_2413 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_lambda_241 = heff_env(self)[7];
  V v_sp_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2442;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_VU: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2421 = heff_dup(heff_field(v_x_2419, 0));
    switch (heff_tag_of(v_t1_2421)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2421, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2421, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2421, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t1_2421);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VRecord: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VSum: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimString: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_VFixed: {
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_x_2419);
    heff_drop(v_lambda_241);
    heff_drop(v_sp_242);
    heff_drop(v_t_2442);
    V v_t_2443 = ({ V a_0 = v_e_244; V a_1 = v_ecallee_248; V a_2 = v_dom_2412; V a_3 = v_cod_2413; V a_4 = v_arg_243; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_cod_2413); heff_drop(v_arg_243); r_; });
    V f_ = v_t_2443;
    heff_room[0] = v_z_246;
    heff_room[1] = v_z_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_dom_2412);
    heff_drop(v_t_2442);
    V v_t_2453;
    if ((heff_dup(v_lambda_241) == NTAG(TAG_True))) {
      heff_drop(v_lambda_241);
      v_t_2453 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2edelayLambda_clo), 5, (V[]){v_e_244, v_sp_242, ((V)&g_heff_2eelab_2erules_2eelimGo_str0), v_arg_243, v_x_2419}));
    } else {
      heff_drop(v_lambda_241);
      v_t_2453 = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam2, 2, 4, (V[]){v_x_2419, v_e_244, v_sp_242, v_arg_243});
    }
    V f_ = v_t_2453;
    heff_room[0] = v_z_246;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam4, 1, 3, (V[]){v_ecallee_248, v_cod_2413, v_z_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args) {
  V v_u_2483 = args[0];
  heff_drop(v_u_2483);
  V v_t_2484 = (g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2484});
}
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args) {
  V v_x_2486 = args[0];
  heff_drop(v_x_2486);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args) {
  V v_x_2487 = args[0];
  heff_drop(v_x_2487);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args) {
  V v_c_2489 = args[0];
  V v_a_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2489, 3, 9); V a_1 = v_a_249; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args) {
  V v_x_2493 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_ecallee_248 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_244, v_sp_242, v_ecallee_248, v_x_2493, v_z_246, v_z_247));
}
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args) {
  V v_x_2482 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_sp_242 = heff_env(self)[4];
  V v_ecallee_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2482) == NTAG(TAG_True))) {
    heff_drop(v_x_2482);
    heff_drop(v_a_249);
    heff_drop_rec(v_z_246, 3);
    heff_drop(v_e_244);
    heff_drop(v_sp_242);
    heff_drop_rec(v_ecallee_248, 2);
    V v_t_2485 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), ((V)&g_heff_2eelab_2erules_2eelimGo_lam10_clo)});
    V v_t_2488 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eelimGo_lam11_clo), ((V)&g_heff_2eelab_2erules_2eelimGo_lam12_clo)});
    V f_ = v_z_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2485, v_t_2488});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2482);
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam13, 1, 1, (V[]){v_a_249})})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_246, 2)), 1, (V[]){v_t_2491}));
    V f_ = heff_dup(heff_rfield(v_z_246, 1));
    heff_room[0] = v_t_2492;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam14, 1, 5, (V[]){v_e_244, v_sp_242, v_ecallee_248, v_z_246, v_z_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimString_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimString_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimString_st;
static V g_heff_2eelab_2erules_2eprimString_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimString_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimString_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimString_st)) return g_heff_2eelab_2erules_2eprimString_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimString_val, &g_heff_2eelab_2erules_2eprimString_st, g_heff_2eelab_2erules_2eprimString_init);
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2erules_2eappendP_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eappendP_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2erules_2eplacesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesGo_entry, 2, 0};

V g_heff_2eelab_2erules_2eplacesGo(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if ((heff_dup(v_b_242) == NTAG(TAG_True))) {
      heff_drop(v_b_242);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_241)}), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2eplacesGo_24dps(v_rest_243, heff_box_word((heff_unbox_word(v_k_241) + ((int64_t)1ULL))), heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_b_242);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2erules_2eplacesGo_24dps(v_rest_243, v_k_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eplacesGo(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldIdxs_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2efieldIdxs_24dps(V v_at_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){MK_INT(0LL), heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_at_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_245;
      v_at_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_p_247 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      V v_t_248 = heff_intSub(heff_intSub(heff_dup(v_at_240), MK_INT(1LL)), v_p_247);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_at_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_249;
      v_at_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldIdxs_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2erules_2efieldTyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldTyAt_entry, 6, 0};

V g_heff_2eelab_2erules_2efieldTyAt(V v_len_240, V v_capture_241, V v_fieldTypes_242, V v_i_243, V v_before_244, V v_j_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_len_240, v_capture_241, v_fieldTypes_242, v_i_243, v_before_244, v_j_245));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_248});
    } else {
      heff_drop(v_field_248);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldTyAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2eelab_2erules_2esumFormation_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map0_entry, 2, 0};

V g_heff_2eelab_2erules_2esumFormation_24map0(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_m_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_243 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = v_t_243;
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_m_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_243 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = v_t_243;
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation_24map0(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2efindOr_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2efindOr_24cpr_str1, 13, "` is defined ");
HEFF_LIT(g_heff_2eelab_2erules_2efindOr_24cpr_str2, 5, "uses ");
HEFF_LIT(g_heff_2eelab_2erules_2efindOr_24cpr_str3, 26, ", which does not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2efindOr_24cpr_str4, 9, "variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efindOr_24cpr_str5, 162, " is the definition being elaborated: it is in hand only under a lambda, where a type is expected of it (an argument, a branch, the result -- not a case scrutinee)");
V g_heff_2eelab_2erules_2efindOr_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efindOr_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efindOr_24cpr(V v_sp_240, V v_x_241, V v_unbound_242) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam0, 1, 3, (V[]){v_x_241, v_sp_240, v_unbound_242})}});
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam1(V self, V *args) {
  V v_k_2418 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_get_n(heff_get_n(v_e_243, 1, 6), 5, 8);
  HeffT2 v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_k_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2419); r_; });
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      heff_drop(v_k_2418);
      V v_place_2423 = v_field_2422;
      return v_place_2423;
    } else {
      heff_drop(v_field_2422);
      return v_k_2418;
    }
  }
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_msg_2426 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2429 = heff_take_field(v_hd_2427, 1);
  V v_malg_2430 = heff_get_n(v_hd_2427, 2, 3);
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(330LL), NTAG(TAG_SError), v_msg_2426, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(v_malg_2430, 1, (V[]){v_t_2433}));
  V f_ = v_bind_2429;
  args[0] = v_t_2434;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam3(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k2_2436 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2437 = heff_take_field(v_hd_2435, 1);
  V v_malg_2438 = heff_get_n(v_hd_2435, 2, 3);
  V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2efindOr_24cpr_str2), v_x_241), ((V)&g_heff_2eelab_2erules_2efindOr_24cpr_str3));
  V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_t_2439, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_call(v_malg_2438, 1, (V[]){v_t_2442}));
  V f_ = v_bind_2437;
  args[0] = v_t_2443;
  args[1] = v_k2_2436;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam5(V self, V *args) {
  V v_mc_2452 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_type_5f_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_243; V a_1 = v_mc_2452; V a_2 = v_type_5f_2446; V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2452); r_; });
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam7(V self, V *args) {
  V v_u_2457 = args[0];
  V v_value_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2457);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_value_2447});
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_key_2444 = heff_env(self)[0];
  V v_value_2447 = heff_env(self)[1];
  V v_k_2449 = heff_env(self)[2];
  V v_type_5f_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2456);
  V v_t_2458 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_2444}), heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam7, 1, 1, (V[]){v_value_2447})});
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2458, v_type_5f_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam4(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_key_2444 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_type_5f_2446 = heff_env(self)[4];
  V v_value_2447 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_bind_2450 = heff_take_field(v_hd_2448, 1);
  V v_malg_2451 = heff_get_n(v_hd_2448, 2, 3);
  V v_t_2453 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_key_2444)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam5, 1, 2, (V[]){v_e_243, heff_dup(v_type_5f_2446)})});
  V v_t_2454 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2453, NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tr(heff_call(v_malg_2451, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})}));
  V f_ = v_bind_2450;
  args[0] = v_t_2455;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam6, 1, 4, (V[]){v_key_2444, v_value_2447, v_k_2449, v_type_5f_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam8(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k2_2460 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2461 = heff_take_field(v_hd_2459, 1);
  V v_malg_2462 = heff_get_n(v_hd_2459, 2, 3);
  V v_t_2463 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2efindOr_24cpr_str4), v_x_241), ((V)&g_heff_2eelab_2erules_2efindOr_24cpr_str5));
  V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(319LL), NTAG(TAG_SError), v_t_2463, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tr(heff_call(v_malg_2462, 1, (V[]){v_t_2466}));
  V f_ = v_bind_2461;
  args[0] = v_t_2467;
  args[1] = v_k2_2460;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam9(V self, V *args) {
  V v_mc_2477 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_ty_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_243; V a_1 = v_mc_2477; V a_2 = v_ty_2469; V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2477); r_; });
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam11(V self, V *args) {
  V v_x_2485 = args[0];
  V v_k_2480 = heff_env(self)[0];
  V v_m_2468 = heff_env(self)[1];
  V v_ty_2469 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2485);
  V f_ = v_k_2480;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2468, v_ty_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam10(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_i_2478 = heff_env(self)[0];
  V v_m_2468 = heff_env(self)[1];
  V v_ty_2469 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2481 = heff_take_field(v_hd_2479, 1);
  V v_malg_2482 = heff_get_n(v_hd_2479, 2, 3);
  V v_t_2483 = heff_tag_n(TAG_Record, 2, (V[]){v_i_2478, NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tr(heff_call(v_malg_2482, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = v_bind_2481;
  args[0] = v_t_2484;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam11, 1, 3, (V[]){v_k_2480, v_m_2468, v_ty_2469});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindOr_24cpr_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_unbound_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 1, 5);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 3, 5);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 5);
  HeffT3 v_t_247 = ({ V a_0 = v_x_241; V a_1 = v_t_244; V a_2 = v_t_245; V a_3 = v_t_246; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); HeffT3 r_ = (g_heff_2eelab_2erules_2evarGo_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_244); heff_drop(v_t_245); heff_drop(v_t_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_field_2410);
      V v_it1_2411 = v_field_249;
      switch (heff_tag_of(v_it1_2411)) {
      case TAG_NotInScope: {
        HeffT3 v_t_2412 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(heff_dup(heff_rfield(v_e_243, 1)), heff_dup(v_x_241)));
        {
          V v_field_2414 = v_t_2412.f[1];
          V v_field_2415 = v_t_2412.f[2];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            heff_drop(v_unbound_242);
            heff_drop(v_field_2415);
            V v_ks_2416 = v_field_2414;
            V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2efindOr_24cpr_str0), v_x_241), ((V)&g_heff_2eelab_2erules_2efindOr_24cpr_str1));
            V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam1, 1, 1, (V[]){v_e_243}), v_ks_2416));
            V v_t_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2eelab_2eglobals_2eplacesSaid(a_0)); heff_drop(v_t_2424); r_; });
            V v_msg_2426 = heff_strAppend(v_t_2417, v_t_2425);
            return heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam2, 2, 2, (V[]){v_msg_2426, v_sp_240});
          } else {
            if ((v_tag_2413 == ((int64_t)1ULL))) {
              heff_drop_rec(v_e_243, 6);
              heff_drop(v_unbound_242);
              heff_drop(v_field_2414);
              heff_drop(v_field_2415);
              return heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam3, 2, 2, (V[]){v_x_241, v_sp_240});
            } else {
              if ((v_tag_2413 == ((int64_t)2ULL))) {
                heff_drop(v_unbound_242);
                V v_key_2444 = v_field_2414;
                V v_ge_2445 = v_field_2415;
                V v_type_5f_2446 = heff_take_field(v_ge_2445, 3);
                V v_value_2447 = heff_get_n(v_ge_2445, 2, 4);
                return heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam4, 2, 6, (V[]){v_sp_240, v_x_241, v_key_2444, v_e_243, v_type_5f_2446, v_value_2447});
              } else {
                heff_drop_rec(v_e_243, 6);
                heff_drop(v_x_241);
                heff_drop(v_sp_240);
                heff_drop(v_field_2414);
                heff_drop(v_field_2415);
                return v_unbound_242;
              }
            }
          }
        }
      }
      case TAG_Delayed2: {
        heff_drop_rec(v_e_243, 6);
        heff_drop(v_unbound_242);
        return heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam8, 2, 2, (V[]){v_x_241, v_sp_240});
      }
      default: return heff_nomatch(v_it1_2411);
      }
    } else {
      heff_drop(v_unbound_242);
      V v_m_2468 = v_field_249;
      V v_ty_2469 = v_field_2410;
      V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 1, 5);
      HeffT2 v_t_2471 = ({ V a_0 = v_t_2470; V a_1 = v_x_241; V a_2 = MK_INT(0LL); HeffT2 r_ = (g_heff_2eelab_2erules_2eindexOfName_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2470); r_; });
      V v_t_2476;
      {
        V v_field_2473 = v_t_2471.f[1];
        int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
        if ((v_tag_2472 == ((int64_t)0ULL))) {
          V v_i_2474 = v_field_2473;
          V v_t_2475 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 5);
          if (heff_intEq_c(v_i_2474, heff_intSub(v_t_2475, MK_INT(1LL)))) {
            v_t_2476 = heff_dup(heff_rfield(v_e_243, 4));
          } else {
            v_t_2476 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_field_2473);
          v_t_2476 = NTAG(TAG_Nothing);
        }
      }
      V v_i_2478 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, v_t_2476, NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam9, 1, 2, (V[]){v_e_243, heff_dup(v_ty_2469)})});
      return heff_clo_n(g_heff_2eelab_2erules_2efindOr_24cpr_lam10, 2, 3, (V[]){v_i_2478, v_m_2468, v_ty_2469});
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam2, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam3, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam5, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam6, 1, 0};
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_entry, 2, 0};

V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432(V v_lit_240, V v_sp_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam0, 3, 2, (V[]){v_sp_241, v_lit_240})});
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432(a[0], a[1]);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  heff_drop(v_x_2419);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  heff_drop(v_x_2420);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  heff_drop(v_x_2437);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  heff_drop(v_x_2438);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_get_n(v_x_248, 1, 2);
  V v_t_2439;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_VNeu: {
    V v_h_2428 = heff_field(v_t_2427, 0);
    V v_sp_2429 = heff_field(v_t_2427, 1);
    V v_ty_2430 = heff_field(v_t_2427, 2);
    V v_expansion_2431 = heff_field(v_t_2427, 3);
    V v_desc_2432 = heff_field(v_t_2427, 4);
    V v_ru_24t_2427_24VNeu = heff_take_reuse_n(v_t_2427, 31ULL, 5);
    v_t_2439 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_2427_24VNeu, v_h_2428, v_sp_2429, v_ty_2430, v_expansion_2431, v_desc_2432));
    break;
  }
  case TAG_VCode: {
    V v_a_2433 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2439 = v_a_2433;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_2427, 0ULL, 2);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_2427, 0ULL, 1);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_t_2439 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam5_clo), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam6_clo)});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V v_x_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_t_2439});
  V f_ = v_k_244;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_dup(heff_rfield(v_x_248, 1));
  V v_a_2421;
  switch (heff_tag_of(v_t_249)) {
  case TAG_VNeu: {
    V v_h_2410 = heff_field(v_t_249, 0);
    V v_sp_2411 = heff_field(v_t_249, 1);
    V v_ty_2412 = heff_field(v_t_249, 2);
    V v_expansion_2413 = heff_field(v_t_249, 3);
    V v_desc_2414 = heff_field(v_t_249, 4);
    V v_ru_24t_249_24VNeu = heff_take_reuse_n(v_t_249, 31ULL, 5);
    v_a_2421 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_249_24VNeu, v_h_2410, v_sp_2411, v_ty_2412, v_expansion_2413, v_desc_2414));
    break;
  }
  case TAG_VCode: {
    V v_a_2415 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    v_a_2421 = v_a_2415;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_249, 0ULL, 2);
    v_a_2421 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_249, 0ULL, 1);
    v_a_2421 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_a_2421 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam2_clo), ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam3_clo)});
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  HeffT1 v_t_2422 = (g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr(v_lit_240, v_sp_241));
  V v_c_2425;
  {
    V v_field_2423 = v_t_2422.f[0];
    V v_f_2424 = v_field_2423;
    v_c_2425 = heff_tr(heff_call(v_f_2424, 2, (V[]){v_e_242, v_a_2421}));
  }
  V f_ = v_c_2425;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam4, 1, 2, (V[]){v_x_248, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_hd_243 = args[1];
  V v_k_244 = args[2];
  V v_sp_241 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 5);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 5);
  V v_t_247 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return ({ V a_0 = v_t_245; V a_1 = v_t_246; V a_2 = v_t_247; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_str0); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_243); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_lam1, 1, 5, (V[]){v_lit_240, v_sp_241, v_e_242, v_hd_243, v_k_244}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_246); r_; });
}
Clo g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_entry, 2, 0};

V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = (g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672(a[0], a[1]);
}