// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_depth 296830685
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_goal 9673690
#define LBL_hole 9703815
#define LBL_instances 1653559473
#define LBL_instantiated 552850723
#define LBL_insts 301719303
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_state 311115947
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_wantedBy 1134124532
#define LBL_witness 1587180415
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_depth__wantedBy[] = {LBL_depth, LBL_wantedBy};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_name__goal[] = {LBL_name, LBL_goal};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s1601686549x58384075(V, V, V, V);
V g_co_2ebind_24s1601686549x58384075_entry(V self, V *a);
extern Clo g_co_2ebind_24s1601686549x58384075_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimString_get(void);
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2ebrokenInstanceIn(V);
V g_heff_2eelab_2erules_2ebrokenInstanceIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebrokenInstanceIn_clo;
V g_heff_2eelab_2erules_2ecatMaybesR(V);
V g_heff_2eelab_2erules_2ecatMaybesR_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_clo;
V g_heff_2eelab_2erules_2ecommitted(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecommitted_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2eeachSubgoal(V, V);
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeachSubgoal_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
V g_heff_2eelab_2erules_2eelimPlain(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimPlain_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimPlain_clo;
V g_heff_2eelab_2erules_2eeqTyStr(V, V, V);
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqTyStr_clo;
V g_heff_2eelab_2erules_2eerrorOf_get(void);
V g_heff_2eelab_2erules_2efieldIdxs_24dps(V, V, V);
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo;
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2erules_2efits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efits_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2egivenTwice(V, V);
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenTwice_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2einstGlobal(V, V);
V g_heff_2eelab_2erules_2einstGlobal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstGlobal_clo;
V g_heff_2eelab_2erules_2einstanceDepthLimit_get(void);
V g_heff_2eelab_2erules_2eintoSilent(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintoSilent_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintoSilent_clo;
V g_heff_2eelab_2erules_2elitBytes(V, V);
V g_heff_2eelab_2erules_2elitBytes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitBytes_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2emisfit(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo;
V g_heff_2eelab_2erules_2enestedField(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enestedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enestedField_clo;
V g_heff_2eelab_2erules_2enotAFunction(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotAFunction_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2enumLitDefault(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitDefault_clo;
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2eplacesGo(V, V);
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_clo;
V g_heff_2eelab_2erules_2eplacesGo_24dps(V, V, V);
V g_heff_2eelab_2erules_2eplacesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesGo_24dps_clo;
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordNameOf(V, V, V, V);
V g_heff_2eelab_2erules_2erecordNameOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordNameOf_clo;
V g_heff_2eelab_2erules_2erecordUpdate(V, V, V, V);
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordUpdate_clo;
V g_heff_2eelab_2erules_2erequireAgree(V, V, V);
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erequireAgree_clo;
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2esumIntro(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntro_clo;
V g_heff_2eelab_2erules_2esumIntroNow(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntroNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntroNow_clo;
V g_heff_2eelab_2erules_2etooDeep(V, V, V, V);
V g_heff_2eelab_2erules_2etooDeep_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etooDeep_clo;
V g_heff_2eelab_2erules_2eupdateInner(V);
V g_heff_2eelab_2erules_2eupdateInner_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateInner_clo;
V g_heff_2eelab_2erules_2eupdateOf(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateOf_clo;
V g_heff_2eelab_2erules_2eupdateSetting(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateSetting_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2erules_2ewitnessMatches(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewitnessMatches_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edecodeN(V);
V g_heff_2eelab_2evalue_2edecodeN_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeN_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eimplicitDefault(V);
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1049333826x1545174117(V, V, V);
V g_list_2emap_24s1049333826x1545174117_entry(V self, V *a);
extern Clo g_list_2emap_24s1049333826x1545174117_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqTyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqTyStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqTyStr(V v_g_240, V v_cs_241, V v_t_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_take_field(v_cs_241, 0), v_t_242));
  V v_t_249 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqTyStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_t_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 1, 2), 1, (V[]){v_t_243}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = heff_get_n(v_cs_241, 1, 2); V a_3 = v_t_2410; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
}
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqTyStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqTyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_248;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitArg_entry, 5, 0};

V g_heff_2eelab_2erules_2eimplicitArg(V v_e_240, V v_sp_241, V v_ty_242, V v_dom_243, V v_x_244) {
top: ;
  V v_t_245 = (g_heff_2eelab_2evalue_2eimplicitDefault(v_ty_242));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam0, 2, 4, (V[]){v_e_240, v_dom_243, v_x_244, v_sp_241});
  }
  case TAG_Just: {
    V v_d_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop(v_sp_241);
    heff_drop(v_dom_243);
    heff_drop(v_x_244);
    return heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam3, 2, 2, (V[]){v_d_2413, v_e_240});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eimplicitArg(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2eimplicitArg_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam2, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_nf(v_x_2410, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitArg_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_dom_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_249 = heff_get_n(heff_get_n(v_e_240, 0, 6), 2, 4);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = v_dom_243; V a_3 = v_x_244; V a_4 = v_sp_241; V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam1, 1, 1, (V[]){v_k_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2eimplicitArg_lam4(V self, V *args) {
  V v_u_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_d_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_get_n(v_e_240, 1, 6), NTAG(TAG_N), v_d_2413, NTAG(TAG_LNil)));
}
V g_heff_2eelab_2erules_2eimplicitArg_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_2413), heff_clo_n(g_heff_2eelab_2erules_2eimplicitArg_lam4, 1, 2, (V[]){v_e_240, v_d_2413})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ewitnessMatches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ewitnessMatches_entry, 6, 0};

V g_heff_2eelab_2erules_2ewitnessMatches(V v_e_240, V v_sp_241, V v_goal_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_goal_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_w_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    HEFF_LAST return g_heff_2eelab_2erules_2efits(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_goal_242), v_w_246, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam0, 1, 6, (V[]){v_e_240, v_sp_241, v_goal_242, v_rest_247, v_p_244, v_p_245}));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2ewitnessMatches_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ewitnessMatches(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_x_2412 = v_x_2410;
    break;
  }
  case TAG_Just: {
    V v_f_2411 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    v_x_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2411, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V f_ = v_p_245;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ewitnessMatches_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_goal_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_249 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ewitnessMatches_clo), 4, (V[]){v_e_240, v_sp_241, v_goal_242, v_rest_247}));
  V f_ = v_c_249;
  heff_room[0] = v_p_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ewitnessMatches_lam1, 1, 2, (V[]){v_x_248, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str1, 3, " : ");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str2, 6, "found ");
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ecommitted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_lam0, 1, 0};
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecommitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_entry, 8, 0};

V g_heff_2eelab_2erules_2ecommitted(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_fit_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2ecommitted_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam1, 1, 8, (V[]){v_fit_245, v_hd_246, v_e_240, v_hm_242, v_holeVal_243, v_sp_241, v_k_247, v_goal_244})});
}
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecommitted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args) {
  V v_u_2429 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2429);
  V v_t_2430 = heff_get_n(heff_get_n(v_fit_245, 0, 3), 0, 6);
  V v_t_2431 = heff_tr(heff_call(v_t_2430, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2432 = ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  V v_t_2433 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2eelab_2erules_2ecommitted_str1), v_t_2432));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2ecommitted_str2), v_t_2433);
}
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_fit_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V f_ = v_k_247;
  args[0] = heff_get_n(v_fit_245, 1, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_fit_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_goal_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_err_2427 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_goal_244);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = heff_get_n(v_fit_245, 0, 3); V a_3 = v_err_2427; V a_4 = v_hd_246; V a_5 = v_k_247; V r_ = (g_heff_2eelab_2erules_2emisfit(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_err_2427); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2426, 0ULL, 1);
    V v_t_2434 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2ecommitted_str0), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam4, 1, 4, (V[]){heff_dup(v_fit_245), v_e_240, v_x_2412, v_goal_244})}), NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2435;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam5, 1, 2, (V[]){v_k_247, v_fit_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_fit_245 = heff_env(self)[1];
  V v_hm_242 = heff_env(self)[2];
  V v_holeVal_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_goal_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2416);
  V v_c_2417 = heff_dup(heff_rfield(v_e_240, 0));
  V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_fit_245, 1)), 0, 3);
  V v_x1_2419 = heff_tr(heff_call(heff_get_n(v_t_2418, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nom: {
    V v_x_2420 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = v_x_2420;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2419, 0ULL, 1);
    v_t_2423 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2422 = heff_field(v_x1_2419, 0);
    heff_take_n(v_x1_2419, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x1_2419);
  }
  V v_t_2424 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2417, 0), heff_get_n(v_c_2417, 1, 4)});
  V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_fit_245, 1)), 0, 3);
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), v_t_2424, v_hm_242, v_holeVal_243, heff_get_n(v_t_2425, 0, 2), v_t_2423, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam3, 1, 7, (V[]){v_e_240, v_sp_241, v_fit_245, v_hd_246, v_k_247, v_x_2412, v_goal_244})));
}
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hm_242 = heff_env(self)[3];
  V v_holeVal_243 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_goal_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_Put, 2, (V[]){heff_dup(heff_rfield(v_fit_245, 2)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam2, 1, 9, (V[]){v_e_240, v_fit_245, v_hm_242, v_holeVal_243, v_hd_246, v_sp_241, v_k_247, v_x_2412, v_goal_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str0, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str1, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str4, 52, "an instance argument's type is not determined here: ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str5, 79, "give the argument explicitly, or annotate so the implicits around it are solved");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str6, 201, "an instance's instance arguments are found by searches of their own, and one that wants an instance of a type no smaller than its own may want them without end: give the argument explicitly, `(x := e)`");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str7, 20, "an instance argument");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str8, 16, "no instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str9, 39, ", where one in scope does not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str10, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str11, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str13, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str14, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str15, 16, "no instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str16, 103, "declare one, `instance x : T`, bind one, `{{x : T}} -> ...`, where this is used, or give it: `(x := e)`");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str17, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str18, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str19, 1, "]");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str20, 6, "  [by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str21, 7, "wanted ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str22, 5, " for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str23, 12, ", wanted by ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str24, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str25, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str26, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str27, 1, ")");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str28, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str29, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str30, 2, ": ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str31, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str32, 27, "more than one instance for ");
HEFF_LIT(g_heff_2eelab_2erules_2eresolveWanted_str33, 100, "they cannot be told apart by type (small values are statically opaque): give the argument explicitly");
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam0, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2eresolveWanted_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_lam10, 1, 0};
V g_heff_2eelab_2erules_2eresolveWanted_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eresolveWanted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresolveWanted_entry, 9, 0};

V g_heff_2eelab_2erules_2eresolveWanted(V v_e_240, V v_sp_241, V v_search_242, V v_hm_243, V v_holeVal_244, V v_goal_245, V v_final_246, V v_hd_247, V v_k_248) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_hd_247, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam1, 1, 9, (V[]){v_e_240, v_goal_245, v_final_246, v_search_242, v_sp_241, v_hd_247, v_k_248, v_hm_243, v_holeVal_244})});
}
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eresolveWanted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 8);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam2(V self, V *args) {
  V v_w_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = heff_take_field(v_w_2422, 1); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2424 = heff_strAppend(heff_get_n(v_w_2422, 0, 2), heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str0), v_t_2423));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str1), v_t_2424);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam4(V self, V *args) {
  V v_u_2443 = args[0];
  V v_c_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2443);
  return heff_get_n(v_c_2440, 0, 3);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam3(V self, V *args) {
  V v_c_2440 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_stx_2442 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_t_2441, heff_dup(heff_rfield(v_c_2440, 2))));
  return heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam4, 1, 1, (V[]){heff_dup(v_c_2440)}), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str7), NTAG(TAG_False), heff_dup(heff_rfield(v_c_2440, 1)), v_stx_2442, heff_get_n(v_c_2440, 2, 3)});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam5(V self, V *args) {
  V v_i_2447 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erules_2einstGlobal(v_e_240, v_i_2447));
}
V g_heff_2eelab_2erules_2eresolveWanted_lam7(V self, V *args) {
  V v_w_2460 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = heff_take_field(v_w_2460, 1); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2462 = heff_strAppend(heff_get_n(v_w_2460, 0, 2), heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str10), v_t_2461));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str11), v_t_2462);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam10(V self, V *args) {
  V v_c_2479 = args[0];
  return heff_get_n(v_c_2479, 3, 8);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam12(V self, V *args) {
  V v_u_2484 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2483 = heff_env(self)[1];
  V v_sg_2476 = heff_env(self)[2];
  V v_one_2473 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_goal_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_u_2484);
  V v_t_2485 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_x_2483; V a_2 = heff_get_n(v_sg_2476, 1, 2); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2483); r_; });
  V v_t_2486 = heff_get_n(heff_get_n(v_one_2473, 0, 3), 0, 6);
  V v_t_2487 = heff_tr(heff_call(v_t_2486, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2488 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2489 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str18), heff_strAppend(v_t_2488, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str19)));
  V v_t_2490 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str20), heff_strAppend(v_t_2487, v_t_2489));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str21), heff_strAppend(v_t_2485, v_t_2490));
}
V g_heff_2eelab_2erules_2eresolveWanted_lam15(V self, V *args) {
  V v_b_24138 = args[0];
  V v_search_242 = heff_env(self)[0];
  V v_one_2473 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_sg_2476 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_hd_2477 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24139 = heff_intAdd(heff_take_field(v_search_242, 0), MK_INT(1LL));
  V v_t_24140 = heff_get_n(heff_get_n(v_one_2473, 0, 3), 0, 6);
  V v_t_24141 = heff_tr(heff_call(v_t_24140, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24142 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_24141, v_goal_245}), heff_get_n(v_search_242, 1, 2)});
  V v_t_24143 = heff_get_n(heff_dup(heff_rfield(v_sg_2476, 0)), 0, 2);
  V v_t_24179;
  switch (heff_tag_of(v_t_24143)) {
  case TAG_SLocal: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_24143, 0ULL, 3);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_24168 = heff_field(v_t_24143, 0);
    heff_take_n(v_t_24143, 1ULL, 3);
    v_t_24179 = v_k_24168;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_24143, 0ULL, 2);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_24143, 0ULL, 1);
    v_t_24179 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_24143);
  }
  V v_t_24180 = heff_get_n(heff_dup(heff_rfield(v_sg_2476, 0)), 1, 2);
  V v_c_24181 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 7, (V[]){v_e_240, v_sp_241, heff_rec_n(2, shape_depth__wantedBy, (V[]){v_t_24139, v_t_24142}), v_t_24179, v_t_24180, heff_get_n(v_sg_2476, 1, 2), v_b_24138}));
  V f_ = v_c_24181;
  heff_room[0] = heff_dup(v_hd_2477);
  heff_room[1] = heff_get_n(v_hd_2477, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam14(V self, V *args) {
  V v_x_24137 = args[0];
  V v_k_2478 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_search_242 = heff_env(self)[2];
  V v_one_2473 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_sg_2476 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_hd_2477 = heff_env(self)[7];
  heff_clo_take(self, 8);
  if ((heff_dup(v_x_24137) == NTAG(TAG_True))) {
    heff_drop(v_x_24137);
    heff_drop(v_sp_241);
    heff_drop_rec(v_search_242, 2);
    heff_drop_rec(v_one_2473, 3);
    heff_drop(v_goal_245);
    heff_drop_rec(v_sg_2476, 2);
    heff_drop_rec(v_e_240, 6);
    heff_drop_rec(v_hd_2477, 3);
    V f_ = v_k_2478;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24137);
    V v_t_24182 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam15, 1, 7, (V[]){v_search_242, v_one_2473, v_goal_245, v_sg_2476, v_e_240, v_sp_241, heff_dup(v_hd_2477)}), NTAG(TAG_MkUnit)});
    V v_t_24183 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24182})});
    V v_t_24184 = heff_tr(heff_call(heff_take_field(v_hd_2477, 2), 1, (V[]){v_t_24183}));
    V f_ = heff_get_n(v_hd_2477, 1, 3);
    heff_room[0] = v_t_24184;
    heff_room[1] = v_k_2478;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam13(V self, V *args) {
  V v_x_2493 = args[0];
  V v_search_242 = heff_env(self)[0];
  V v_one_2473 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_sg_2476 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  V v_hd_2477 = heff_env(self)[7];
  V v_k_2478 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2493);
  V v_t_2494 = heff_intAdd(heff_dup(heff_rfield(v_search_242, 0)), MK_INT(1LL));
  V v_t_2495 = heff_get_n(heff_dup(heff_rfield(v_one_2473, 0)), 0, 6);
  V v_t_2496 = heff_tr(heff_call(v_t_2495, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__goal, (V[]){v_t_2496, heff_dup(v_goal_245)}), heff_dup(heff_rfield(v_search_242, 1))});
  V v_t_2498 = heff_get_n(heff_dup(heff_rfield(v_sg_2476, 0)), 0, 2);
  V v_t_24134;
  switch (heff_tag_of(v_t_2498)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2498, 0ULL, 3);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_24123 = heff_field(v_t_2498, 0);
    heff_take_n(v_t_2498, 1ULL, 3);
    v_t_24134 = v_k_24123;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2498, 0ULL, 2);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_2498, 0ULL, 1);
    v_t_24134 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2498);
  }
  V v_t_24135 = heff_get_n(heff_dup(heff_rfield(v_sg_2476, 0)), 1, 2);
  V v_c_24136 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eresolveWanted_clo), 7, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_rec_n(2, shape_depth__wantedBy, (V[]){v_t_2494, v_t_2497}), v_t_24134, v_t_24135, heff_dup(heff_rfield(v_sg_2476, 1)), v_final_246}));
  V f_ = v_c_24136;
  heff_room[0] = heff_dup(v_hd_2477);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam14, 1, 8, (V[]){v_k_2478, v_sp_241, v_search_242, v_one_2473, v_goal_245, v_sg_2476, v_e_240, v_hd_2477});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam11(V self, V *args) {
  V v_x_2483 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sg_2476 = heff_env(self)[2];
  V v_one_2473 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_goal_245 = heff_env(self)[5];
  V v_hd_2477 = heff_env(self)[6];
  V v_search_242 = heff_env(self)[7];
  V v_final_246 = heff_env(self)[8];
  V v_k_2478 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2491 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_241), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str17), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam12, 1, 6, (V[]){heff_dup(v_e_240), v_x_2483, heff_dup(v_sg_2476), heff_dup(v_one_2473), v_x_2413, heff_dup(v_goal_245)})}), NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2477, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})}));
  V f_ = heff_dup(heff_rfield(v_hd_2477, 1));
  heff_room[0] = v_t_2492;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam13, 1, 9, (V[]){v_search_242, v_one_2473, v_goal_245, v_sg_2476, v_e_240, v_sp_241, v_final_246, v_hd_2477, v_k_2478});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam9(V self, V *args) {
  V v_sg_2476 = args[0];
  V v_hd_2477 = args[1];
  V v_k_2478 = args[2];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_2473 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_search_242 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_lam10_clo)})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2477, 2)), 1, (V[]){v_t_2481}));
  V f_ = heff_dup(heff_rfield(v_hd_2477, 1));
  args[0] = v_t_2482;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam11, 1, 10, (V[]){v_sp_241, v_e_240, v_sg_2476, v_one_2473, v_x_2413, v_goal_245, v_hd_2477, v_search_242, v_final_246, v_k_2478});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam16(V self, V *args) {
  V v_x_24186 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24186);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam8(V self, V *args) {
  V v_x_2475 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_one_2473 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_goal_245 = heff_env(self)[4];
  V v_search_242 = heff_env(self)[5];
  V v_final_246 = heff_env(self)[6];
  V v_hd_247 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_24185 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam9, 3, 7, (V[]){v_sp_241, v_e_240, v_one_2473, v_x_2413, v_goal_245, v_search_242, v_final_246}); V b_1 = heff_get_n(v_x_2475, 2, 3); V r_ = (g_heff_2eelab_2erules_2eeachSubgoal(a_0, b_1)); heff_drop(b_1); r_; });
  V f_ = v_c_24185;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam16, 1, 1, (V[]){v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eresolveWanted_lam17(V self, V *args) {
  V v_w_24190 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24191 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = heff_take_field(v_w_24190, 1); V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_24192 = heff_strAppend(heff_get_n(v_w_24190, 0, 2), heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str22), v_t_24191));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str23), v_t_24192);
}
V g_heff_2eelab_2erules_2eresolveWanted_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_goal_245 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_search_242 = heff_env(self)[6];
  V v_hm_243 = heff_env(self)[7];
  V v_holeVal_244 = heff_env(self)[8];
  V v_final_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2451)) {
  case TAG_Nil: {
    heff_drop(v_hm_243);
    heff_drop(v_holeVal_244);
    heff_drop(v_final_246);
    V v_t_2452 = (g_heff_2eelab_2erules_2ebrokenInstanceIn(heff_dup(v_e_240)));
    if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
      heff_drop_rec(v_search_242, 2);
      heff_drop(v_t_2452);
      V v_t_2453 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
      V v_msg_2454 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str8), heff_strAppend(v_t_2453, ((V)&g_heff_2eelab_2erules_2eresolveWanted_str9)));
      V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_msg_2454, v_sp_241, NTAG(TAG_Nothing)});
      V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2457}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2458;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2452);
      V v_t_2459 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
      V v_x2_2463 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam7, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
      V v_t_2466;
      switch (heff_tag_of(v_x2_2463)) {
      case TAG_Nil: {
        v_t_2466 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2464 = heff_field(v_x2_2463, 0);
        V v_xs_2465 = heff_field(v_x2_2463, 1);
        heff_take_n(v_x2_2463, 3ULL, 2);
        v_t_2466 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str13); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2463);
      }
      V v_t_2467 = heff_strAppend(v_t_2459, heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str14), v_t_2466));
      V v_msg_2468 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str15), v_t_2467);
      V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(341LL), NTAG(TAG_SError), v_msg_2468, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str16)})});
      V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2471}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2472;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Cons: {
    V v_one_2473 = heff_dup(heff_field(v_x_2451, 0));
    V v_it2_2474 = heff_dup(heff_field(v_x_2451, 1));
    switch (heff_tag_of(v_it2_2474)) {
    case TAG_Nil: {
      heff_drop_tag(v_x_2451, 2);
      return (g_heff_2eelab_2erules_2ecommitted(heff_dup(v_e_240), heff_dup(v_sp_241), v_hm_243, v_holeVal_244, heff_dup(v_goal_245), heff_dup(v_one_2473), heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam8, 1, 9, (V[]){v_sp_241, v_e_240, v_one_2473, v_x_2413, v_goal_245, v_search_242, v_final_246, v_hd_247, v_k_248})));
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2474, 0ULL, 2);
      heff_drop(v_hm_243);
      heff_drop(v_holeVal_244);
      heff_drop(v_final_246);
      heff_drop_rec(v_one_2473, 3);
      V v_t_24189 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
      V v_x2_24193 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam17, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
      V v_t_24196;
      switch (heff_tag_of(v_x2_24193)) {
      case TAG_Nil: {
        v_t_24196 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str24);
        break;
      }
      case TAG_Cons: {
        V v_x_24194 = heff_field(v_x2_24193, 0);
        V v_xs_24195 = heff_field(v_x2_24193, 1);
        heff_take_n(v_x2_24193, 3ULL, 2);
        v_t_24196 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str25); V a_1 = v_x_24194; V a_2 = v_xs_24195; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24195); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24193);
      }
      V v_x2_24197 = (g_list_2emap_24s1049333826x1545174117(((V)&g_heff_2eelab_2erules_2eresolveWanted_str26), ((V)&g_heff_2eelab_2erules_2eresolveWanted_str27), v_x_2451));
      V v_t_24200;
      switch (heff_tag_of(v_x2_24197)) {
      case TAG_Nil: {
        v_t_24200 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str28);
        break;
      }
      case TAG_Cons: {
        V v_x_24198 = heff_field(v_x2_24197, 0);
        V v_xs_24199 = heff_field(v_x2_24197, 1);
        heff_take_n(v_x2_24197, 3ULL, 2);
        v_t_24200 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str29); V a_1 = v_x_24198; V a_2 = v_xs_24199; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24199); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24197);
      }
      V v_t_24201 = heff_strAppend(v_t_24196, heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str30), v_t_24200));
      V v_t_24202 = heff_strAppend(v_t_24189, heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str31), v_t_24201));
      V v_msg_24203 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str32), v_t_24202);
      V v_t_24204 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(342LL), NTAG(TAG_SError), v_msg_24203, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str33)})});
      V v_t_24205 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24204})});
      V v_t_24206 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24205})});
      V v_t_24207 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24206}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24207;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it2_2474);
    }
  }
  default: return heff_nomatch(v_x_2451);
  }
}
V g_heff_2eelab_2erules_2eresolveWanted_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_245 = heff_env(self)[1];
  V v_final_246 = heff_env(self)[2];
  V v_search_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_hm_243 = heff_env(self)[7];
  V v_holeVal_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = (g_heff_2eelab_2eunify_2emetasK(v_x_2413));
  V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_x1_2416 = heff_tr(heff_call(heff_get_n(v_t_2414, 1, 3), 3, (V[]){MK_INT(20LL), v_t_2415, heff_dup(v_goal_245)}));
  V v_x1_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nil: {
    v_x1_2419 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2416, 0ULL, 2);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = heff_bool(!(heff_dup(v_x1_2419) == NTAG(TAG_True)));
  heff_drop(v_x1_2419);
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_hm_243);
    heff_drop(v_holeVal_244);
    heff_drop(v_t_2420);
    if ((heff_dup(v_final_246) == NTAG(TAG_True))) {
      heff_drop(v_final_246);
      V v_t_2421 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2413, v_goal_245));
      V v_x2_2425 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam2, 1, 2, (V[]){v_e_240, v_x_2413}), heff_get_n(v_search_242, 1, 2)));
      V v_t_2428;
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nil: {
        v_t_2428 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        V v_xs_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        v_t_2428 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eresolveWanted_str3); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2425);
      }
      V v_msg_2429 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresolveWanted_str4), heff_strAppend(v_t_2421, v_t_2428));
      V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(340LL), NTAG(TAG_SError), v_msg_2429, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str5)})});
      V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2432}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2433;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_2413);
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_goal_245);
      heff_drop(v_final_246);
      heff_drop_rec(v_search_242, 2);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_247, 3);
      V f_ = v_k_248;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_t_2420);
    if (heff_intLt_c(heff_dup(g_heff_2eelab_2erules_2einstanceDepthLimit_get()), heff_dup(heff_rfield(v_search_242, 0)))) {
      heff_drop(v_final_246);
      heff_drop(v_hm_243);
      heff_drop(v_holeVal_244);
      V v_msg_2435 = ({ V a_0 = v_e_240; V a_1 = v_x_2413; V a_2 = v_search_242; V a_3 = v_goal_245; V r_ = (g_heff_2eelab_2erules_2etooDeep(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
      V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(349LL), NTAG(TAG_SError), v_msg_2435, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eresolveWanted_str6)})});
      V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2438}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_2439;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_t_2444 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam3, 1, 1, (V[]){heff_dup(v_e_240)}), heff_dup(heff_rfield(v_e_240, 5))));
      V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 6, 7);
      V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2445));
      V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam5, 1, 1, (V[]){heff_dup(v_e_240)}), v_t_2446));
      V v_t_2449 = (g_heff_2eelab_2erules_2ecatMaybesR(v_t_2448));
      V v_t_2450 = (g_prelude_2e_2b_2b(v_t_2444, v_t_2449));
      return (g_heff_2eelab_2erules_2ewitnessMatches(heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_goal_245), v_t_2450, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2eresolveWanted_lam6, 1, 10, (V[]){v_e_240, v_x_2413, v_goal_245, v_sp_241, v_hd_247, v_k_248, v_search_242, v_hm_243, v_holeVal_244, v_final_246})));
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str0, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str4, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str5, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str6, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str7, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str8, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str9, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str10, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str11, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_str12, 57, "tried to check a lambda expression at a non-function type");
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam13(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroAnn_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionIntroAnn(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam0, 4, 4, (V[]){v_sp_240, heff_dup(v_dom_242), v_x_241, heff_dup(v_body_243)})});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2efunctionIntroAnn(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam7(V self, V *args) {
  V v_u_2457 = args[0];
  V v_v_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2457);
  return v_v_2446;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam10(V self, V *args) {
  V v_u_2476 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2476);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2467 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2469 = heff_take_field(v_e_244, 2);
  V v_t_2472;
  switch (heff_tag_of(v_t_2469)) {
  case TAG_ForNominative: {
    v_t_2472 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2469, 0ULL, 2);
    v_t_2472 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2469);
  }
  V v_t_2473 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2474 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_2475 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2474, heff_dup(v_x_2412)));
  V v_x_2477 = (g_heff_2eelab_2ememoed_2elam(v_t_2472, heff_get_n(v_e_244, 1, 6), v_t_2473, heff_rec_n(2, shape_stx__val, (V[]){v_t_2475, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam10, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2468})));
  V f_ = v_k_2467;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam8(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2465;
  args[0] = v_hd_2466;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam9, 1, 4, (V[]){v_e_244, v_x_2412, v_x_241, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam6(V self, V *args) {
  V v_v_2446 = args[0];
  V v_scope_27_2447 = args[1];
  V v_e_244 = heff_env(self)[0];
  V v_cod_2421 = heff_env(self)[1];
  V v_body_243 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2448 = heff_dup(heff_rfield(v_e_244, 2));
  V v_t_2451;
  switch (heff_tag_of(v_t_2448)) {
  case TAG_ForNominative: {
    v_t_2451 = NTAG(TAG_ForNominative);
    break;
  }
  case TAG_ForDescriptive: {
    V v_h_2449 = heff_field(v_t_2448, 0);
    V v_sp_2450 = heff_field(v_t_2448, 1);
    V v_ru_24t_2448_24ForDescriptive = heff_take_reuse_n(v_t_2448, 3ULL, 2);
    v_t_2451 = heff_tag_at_n(v_ru_24t_2448_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2449, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2450, heff_dup(v_v_2446)})});
    break;
  }
  default: heff_nomatch(v_t_2448);
  }
  V v_t_2452 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
  V v_e_2453 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2447, heff_dup(heff_rfield(v_e_244, 1)), v_t_2451, v_t_2452, heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
  V v_x1_2459;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2455 = heff_field(v_cod_2421, 1);
    V v_body_2456 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2459 = heff_tr(heff_call(v_body_2456, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2455, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam7, 1, 1, (V[]){v_v_2446})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2458 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    heff_drop(v_v_2446);
    v_x1_2459 = v_body_2458;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_2463;
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_Nom: {
    V v_x_2460 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    v_a_2463 = v_x_2460;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2459, 0ULL, 1);
    v_a_2463 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2462 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    v_a_2463 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_x1_2459);
  }
  V v_c_2465;
  switch (heff_tag_of(v_body_243)) {
  case TAG_MkChk: {
    V v_f_2464 = heff_field(v_body_243, 0);
    heff_take_n(v_body_243, 1ULL, 1);
    v_c_2465 = heff_tr(heff_call(v_f_2464, 2, (V[]){v_e_2453, v_a_2463}));
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam8, 2, 4, (V[]){v_c_2465, v_e_244, v_x_2412, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  V v_body_243 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_z_2437 = heff_env(self)[6];
  V v_z_2438 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2440);
  V v_x1_2441 = heff_tr(heff_call(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_t_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_t_2478 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_t_2445, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam6, 2, 5, (V[]){v_e_244, v_cod_2421, v_body_243, v_x_2412, v_x_241})));
  V f_ = v_t_2478;
  heff_room[0] = v_z_2437;
  heff_room[1] = v_z_2438;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam4(V self, V *args) {
  V v_agree_2436 = args[0];
  V v_z_2437 = args[1];
  V v_z_2438 = args[2];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2439 = (g_heff_2eelab_2erules_2erequireAgree(heff_dup(v_e_244), v_sp_240, v_agree_2436));
  V f_ = v_c_2439;
  args[0] = heff_dup(v_z_2437);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam5, 1, 8, (V[]){v_x_2426, v_x_241, v_e_244, v_cod_2421, v_body_243, v_x_2412, v_z_2437, v_z_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_fdom_2420 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2427 = heff_dup(heff_rfield(v_e_244, 0));
  V v_x1_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2426, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_b_2432;
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_Nom: {
    V v_x_2429 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    v_b_2432 = v_x_2429;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    v_b_2432 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2431 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    v_b_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x1_2428);
  }
  V v_t_2433 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2427, 0), heff_get_n(v_c_2427, 1, 4)});
  V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_dup(heff_rfield(v_e_244, 1)), v_t_2433, v_fdom_2420, v_b_2432}));
  V v_t_2435 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_2434}));
  return (g_co_2ebind_24s1601686549x58384075(v_t_2435, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam4, 3, 7, (V[]){v_e_244, v_sp_240, v_x_2426, v_x_241, v_cod_2421, v_body_243, v_x_2412}), v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam12(V self, V *args) {
  V v_u_2496 = args[0];
  V v_v_2484 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2496);
  return v_v_2484;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam15(V self, V *args) {
  V v_u_24120 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24120);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam14(V self, V *args) {
  V v_x_24107 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_cod_2421 = heff_env(self)[2];
  V v_k_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24108 = heff_take_field(v_e_244, 2);
  V v_t_24111;
  switch (heff_tag_of(v_t_24108)) {
  case TAG_ForNominative: {
    v_t_24111 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_24108, 0ULL, 2);
    v_t_24111 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_24108);
  }
  V v_t_24112 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_24113 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_24114 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_24113, heff_dup(v_x_2412)));
  V v_t_24119;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_24115 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 3);
    v_t_24119 = v_n_24115;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2421, 0ULL, 1);
    v_t_24119 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str3);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_x_24121 = (g_heff_2eelab_2ememoed_2elam(v_t_24111, heff_get_n(v_e_244, 1, 6), v_t_24112, heff_rec_n(2, shape_stx__val, (V[]){v_t_24114, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam15, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_24119, v_x_24107})));
  V f_ = v_k_24106;
  args[0] = v_x_24121;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam13(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k_24106 = args[1];
  V v_c_24104 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24104;
  args[0] = v_hd_24105;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam14, 1, 4, (V[]){v_e_244, v_x_2412, v_cod_2421, v_k_24106});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam11(V self, V *args) {
  V v_v_2484 = args[0];
  V v_scope_27_2485 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_dom_242 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_implicit_2422 = heff_env(self)[6];
  V v_fdom_2420 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x1_2486 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_dom_242; V a_3 = v_body_243; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_dom_242); heff_drop(v_body_243); r_; });
  V v_t_2491;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_2487 = heff_dup(heff_field(v_cod_2421, 0));
    v_t_2491 = v_n_2487;
    break;
  }
  case TAG_CloConst: {
    v_t_2491 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str2);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_e_2492 = ({ V a_0 = heff_dup(v_e_244); V a_1 = v_implicit_2422; V a_2 = v_t_2491; V a_3 = v_fdom_2420; V a_4 = v_scope_27_2485; V a_5 = heff_dup(v_v_2484); V b_6 = NTAG(TAG_True); V r_ = (g_heff_2eelab_2erules_2eintoSilent(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_implicit_2422); heff_drop(b_6); r_; });
  V v_x1_2498;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2494 = heff_dup(heff_field(v_cod_2421, 1));
    V v_body_2495 = heff_dup(heff_field(v_cod_2421, 2));
    v_x1_2498 = heff_tr(heff_call(v_body_2495, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2494, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam12, 1, 1, (V[]){v_v_2484})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2497 = heff_dup(heff_field(v_cod_2421, 0));
    heff_drop(v_v_2484);
    v_x1_2498 = v_body_2497;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_24102;
  switch (heff_tag_of(v_x1_2498)) {
  case TAG_Nom: {
    V v_x_2499 = heff_field(v_x1_2498, 0);
    heff_take_n(v_x1_2498, 1ULL, 1);
    v_a_24102 = v_x_2499;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_a_24102 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24101 = heff_field(v_x1_2498, 0);
    heff_take_n(v_x1_2498, 1ULL, 1);
    v_a_24102 = v_x_24101;
    break;
  }
  default: heff_nomatch(v_x1_2498);
  }
  V v_c_24104;
  switch (heff_tag_of(v_x1_2486)) {
  case TAG_MkChk: {
    V v_f_24103 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 1);
    v_c_24104 = heff_tr(heff_call(v_f_24103, 2, (V[]){v_e_2492, v_a_24102}));
    break;
  }
  default: heff_nomatch(v_x1_2486);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam13, 2, 4, (V[]){v_c_24104, v_e_244, v_x_2412, v_cod_2421});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_dom_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2417}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2418;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_fdom_2420 = heff_field(v_t_2413, 1);
    V v_cod_2421 = heff_field(v_t_2413, 2);
    V v_implicit_2422 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      v_t_2423 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_implicit_2422);
      heff_drop(v_t_2423);
      V v_c_2425;
      switch (heff_tag_of(v_dom_242)) {
      case TAG_MkTyp: {
        V v_f_2424 = heff_field(v_dom_242, 0);
        heff_take_n(v_dom_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_call(v_f_2424, 1, (V[]){heff_dup(v_e_244)}));
        break;
      }
      default: heff_nomatch(v_dom_242);
      }
      V f_ = v_c_2425;
      heff_room[0] = heff_dup(v_hd_246);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam3, 1, 9, (V[]){v_e_244, v_fdom_2420, v_sp_240, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_hd_246, v_k_247});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2423);
      V v_t_2483;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2479 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2483 = v_n_2479;
        break;
      }
      case TAG_CloConst: {
        v_t_2483 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str1);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_t_24122 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2483, heff_dup(v_fdom_2420), heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam11, 2, 9, (V[]){v_sp_240, v_x_241, v_dom_242, v_body_243, v_cod_2421, v_e_244, v_implicit_2422, v_fdom_2420, v_x_2412})));
      V f_ = v_t_24122;
      heff_room[0] = v_hd_246;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24127 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24126})});
    V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
    V v_t_24129 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24128}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24129;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24131 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24132 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24131})});
    V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24133}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24134;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
    V v_t_24138 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24137}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24138;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24139})});
    V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
    V v_t_24142 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24141}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24142;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24143 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24143})});
    V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24145}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24146;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24147 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24148 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
    V v_t_24150 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24149}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24150;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24152 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24153 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24152})});
    V v_t_24154 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
    V v_t_24155 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24154}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24155;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24158 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24157})});
    V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
    V v_t_24160 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24159}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24160;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24161 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24162 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24161})});
    V v_t_24163 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24162})});
    V v_t_24164 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24163}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24164;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_lam2, 1, 7, (V[]){v_sp_240, v_hd_246, v_k_247, v_dom_242, v_e_244, v_x_241, v_body_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_str3, 1, "_");
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2enamedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedGo_entry, 8, 0};

V g_heff_2eelab_2erules_2enamedGo(V v_sp_240, V v_x_241, V v_arg_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam0, 1, 1, (V[]){v_ty0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam1, 1, 7, (V[]){v_sp_240, v_x_241, v_hd_246, v_k_247, heff_dup(v_arg_242), v_e_243, v_m_244})});
}
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2enamedGo(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2enamedGo_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_ty0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_ty0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_call(heff_get_n(v_x_2428, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_implicit_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_cod_2417 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429;
  switch (heff_tag_of(v_implicit_2418)) {
  case TAG_Expl: {
    heff_drop(v_x_241);
    v_t_2429 = (g_heff_2eelab_2ememoed_2eapp(v_m_244, heff_dup(v_x_2428)));
    break;
  }
  case TAG_Impl: {
    v_t_2429 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2428)));
    break;
  }
  case TAG_Inst: {
    v_t_2429 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2428)));
    break;
  }
  default: heff_nomatch(v_implicit_2418);
  }
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2431 = heff_field(v_cod_2417, 1);
    V v_body_2432 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_call(v_body_2432, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam3, 1, 1, (V[]){v_x_2428})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2428, 2);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  V v_x_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_t_2443});
  V f_ = v_k_247;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enamedGo_lam5(V self, V *args) {
  V v_u_2462 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2462);
  V v_x1_2463 = heff_tr(heff_call(heff_get_n(v_x_2452, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_Nom: {
    V v_x_2464 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    return v_x_2464;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2466 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    return v_x_2466;
  }
  default: return heff_nomatch(v_x1_2463);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam4(V self, V *args) {
  V v_x_2452 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2457;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2453 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2457 = v_n_2453;
    break;
  }
  case TAG_CloConst: {
    v_t_2457 = ((V)&g_heff_2eelab_2erules_2enamedGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2458 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2457, v_m_244, heff_dup(v_x_2452)));
  V v_x1_2468;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2460 = heff_field(v_cod_2417, 1);
    V v_body_2461 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2468 = heff_tr(heff_call(v_body_2461, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2460, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam5, 1, 1, (V[]){v_x_2452})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2467 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2452, 2);
    v_x1_2468 = v_body_2467;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2472;
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_Nom: {
    V v_x_2469 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_t_2472 = v_x_2469;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2468, 0ULL, 1);
    v_t_2472 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2471 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_t_2472 = v_x_2471;
    break;
  }
  default: heff_nomatch(v_x1_2468);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2458; V a_5 = v_t_2472; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam7(V self, V *args) {
  V v_u_2489 = args[0];
  V v_x_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2489);
  V v_x1_2490 = heff_tr(heff_call(heff_get_n(v_x_2479, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2490)) {
  case TAG_Nom: {
    V v_x_2491 = heff_field(v_x1_2490, 0);
    heff_take_n(v_x1_2490, 1ULL, 1);
    return v_x_2491;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2490, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2493 = heff_field(v_x1_2490, 0);
    heff_take_n(v_x1_2490, 1ULL, 1);
    return v_x_2493;
  }
  default: return heff_nomatch(v_x1_2490);
  }
}
V g_heff_2eelab_2erules_2enamedGo_lam6(V self, V *args) {
  V v_x_2479 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2484;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2480 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2484 = v_n_2480;
    break;
  }
  case TAG_CloConst: {
    v_t_2484 = ((V)&g_heff_2eelab_2erules_2enamedGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2485 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2484, v_m_244, heff_dup(v_x_2479)));
  V v_x1_2495;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2487 = heff_field(v_cod_2417, 1);
    V v_body_2488 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2495 = heff_tr(heff_call(v_body_2488, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2487, heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam7, 1, 1, (V[]){v_x_2479})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2494 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2479, 2);
    v_x1_2495 = v_body_2494;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2499;
  switch (heff_tag_of(v_x1_2495)) {
  case TAG_Nom: {
    V v_x_2496 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    v_t_2499 = v_x_2496;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2495, 0ULL, 1);
    v_t_2499 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2498 = heff_field(v_x1_2495, 0);
    heff_take_n(v_x1_2495, 1ULL, 1);
    v_t_2499 = v_x_2498;
    break;
  }
  default: heff_nomatch(v_x1_2495);
  }
  return ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_arg_242; V a_3 = v_e_243; V a_4 = v_t_2485; V a_5 = v_t_2499; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
}
V g_heff_2eelab_2erules_2enamedGo_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2413, 1);
    V v_cod_2417 = heff_field(v_t_2413, 2);
    V v_implicit_2418 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_x1_2423;
    switch (heff_tag_of(v_cod_2417)) {
    case TAG_MkClo: {
      V v_n_2419 = heff_dup(heff_field(v_cod_2417, 0));
      v_x1_2423 = heff_tag_n(TAG_Just, 1, (V[]){v_n_2419});
      break;
    }
    case TAG_CloConst: {
      v_x1_2423 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_cod_2417);
    }
    V v_t_2425;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Nothing: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_y_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      v_t_2425 = heff_strEq(v_y_2424, heff_dup(v_x_241));
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_sp_240);
      heff_drop(v_t_2425);
      V v_c_2427;
      switch (heff_tag_of(v_arg_242)) {
      case TAG_MkChk: {
        V v_f_2426 = heff_field(v_arg_242, 0);
        heff_take_n(v_arg_242, 1ULL, 1);
        v_c_2427 = heff_tr(heff_call(v_f_2426, 2, (V[]){v_e_243, v_dom_2416}));
        break;
      }
      default: heff_nomatch(v_arg_242);
      }
      V f_ = v_c_2427;
      heff_room[0] = v_hd_246;
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam2, 1, 5, (V[]){v_implicit_2418, v_m_244, v_x_241, v_cod_2417, v_k_247});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2425);
      V v_t_2445;
      switch (heff_tag_of(v_implicit_2418)) {
      case TAG_Expl: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_Impl: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_Inst: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_implicit_2418);
      }
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_implicit_2418);
        heff_drop(v_t_2445);
        V v_t_2450;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2446 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2450 = v_n_2446;
          break;
        }
        case TAG_CloConst: {
          v_t_2450 = ((V)&g_heff_2eelab_2erules_2enamedGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2451 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_243), heff_dup(v_sp_240), v_x_2412, v_dom_2416, v_t_2450));
        V f_ = v_c_2451;
        heff_room[0] = heff_dup(v_hd_246);
        heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam4, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_x_2412);
        heff_drop(v_t_2445);
        V v_t_2473;
        switch (heff_tag_of(v_implicit_2418)) {
        case TAG_Expl: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_Impl: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_Inst: {
          v_t_2473 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_implicit_2418);
        }
        if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
          heff_drop(v_t_2473);
          V v_t_2478;
          switch (heff_tag_of(v_cod_2417)) {
          case TAG_MkClo: {
            V v_n_2474 = heff_dup(heff_field(v_cod_2417, 0));
            v_t_2478 = v_n_2474;
            break;
          }
          case TAG_CloConst: {
            v_t_2478 = ((V)&g_heff_2eelab_2erules_2enamedGo_str2);
            break;
          }
          default: heff_nomatch(v_cod_2417);
          }
          return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_243), heff_dup(v_sp_240), v_dom_2416, v_t_2478, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2enamedGo_lam6, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_arg_242, v_e_243, v_hd_246, v_k_247})));
        } else {
          heff_drop(v_arg_242);
          heff_drop(v_e_243);
          heff_drop(v_m_244);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          heff_drop(v_t_2473);
          return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
      }
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_arg_242);
    heff_drop(v_e_243);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eelimGo_str0, 8, "argument");
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam20(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam21(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam19(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam23(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam24(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam22(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam26(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam27(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam25(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam29(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam30(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam28(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam32(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam33(V self, V *args);
V g_heff_2eelab_2erules_2eelimGo_lam31(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimGo_entry, 7, 0};

V g_heff_2eelab_2erules_2eelimGo(V v_checksOnly_240, V v_sp_241, V v_arg_242, V v_e_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_ecallee_247 = heff_field(v_x5_244, 0);
    V v_a_248 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_t_249 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_248)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_LikeU: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam0, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeFunction: {
      V v_dom_2418 = heff_field(v_t_249, 1);
      V v_cod_2419 = heff_field(v_t_249, 2);
      heff_take_n(v_t_249, 6ULL, 4);
      heff_drop(v_a_248);
      if ((heff_dup(v_checksOnly_240) == NTAG(TAG_True))) {
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam3, 1, 1, (V[]){heff_dup(v_dom_2418)})})});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2423}));
        return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2424, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam4, 1, 8, (V[]){v_e_243, v_ecallee_247, v_dom_2418, v_cod_2419, heff_dup(v_arg_242), v_z_245, v_z_246, v_sp_241})});
      } else {
        heff_drop(v_sp_241);
        return ({ V a_0 = v_e_243; V a_1 = v_ecallee_247; V a_2 = v_dom_2418; V a_3 = v_cod_2419; V a_4 = v_arg_242; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_cod_2419); r_; });
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_249, 0ULL, 3);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam7, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam10, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeInt: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam13, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeFloat: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam16, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeString: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam19, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeRune: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam22, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam25, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_249, 0ULL, 1);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam28, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    case TAG_NoRules: {
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_248), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam31, 1, 6, (V[]){v_z_245, v_z_246, v_a_248, v_e_243, v_sp_241, v_ecallee_247})));
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eelimGo(a0, a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eelimGo_lam1(V self, V *args) {
  V v_c_2412 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2412, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2416, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2411) == NTAG(TAG_True))) {
    heff_drop(v_x_2411);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2411);
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam1, 1, 1, (V[]){v_a_248})})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2414}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam2, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam3(V self, V *args) {
  V v_c_2421 = args[0];
  V v_dom_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2421, 3, 8); V a_1 = v_dom_2418; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam6(V self, V *args) {
  V v_u_2454 = args[0];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2454);
  V v_x1_2455 = heff_tr(heff_call(heff_get_n(v_x_2449, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Nom: {
    V v_x_2456 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2456;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2455, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2458 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2458;
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_ecallee_247 = heff_env(self)[0];
  V v_cod_2419 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2450 = (g_heff_2eelab_2ememoed_2eapp(v_ecallee_247, heff_dup(v_x_2449)));
  V v_x1_2460;
  switch (heff_tag_of(v_cod_2419)) {
  case TAG_MkClo: {
    V v_vs_2452 = heff_field(v_cod_2419, 1);
    V v_body_2453 = heff_field(v_cod_2419, 2);
    heff_take_n(v_cod_2419, 6ULL, 3);
    v_x1_2460 = heff_tr(heff_call(v_body_2453, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2452, heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam6, 1, 1, (V[]){v_x_2449})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2459 = heff_field(v_cod_2419, 0);
    heff_take_n(v_cod_2419, 1ULL, 1);
    heff_drop_rec(v_x_2449, 2);
    v_x1_2460 = v_body_2459;
    break;
  }
  default: heff_nomatch(v_cod_2419);
  }
  V v_t_2464;
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_Nom: {
    V v_x_2461 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    v_t_2464 = v_x_2461;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2460, 0ULL, 1);
    v_t_2464 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2463 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    v_t_2464 = v_x_2463;
    break;
  }
  default: heff_nomatch(v_x1_2460);
  }
  V v_x_2465 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, v_t_2464});
  V f_ = v_z_246;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimGo_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_ecallee_247 = heff_env(self)[1];
  V v_dom_2418 = heff_env(self)[2];
  V v_cod_2419 = heff_env(self)[3];
  V v_arg_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2447;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_VU: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2427 = heff_dup(heff_field(v_x_2425, 0));
    switch (heff_tag_of(v_t1_2427)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2427, 0ULL, 1);
      v_x1_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2427, 0ULL, 1);
      v_x1_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2427, 0ULL, 1);
      v_x1_2447 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_x1_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2427);
    }
    break;
  }
  case TAG_VFunction: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_x1_2447 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_t_2448 = heff_bool(!(heff_dup(v_x1_2447) == NTAG(TAG_True)));
  heff_drop(v_x1_2447);
  if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    heff_drop(v_sp_241);
    heff_drop(v_t_2448);
    return ({ V a_0 = v_e_243; V a_1 = v_ecallee_247; V a_2 = v_dom_2418; V a_3 = v_cod_2419; V a_4 = v_arg_242; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2erules_2eelimPlain(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_cod_2419); heff_drop(v_arg_242); r_; });
  } else {
    heff_drop(v_dom_2418);
    heff_drop(v_t_2448);
    return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2eelimGo_str0); V a_3 = v_arg_242; V a_4 = heff_dup(v_x_2425); V a_5 = v_x_2425; V a_6 = v_z_245; V a_7 = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam5, 1, 3, (V[]){v_ecallee_247, v_cod_2419, v_z_246}); V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_arg_242); r_; });
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam8(V self, V *args) {
  V v_c_2470 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2470, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2474, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam7(V self, V *args) {
  V v_x_2469 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2469) == NTAG(TAG_True))) {
    heff_drop(v_x_2469);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2469);
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam8, 1, 1, (V[]){v_a_248})})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2472}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2473;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam9, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam11(V self, V *args) {
  V v_c_2477 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2477, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam12(V self, V *args) {
  V v_x_2481 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2481, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam10(V self, V *args) {
  V v_x_2476 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2476) == NTAG(TAG_True))) {
    heff_drop(v_x_2476);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2476);
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam11, 1, 1, (V[]){v_a_248})})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2479}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2480;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam12, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam14(V self, V *args) {
  V v_c_2483 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2483, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam15(V self, V *args) {
  V v_x_2487 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2487, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam13(V self, V *args) {
  V v_x_2482 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2482) == NTAG(TAG_True))) {
    heff_drop(v_x_2482);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2482);
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam14, 1, 1, (V[]){v_a_248})})});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2485}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2486;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam15, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam17(V self, V *args) {
  V v_c_2489 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2489, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam18(V self, V *args) {
  V v_x_2493 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2493, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam16(V self, V *args) {
  V v_x_2488 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2488) == NTAG(TAG_True))) {
    heff_drop(v_x_2488);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2488);
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam17, 1, 1, (V[]){v_a_248})})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2491}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2492;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam18, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam20(V self, V *args) {
  V v_c_2495 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2495, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam21(V self, V *args) {
  V v_x_2499 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_2499, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam19(V self, V *args) {
  V v_x_2494 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2494) == NTAG(TAG_True))) {
    heff_drop(v_x_2494);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2494);
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam20, 1, 1, (V[]){v_a_248})})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2497}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2498;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam21, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam23(V self, V *args) {
  V v_c_24101 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24101, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam24(V self, V *args) {
  V v_x_24105 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24105, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam22(V self, V *args) {
  V v_x_24100 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24100) == NTAG(TAG_True))) {
    heff_drop(v_x_24100);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24100);
    V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam23, 1, 1, (V[]){v_a_248})})});
    V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24103}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24104;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam24, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam26(V self, V *args) {
  V v_c_24108 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24108, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam27(V self, V *args) {
  V v_x_24112 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24112, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam25(V self, V *args) {
  V v_x_24107 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24107) == NTAG(TAG_True))) {
    heff_drop(v_x_24107);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24107);
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam26, 1, 1, (V[]){v_a_248})})});
    V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24110}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24111;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam27, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam29(V self, V *args) {
  V v_c_24115 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24115, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam30(V self, V *args) {
  V v_x_24119 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24119, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam28(V self, V *args) {
  V v_x_24114 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24114) == NTAG(TAG_True))) {
    heff_drop(v_x_24114);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24114);
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam29, 1, 1, (V[]){v_a_248})})});
    V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24117}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24118;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam30, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eelimGo_lam32(V self, V *args) {
  V v_c_24121 = args[0];
  V v_a_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24121, 3, 8); V a_1 = v_a_248; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eelimGo_lam33(V self, V *args) {
  V v_x_24125 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ecallee_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2enotAFunction(v_e_243, v_sp_241, v_ecallee_247, v_x_24125, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2eelimGo_lam31(V self, V *args) {
  V v_x_24120 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_ecallee_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_24120) == NTAG(TAG_True))) {
    heff_drop(v_x_24120);
    heff_drop(v_a_248);
    heff_drop(v_e_243);
    heff_drop(v_sp_241);
    heff_drop(v_ecallee_247);
    V f_ = heff_dup(g_heff_2eelab_2erules_2eerrorOf_get());
    heff_room[0] = v_z_245;
    heff_room[1] = v_z_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24120);
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam32, 1, 1, (V[]){v_a_248})})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_24123}));
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_24124;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eelimGo_lam33, 1, 5, (V[]){v_e_243, v_sp_241, v_ecallee_247, v_z_245, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimString_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimString_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimString_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimString_st;
static V g_heff_2eelab_2erules_2eprimString_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimString_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimString_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimString_st)) return g_heff_2eelab_2erules_2eprimString_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimString_val, &g_heff_2eelab_2erules_2eprimString_st, g_heff_2eelab_2erules_2eprimString_init);
}
V g_heff_2eelab_2erules_2eprimString_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2elitBytes_str0, 13, "prelude.Bytes");
HEFF_LIT(g_heff_2eelab_2erules_2elitBytes_str1, 13, "prelude.Bytes");
HEFF_LIT(g_heff_2eelab_2erules_2elitBytes_str2, 71, "a bytes literal is of the prelude's `Bytes`, which is not in scope here");
V g_heff_2eelab_2erules_2elitBytes_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elitBytes_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2elitBytes_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitBytes_lam2, 1, 0};
V g_heff_2eelab_2erules_2elitBytes_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elitBytes_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elitBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elitBytes_entry, 2, 0};

V g_heff_2eelab_2erules_2elitBytes(V v_sp_240, V v_s_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elitBytes_lam0, 1, 2, (V[]){v_sp_240, v_s_241})});
}
V g_heff_2eelab_2erules_2elitBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elitBytes(a[0], a[1]);
}
V g_heff_2eelab_2erules_2elitBytes_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2elitBytes_str2), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elitBytes_lam2(V self, V *args) {
  V v_u_2416 = args[0];
  heff_drop(v_u_2416);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2elitBytes_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elitBytes_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_get_n(v_e_242, 1, 6), 1, 7);
  V v_t_244 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2elitBytes_str0); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_it_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_it_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    v_it_246 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2erules_2elitBytes_str1), v_e_245})});
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_it_246)) {
  case TAG_Nothing: {
    heff_drop(v_s_241);
    return heff_clo_n(g_heff_2eelab_2erules_2elitBytes_lam1, 2, 1, (V[]){v_sp_240});
  }
  case TAG_Just: {
    V v_it1_2413 = heff_field(v_it_246, 0);
    V v_ru_24it_246_24Just = heff_take_reuse_n(v_it_246, 1ULL, 1);
    heff_drop(v_sp_240);
    switch (heff_tag_of(v_it1_2413)) {
    case TAG_MkPair: {
      V v_ge_2415 = heff_field(v_it1_2413, 1);
      V v_ru_24it1_2413_24MkPair = heff_take_reuse_n(v_it1_2413, 2ULL, 2);
      V v_t_2417 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_s_241}), ((V)&g_heff_2eelab_2erules_2elitBytes_lam2_clo)});
      V v_t_2418 = ({ V b_0 = heff_get_n(v_ge_2415, 2, 4); V r_ = (g_heff_2eelab_2evalue_2edecodeN(b_0)); heff_drop(b_0); r_; });
      V v_x1_2419 = heff_tag_at_n(v_ru_24it_246_24Just, TAG_Nom, 1, (V[]){v_t_2418});
      V v_t_2423;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_Nom: {
        V v_x_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2420;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2419, 0ULL, 1);
        v_t_2423 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2422 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      V v_x_2424 = heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_t_2423});
      return heff_clo_n(g_heff_2eelab_2erules_2elitBytes_lam3, 2, 1, (V[]){v_x_2424});
    }
    default: return heff_nomatch(v_it1_2413);
    }
  }
  default: return heff_nomatch(v_it_246);
  }
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam3, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitDefault(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_2413 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam0, 3, 1, (V[]){v_i_246})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2413)) {
    case TAG_MkChk: {
      V v_f_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      return heff_tail(v_f_2414, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_FracNum: {
    V v_x_2415 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_2422 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam2, 3, 1, (V[]){v_x_2415})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2422)) {
    case TAG_MkChk: {
      V v_f_2423 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      return heff_tail(v_f_2423, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitDefault(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  V v_i_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_247);
  heff_drop(v_hd_248);
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam1_clo)});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, NTAG(TAG_VPrimInt)});
  V f_ = v_k_249;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  heff_drop(v_u_2419);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args) {
  V v_e_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2416);
  heff_drop(v_hd_2417);
  V v_t_2420 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFloat, 1, (V[]){v_x_2415}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam3_clo)});
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, NTAG(TAG_VPrimFloat)});
  V f_ = v_k_2418;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitWait_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitWait_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_entry, 3, 0};

V g_heff_2eelab_2erules_2enumLitWait(V v_n_240, V v_sp_241, V v_lit_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam0, 4, 3, (V[]){v_sp_241, v_lit_242, v_n_240})});
}
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitWait(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_n_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2433;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_VU: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2413 = heff_dup(heff_field(v_x_2411, 0));
    switch (heff_tag_of(v_t1_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_x1_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_x1_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_x1_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_x1_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_x1_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2434 = heff_bool(!(heff_dup(v_x1_2433) == NTAG(TAG_True)));
  heff_drop(v_x1_2433);
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_n_240);
    heff_drop(v_t_2434);
    return (g_heff_2eelab_2erules_2enumLitAt(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
  } else {
    heff_drop(v_t_2434);
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_n_240))) {
      switch (heff_tag_of(v_lit_242)) {
      case TAG_IntNum: {
        V v_c_2437 = (g_heff_2eelab_2erules_2enumLitWait(heff_intSub(v_n_240, MK_INT(1LL)), heff_dup(v_sp_241), v_lit_242));
        return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2enumLitWait_str0); V a_3 = v_c_2437; V a_4 = heff_dup(v_x_2411); V a_5 = v_x_2411; V a_6 = v_hd_245; V a_7 = v_k_246; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2437); r_; });
      }
      case TAG_FracNum: {
        heff_drop(v_n_240);
        return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
      }
      default: return heff_nomatch(v_lit_242);
      }
    } else {
      heff_drop(v_n_240);
      return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
    }
  }
}
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_241 = heff_env(self)[0];
  V v_lit_242 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam2, 1, 6, (V[]){v_sp_241, v_e_243, v_lit_242, v_hd_245, v_k_246, v_n_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eappendP_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eappendP_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2erules_2eplacesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesGo_entry, 2, 0};

V g_heff_2eelab_2erules_2eplacesGo(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if ((heff_dup(v_b_242) == NTAG(TAG_True))) {
      heff_drop(v_b_242);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_241)}), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2eplacesGo_24dps(v_rest_243, heff_intAdd(v_k_241, MK_INT(1LL)), heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_b_242);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2erules_2eplacesGo_24dps(v_rest_243, v_k_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eplacesGo(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldIdxs_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2efieldIdxs_24dps(V v_at_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){MK_INT(0LL), heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_at_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_245;
      v_at_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_p_247 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      V v_t_248 = heff_intSub(heff_intSub(heff_dup(v_at_240), MK_INT(1LL)), v_p_247);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_at_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_249;
      v_at_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldIdxs_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2efieldTyAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efieldTyAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldTyAt_entry, 6, 0};

V g_heff_2eelab_2erules_2efieldTyAt(V v_len_240, V v_capture_241, V v_fieldTypes_242, V v_i_243, V v_before_244, V v_j_245) {
top: ;
  if (heff_intLt_c(heff_dup(v_j_245), heff_dup(v_i_243))) {
    V v_xs_247 = heff_dup(heff_rfield(v_fieldTypes_242, 2));
    V v_t_2411;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_j_245))) {
      if (heff_intLt_c(heff_dup(v_j_245), heff_arrayLength(heff_dup(v_xs_247)))) {
        V v_v_2410 = heff_arrayIndex(v_xs_247, heff_dup(v_j_245));
        v_t_2411 = v_v_2410;
      } else {
        heff_drop(v_xs_247);
        v_t_2411 = heff_abandon();
      }
    } else {
      heff_drop(v_xs_247);
      v_t_2411 = heff_abandon();
    }
    V v_t_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){heff_dup(v_capture_241), heff_dup(v_before_244)})}));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkField: {
      V v_fty_2413 = heff_field(v_t_2412, 0);
      V v_fvalue_2414 = heff_field(v_t_2412, 1);
      V v_ru_24t_2412_24MkField = heff_take_reuse_n(v_t_2412, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_fvalue_2414)) {
      case TAG_Nothing: {
        V v_t_2415 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_intAdd(heff_dup(v_len_240), heff_dup(v_j_245))});
        v_t_2418 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2415, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2efieldTyAt_lam0, 1, 1, (V[]){v_fty_2413}), NTAG(TAG_Nothing)));
        break;
      }
      case TAG_Just: {
        V v_v_2417 = heff_field(v_fvalue_2414, 0);
        heff_take_n(v_fvalue_2414, 1ULL, 1);
        heff_drop(v_fty_2413);
        v_t_2418 = v_v_2417;
        break;
      }
      default: heff_nomatch(v_fvalue_2414);
      }
      V v_t_2419 = heff_tag_at_n(v_ru_24t_2412_24MkField, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_t_2420 = (g_heff_2eelab_2erules_2eappendP(heff_arrayToList(v_before_244), v_t_2419));
      V t_0 = v_len_240;
      V t_1 = v_capture_241;
      V t_2 = v_fieldTypes_242;
      V t_3 = v_i_243;
      V t_4 = heff_arrayFromList(v_t_2420);
      V t_5 = heff_intAdd(v_j_245, MK_INT(1LL));
      v_len_240 = t_0;
      v_capture_241 = t_1;
      v_fieldTypes_242 = t_2;
      v_i_243 = t_3;
      v_before_244 = t_4;
      v_j_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  } else {
    heff_drop(v_j_245);
    V v_xs_2421 = heff_get_n(v_fieldTypes_242, 2, 3);
    V v_t_2425;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_243))) {
      if (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength(heff_dup(v_xs_2421)))) {
        V v_v_2424 = heff_arrayIndex(v_xs_2421, heff_dup(v_i_243));
        v_t_2425 = v_v_2424;
      } else {
        heff_drop(v_xs_2421);
        v_t_2425 = heff_abandon();
      }
    } else {
      heff_drop(v_xs_2421);
      v_t_2425 = heff_abandon();
    }
    V v_t_2426 = heff_tr(heff_call(v_t_2425, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){v_capture_241, v_before_244})}));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_MkField: {
      V v_fty_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 2);
      V v_t_2429 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_len_240, v_i_243), heff_dup(v_fty_2427)));
      V v_t_2430 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2429; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(a_0, a_1)); heff_drop(v_t_2429); r_; });
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_fty_2427);
        heff_drop(v_t_2430);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_t_2430);
        return heff_tag_n(TAG_Just, 1, (V[]){v_fty_2427});
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
}
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldTyAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efieldTyAt_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_fty_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  return v_fty_2413;
}
HEFF_LIT(g_heff_2eelab_2erules_2esumIntro_str0, 3, "tag");
V g_heff_2eelab_2erules_2esumIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntro_entry, 4, 0};

V g_heff_2eelab_2erules_2esumIntro(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam0, 4, 4, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243})});
}
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumIntro(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2esumIntro_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntro_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2434;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_VU: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2414 = heff_dup(heff_field(v_x_2412, 0));
    switch (heff_tag_of(v_t1_2414)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2414, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2414);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2434 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_t_2434);
    V v_t_2435 = (g_heff_2eelab_2erules_2esumIntroNow(heff_dup(v_sp_240), v_tsp_241, v_x_242, v_cs_243));
    return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumIntro_str0); V a_3 = v_t_2435; V a_4 = heff_dup(v_x_2412); V a_5 = v_x_2412; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2435); r_; });
  } else {
    heff_drop(v_t_2434);
    V v_t_2436 = (g_heff_2eelab_2erules_2esumIntroNow(v_sp_240, v_tsp_241, v_x_242, v_cs_243));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_MkChk: {
      V v_f_2437 = heff_field(v_t_2436, 0);
      heff_take_n(v_t_2436, 1ULL, 1);
      V f_ = v_f_2437;
      heff_room[0] = v_e_244;
      heff_room[1] = v_x_2412;
      heff_room[2] = v_hd_246;
      heff_room[3] = v_k_247;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
}
V g_heff_2eelab_2erules_2esumIntro_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_tsp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntro_lam2, 1, 7, (V[]){v_sp_240, v_tsp_241, v_x_242, v_cs_243, v_e_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdateSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_entry, 8, 0};

V g_heff_2eelab_2erules_2eupdateSetting(V v_upd_240, V v_e_241, V v_sp_242, V v_r_243, V v_g_244, V v_a_245, V v_fs_246, V v_x_247) {
top: ;
  V v_it_2418 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam0, 1, 1, (V[]){heff_dup(v_x_247)}), heff_dup(v_fs_246)));
  switch (heff_tag_of(v_it_2418)) {
  case TAG_Nil: {
    heff_drop(v_upd_240);
    heff_drop(v_e_241);
    heff_drop(v_fs_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam1, 2, 5, (V[]){v_x_247, v_sp_242, v_r_243, v_g_244, v_a_245});
  }
  case TAG_Cons: {
    V v_it1_2430 = heff_field(v_it_2418, 0);
    V v_it2_2431 = heff_field(v_it_2418, 1);
    heff_take_n(v_it_2418, 3ULL, 2);
    heff_drop(v_sp_242);
    switch (heff_tag_of(v_it1_2430)) {
    case TAG_UpdateTo: {
      V v_xsp_2433 = heff_field(v_it1_2430, 1);
      V v_fsp_2434 = heff_field(v_it1_2430, 2);
      V v_c_2435 = heff_field(v_it1_2430, 3);
      heff_take_n(v_it1_2430, 14ULL, 4);
      heff_drop(v_upd_240);
      heff_drop(v_e_241);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_a_245);
      switch (heff_tag_of(v_it2_2431)) {
      case TAG_Nil: {
        heff_drop(v_fs_246);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam5, 2, 4, (V[]){v_x_247, v_c_2435, v_fsp_2434, v_xsp_2433});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_2431, 0ULL, 2);
        heff_drop(v_xsp_2433);
        heff_drop(v_fsp_2434);
        heff_drop(v_c_2435);
        return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
      }
      default: return heff_nomatch(v_it2_2431);
      }
    }
    case TAG_UpdateIn: {
      V v_xsp_2441 = heff_field(v_it1_2430, 1);
      V v_fsp_2442 = heff_field(v_it1_2430, 2);
      V v_inner_2443 = heff_field(v_it1_2430, 3);
      heff_take_n(v_it1_2430, 14ULL, 4);
      V v_t_2444 = ({ V a_0 = v_it2_2431; V r_ = (g_heff_2eelab_2erules_2eupdateInner(a_0)); heff_drop(v_it2_2431); r_; });
      switch (heff_tag_of(v_t_2444)) {
      case TAG_Nothing: {
        heff_drop(v_upd_240);
        heff_drop(v_e_241);
        heff_drop(v_r_243);
        heff_drop(v_g_244);
        heff_drop(v_a_245);
        heff_drop(v_xsp_2441);
        heff_drop(v_fsp_2442);
        heff_drop(v_inner_2443);
        return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
      }
      case TAG_Just: {
        V v_rest_2445 = heff_field(v_t_2444, 0);
        heff_take_n(v_t_2444, 1ULL, 1);
        heff_drop(v_fs_246);
        V v_c_2446 = heff_tr(g_heff_2eelab_2erules_2erecordNameOf(v_e_241, heff_dup(v_a_245), heff_dup(v_x_247), v_xsp_2441));
        return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam6, 2, 9, (V[]){v_c_2446, v_inner_2443, v_rest_2445, v_upd_240, v_fsp_2442, v_r_243, v_g_244, v_a_245, v_x_247});
      }
      default: return heff_nomatch(v_t_2444);
      }
    }
    default: return heff_nomatch(v_it1_2430);
    }
  }
  default: return heff_nomatch(v_it_2418);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdateSetting(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args) {
  V v_f_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_f_248)) {
  case TAG_UpdateTo: {
    V v_x_249 = heff_field(v_f_248, 0);
    heff_take_n(v_f_248, 1ULL, 4);
    v_t_2417 = v_x_249;
    break;
  }
  case TAG_UpdateIn: {
    V v_x_2413 = heff_field(v_f_248, 0);
    heff_take_n(v_f_248, 1ULL, 4);
    v_t_2417 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_f_248);
  }
  return heff_strEq(v_t_2417, v_x_247);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_e_2421 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_fty_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_MkPair: {
    V v_m_2427 = heff_field(v_x_2426, 0);
    V v_t_2428 = heff_field(v_x_2426, 1);
    heff_take_n(v_x_2426, 3ULL, 2);
    return (g_heff_2eelab_2erules_2esameField(v_sp_242, v_e_2421, v_x_247, v_fty_2422, v_m_2427, v_t_2428, v_hd_2424, v_k_2425));
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_e_2421 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_fty_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam4, 1, 6, (V[]){v_sp_242, v_e_2421, v_x_247, v_fty_2422, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args) {
  V v_e_2421 = args[0];
  V v_fty_2422 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  V v_g_244 = heff_env(self)[2];
  V v_a_245 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2423 = (g_heff_2eelab_2erules_2eupdatedField(heff_dup(v_sp_242), heff_dup(v_e_2421), v_r_243, v_g_244, v_a_245, heff_dup(v_x_247)));
  return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam3, 2, 5, (V[]){v_c_2423, v_sp_242, v_e_2421, v_x_247, v_fty_2422});
}
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_r_243 = heff_env(self)[2];
  V v_g_244 = heff_env(self)[3];
  V v_a_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_hd_2419);
  V v_t_2429 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){heff_dup(v_x_247), heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam2, 2, 5, (V[]){heff_dup(v_sp_242), v_r_243, v_g_244, v_a_245, v_x_247})}), v_sp_242, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2420;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_c_2435 = heff_env(self)[1];
  V v_fsp_2434 = heff_env(self)[2];
  V v_xsp_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, v_c_2435, v_fsp_2434, v_xsp_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_inner_2443 = heff_env(self)[0];
  V v_rest_2445 = heff_env(self)[1];
  V v_upd_240 = heff_env(self)[2];
  V v_fsp_2442 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_a_245 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_k_2448 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2449);
  V v_t_2450 = (g_heff_2eelab_2erules_2eappendP(v_inner_2443, v_rest_2445));
  V v_t_2451 = (g_heff_2eelab_2erules_2enestedField(v_upd_240, heff_dup(v_fsp_2442), v_r_243, v_g_244, v_a_245, heff_dup(v_x_247), v_t_2450));
  V v_x_2452 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, v_t_2451, v_fsp_2442, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2448;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_inner_2443 = heff_env(self)[1];
  V v_rest_2445 = heff_env(self)[2];
  V v_upd_240 = heff_env(self)[3];
  V v_fsp_2442 = heff_env(self)[4];
  V v_r_243 = heff_env(self)[5];
  V v_g_244 = heff_env(self)[6];
  V v_a_245 = heff_env(self)[7];
  V v_x_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam7, 1, 9, (V[]){v_inner_2443, v_rest_2445, v_upd_240, v_fsp_2442, v_r_243, v_g_244, v_a_245, v_x_247, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordUpdate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordUpdate_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordUpdate(V v_sp_240, V v_s_241, V v_r_242, V v_fs_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_r_242, v_fs_243})});
}
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordUpdate(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordUpdate_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_a_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_a_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_r_242 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_fs_243 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_g_2417 = heff_field(v_x_2416, 0);
    V v_a_2418 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    return (g_heff_2eelab_2erules_2eupdateOf(v_sp_240, v_r_242, v_e_244, v_g_2417, heff_dup(v_a_2418), v_fs_243, v_hd_247, heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam4, 1, 2, (V[]){v_k_248, v_a_2418})));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2erecordUpdate_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_fs_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_dup(heff_field(v_x_249, 0));
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_y_2414 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 2ULL, 2);
    v_t_2415 = v_y_2414;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_240), v_t_2412, v_t_2415, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam3, 1, 6, (V[]){v_sp_240, v_r_242, v_e_244, v_fs_243, v_hd_247, v_k_248})));
}
V g_heff_2eelab_2erules_2erecordUpdate_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_fs_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam2, 1, 6, (V[]){v_e_244, v_sp_240, v_hd_247, v_r_242, v_fs_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  V v_fs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_240, v_r_242, v_fs_243});
}