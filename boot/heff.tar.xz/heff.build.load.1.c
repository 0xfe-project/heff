// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_absolute 325777132
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_drive 297211300
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_segments 1801007612
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module[] = {LBL_path, LBL_source, LBL_place, LBL_module};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2elibRead(V, V, V);
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2elibRead_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo;
V g_heff_2ebuild_2eload_2epackageRead(V, V, V, V);
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackageRead_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2eload_2epkgByPath(V, V);
V g_heff_2ebuild_2eload_2epkgByPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgByPath_clo;
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo;
V g_heff_2ebuild_2eload_2erelFrom(V, V, V);
V g_heff_2ebuild_2eload_2erelFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erelFrom_clo;
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_clo;
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisName(V);
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisName_clo;
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1345968422x916930247(V, V, V);
V g_list_2eany_24s1345968422x916930247_entry(V self, V *a);
extern Clo g_list_2eany_24s1345968422x916930247_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s639151216x1214259357(V, V, V);
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_clo;
V g_list_2efind_24s1250280863x1570195177(V, V);
V g_list_2efind_24s1250280863x1570195177_entry(V self, V *a);
extern Clo g_list_2efind_24s1250280863x1570195177_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1002907040x997927369(V, V);
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1002907040x997927369_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f904804876x285797696(V, V, V);
V g_list_2emap_24f904804876x285797696_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
V g_std_2epath_2enormalize(V, V);
V g_std_2epath_2enormalize_entry(V self, V *a);
extern Clo g_std_2epath_2enormalize_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str6, 1, ".");
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2eload_2erelFrom(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_path_241)));
  V v_p_248;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = (g_heff_2ebuild_2eload_2erelFrom(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 1)), heff_dup(v_path_241)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = (g_heff_2ebuild_2eload_2erelFrom(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(v_path_241)));
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nothing: {
        v_p_248 = v_path_241;
        break;
      }
      case TAG_Just: {
        V v_rel_245 = heff_field(v_t_244, 0);
        heff_take_n(v_t_244, 1ULL, 1);
        heff_drop(v_path_241);
        v_p_248 = v_rel_245;
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      break;
    }
    case TAG_Just: {
      V v_rel_246 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      heff_drop(v_path_241);
      v_p_248 = v_rel_246;
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    break;
  }
  case TAG_Just: {
    V v_rel_247 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    heff_drop(v_path_241);
    v_p_248 = v_rel_247;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_249 = heff_intSub(heff_strLength_lent(v_p_248, 0), MK_INT(3LL));
  V v_t_2410 = heff_strSlice(heff_dup(v_p_248), v_t_249, heff_strLength_lent(v_p_248, 0));
  V v_t_2413;
  if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
    V v_t_2412 = heff_intSub(heff_strLength_lent(v_p_248, 0), MK_INT(3LL));
    v_t_2413 = heff_strSlice(v_p_248, MK_INT(0LL), v_t_2412);
  } else {
    v_t_2413 = v_p_248;
  }
  V v_p_2414 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_t_2413; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_xs_2415 = (g_list_2efoldl_24s1725521117x1379101383(((V)&g_heff_2ebuild_2eload_2emoduleOf_str1), heff_dup(v_p_2414), ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2), ((V)&g_heff_2ebuild_2eload_2emoduleOf_str3), ((V)&g_heff_2ebuild_2eload_2emoduleOf_str4), NTAG(TAG_Nil), heff_get_n(v_p_2414, 2, 3)));
  V v_x2_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str5);
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str6); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eheffAt_str0, 3, "lib");
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eheffAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eheffAt_entry, 2, 0};

V g_heff_2ebuild_2eload_2eheffAt(V v_h_240, V v_d_241) {
top: ;
  V v_t_247 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2eload_2eheffAt_lam0, 1, 2, (V[]){heff_dup(v_h_240), heff_dup(v_d_241)}), heff_rfield(v_h_240, 4)));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) || ({ V v_b_248 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2eheffAt_str0))); int c_ = ({ V v_t_249 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), heff_dup(heff_rfield(v_h_240, 0)))); int c_ = ({ V v_t_2410 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), heff_dup(v_t_249))); int c_ = ({ V v_t_2411 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), heff_dup(v_b_248))); int c_ = ({ V v_t_2412 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), heff_dup(v_t_2411))); int c_ = heff_strEq_c_lent(v_t_2410, v_t_2412, 0); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2411); c_; }); heff_drop(v_t_2410); c_; }); heff_drop(v_t_249); c_; }); heff_drop(v_b_248); c_; })));
  heff_drop_rec(v_h_240, 5);
  heff_drop(v_d_241);
  heff_drop(v_t_247);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eheffAt(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), v_o_242));
  V v_t_244 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), v_t_243));
  V v_t_245 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_take_field(v_h_240, 2), v_d_241));
  V v_t_246 = ({ V b_0 = heff_get_n(v_h_240, 3, 5); V a_1 = v_t_245; V r_ = (g_std_2epath_2enormalize(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_strEq(v_t_244, v_t_246);
}
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str0, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str1, 3, "lib");
Clo g_heff_2ebuild_2eload_2elibRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2elibRead_entry, 3, 0};

V g_heff_2ebuild_2eload_2elibRead(V v_h_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    heff_drop(v_d_241);
    return heff_get_n(v_h_240, 0, 5);
  }
  case TAG_Right: {
    V v_pk_244 = heff_field(v_x3_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_244, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_t_246 = (g_heff_2ebuild_2eload_2eheffAt(heff_dup(v_h_240), heff_dup(v_d_241)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_b_247 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2elibRead_str0)));
        V v_t_248 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), heff_dup(heff_rfield(v_h_240, 0))));
        V v_t_249 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), v_t_248));
        V v_t_2410 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_take_field(v_h_240, 2), v_b_247));
        V v_t_2411 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), v_t_2410));
        if (heff_strEq_c(v_t_249, v_t_2411)) {
          heff_drop(v_d_241);
          return heff_get_n(v_h_240, 0, 5);
        } else {
          return ({ V b_0 = heff_get_n(v_h_240, 3, 5); V a_1 = v_d_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2elibRead_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        }
      } else {
        heff_drop(v_d_241);
        heff_drop(v_t_246);
        return heff_get_n(v_h_240, 0, 5);
      }
    } else {
      heff_drop(v_d_241);
      return heff_get_n(v_h_240, 0, 5);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2elibRead(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2etakeUntil_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      heff_drop(v_x_240);
      heff_drop(v_rest_244);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_x_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_247;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2etakeUntil_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_stack_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ebuild_2eload_2etakeUntil(heff_dup(v_path_243), v_stack_241));
      V v_xs_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, v_t_247});
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_t_246);
      V v_t_2410 = (g_heff_2ebuild_2eload_2epkgByPath(v_pkgs_240, heff_dup(v_path_243)));
      V v_t_2412;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        v_t_2412 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_k_2411 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        v_t_2412 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2411, 6, 7)));
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V v_x1_2413 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2412));
      V v_x2_2414 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Nothing: {
        return v_x2_2414;
      }
      case TAG_Just: {
        V v_x_2415 = heff_field(v_x1_2413, 0);
        V v_ru_24x1_2413_24Just = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
        heff_drop(v_x2_2414);
        return heff_tag_at_n(v_ru_24x1_2413_24Just, TAG_Just, 1, (V[]){v_x_2415});
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2ecycleAmong(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str1, 1, "_");
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c(heff_dup(v_n_242), MK_INT(2LL))) {
    v_t_245 = heff_dup(v_x_241);
  } else {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str0), heff_intShow(heff_dup(v_n_242)));
    v_t_245 = heff_strAppend(heff_dup(v_x_241), v_t_244);
  }
  V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_245}));
  V v_x1_247 = (g_list_2eany(v_t_246, v_taken_240));
  if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_x1_247);
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  } else {
    heff_drop(v_x1_247);
    if (heff_intLt_c(heff_dup(v_n_242), MK_INT(2LL))) {
      heff_drop(v_n_242);
      return v_x_241;
    } else {
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str1), heff_intShow(v_n_242));
      return heff_strAppend(v_x_241, v_t_249);
    }
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2efreeName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str5, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str9, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str11, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str13, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str16, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str17, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str19, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str20, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str21, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str23, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str24, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str25, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str26, 3, ".hf");
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args);
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_d_244 = heff_dup(heff_rfield(v_ps_240, 2));
  V v_t_2411 = heff_bool((heff_strEq_c_lent(v_d_244, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0), 2) ? !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1)) : ({ V v_t_247 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_d_244))); int c_ = ({ V v_t_248 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_from_242))); int c_ = ({ V v_t_249 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), heff_dup(v_t_247), heff_dup(v_t_248))); int c_ = ((heff_dup(v_t_249) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str2))); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; })));
  heff_drop(v_d_244);
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_t_2411);
    V v_base_2412 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_2413 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str3), heff_dup(v_w_243), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str4), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
    V v_parts_2418;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_parts_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_2415 = heff_field(v_t_2414, 0);
      V v_before_2416 = heff_field(v_t_2414, 1);
      V v_ru_24t_2414_24Cons = heff_take_reuse_n(v_t_2414, 3ULL, 2);
      V v_t_2417 = heff_tag_at_n(v_ru_24t_2414_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2415, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5)), v_before_2416});
      v_parts_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2417));
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2421 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2412), v_parts_2418));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2421, v_base_2412, v_parts_2418, v_w_243}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_2411);
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2422 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2423 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2424 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2423; V a_2 = v_project_2422; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2423); r_; });
      V v_t_2454;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2424, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str6))) {
        V v_base_2426 = heff_dup(heff_rfield(v_k_2424, 2));
        V v_xs_2427 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str7), heff_dup(v_w_243), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
        V v_parts_2432;
        switch (heff_tag_of(v_t_2428)) {
        case TAG_Nil: {
          v_parts_2432 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2429 = heff_field(v_t_2428, 0);
          V v_before_2430 = heff_field(v_t_2428, 1);
          V v_ru_24t_2428_24Cons = heff_take_reuse_n(v_t_2428, 3ULL, 2);
          V v_t_2431 = heff_tag_at_n(v_ru_24t_2428_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2429, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9)), v_before_2430});
          v_parts_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2431));
          break;
        }
        default: heff_nomatch(v_t_2428);
        }
        V v_t_2435 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam1, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2426), v_parts_2432));
        v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2435, v_base_2426, v_parts_2432, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_j_2436 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), v_w_243, MK_INT(0LL), 5);
        V v_t_2438;
        if (heff_intLt_c(heff_dup(v_j_2436), MK_INT(0LL))) {
          heff_drop(v_j_2436);
          v_t_2438 = heff_dup(v_w_243);
        } else {
          v_t_2438 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2436, 6);
        }
        if (heff_strEq_c(v_t_2438, heff_dup(heff_rfield(v_k_2424, 3)))) {
          V v_base_2440 = heff_dup(heff_rfield(v_k_2424, 2));
          V v_xs_2441 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str11), heff_dup(v_w_243), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
          V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2441));
          V v_parts_2446;
          switch (heff_tag_of(v_t_2442)) {
          case TAG_Nil: {
            v_parts_2446 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2443 = heff_field(v_t_2442, 0);
            V v_before_2444 = heff_field(v_t_2442, 1);
            V v_ru_24t_2442_24Cons = heff_take_reuse_n(v_t_2442, 3ULL, 2);
            V v_t_2445 = heff_tag_at_n(v_ru_24t_2442_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2443, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13)), v_before_2444});
            v_parts_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2445));
            break;
          }
          default: heff_nomatch(v_t_2442);
          }
          V v_j_2447 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), v_w_243, MK_INT(0LL), 5);
          V v_t_2449;
          if (heff_intLt_c(heff_dup(v_j_2447), MK_INT(0LL))) {
            heff_drop(v_j_2447);
            v_t_2449 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str15);
          } else {
            v_t_2449 = heff_strSlice(heff_dup(v_w_243), v_j_2447, heff_strLength_lent(v_w_243, 0));
          }
          V v_m_2450 = heff_strAppend(heff_dup(heff_rfield(v_k_2424, 4)), v_t_2449);
          V v_t_2453 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam2, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2440), v_parts_2446));
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2453, v_base_2440, v_parts_2446, v_m_2450}), NTAG(TAG_Nil)});
        } else {
          v_t_2454 = NTAG(TAG_Nil);
        }
      }
      V v_j_2455 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str16), v_w_243, MK_INT(0LL), 5);
      V v_t_2457;
      if (heff_intLt_c(heff_dup(v_j_2455), MK_INT(0LL))) {
        heff_drop(v_j_2455);
        v_t_2457 = heff_dup(v_w_243);
      } else {
        v_t_2457 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2455, 6);
      }
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str17), v_w_243, MK_INT(0LL), 5);
      V v_t_2460;
      if (heff_intLt_c(heff_dup(v_j_2458), MK_INT(0LL))) {
        heff_drop(v_j_2458);
        v_t_2460 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str18);
      } else {
        v_t_2460 = heff_strSlice(heff_dup(v_w_243), v_j_2458, heff_strLength_lent(v_w_243, 0));
      }
      V v_t_2461 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2424); V a_3 = v_t_2457; V a_4 = v_t_2460; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_pkgs_241, 2); r_; });
      V v_base_2462 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2463 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str19), heff_dup(v_w_243), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str20), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2463));
      V v_parts_2468;
      switch (heff_tag_of(v_t_2464)) {
      case TAG_Nil: {
        v_parts_2468 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2465 = heff_field(v_t_2464, 0);
        V v_before_2466 = heff_field(v_t_2464, 1);
        V v_ru_24t_2464_24Cons = heff_take_reuse_n(v_t_2464, 3ULL, 2);
        V v_t_2467 = heff_tag_at_n(v_ru_24t_2464_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2465, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21)), v_before_2466});
        v_parts_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2467));
        break;
      }
      default: heff_nomatch(v_t_2464);
      }
      V v_t_2471 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam3, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2462), v_parts_2468));
      V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2471, v_base_2462, v_parts_2468, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      V v_t_2479;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2424, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str22))) {
        V v_d_2474 = heff_dup(heff_rfield(v_k_2424, 2));
        V v_x1_2478;
        if (heff_strEq_c_lent(v_d_2474, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23), 2)) {
          heff_drop(v_from_242);
          heff_drop(v_d_2474);
          v_x1_2478 = NTAG(TAG_True);
        } else {
          V v_t_2476 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), v_d_2474));
          V v_t_2477 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), v_from_242));
          v_x1_2478 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_2476, v_t_2477));
        }
        v_t_2479 = heff_bool(!(heff_dup(v_x1_2478) == NTAG(TAG_True)));
        heff_drop(v_x1_2478);
      } else {
        heff_drop(v_from_242);
        v_t_2479 = NTAG(TAG_False);
      }
      V v_t_2490;
      if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
        heff_drop(v_t_2479);
        V v_base_2480 = heff_get_n(v_k_2424, 1, 7);
        V v_xs_2481 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eload_2eplacesOf_str24), heff_dup(v_w_243), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str25), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2481));
        V v_parts_2486;
        switch (heff_tag_of(v_t_2482)) {
        case TAG_Nil: {
          v_parts_2486 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2483 = heff_field(v_t_2482, 0);
          V v_before_2484 = heff_field(v_t_2482, 1);
          V v_ru_24t_2482_24Cons = heff_take_reuse_n(v_t_2482, 3ULL, 2);
          V v_t_2485 = heff_tag_at_n(v_ru_24t_2482_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2483, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str26)), v_before_2484});
          v_parts_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2485));
          break;
        }
        default: heff_nomatch(v_t_2482);
        }
        V v_t_2489 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam4, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2480), v_parts_2486));
        v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2489, v_base_2480, v_parts_2486, v_w_243}), NTAG(TAG_Nil)});
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2424, 7);
        heff_drop(v_t_2479);
        v_t_2490 = NTAG(TAG_Nil);
      }
      V v_t_2491 = (g_prelude_2e_2b_2b(v_t_2472, v_t_2490));
      V v_t_2492 = (g_prelude_2e_2b_2b(v_t_2461, v_t_2491));
      return (g_prelude_2e_2b_2b(v_t_2454, v_t_2492));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args) {
  V v_d_2419 = args[0];
  V v_p_2420 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2419; V a_2 = v_p_2420; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args) {
  V v_d_2433 = args[0];
  V v_p_2434 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2433; V a_2 = v_p_2434; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args) {
  V v_d_2451 = args[0];
  V v_p_2452 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2451; V a_2 = v_p_2452; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args) {
  V v_d_2469 = args[0];
  V v_p_2470 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2469; V a_2 = v_p_2470; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args) {
  V v_d_2487 = args[0];
  V v_p_2488 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2487; V a_2 = v_p_2488; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str3, 0, "");
Clo g_heff_2ebuild_2eload_2esameButCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameButCase_entry, 2, 0};

V g_heff_2ebuild_2eload_2esameButCase(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_a_240)}));
  V v_x2_243 = (g_list_2emap_24f904804876x285797696(v_t_242, MK_INT(0LL), heff_strLength(v_a_240)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_tr(heff_call(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_b_241)}));
  V v_x2_248 = (g_list_2emap_24f904804876x285797696(v_t_247, MK_INT(0LL), heff_strLength(v_b_241)));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  return heff_strEq(v_t_246, v_t_2411);
}
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2esameButCase(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str1, 10, "package.hf");
Clo g_heff_2ebuild_2eload_2epackageRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackageRead_entry, 4, 0};

V g_heff_2ebuild_2eload_2epackageRead(V v_h_240, V v_ps_241, V v_src_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Left = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_h_240);
    V v_t_245 = ({ V b_0 = heff_take_field(v_ps_241, 5); V a_1 = heff_get_n(v_ps_241, 0, 6); V a_2 = ((V)&g_heff_2ebuild_2eload_2epackageRead_str0); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_246 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_245, v_src_242, v_p_244));
    return heff_tag_at_n(v_ru_24x4_243_24Left, TAG_Left, 1, (V[]){v_t_246});
  }
  case TAG_Right: {
    V v_pk_247 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Right = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_247, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_x1_249 = (g_heff_2ebuild_2eload_2eheffAt(v_h_240, heff_dup(heff_rfield(v_ps_241, 0))));
      if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_src_242);
        heff_drop(v_x1_249);
        return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_247});
      } else {
        heff_drop_rec(v_pk_247, 4);
        heff_drop_cell(v_ru_24x4_243_24Right, 1);
        heff_drop(v_x1_249);
        V v_t_2410 = ({ V b_0 = heff_take_field(v_ps_241, 5); V a_1 = heff_get_n(v_ps_241, 0, 6); V a_2 = ((V)&g_heff_2ebuild_2eload_2epackageRead_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2411 = (g_heff_2ebuild_2eproject_2epackageLit(heff_dup(v_src_242)));
        V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2eproject_2eclaimOf(a_0)); heff_drop(v_t_2411); r_; });
        V v_t_2413 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2410, v_src_242, v_t_2412));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2413});
      }
    } else {
      heff_drop(v_h_240);
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_src_242);
      return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_247});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epackageRead(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_244 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_why_245 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_245, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_244, 0ULL, 1);
      v_t_247 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2410;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_249 = heff_field(v_pkgs_242, 1);
    v_t_2410 = heff_dup(v_y_249);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_take_field(v_st_243, 2)));
  V v_t_2412 = (g_prelude_2e_2b_2b(v_t_247, v_t_2411));
  V v_t_2416;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2413 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      heff_take_n(v_x11_2413, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2415 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2415});
      break;
    }
    default: heff_nomatch(v_x11_2413);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2419;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_pkgs_242, 0);
    v_t_2419 = heff_dup(v_x_2417);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){heff_get_n(v_st_243, 0, 3), v_t_2412, v_ps_240, v_t_2416, v_t_2419});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry, 2, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_h_240, 3));
  V v_p_243 = (g_std_2epath_2eparse(v_st_242, heff_dup(v_file_241)));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_243, 2)));
  V v_xs_245 = (g_list_2edrop(MK_INT(1LL), v_t_244));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_nf(v_p_243, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_248 = ({ V a_0 = v_st_242; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); r_; });
  V v_st_249 = heff_dup(heff_rfield(v_h_240, 3));
  V v_p_2410 = (g_std_2epath_2eparse(v_st_249, v_file_241));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2410, 2)));
  V v_xs_2412 = (g_list_2edrop(MK_INT(1LL), v_t_2411));
  V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
  V v_t_2414 = ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_p_2410, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2415 = ({ V a_0 = v_st_249; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_249); r_; });
  return (g_heff_2ebuild_2eload_2erootFrom_24s2119800462x1566710179(v_h_240, v_t_248, v_t_2415));
}
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry, 5, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_rd_240);
    heff_drop(v_root_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam0, 2, 2, (V[]){v_seen_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_n_247, 1)), heff_dup(v_root_241))) {
      v_t_2410 = NTAG(TAG_True);
    } else {
      v_t_2410 = (g_list_2eany_24s1345968422x916930247(heff_dup(heff_rfield(v_n_247, 1)), heff_dup(heff_rfield(v_n_247, 2)), v_seen_243));
    }
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop_rec(v_n_247, 3);
      heff_drop(v_t_2410);
      V t_0 = v_rd_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_seen_243;
      V t_4 = v_errs_244;
      v_rd_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_c_2411 = heff_tr(heff_call(heff_dup(v_rd_240), 3, (V[]){heff_dup(heff_rfield(v_n_247, 0)), heff_dup(heff_rfield(v_n_247, 1)), heff_dup(heff_rfield(v_n_247, 2))}));
      return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam1, 2, 7, (V[]){v_c_2411, v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_seen_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_n_247 = heff_env(self)[0];
  V v_seen_243 = heff_env(self)[1];
  V v_errs_244 = heff_env(self)[2];
  V v_rd_240 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), NTAG(TAG_Nothing)});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2417));
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2419));
    V v_t_2421 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(v_rd_240, v_root_241, v_rest_248, v_t_2418, v_t_2420));
    V f_ = v_t_2421;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2422 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_str0), heff_dup(heff_rfield(v_n_247, 2)));
    V v_t_2424 = heff_strAppend(heff_dup(heff_rfield(v_n_247, 1)), v_t_2423);
    V v_t_2425 = (g_list_2emap_24s675147852x248982264(v_t_2424, heff_dup(heff_rfield(v_pk_2422, 2))));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_rest_248, v_t_2425));
    V v_t_2427 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), heff_tag_n(TAG_Just, 1, (V[]){v_pk_2422})});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2428));
    V v_t_2430 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(v_rd_240, v_root_241, v_t_2426, v_t_2429, v_errs_244));
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_n_247 = heff_env(self)[1];
  V v_seen_243 = heff_env(self)[2];
  V v_errs_244 = heff_env(self)[3];
  V v_rd_240 = heff_env(self)[4];
  V v_root_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_lam2, 1, 8, (V[]){v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str2, 15, " cannot be read");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str3, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str5, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str6, 6, ", not ");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str7, 16, " is the package ");
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(V v_ps_240, V v_dir_241, V v_path_242) {
top: ;
  V v_path_243 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(v_dir_241), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0, 2, 4, (V[]){v_path_243, v_ps_240, v_dir_241, v_path_242});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2427;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_path_242);
    V v_t_2411 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_x_2427 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str2))});
    break;
  }
  case TAG_Just: {
    V v_t_2412 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_x1_2413 = (g_heff_2ebuild_2eproject_2epackageLit(heff_dup(v_t_2412)));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Left: {
      V v_p_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      heff_drop(v_path_242);
      V v_t_2415 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str3); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_2416 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2415, v_t_2412, v_p_2414));
      v_x_2427 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Left, 1, (V[]){v_t_2416});
      break;
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      V v_t_2418 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2417); r_; });
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Left: {
        V v_p_2419 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        heff_drop(v_path_242);
        V v_t_2420 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str4); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2421 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2420, v_t_2412, v_p_2419));
        v_x_2427 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Left, 1, (V[]){v_t_2421});
        break;
      }
      case TAG_Right: {
        V v_pk_2422 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        heff_drop(v_t_2412);
        if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2422, 0)), heff_dup(v_path_242))) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_dir_241);
          heff_drop(v_path_242);
          v_x_2427 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Right, 1, (V[]){v_pk_2422});
        } else {
          V v_t_2424 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_dir_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str5); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          V v_t_2425 = heff_strAppend(heff_get_n(v_pk_2422, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str6), v_path_242));
          V v_t_2426 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_str7), v_t_2425));
          v_x_2427 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Left, 1, (V[]){v_t_2426});
        }
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    default: heff_nomatch(v_x1_2413);
    }
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_245;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_243, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, v_hd_244, heff_clo_n(g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_lam2, 1, 4, (V[]){v_ps_240, v_dir_241, v_path_242, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str2, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str3, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str5, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str6, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str7, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str9, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str10, 1, " ");
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_246 = (g_list_2efilter_24s2128134357x1680551385(heff_dup(v_path_244), heff_take_field(v_root_241, 2)));
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    V v_t_249 = (g_list_2efilter_24s50027113x1989932102(v_r_247, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_path_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str0));
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam0, 2, 6, (V[]){v_path_2414, v_v_245, v_path_244, v_by_243, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2450 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_t_2451 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), v_d_2450));
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2451, v_path_244));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_v_245 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_by_243 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2415);
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str1), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str2)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str3), heff_strAppend(v_path_244, v_t_2422));
    V v_t_2424 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_by_243, v_t_2423)});
    V f_ = v_k_2416;
    args[0] = v_t_2424;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_h_2425 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Just = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2426 = (g_list_2efilter_24s639151216x1214259357(heff_dup(v_path_244), heff_dup(v_v_245), v_sums_242));
    V v_t_2429;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2421_24Just, 1);
      v_t_2429 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 2);
      v_t_2429 = heff_tag_at_n(v_ru_24x_2421_24Just, TAG_Just, 1, (V[]){heff_get_n(v_s_2427, 2, 3)});
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2415);
      heff_drop(v_h_2425);
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str4), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str5)));
      V v_t_2431 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str6), heff_strAppend(v_path_244, v_t_2430));
      V f_ = v_k_2416;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_want_2432 = heff_field(v_t_2429, 0);
      V v_ru_24t_2429_24Just = heff_take_reuse_n(v_t_2429, 1ULL, 1);
      V v_t_2433 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2434 = heff_intSub(heff_strLength_lent(v_h_2425, 0), MK_INT(1LL));
      V v_t_2435 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), v_t_2434, MK_INT(-1LL)));
      V v_t_2436 = heff_strSlice(heff_dup(v_h_2425), v_t_2433, heff_intAdd(v_t_2435, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2436, v_want_2432, 1)) {
        heff_drop(v_h_2425);
        heff_drop(v_want_2432);
        heff_drop_cell(v_ru_24t_2429_24Just, 1);
        V v_t_2438 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2439 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2438, v_path_244));
        V f_ = v_t_2439;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_hd_2415);
        V v_t_2440 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_244), heff_dup(v_v_245)));
        V v_t_2441 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2442 = heff_intSub(heff_strLength_lent(v_h_2425, 0), MK_INT(1LL));
        V v_t_2443 = (g_prelude_2eskipSpaces(heff_dup(v_h_2425), v_t_2442, MK_INT(-1LL)));
        V v_t_2444 = heff_strSlice(v_h_2425, v_t_2441, heff_intAdd(v_t_2443, MK_INT(1LL)));
        V v_t_2445 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str7), v_want_2432));
        V v_t_2446 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str8), v_t_2445));
        V v_t_2447 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str9), v_t_2446));
        V v_t_2448 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_str10), v_t_2447));
        V v_x_2449 = heff_tag_at_n(v_ru_24t_2429_24Just, TAG_Left, 1, (V[]){v_t_2448});
        V f_ = v_k_2416;
        args[0] = v_x_2449;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_path_2414 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_by_243 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2414, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam1_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_lam2, 1, 7, (V[]){v_v_245, v_path_244, v_by_243, v_k_2416, v_sums_242, v_ps_240, v_hd_2415})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str0, 19, " is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str3, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str4, 60, ": a package's src/ holds one directory, named as the package");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str5, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str6, 26, ", which is not a directory");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str7, 72, " cannot name a package: a lowercase letter, then letters, digits and `_`");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str10, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str11, 60, ": a package's src/ holds one directory, named as the package");
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2(V self, V *args); static Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2, 1, 0};
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry, 4, 0};

V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V v_ps_240, V v_src_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_src_241), ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam1, 1, 4, (V[]){v_src_241, v_k_243, v_ps_240, v_hd_242})));
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam0(V self, V *args) {
  V v_ns_244 = args[0];
  return v_ns_244;
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2(V self, V *args) {
  V v_ns_2419 = args[0];
  return v_ns_2419;
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_src_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2428;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str5), heff_strAppend(v_x_2416, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str6)));
    v_x_2428 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2424)});
    break;
  }
  case TAG_Just: {
    V v_ru_24x_2423_24Just = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    V v_t_2426 = (g_heff_2ebuild_2eproject_2eisName(heff_dup(v_x_2416)));
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_src_241);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_t_2426);
      v_x_2428 = heff_tag_at_n(v_ru_24x_2423_24Just, TAG_Right, 1, (V[]){v_x_2416});
    } else {
      heff_drop(v_t_2426);
      V v_t_2427 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_src_241; V a_2 = v_x_2416; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      v_x_2428 = heff_tag_at_n(v_ru_24x_2423_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str7))});
    }
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_k_243;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_src_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_242);
    V v_t_249 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_src_241, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str0))});
    V f_ = v_k_243;
    args[0] = v_t_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_242);
      V v_t_2413;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_it1_2410, 0);
        V v_xs_2412 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_it1_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str4)));
      V v_x_2415 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2414)});
      V f_ = v_k_243;
      args[0] = v_x_2415;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2416 = heff_dup(heff_field(v_it1_2410, 0));
      V v_it12_2417 = heff_dup(heff_field(v_it1_2410, 1));
      switch (heff_tag_of(v_it12_2417)) {
      case TAG_Nil: {
        heff_drop_tag(v_it1_2410, 2);
        V v_path_2418 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(v_src_241), heff_dup(v_x_2416)));
        V v_t_2420 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){v_path_2418, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam2_clo)})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        return (g_co_2eop_24s954557541x749476273(v_t_2422, v_hd_242, heff_clo_n(g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_lam3, 1, 4, (V[]){v_x_2416, v_src_241, v_ps_240, v_k_243})));
      }
      case TAG_Cons: {
        heff_take_n(v_it12_2417, 0ULL, 2);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_242);
        heff_drop(v_x_2416);
        V v_t_2433;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_Nil: {
          v_t_2433 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2431 = heff_field(v_it1_2410, 0);
          V v_xs_2432 = heff_field(v_it1_2410, 1);
          heff_take_n(v_it1_2410, 3ULL, 2);
          v_t_2433 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str9); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
          break;
        }
        default: heff_nomatch(v_it1_2410);
        }
        V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str10), heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_str11)));
        V v_x_2435 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_src_241, v_t_2434)});
        V f_ = v_k_243;
        args[0] = v_x_2435;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_it12_2417);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str1, 3, "src");
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243) {
top: ;
  V v_t_244 = (g_list_2efilter_24s2128134357x1680551385(heff_dup(heff_rfield(v_x_242, 0)), heff_take_field(v_root_241, 2)));
  V v_x_2410;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_x_2410 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
    break;
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_t_247 = (g_list_2efilter_24s50027113x1989932102(v_r_245, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_x_2410 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
      break;
    }
    case TAG_Cons: {
      V v_p_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 2);
      v_x_2410 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), heff_get_n(v_p_248, 1, 2)));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam0, 2, 4, (V[]){v_ps_240, v_x_2410, v_pk_243, v_x_242});
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2420;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_x_2410);
    heff_drop_rec(v_pk_243, 4);
    heff_drop_rec(v_x_242, 3);
    v_x_2420 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_Left, 1, (V[]){v_why_2415});
    break;
  }
  case TAG_Right: {
    V v_name_2416 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2417 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = heff_dup(v_x_2410); V a_2 = ((V)&g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_2418 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_pk_243, 2)));
    V v_t_2419 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_get_n(v_x_242, 0, 3), v_x_2410, v_t_2417, heff_dup(v_name_2416), v_name_2416, heff_get_n(v_pk_243, 1, 4), v_t_2418});
    v_x_2420 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_Right, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_2412;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_str0)));
  return (g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(heff_dup(v_ps_240), v_t_2413, v_hd_2411, heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917_lam1, 1, 5, (V[]){v_ps_240, v_x_2410, v_pk_243, v_x_242, v_k_2412})));
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_entry, 5, 0};

V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam0, 2, 2, (V[]){v_acc_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_dup(heff_rfield(v_x31_247, 2));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x31_247, 3);
      V t_0 = v_ps_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_acc_243;
      V t_4 = v_errs_244;
      v_ps_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_c_2411 = (g_heff_2ebuild_2eload_2epkgOf_24s1016973630x1844072917(heff_dup(v_ps_240), heff_dup(v_root_241), v_x31_247, v_pk_2410));
      return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam1, 2, 6, (V[]){v_c_2411, v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_errs_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2417 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2416));
    V v_t_2418 = (g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(v_ps_240, v_root_241, v_rest_248, v_acc_243, v_t_2417));
    V f_ = v_t_2418;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_p_2419 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2420));
    V v_t_2422 = (g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(v_ps_240, v_root_241, v_rest_248, v_t_2421, v_errs_244));
    V f_ = v_t_2422;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789_lam2, 1, 7, (V[]){v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str1, 11, "the project");
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(V v_ps_240, V v_root_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam0, 2, 3, (V[]){v_c_242, v_ps_240, v_root_241});
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_seen_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2419; V a_1 = v_seen_2417; V r_ = (g_list_2efoldl_24s1002907040x997927369(a_0, a_1)); heff_drop(v_seen_2417); r_; });
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_dup(heff_field(v_x_2422, 0));
    v_t_2425 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_t_2428;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_x_2426 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2426, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2431;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_y_2430 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 2ULL, 2);
    v_t_2431 = v_y_2430;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2434;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_MkPair: {
    V v_y_2433 = heff_field(v_x_2422, 1);
    heff_take_n(v_x_2422, 2ULL, 2);
    v_t_2434 = v_y_2433;
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2434));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2435));
  V v_x_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_t_2436});
  V f_ = v_k_244;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_seen_2417;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_dup(heff_field(v_x_2414, 0));
    v_seen_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2418 = (g_list_2efoldl_24s489050722x1368997552(NTAG(TAG_Nil), heff_dup(v_seen_2417)));
  V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam3, 1, 1, (V[]){v_seen_2417}), v_t_2418));
  V v_c_2421 = (g_heff_2ebuild_2eload_2epkgsOf_24s867071139x625783789(v_ps_240, v_root_241, v_t_2420, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam4, 1, 3, (V[]){v_x_245, v_x_2414, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_dup(heff_field(v_x_245, 0));
    v_t_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s353563038x1121165991_clo), 3, (V[]){heff_dup(v_ps_240), heff_dup(v_root_241), v_t_248}));
  V v_t_2411;
  if (heff_strEq_c(heff_dup(heff_rfield(v_root_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str0))) {
    v_t_2411 = ((V)&g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_str1);
  } else {
    v_t_2411 = heff_dup(heff_rfield(v_root_241, 0));
  }
  V v_t_2412 = (g_list_2emap_24s675147852x248982264(v_t_2411, heff_dup(heff_rfield(v_root_241, 2))));
  V v_c_2413 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(v_t_249, heff_dup(heff_rfield(v_root_241, 0)), v_t_2412, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam2, 1, 5, (V[]){v_ps_240, v_root_241, v_hd_243, v_x_245, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407_lam1, 1, 4, (V[]){v_ps_240, v_root_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str9, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str10, 30, "packages require one another: ");
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry, 2, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam0, 2, 1, (V[]){v_ps_240});
  }
  case TAG_Just: {
    V v_root_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_c_248 = (g_heff_2ebuild_2eload_2ereachAll_24s2034861336x1849758407(heff_dup(v_ps_240), heff_dup(v_root_247)));
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam1, 2, 3, (V[]){v_c_248, v_ps_240, v_root_247});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str0), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str1), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str2), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str3), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3(V self, V *args) {
  V v_ns_2412 = args[0];
  return v_ns_2412;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5(V self, V *args) {
  V v_ns_2420 = args[0];
  return v_ns_2420;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7(V self, V *args) {
  V v_ns_2428 = args[0];
  return v_ns_2428;
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam8(V self, V *args) {
  V v_x_2432 = args[0];
  V v_root_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2434;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Nothing: {
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2433 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    v_t_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  V v_x_2435 = (g_list_2emap_24s1462590149x1582455373(v_t_2434));
  V v_t_2436 = (g_list_2emap_24s18996220x10511024(heff_dup(heff_rfield(v_root_247, 2))));
  V v_t_2437 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str4), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str5), heff_dup(heff_rfield(v_root_247, 1)), v_t_2436});
  V v_t_2438 = (g_prelude_2e_2b_2b(v_x_2427, v_x_2435));
  V v_t_2439 = (g_prelude_2e_2b_2b(v_x_2419, v_t_2438));
  V v_t_2442;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_dup(heff_field(v_x_2411, 0));
    v_t_2442 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2443 = (g_heff_2ebuild_2eload_2enamedGo(v_t_2439, v_t_2442));
  V v_t_2446;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2445 = heff_dup(heff_field(v_x_2411, 1));
    v_t_2446 = v_y_2445;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2447 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_root_247, 2)));
  V v_t_2448 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_247, 0)), heff_take_field(v_ps_240, 0), heff_get_n(v_ps_240, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str7), heff_take_field(v_root_247, 1), v_t_2447});
  V v_t_2451;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 2);
    v_t_2451 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_247, 0, 4), NTAG(TAG_Nil)});
  V v_t_2453 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2451}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2452; V r_ = (g_heff_2ebuild_2eload_2ecycleAmong(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2458;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_Nothing: {
    v_t_2458 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_c_2454 = heff_field(v_t_2453, 0);
    heff_take_n(v_t_2453, 1ULL, 1);
    V v_t_2457;
    switch (heff_tag_of(v_c_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_c_2454, 0);
      V v_xs_2456 = heff_field(v_c_2454, 1);
      heff_take_n(v_c_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str9); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_c_2454);
    }
    v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_str10), v_t_2457), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_t_2459 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2458));
  V v_x_2460 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2443}), v_t_2459});
  V f_ = v_k_2410;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    v_t_2426 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2425 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V v_x_2427 = (g_list_2emap_24s1462590149x1582455373(v_t_2426));
  V v_t_2429 = heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam7_clo)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_249, heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam8, 1, 6, (V[]){v_root_247, v_ps_240, v_x_2427, v_x_2419, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V v_x_2419 = (g_list_2emap_24s1462590149x1582455373(v_t_2418));
  V v_t_2421 = heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam5_clo)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam6, 1, 6, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2419, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(heff_rfield(v_ps_240, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam3_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam4, 1, 5, (V[]){v_ps_240, v_hd_249, v_root_247, v_x_2411, v_k_2410})));
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101_lam2, 1, 4, (V[]){v_ps_240, v_hd_249, v_root_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_pl_243 = heff_field(v_x2_240, 0);
    V v_rest_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0_clo)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    HEFF_LAST return g_co_2eop_24s1084803226x1249263831(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam1, 1, 4, (V[]){v_rest_244, v_p_241, v_pl_243, v_p_242}));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam0(V self, V *args) {
  V v_a_245 = args[0];
  return v_a_245;
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_243, 4);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Just: {
    V v_s_2411 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2412 = heff_rec_n(4, shape_path__source__place__module, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), v_s_2411, heff_dup(v_pl_243), heff_get_n(v_pl_243, 3, 4)});
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_p_242;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688_lam2, 1, 3, (V[]){v_x_249, v_pl_243, v_p_242})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_imp_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_stack_242);
    heff_drop(v_from_243);
    heff_drop(v_imp_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam1, 2, 10, (V[]){v_t_2412, v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam4(V self, V *args) {
  V v_x_2483 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_f_2428 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_rs_247 = heff_env(self)[4];
  V v_pkgs_241 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_from_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2486;
  switch (heff_tag_of(v_x_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_dup(heff_field(v_x_2483, 0));
    v_t_2486 = v_x_2484;
    break;
  }
  default: heff_nomatch(v_x_2483);
  }
  V v_t_2487 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
  V v_t_2490;
  switch (heff_tag_of(v_x_2483)) {
  case TAG_MkPair: {
    V v_y_2489 = heff_field(v_x_2483, 1);
    heff_take_n(v_x_2483, 2ULL, 2);
    v_t_2490 = v_y_2489;
    break;
  }
  default: heff_nomatch(v_x_2483);
  }
  V v_t_2491 = (g_heff_2ebuild_2eload_2epushDone(v_t_2486, heff_dup(v_ps_240), heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_f_2428, 0), heff_take_field(v_f_2428, 1), v_t_2487, v_t_2490));
  V v_m_2492 = heff_get_n(v_f_2428, 3, 4);
  V v_t_2494;
  if (heff_strEq_c_lent(v_w_2410, v_m_2492, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2492);
    v_t_2494 = v_rs_247;
  } else {
    v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2492}), v_rs_247});
  }
  V v_t_2495 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2491, v_t_2494));
  V f_ = v_t_2495;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam3(V self, V *args) {
  V v_x_2469 = args[0];
  V v_f_2428 = heff_env(self)[0];
  V v_stack_242 = heff_env(self)[1];
  V v_imp_244 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  V v_pkgs_241 = heff_env(self)[7];
  V v_hd_2413 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  V v_rest_2411 = heff_env(self)[10];
  V v_k_2414 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_dup(v_stack_242)});
  V v_t_2471 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
  V v_t_2472 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2471, heff_dup(heff_rfield(v_f_2428, 1))));
  V v_imps_2473 = heff_get_n(v_t_2472, 0, 3);
  V v_t_2474 = (g_list_2emap_24s1817208647x1282894070(v_imps_2473));
  V v_t_2475 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2474));
  V v_t_2481;
  switch (heff_tag_of(v_x_2469)) {
  case TAG_Nothing: {
    v_t_2481 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2476 = heff_field(v_x_2469, 0);
    heff_take_n(v_x_2469, 1ULL, 1);
    V v_t_2477 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str9), v_why_2476));
    V v_t_2478 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str10), v_t_2477));
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, NTAG(TAG_Nil)});
    V v_t_2480 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2479));
    v_t_2481 = ({ V rv_2 = v_t_2480; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2469);
  }
  V v_c_2482 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(heff_dup(v_ps_240), heff_dup(v_pkgs_241), v_t_2470, heff_dup(heff_rfield(v_f_2428, 0)), heff_dup(v_imp_244), v_t_2475, v_t_2481, NTAG(TAG_Nil)));
  V f_ = v_c_2482;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam4, 1, 11, (V[]){v_imp_244, v_f_2428, v_ps_240, v_w_2410, v_rs_247, v_pkgs_241, v_stack_242, v_from_243, v_rest_2411, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_pkgs_241 = heff_env(self)[1];
  V v_from_243 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_imp_244 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nil: {
    V v_places_2416 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_x2_2417 = (g_list_2emap_24s435407392x1528135477(v_places_2416));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str2), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str3)));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str4), heff_strAppend(v_w_2410, v_t_2421));
    V v_e_2423 = heff_strAppend(heff_dup(v_from_243), v_t_2422);
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2424));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2427 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2426, v_rs_247));
    V f_ = v_t_2427;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2428 = heff_dup(heff_field(v_x_2415, 0));
    V v_others_2429 = heff_dup(heff_field(v_x_2415, 1));
    V v_t_2430 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
    V v_t_2431 = (g_list_2eany(v_t_2430, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2415, 2);
      heff_drop(v_others_2429);
      heff_drop(v_t_2431);
      V v_m_2432 = heff_get_n(v_f_2428, 3, 4);
      V v_t_2434;
      if (heff_strEq_c_lent(v_w_2410, v_m_2432, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2432);
        v_t_2434 = v_rs_247;
      } else {
        v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2432}), v_rs_247});
      }
      V v_t_2435 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_st_246, v_t_2434));
      V f_ = v_t_2435;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2431);
      V v_t_2436 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
      V v_t_2437 = (g_list_2eany(v_t_2436, v_stack_242));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2415, 2);
        heff_drop(v_others_2429);
        heff_drop(v_t_2437);
        V v_m_2438 = heff_dup(heff_rfield(v_f_2428, 3));
        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_242)));
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2438), NTAG(TAG_Nil)});
        V v_x2_2441 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2440));
        V v_t_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_t_2444 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str6); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        V v_t_2445 = heff_strAppend(v_m_2438, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str7), v_t_2444));
        V v_e_2446 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_str8), v_t_2445));
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
        V v_t_2448 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2447));
        V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2450 = heff_get_n(v_f_2428, 3, 4);
        V v_t_2452;
        if (heff_strEq_c_lent(v_w_2410, v_m_2450, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2450);
          v_t_2452 = v_rs_247;
        } else {
          v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2450}), v_rs_247});
        }
        V v_t_2453 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2449, v_t_2452));
        V f_ = v_t_2453;
        heff_room[0] = v_hd_2413;
        heff_room[1] = v_k_2414;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2437);
        V v_t_2456;
        switch (heff_tag_of(v_others_2429)) {
        case TAG_Nil: {
          v_t_2456 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_others_2429, 0ULL, 2);
          v_t_2456 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_others_2429);
        }
        if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
          heff_drop(v_t_2456);
          V v_e_2457 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_240), v_x_2415, heff_dup(v_from_243), heff_dup(v_w_2410)));
          V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2457, NTAG(TAG_Nil)});
          V v_t_2459 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2458));
          V v_st_2460 = ({ V rv_2 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_st_2460, 1)});
          V v_t_2462 = ({ V rv_1 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_st_2460, 5ULL, 3, shape_done__doneMods__errors, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_m_2463 = heff_get_n(v_f_2428, 3, 4);
          V v_t_2465;
          if (heff_strEq_c_lent(v_w_2410, v_m_2463, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2463);
            v_t_2465 = v_rs_247;
          } else {
            v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2463}), v_rs_247});
          }
          V v_t_2466 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2462, v_t_2465));
          V f_ = v_t_2466;
          heff_room[0] = v_hd_2413;
          heff_room[1] = v_k_2414;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop_tag(v_x_2415, 2);
          heff_drop(v_t_2456);
          V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 1, 4);
          V v_t_2468 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s980013260x1879529931(heff_dup(v_ps_240), v_t_2467, v_t_2468, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam3, 1, 12, (V[]){v_f_2428, v_stack_242, v_imp_244, v_st_246, v_w_2410, v_from_243, v_ps_240, v_pkgs_241, v_hd_2413, v_rs_247, v_rest_2411, v_k_2414})));
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pkgs_241 = heff_env(self)[2];
  V v_from_243 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_imp_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2eload_2ereadEvery_24s1096987026x1242821688(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842_lam2, 1, 11, (V[]){v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247, v_hd_2413, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry, 2, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(V v_h_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(heff_dup(v_h_240), heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam0, 2, 3, (V[]){v_c_242, v_h_240, v_file_241});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4(V self, V *args) {
  V v_a_2414 = args[0];
  return v_a_2414;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam7(V self, V *args) {
  V v_m_2443 = args[0];
  V v_made_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = ({ V a_0 = v_m_2443; V a_1 = v_made_2429; V r_ = (g_list_2efind_24s1250280863x1570195177(a_0, a_1)); heff_drop(v_made_2429); r_; });
  switch (heff_tag_of(v_t_2444)) {
  case TAG_Nothing: {
    return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
  }
  case TAG_Just: {
    V v_s_2445 = heff_field(v_t_2444, 0);
    heff_take_n(v_t_2444, 1ULL, 1);
    return heff_get_n(v_s_2445, 5, 7);
  }
  default: return heff_nomatch(v_t_2444);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_made_2429 = heff_env(self)[2];
  V v_src_2423 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_dup(heff_field(v_x_2447, 0));
    v_t_2450 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V v_t_2451 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_2452 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2453 = ({ V a_0 = v_m_2452; V a_1 = v_made_2429; V r_ = (g_list_2efind_24s1250280863x1570195177(a_0, a_1)); heff_drop(v_made_2429); r_; });
  V v_t_2455;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_Nothing: {
    v_t_2455 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2454 = heff_field(v_t_2453, 0);
    heff_take_n(v_t_2453, 1ULL, 1);
    v_t_2455 = heff_get_n(v_s_2454, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_t_2458;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_MkPair: {
    V v_y_2457 = heff_field(v_x_2447, 1);
    heff_take_n(v_x_2447, 2ULL, 2);
    v_t_2458 = v_y_2457;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V v_t_2459 = (g_heff_2ebuild_2eload_2epushDone(v_t_2450, heff_dup(v_x_245), v_t_2451, v_file_241, v_src_2423, v_t_2455, v_t_2458));
  V v_x_2460 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2459; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_244;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_src_2423 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_made_2429 = heff_get_n(v_x_2428, 0, 3);
  V v_t_2432;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2432 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2433 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_m_2435 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2436 = (g_list_2efind_24s1250280863x1570195177(v_m_2435, v_made_2429));
  V v_t_2438;
  switch (heff_tag_of(v_t_2436)) {
  case TAG_Nothing: {
    v_t_2438 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    break;
  }
  case TAG_Just: {
    V v_s_2437 = heff_field(v_t_2436, 0);
    heff_take_n(v_t_2436, 1ULL, 1);
    v_t_2438 = heff_get_n(v_s_2437, 5, 7);
    break;
  }
  default: heff_nomatch(v_t_2436);
  }
  V v_t_2439 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2438, heff_dup(v_src_2423)));
  V v_imps_2440 = heff_get_n(v_t_2439, 0, 3);
  V v_t_2441 = (g_list_2emap_24s1817208647x1282894070(v_imps_2440));
  V v_t_2442 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2441));
  V v_c_2446 = (g_heff_2ebuild_2eload_2eloadMany_24s112798442x1727805842(heff_dup(v_x_245), v_t_2432, v_t_2434, heff_dup(v_file_241), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam7, 1, 1, (V[]){heff_dup(v_made_2429)}), v_t_2442, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2446;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam8, 1, 7, (V[]){v_x_245, v_file_241, v_made_2429, v_src_2423, v_x_247, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2419));
    V v_t_2421 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2420});
    V v_x_2422 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2421; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
    V f_ = v_k_244;
    args[0] = v_x_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2423 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_t_2426;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2426 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_c_2427 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1834102042x60992877(heff_dup(v_x_245), v_t_2426, heff_dup(v_file_241), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2427;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam6, 1, 7, (V[]){v_x_2413, v_x_245, v_file_241, v_src_2423, v_hd_243, v_x_247, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_file_241), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam4_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s1084803226x1249263831(v_t_2417, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam5, 1, 6, (V[]){v_file_241, v_x_245, v_x_247, v_x_2413, v_k_244, v_hd_243})));
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_2412 = (g_heff_2ebuild_2eload_2epackagesOf_24s1189598642x1489870101(heff_dup(v_x_245), v_t_2411));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam3, 1, 5, (V[]){v_file_241, v_hd_243, v_x_245, v_x_247, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s1962253461x854609322(v_h_240, heff_dup(v_x_245)));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_lam1, 1, 4, (V[]){v_h_240, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}