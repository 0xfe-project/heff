// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_base 9511832
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_place 308106529
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__source__place__module__named[] = {LBL_path, LBL_source, LBL_place, LBL_module, LBL_named};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_clo;
HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2elibRead(V, V, V);
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2elibRead_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s42671976x288945834(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s42671976x288945834_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s42671976x288945834_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s537155342x1194319747(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s537155342x1194319747_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s537155342x1194319747_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epackageRead(V, V, V, V);
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackageRead_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s12009349x1683269345(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s12009349x1683269345_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s12009349x1683269345_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s73970158x1828258719(V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s73970158x1828258719_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s73970158x1828258719_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451(V);
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1972626640x599963156(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s1972626640x599963156_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s1972626640x599963156_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s240089035x833146738(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s240089035x833146738_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s240089035x833146738_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2eutil_2ehostpath_2eisUnder(V, V, V);
V g_heff_2eutil_2ehostpath_2eisUnder_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2eisUnder_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s41451459x2069155315_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1313398329x1387572461(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1313398329x1387572461_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1313398329x1387572461_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1511525408x973271992(V, V);
V g_list_2ekeepIf_24s1511525408x973271992_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1511525408x973271992_clo;
V g_list_2ekeepIf_24s188390362x2017344139(V, V, V);
V g_list_2ekeepIf_24s188390362x2017344139_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s188390362x2017344139_clo;
V g_list_2ekeepIf_24s684755021x1118425975(V, V);
V g_list_2ekeepIf_24s684755021x1118425975_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s684755021x1118425975_clo;
V g_list_2emap_24f2056124927x822823214(V, V, V);
V g_list_2emap_24f2056124927x822823214_entry(V self, V *a);
extern Clo g_list_2emap_24f2056124927x822823214_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT2 g_std_2epath_2erelative_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(heff_rfield(v_ps_240, 4))));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, heff_dup(v_d_241)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_st_248 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_249 = (g_std_2epath_2eparse(v_st_248, heff_dup(heff_rfield(v_ps_240, 4))));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_248, heff_dup(v_path_242)));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  V v_t_2412 = ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
  V v_t_2413 = (g_heff_2eutil_2ehostpath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_247, v_t_2412));
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    V v_st_2414 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_st_2415 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2416 = (g_std_2epath_2eparse(v_st_2415, heff_dup(heff_rfield(v_ps_240, 4))));
    V v_t_2417 = (g_std_2epath_2eparse(v_st_2415, v_d_241));
    V v_t_2418 = (g_std_2epath_2ejoin(v_t_2416, v_t_2417));
    V v_from_2419 = ({ V a_0 = v_st_2415; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2418); r_; });
    V v_st_2420 = heff_take_field(v_ps_240, 5);
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2420, heff_get_n(v_ps_240, 4, 6)));
    V v_t_2422 = (g_std_2epath_2eparse(v_st_2420, v_path_242));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    V v_to_2424 = ({ V a_0 = v_st_2420; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2423); r_; });
    V v_t_2425 = (g_std_2epath_2eparse(v_st_2414, v_from_2419));
    V v_t_2426 = (g_std_2epath_2eparse(v_st_2414, v_to_2424));
    HeffT2 v_t_2427 = (g_std_2epath_2erelative_24cpr(v_st_2414, v_t_2425, v_t_2426));
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        V v_x_2431 = v_field_2429;
        V v_f_2432 = ({ V a_0 = v_st_2414; V a_1 = v_x_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_x_2431); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
      } else {
        heff_drop(v_st_2414);
        heff_drop(v_field_2429);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_t_2413);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str6, 1, ".");
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_path_241)));
  V v_p_2417;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_path_241);
      V v_rel_246 = v_field_244;
      v_p_2417 = v_rel_246;
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_247 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 1)), heff_dup(v_path_241)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_path_241);
          V v_rel_2411 = v_field_249;
          v_p_2417 = v_rel_2411;
        } else {
          heff_drop(v_field_249);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(v_path_241)));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              heff_drop(v_path_241);
              V v_rel_2416 = v_field_2414;
              v_p_2417 = v_rel_2416;
            } else {
              heff_drop(v_field_2414);
              v_p_2417 = v_path_241;
            }
          }
        }
      }
    }
  }
  int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
  V v_t_2419 = heff_strSlice(heff_dup(v_p_2417), heff_box_word(v_t_2418), heff_strLength_lent(v_p_2417, 0));
  V v_t_2422;
  if (heff_strEq_c(v_t_2419, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
    int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
    v_t_2422 = heff_strSlice(v_p_2417, MK_INT(0LL), heff_box_word(v_t_2421));
  } else {
    v_t_2422 = v_p_2417;
  }
  HeffT3 v_t_2423 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_t_2422; HeffT3 r_ = (g_std_2epath_2eparse_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_d_2427 = v_field_2424;
    heff_drop(v_d_2427);
    V v_a_2428 = v_field_2425;
    V v_xs_2429 = v_field_2426;
    V v_xs_2430 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str1); V a_1 = v_a_2428; V a_2 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2); V b_3 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str3); V a_4 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2429; V r_ = (g_list_2efoldl_24s1313398329x1387572461(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2428); heff_drop(b_3); r_; });
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
    V v_x2_2432 = v_t_2431;
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str5);
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_xs_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str6); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2einside_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2einside_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2einside_entry, 3, 0};

V g_heff_2ebuild_2eload_2einside(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  if (heff_strEq_c_lent(v_d_241, ((V)&g_heff_2ebuild_2eload_2einside_str0), 2)) {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    return NTAG(TAG_True);
  } else {
    V v_st_244 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_245 = (g_std_2epath_2eparse(v_st_244, heff_dup(heff_rfield(v_ps_240, 4))));
    V v_t_246 = (g_std_2epath_2eparse(v_st_244, v_d_241));
    V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
    V v_t_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
    V v_st_249 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2410 = (g_std_2epath_2eparse(v_st_249, heff_take_field(v_ps_240, 4)));
    V v_t_2411 = (g_std_2epath_2eparse(v_st_249, v_path_242));
    V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
    V v_t_2413 = ({ V a_0 = v_st_249; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_249); heff_drop(v_t_2412); r_; });
    return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_t_248; V a_2 = v_t_2413; V r_ = (g_heff_2eutil_2ehostpath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  }
}
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2einside(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2esameDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2esameDir(V v_h_240, V v_a_241, V v_b_242) {
top: ;
  V v_st_243 = heff_dup(heff_rfield(v_h_240, 3));
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(heff_rfield(v_h_240, 2))));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, v_a_241));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_t_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_heff_2eutil_2ehostpath_2enormalize(heff_rfield(v_h_240, 3), v_t_247));
  V v_st_249 = heff_dup(heff_rfield(v_h_240, 3));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_249, heff_take_field(v_h_240, 2)));
  V v_t_2411 = (g_std_2epath_2eparse(v_st_249, v_b_242));
  V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
  V v_t_2413 = ({ V a_0 = v_st_249; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_249); heff_drop(v_t_2412); r_; });
  V v_t_2414 = ({ V b_0 = heff_get_n(v_h_240, 3, 5); V a_1 = v_t_2413; V r_ = (g_heff_2eutil_2ehostpath_2enormalize(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_strEq(v_t_248, v_t_2414);
}
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2esameDir(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eheffAt_str0, 3, "lib");
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eheffAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eheffAt_entry, 2, 0};

V g_heff_2ebuild_2eload_2eheffAt(V v_h_240, V v_d_241) {
top: ;
  V v_t_243 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2eload_2eheffAt_lam0, 1, 2, (V[]){heff_dup(v_h_240), heff_dup(v_d_241)}), heff_rfield(v_h_240, 4)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop_rec(v_h_240, 5);
    heff_drop(v_d_241);
    heff_drop(v_t_243);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    V v_st_244 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_245 = (g_std_2epath_2eparse(v_st_244, v_d_241));
    V v_t_246 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ebuild_2eload_2eheffAt_str0)));
    V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
    V v_t_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
    return (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_240), heff_get_n(v_h_240, 0, 5), v_t_248));
  }
}
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eheffAt(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2eload_2esameDir(v_h_240, v_o_242, v_d_241));
}
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str0, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str1, 3, "lib");
Clo g_heff_2ebuild_2eload_2elibRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2elibRead_entry, 3, 0};

V g_heff_2ebuild_2eload_2elibRead(V v_h_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    heff_drop(v_d_241);
    return heff_get_n(v_h_240, 0, 5);
  }
  case TAG_Right: {
    V v_pk_244 = heff_field(v_x3_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_244, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_t_246 = (g_heff_2ebuild_2eload_2eheffAt(heff_dup(v_h_240), heff_dup(v_d_241)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_st_247 = heff_dup(heff_rfield(v_h_240, 3));
        V v_t_248 = (g_std_2epath_2eparse(v_st_247, heff_dup(v_d_241)));
        V v_t_249 = (g_std_2epath_2eparse(v_st_247, ((V)&g_heff_2ebuild_2eload_2elibRead_str0)));
        V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
        V v_t_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
        V v_x1_2412 = (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_240), heff_dup(heff_rfield(v_h_240, 0)), v_t_2411));
        if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
          heff_drop(v_d_241);
          heff_drop(v_x1_2412);
          return heff_get_n(v_h_240, 0, 5);
        } else {
          heff_drop(v_x1_2412);
          V v_st_2413 = heff_get_n(v_h_240, 3, 5);
          V v_t_2414 = (g_std_2epath_2eparse(v_st_2413, v_d_241));
          V v_t_2415 = (g_std_2epath_2eparse(v_st_2413, ((V)&g_heff_2ebuild_2eload_2elibRead_str1)));
          V v_t_2416 = (g_std_2epath_2ejoin(v_t_2414, v_t_2415));
          return ({ V a_0 = v_st_2413; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); heff_drop(v_t_2416); r_; });
        }
      } else {
        heff_drop(v_d_241);
        heff_drop(v_t_246);
        return heff_get_n(v_h_240, 0, 5);
      }
    } else {
      heff_drop(v_d_241);
      return heff_get_n(v_h_240, 0, 5);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2elibRead(a[0], a[1], a2); heff_drop(a2); return r;
}

HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_k_242}});
    } else {
      heff_drop_rec(v_k_242, 7);
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2etakeUntil_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      heff_drop(v_rest_244);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_x_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_247;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_pkgs_240);
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_stack_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_pkgs_240);
      heff_drop(v_rest_244);
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ebuild_2eload_2etakeUntil(v_path_243, v_stack_241));
      V v_xs_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, v_t_247});
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_t_246);
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(heff_dup(v_pkgs_240), v_path_243));
      V v_t_2415;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k_2414 = v_field_2412;
          v_t_2415 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2414, 6, 7)));
        } else {
          heff_drop(v_field_2412);
          v_t_2415 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2416 = (g_heff_2ebuild_2eload_2ecycleAmong(heff_dup(v_pkgs_240), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2415));
      V v_x2_2417 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2416)) {
      case TAG_Nothing: {
        return v_x2_2417;
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_x1_2416, 0);
        V v_ru_24x1_2416_24Just = heff_take_reuse_n(v_x1_2416, 1ULL, 1);
        heff_drop(v_x2_2417);
        return heff_tag_at_n(v_ru_24x1_2416_24Just, TAG_Just, 1, (V[]){v_x_2418});
      }
      default: return heff_nomatch(v_x1_2416);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecycleAmong(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str1, 1, "_");
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
    v_t_245 = heff_dup(v_x_241);
  } else {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str0), heff_intShow(heff_dup(v_n_242)));
    v_t_245 = heff_strAppend(heff_dup(v_x_241), v_t_244);
  }
  V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_245}));
  V v_x1_247 = (g_list_2eany(v_t_246, v_taken_240));
  if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_x1_247);
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  } else {
    heff_drop(v_x1_247);
    if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
      heff_drop(v_n_242);
      return v_x_241;
    } else {
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str1), heff_intShow(v_n_242));
      return heff_strAppend(v_x_241, v_t_249);
    }
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2efreeName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str3, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str7, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str11, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str15, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str17, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str18, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str19, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str21, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str22, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str23, 3, ".hf");
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args);
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_from_242)));
  V v_t_246 = heff_bool(((heff_dup(v_t_244) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0))));
  heff_drop(v_t_244);
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_t_246);
    V v_base_247 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_248 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str2), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
    V v_parts_2413;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_parts_2413 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_2410 = heff_field(v_t_249, 0);
      V v_before_2411 = heff_field(v_t_249, 1);
      V v_ru_24t_249_24Cons = heff_take_reuse_n(v_t_249, 3ULL, 2);
      V v_t_2412 = heff_tag_at_n(v_ru_24t_249_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2410, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str3)), v_before_2411});
      v_parts_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2412));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2420 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_247), v_parts_2413));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2420, v_base_247, v_parts_2413, v_w_243}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_246);
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2421 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2422 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2423 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2422; V a_2 = v_project_2421; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2422); r_; });
      V v_t_2461;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2423, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str4))) {
        V v_base_2425 = heff_dup(heff_rfield(v_k_2423, 2));
        V v_xs_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str6), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2426));
        V v_parts_2431;
        switch (heff_tag_of(v_t_2427)) {
        case TAG_Nil: {
          v_parts_2431 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2428 = heff_field(v_t_2427, 0);
          V v_before_2429 = heff_field(v_t_2427, 1);
          V v_ru_24t_2427_24Cons = heff_take_reuse_n(v_t_2427, 3ULL, 2);
          V v_t_2430 = heff_tag_at_n(v_ru_24t_2427_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2428, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str7)), v_before_2429});
          v_parts_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2430));
          break;
        }
        default: heff_nomatch(v_t_2427);
        }
        V v_t_2438 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam1, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2425), v_parts_2431));
        v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2438, v_base_2425, v_parts_2431, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_j_2439 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), v_w_243, MK_INT(0LL), 5);
        V v_t_2441;
        if (heff_intLt_c_lent(v_j_2439, MK_INT(0LL), 2)) {
          heff_drop(v_j_2439);
          v_t_2441 = heff_dup(v_w_243);
        } else {
          v_t_2441 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2439, 6);
        }
        if (heff_strEq_c(v_t_2441, heff_dup(heff_rfield(v_k_2423, 3)))) {
          V v_base_2443 = heff_dup(heff_rfield(v_k_2423, 2));
          V v_xs_2444 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2444));
          V v_parts_2449;
          switch (heff_tag_of(v_t_2445)) {
          case TAG_Nil: {
            v_parts_2449 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2446 = heff_field(v_t_2445, 0);
            V v_before_2447 = heff_field(v_t_2445, 1);
            V v_ru_24t_2445_24Cons = heff_take_reuse_n(v_t_2445, 3ULL, 2);
            V v_t_2448 = heff_tag_at_n(v_ru_24t_2445_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2446, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str11)), v_before_2447});
            v_parts_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2448));
            break;
          }
          default: heff_nomatch(v_t_2445);
          }
          V v_j_2450 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), v_w_243, MK_INT(0LL), 5);
          V v_t_2452;
          if (heff_intLt_c_lent(v_j_2450, MK_INT(0LL), 2)) {
            heff_drop(v_j_2450);
            v_t_2452 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13);
          } else {
            v_t_2452 = heff_strSlice(heff_dup(v_w_243), v_j_2450, heff_strLength_lent(v_w_243, 0));
          }
          V v_m_2453 = heff_strAppend(heff_dup(heff_rfield(v_k_2423, 4)), v_t_2452);
          V v_t_2460 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam2, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2443), v_parts_2449));
          v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2460, v_base_2443, v_parts_2449, v_m_2453}), NTAG(TAG_Nil)});
        } else {
          v_t_2461 = NTAG(TAG_Nil);
        }
      }
      V v_j_2462 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), v_w_243, MK_INT(0LL), 5);
      V v_t_2464;
      if (heff_intLt_c_lent(v_j_2462, MK_INT(0LL), 2)) {
        heff_drop(v_j_2462);
        v_t_2464 = heff_dup(v_w_243);
      } else {
        v_t_2464 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2462, 6);
      }
      V v_j_2465 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str15), v_w_243, MK_INT(0LL), 5);
      V v_t_2467;
      if (heff_intLt_c_lent(v_j_2465, MK_INT(0LL), 2)) {
        heff_drop(v_j_2465);
        v_t_2467 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str16);
      } else {
        v_t_2467 = heff_strSlice(heff_dup(v_w_243), v_j_2465, heff_strLength_lent(v_w_243, 0));
      }
      V v_t_2468 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2423); V a_3 = v_t_2464; V a_4 = v_t_2467; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2464); r_; });
      V v_base_2469 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2470 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str17); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str18), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2470));
      V v_parts_2475;
      switch (heff_tag_of(v_t_2471)) {
      case TAG_Nil: {
        v_parts_2475 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2472 = heff_field(v_t_2471, 0);
        V v_before_2473 = heff_field(v_t_2471, 1);
        V v_ru_24t_2471_24Cons = heff_take_reuse_n(v_t_2471, 3ULL, 2);
        V v_t_2474 = heff_tag_at_n(v_ru_24t_2471_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2472, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str19)), v_before_2473});
        v_parts_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2474));
        break;
      }
      default: heff_nomatch(v_t_2471);
      }
      V v_t_2482 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam3, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2469), v_parts_2475));
      V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2482, v_base_2469, v_parts_2475, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      V v_t_24100;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2423, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str20))) {
        V v_x1_2485 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_take_field(v_k_2423, 2), v_from_242));
        if ((heff_dup(v_x1_2485) == NTAG(TAG_True))) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_w_243);
          heff_drop_rec(v_k_2423, 7);
          heff_drop(v_x1_2485);
          v_t_24100 = NTAG(TAG_Nil);
        } else {
          heff_drop(v_x1_2485);
          V v_base_2486 = heff_get_n(v_k_2423, 1, 7);
          V v_xs_2487 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str22), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2487));
          V v_parts_2492;
          switch (heff_tag_of(v_t_2488)) {
          case TAG_Nil: {
            v_parts_2492 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2489 = heff_field(v_t_2488, 0);
            V v_before_2490 = heff_field(v_t_2488, 1);
            V v_ru_24t_2488_24Cons = heff_take_reuse_n(v_t_2488, 3ULL, 2);
            V v_t_2491 = heff_tag_at_n(v_ru_24t_2488_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2489, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23)), v_before_2490});
            v_parts_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2491));
            break;
          }
          default: heff_nomatch(v_t_2488);
          }
          V v_t_2499 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam4, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2486), v_parts_2492));
          v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2499, v_base_2486, v_parts_2492, v_w_243}), NTAG(TAG_Nil)});
        }
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_from_242);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2423, 7);
        v_t_24100 = NTAG(TAG_Nil);
      }
      V v_t_24101 = (g_prelude_2e_2b_2b(v_t_2483, v_t_24100));
      V v_t_24102 = (g_prelude_2e_2b_2b(v_t_2468, v_t_24101));
      return (g_prelude_2e_2b_2b(v_t_2461, v_t_24102));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args) {
  V v_d_2414 = args[0];
  V v_p_2415 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2416 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2417 = (g_std_2epath_2eparse(v_st_2416, v_d_2414));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_2416, v_p_2415));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  return ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2419); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args) {
  V v_d_2432 = args[0];
  V v_p_2433 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2434 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2435 = (g_std_2epath_2eparse(v_st_2434, v_d_2432));
  V v_t_2436 = (g_std_2epath_2eparse(v_st_2434, v_p_2433));
  V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
  return ({ V a_0 = v_st_2434; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); heff_drop(v_t_2437); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args) {
  V v_d_2454 = args[0];
  V v_p_2455 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2456 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2457 = (g_std_2epath_2eparse(v_st_2456, v_d_2454));
  V v_t_2458 = (g_std_2epath_2eparse(v_st_2456, v_p_2455));
  V v_t_2459 = (g_std_2epath_2ejoin(v_t_2457, v_t_2458));
  return ({ V a_0 = v_st_2456; V a_1 = v_t_2459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2456); heff_drop(v_t_2459); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args) {
  V v_d_2476 = args[0];
  V v_p_2477 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2478 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2479 = (g_std_2epath_2eparse(v_st_2478, v_d_2476));
  V v_t_2480 = (g_std_2epath_2eparse(v_st_2478, v_p_2477));
  V v_t_2481 = (g_std_2epath_2ejoin(v_t_2479, v_t_2480));
  return ({ V a_0 = v_st_2478; V a_1 = v_t_2481; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2478); heff_drop(v_t_2481); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args) {
  V v_d_2493 = args[0];
  V v_p_2494 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2495 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2496 = (g_std_2epath_2eparse(v_st_2495, v_d_2493));
  V v_t_2497 = (g_std_2epath_2eparse(v_st_2495, v_p_2494));
  V v_t_2498 = (g_std_2epath_2ejoin(v_t_2496, v_t_2497));
  return ({ V a_0 = v_st_2495; V a_1 = v_t_2498; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2495); heff_drop(v_t_2498); r_; });
}
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str3, 0, "");
Clo g_heff_2ebuild_2eload_2esameButCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameButCase_entry, 2, 0};

V g_heff_2ebuild_2eload_2esameButCase(V v_a_240, V v_b_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24f2056124927x822823214(v_a_240, MK_INT(0LL), heff_strLength_lent(v_a_240, 0)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_246 = (g_list_2emap_24f2056124927x822823214(v_b_241, MK_INT(0LL), heff_strLength_lent(v_b_241, 0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  return heff_strEq(v_t_245, v_t_249);
}
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eload_2esameButCase(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0, 59, " on the disk: a file system that tells case apart finds no ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1, 10, " is named ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5, 74, ": names that differ only in case are one file where case is not told apart");

HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243) {
top: ;
  switch (heff_tag_of(v_ns_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_x_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_n_244 = heff_dup(heff_field(v_ns_243, 0));
    V v_ns2_245 = heff_dup(heff_field(v_ns_243, 1));
    switch (heff_tag_of(v_ns2_245)) {
    case TAG_Nil: {
      heff_drop_tag(v_ns_243, 2);
      if (heff_strEq_c_lent(v_n_244, v_x_242, 0)) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_x_242);
        heff_drop(v_n_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_st_247 = heff_get_n(v_ps_240, 5, 6);
        V v_t_248 = (g_std_2epath_2eparse(v_st_247, v_d_241));
        V v_t_249 = (g_std_2epath_2eparse(v_st_247, heff_dup(v_x_242)));
        V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
        V v_t_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
        V v_t_2412 = heff_strAppend(v_n_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0), v_x_242));
        V v_f_2413 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1), v_t_2412));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
      }
    }
    case TAG_Cons: {
      heff_take_n(v_ns2_245, 0ULL, 2);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_x_242);
      heff_drop(v_n_244);
      V v_t_2418;
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Nil: {
        v_t_2418 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_ns_243, 0);
        V v_xs_2417 = heff_field(v_ns_243, 1);
        heff_take_n(v_ns_243, 3ULL, 2);
        v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
        break;
      }
      default: heff_nomatch(v_ns_243);
      }
      V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4), heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5)));
      V v_f_2420 = heff_strAppend(v_d_241, v_t_2419);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ns2_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ns_243)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str1, 10, "package.hf");
Clo g_heff_2ebuild_2eload_2epackageRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackageRead_entry, 4, 0};

V g_heff_2ebuild_2eload_2epackageRead(V v_h_240, V v_ps_241, V v_src_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Left = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_h_240);
    V v_st_245 = heff_take_field(v_ps_241, 5);
    V v_t_246 = (g_std_2epath_2eparse(v_st_245, heff_get_n(v_ps_241, 0, 6)));
    V v_t_247 = (g_std_2epath_2eparse(v_st_245, ((V)&g_heff_2ebuild_2eload_2epackageRead_str0)));
    V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_249, v_src_242, v_p_244));
    return heff_tag_at_n(v_ru_24x4_243_24Left, TAG_Left, 1, (V[]){v_t_2410});
  }
  case TAG_Right: {
    V v_pk_2411 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Right = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2411, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_x1_2413 = (g_heff_2ebuild_2eload_2eheffAt(v_h_240, heff_dup(heff_rfield(v_ps_241, 0))));
      if ((heff_dup(v_x1_2413) == NTAG(TAG_True))) {
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_x1_2413);
        return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_2411});
      } else {
        heff_drop_rec(v_pk_2411, 4);
        heff_drop_cell(v_ru_24x4_243_24Right, 1);
        heff_drop(v_x1_2413);
        V v_st_2414 = heff_take_field(v_ps_241, 5);
        V v_t_2415 = (g_std_2epath_2eparse(v_st_2414, heff_get_n(v_ps_241, 0, 6)));
        V v_t_2416 = (g_std_2epath_2eparse(v_st_2414, ((V)&g_heff_2ebuild_2eload_2epackageRead_str1)));
        V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
        V v_t_2418 = ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2417); r_; });
        V v_t_2419 = (g_heff_2ebuild_2eproject_2epackageLit(v_src_242));
        V v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2ebuild_2eproject_2eclaimOf(a_0)); heff_drop(v_t_2419); r_; });
        V v_t_2421 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2418, v_src_242, v_t_2420));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
      }
    } else {
      heff_drop(v_h_240);
      heff_drop_rec(v_ps_241, 6);
      return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_2411});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2epackageRead(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_244 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_why_245 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_245, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_244, 0ULL, 1);
      v_t_247 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2410;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_249 = heff_field(v_pkgs_242, 1);
    v_t_2410 = heff_dup(v_y_249);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_take_field(v_st_243, 2)));
  V v_t_2412 = (g_prelude_2e_2b_2b(v_t_247, v_t_2411));
  V v_t_2416;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2413 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      heff_take_n(v_x11_2413, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2415 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2415});
      break;
    }
    default: heff_nomatch(v_x11_2413);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2419;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_pkgs_242, 0);
    v_t_2419 = heff_dup(v_x_2417);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){heff_get_n(v_st_243, 0, 3), v_t_2412, v_ps_240, v_t_2416, v_t_2419});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry, 2, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_243 = (g_std_2epath_2eparse_24cpr(v_st_242, heff_dup(v_file_241)));
  V v_t_2413;
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_d_247 = v_field_244;
    V v_a_248 = v_field_245;
    V v_xs_249 = v_field_246;
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_xs_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2410; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
    v_t_2413 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_247, v_a_248, v_t_2412});
  }
  V v_t_2414 = ({ V a_0 = v_st_242; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2413); r_; });
  V v_st_2415 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_2416 = (g_std_2epath_2eparse_24cpr(v_st_2415, v_file_241));
  V v_t_2426;
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2418 = v_t_2416.f[1];
    V v_field_2419 = v_t_2416.f[2];
    V v_d_2420 = v_field_2417;
    V v_a_2421 = v_field_2418;
    V v_xs_2422 = v_field_2419;
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2422));
    V v_xs_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2423; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    v_t_2426 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2420, v_a_2421, v_t_2425});
  }
  V v_t_2427 = ({ V a_0 = v_st_2415; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2426); r_; });
  return (g_heff_2ebuild_2eload_2erootFrom_24s240089035x833146738(v_h_240, v_t_2414, v_t_2427));
}
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str2, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str3, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str5, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str6, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str7, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str9, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str10, 1, " ");
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_246 = (g_list_2ekeepIf_24s684755021x1118425975(v_path_244, heff_take_field(v_root_241, 2)));
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    V v_t_249 = (g_list_2ekeepIf_24s1511525408x973271992(v_r_247, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_s_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str0));
    V v_path_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2414; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2415; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2415); r_; });
    V v_a_2418 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2416, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam0_clo)});
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam1, 2, 6, (V[]){v_a_2418, v_v_245, v_path_244, v_by_243, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2455 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2456 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2457 = (g_std_2epath_2eparse(v_st_2456, heff_dup(heff_rfield(v_ps_240, 0))));
    V v_t_2458 = (g_std_2epath_2eparse(v_st_2456, v_d_2455));
    V v_t_2459 = (g_std_2epath_2ejoin(v_t_2457, v_t_2458));
    V v_t_2460 = ({ V a_0 = v_st_2456; V a_1 = v_t_2459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2456); heff_drop(v_t_2459); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257(v_ps_240, v_t_2460, v_path_244));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam0(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_v_245 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_by_243 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2419 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Nothing: {
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2419);
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str1), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str2)));
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str3), heff_strAppend(v_path_244, v_t_2428));
    V v_t_2430 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_by_243, v_t_2429)});
    V f_ = v_k_2420;
    args[0] = v_t_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_h_2431 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Just = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2432 = (g_list_2ekeepIf_24s188390362x2017344139(v_path_244, v_v_245, v_sums_242));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2419);
      heff_drop(v_h_2431);
      heff_drop_cell(v_ru_24x_2427_24Just, 1);
      V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str4), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str5)));
      V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str6), heff_strAppend(v_path_244, v_t_2433));
      V f_ = v_k_2420;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2434});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_s_2435 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 2);
      V v_want_2437 = heff_get_n(v_s_2435, 2, 3);
      V v_t_2438 = (g_prelude_2eskipSpaces(v_h_2431, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_h_2431, 0)) - ((int64_t)1ULL));
      V v_t_2440 = (g_prelude_2eskipSpaces(v_h_2431, heff_box_word(v_t_2439), MK_INT(-1LL)));
      V v_t_2441 = heff_strSlice(heff_dup(v_h_2431), v_t_2438, heff_intAdd(v_t_2440, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2441, v_want_2437, 1)) {
        heff_drop(v_h_2431);
        heff_drop_cell(v_ru_24x_2427_24Just, 1);
        heff_drop(v_want_2437);
        V v_t_2443 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2444 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257(v_ps_240, v_t_2443, v_path_244));
        V f_ = v_t_2444;
        heff_room[0] = v_hd_2419;
        heff_room[1] = v_k_2420;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_hd_2419);
        V v_t_2445 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_244), heff_dup(v_v_245)));
        V v_t_2446 = (g_prelude_2eskipSpaces(v_h_2431, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2447 = (heff_unbox_word(heff_strLength_lent(v_h_2431, 0)) - ((int64_t)1ULL));
        V v_t_2448 = (g_prelude_2eskipSpaces(v_h_2431, heff_box_word(v_t_2447), MK_INT(-1LL)));
        V v_t_2449 = heff_strSlice(v_h_2431, v_t_2446, heff_intAdd(v_t_2448, MK_INT(1LL)));
        V v_t_2450 = heff_strAppend(v_t_2449, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str7), v_want_2437));
        V v_t_2451 = heff_strAppend(v_t_2445, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str8), v_t_2450));
        V v_t_2452 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str9), v_t_2451));
        V v_t_2453 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_str10), v_t_2452));
        V v_x_2454 = heff_tag_at_n(v_ru_24x_2427_24Just, TAG_Left, 1, (V[]){v_t_2453});
        V f_ = v_k_2420;
        args[0] = v_x_2454;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_a_2418 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_by_243 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2418})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s495635622x733177935(v_t_2426, heff_dup(v_hd_2419), heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s511122923x1484899236_lam2, 1, 7, (V[]){v_v_245, v_path_244, v_by_243, v_k_2420, v_sums_242, v_ps_240, v_hd_2419})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam2(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_243 = heff_field(v_x2_240, 0);
    V v_rest_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(heff_rfield(v_pl_243, 0)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_a_245; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_245); r_; });
    V v_a_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_ReadFile, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam2, 2, 3, (V[]){v_a_248, v_rest_244, v_pl_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451(a[0]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam1(V self, V *args) {
  V v_a_247 = args[0];
  return v_a_247;
}
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_pl_243 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2431;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_243, 4);
    v_x_2431 = v_x_2419;
    break;
  }
  case TAG_Just: {
    V v_s_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    V v_t_2421 = heff_dup(heff_rfield(v_pl_243, 2));
    V v_p_2424;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nil: {
      v_p_2424 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_t_2421, 0);
      V v_xs_2423 = heff_field(v_t_2421, 1);
      heff_take_n(v_t_2421, 3ULL, 2);
      v_p_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_str1); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_p_2424, 0)) - ((int64_t)3ULL));
    V v_t_2426 = heff_strSlice(heff_dup(v_p_2424), heff_box_word(v_t_2425), heff_strLength_lent(v_p_2424, 0));
    V v_t_2429;
    if (heff_strEq_c(v_t_2426, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_str2))) {
      int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_2424, 0)) - ((int64_t)3ULL));
      v_t_2429 = heff_strSlice(v_p_2424, MK_INT(0LL), heff_box_word(v_t_2428));
    } else {
      v_t_2429 = v_p_2424;
    }
    V v_t_2430 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), v_s_2420, heff_dup(v_pl_243), heff_get_n(v_pl_243, 3, 4), v_t_2429});
    v_x_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_k_2410;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2418 = (g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451(v_rest_244));
  V f_ = v_c_2418;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam4, 1, 3, (V[]){v_x_2417, v_pl_243, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_a_248 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s22628809x1035315751(v_t_2416, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451_lam3, 1, 4, (V[]){v_rest_244, v_hd_249, v_pl_243, v_k_2410})));
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_entry, 6, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam0, 2, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2411 = (g_heff_2ebuild_2eload_2eloadMany_24s537155342x1194319747(heff_dup(v_before_243), heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam1, 2, 7, (V[]){v_c_2411, v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_before_243, v_t_2415));
  V v_t_2419;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 2);
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2420 = (g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131(v_ps_240, v_pkgs_241, v_from_242, v_t_2416, v_ms_249, v_t_2419));
  V f_ = v_t_2420;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_m_248 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_from_242 = heff_env(self)[5];
  V v_ms_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131_lam2, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_imp_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_stack_242);
    heff_drop(v_from_243);
    heff_drop(v_imp_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_c_2413 = (g_heff_2ebuild_2eload_2ereadEvery_24s622702791x2088398451(v_t_2412));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam1, 2, 10, (V[]){v_c_2413, v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_rs_247 = heff_env(self)[4];
  V v_pkgs_241 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_from_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2476 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2429, 3))}));
  V v_t_2479;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2478 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2479 = v_y_2478;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2480 = (g_heff_2ebuild_2eload_2epushDone(v_t_2475, heff_dup(v_ps_240), heff_dup(heff_rfield(v_f_2429, 3)), heff_take_field(v_f_2429, 4), heff_take_field(v_f_2429, 0), heff_take_field(v_f_2429, 1), v_t_2476, v_t_2479));
  V v_m_2481 = heff_get_n(v_f_2429, 3, 5);
  V v_t_2483;
  if (heff_strEq_c_lent(v_w_2410, v_m_2481, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2481);
    v_t_2483 = v_rs_247;
  } else {
    v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2481}), v_rs_247});
  }
  V v_t_2484 = (g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2480, v_t_2483));
  V f_ = v_t_2484;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam3(V self, V *args) {
  V v_x_2458 = args[0];
  V v_f_2429 = heff_env(self)[0];
  V v_stack_242 = heff_env(self)[1];
  V v_imp_244 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  V v_pkgs_241 = heff_env(self)[7];
  V v_hd_2414 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  V v_rest_2411 = heff_env(self)[10];
  V v_k_2415 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2429, 3)), heff_dup(v_stack_242)});
  V v_t_2460 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(heff_rfield(v_f_2429, 3))}));
  V v_t_2461 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2460, heff_dup(heff_rfield(v_f_2429, 1))));
  V v_imps_2462 = heff_get_n(v_t_2461, 0, 4);
  V v_t_2463 = (g_list_2emap_24s1817208647x1282894070(v_imps_2462));
  V v_t_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
  V v_t_2470;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_t_2470 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2465 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    V v_t_2466 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str9), v_why_2465));
    V v_t_2467 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str10), v_t_2466));
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2468));
    v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_c_2471 = (g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(heff_dup(v_ps_240), heff_dup(v_pkgs_241), v_t_2459, heff_dup(heff_rfield(v_f_2429, 0)), heff_dup(v_imp_244), v_t_2464, v_t_2470, NTAG(TAG_Nil)));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_2414);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam4, 1, 11, (V[]){v_imp_244, v_f_2429, v_ps_240, v_w_2410, v_rs_247, v_pkgs_241, v_stack_242, v_from_243, v_rest_2411, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_pkgs_241 = heff_env(self)[1];
  V v_from_243 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_imp_244 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nil: {
    V v_places_2417 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_x2_2418 = (g_list_2emap_24s435407392x1528135477(v_places_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str1); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str2), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str3)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str4), heff_strAppend(v_w_2410, v_t_2422));
    V v_e_2424 = heff_strAppend(heff_dup(v_from_243), v_t_2423);
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2424, NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2425));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2428 = (g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2427, v_rs_247));
    V f_ = v_t_2428;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2429 = heff_dup(heff_field(v_x_2416, 0));
    V v_others_2430 = heff_dup(heff_field(v_x_2416, 1));
    V v_t_2431 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2429, 3))}));
    V v_t_2432 = (g_list_2eany(v_t_2431, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2416, 2);
      heff_drop(v_others_2430);
      heff_drop(v_t_2432);
      V v_m_2433 = heff_get_n(v_f_2429, 3, 5);
      V v_t_2435;
      if (heff_strEq_c_lent(v_w_2410, v_m_2433, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2433);
        v_t_2435 = v_rs_247;
      } else {
        v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2433}), v_rs_247});
      }
      V v_t_2436 = (g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_st_246, v_t_2435));
      V f_ = v_t_2436;
      heff_room[0] = v_hd_2414;
      heff_room[1] = v_k_2415;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2432);
      V v_t_2437 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2429, 3))}));
      V v_t_2438 = (g_list_2eany(v_t_2437, v_stack_242));
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2416, 2);
        heff_drop(v_others_2430);
        heff_drop(v_t_2438);
        V v_m_2439 = heff_dup(heff_rfield(v_f_2429, 3));
        V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_242)));
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2439), NTAG(TAG_Nil)});
        V v_x2_2442 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
        V v_t_2445;
        switch (heff_tag_of(v_x2_2442)) {
        case TAG_Nil: {
          v_t_2445 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2443 = heff_field(v_x2_2442, 0);
          V v_xs_2444 = heff_field(v_x2_2442, 1);
          heff_take_n(v_x2_2442, 3ULL, 2);
          v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str6); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2442);
        }
        V v_t_2446 = heff_strAppend(v_m_2439, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str7), v_t_2445));
        V v_e_2447 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_str8), v_t_2446));
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2447, NTAG(TAG_Nil)});
        V v_t_2449 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2448));
        V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2451 = heff_get_n(v_f_2429, 3, 5);
        V v_t_2453;
        if (heff_strEq_c_lent(v_w_2410, v_m_2451, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2451);
          v_t_2453 = v_rs_247;
        } else {
          v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2451}), v_rs_247});
        }
        V v_t_2454 = (g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2450, v_t_2453));
        V f_ = v_t_2454;
        heff_room[0] = v_hd_2414;
        heff_room[1] = v_k_2415;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2438);
        switch (heff_tag_of(v_others_2430)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2416, 2);
          V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_f_2429, 2)), 1, 4);
          V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_f_2429, 2)), 2, 4);
          V v_c_2457 = (g_heff_2ebuild_2eload_2epartsNamed_24s73970158x1828258719(heff_dup(v_ps_240), v_t_2455, v_t_2456));
          V f_ = v_c_2457;
          heff_room[0] = heff_dup(v_hd_2414);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam3, 1, 12, (V[]){v_f_2429, v_stack_242, v_imp_244, v_st_246, v_w_2410, v_from_243, v_ps_240, v_pkgs_241, v_hd_2414, v_rs_247, v_rest_2411, v_k_2415});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2430_24Cons = heff_take_reuse_n(v_others_2430, 0ULL, 2);
          V v_e_2487 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_240), v_x_2416, heff_dup(v_from_243), heff_dup(v_w_2410)));
          V v_t_2488 = heff_tag_at_n(v_ru_24others_2430_24Cons, TAG_Cons, 2, (V[]){v_e_2487, NTAG(TAG_Nil)});
          V v_t_2489 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2488));
          V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2429, 3)), heff_take_field(v_st_246, 1)});
          V v_t_2491 = ({ V rv_1 = v_t_2490; V rv_2 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_st_246, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2492 = heff_get_n(v_f_2429, 3, 5);
          V v_t_2494;
          if (heff_strEq_c_lent(v_w_2410, v_m_2492, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2492);
            v_t_2494 = v_rs_247;
          } else {
            v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2492}), v_rs_247});
          }
          V v_t_2495 = (g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2491, v_t_2494));
          V f_ = v_t_2495;
          heff_room[0] = v_hd_2414;
          heff_room[1] = v_k_2415;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2430);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pkgs_241 = heff_env(self)[2];
  V v_from_243 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_imp_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581_lam2, 1, 11, (V[]){v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam4(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam4, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_entry, 2, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742(V v_h_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(heff_dup(v_h_240), heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam0, 2, 3, (V[]){v_c_242, v_h_240, v_file_241});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam4(V self, V *args) {
  V v_a_2416 = args[0];
  return v_a_2416;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam7(V self, V *args) {
  V v_m_2452 = args[0];
  V v_made_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2453 = ({ V a_0 = v_m_2452; V a_1 = v_made_2435; HeffT2 r_ = (g_list_2efind_24s41451459x2069155315_24cpr(a_0, a_1)); heff_drop(v_m_2452); r_; });
  {
    V v_field_2455 = v_t_2453.f[1];
    int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
    if ((v_tag_2454 == ((int64_t)0ULL))) {
      V v_s_2457 = v_field_2455;
      return heff_get_n(v_s_2457, 6, 8);
    } else {
      heff_drop(v_field_2455);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_made_2435 = heff_env(self)[2];
  V v_src_2429 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2462;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_dup(heff_field(v_x_2459, 0));
    v_t_2462 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_t_2463 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2464 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_2465 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2466 = ({ V a_0 = v_m_2465; V a_1 = v_made_2435; HeffT2 r_ = (g_list_2efind_24s41451459x2069155315_24cpr(a_0, a_1)); heff_drop(v_m_2465); r_; });
  V v_t_2471;
  {
    V v_field_2468 = v_t_2466.f[1];
    int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
    if ((v_tag_2467 == ((int64_t)0ULL))) {
      V v_s_2470 = v_field_2468;
      v_t_2471 = heff_get_n(v_s_2470, 6, 8);
    } else {
      heff_drop(v_field_2468);
      v_t_2471 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2474;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_MkPair: {
    V v_y_2473 = heff_field(v_x_2459, 1);
    heff_take_n(v_x_2459, 2ULL, 2);
    v_t_2474 = v_y_2473;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_t_2475 = (g_heff_2ebuild_2eload_2epushDone(v_t_2462, heff_dup(v_x_245), v_t_2463, v_t_2464, v_file_241, v_src_2429, v_t_2471, v_t_2474));
  V v_x_2476 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2475; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_244;
  args[0] = v_x_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_src_2429 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_made_2435 = heff_get_n(v_x_2434, 0, 3);
  V v_t_2438;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2438 = v_x_2436;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2439 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
  V v_m_2441 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2442 = ({ V a_0 = v_m_2441; V a_1 = heff_dup(v_made_2435); HeffT2 r_ = (g_list_2efind_24s41451459x2069155315_24cpr(a_0, a_1)); heff_drop(v_m_2441); r_; });
  V v_t_2447;
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_s_2446 = v_field_2444;
      v_t_2447 = heff_get_n(v_s_2446, 6, 8);
    } else {
      heff_drop(v_field_2444);
      v_t_2447 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2448 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2447, heff_dup(v_src_2429)));
  V v_imps_2449 = heff_get_n(v_t_2448, 0, 4);
  V v_t_2450 = (g_list_2emap_24s1817208647x1282894070(v_imps_2449));
  V v_t_2451 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2450));
  V v_c_2458 = (g_heff_2ebuild_2eload_2eloadMany_24s498769940x579058581(heff_dup(v_x_245), v_t_2438, v_t_2440, heff_dup(v_file_241), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam7, 1, 1, (V[]){heff_dup(v_made_2435)}), v_t_2451, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2458;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam8, 1, 7, (V[]){v_x_245, v_file_241, v_made_2435, v_src_2429, v_x_247, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2425));
    V v_t_2427 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2426});
    V v_x_2428 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2427; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
    V f_ = v_k_244;
    args[0] = v_x_2428;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2429 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    V v_t_2432;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2432 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_c_2433 = (g_heff_2ebuild_2eload_2emadeOfGo_24s809671628x1446456131(heff_dup(v_x_245), v_t_2432, heff_dup(v_file_241), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2433;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam6, 1, 7, (V[]){v_x_2413, v_x_245, v_file_241, v_src_2429, v_hd_243, v_x_247, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_a_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_file_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_a_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_a_2414); r_; });
  V v_a_2417 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam4_clo)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s22628809x1035315751(v_t_2423, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam5, 1, 6, (V[]){v_file_241, v_x_245, v_x_247, v_x_2413, v_k_244, v_hd_243})));
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_2412 = (g_heff_2ebuild_2eload_2epackagesOf_24s12009349x1683269345(heff_dup(v_x_245), v_t_2411));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam3, 1, 5, (V[]){v_file_241, v_hd_243, v_x_245, v_x_247, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s1972626640x599963156(v_h_240, heff_dup(v_x_245)));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s789940797x1463274742_lam1, 1, 4, (V[]){v_h_240, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_entry, 7, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam0, 2, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s42671976x288945834(heff_dup(v_before_244), heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam1, 2, 8, (V[]){v_c_2412, v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_hd_2413 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_before_244, v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2421 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2417, v_ms_2410, v_t_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  V v_before_244 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_ms_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1026546063x1747579401_lam2, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}