// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Right 62770
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2enamedGo(V, V);
V g_heff_2ebuild_2eload_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2enamedGo_clo;
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106(V, V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249(V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242(V, V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_clo;
V g_heff_2ebuild_2eload_2ereadEvery(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053(V, V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206(V, V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2eutil_2ehostpath_2eisUnder(V, V, V);
V g_heff_2eutil_2ehostpath_2eisUnder_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2eisUnder_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f201346761x152404242(V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1462590149x1582455373(V);
V g_list_2emap_24s1462590149x1582455373_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT4 g_std_2epath_2erelative_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_d_241)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_st_2410 = heff_dup(v_style_243);
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_2410), heff_dup(v_cwd_244)));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2410), heff_dup(v_path_242)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
  V v_t_2415 = (g_heff_2eutil_2ehostpath_2eisUnder(heff_dup(v_style_243), v_t_249, v_t_2414));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    V v_st_2416 = heff_dup(v_style_243);
    V v_st_2417 = heff_dup(v_style_243);
    V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_cwd_244)));
    V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_241));
    V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
    V v_from_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
    V v_st_2422 = v_style_243;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_cwd_244));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_path_242));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    V v_to_2426 = ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_from_2421));
    V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_to_2426));
    HeffT4 v_t_2429 = (g_std_2epath_2erelative_24cpr(heff_dup(v_st_2416), v_t_2427, v_t_2428));
    {
      V v_field_2431 = v_t_2429.f[1];
      V v_field_2432 = v_t_2429.f[2];
      V v_field_2433 = v_t_2429.f[3];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2434 = heff_tag_n(TAG_MkPath, 3, (V[]){v_field_2431, v_field_2432, v_field_2433});
        V v_f_2435 = ({ V a_0 = v_st_2416; V a_1 = v_x_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop_tag(v_x_2434, 3); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2435}});
      } else {
        heff_drop(v_st_2416);
        heff_drop(v_field_2431);
        heff_drop(v_field_2432);
        heff_drop(v_field_2433);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    heff_drop(v_t_2415);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str6, 1, ".");
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_ps_240, 5));
  HeffT2 v_t_243 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_path_241)));
  V v_p_2415;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_path_241);
      V v_rel_246 = v_field_245;
      v_p_2415 = v_rel_246;
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_247 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 1)), heff_dup(v_path_241)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_path_241);
          V v_rel_2410 = v_field_249;
          v_p_2415 = v_rel_2410;
        } else {
          heff_drop(v_field_249);
          HeffT2 v_t_2411 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 0, 6), heff_dup(v_path_241)));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop(v_path_241);
              V v_rel_2414 = v_field_2413;
              v_p_2415 = v_rel_2414;
            } else {
              heff_drop(v_field_2413);
              v_p_2415 = v_path_241;
            }
          }
        }
      }
    }
  }
  int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_2415, 0)) - ((int64_t)3ULL));
  V v_t_2417 = heff_strSlice(heff_dup(v_p_2415), heff_box_word(v_t_2416), heff_strLength_lent(v_p_2415, 0));
  V v_t_2419;
  if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_p_2415, 0)) - ((int64_t)3ULL));
    v_t_2419 = heff_strSlice(v_p_2415, MK_INT(0LL), heff_box_word(v_t_2418));
  } else {
    v_t_2419 = v_p_2415;
  }
  HeffT3 v_t_2420 = (g_std_2epath_2eparse_24cpr(v_st_242, v_t_2419));
  {
    V v_field_2421 = v_t_2420.f[0];
    V v_field_2422 = v_t_2420.f[1];
    V v_field_2423 = v_t_2420.f[2];
    V v_d_2424 = v_field_2421;
    heff_drop(v_d_2424);
    V v_a_2425 = v_field_2422;
    V v_xs_2426 = v_field_2423;
    V v_xs_2427 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str1); V a_1 = v_a_2425; V a_2 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2); V b_3 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str3); V a_4 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2426; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2425); heff_drop(b_3); r_; });
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
    V v_x2_2429 = v_t_2428;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str5);
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str6); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2einside_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2einside_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2einside_entry, 3, 0};

V g_heff_2ebuild_2eload_2einside(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  if (heff_strEq_c_lent(v_d_241, ((V)&g_heff_2ebuild_2eload_2einside_str0), 2)) {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    return NTAG(TAG_True);
  } else {
    V v_st_245 = heff_dup(v_style_243);
    V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_241));
    V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
    V v_st_2410 = heff_dup(v_style_243);
    V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_2410), v_cwd_244));
    V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2410), v_path_242));
    V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
    V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
    HEFF_LAST return g_heff_2eutil_2ehostpath_2eisUnder(v_style_243, v_t_249, v_t_2414);
  }
}
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2einside(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2esameDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2esameDir(V v_h_240, V v_a_241, V v_b_242) {
top: ;
  V v_style_243 = heff_take_field(v_h_240, 3);
  V v_cwd_244 = heff_get_n(v_h_240, 2, 5);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_a_241));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_heff_2eutil_2ehostpath_2enormalize(heff_dup(v_style_243), v_t_249));
  V v_st_2411 = heff_dup(v_style_243);
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2411), v_cwd_244));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2411), v_b_242));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = v_st_2411; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2411); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2eutil_2ehostpath_2enormalize(v_style_243, v_t_2415));
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2410, v_t_2416, 0));
  heff_drop(v_t_2410);
  heff_drop(v_t_2416);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2esameDir(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eheffAt_str0, 3, "lib");
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eheffAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eheffAt_entry, 2, 0};

V g_heff_2ebuild_2eload_2eheffAt(V v_h_240, V v_d_241) {
top: ;
  V v_t_243 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2eload_2eheffAt_lam0, 1, 2, (V[]){heff_dup(v_h_240), heff_dup(v_d_241)}), heff_rfield(v_h_240, 4)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop_rec(v_h_240, 5);
    heff_drop(v_d_241);
    heff_drop(v_t_243);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    V v_st_244 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_d_241));
    V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2eload_2eheffAt_str0)));
    V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
    V v_t_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
    return (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_240), heff_get_n(v_h_240, 0, 5), v_t_248));
  }
}
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eheffAt(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2eload_2esameDir(v_h_240, v_o_242, v_d_241));
}

HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_k_242)}});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_entry, 6, 0};

V g_heff_2ebuild_2eload_2eversionsGo(V v_e_240, V v_rd_241, V v_root_242, V v_x3_243, V v_seen_244, V v_errs_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_rd_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_lam0, 2, 2, (V[]){v_seen_244, v_errs_245});
  }
  case TAG_Cons: {
    V v_n_248 = heff_field(v_x3_243, 0);
    V v_rest_249 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_path_2410 = heff_take_field(v_n_248, 1);
    V v_version_2411 = heff_take_field(v_n_248, 2);
    V v_by_2412 = heff_get_n(v_n_248, 0, 3);
    if (heff_strEq_c_lent(v_path_2410, v_root_242, 0)) {
      heff_drop(v_path_2410);
      heff_drop(v_version_2411);
      heff_drop(v_by_2412);
      V t_0 = v_e_240;
      V t_1 = v_rd_241;
      V t_2 = v_root_242;
      V t_3 = v_rest_249;
      V t_4 = v_seen_244;
      V t_5 = v_errs_245;
      v_e_240 = t_0;
      v_rd_241 = t_1;
      v_root_242 = t_2;
      v_x3_243 = t_3;
      v_seen_244 = t_4;
      v_errs_245 = t_5;
      goto top;
    } else {
      V v_t_2413 = (g_list_2eany_24s241416889x826324235(v_path_2410, v_version_2411, v_seen_244));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_path_2410);
        heff_drop(v_version_2411);
        heff_drop(v_by_2412);
        heff_drop(v_t_2413);
        V t_0 = v_e_240;
        V t_1 = v_rd_241;
        V t_2 = v_root_242;
        V t_3 = v_rest_249;
        V t_4 = v_seen_244;
        V t_5 = v_errs_245;
        v_e_240 = t_0;
        v_rd_241 = t_1;
        v_root_242 = t_2;
        v_x3_243 = t_3;
        v_seen_244 = t_4;
        v_errs_245 = t_5;
        goto top;
      } else {
        heff_drop(v_t_2413);
        V v_c_2414 = heff_tr(heff_call(heff_dup(v_rd_241), 3, (V[]){v_by_2412, heff_dup(v_path_2410), heff_dup(v_version_2411)}));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_lam1, 2, 9, (V[]){v_c_2414, v_path_2410, v_version_2411, v_seen_244, v_errs_245, heff_dup(v_e_240), v_rd_241, heff_dup(v_root_242), v_rest_249});
      }
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eversionsGo(a0, a[1], a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_seen_244 = heff_env(self)[0];
  V v_errs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_244, v_errs_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_path_2410 = heff_env(self)[0];
  V v_version_2411 = heff_env(self)[1];
  V v_seen_244 = heff_env(self)[2];
  V v_errs_245 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_rd_241 = heff_env(self)[5];
  V v_root_242 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  V v_hd_2415 = heff_env(self)[8];
  V v_k_2416 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_why_2418 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    V v_t_2419 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2410, v_version_2411, NTAG(TAG_Nothing)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(v_seen_244, v_t_2420));
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2418, NTAG(TAG_Nil)});
    V v_t_2423 = (g_prelude_2e_2b_2b(v_errs_245, v_t_2422));
    V v_t_2424 = ({ V a_0 = v_e_240; V a_1 = v_rd_241; V a_2 = v_root_242; V a_3 = v_rest_249; V a_4 = v_t_2421; V a_5 = v_t_2423; V r_ = (g_heff_2ebuild_2eload_2eversionsGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_240); heff_drop(v_root_242); r_; });
    V f_ = v_t_2424;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2425 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    V v_t_2426 = heff_strAppend(heff_strAppend(heff_dup(v_path_2410), ((V)&g_heff_2ebuild_2eload_2eversionsGo_str0)), heff_dup(v_version_2411));
    V v_t_2427 = (g_list_2emap_24s675147852x248982264(v_t_2426, heff_dup(heff_rfield(v_pk_2425, 2))));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_rest_249, v_t_2427));
    V v_t_2429 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2410, v_version_2411, heff_tag_n(TAG_Just, 1, (V[]){v_pk_2425})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = (g_prelude_2e_2b_2b(v_seen_244, v_t_2430));
    V v_t_2432 = ({ V a_0 = v_e_240; V a_1 = v_rd_241; V a_2 = v_root_242; V a_3 = v_t_2428; V a_4 = v_t_2431; V a_5 = v_errs_245; V r_ = (g_heff_2ebuild_2eload_2eversionsGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_e_240); heff_drop(v_root_242); r_; });
    V f_ = v_t_2432;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_path_2410 = heff_env(self)[1];
  V v_version_2411 = heff_env(self)[2];
  V v_seen_244 = heff_env(self)[3];
  V v_errs_245 = heff_env(self)[4];
  V v_e_240 = heff_env(self)[5];
  V v_rd_241 = heff_env(self)[6];
  V v_root_242 = heff_env(self)[7];
  V v_rest_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_lam2, 1, 10, (V[]){v_path_2410, v_version_2411, v_seen_244, v_errs_245, v_e_240, v_rd_241, v_root_242, v_rest_249, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2etakeUntil_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      heff_drop(v_rest_244);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1006624359x760861690(v_path_243, v_stack_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ebuild_2eload_2etakeUntil(v_path_243, v_stack_241));
      V v_xs_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, v_t_246});
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
    } else {
      heff_drop(v_t_245);
      HeffT2 v_t_249 = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(v_pkgs_240, v_path_243));
      V v_t_2413;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_k_2412 = v_field_2411;
          v_t_2413 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2412, 6, 7)));
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2414 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2413));
      V v_x2_2415 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nothing: {
        return v_x2_2415;
      }
      case TAG_Just: {
        V v_x_2416 = heff_field(v_x1_2414, 0);
        V v_ru_24x1_2414_24Just = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
        heff_drop(v_x2_2415);
        return heff_tag_at_n(v_ru_24x1_2414_24Just, TAG_Just, 1, (V[]){v_x_2416});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2ecycleAmong(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str1, 1, "_");
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_243;
  if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
    v_t_243 = heff_dup(v_x_241);
  } else {
    v_t_243 = heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2eload_2efreeName_str0)), heff_intShow(heff_dup(v_n_242)));
  }
  V v_x1_244 = ({ V a_0 = v_t_243; V a_1 = v_taken_240; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_243); r_; });
  if (!(heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
      heff_drop(v_n_242);
      return v_x_241;
    } else {
      return heff_strAppend(heff_strAppend(v_x_241, ((V)&g_heff_2ebuild_2eload_2efreeName_str1)), heff_intShow(v_n_242));
    }
  } else {
    heff_drop(v_x1_244);
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2efreeName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str3, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str7, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str11, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str15, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str17, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str18, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str19, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str21, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str22, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str23, 3, ".hf");
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args);
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_from_242)));
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0)))) {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_t_244);
    V v_base_245 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_246 = ({ V a_0 = v_w_243; V b_1 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str2), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
    V v_parts_2411;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_parts_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_248 = heff_field(v_t_247, 0);
      V v_before_249 = heff_field(v_t_247, 1);
      V v_ru_24t_247_24Cons = heff_take_reuse_n(v_t_247, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_248, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str3)), NTAG(TAG_Nil)});
      v_parts_2411 = (g_list_2efoldl_24s1370882877x364361272(v_t_2410, v_before_249));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2418 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_245), v_parts_2411));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2418, v_base_245, v_parts_2411, v_w_243}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_244);
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2419 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2420 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2421 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2420; V a_2 = v_project_2419; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2420); r_; });
      V v_t_2455;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str4))) {
        V v_base_2422 = heff_dup(heff_rfield(v_k_2421, 2));
        V v_xs_2423 = ({ V a_0 = v_w_243; V b_1 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str6), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
        V v_parts_2428;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nil: {
          v_parts_2428 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2425 = heff_field(v_t_2424, 0);
          V v_before_2426 = heff_field(v_t_2424, 1);
          V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 3ULL, 2);
          V v_t_2427 = heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2425, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str7)), NTAG(TAG_Nil)});
          v_parts_2428 = (g_list_2efoldl_24s1370882877x364361272(v_t_2427, v_before_2426));
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_t_2435 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam1, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2422), v_parts_2428));
        v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2435, v_base_2422, v_parts_2428, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_j_2436 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), v_w_243, MK_INT(0LL), 5);
        V v_t_2437;
        if (heff_intLt_c_lent(v_j_2436, MK_INT(0LL), 2)) {
          heff_drop(v_j_2436);
          v_t_2437 = heff_dup(v_w_243);
        } else {
          v_t_2437 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2436, 6);
        }
        if (heff_strEq_c(v_t_2437, heff_dup(heff_rfield(v_k_2421, 3)))) {
          V v_base_2438 = heff_dup(heff_rfield(v_k_2421, 2));
          V v_xs_2439 = ({ V a_0 = v_w_243; V b_1 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
          V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2439));
          V v_parts_2444;
          switch (heff_tag_of(v_t_2440)) {
          case TAG_Nil: {
            v_parts_2444 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2441 = heff_field(v_t_2440, 0);
            V v_before_2442 = heff_field(v_t_2440, 1);
            V v_ru_24t_2440_24Cons = heff_take_reuse_n(v_t_2440, 3ULL, 2);
            V v_t_2443 = heff_tag_at_n(v_ru_24t_2440_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2441, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str11)), NTAG(TAG_Nil)});
            v_parts_2444 = (g_list_2efoldl_24s1370882877x364361272(v_t_2443, v_before_2442));
            break;
          }
          default: heff_nomatch(v_t_2440);
          }
          V v_j_2445 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), v_w_243, MK_INT(0LL), 5);
          V v_t_2446;
          if (heff_intLt_c_lent(v_j_2445, MK_INT(0LL), 2)) {
            heff_drop(v_j_2445);
            v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13);
          } else {
            v_t_2446 = heff_strSlice(heff_dup(v_w_243), v_j_2445, heff_strLength_lent(v_w_243, 0));
          }
          V v_m_2447 = heff_strAppend(heff_dup(heff_rfield(v_k_2421, 4)), v_t_2446);
          V v_t_2454 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam2, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2438), v_parts_2444));
          v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2454, v_base_2438, v_parts_2444, v_m_2447}), NTAG(TAG_Nil)});
        } else {
          v_t_2455 = NTAG(TAG_Nil);
        }
      }
      V v_j_2456 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), v_w_243, MK_INT(0LL), 5);
      V v_t_2457;
      if (heff_intLt_c_lent(v_j_2456, MK_INT(0LL), 2)) {
        heff_drop(v_j_2456);
        v_t_2457 = heff_dup(v_w_243);
      } else {
        v_t_2457 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2456, 6);
      }
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str15), v_w_243, MK_INT(0LL), 5);
      V v_t_2459;
      if (heff_intLt_c_lent(v_j_2458, MK_INT(0LL), 2)) {
        heff_drop(v_j_2458);
        v_t_2459 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str16);
      } else {
        v_t_2459 = heff_strSlice(heff_dup(v_w_243), v_j_2458, heff_strLength_lent(v_w_243, 0));
      }
      V v_t_2460 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2421); V a_3 = v_t_2457; V a_4 = v_t_2459; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_pkgs_241, 2); heff_drop(v_t_2457); r_; });
      V v_base_2461 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2462 = ({ V a_0 = v_w_243; V b_1 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str17); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str18), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2462));
      V v_parts_2467;
      switch (heff_tag_of(v_t_2463)) {
      case TAG_Nil: {
        v_parts_2467 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2464 = heff_field(v_t_2463, 0);
        V v_before_2465 = heff_field(v_t_2463, 1);
        V v_ru_24t_2463_24Cons = heff_take_reuse_n(v_t_2463, 3ULL, 2);
        V v_t_2466 = heff_tag_at_n(v_ru_24t_2463_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2464, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str19)), NTAG(TAG_Nil)});
        v_parts_2467 = (g_list_2efoldl_24s1370882877x364361272(v_t_2466, v_before_2465));
        break;
      }
      default: heff_nomatch(v_t_2463);
      }
      V v_t_2474 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam3, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2461), v_parts_2467));
      V v_t_2475 = heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2474, v_base_2461, v_parts_2467, heff_dup(v_w_243)});
      V v_ys_2491;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str20))) {
        V v_x1_2476 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_take_field(v_k_2421, 2), v_from_242));
        if (!(heff_dup(v_x1_2476) == NTAG(TAG_True))) {
          heff_drop(v_x1_2476);
          V v_base_2477 = heff_get_n(v_k_2421, 1, 7);
          V v_xs_2478 = ({ V a_0 = v_w_243; V b_1 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str22), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
          V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2478));
          V v_parts_2483;
          switch (heff_tag_of(v_t_2479)) {
          case TAG_Nil: {
            v_parts_2483 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2480 = heff_field(v_t_2479, 0);
            V v_before_2481 = heff_field(v_t_2479, 1);
            V v_ru_24t_2479_24Cons = heff_take_reuse_n(v_t_2479, 3ULL, 2);
            V v_t_2482 = heff_tag_at_n(v_ru_24t_2479_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2480, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23)), NTAG(TAG_Nil)});
            v_parts_2483 = (g_list_2efoldl_24s1370882877x364361272(v_t_2482, v_before_2481));
            break;
          }
          default: heff_nomatch(v_t_2479);
          }
          V v_t_2490 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam4, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2477), v_parts_2483));
          v_ys_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2490, v_base_2477, v_parts_2483, v_w_243}), NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_w_243);
          heff_drop_rec(v_k_2421, 7);
          heff_drop(v_x1_2476);
          v_ys_2491 = NTAG(TAG_Nil);
        }
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_from_242);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2421, 7);
        v_ys_2491 = NTAG(TAG_Nil);
      }
      V v_t_2492 = (g_prelude_2e_2b_2b(v_t_2460, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_ys_2491})));
      return (g_prelude_2e_2b_2b(v_t_2455, v_t_2492));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args) {
  V v_d_2412 = args[0];
  V v_p_2413 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2414 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_d_2412));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_p_2413));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  return ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args) {
  V v_d_2429 = args[0];
  V v_p_2430 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2431 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2431), v_d_2429));
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_2431), v_p_2430));
  V v_t_2434 = (g_std_2epath_2ejoin(v_t_2432, v_t_2433));
  return ({ V a_0 = v_st_2431; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2431); heff_drop(v_t_2434); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args) {
  V v_d_2448 = args[0];
  V v_p_2449 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2450 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_d_2448));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_p_2449));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  return ({ V a_0 = v_st_2450; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2453); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args) {
  V v_d_2468 = args[0];
  V v_p_2469 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2470 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2471 = (g_std_2epath_2eparse(heff_dup(v_st_2470), v_d_2468));
  V v_t_2472 = (g_std_2epath_2eparse(heff_dup(v_st_2470), v_p_2469));
  V v_t_2473 = (g_std_2epath_2ejoin(v_t_2471, v_t_2472));
  return ({ V a_0 = v_st_2470; V a_1 = v_t_2473; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2470); heff_drop(v_t_2473); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args) {
  V v_d_2484 = args[0];
  V v_p_2485 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2486 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_2486), v_d_2484));
  V v_t_2488 = (g_std_2epath_2eparse(heff_dup(v_st_2486), v_p_2485));
  V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
  return ({ V a_0 = v_st_2486; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2486); heff_drop(v_t_2489); r_; });
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_done_244 = heff_take_field(v_st_243, 0);
  V v_errors_245 = heff_get_n(v_st_243, 2, 3);
  V v_t_249;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_246 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_why_247 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_247, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_246, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_246);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_field(v_pkgs_242, 1);
    v_t_2412 = heff_dup(v_y_2411);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_errors_245));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2418;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2415 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      heff_take_n(v_x11_2415, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2417 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2417});
      break;
    }
    default: heff_nomatch(v_x11_2415);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2421;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_pkgs_242, 0);
    v_t_2421 = heff_dup(v_x_2419);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_done_244, v_t_2414, v_ps_240, v_t_2418, v_t_2421});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str3, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str4, 3, "lib");
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam0, 3, 0};
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_entry, 4, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206(V v_e_240, V v_h_241, V v_start_242, V v_d_243) {
top: ;
  V v_st_244 = heff_dup(heff_rfield(v_h_241, 3));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), heff_dup(v_d_243)));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_s_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_248));
  V v_c_2410 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_249; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_249); r_; });
  V v_t_2411 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam1, 2, 5, (V[]){v_c_2415, v_d_243, v_h_241, v_e_240, v_start_242});
}
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_start_242 = heff_env(self)[3];
  V v_hd_2416 = heff_env(self)[4];
  V v_k_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    if (heff_strEq_c_lent(v_d_243, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str1), 2)) {
      heff_drop(v_d_243);
      V v_st_2420 = heff_dup(heff_rfield(v_h_241, 3));
      HeffT3 v_t_2421 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2420), heff_dup(heff_rfield(v_h_241, 2))));
      V v_t_2431;
      {
        V v_field_2422 = v_t_2421.f[0];
        V v_field_2423 = v_t_2421.f[1];
        V v_field_2424 = v_t_2421.f[2];
        V v_d_2425 = v_field_2422;
        V v_a_2426 = v_field_2423;
        V v_xs_2427 = v_field_2424;
        V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
        V v_xs_2429 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2428; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2428); r_; });
        V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
        v_t_2431 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2425, v_a_2426, v_t_2430});
      }
      V v_t_2432 = ({ V a_0 = v_st_2420; V a_1 = v_t_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2431); r_; });
      V v_t_2433 = (g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206(v_e_240, v_h_241, v_start_242, v_t_2432));
      V f_ = v_t_2433;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_st_2434 = heff_dup(heff_rfield(v_h_241, 3));
      HeffT3 v_t_2435 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2434), heff_dup(v_d_243)));
      V v_t_2445;
      {
        V v_field_2436 = v_t_2435.f[0];
        V v_field_2437 = v_t_2435.f[1];
        V v_field_2438 = v_t_2435.f[2];
        V v_d_2439 = v_field_2436;
        V v_a_2440 = v_field_2437;
        V v_xs_2441 = v_field_2438;
        V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2441));
        V v_xs_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2442; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2442); r_; });
        V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2443));
        v_t_2445 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2439, v_a_2440, v_t_2444});
      }
      V v_t_2446 = ({ V a_0 = v_st_2434; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); heff_drop(v_t_2445); r_; });
      if (heff_strEq_c_lent(v_t_2446, v_d_243, 1)) {
        heff_drop(v_d_243);
        heff_drop(v_e_240);
        heff_drop(v_hd_2416);
        V v_t_2447 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_242), v_start_242, heff_take_field(v_h_241, 0), heff_take_field(v_h_241, 1), heff_take_field(v_h_241, 2), heff_get_n(v_h_241, 3, 5)});
        V f_ = v_k_2417;
        args[0] = v_t_2447;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        V v_st_2448 = heff_dup(heff_rfield(v_h_241, 3));
        HeffT3 v_t_2449 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2448), v_d_243));
        V v_t_2459;
        {
          V v_field_2450 = v_t_2449.f[0];
          V v_field_2451 = v_t_2449.f[1];
          V v_field_2452 = v_t_2449.f[2];
          V v_d_2453 = v_field_2450;
          V v_a_2454 = v_field_2451;
          V v_xs_2455 = v_field_2452;
          V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2455));
          V v_xs_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2456; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2456); r_; });
          V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2457));
          v_t_2459 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2453, v_a_2454, v_t_2458});
        }
        V v_t_2460 = ({ V a_0 = v_st_2448; V a_1 = v_t_2459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2448); heff_drop(v_t_2459); r_; });
        V v_t_2461 = (g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206(v_e_240, v_h_241, v_start_242, v_t_2460));
        V f_ = v_t_2461;
        heff_room[0] = v_hd_2416;
        heff_room[1] = v_k_2417;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  case TAG_Right: {
    V v_y_2462 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_start_242);
    heff_drop(v_hd_2416);
    V v_st_2463 = heff_dup(heff_rfield(v_h_241, 3));
    V v_t_2464 = (g_std_2epath_2eparse(heff_dup(v_st_2463), heff_dup(v_d_243)));
    V v_t_2465 = (g_std_2epath_2eparse(heff_dup(v_st_2463), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str2)));
    V v_t_2466 = (g_std_2epath_2ejoin(v_t_2464, v_t_2465));
    V v_t_2467 = ({ V a_0 = v_st_2463; V a_1 = v_t_2466; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2463); heff_drop(v_t_2466); r_; });
    V v_h_2468 = heff_dup(v_h_241);
    V v_d_2469 = heff_dup(v_d_243);
    HeffT2 v_t_2470 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2462));
    V v_x3_2475;
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      if ((v_tag_2471 == ((int64_t)0ULL))) {
        V v_p_2473 = v_field_2472;
        v_x3_2475 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Left, 1, (V[]){v_p_2473});
      } else {
        heff_drop_cell(v_ru_24x_2418_24Right, 1);
        V v_x_2474 = v_field_2472;
        v_x3_2475 = ({ V a_0 = v_x_2474; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2474); r_; });
      }
    }
    V v_t_2489;
    switch (heff_tag_of(v_x3_2475)) {
    case TAG_Left: {
      heff_take_n(v_x3_2475, 0ULL, 1);
      heff_drop(v_d_2469);
      v_t_2489 = heff_get_n(v_h_2468, 0, 5);
      break;
    }
    case TAG_Right: {
      V v_pk_2477 = heff_field(v_x3_2475, 0);
      heff_take_n(v_x3_2475, 1ULL, 1);
      if (heff_strEq_c(heff_get_n(v_pk_2477, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
        V v_t_2478 = (g_heff_2ebuild_2eload_2eheffAt(heff_dup(v_h_2468), heff_dup(v_d_2469)));
        if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
          heff_drop(v_t_2478);
          V v_st_2479 = heff_dup(heff_rfield(v_h_2468, 3));
          V v_t_2480 = (g_std_2epath_2eparse(heff_dup(v_st_2479), heff_dup(v_d_2469)));
          V v_t_2481 = (g_std_2epath_2eparse(heff_dup(v_st_2479), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str3)));
          V v_t_2482 = (g_std_2epath_2ejoin(v_t_2480, v_t_2481));
          V v_t_2483 = ({ V a_0 = v_st_2479; V a_1 = v_t_2482; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2479); heff_drop(v_t_2482); r_; });
          V v_x1_2484 = (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_2468), heff_dup(heff_rfield(v_h_2468, 0)), v_t_2483));
          if (!(heff_dup(v_x1_2484) == NTAG(TAG_True))) {
            heff_drop(v_x1_2484);
            V v_st_2485 = heff_get_n(v_h_2468, 3, 5);
            V v_t_2486 = (g_std_2epath_2eparse(heff_dup(v_st_2485), v_d_2469));
            V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_2485), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_str4)));
            V v_t_2488 = (g_std_2epath_2ejoin(v_t_2486, v_t_2487));
            v_t_2489 = ({ V a_0 = v_st_2485; V a_1 = v_t_2488; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2485); heff_drop(v_t_2488); r_; });
          } else {
            heff_drop(v_d_2469);
            heff_drop(v_x1_2484);
            v_t_2489 = heff_get_n(v_h_2468, 0, 5);
          }
        } else {
          heff_drop(v_d_2469);
          heff_drop(v_t_2478);
          v_t_2489 = heff_get_n(v_h_2468, 0, 5);
        }
      } else {
        heff_drop(v_d_2469);
        v_t_2489 = heff_get_n(v_h_2468, 0, 5);
      }
      break;
    }
    default: heff_nomatch(v_x3_2475);
    }
    V v_x_2490 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_243, v_t_2467, v_t_2489, heff_take_field(v_h_241, 1), heff_take_field(v_h_241, 2), heff_get_n(v_h_241, 3, 5)});
    V f_ = v_k_2417;
    args[0] = v_x_2490;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_h_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_start_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s1076829123x2020170206_lam2, 1, 6, (V[]){v_d_243, v_h_241, v_e_240, v_start_242, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str0, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str3, 8, "heff.sum");
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam0, 3, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053(V v_e_240, V v_ps_241) {
top: ;
  V v_style_242 = heff_take_field(v_ps_241, 5);
  V v_root_243 = heff_get_n(v_ps_241, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), heff_dup(v_root_243)));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_s_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_248));
  V v_c_2410 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_249; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_249); r_; });
  V v_t_2411 = (g_exception_2eattempted(v_e_240));
  V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam1, 2, 3, (V[]){v_c_2415, v_root_243, v_style_242});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_root_243 = heff_env(self)[1];
  V v_style_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 0ULL, 1);
    heff_drop(v_root_243);
    heff_drop(v_style_242);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    V f_ = v_k_2417;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2422 = ({ V a_0 = v_y_2421; V b_1 = ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str2), v_y_2421, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    HeffT2 v_t_2423 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(MK_INT(0LL), v_t_2422));
    V v_x_2435;
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2418_24Right, 1);
        V v_p_2426 = v_field_2425;
        V v_d_2427 = v_root_243;
        V v_st_2428 = v_style_242;
        V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_2428), v_d_2427));
        V v_t_2430 = (g_std_2epath_2eparse(heff_dup(v_st_2428), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_str3)));
        V v_t_2431 = (g_std_2epath_2ejoin(v_t_2429, v_t_2430));
        V v_t_2432 = ({ V a_0 = v_st_2428; V a_1 = v_t_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2428); heff_drop(v_t_2431); r_; });
        V v_t_2433 = ({ V a_0 = v_t_2432; V a_1 = v_y_2421; V a_2 = v_p_2426; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2421); r_; });
        v_x_2435 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2433});
      } else {
        heff_drop(v_root_243);
        heff_drop(v_style_242);
        heff_drop(v_y_2421);
        V v_sums_2434 = v_field_2425;
        v_x_2435 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Right, 1, (V[]){v_sums_2434});
      }
    }
    V f_ = v_k_2417;
    args[0] = v_x_2435;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_root_243 = heff_env(self)[1];
  V v_style_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053_lam2, 1, 3, (V[]){v_k_2417, v_root_243, v_style_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_entry, 9, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_e_244, V v_root_245, V v_x3_246, V v_seen_247, V v_errs_248) {
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam0, 2, 2, (V[]){v_seen_247, v_errs_248});
  }
  case TAG_Cons: {
    V v_n_2411 = heff_field(v_x3_246, 0);
    V v_rest_2412 = heff_field(v_x3_246, 1);
    heff_take_n(v_x3_246, 3ULL, 2);
    V v_path_2413 = heff_take_field(v_n_2411, 1);
    V v_version_2414 = heff_take_field(v_n_2411, 2);
    V v_by_2415 = heff_get_n(v_n_2411, 0, 3);
    if (heff_strEq_c_lent(v_path_2413, v_root_245, 0)) {
      heff_drop(v_path_2413);
      heff_drop(v_version_2414);
      heff_drop(v_by_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_e_244;
      V t_5 = v_root_245;
      V t_6 = v_rest_2412;
      V t_7 = v_seen_247;
      V t_8 = v_errs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_e_244 = t_4;
      v_root_245 = t_5;
      v_x3_246 = t_6;
      v_seen_247 = t_7;
      v_errs_248 = t_8;
      goto top;
    } else {
      V v_t_2416 = (g_list_2eany_24s241416889x826324235(v_path_2413, v_version_2414, v_seen_247));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_path_2413);
        heff_drop(v_version_2414);
        heff_drop(v_by_2415);
        heff_drop(v_t_2416);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_e_244;
        V t_5 = v_root_245;
        V t_6 = v_rest_2412;
        V t_7 = v_seen_247;
        V t_8 = v_errs_248;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_e_244 = t_4;
        v_root_245 = t_5;
        v_x3_246 = t_6;
        v_seen_247 = t_7;
        v_errs_248 = t_8;
        goto top;
      } else {
        heff_drop(v_t_2416);
        V v_c_2417 = (g_heff_2ebuild_2eload_2ecachedPkg_24s1874945706x399847513(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_by_2415, heff_dup(v_path_2413), heff_dup(v_version_2414)));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam1, 2, 12, (V[]){v_c_2417, v_path_2413, v_version_2414, v_seen_247, v_errs_248, v_lit_240, v_lit_241, v_lit_242, v_lit_243, heff_dup(v_e_244), heff_dup(v_root_245), v_rest_2412});
      }
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559(a[0], a[1], a[2], a[3], a4, a5, a[6], a[7], a[8]); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_seen_247 = heff_env(self)[0];
  V v_errs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_247, v_errs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_path_2413 = heff_env(self)[0];
  V v_version_2414 = heff_env(self)[1];
  V v_seen_247 = heff_env(self)[2];
  V v_errs_248 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  V v_e_244 = heff_env(self)[8];
  V v_root_245 = heff_env(self)[9];
  V v_rest_2412 = heff_env(self)[10];
  V v_hd_2418 = heff_env(self)[11];
  V v_k_2419 = heff_env(self)[12];
  heff_clo_take(self, 13);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_why_2421 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    V v_t_2422 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2413, v_version_2414, NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(v_seen_247, v_t_2423));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2421, NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(v_errs_248, v_t_2425));
    V v_t_2427 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_root_245; V a_6 = v_rest_2412; V a_7 = v_t_2424; V a_8 = v_t_2426; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_e_244); heff_drop(v_root_245); r_; });
    V f_ = v_t_2427;
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2428 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    V v_t_2429 = heff_strAppend(heff_strAppend(heff_dup(v_path_2413), ((V)&g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_str0)), heff_dup(v_version_2414));
    V v_t_2430 = (g_list_2emap_24s675147852x248982264(v_t_2429, heff_dup(heff_rfield(v_pk_2428, 2))));
    V v_t_2431 = (g_prelude_2e_2b_2b(v_rest_2412, v_t_2430));
    V v_t_2432 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2413, v_version_2414, heff_tag_n(TAG_Just, 1, (V[]){v_pk_2428})});
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
    V v_t_2434 = (g_prelude_2e_2b_2b(v_seen_247, v_t_2433));
    V v_t_2435 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_root_245; V a_6 = v_t_2431; V a_7 = v_t_2434; V a_8 = v_errs_248; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_e_244); heff_drop(v_root_245); r_; });
    V f_ = v_t_2435;
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_path_2413 = heff_env(self)[1];
  V v_version_2414 = heff_env(self)[2];
  V v_seen_247 = heff_env(self)[3];
  V v_errs_248 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_e_244 = heff_env(self)[9];
  V v_root_245 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559_lam2, 1, 13, (V[]){v_path_2413, v_version_2414, v_seen_247, v_errs_248, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_e_244, v_root_245, v_rest_2412, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_str1, 3, "src");
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_entry, 5, 0};

V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263(V v_e_240, V v_ps_241, V v_root_242, V v_x_243, V v_pk_244) {
top: ;
  V v_heff_245 = heff_take_field(v_pk_244, 1);
  V v_require_246 = heff_get_n(v_pk_244, 2, 4);
  V v_path_247 = heff_take_field(v_x_243, 0);
  V v_version_248 = heff_get_n(v_x_243, 1, 3);
  V v_require_249 = heff_take_field(v_root_242, 2);
  V v_replace_2410 = heff_get_n(v_root_242, 3, 4);
  V v_t_2411 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_247, v_require_249));
  V v_x_2422;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    heff_drop(v_replace_2410);
    v_x_2422 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_247), v_version_248));
    break;
  }
  case TAG_Cons: {
    V v_r_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    V v_t_2414 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2412, v_replace_2410));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_x_2422 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_247), v_version_248));
      break;
    }
    case TAG_Cons: {
      V v_p_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 2);
      heff_drop(v_version_248);
      V v_d_2417 = heff_dup(heff_rfield(v_ps_241, 0));
      V v_st_2418 = heff_dup(heff_rfield(v_ps_241, 5));
      V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_d_2417));
      V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_get_n(v_p_2415, 1, 2)));
      V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
      v_x_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  return heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_lam0, 2, 6, (V[]){v_ps_241, v_x_2422, v_e_240, v_require_246, v_path_247, v_heff_245});
}
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_require_246 = heff_env(self)[2];
  V v_path_247 = heff_env(self)[3];
  V v_heff_245 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2440;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_why_2432 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_x_2422);
    heff_drop(v_require_246);
    heff_drop(v_path_247);
    heff_drop(v_heff_245);
    v_x_2440 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_Left, 1, (V[]){v_why_2432});
    break;
  }
  case TAG_Right: {
    V v_name_2433 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    V v_st_2434 = heff_get_n(v_ps_241, 5, 6);
    V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_2434), heff_dup(v_x_2422)));
    V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_2434), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_str1)));
    V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
    V v_t_2438 = ({ V a_0 = v_st_2434; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); heff_drop(v_t_2437); r_; });
    V v_t_2439 = (g_list_2emap_24s18996220x10511024(v_require_246));
    v_x_2440 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_Right, 1, (V[]){heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){v_path_247, v_x_2422, v_t_2438, heff_dup(v_name_2433), v_name_2433, v_heff_245, v_t_2439})});
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V f_ = v_k_2424;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_lam0(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_ps_241 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_require_246 = heff_env(self)[3];
  V v_path_247 = heff_env(self)[4];
  V v_heff_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2425 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2425), heff_dup(v_x_2422)));
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2425), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_str0)));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  V v_t_2429 = ({ V a_0 = v_st_2425; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); heff_drop(v_t_2428); r_; });
  V v_c_2430 = (g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(v_e_240, heff_dup(v_ps_241), v_t_2429));
  V f_ = v_c_2430;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s672330555x457418263_lam1, 1, 6, (V[]){v_ps_241, v_x_2422, v_require_246, v_path_247, v_heff_245, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_str1, 11, "the project");
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242(V v_e_240, V v_ps_241, V v_root_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2ereadSumAt_24s1191429465x241136053(heff_dup(v_e_240), heff_dup(v_ps_241)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam0, 2, 4, (V[]){v_c_243, v_root_242, v_e_240, v_ps_241});
}
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_seen_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2418; V a_1 = v_seen_2416; V r_ = (g_list_2efoldl_24s1910320727x339655847(a_0, a_1)); heff_drop(v_seen_2416); r_; });
}
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_dup(heff_field(v_x_2421, 0));
    v_t_2424 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2427;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    V v_x_2425 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_246, 0ULL, 1);
    v_t_2427 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V v_t_2430;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 2ULL, 2);
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2433;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_MkPair: {
    V v_y_2432 = heff_field(v_x_2421, 1);
    heff_take_n(v_x_2421, 2ULL, 2);
    v_t_2433 = v_y_2432;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2433));
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2434));
  V v_x_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2435});
  V f_ = v_k_245;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_root_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_seen_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_dup(heff_field(v_x_2413, 0));
    v_seen_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2417 = (g_list_2efoldl_24s422700624x1171050237(NTAG(TAG_Nil), heff_dup(v_seen_2416)));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam3, 1, 1, (V[]){v_seen_2416}), v_t_2417));
  V v_c_2420 = (g_heff_2ebuild_2eload_2epkgsOf_24s1176775887x763914756(v_e_240, v_ps_241, v_root_242, v_t_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2420;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam4, 1, 3, (V[]){v_x_246, v_x_2413, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_root_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_248 = heff_dup(heff_field(v_x_246, 0));
    v_t_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V v_t_2410;
  if (heff_strEq_c(heff_dup(heff_rfield(v_root_242, 0)), ((V)&g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_str0))) {
    v_t_2410 = ((V)&g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_str1);
  } else {
    v_t_2410 = heff_dup(heff_rfield(v_root_242, 0));
  }
  V v_t_2411 = (g_list_2emap_24s675147852x248982264(v_t_2410, heff_dup(heff_rfield(v_root_242, 2))));
  V v_c_2412 = (g_heff_2ebuild_2eload_2eversionsGo_24s1278648006x947667559(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_root_242), v_t_249, v_e_240, heff_rfield(v_root_242, 0), v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam2, 1, 6, (V[]){v_e_240, v_ps_241, v_root_242, v_hd_244, v_x_246, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242_lam1, 1, 5, (V[]){v_root_242, v_e_240, v_ps_241, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str9, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str10, 30, "packages require one another: ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str16, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str17, 30, "packages require one another: ");
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam3(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam3, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam6(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam6, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam10(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam9(V self, V *args); static Clo g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam9, 1, 0};
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam11(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_entry, 3, 0};

V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106(V v_e_240, V v_ps_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam0, 2, 1, (V[]){v_ps_241});
  }
  case TAG_Just: {
    V v_root_248 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_c_249 = (g_heff_2ebuild_2eload_2ereachAll_24s370949257x288147242(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_root_248)));
    return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam1, 2, 4, (V[]){v_c_249, v_ps_241, v_e_240, v_root_248});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_ps_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str0), heff_take_field(v_ps_241, 0), heff_get_n(v_ps_241, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str1), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str2), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str3), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V f_ = v_k_244;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2417 = (g_list_2emap_24s219049803x1458391381(v_x_2416));
  return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam4, 2, 1, (V[]){v_x_2417});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam7(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2430 = (g_list_2emap_24s219049803x1458391381(v_x_2429));
  return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam7, 2, 1, (V[]){v_x_2430});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam10(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_x_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2443 = (g_list_2emap_24s219049803x1458391381(v_x_2442));
  return heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam10, 2, 1, (V[]){v_x_2443});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam11(V self, V *args) {
  V v_x_2447 = args[0];
  V v_root_248 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    heff_take_n(v_x_2447, 0ULL, 1);
    V v_t_2449 = (g_list_2emap_24s18996220x10511024(heff_dup(heff_rfield(v_root_248, 2))));
    V v_t_2450 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_248, 0)), heff_dup(heff_rfield(v_ps_241, 0)), heff_dup(heff_rfield(v_ps_241, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str4), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str5), heff_dup(heff_rfield(v_root_248, 1)), v_t_2449});
    V v_t_2451 = (g_prelude_2e_2b_2b(v_x_2438, NTAG(TAG_Nil)));
    V v_t_2452 = (g_prelude_2e_2b_2b(v_x_2425, v_t_2451));
    V v_t_2455;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_dup(heff_field(v_x_2412, 0));
      v_t_2455 = v_x_2453;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2456 = (g_heff_2ebuild_2eload_2enamedGo(v_t_2452, v_t_2455));
    V v_t_2459;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_y_2458 = heff_dup(heff_field(v_x_2412, 1));
      v_t_2459 = v_y_2458;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2460 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_root_248, 2)));
    V v_t_2461 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_248, 0)), heff_take_field(v_ps_241, 0), heff_get_n(v_ps_241, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str7), heff_take_field(v_root_248, 1), v_t_2460});
    V v_t_2464;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x_2412, 0);
      heff_take_n(v_x_2412, 1ULL, 2);
      v_t_2464 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_248, 0, 4), NTAG(TAG_Nil)});
    V v_t_2466 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, v_t_2464}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2465; V r_ = (g_heff_2ebuild_2eload_2ecycleAmong(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_2471;
    switch (heff_tag_of(v_t_2466)) {
    case TAG_Nothing: {
      v_t_2471 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_c_2467 = heff_field(v_t_2466, 0);
      heff_take_n(v_t_2466, 1ULL, 1);
      V v_t_2470;
      switch (heff_tag_of(v_c_2467)) {
      case TAG_Nil: {
        v_t_2470 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2468 = heff_field(v_c_2467, 0);
        V v_xs_2469 = heff_field(v_c_2467, 1);
        heff_take_n(v_c_2467, 3ULL, 2);
        v_t_2470 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str9); V a_1 = v_x_2468; V a_2 = v_xs_2469; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2469); r_; });
        break;
      }
      default: heff_nomatch(v_c_2467);
      }
      v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str10), v_t_2470), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2466);
    }
    V v_t_2472 = (g_prelude_2e_2b_2b(v_t_2459, v_t_2471));
    V v_x_2473 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2456}), v_t_2472});
    V f_ = v_k_2411;
    args[0] = v_x_2473;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2474 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    V v_x_2475 = (g_list_2emap_24s1462590149x1582455373(v_y_2474));
    V v_t_2476 = (g_list_2emap_24s18996220x10511024(heff_dup(heff_rfield(v_root_248, 2))));
    V v_t_2477 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_248, 0)), heff_dup(heff_rfield(v_ps_241, 0)), heff_dup(heff_rfield(v_ps_241, 1)), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str11), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str12), heff_dup(heff_rfield(v_root_248, 1)), v_t_2476});
    V v_t_2478 = (g_prelude_2e_2b_2b(v_x_2438, v_x_2475));
    V v_t_2479 = (g_prelude_2e_2b_2b(v_x_2425, v_t_2478));
    V v_t_2482;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_x_2480 = heff_dup(heff_field(v_x_2412, 0));
      v_t_2482 = v_x_2480;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2483 = (g_heff_2ebuild_2eload_2enamedGo(v_t_2479, v_t_2482));
    V v_t_2486;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_y_2485 = heff_dup(heff_field(v_x_2412, 1));
      v_t_2486 = v_y_2485;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2487 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_root_248, 2)));
    V v_t_2488 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_dup(heff_rfield(v_root_248, 0)), heff_take_field(v_ps_241, 0), heff_get_n(v_ps_241, 1, 6), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str13), ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str14), heff_take_field(v_root_248, 1), v_t_2487});
    V v_t_2491;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x_2412, 0);
      heff_take_n(v_x_2412, 1ULL, 2);
      v_t_2491 = v_x_2489;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_root_248, 0, 4), NTAG(TAG_Nil)});
    V v_t_2493 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, v_t_2491}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2492; V r_ = (g_heff_2ebuild_2eload_2ecycleAmong(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_2498;
    switch (heff_tag_of(v_t_2493)) {
    case TAG_Nothing: {
      v_t_2498 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_c_2494 = heff_field(v_t_2493, 0);
      heff_take_n(v_t_2493, 1ULL, 1);
      V v_t_2497;
      switch (heff_tag_of(v_c_2494)) {
      case TAG_Nil: {
        v_t_2497 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2495 = heff_field(v_c_2494, 0);
        V v_xs_2496 = heff_field(v_c_2494, 1);
        heff_take_n(v_c_2494, 3ULL, 2);
        v_t_2497 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str16); V a_1 = v_x_2495; V a_2 = v_xs_2496; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2496); r_; });
        break;
      }
      default: heff_nomatch(v_c_2494);
      }
      v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_str17), v_t_2497), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2493);
    }
    V v_t_2499 = (g_prelude_2e_2b_2b(v_t_2486, v_t_2498));
    V v_x_24100 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_t_2483}), v_t_2499});
    V f_ = v_k_2411;
    args[0] = v_x_24100;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_root_248 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2437;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    heff_take_n(v_x_2434, 0ULL, 1);
    v_t_2437 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_2436 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 1);
    v_t_2437 = v_y_2436;
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V v_x_2438 = (g_list_2emap_24s1462590149x1582455373(v_t_2437));
  V v_path_2439 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_241, 2))));
  V v_c_2440 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2439));
  V v_t_2441 = (g_exception_2eattempted(v_e_240));
  V v_c_2446 = heff_tr(heff_call(v_c_2440, 2, (V[]){v_t_2441, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam9_clo)}));
  V f_ = v_c_2446;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam11, 1, 6, (V[]){v_root_248, v_ps_241, v_x_2438, v_x_2425, v_x_2412, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_root_248 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    v_t_2424 = v_y_2423;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_x_2425 = (g_list_2emap_24s1462590149x1582455373(v_t_2424));
  V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_241, 0))));
  V v_c_2427 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2426));
  V v_t_2428 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2433 = heff_tr(heff_call(v_c_2427, 2, (V[]){v_t_2428, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam6_clo)}));
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_2410);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam8, 1, 7, (V[]){v_ps_241, v_e_240, v_hd_2410, v_root_248, v_x_2425, v_x_2412, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_root_248 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_ps_241, 1))));
  V v_c_2414 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2413));
  V v_t_2415 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2420 = heff_tr(heff_call(v_c_2414, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam3_clo)}));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2410);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam5, 1, 6, (V[]){v_ps_241, v_e_240, v_hd_2410, v_root_248, v_x_2412, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_root_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epackagesOf_24s1046924613x1568067106_lam2, 1, 5, (V[]){v_ps_241, v_e_240, v_hd_2410, v_root_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str4, 10, " is named ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str5, 59, " on the disk: a file system that tells case apart finds no ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str7, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str8, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str9, 74, ": names that differ only in case are one file where case is not told apart");
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam0, 2, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam1, 1, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_entry, 4, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249(V v_e_240, V v_ps_241, V v_d_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_d_242);
    return ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_d_242)));
    V v_c_249 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_248));
    V v_t_2410 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2415 = heff_tr(heff_call(v_c_249, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam3, 2, 6, (V[]){v_c_2415, v_ps_241, v_d_242, heff_dup(v_x_246), v_e_240, heff_dup(v_rest_247)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2412 = (g_list_2emap_24s219049803x1458391381(v_x_2411));
  return heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam2, 2, 1, (V[]){v_x_2412});
}
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam5(V self, V *args) {
  V v_n_2424 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2425 = v_n_2424;
  V v_b_2426 = v_x_246;
  V v_x2_2427 = ({ V a_0 = MK_INT(65LL); V a_1 = v_a_2425; V a_2 = MK_INT(90LL); V a_3 = MK_INT(32LL); V a_4 = MK_INT(1LL); V a_5 = MK_INT(0LL); V a_6 = heff_strLength_lent(v_a_2425, 0); V r_ = (g_list_2emap_24f201346761x152404242(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_2425); r_; });
  V v_t_2430;
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_Nil: {
    v_t_2430 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_xs_2429 = heff_field(v_x2_2427, 1);
    heff_take_n(v_x2_2427, 3ULL, 2);
    v_t_2430 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str1); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2427);
  }
  V v_x2_2431 = ({ V a_0 = MK_INT(65LL); V a_1 = v_b_2426; V a_2 = MK_INT(90LL); V a_3 = MK_INT(32LL); V a_4 = MK_INT(1LL); V a_5 = MK_INT(0LL); V a_6 = heff_strLength_lent(v_b_2426, 0); V r_ = (g_list_2emap_24f201346761x152404242(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_b_2426); r_; });
  V v_t_2434;
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_Nil: {
    v_t_2434 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_xs_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    v_t_2434 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str3); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2431);
  }
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2430, v_t_2434, 0));
  heff_drop(v_t_2430);
  heff_drop(v_t_2434);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_hd_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_d_242);
    heff_drop(v_x_246);
    heff_drop(v_e_240);
    heff_drop(v_rest_247);
    heff_drop(v_hd_2416);
    V f_ = v_k_2417;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_ps_2421 = heff_dup(v_ps_241);
    V v_d_2422 = heff_dup(v_d_242);
    V v_x_2423 = heff_dup(v_x_246);
    V v_ns_2435 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam5, 1, 1, (V[]){heff_dup(v_x_246)}), v_y_2420));
    V v_t_2453;
    switch (heff_tag_of(v_ns_2435)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      heff_drop_rec(v_ps_2421, 6);
      heff_drop(v_d_2422);
      heff_drop(v_x_2423);
      v_t_2453 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_ns2_2437 = heff_dup(heff_field(v_ns_2435, 1));
      switch (heff_tag_of(v_ns2_2437)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_ns_2435)) {
        case TAG_Cons: {
          V v_n_2438 = heff_field(v_ns_2435, 0);
          heff_take_n(v_ns_2435, 1ULL, 2);
          if (heff_strEq_c_lent(v_n_2438, v_x_2423, 0)) {
            heff_drop_cell(v_ru_24x_2418_24Right, 1);
            heff_drop_rec(v_ps_2421, 6);
            heff_drop(v_d_2422);
            heff_drop(v_x_2423);
            heff_drop(v_n_2438);
            v_t_2453 = NTAG(TAG_Nothing);
          } else {
            V v_st_2440 = heff_get_n(v_ps_2421, 5, 6);
            V v_t_2441 = (g_std_2epath_2eparse(heff_dup(v_st_2440), v_d_2422));
            V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2440), heff_dup(v_x_2423)));
            V v_t_2443 = (g_std_2epath_2ejoin(v_t_2441, v_t_2442));
            V v_t_2444 = ({ V a_0 = v_st_2440; V a_1 = v_t_2443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2440); heff_drop(v_t_2443); r_; });
            V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str4)), v_n_2438);
            V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str5)), v_x_2423);
            v_t_2453 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){v_t_2446});
          }
          break;
        }
        default: heff_nomatch(v_ns_2435);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_ns2_2437, 0ULL, 2);
        heff_drop_rec(v_ps_2421, 6);
        heff_drop(v_x_2423);
        V v_t_2451;
        switch (heff_tag_of(v_ns_2435)) {
        case TAG_Nil: {
          v_t_2451 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2449 = heff_field(v_ns_2435, 0);
          V v_xs_2450 = heff_field(v_ns_2435, 1);
          heff_take_n(v_ns_2435, 3ULL, 2);
          v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str7); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
          break;
        }
        default: heff_nomatch(v_ns_2435);
        }
        V v_t_2452 = heff_strAppend(heff_strAppend(v_d_2422, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str8)), v_t_2451);
        v_t_2453 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){heff_strAppend(v_t_2452, ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_str9))});
        break;
      }
      default: heff_nomatch(v_ns2_2437);
      }
      break;
    }
    default: heff_nomatch(v_ns_2435);
    }
    switch (heff_tag_of(v_t_2453)) {
    case TAG_Nothing: {
      V v_st_2454 = heff_dup(heff_rfield(v_ps_241, 5));
      V v_t_2455 = (g_std_2epath_2eparse(heff_dup(v_st_2454), v_d_242));
      V v_t_2456 = (g_std_2epath_2eparse(heff_dup(v_st_2454), v_x_246));
      V v_t_2457 = (g_std_2epath_2ejoin(v_t_2455, v_t_2456));
      V v_t_2458 = ({ V a_0 = v_st_2454; V a_1 = v_t_2457; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2454); heff_drop(v_t_2457); r_; });
      V v_t_2459 = ({ V a_0 = v_e_240; V a_1 = v_ps_241; V a_2 = v_t_2458; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
      V f_ = v_t_2459;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_why_2460 = heff_field(v_t_2453, 0);
      heff_take_n(v_t_2453, 1ULL, 1);
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_d_242);
      heff_drop(v_x_246);
      heff_drop(v_e_240);
      heff_drop(v_rest_247);
      heff_drop(v_hd_2416);
      V f_ = v_k_2417;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2460});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2453);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249_lam4, 1, 7, (V[]){v_k_2417, v_ps_241, v_d_242, v_x_246, v_e_240, v_rest_247, v_hd_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str0, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str5, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str7, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_entry, 10, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(V v_lit_240, V v_e_241, V v_read_242, V v_ps_243, V v_pkgs_244, V v_stack_245, V v_from_246, V v_x7_247, V v_st_248, V v_rs_249) {
top: ;
  switch (heff_tag_of(v_x7_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_e_241);
    heff_drop(v_read_242);
    heff_drop(v_ps_243);
    heff_drop(v_pkgs_244);
    heff_drop(v_stack_245);
    heff_drop(v_from_246);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam0, 2, 2, (V[]){v_st_248, v_rs_249});
  }
  case TAG_Cons: {
    V v_w_2412 = heff_field(v_x7_247, 0);
    V v_rest_2413 = heff_field(v_x7_247, 1);
    heff_take_n(v_x7_247, 3ULL, 2);
    V v_t_2414 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_243), heff_dup(v_pkgs_244), heff_dup(v_from_246), heff_dup(v_w_2412)));
    V v_c_2415 = (g_heff_2ebuild_2eload_2ereadEvery(v_e_241, heff_dup(v_read_242), v_t_2414));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam1, 2, 12, (V[]){v_c_2415, v_ps_243, v_pkgs_244, v_from_246, v_w_2412, v_st_248, v_lit_240, v_e_241, v_read_242, v_stack_245, v_rest_2413, v_rs_249});
  }
  default: return heff_nomatch(v_x7_247);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_st_248 = heff_env(self)[0];
  V v_rs_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_248, v_rs_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam4(V self, V *args) {
  V v_x_2471 = args[0];
  V v_ps_243 = heff_env(self)[0];
  V v_module_2433 = heff_env(self)[1];
  V v_named_2437 = heff_env(self)[2];
  V v_path_2435 = heff_env(self)[3];
  V v_source_2436 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_w_2412 = heff_env(self)[6];
  V v_rs_249 = heff_env(self)[7];
  V v_e_241 = heff_env(self)[8];
  V v_read_242 = heff_env(self)[9];
  V v_pkgs_244 = heff_env(self)[10];
  V v_stack_245 = heff_env(self)[11];
  V v_from_246 = heff_env(self)[12];
  V v_rest_2413 = heff_env(self)[13];
  V v_hd_2416 = heff_env(self)[14];
  V v_k_2417 = heff_env(self)[15];
  heff_clo_take(self, 16);
  V v_t_2474;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_dup(heff_field(v_x_2471, 0));
    v_t_2474 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2477;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_y_2476 = heff_field(v_x_2471, 1);
    heff_take_n(v_x_2471, 2ULL, 2);
    v_t_2477 = v_y_2476;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2478 = (g_heff_2ebuild_2eload_2epushDone(v_t_2474, heff_dup(v_ps_243), heff_dup(v_module_2433), v_named_2437, v_path_2435, v_source_2436, heff_dup(v_lit_240), v_t_2477));
  V v_m_2479 = v_module_2433;
  V v_t_2480;
  if (heff_strEq_c_lent(v_w_2412, v_m_2479, 0)) {
    heff_drop(v_w_2412);
    heff_drop(v_m_2479);
    v_t_2480 = v_rs_249;
  } else {
    v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2479}), v_rs_249});
  }
  V v_t_2481 = (g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(v_lit_240, v_e_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_rest_2413, v_t_2478, v_t_2480));
  V f_ = v_t_2481;
  heff_room[0] = v_hd_2416;
  heff_room[1] = v_k_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_source_2436 = heff_env(self)[1];
  V v_st_248 = heff_env(self)[2];
  V v_from_246 = heff_env(self)[3];
  V v_w_2412 = heff_env(self)[4];
  V v_e_241 = heff_env(self)[5];
  V v_read_242 = heff_env(self)[6];
  V v_ps_243 = heff_env(self)[7];
  V v_pkgs_244 = heff_env(self)[8];
  V v_module_2433 = heff_env(self)[9];
  V v_stack_245 = heff_env(self)[10];
  V v_path_2435 = heff_env(self)[11];
  V v_hd_2416 = heff_env(self)[12];
  V v_named_2437 = heff_env(self)[13];
  V v_rs_249 = heff_env(self)[14];
  V v_rest_2413 = heff_env(self)[15];
  V v_k_2417 = heff_env(self)[16];
  heff_clo_take(self, 17);
  V v_t_2460 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(v_source_2436)));
  V v_imps_2461 = heff_get_n(v_t_2460, 0, 4);
  V v_t_2462 = (g_list_2emap_24s1817208647x1282894070(v_imps_2461));
  V v_t_2463 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2462));
  V v_t_2469;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2469 = v_st_248;
    break;
  }
  case TAG_Just: {
    V v_why_2464 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    V v_t_2465 = heff_strAppend(heff_strAppend(heff_dup(v_from_246), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str9)), heff_dup(v_w_2412));
    V v_t_2466 = heff_strAppend(heff_strAppend(v_t_2465, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str10)), v_why_2464);
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
    V v_t_2468 = (g_prelude_2e_2b_2b(heff_take_field(v_st_248, 2), v_t_2467));
    v_t_2469 = ({ V rv_2 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_st_248, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2470 = (g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(heff_dup(v_lit_240), heff_dup(v_e_241), heff_dup(v_read_242), heff_dup(v_ps_243), heff_dup(v_pkgs_244), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2433), heff_dup(v_stack_245)}), heff_dup(v_path_2435), v_t_2463, v_t_2469, NTAG(TAG_Nil)));
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam4, 1, 16, (V[]){v_ps_243, v_module_2433, v_named_2437, v_path_2435, v_source_2436, v_lit_240, v_w_2412, v_rs_249, v_e_241, v_read_242, v_pkgs_244, v_stack_245, v_from_246, v_rest_2413, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_ps_243 = heff_env(self)[0];
  V v_pkgs_244 = heff_env(self)[1];
  V v_from_246 = heff_env(self)[2];
  V v_w_2412 = heff_env(self)[3];
  V v_st_248 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_e_241 = heff_env(self)[6];
  V v_read_242 = heff_env(self)[7];
  V v_stack_245 = heff_env(self)[8];
  V v_rest_2413 = heff_env(self)[9];
  V v_rs_249 = heff_env(self)[10];
  V v_hd_2416 = heff_env(self)[11];
  V v_k_2417 = heff_env(self)[12];
  heff_clo_take(self, 13);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nil: {
    V v_places_2419 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_243), heff_dup(v_pkgs_244), heff_dup(v_from_246), heff_dup(v_w_2412)));
    V v_t_2420 = heff_strAppend(heff_strAppend(heff_dup(v_from_246), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str0)), v_w_2412);
    V v_x2_2421 = (g_list_2emap_24s435407392x1528135477(v_places_2419));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str2); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str3)), v_t_2424);
    V v_e_2426 = heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str4));
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2426, NTAG(TAG_Nil)});
    V v_t_2428 = (g_prelude_2e_2b_2b(heff_take_field(v_st_248, 2), v_t_2427));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_st_248, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2430 = (g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(v_lit_240, v_e_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_rest_2413, v_t_2429, v_rs_249));
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2431 = heff_dup(heff_field(v_x_2418, 0));
    V v_others_2432 = heff_dup(heff_field(v_x_2418, 1));
    V v_module_2433 = heff_take_field(v_f_2431, 3);
    V v_place_2434 = heff_take_field(v_f_2431, 2);
    V v_path_2435 = heff_take_field(v_f_2431, 0);
    V v_source_2436 = heff_take_field(v_f_2431, 1);
    V v_named_2437 = heff_get_n(v_f_2431, 4, 5);
    V v_t_2438 = (g_list_2eany_24s1006624359x760861690(v_module_2433, heff_rfield(v_st_248, 1)));
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2418, 2);
      heff_drop(v_others_2432);
      heff_drop_rec(v_place_2434, 4);
      heff_drop(v_path_2435);
      heff_drop(v_source_2436);
      heff_drop(v_named_2437);
      heff_drop(v_t_2438);
      V v_m_2439 = v_module_2433;
      V v_t_2440;
      if (heff_strEq_c_lent(v_w_2412, v_m_2439, 0)) {
        heff_drop(v_w_2412);
        heff_drop(v_m_2439);
        v_t_2440 = v_rs_249;
      } else {
        v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2439}), v_rs_249});
      }
      V v_t_2441 = (g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(v_lit_240, v_e_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_rest_2413, v_st_248, v_t_2440));
      V f_ = v_t_2441;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2438);
      V v_t_2442 = (g_list_2eany_24s1006624359x760861690(v_module_2433, v_stack_245));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2418, 2);
        heff_drop(v_others_2432);
        heff_drop_rec(v_place_2434, 4);
        heff_drop(v_path_2435);
        heff_drop(v_source_2436);
        heff_drop(v_named_2437);
        heff_drop(v_t_2442);
        V v_m_2443 = heff_dup(v_module_2433);
        V v_t_2444 = heff_strAppend(heff_strAppend(heff_dup(v_from_246), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str5)), heff_dup(v_m_2443));
        V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_245)));
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2443, NTAG(TAG_Nil)});
        V v_x2_2447 = (g_prelude_2e_2b_2b(v_t_2445, v_t_2446));
        V v_t_2450;
        switch (heff_tag_of(v_x2_2447)) {
        case TAG_Nil: {
          v_t_2450 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2448 = heff_field(v_x2_2447, 0);
          V v_xs_2449 = heff_field(v_x2_2447, 1);
          heff_take_n(v_x2_2447, 3ULL, 2);
          v_t_2450 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str7); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2447);
        }
        V v_e_2451 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_str8)), v_t_2450);
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2451, NTAG(TAG_Nil)});
        V v_t_2453 = (g_prelude_2e_2b_2b(heff_take_field(v_st_248, 2), v_t_2452));
        V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_st_248, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2455 = v_module_2433;
        V v_t_2456;
        if (heff_strEq_c_lent(v_w_2412, v_m_2455, 0)) {
          heff_drop(v_w_2412);
          heff_drop(v_m_2455);
          v_t_2456 = v_rs_249;
        } else {
          v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2455}), v_rs_249});
        }
        V v_t_2457 = (g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(v_lit_240, v_e_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_rest_2413, v_t_2454, v_t_2456));
        V f_ = v_t_2457;
        heff_room[0] = v_hd_2416;
        heff_room[1] = v_k_2417;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2442);
        switch (heff_tag_of(v_others_2432)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2418, 2);
          V v_c_2458 = ({ V a_0 = heff_dup(v_e_241); V a_1 = heff_dup(v_ps_243); V a_2 = heff_take_field(v_place_2434, 1); V b_3 = heff_get_n(v_place_2434, 2, 4); V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s2105535695x736448249(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          V f_ = v_c_2458;
          heff_room[0] = heff_dup(v_hd_2416);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam3, 1, 17, (V[]){v_lit_240, v_source_2436, v_st_248, v_from_246, v_w_2412, v_e_241, v_read_242, v_ps_243, v_pkgs_244, v_module_2433, v_stack_245, v_path_2435, v_hd_2416, v_named_2437, v_rs_249, v_rest_2413, v_k_2417});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2432_24Cons = heff_take_reuse_n(v_others_2432, 0ULL, 2);
          heff_drop_rec(v_place_2434, 4);
          heff_drop(v_path_2435);
          heff_drop(v_source_2436);
          heff_drop(v_named_2437);
          V v_e_2484 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_243), v_x_2418, heff_dup(v_from_246), heff_dup(v_w_2412)));
          V v_t_2485 = heff_take_field(v_st_248, 0);
          V v_t_2486 = heff_take_field(v_st_248, 1);
          V v_t_2487 = heff_tag_at_n(v_ru_24others_2432_24Cons, TAG_Cons, 2, (V[]){v_e_2484, NTAG(TAG_Nil)});
          V v_t_2488 = (g_prelude_2e_2b_2b(heff_get_n(v_st_248, 2, 3), v_t_2487));
          V v_t_2489 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){v_t_2485, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2433), v_t_2486}), v_t_2488});
          V v_m_2490 = v_module_2433;
          V v_t_2491;
          if (heff_strEq_c_lent(v_w_2412, v_m_2490, 0)) {
            heff_drop(v_w_2412);
            heff_drop(v_m_2490);
            v_t_2491 = v_rs_249;
          } else {
            v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2412, v_m_2490}), v_rs_249});
          }
          V v_t_2492 = (g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(v_lit_240, v_e_241, v_read_242, v_ps_243, v_pkgs_244, v_stack_245, v_from_246, v_rest_2413, v_t_2489, v_t_2491));
          V f_ = v_t_2492;
          heff_room[0] = v_hd_2416;
          heff_room[1] = v_k_2417;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2432);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_ps_243 = heff_env(self)[1];
  V v_pkgs_244 = heff_env(self)[2];
  V v_from_246 = heff_env(self)[3];
  V v_w_2412 = heff_env(self)[4];
  V v_st_248 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_e_241 = heff_env(self)[7];
  V v_read_242 = heff_env(self)[8];
  V v_stack_245 = heff_env(self)[9];
  V v_rest_2413 = heff_env(self)[10];
  V v_rs_249 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840_lam2, 1, 13, (V[]){v_ps_243, v_pkgs_244, v_from_246, v_w_2412, v_st_248, v_lit_240, v_e_241, v_read_242, v_stack_245, v_rest_2413, v_rs_249, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_entry, 8, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171(V v_e_240, V v_read_241, V v_ps_242, V v_pkgs_243, V v_from_244, V v_before_245, V v_x6_246, V v_st_247) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_read_241);
    heff_drop(v_ps_242);
    heff_drop(v_pkgs_243);
    heff_drop(v_from_244);
    heff_drop(v_before_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam0, 2, 1, (V[]){v_st_247});
  }
  case TAG_Cons: {
    V v_m_2410 = heff_field(v_x6_246, 0);
    V v_ms_2411 = heff_field(v_x6_246, 1);
    V v_ru_24x6_246_24Cons = heff_take_reuse_n(v_x6_246, 3ULL, 2);
    V v_t_2412 = heff_tag_at_n(v_ru_24x6_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_2410), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2ebuild_2eload_2eloadMany_24s558500036x1900717840(heff_dup(v_before_245), heff_dup(v_e_240), heff_dup(v_read_241), heff_dup(v_ps_242), heff_dup(v_pkgs_243), NTAG(TAG_Nil), heff_dup(v_from_244), v_t_2412, v_st_247, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam1, 2, 9, (V[]){v_c_2413, v_m_2410, v_before_245, v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_from_244, v_ms_2411});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_st_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_before_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_read_241 = heff_env(self)[3];
  V v_ps_242 = heff_env(self)[4];
  V v_pkgs_243 = heff_env(self)[5];
  V v_from_244 = heff_env(self)[6];
  V v_ms_2411 = heff_env(self)[7];
  V v_hd_2414 = heff_env(self)[8];
  V v_k_2415 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
  V v_t_2418 = (g_prelude_2e_2b_2b(v_before_245, v_t_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 2);
    v_t_2421 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V v_t_2422 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171(v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_from_244, v_t_2418, v_ms_2411, v_t_2421));
  V f_ = v_t_2422;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_m_2410 = heff_env(self)[1];
  V v_before_245 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_read_241 = heff_env(self)[4];
  V v_ps_242 = heff_env(self)[5];
  V v_pkgs_243 = heff_env(self)[6];
  V v_from_244 = heff_env(self)[7];
  V v_ms_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1420856764x1499031171_lam2, 1, 10, (V[]){v_m_2410, v_before_245, v_e_240, v_read_241, v_ps_242, v_pkgs_243, v_from_244, v_ms_2411, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}