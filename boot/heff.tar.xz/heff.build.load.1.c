// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_absolute 325777132
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_drive 297211300
#define LBL_errors 652506774
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_segments 1801007612
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__source__place__module[] = {LBL_path, LBL_source, LBL_place, LBL_module};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_clo;
HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2elibRead(V, V, V);
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2elibRead_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_clo;
V g_heff_2ebuild_2eload_2epackageRead(V, V, V, V);
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackageRead_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214(V, V);
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_clo;
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1345968422x916930247(V, V, V);
V g_list_2eany_24s1345968422x916930247_entry(V self, V *a);
extern Clo g_list_2eany_24s1345968422x916930247_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s639151216x1214259357(V, V, V);
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_clo;
HeffT2 g_list_2efind_24s1250280863x1570195177_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1002907040x997927369(V, V);
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1002907040x997927369_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f2056124927x822823214(V, V, V);
V g_list_2emap_24f2056124927x822823214_entry(V self, V *a);
extern Clo g_list_2emap_24f2056124927x822823214_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enormalize(V, V);
V g_std_2epath_2enormalize_entry(V self, V *a);
extern Clo g_std_2epath_2enormalize_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT2 g_std_2epath_2erelative_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_t_243 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_d_241)));
  V v_t_244 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_path_242)));
  V v_t_245 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_243, v_t_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), v_d_241));
    V v_t_247 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_take_field(v_ps_240, 4), v_path_242));
    return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_t_246; V a_2 = v_t_247; HeffT2 r_ = (g_std_2epath_2erelative_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  } else {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_t_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str6, 1, ".");
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_path_241)));
  V v_p_2417;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_path_241);
      V v_rel_246 = v_field_244;
      v_p_2417 = v_rel_246;
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_247 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 1)), heff_dup(v_path_241)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_path_241);
          V v_rel_2411 = v_field_249;
          v_p_2417 = v_rel_2411;
        } else {
          heff_drop(v_field_249);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(v_path_241)));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              heff_drop(v_path_241);
              V v_rel_2416 = v_field_2414;
              v_p_2417 = v_rel_2416;
            } else {
              heff_drop(v_field_2414);
              v_p_2417 = v_path_241;
            }
          }
        }
      }
    }
  }
  int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
  V v_t_2419 = heff_strSlice(heff_dup(v_p_2417), heff_box_word(v_t_2418), heff_strLength_lent(v_p_2417, 0));
  V v_t_2422;
  if (heff_strEq_c(v_t_2419, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
    int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_p_2417, 0)) - ((int64_t)3ULL));
    v_t_2422 = heff_strSlice(v_p_2417, MK_INT(0LL), heff_box_word(v_t_2421));
  } else {
    v_t_2422 = v_p_2417;
  }
  V v_p_2423 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_t_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_xs_2424 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str1); V a_1 = heff_dup(v_p_2423); V a_2 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2); V b_3 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str3); V a_4 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str4); V a_5 = NTAG(TAG_Nil); V a_6 = heff_get_n(v_p_2423, 2, 3); V r_ = (g_list_2efoldl_24s1725521117x1379101383(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
  V v_x2_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str5);
  }
  case TAG_Cons: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_xs_2427 = heff_field(v_x2_2425, 1);
    heff_take_n(v_x2_2425, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str6); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eheffAt_str0, 3, "lib");
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eheffAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eheffAt_entry, 2, 0};

V g_heff_2ebuild_2eload_2eheffAt(V v_h_240, V v_d_241) {
top: ;
  V v_t_247 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2eload_2eheffAt_lam0, 1, 2, (V[]){heff_dup(v_h_240), heff_dup(v_d_241)}), heff_rfield(v_h_240, 4)));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) || ({ V v_b_248 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2eheffAt_str0))); int c_ = ({ V v_t_249 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), heff_dup(heff_rfield(v_h_240, 0)))); int c_ = ({ V v_t_2410 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), heff_dup(v_t_249))); int c_ = ({ V v_t_2411 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), heff_dup(v_b_248))); int c_ = ({ V v_t_2412 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), heff_dup(v_t_2411))); int c_ = heff_strEq_c_lent(v_t_2410, v_t_2412, 0); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2411); c_; }); heff_drop(v_t_2410); c_; }); heff_drop(v_t_249); c_; }); heff_drop(v_b_248); c_; })));
  heff_drop_rec(v_h_240, 5);
  heff_drop(v_d_241);
  heff_drop(v_t_247);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eheffAt(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), v_o_242));
  V v_t_244 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), v_t_243));
  V v_t_245 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_take_field(v_h_240, 2), v_d_241));
  V v_t_246 = ({ V b_0 = heff_get_n(v_h_240, 3, 5); V a_1 = v_t_245; V r_ = (g_std_2epath_2enormalize(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_strEq(v_t_244, v_t_246);
}
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str0, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str1, 3, "lib");
Clo g_heff_2ebuild_2eload_2elibRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2elibRead_entry, 3, 0};

V g_heff_2ebuild_2eload_2elibRead(V v_h_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    heff_drop(v_d_241);
    return heff_get_n(v_h_240, 0, 5);
  }
  case TAG_Right: {
    V v_pk_244 = heff_field(v_x3_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_244, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_t_246 = (g_heff_2ebuild_2eload_2eheffAt(heff_dup(v_h_240), heff_dup(v_d_241)));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_b_247 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2elibRead_str0)));
        V v_t_248 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(heff_rfield(v_h_240, 2)), heff_dup(heff_rfield(v_h_240, 0))));
        V v_t_249 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), v_t_248));
        V v_t_2410 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_take_field(v_h_240, 2), v_b_247));
        V v_t_2411 = (g_std_2epath_2enormalize(heff_rfield(v_h_240, 3), v_t_2410));
        if (heff_strEq_c(v_t_249, v_t_2411)) {
          heff_drop(v_d_241);
          return heff_get_n(v_h_240, 0, 5);
        } else {
          return ({ V b_0 = heff_get_n(v_h_240, 3, 5); V a_1 = v_d_241; V a_2 = ((V)&g_heff_2ebuild_2eload_2elibRead_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        }
      } else {
        heff_drop(v_d_241);
        heff_drop(v_t_246);
        return heff_get_n(v_h_240, 0, 5);
      }
    } else {
      heff_drop(v_d_241);
      return heff_get_n(v_h_240, 0, 5);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2elibRead(a[0], a[1], a2); heff_drop(a2); return r;
}

HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_k_242}});
    } else {
      heff_drop_rec(v_k_242, 7);
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2etakeUntil_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      heff_drop(v_rest_244);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_x_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_247;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_pkgs_240);
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_stack_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_pkgs_240);
      heff_drop(v_rest_244);
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ebuild_2eload_2etakeUntil(v_path_243, v_stack_241));
      V v_xs_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, v_t_247});
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_t_246);
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(heff_dup(v_pkgs_240), v_path_243));
      V v_t_2415;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k_2414 = v_field_2412;
          v_t_2415 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2414, 6, 7)));
        } else {
          heff_drop(v_field_2412);
          v_t_2415 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2416 = (g_heff_2ebuild_2eload_2ecycleAmong(heff_dup(v_pkgs_240), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2415));
      V v_x2_2417 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2416)) {
      case TAG_Nothing: {
        return v_x2_2417;
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_x1_2416, 0);
        V v_ru_24x1_2416_24Just = heff_take_reuse_n(v_x1_2416, 1ULL, 1);
        heff_drop(v_x2_2417);
        return heff_tag_at_n(v_ru_24x1_2416_24Just, TAG_Just, 1, (V[]){v_x_2418});
      }
      default: return heff_nomatch(v_x1_2416);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecycleAmong(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str1, 1, "_");
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
    v_t_245 = heff_dup(v_x_241);
  } else {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str0), heff_intShow(heff_dup(v_n_242)));
    v_t_245 = heff_strAppend(heff_dup(v_x_241), v_t_244);
  }
  V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_245}));
  V v_x1_247 = (g_list_2eany(v_t_246, v_taken_240));
  if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
    heff_drop(v_x1_247);
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  } else {
    heff_drop(v_x1_247);
    if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
      heff_drop(v_n_242);
      return v_x_241;
    } else {
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str1), heff_intShow(v_n_242));
      return heff_strAppend(v_x_241, v_t_249);
    }
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2efreeName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str5, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str9, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str11, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str13, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str16, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str17, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str19, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str20, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str21, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str23, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str24, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str25, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str26, 3, ".hf");
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args);
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_d_244 = heff_dup(heff_rfield(v_ps_240, 2));
  V v_t_2411 = heff_bool((heff_strEq_c_lent(v_d_244, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0), 2) ? !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1)) : ({ V v_t_247 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_d_244))); int c_ = ({ V v_t_248 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), heff_dup(v_from_242))); int c_ = ({ V v_t_249 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), heff_dup(v_t_247), heff_dup(v_t_248))); int c_ = ((heff_dup(v_t_249) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str2))); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; })));
  heff_drop(v_d_244);
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_t_2411);
    V v_base_2412 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str3); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str4), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
    V v_parts_2418;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_parts_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_2415 = heff_field(v_t_2414, 0);
      V v_before_2416 = heff_field(v_t_2414, 1);
      V v_ru_24t_2414_24Cons = heff_take_reuse_n(v_t_2414, 3ULL, 2);
      V v_t_2417 = heff_tag_at_n(v_ru_24t_2414_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2415, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5)), v_before_2416});
      v_parts_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2417));
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2421 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2412), v_parts_2418));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2421, v_base_2412, v_parts_2418, v_w_243}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_2411);
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2422 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2423 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2424 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2423; V a_2 = v_project_2422; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2423); r_; });
      V v_t_2454;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2424, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str6))) {
        V v_base_2426 = heff_dup(heff_rfield(v_k_2424, 2));
        V v_xs_2427 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str7); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
        V v_parts_2432;
        switch (heff_tag_of(v_t_2428)) {
        case TAG_Nil: {
          v_parts_2432 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2429 = heff_field(v_t_2428, 0);
          V v_before_2430 = heff_field(v_t_2428, 1);
          V v_ru_24t_2428_24Cons = heff_take_reuse_n(v_t_2428, 3ULL, 2);
          V v_t_2431 = heff_tag_at_n(v_ru_24t_2428_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2429, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9)), v_before_2430});
          v_parts_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2431));
          break;
        }
        default: heff_nomatch(v_t_2428);
        }
        V v_t_2435 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam1, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2426), v_parts_2432));
        v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2435, v_base_2426, v_parts_2432, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_j_2436 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), v_w_243, MK_INT(0LL), 5);
        V v_t_2438;
        if (heff_intLt_c_lent(v_j_2436, MK_INT(0LL), 2)) {
          heff_drop(v_j_2436);
          v_t_2438 = heff_dup(v_w_243);
        } else {
          v_t_2438 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2436, 6);
        }
        if (heff_strEq_c(v_t_2438, heff_dup(heff_rfield(v_k_2424, 3)))) {
          V v_base_2440 = heff_dup(heff_rfield(v_k_2424, 2));
          V v_xs_2441 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str11); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2441));
          V v_parts_2446;
          switch (heff_tag_of(v_t_2442)) {
          case TAG_Nil: {
            v_parts_2446 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2443 = heff_field(v_t_2442, 0);
            V v_before_2444 = heff_field(v_t_2442, 1);
            V v_ru_24t_2442_24Cons = heff_take_reuse_n(v_t_2442, 3ULL, 2);
            V v_t_2445 = heff_tag_at_n(v_ru_24t_2442_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2443, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13)), v_before_2444});
            v_parts_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2445));
            break;
          }
          default: heff_nomatch(v_t_2442);
          }
          V v_j_2447 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), v_w_243, MK_INT(0LL), 5);
          V v_t_2449;
          if (heff_intLt_c_lent(v_j_2447, MK_INT(0LL), 2)) {
            heff_drop(v_j_2447);
            v_t_2449 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str15);
          } else {
            v_t_2449 = heff_strSlice(heff_dup(v_w_243), v_j_2447, heff_strLength_lent(v_w_243, 0));
          }
          V v_m_2450 = heff_strAppend(heff_dup(heff_rfield(v_k_2424, 4)), v_t_2449);
          V v_t_2453 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam2, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2440), v_parts_2446));
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2453, v_base_2440, v_parts_2446, v_m_2450}), NTAG(TAG_Nil)});
        } else {
          v_t_2454 = NTAG(TAG_Nil);
        }
      }
      V v_j_2455 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str16), v_w_243, MK_INT(0LL), 5);
      V v_t_2457;
      if (heff_intLt_c_lent(v_j_2455, MK_INT(0LL), 2)) {
        heff_drop(v_j_2455);
        v_t_2457 = heff_dup(v_w_243);
      } else {
        v_t_2457 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2455, 6);
      }
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str17), v_w_243, MK_INT(0LL), 5);
      V v_t_2460;
      if (heff_intLt_c_lent(v_j_2458, MK_INT(0LL), 2)) {
        heff_drop(v_j_2458);
        v_t_2460 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str18);
      } else {
        v_t_2460 = heff_strSlice(heff_dup(v_w_243), v_j_2458, heff_strLength_lent(v_w_243, 0));
      }
      V v_t_2461 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2424); V a_3 = v_t_2457; V a_4 = v_t_2460; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2457); r_; });
      V v_base_2462 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2463 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str19); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str20), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2463));
      V v_parts_2468;
      switch (heff_tag_of(v_t_2464)) {
      case TAG_Nil: {
        v_parts_2468 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2465 = heff_field(v_t_2464, 0);
        V v_before_2466 = heff_field(v_t_2464, 1);
        V v_ru_24t_2464_24Cons = heff_take_reuse_n(v_t_2464, 3ULL, 2);
        V v_t_2467 = heff_tag_at_n(v_ru_24t_2464_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2465, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21)), v_before_2466});
        v_parts_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2467));
        break;
      }
      default: heff_nomatch(v_t_2464);
      }
      V v_t_2471 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam3, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2462), v_parts_2468));
      V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2471, v_base_2462, v_parts_2468, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      V v_t_2489;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2424, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str22))) {
        V v_d_2474 = heff_take_field(v_k_2424, 2);
        if (heff_strEq_c_lent(v_d_2474, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23), 2)) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_from_242);
          heff_drop(v_w_243);
          heff_drop_rec(v_k_2424, 7);
          heff_drop(v_d_2474);
          v_t_2489 = NTAG(TAG_Nil);
        } else {
          V v_t_2476 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), v_d_2474));
          V v_t_2477 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 4)), v_from_242));
          V v_x1_2478 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_240, 5), v_t_2476, v_t_2477));
          if ((heff_dup(v_x1_2478) == NTAG(TAG_True))) {
            heff_drop_rec(v_ps_240, 6);
            heff_drop(v_w_243);
            heff_drop_rec(v_k_2424, 7);
            heff_drop(v_x1_2478);
            v_t_2489 = NTAG(TAG_Nil);
          } else {
            heff_drop(v_x1_2478);
            V v_base_2479 = heff_get_n(v_k_2424, 1, 7);
            V v_xs_2480 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str24); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str25), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
            V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2480));
            V v_parts_2485;
            switch (heff_tag_of(v_t_2481)) {
            case TAG_Nil: {
              v_parts_2485 = NTAG(TAG_Nil);
              break;
            }
            case TAG_Cons: {
              V v_last_2482 = heff_field(v_t_2481, 0);
              V v_before_2483 = heff_field(v_t_2481, 1);
              V v_ru_24t_2481_24Cons = heff_take_reuse_n(v_t_2481, 3ULL, 2);
              V v_t_2484 = heff_tag_at_n(v_ru_24t_2481_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2482, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str26)), v_before_2483});
              v_parts_2485 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2484));
              break;
            }
            default: heff_nomatch(v_t_2481);
            }
            V v_t_2488 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam4, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2479), v_parts_2485));
            v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2488, v_base_2479, v_parts_2485, v_w_243}), NTAG(TAG_Nil)});
          }
        }
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_from_242);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2424, 7);
        v_t_2489 = NTAG(TAG_Nil);
      }
      V v_t_2490 = (g_prelude_2e_2b_2b(v_t_2472, v_t_2489));
      V v_t_2491 = (g_prelude_2e_2b_2b(v_t_2461, v_t_2490));
      return (g_prelude_2e_2b_2b(v_t_2454, v_t_2491));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args) {
  V v_d_2419 = args[0];
  V v_p_2420 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2419; V a_2 = v_p_2420; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args) {
  V v_d_2433 = args[0];
  V v_p_2434 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2433; V a_2 = v_p_2434; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args) {
  V v_d_2451 = args[0];
  V v_p_2452 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2451; V a_2 = v_p_2452; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args) {
  V v_d_2469 = args[0];
  V v_p_2470 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2469; V a_2 = v_p_2470; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args) {
  V v_d_2486 = args[0];
  V v_p_2487 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2486; V a_2 = v_p_2487; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str3, 0, "");
Clo g_heff_2ebuild_2eload_2esameButCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameButCase_entry, 2, 0};

V g_heff_2ebuild_2eload_2esameButCase(V v_a_240, V v_b_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24f2056124927x822823214(v_a_240, MK_INT(0LL), heff_strLength_lent(v_a_240, 0)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_246 = (g_list_2emap_24f2056124927x822823214(v_b_241, MK_INT(0LL), heff_strLength_lent(v_b_241, 0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  return heff_strEq(v_t_245, v_t_249);
}
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eload_2esameButCase(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0, 59, " on the disk: a file system that tells case apart finds no ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1, 10, " is named ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5, 74, ": names that differ only in case are one file where case is not told apart");

HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243) {
top: ;
  switch (heff_tag_of(v_ns_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_x_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_n_244 = heff_dup(heff_field(v_ns_243, 0));
    V v_ns2_245 = heff_dup(heff_field(v_ns_243, 1));
    switch (heff_tag_of(v_ns2_245)) {
    case TAG_Nil: {
      heff_drop_tag(v_ns_243, 2);
      if (heff_strEq_c_lent(v_n_244, v_x_242, 0)) {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_x_242);
        heff_drop(v_n_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_t_247 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_241; V a_2 = heff_dup(v_x_242); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_248 = heff_strAppend(v_n_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0), v_x_242));
        V v_f_249 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1), v_t_248));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
      }
    }
    case TAG_Cons: {
      heff_take_n(v_ns2_245, 0ULL, 2);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_x_242);
      heff_drop(v_n_244);
      V v_t_2414;
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_ns_243, 0);
        V v_xs_2413 = heff_field(v_ns_243, 1);
        heff_take_n(v_ns_243, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_ns_243);
      }
      V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4), heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5)));
      V v_f_2416 = heff_strAppend(v_d_241, v_t_2415);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ns2_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ns_243)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str1, 10, "package.hf");
Clo g_heff_2ebuild_2eload_2epackageRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackageRead_entry, 4, 0};

V g_heff_2ebuild_2eload_2epackageRead(V v_h_240, V v_ps_241, V v_src_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    V v_p_244 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Left = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_h_240);
    V v_t_245 = ({ V b_0 = heff_take_field(v_ps_241, 5); V a_1 = heff_get_n(v_ps_241, 0, 6); V a_2 = ((V)&g_heff_2ebuild_2eload_2epackageRead_str0); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_246 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_245, v_src_242, v_p_244));
    return heff_tag_at_n(v_ru_24x4_243_24Left, TAG_Left, 1, (V[]){v_t_246});
  }
  case TAG_Right: {
    V v_pk_247 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Right = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_247, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_x1_249 = (g_heff_2ebuild_2eload_2eheffAt(v_h_240, heff_dup(heff_rfield(v_ps_241, 0))));
      if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_x1_249);
        return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_247});
      } else {
        heff_drop_rec(v_pk_247, 4);
        heff_drop_cell(v_ru_24x4_243_24Right, 1);
        heff_drop(v_x1_249);
        V v_t_2410 = ({ V b_0 = heff_take_field(v_ps_241, 5); V a_1 = heff_get_n(v_ps_241, 0, 6); V a_2 = ((V)&g_heff_2ebuild_2eload_2epackageRead_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2411 = (g_heff_2ebuild_2eproject_2epackageLit(v_src_242));
        V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2eproject_2eclaimOf(a_0)); heff_drop(v_t_2411); r_; });
        V v_t_2413 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2410, v_src_242, v_t_2412));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2413});
      }
    } else {
      heff_drop(v_h_240);
      heff_drop_rec(v_ps_241, 6);
      return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_247});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2epackageRead(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_244 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_why_245 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_245, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_244, 0ULL, 1);
      v_t_247 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2410;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_249 = heff_field(v_pkgs_242, 1);
    v_t_2410 = heff_dup(v_y_249);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, heff_take_field(v_st_243, 2)));
  V v_t_2412 = (g_prelude_2e_2b_2b(v_t_247, v_t_2411));
  V v_t_2416;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2413 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      heff_take_n(v_x11_2413, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2415 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2415});
      break;
    }
    default: heff_nomatch(v_x11_2413);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2419;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_pkgs_242, 0);
    v_t_2419 = heff_dup(v_x_2417);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){heff_get_n(v_st_243, 0, 3), v_t_2412, v_ps_240, v_t_2416, v_t_2419});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_str1, 3, "src");
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam1, 1, 0};
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_entry, 3, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948(V v_h_240, V v_start_241, V v_d_242) {
top: ;
  V v_path_243 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_242), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam0, 2, 4, (V[]){v_path_243, v_h_240, v_d_242, v_start_241});
}
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_start_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    V v_st_2413 = heff_dup(heff_rfield(v_h_240, 3));
    HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(v_st_2413, heff_dup(v_d_242)));
    V v_t_2421;
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_field_2416 = v_t_2414.f[1];
      V v_field_2417 = v_t_2414.f[2];
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2417));
      V v_xs_2419 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2418; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2418); r_; });
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
      v_t_2421 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2415, v_field_2416, v_t_2420});
    }
    V v_t_2422 = ({ V a_0 = v_st_2413; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); r_; });
    if (heff_strEq_c_lent(v_t_2422, v_d_242, 1)) {
      heff_drop(v_d_242);
      heff_drop(v_hd_244);
      V v_t_2424 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_241), v_start_241, heff_take_field(v_h_240, 0), heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
      V f_ = v_k_245;
      args[0] = v_t_2424;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      V v_st_2425 = heff_dup(heff_rfield(v_h_240, 3));
      HeffT3 v_t_2426 = (g_std_2epath_2eparse_24cpr(v_st_2425, v_d_242));
      V v_t_2433;
      {
        V v_field_2427 = v_t_2426.f[0];
        V v_field_2428 = v_t_2426.f[1];
        V v_field_2429 = v_t_2426.f[2];
        V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2429));
        V v_xs_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2430; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2430); r_; });
        V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
        v_t_2433 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2427, v_field_2428, v_t_2432});
      }
      V v_t_2434 = ({ V a_0 = v_st_2425; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); r_; });
      V v_t_2435 = (g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948(v_h_240, v_start_241, v_t_2434));
      V f_ = v_t_2435;
      heff_room[0] = v_hd_244;
      heff_room[1] = v_k_245;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    heff_drop(v_start_241);
    heff_drop(v_hd_244);
    V v_t_2437 = (g_std_2epath_2ejoin(heff_rfield(v_h_240, 3), heff_dup(v_d_242), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_str1)));
    V v_t_2446;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nothing: {
      v_t_2446 = heff_dup(heff_rfield(v_h_240, 0));
      break;
    }
    case TAG_Just: {
      V v_hf_2438 = heff_field(v_x_2412, 0);
      V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
      HeffT2 v_t_2439 = ({ V a_0 = v_hf_2438; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_hf_2438); r_; });
      V v_t_2445;
      {
        V v_field_2441 = v_t_2439.f[1];
        int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
        if ((v_tag_2440 == ((int64_t)0ULL))) {
          V v_p_2443 = v_field_2441;
          v_t_2445 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Left, 1, (V[]){v_p_2443});
        } else {
          heff_drop_cell(v_ru_24x_2412_24Just, 1);
          V v_x_2444 = v_field_2441;
          v_t_2445 = (g_heff_2ebuild_2eproject_2epackageOf(v_x_2444));
        }
      }
      v_t_2446 = ({ V a_0 = heff_dup(v_h_240); V a_1 = heff_dup(v_d_242); V a_2 = v_t_2445; V r_ = (g_heff_2ebuild_2eload_2elibRead(a_0, a_1, a_2)); heff_drop(v_t_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_x_2447 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_242, v_t_2437, v_t_2446, heff_take_field(v_h_240, 1), heff_take_field(v_h_240, 2), heff_get_n(v_h_240, 3, 5)});
    V f_ = v_k_245;
    args[0] = v_x_2447;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_start_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_243, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948_lam2, 1, 5, (V[]){v_h_240, v_d_242, v_start_241, v_k_245, v_hd_244})));
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry, 2, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_243 = (g_std_2epath_2eparse_24cpr(v_st_242, heff_dup(v_file_241)));
  V v_t_2410;
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_246));
    V v_xs_248 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_247; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
    v_t_2410 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_244, v_field_245, v_t_249});
  }
  V v_t_2411 = ({ V a_0 = v_st_242; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); r_; });
  V v_st_2412 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_2413 = (g_std_2epath_2eparse_24cpr(v_st_2412, v_file_241));
  V v_t_2420;
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2416));
    V v_xs_2418 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2417; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2417); r_; });
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
    v_t_2420 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2414, v_field_2415, v_t_2419});
  }
  V v_t_2421 = ({ V a_0 = v_st_2412; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); r_; });
  return (g_heff_2ebuild_2eload_2erootFrom_24s122572187x1805628948(v_h_240, v_t_2411, v_t_2421));
}
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str0, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str3, 8, "heff.sum");
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053(V v_ps_240) {
top: ;
  V v_path_241 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str0)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam0, 2, 2, (V[]){v_path_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053(a[0]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    v_x_2421 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_t_2411 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_t_2412 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str1); V a_1 = v_t_2411; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str2), v_t_2411, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT2 v_t_2413 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(MK_INT(0LL), v_t_2412));
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_p_2417 = v_field_2415;
        V v_t_2418 = ({ V b_0 = heff_take_field(v_ps_240, 5); V a_1 = heff_get_n(v_ps_240, 0, 6); V a_2 = ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_str3); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_t_2411; V a_2 = v_p_2417; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
        v_x_2421 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Left, 1, (V[]){v_t_2419});
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_t_2411);
        V v_sums_2420 = v_field_2415;
        v_x_2421 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Right, 1, (V[]){v_sums_2420});
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_243;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_path_241 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_241, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), v_hd_242, heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_lam2, 1, 2, (V[]){v_ps_240, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str2, 38, ", which is not fetched: run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str3, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str5, 16, ": run `heff get`");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str6, 25, "heff.sum says nothing of ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str7, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str9, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str10, 1, " ");
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_246 = (g_list_2efilter_24s2128134357x1680551385(v_path_244, heff_take_field(v_root_241, 2)));
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    V v_t_249 = (g_list_2efilter_24s50027113x1989932102(v_r_247, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_path_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str0));
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam0, 2, 6, (V[]){v_path_2414, v_v_245, v_path_244, v_by_243, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2451 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_t_2452 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), v_d_2451));
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(v_ps_240, v_t_2452, v_path_244));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam1(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_v_245 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_by_243 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Nothing: {
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2415);
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str1), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str2)));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str3), heff_strAppend(v_path_244, v_t_2424));
    V v_t_2426 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_by_243, v_t_2425)});
    V f_ = v_k_2416;
    args[0] = v_t_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_h_2427 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Just = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2428 = (g_list_2efilter_24s639151216x1214259357(v_path_244, v_v_245, v_sums_242));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_hd_2415);
      heff_drop(v_h_2427);
      heff_drop_cell(v_ru_24x_2423_24Just, 1);
      V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str4), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str5)));
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str6), heff_strAppend(v_path_244, v_t_2429));
      V f_ = v_k_2416;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2430});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_s_2431 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 2);
      V v_want_2433 = heff_get_n(v_s_2431, 2, 3);
      V v_t_2434 = (g_prelude_2eskipSpaces(v_h_2427, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_h_2427, 0)) - ((int64_t)1ULL));
      V v_t_2436 = (g_prelude_2eskipSpaces(v_h_2427, heff_box_word(v_t_2435), MK_INT(-1LL)));
      V v_t_2437 = heff_strSlice(heff_dup(v_h_2427), v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
      if (heff_strEq_c_lent(v_t_2437, v_want_2433, 1)) {
        heff_drop(v_h_2427);
        heff_drop_cell(v_ru_24x_2423_24Just, 1);
        heff_drop(v_want_2433);
        V v_t_2439 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2440 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1087190516x917851092(v_ps_240, v_t_2439, v_path_244));
        V f_ = v_t_2440;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_hd_2415);
        V v_t_2441 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_244), heff_dup(v_v_245)));
        V v_t_2442 = (g_prelude_2eskipSpaces(v_h_2427, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2443 = (heff_unbox_word(heff_strLength_lent(v_h_2427, 0)) - ((int64_t)1ULL));
        V v_t_2444 = (g_prelude_2eskipSpaces(v_h_2427, heff_box_word(v_t_2443), MK_INT(-1LL)));
        V v_t_2445 = heff_strSlice(v_h_2427, v_t_2442, heff_intAdd(v_t_2444, MK_INT(1LL)));
        V v_t_2446 = heff_strAppend(v_t_2445, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str7), v_want_2433));
        V v_t_2447 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str8), v_t_2446));
        V v_t_2448 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str9), v_t_2447));
        V v_t_2449 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_str10), v_t_2448));
        V v_x_2450 = heff_tag_at_n(v_ru_24x_2423_24Just, TAG_Left, 1, (V[]){v_t_2449});
        V f_ = v_k_2416;
        args[0] = v_x_2450;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_path_2414 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_by_243 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2414, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam1_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566_lam2, 1, 7, (V[]){v_v_245, v_path_244, v_by_243, v_k_2416, v_sums_242, v_ps_240, v_hd_2415})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_entry, 7, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522(V v_lit_240, V v_lit_241, V v_lit_242, V v_root_243, V v_x3_244, V v_seen_245, V v_errs_246) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam0, 2, 2, (V[]){v_seen_245, v_errs_246});
  }
  case TAG_Cons: {
    V v_n_249 = heff_field(v_x3_244, 0);
    V v_rest_2410 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_n_249, 1)), heff_dup(v_root_243))) {
      heff_drop_rec(v_n_249, 3);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_root_243;
      V t_4 = v_rest_2410;
      V t_5 = v_seen_245;
      V t_6 = v_errs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_root_243 = t_3;
      v_x3_244 = t_4;
      v_seen_245 = t_5;
      v_errs_246 = t_6;
      goto top;
    } else {
      V v_t_2412 = (g_list_2eany_24s1345968422x916930247(heff_rfield(v_n_249, 1), heff_rfield(v_n_249, 2), v_seen_245));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_rec(v_n_249, 3);
        heff_drop(v_t_2412);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_root_243;
        V t_4 = v_rest_2410;
        V t_5 = v_seen_245;
        V t_6 = v_errs_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_root_243 = t_3;
        v_x3_244 = t_4;
        v_seen_245 = t_5;
        v_errs_246 = t_6;
        goto top;
      } else {
        heff_drop(v_t_2412);
        V v_c_2413 = (g_heff_2ebuild_2eload_2ecachedPkg_24s2084468972x1440549566(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(heff_rfield(v_n_249, 0)), heff_dup(heff_rfield(v_n_249, 1)), heff_dup(heff_rfield(v_n_249, 2))));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam1, 2, 9, (V[]){v_c_2413, v_n_249, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, heff_dup(v_root_243), v_rest_2410});
      }
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_seen_245 = heff_env(self)[0];
  V v_errs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_245, v_errs_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_249 = heff_env(self)[0];
  V v_seen_245 = heff_env(self)[1];
  V v_errs_246 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_root_243 = heff_env(self)[6];
  V v_rest_2410 = heff_env(self)[7];
  V v_hd_2414 = heff_env(self)[8];
  V v_k_2415 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_249, 1), heff_get_n(v_n_249, 2, 3), NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2417, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_errs_246, v_t_2421));
    V v_t_2423 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_rest_2410; V a_5 = v_t_2420; V a_6 = v_t_2422; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2423;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2424 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_str0), heff_dup(heff_rfield(v_n_249, 2)));
    V v_t_2426 = heff_strAppend(heff_dup(heff_rfield(v_n_249, 1)), v_t_2425);
    V v_t_2427 = (g_list_2emap_24s675147852x248982264(v_t_2426, heff_dup(heff_rfield(v_pk_2424, 2))));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_rest_2410, v_t_2427));
    V v_t_2429 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_249, 1), heff_get_n(v_n_249, 2, 3), heff_tag_n(TAG_Just, 1, (V[]){v_pk_2424})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2430));
    V v_t_2432 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_t_2428; V a_5 = v_t_2431; V a_6 = v_errs_246; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2432;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_n_249 = heff_env(self)[1];
  V v_seen_245 = heff_env(self)[2];
  V v_errs_246 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_root_243 = heff_env(self)[7];
  V v_rest_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522_lam2, 1, 10, (V[]){v_n_249, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, v_root_243, v_rest_2410, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_str1, 3, "src");
V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243) {
top: ;
  V v_t_244 = (g_list_2efilter_24s2128134357x1680551385(heff_rfield(v_x_242, 0), heff_take_field(v_root_241, 2)));
  V v_x_2410;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_x_2410 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
    break;
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_t_247 = (g_list_2efilter_24s50027113x1989932102(v_r_245, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_x_2410 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1))));
      break;
    }
    case TAG_Cons: {
      V v_p_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 2);
      v_x_2410 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), heff_get_n(v_p_248, 1, 2)));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_lam0, 2, 4, (V[]){v_ps_240, v_x_2410, v_pk_243, v_x_242});
}
V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2420;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_x_2410);
    heff_drop_rec(v_pk_243, 4);
    heff_drop_rec(v_x_242, 3);
    v_x_2420 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_Left, 1, (V[]){v_why_2415});
    break;
  }
  case TAG_Right: {
    V v_name_2416 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2417 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = heff_dup(v_x_2410); V a_2 = ((V)&g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_str1); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_2418 = (g_list_2emap_24s18996220x10511024(heff_take_field(v_pk_243, 2)));
    V v_t_2419 = heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){heff_get_n(v_x_242, 0, 3), v_x_2410, v_t_2417, heff_dup(v_name_2416), v_name_2416, heff_get_n(v_pk_243, 1, 4), v_t_2418});
    v_x_2420 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_Right, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_2412;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_pk_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_str0)));
  return (g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(heff_dup(v_ps_240), v_t_2413, v_hd_2411, heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725_lam1, 1, 5, (V[]){v_ps_240, v_x_2410, v_pk_243, v_x_242, v_k_2412})));
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_entry, 5, 0};

V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam0, 2, 2, (V[]){v_acc_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_dup(heff_rfield(v_x31_247, 2));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x31_247, 3);
      V t_0 = v_ps_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_acc_243;
      V t_4 = v_errs_244;
      v_ps_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_c_2411 = (g_heff_2ebuild_2eload_2epkgOf_24s905710573x438360725(heff_dup(v_ps_240), heff_dup(v_root_241), v_x31_247, v_pk_2410));
      return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam1, 2, 6, (V[]){v_c_2411, v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_errs_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2417 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2416));
    V v_t_2418 = (g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420(v_ps_240, v_root_241, v_rest_248, v_acc_243, v_t_2417));
    V f_ = v_t_2418;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_p_2419 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2420));
    V v_t_2422 = (g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420(v_ps_240, v_root_241, v_rest_248, v_t_2421, v_errs_244));
    V f_ = v_t_2422;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420_lam2, 1, 7, (V[]){v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_str1, 11, "the project");
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214(V v_ps_240, V v_root_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam0, 2, 3, (V[]){v_c_242, v_root_241, v_ps_240});
}
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_seen_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2418; V a_1 = v_seen_2416; V r_ = (g_list_2efoldl_24s1002907040x997927369(a_0, a_1)); heff_drop(v_seen_2416); r_; });
}
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_dup(heff_field(v_x_2421, 0));
    v_t_2424 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2427;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_x_2425 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_t_2427 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2430;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 2ULL, 2);
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2433;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_MkPair: {
    V v_y_2432 = heff_field(v_x_2421, 1);
    heff_take_n(v_x_2421, 2ULL, 2);
    v_t_2433 = v_y_2432;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2433));
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2434));
  V v_x_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2435});
  V f_ = v_k_244;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_seen_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_dup(heff_field(v_x_2413, 0));
    v_seen_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2417 = (g_list_2efoldl_24s489050722x1368997552(NTAG(TAG_Nil), heff_dup(v_seen_2416)));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam3, 1, 1, (V[]){v_seen_2416}), v_t_2417));
  V v_c_2420 = (g_heff_2ebuild_2eload_2epkgsOf_24s1903017754x864559420(v_ps_240, v_root_241, v_t_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2420;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam4, 1, 3, (V[]){v_x_245, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_dup(heff_field(v_x_245, 0));
    v_t_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V v_t_2410;
  if (heff_strEq_c(heff_dup(heff_rfield(v_root_241, 0)), ((V)&g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_str0))) {
    v_t_2410 = ((V)&g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_str1);
  } else {
    v_t_2410 = heff_dup(heff_rfield(v_root_241, 0));
  }
  V v_t_2411 = (g_list_2emap_24s675147852x248982264(v_t_2410, heff_dup(heff_rfield(v_root_241, 2))));
  V v_c_2412 = (g_heff_2ebuild_2eload_2eversionsGo_24s487874943x1147500522(heff_dup(v_ps_240), heff_dup(v_root_241), v_t_248, heff_rfield(v_root_241, 0), v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam2, 1, 5, (V[]){v_ps_240, v_root_241, v_hd_243, v_x_245, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereachAll_24s147303050x1028552214_lam1, 1, 4, (V[]){v_root_241, v_ps_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_entry, 3, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_pl_243 = heff_field(v_x2_240, 0);
    V v_rest_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam0_clo)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    HEFF_LAST return g_co_2eop_24s903439140x919002362(v_t_2411, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam1, 1, 4, (V[]){v_rest_244, v_p_241, v_pl_243, v_p_242}));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam0(V self, V *args) {
  V v_a_245 = args[0];
  return v_a_245;
}
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_pl_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_243, 4);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Just: {
    V v_s_2414 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    V v_t_2415 = heff_rec_n(4, shape_path__source__place__module, (V[]){heff_dup(heff_rfield(v_pl_243, 0)), v_s_2414, heff_dup(v_pl_243), heff_get_n(v_pl_243, 3, 4)});
    v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_x_2413});
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_p_242;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_pl_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810_lam2, 1, 3, (V[]){v_x_2412, v_pl_243, v_p_242})));
}
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam0, 1, 0};
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_entry, 5, 0};

V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(V v_ps_240, V v_d_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadDirectory, 2, (V[]){heff_dup(v_d_241), ((V)&g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam1, 1, 6, (V[]){v_p_244, v_x_245, v_ps_240, v_d_241, v_rest_246, v_p_243})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam0(V self, V *args) {
  V v_ns_247 = args[0];
  return v_ns_247;
}
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam2(V self, V *args) {
  V v_n_2415 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_n_2415; V a_1 = v_x_245; V r_ = (g_heff_2ebuild_2eload_2esameButCase(a_0, a_1)); heff_drop(v_n_2415); heff_drop(v_x_245); r_; });
}
V g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    heff_drop(v_x_245);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_rest_246);
    heff_drop(v_p_243);
    V f_ = v_p_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_ns_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    V v_t_2416 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901_lam2, 1, 1, (V[]){heff_dup(v_x_245)}), v_ns_2414));
    HeffT2 v_t_2417 = (g_heff_2ebuild_2eload_2ecasesIn_24cpr(heff_dup(v_ps_240), heff_dup(v_d_241), heff_dup(v_x_245), v_t_2416));
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        heff_drop(v_x_245);
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_d_241);
        heff_drop(v_rest_246);
        heff_drop(v_p_243);
        V v_why_2421 = v_field_2419;
        V f_ = v_p_244;
        args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_why_2421});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_field_2419);
        V v_t_2422 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_241, v_x_245));
        return (g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(v_ps_240, v_t_2422, v_rest_246, v_p_243, v_p_244));
      }
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(V v_lit_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam1, 2, 10, (V[]){v_t_2412, v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam4(V self, V *args) {
  V v_x_2469 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_f_2428 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_rs_247 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_from_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2472;
  switch (heff_tag_of(v_x_2469)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_dup(heff_field(v_x_2469, 0));
    v_t_2472 = v_x_2470;
    break;
  }
  default: heff_nomatch(v_x_2469);
  }
  V v_t_2475;
  switch (heff_tag_of(v_x_2469)) {
  case TAG_MkPair: {
    V v_y_2474 = heff_field(v_x_2469, 1);
    heff_take_n(v_x_2469, 2ULL, 2);
    v_t_2475 = v_y_2474;
    break;
  }
  default: heff_nomatch(v_x_2469);
  }
  V v_t_2476 = (g_heff_2ebuild_2eload_2epushDone(v_t_2472, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_f_2428, 0), heff_take_field(v_f_2428, 1), heff_dup(v_lit_240), v_t_2475));
  V v_m_2477 = heff_get_n(v_f_2428, 3, 4);
  V v_t_2479;
  if (heff_strEq_c_lent(v_w_2410, v_m_2477, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2477);
    v_t_2479 = v_rs_247;
  } else {
    v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2477}), v_rs_247});
  }
  V v_t_2480 = (g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2476, v_t_2479));
  V f_ = v_t_2480;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam3(V self, V *args) {
  V v_x_2456 = args[0];
  V v_f_2428 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_ps_241 = heff_env(self)[6];
  V v_pkgs_242 = heff_env(self)[7];
  V v_hd_2413 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  V v_rest_2411 = heff_env(self)[10];
  V v_k_2414 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_dup(v_stack_243)});
  V v_t_2458 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(heff_rfield(v_f_2428, 1))));
  V v_imps_2459 = heff_get_n(v_t_2458, 0, 4);
  V v_t_2460 = (g_list_2emap_24s1817208647x1282894070(v_imps_2459));
  V v_t_2461 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2460));
  V v_t_2467;
  switch (heff_tag_of(v_x_2456)) {
  case TAG_Nothing: {
    v_t_2467 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2462 = heff_field(v_x_2456, 0);
    heff_take_n(v_x_2456, 1ULL, 1);
    V v_t_2463 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str9), v_why_2462));
    V v_t_2464 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str10), v_t_2463));
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
    V v_t_2466 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2465));
    v_t_2467 = ({ V rv_2 = v_t_2466; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2456);
  }
  V v_c_2468 = (g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(heff_dup(v_lit_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2457, heff_dup(heff_rfield(v_f_2428, 0)), v_t_2461, v_t_2467, NTAG(TAG_Nil)));
  V f_ = v_c_2468;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam4, 1, 11, (V[]){v_ps_241, v_f_2428, v_lit_240, v_w_2410, v_rs_247, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2413 = heff_env(self)[9];
  V v_k_2414 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nil: {
    V v_places_2416 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_x2_2417 = (g_list_2emap_24s435407392x1528135477(v_places_2416));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str2), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str3)));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str4), heff_strAppend(v_w_2410, v_t_2421));
    V v_e_2423 = heff_strAppend(heff_dup(v_from_244), v_t_2422);
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2424));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2427 = (g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2426, v_rs_247));
    V f_ = v_t_2427;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2428 = heff_dup(heff_field(v_x_2415, 0));
    V v_others_2429 = heff_dup(heff_field(v_x_2415, 1));
    V v_t_2430 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
    V v_t_2431 = (g_list_2eany(v_t_2430, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2415, 2);
      heff_drop(v_others_2429);
      heff_drop(v_t_2431);
      V v_m_2432 = heff_get_n(v_f_2428, 3, 4);
      V v_t_2434;
      if (heff_strEq_c_lent(v_w_2410, v_m_2432, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2432);
        v_t_2434 = v_rs_247;
      } else {
        v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2432}), v_rs_247});
      }
      V v_t_2435 = (g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_st_246, v_t_2434));
      V f_ = v_t_2435;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2431);
      V v_t_2436 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2428, 3))}));
      V v_t_2437 = (g_list_2eany(v_t_2436, v_stack_243));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2415, 2);
        heff_drop(v_others_2429);
        heff_drop(v_t_2437);
        V v_m_2438 = heff_dup(heff_rfield(v_f_2428, 3));
        V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2438), NTAG(TAG_Nil)});
        V v_x2_2441 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2440));
        V v_t_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_t_2444 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str6); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        V v_t_2445 = heff_strAppend(v_m_2438, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str7), v_t_2444));
        V v_e_2446 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_str8), v_t_2445));
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
        V v_t_2448 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2447));
        V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2450 = heff_get_n(v_f_2428, 3, 4);
        V v_t_2452;
        if (heff_strEq_c_lent(v_w_2410, v_m_2450, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2450);
          v_t_2452 = v_rs_247;
        } else {
          v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2450}), v_rs_247});
        }
        V v_t_2453 = (g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2449, v_t_2452));
        V f_ = v_t_2453;
        heff_room[0] = v_hd_2413;
        heff_room[1] = v_k_2414;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2437);
        switch (heff_tag_of(v_others_2429)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2415, 2);
          V v_t_2454 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 1, 4);
          V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_f_2428, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(heff_dup(v_ps_241), v_t_2454, v_t_2455, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam3, 1, 12, (V[]){v_f_2428, v_stack_243, v_lit_240, v_st_246, v_w_2410, v_from_244, v_ps_241, v_pkgs_242, v_hd_2413, v_rs_247, v_rest_2411, v_k_2414})));
        }
        case TAG_Cons: {
          V v_ru_24others_2429_24Cons = heff_take_reuse_n(v_others_2429, 0ULL, 2);
          V v_e_2483 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2415, heff_dup(v_from_244), heff_dup(v_w_2410)));
          V v_t_2484 = heff_tag_at_n(v_ru_24others_2429_24Cons, TAG_Cons, 2, (V[]){v_e_2483, NTAG(TAG_Nil)});
          V v_t_2485 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2484));
          V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2428, 3)), heff_take_field(v_st_246, 1)});
          V v_t_2487 = ({ V rv_1 = v_t_2486; V rv_2 = v_t_2485; V rr_ = heff_rec_reuse_nf(v_st_246, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2488 = heff_get_n(v_f_2428, 3, 4);
          V v_t_2490;
          if (heff_strEq_c_lent(v_w_2410, v_m_2488, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2488);
            v_t_2490 = v_rs_247;
          } else {
            v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2488}), v_rs_247});
          }
          V v_t_2491 = (g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2487, v_t_2490));
          V f_ = v_t_2491;
          heff_room[0] = v_hd_2413;
          heff_room[1] = v_k_2414;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2429);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2eload_2ereadEvery_24s73916487x1793038810(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049_lam2, 1, 11, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_entry, 6, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam0, 2, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2411 = (g_heff_2ebuild_2eload_2eloadMany_24s1302003326x1496052049(heff_dup(v_before_243), heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam1, 2, 7, (V[]){v_c_2411, v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_before_243, v_t_2415));
  V v_t_2419;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 2);
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2420 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282(v_ps_240, v_pkgs_241, v_from_242, v_t_2416, v_ms_249, v_t_2419));
  V f_ = v_t_2420;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_m_248 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_from_242 = heff_env(self)[5];
  V v_ms_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282_lam2, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam4(V self, V *args); static Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam4, 1, 0};
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam8(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_entry, 2, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648(V v_h_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(heff_dup(v_h_240), heff_dup(v_file_241)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam0, 2, 3, (V[]){v_c_242, v_h_240, v_file_241});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam4(V self, V *args) {
  V v_a_2414 = args[0];
  return v_a_2414;
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam7(V self, V *args) {
  V v_m_2448 = args[0];
  V v_made_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2449 = ({ V a_0 = v_m_2448; V a_1 = v_made_2431; HeffT2 r_ = (g_list_2efind_24s1250280863x1570195177_24cpr(a_0, a_1)); heff_drop(v_m_2448); r_; });
  {
    V v_field_2451 = v_t_2449.f[1];
    int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
    if ((v_tag_2450 == ((int64_t)0ULL))) {
      V v_s_2453 = v_field_2451;
      return heff_get_n(v_s_2453, 5, 7);
    } else {
      heff_drop(v_field_2451);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam8(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_made_2431 = heff_env(self)[2];
  V v_src_2425 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2458;
  switch (heff_tag_of(v_x_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_dup(heff_field(v_x_2455, 0));
    v_t_2458 = v_x_2456;
    break;
  }
  default: heff_nomatch(v_x_2455);
  }
  V v_t_2459 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_m_2460 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2461 = ({ V a_0 = v_m_2460; V a_1 = v_made_2431; HeffT2 r_ = (g_list_2efind_24s1250280863x1570195177_24cpr(a_0, a_1)); heff_drop(v_m_2460); r_; });
  V v_t_2466;
  {
    V v_field_2463 = v_t_2461.f[1];
    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
    if ((v_tag_2462 == ((int64_t)0ULL))) {
      V v_s_2465 = v_field_2463;
      v_t_2466 = heff_get_n(v_s_2465, 5, 7);
    } else {
      heff_drop(v_field_2463);
      v_t_2466 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2469;
  switch (heff_tag_of(v_x_2455)) {
  case TAG_MkPair: {
    V v_y_2468 = heff_field(v_x_2455, 1);
    heff_take_n(v_x_2455, 2ULL, 2);
    v_t_2469 = v_y_2468;
    break;
  }
  default: heff_nomatch(v_x_2455);
  }
  V v_t_2470 = (g_heff_2ebuild_2eload_2epushDone(v_t_2458, heff_dup(v_x_245), v_t_2459, v_file_241, v_src_2425, v_t_2466, v_t_2469));
  V v_x_2471 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2470; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_244;
  args[0] = v_x_2471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_src_2425 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_made_2431 = heff_get_n(v_x_2430, 0, 3);
  V v_t_2434;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2434 = v_x_2432;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2435 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
  V v_m_2437 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_245), heff_dup(v_file_241)));
  HeffT2 v_t_2438 = ({ V a_0 = v_m_2437; V a_1 = heff_dup(v_made_2431); HeffT2 r_ = (g_list_2efind_24s1250280863x1570195177_24cpr(a_0, a_1)); heff_drop(v_m_2437); r_; });
  V v_t_2443;
  {
    V v_field_2440 = v_t_2438.f[1];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_s_2442 = v_field_2440;
      v_t_2443 = heff_get_n(v_s_2442, 5, 7);
    } else {
      heff_drop(v_field_2440);
      v_t_2443 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2444 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2443, heff_dup(v_src_2425)));
  V v_imps_2445 = heff_get_n(v_t_2444, 0, 4);
  V v_t_2446 = (g_list_2emap_24s1817208647x1282894070(v_imps_2445));
  V v_t_2447 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2446));
  V v_c_2454 = (g_heff_2ebuild_2eload_2eloadMany_24s1738941872x287629444(heff_dup(v_x_245), v_t_2434, v_t_2436, heff_dup(v_file_241), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam7, 1, 1, (V[]){heff_dup(v_made_2431)}), v_t_2447, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2454;
  heff_room[0] = v_hd_243;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam8, 1, 7, (V[]){v_x_245, v_file_241, v_made_2431, v_src_2425, v_x_247, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_str0), v_file_241), NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2421));
    V v_t_2423 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2422});
    V v_x_2424 = ({ V a_0 = v_x_245; V a_1 = v_x_247; V a_2 = v_x_2413; V a_3 = v_t_2423; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
    V f_ = v_k_244;
    args[0] = v_x_2424;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2425 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    V v_t_2428;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_dup(heff_field(v_x_2413, 0));
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_c_2429 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1917389134x1958115282(heff_dup(v_x_245), v_t_2428, heff_dup(v_file_241), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2429;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam6, 1, 7, (V[]){v_x_2413, v_x_245, v_file_241, v_src_2425, v_hd_243, v_x_247, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_file_241), ((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam4_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s903439140x919002362(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam5, 1, 6, (V[]){v_file_241, v_x_245, v_x_247, v_x_2413, v_k_244, v_hd_243})));
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_248 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      heff_take_n(v_x11_248, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Just, 1, (V[]){v_p_2410});
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_c_2412 = (g_heff_2ebuild_2eload_2epackagesOf_24s159043868x1195346404(heff_dup(v_x_245), v_t_2411));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam3, 1, 5, (V[]){v_file_241, v_hd_243, v_x_245, v_x_247, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s2091041826x1517140218(v_h_240, heff_dup(v_x_245)));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_lam1, 1, 4, (V[]){v_h_240, v_hd_243, v_file_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_entry, 5, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_rd_240);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam0, 2, 2, (V[]){v_seen_243, v_errs_244});
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_n_247, 1)), heff_dup(v_root_241))) {
      heff_drop_rec(v_n_247, 3);
      V t_0 = v_rd_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_seen_243;
      V t_4 = v_errs_244;
      v_rd_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    } else {
      V v_t_2410 = (g_list_2eany_24s1345968422x916930247(heff_rfield(v_n_247, 1), heff_rfield(v_n_247, 2), v_seen_243));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_n_247, 3);
        heff_drop(v_t_2410);
        V t_0 = v_rd_240;
        V t_1 = v_root_241;
        V t_2 = v_rest_248;
        V t_3 = v_seen_243;
        V t_4 = v_errs_244;
        v_rd_240 = t_0;
        v_root_241 = t_1;
        v_x3_242 = t_2;
        v_seen_243 = t_3;
        v_errs_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2410);
        V v_c_2411 = heff_tr(heff_call(heff_dup(v_rd_240), 3, (V[]){heff_dup(heff_rfield(v_n_247, 0)), heff_dup(heff_rfield(v_n_247, 1)), heff_dup(heff_rfield(v_n_247, 2))}));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam1, 2, 7, (V[]){v_c_2411, v_n_247, v_seen_243, v_errs_244, v_rd_240, heff_dup(v_root_241), v_rest_248});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_seen_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_n_247 = heff_env(self)[0];
  V v_seen_243 = heff_env(self)[1];
  V v_errs_244 = heff_env(self)[2];
  V v_rd_240 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), NTAG(TAG_Nothing)});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2417));
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2419));
    V v_t_2421 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_rest_248; V a_3 = v_t_2418; V a_4 = v_t_2420; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_root_241); r_; });
    V f_ = v_t_2421;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2422 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_str0), heff_dup(heff_rfield(v_n_247, 2)));
    V v_t_2424 = heff_strAppend(heff_dup(heff_rfield(v_n_247, 1)), v_t_2423);
    V v_t_2425 = (g_list_2emap_24s675147852x248982264(v_t_2424, heff_dup(heff_rfield(v_pk_2422, 2))));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_rest_248, v_t_2425));
    V v_t_2427 = heff_rec_n(3, shape_path__version__pkg, (V[]){heff_take_field(v_n_247, 1), heff_get_n(v_n_247, 2, 3), heff_tag_n(TAG_Just, 1, (V[]){v_pk_2422})});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2428));
    V v_t_2430 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_t_2426; V a_3 = v_t_2429; V a_4 = v_errs_244; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_root_241); r_; });
    V f_ = v_t_2430;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_n_247 = heff_env(self)[1];
  V v_seen_243 = heff_env(self)[2];
  V v_errs_244 = heff_env(self)[3];
  V v_rd_240 = heff_env(self)[4];
  V v_root_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_lam2, 1, 8, (V[]){v_n_247, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(heff_rfield(v_pl_244, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_244, 4);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_rec_n(4, shape_path__source__place__module, (V[]){heff_dup(heff_rfield(v_pl_244, 0)), v_s_2412, heff_dup(v_pl_244), heff_get_n(v_pl_244, 3, 4)});
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807(v_read_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(V v_lit_240, V v_read_241, V v_ps_242, V v_pkgs_243, V v_stack_244, V v_from_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_read_241);
    heff_drop(v_ps_242);
    heff_drop(v_pkgs_243);
    heff_drop(v_stack_244);
    heff_drop(v_from_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807(heff_dup(v_read_241), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam1, 2, 11, (V[]){v_c_2414, v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam4(V self, V *args) {
  V v_x_2471 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_241 = heff_env(self)[5];
  V v_pkgs_243 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_from_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2474;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_dup(heff_field(v_x_2471, 0));
    v_t_2474 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2477;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_y_2476 = heff_field(v_x_2471, 1);
    heff_take_n(v_x_2471, 2ULL, 2);
    v_t_2477 = v_y_2476;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2478 = (g_heff_2ebuild_2eload_2epushDone(v_t_2474, heff_dup(v_ps_242), heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_f_2430, 0), heff_take_field(v_f_2430, 1), heff_dup(v_lit_240), v_t_2477));
  V v_m_2479 = heff_get_n(v_f_2430, 3, 4);
  V v_t_2481;
  if (heff_strEq_c_lent(v_w_2411, v_m_2479, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2479);
    v_t_2481 = v_rs_248;
  } else {
    v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2479}), v_rs_248});
  }
  V v_t_2482 = (g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2478, v_t_2481));
  V f_ = v_t_2482;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam3(V self, V *args) {
  V v_x_2458 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_stack_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_from_245 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_ps_242 = heff_env(self)[7];
  V v_pkgs_243 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  V v_k_2416 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_dup(v_stack_244)});
  V v_t_2460 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(heff_rfield(v_f_2430, 1))));
  V v_imps_2461 = heff_get_n(v_t_2460, 0, 4);
  V v_t_2462 = (g_list_2emap_24s1817208647x1282894070(v_imps_2461));
  V v_t_2463 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2462));
  V v_t_2469;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_t_2469 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2464 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    V v_t_2465 = heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str9), v_why_2464));
    V v_t_2466 = heff_strAppend(heff_dup(v_from_245), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str10), v_t_2465));
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
    V v_t_2468 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2467));
    v_t_2469 = ({ V rv_2 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_c_2470 = (g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(heff_dup(v_lit_240), heff_dup(v_read_241), heff_dup(v_ps_242), heff_dup(v_pkgs_243), v_t_2459, heff_dup(heff_rfield(v_f_2430, 0)), v_t_2463, v_t_2469, NTAG(TAG_Nil)));
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam4, 1, 12, (V[]){v_ps_242, v_f_2430, v_lit_240, v_w_2411, v_rs_248, v_read_241, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_pkgs_243 = heff_env(self)[1];
  V v_from_245 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str2), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str3)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str4), heff_strAppend(v_w_2411, v_t_2423));
    V v_e_2425 = heff_strAppend(heff_dup(v_from_245), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
    V v_t_2433 = (g_list_2eany(v_t_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop(v_t_2433);
      V v_m_2434 = heff_get_n(v_f_2430, 3, 4);
      V v_t_2436;
      if (heff_strEq_c_lent(v_w_2411, v_m_2434, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2434);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2434}), v_rs_248});
      }
      V v_t_2437 = (g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_st_247, v_t_2436));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2433);
      V v_t_2438 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
      V v_t_2439 = (g_list_2eany(v_t_2438, v_stack_244));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop(v_t_2439);
        V v_m_2440 = heff_dup(heff_rfield(v_f_2430, 3));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_244)));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2440), NTAG(TAG_Nil)});
        V v_x2_2443 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str6); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_t_2447 = heff_strAppend(v_m_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str7), v_t_2446));
        V v_e_2448 = heff_strAppend(heff_dup(v_from_245), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_str8), v_t_2447));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
        V v_t_2450 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2449));
        V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2452 = heff_get_n(v_f_2430, 3, 4);
        V v_t_2454;
        if (heff_strEq_c_lent(v_w_2411, v_m_2452, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2452);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2452}), v_rs_248});
        }
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2451, v_t_2454));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2439);
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2417, 2);
          V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 1, 4);
          V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(heff_dup(v_ps_242), v_t_2456, v_t_2457, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam3, 1, 13, (V[]){v_f_2430, v_stack_244, v_lit_240, v_st_247, v_w_2411, v_from_245, v_read_241, v_ps_242, v_pkgs_243, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416})));
        }
        case TAG_Cons: {
          V v_ru_24others_2431_24Cons = heff_take_reuse_n(v_others_2431, 0ULL, 2);
          V v_e_2485 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_242), v_x_2417, heff_dup(v_from_245), heff_dup(v_w_2411)));
          V v_t_2486 = heff_tag_at_n(v_ru_24others_2431_24Cons, TAG_Cons, 2, (V[]){v_e_2485, NTAG(TAG_Nil)});
          V v_t_2487 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2486));
          V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_st_247, 1)});
          V v_t_2489 = ({ V rv_1 = v_t_2488; V rv_2 = v_t_2487; V rr_ = heff_rec_reuse_nf(v_st_247, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2490 = heff_get_n(v_f_2430, 3, 4);
          V v_t_2492;
          if (heff_strEq_c_lent(v_w_2411, v_m_2490, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2490);
            v_t_2492 = v_rs_248;
          } else {
            v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2490}), v_rs_248});
          }
          V v_t_2493 = (g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2489, v_t_2492));
          V f_ = v_t_2493;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2431);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_242 = heff_env(self)[1];
  V v_pkgs_243 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_read_241 = heff_env(self)[7];
  V v_stack_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s914472339x1226288897_lam2, 1, 12, (V[]){v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(V v_read_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_imp_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    heff_drop(v_imp_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s1290713744x66191807(heff_dup(v_read_240), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam1, 2, 11, (V[]){v_c_2414, v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  V v_imp_245 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_rs_248 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_pkgs_242 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_from_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2476 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2479;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2478 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2479 = v_y_2478;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2480 = (g_heff_2ebuild_2eload_2epushDone(v_t_2475, heff_dup(v_ps_241), heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_f_2430, 0), heff_take_field(v_f_2430, 1), v_t_2476, v_t_2479));
  V v_m_2481 = heff_get_n(v_f_2430, 3, 4);
  V v_t_2483;
  if (heff_strEq_c_lent(v_w_2411, v_m_2481, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2481);
    v_t_2483 = v_rs_248;
  } else {
    v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2481}), v_rs_248});
  }
  V v_t_2484 = (g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2480, v_t_2483));
  V f_ = v_t_2484;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam3(V self, V *args) {
  V v_x_2458 = args[0];
  V v_f_2430 = heff_env(self)[0];
  V v_stack_243 = heff_env(self)[1];
  V v_imp_245 = heff_env(self)[2];
  V v_st_247 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_from_244 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_ps_241 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_hd_2415 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  V v_rest_2412 = heff_env(self)[11];
  V v_k_2416 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_dup(v_stack_243)});
  V v_t_2460 = heff_tr(heff_call(heff_dup(v_imp_245), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
  V v_t_2461 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2460, heff_dup(heff_rfield(v_f_2430, 1))));
  V v_imps_2462 = heff_get_n(v_t_2461, 0, 4);
  V v_t_2463 = (g_list_2emap_24s1817208647x1282894070(v_imps_2462));
  V v_t_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
  V v_t_2470;
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    v_t_2470 = v_st_247;
    break;
  }
  case TAG_Just: {
    V v_why_2465 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    V v_t_2466 = heff_strAppend(heff_dup(v_w_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str9), v_why_2465));
    V v_t_2467 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str10), v_t_2466));
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2468));
    v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2458);
  }
  V v_c_2471 = (g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), v_t_2459, heff_dup(heff_rfield(v_f_2430, 0)), heff_dup(v_imp_245), v_t_2464, v_t_2470, NTAG(TAG_Nil)));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam4, 1, 12, (V[]){v_imp_245, v_f_2430, v_ps_241, v_w_2411, v_rs_248, v_read_240, v_pkgs_242, v_stack_243, v_from_244, v_rest_2412, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_imp_245 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  heff_clo_take(self, 12);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str2), heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str3)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str4), heff_strAppend(v_w_2411, v_t_2423));
    V v_e_2425 = heff_strAppend(heff_dup(v_from_244), v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_t_2432 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
    V v_t_2433 = (g_list_2eany(v_t_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop(v_t_2433);
      V v_m_2434 = heff_get_n(v_f_2430, 3, 4);
      V v_t_2436;
      if (heff_strEq_c_lent(v_w_2411, v_m_2434, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2434);
        v_t_2436 = v_rs_248;
      } else {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2434}), v_rs_248});
      }
      V v_t_2437 = (g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_st_247, v_t_2436));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2433);
      V v_t_2438 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2430, 3))}));
      V v_t_2439 = (g_list_2eany(v_t_2438, v_stack_243));
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop(v_t_2439);
        V v_m_2440 = heff_dup(heff_rfield(v_f_2430, 3));
        V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2440), NTAG(TAG_Nil)});
        V v_x2_2443 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str6); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_t_2447 = heff_strAppend(v_m_2440, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str7), v_t_2446));
        V v_e_2448 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_str8), v_t_2447));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2448, NTAG(TAG_Nil)});
        V v_t_2450 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2449));
        V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2452 = heff_get_n(v_f_2430, 3, 4);
        V v_t_2454;
        if (heff_strEq_c_lent(v_w_2411, v_m_2452, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2452);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2452}), v_rs_248});
        }
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2451, v_t_2454));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2439);
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2417, 2);
          V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 1, 4);
          V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_f_2430, 2)), 2, 4);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s876691898x148348901(heff_dup(v_ps_241), v_t_2456, v_t_2457, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam3, 1, 13, (V[]){v_f_2430, v_stack_243, v_imp_245, v_st_247, v_w_2411, v_from_244, v_read_240, v_ps_241, v_pkgs_242, v_hd_2415, v_rs_248, v_rest_2412, v_k_2416})));
        }
        case TAG_Cons: {
          V v_ru_24others_2431_24Cons = heff_take_reuse_n(v_others_2431, 0ULL, 2);
          V v_e_2487 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2417, heff_dup(v_from_244), heff_dup(v_w_2411)));
          V v_t_2488 = heff_tag_at_n(v_ru_24others_2431_24Cons, TAG_Cons, 2, (V[]){v_e_2487, NTAG(TAG_Nil)});
          V v_t_2489 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2488));
          V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_f_2430, 3)), heff_take_field(v_st_247, 1)});
          V v_t_2491 = ({ V rv_1 = v_t_2490; V rv_2 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_st_247, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2492 = heff_get_n(v_f_2430, 3, 4);
          V v_t_2494;
          if (heff_strEq_c_lent(v_w_2411, v_m_2492, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2492);
            v_t_2494 = v_rs_248;
          } else {
            v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2492}), v_rs_248});
          }
          V v_t_2495 = (g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495(v_read_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_imp_245, v_rest_2412, v_t_2491, v_t_2494));
          V f_ = v_t_2495;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2431);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_read_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_imp_245 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s443552052x2030200495_lam2, 1, 12, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2411, v_st_247, v_read_240, v_stack_243, v_imp_245, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}