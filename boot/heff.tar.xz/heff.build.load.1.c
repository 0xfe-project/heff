// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_at 9882
#define LBL_cwd 308458
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_sources 357464573
#define LBL_start 311115900
#define LBL_style 311138763
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V, V, V, V);
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2eload_2esameDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2esameDir(V v_h_240, V v_a_241, V v_b_242) {
top: ;
  V v_style_243 = heff_take_field(v_h_240, 3);
  V v_cwd_244 = heff_get_n(v_h_240, 2, 5);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_a_241));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_heff_2eutil_2ehostpath_2enormalize(heff_dup(v_style_243), v_t_249));
  V v_st_2411 = heff_dup(v_style_243);
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2411), v_cwd_244));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2411), v_b_242));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = v_st_2411; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2411); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2eutil_2ehostpath_2enormalize(v_style_243, v_t_2415));
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2410, v_t_2416, 0));
  heff_drop(v_t_2410);
  heff_drop(v_t_2416);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2esameDir(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_k_242)}});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2etakeUntil_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      heff_drop(v_rest_244);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str1, 1, "_");
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_243;
  if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
    v_t_243 = heff_dup(v_x_241);
  } else {
    v_t_243 = heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2eload_2efreeName_str0)), heff_intShow(heff_dup(v_n_242)));
  }
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_243}));
  V v_x1_245 = (g_list_2eany(v_t_244, v_taken_240));
  if (!(heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop(v_x1_245);
    if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
      heff_drop(v_n_242);
      return v_x_241;
    } else {
      return heff_strAppend(heff_strAppend(v_x_241, ((V)&g_heff_2ebuild_2eload_2efreeName_str1)), heff_intShow(v_n_242));
    }
  } else {
    heff_drop(v_x1_245);
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2efreeName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0, 10, " is named ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1, 59, " on the disk: a file system that tells case apart finds no ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5, 74, ": names that differ only in case are one file where case is not told apart");

HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243) {
top: ;
  switch (heff_tag_of(v_ns_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_x_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_ns2_245 = heff_field(v_ns_243, 1);
    switch (heff_tag_of(v_ns2_245)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Cons: {
        V v_n_246 = heff_field(v_ns_243, 0);
        if (heff_strEq_c_lent(v_n_246, v_x_242, 0)) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_d_241);
          heff_drop(v_x_242);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          V v_st_248 = heff_get_n(v_ps_240, 5, 6);
          V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_248), v_d_241));
          V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_248), heff_dup(v_x_242)));
          V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
          V v_t_2412 = ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
          V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0)), heff_dup(v_n_246));
          V v_f_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1)), v_x_242);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ns_243)}});
      }
    }
    case TAG_Cons: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_x_242);
      V v_t_2419;
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_ns_243, 0);
        V v_xs_2418 = heff_field(v_ns_243, 1);
        v_t_2419 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3), heff_dup(v_x_2417), v_xs_2418));
        break;
      }
      default: heff_nomatch(v_ns_243);
      }
      V v_t_2420 = heff_strAppend(heff_strAppend(v_d_241, ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4)), v_t_2419);
      V v_f_2421 = heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ns2_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ns_243)}});
  }
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_done_244 = heff_take_field(v_st_243, 0);
  V v_errors_245 = heff_get_n(v_st_243, 2, 3);
  V v_t_249;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_246 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_why_247 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_247, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_246, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_246);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_field(v_pkgs_242, 1);
    v_t_2412 = heff_dup(v_y_2411);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_errors_245));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2418;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2415 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      heff_take_n(v_x11_2415, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2417 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2417});
      break;
    }
    default: heff_nomatch(v_x11_2415);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2421;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_pkgs_242, 0);
    v_t_2421 = heff_dup(v_x_2419);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_done_244, v_t_2414, v_ps_240, v_t_2418, v_t_2421});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry, 2, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_243 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_242), heff_dup(v_file_241)));
  V v_t_2413;
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_d_247 = v_field_244;
    V v_a_248 = v_field_245;
    V v_xs_249 = v_field_246;
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_xs_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2410; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
    v_t_2413 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_247, v_a_248, v_t_2412});
  }
  V v_t_2414 = ({ V a_0 = v_st_242; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2413); r_; });
  V v_st_2415 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_2416 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2415), v_file_241));
  V v_t_2426;
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2418 = v_t_2416.f[1];
    V v_field_2419 = v_t_2416.f[2];
    V v_d_2420 = v_field_2417;
    V v_a_2421 = v_field_2418;
    V v_xs_2422 = v_field_2419;
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2422));
    V v_xs_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2423; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    v_t_2426 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2420, v_a_2421, v_t_2425});
  }
  V v_t_2427 = ({ V a_0 = v_st_2415; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2426); r_; });
  return (g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(v_h_240, v_t_2414, v_t_2427));
}
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str2, 10, "package.hf");
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(V v_h_240, V v_ps_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(heff_rfield(v_ps_241, 0))));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_242), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str0)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_s_246 = ({ V a_0 = v_st_242; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_245); r_; });
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_246));
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_c_2423 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam3, 2, 3, (V[]){v_c_2423, v_h_240, v_ps_241});
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_err_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2419 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2418})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2419));
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam2, 2, 1, (V[]){v_x_2420});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop_rec(v_ps_241, 6);
    V f_ = v_k_2425;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    V v_h_2429 = v_h_240;
    V v_ps_2430 = v_ps_241;
    V v_root_2431 = heff_take_field(v_ps_2430, 0);
    V v_style_2432 = heff_get_n(v_ps_2430, 5, 6);
    V v_src_2433 = heff_dup(v_y_2428);
    HeffT2 v_t_2434 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2428));
    V v_x4_2439;
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_p_2437 = v_field_2436;
        v_x4_2439 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2437});
      } else {
        V v_x_2438 = v_field_2436;
        v_x4_2439 = ({ V a_0 = v_x_2438; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2438); r_; });
      }
    }
    V v_t_2479;
    switch (heff_tag_of(v_x4_2439)) {
    case TAG_Left: {
      V v_p_2440 = heff_field(v_x4_2439, 0);
      V v_ru_24x4_2439_24Left = heff_take_reuse_n(v_x4_2439, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2426_24Right, 1);
      heff_drop(v_h_2429);
      V v_d_2441 = v_root_2431;
      V v_st_2442 = v_style_2432;
      V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2442), v_d_2441));
      V v_t_2444 = (g_std_2epath_2eparse(heff_dup(v_st_2442), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str1)));
      V v_t_2445 = (g_std_2epath_2ejoin(v_t_2443, v_t_2444));
      V v_t_2446 = ({ V a_0 = v_st_2442; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2442); heff_drop(v_t_2445); r_; });
      V v_t_2447 = ({ V a_0 = v_t_2446; V a_1 = v_src_2433; V a_2 = v_p_2440; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2433); r_; });
      v_t_2479 = heff_tag_at_n(v_ru_24x4_2439_24Left, TAG_Left, 1, (V[]){v_t_2447});
      break;
    }
    case TAG_Right: {
      V v_pk_2448 = heff_field(v_x4_2439, 0);
      V v_ru_24x4_2439_24Right = heff_take_reuse_n(v_x4_2439, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2448, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
        V v_x1_2449 = (g_heff_2ebuild_2eload_2eheffAt(v_h_2429, heff_dup(v_root_2431)));
        if (!(heff_dup(v_x1_2449) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x_2426_24Right, 1);
          heff_drop_rec(v_pk_2448, 4);
          heff_drop(v_x1_2449);
          V v_d_2450 = v_root_2431;
          V v_st_2451 = v_style_2432;
          V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2451), v_d_2450));
          V v_t_2453 = (g_std_2epath_2eparse(heff_dup(v_st_2451), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str2)));
          V v_t_2454 = (g_std_2epath_2ejoin(v_t_2452, v_t_2453));
          V v_t_2455 = ({ V a_0 = v_st_2451; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2451); heff_drop(v_t_2454); r_; });
          HeffT2 v_t_2456 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(heff_dup(v_src_2433)));
          V v_t_2477;
          {
            V v_field_2458 = v_t_2456.f[1];
            int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
            if ((v_tag_2457 == ((int64_t)0ULL))) {
              V v_x11_2459 = v_field_2458;
              heff_drop(v_x11_2459);
              v_t_2477 = heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
            } else {
              V v_x_2460 = v_field_2458;
              HeffT2 v_t_2461 = ({ V a_0 = heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()); V a_1 = v_x_2460; HeffT2 r_ = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(a_0, a_1)); heff_drop(v_x_2460); r_; });
              {
                V v_field_2463 = v_t_2461.f[1];
                int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                if ((v_tag_2462 == ((int64_t)0ULL))) {
                  V v_x_2464 = v_field_2463;
                  heff_drop(v_x_2464);
                  v_t_2477 = heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
                } else {
                  V v_x11_2465 = v_field_2463;
                  switch (heff_tag_of(v_x11_2465)) {
                  case TAG_Nil: {
                    v_t_2477 = heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
                    break;
                  }
                  case TAG_Cons: {
                    V v_m_2466 = heff_field(v_x11_2465, 0);
                    heff_take_n(v_x11_2465, 1ULL, 2);
                    V v_t_2476;
                    switch (heff_tag_of(v_m_2466)) {
                    case TAG_LStr: {
                      V v_t_2469 = heff_field(v_m_2466, 1);
                      heff_take_n(v_m_2466, 2ULL, 2);
                      v_t_2476 = v_t_2469;
                      break;
                    }
                    case TAG_LTag: {
                      V v_t_2471 = heff_field(v_m_2466, 1);
                      heff_take_n(v_m_2466, 2ULL, 2);
                      v_t_2476 = v_t_2471;
                      break;
                    }
                    case TAG_LList: {
                      V v_t_2473 = heff_field(v_m_2466, 1);
                      heff_take_n(v_m_2466, 2ULL, 2);
                      v_t_2476 = v_t_2473;
                      break;
                    }
                    case TAG_LRec: {
                      V v_t_2475 = heff_field(v_m_2466, 1);
                      heff_take_n(v_m_2466, 2ULL, 2);
                      v_t_2476 = v_t_2475;
                      break;
                    }
                    default: heff_nomatch(v_m_2466);
                    }
                    v_t_2477 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2476, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
                    break;
                  }
                  default: heff_nomatch(v_x11_2465);
                  }
                }
              }
            }
          }
          V v_t_2478 = ({ V a_0 = v_t_2455; V a_1 = v_src_2433; V a_2 = v_t_2477; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2433); r_; });
          v_t_2479 = heff_tag_at_n(v_ru_24x4_2439_24Right, TAG_Left, 1, (V[]){v_t_2478});
        } else {
          heff_drop(v_root_2431);
          heff_drop(v_style_2432);
          heff_drop(v_src_2433);
          heff_drop_cell(v_ru_24x4_2439_24Right, 1);
          heff_drop(v_x1_2449);
          v_t_2479 = heff_tag_at_n(v_ru_24x_2426_24Right, TAG_Right, 1, (V[]){v_pk_2448});
        }
      } else {
        heff_drop(v_h_2429);
        heff_drop(v_root_2431);
        heff_drop(v_style_2432);
        heff_drop(v_src_2433);
        heff_drop_cell(v_ru_24x4_2439_24Right, 1);
        v_t_2479 = heff_tag_at_n(v_ru_24x_2426_24Right, TAG_Right, 1, (V[]){v_pk_2448});
      }
      break;
    }
    default: heff_nomatch(v_x4_2439);
    }
    V v_x_2480 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2479});
    V f_ = v_k_2425;
    args[0] = v_x_2480;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam4, 1, 3, (V[]){v_k_2425, v_h_240, v_ps_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry, 3, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(v_h_241), heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam0, 2, 4, (V[]){v_c_243, v_h_241, v_read_240, v_file_242});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam6(V self, V *args) {
  V v_m_2442 = args[0];
  V v_made_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2443 = ({ V a_0 = v_m_2442; V a_1 = v_made_2426; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2442); heff_drop(v_made_2426); r_; });
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_s_2446 = v_field_2445;
      return heff_get_n(v_s_2446, 6, 8);
    } else {
      heff_drop(v_field_2445);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_made_2426 = heff_env(self)[2];
  V v_src_2420 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2451;
  switch (heff_tag_of(v_x_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_dup(heff_field(v_x_2448, 0));
    v_t_2451 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  V v_t_2452 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2453 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2454 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2455 = ({ V a_0 = v_m_2454; V a_1 = v_made_2426; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2454); heff_drop(v_made_2426); r_; });
  V v_t_2459;
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    if ((v_tag_2456 == ((int64_t)0ULL))) {
      V v_s_2458 = v_field_2457;
      v_t_2459 = heff_get_n(v_s_2458, 6, 8);
    } else {
      heff_drop(v_field_2457);
      v_t_2459 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2462;
  switch (heff_tag_of(v_x_2448)) {
  case TAG_MkPair: {
    V v_y_2461 = heff_field(v_x_2448, 1);
    heff_take_n(v_x_2448, 2ULL, 2);
    v_t_2462 = v_y_2461;
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  V v_t_2463 = (g_heff_2ebuild_2eload_2epushDone(v_t_2451, heff_dup(v_x_246), v_t_2452, v_t_2453, v_file_242, v_src_2420, v_t_2459, v_t_2462));
  V v_x_2464 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2463; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_src_2420 = heff_env(self)[3];
  V v_read_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_made_2426 = heff_get_n(v_x_2425, 0, 3);
  V v_t_2429;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2427 = heff_dup(heff_field(v_x_2414, 0));
    v_t_2429 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2430 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  V v_m_2432 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2433 = ({ V a_0 = v_m_2432; V a_1 = v_made_2426; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2432); r_; });
  V v_t_2437;
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_s_2436 = v_field_2435;
      v_t_2437 = heff_get_n(v_s_2436, 6, 8);
    } else {
      heff_drop(v_field_2435);
      v_t_2437 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2438 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2437, heff_dup(v_src_2420)));
  V v_imps_2439 = heff_get_n(v_t_2438, 0, 4);
  V v_t_2440 = (g_list_2emap_24s1817208647x1282894070(v_imps_2439));
  V v_t_2441 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2440));
  V v_c_2447 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, heff_dup(v_x_246), v_t_2429, v_t_2431, heff_dup(v_file_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam6, 1, 1, (V[]){heff_dup(v_made_2426)}), v_t_2441, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2447;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam7, 1, 7, (V[]){v_x_246, v_file_242, v_made_2426, v_src_2420, v_x_248, v_x_2414, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2418 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2417});
    V v_x_2419 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2418; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2420 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_dup(heff_field(v_x_2414, 0));
      v_t_2423 = v_x_2421;
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_c_2424 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(heff_dup(v_read_240), heff_dup(v_x_246), v_t_2423, heff_dup(v_file_242), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2424;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam5, 1, 8, (V[]){v_x_2414, v_x_246, v_file_242, v_src_2420, v_read_240, v_hd_244, v_x_248, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_248, v_x_2414, v_k_245, v_read_240, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      heff_take_n(v_x11_249, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Just, 1, (V[]){v_p_2411});
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_c_2413 = (g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(heff_dup(v_x_246), v_t_2412));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(v_h_241, heff_dup(v_x_246)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam1, 1, 5, (V[]){v_h_241, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}