// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Right 62770
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__source__place__module__named[] = {LBL_path, LBL_source, LBL_place, LBL_module, LBL_named};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_clo;
HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eemptySt_get(void);
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163(V, V);
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_clo;
V g_heff_2ebuild_2eload_2elibRead(V, V, V);
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2elibRead_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epackageRead(V, V, V, V);
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackageRead_clo;
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(V, V);
V g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1647993723x1864478745(V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1647993723x1864478745_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1647993723x1864478745_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_clo;
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2eutil_2ehostpath_2eisUnder(V, V, V);
V g_heff_2eutil_2ehostpath_2eisUnder_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2eisUnder_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1218501002x1291750665_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2emap_24f201346761x152404242(V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT2 g_std_2epath_2erelative_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(v_st_245, heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(v_st_245, heff_dup(v_d_241)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_st_2410 = heff_dup(v_style_243);
  V v_t_2411 = (g_std_2epath_2eparse(v_st_2410, heff_dup(v_cwd_244)));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_2410, heff_dup(v_path_242)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
  V v_t_2415 = (g_heff_2eutil_2ehostpath_2eisUnder(v_style_243, v_t_249, v_t_2414));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    V v_st_2416 = heff_dup(v_style_243);
    V v_st_2417 = heff_dup(v_style_243);
    V v_t_2418 = (g_std_2epath_2eparse(v_st_2417, heff_dup(v_cwd_244)));
    V v_t_2419 = (g_std_2epath_2eparse(v_st_2417, v_d_241));
    V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
    V v_from_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
    V v_st_2422 = v_style_243;
    V v_t_2423 = (g_std_2epath_2eparse(v_st_2422, v_cwd_244));
    V v_t_2424 = (g_std_2epath_2eparse(v_st_2422, v_path_242));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    V v_to_2426 = ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_std_2epath_2eparse(v_st_2416, v_from_2421));
    V v_t_2428 = (g_std_2epath_2eparse(v_st_2416, v_to_2426));
    HeffT2 v_t_2429 = (g_std_2epath_2erelative_24cpr(v_st_2416, v_t_2427, v_t_2428));
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2432 = v_field_2431;
        V v_f_2433 = ({ V a_0 = v_st_2416; V a_1 = v_x_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_x_2432); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
      } else {
        heff_drop(v_st_2416);
        heff_drop(v_field_2431);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    heff_drop(v_t_2415);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str6, 1, ".");
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_path_241)));
  V v_p_2414;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_path_241);
      V v_rel_245 = v_field_244;
      v_p_2414 = v_rel_245;
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_246 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 1)), heff_dup(v_path_241)));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop(v_path_241);
          V v_rel_249 = v_field_248;
          v_p_2414 = v_rel_249;
        } else {
          heff_drop(v_field_248);
          HeffT2 v_t_2410 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 0)), heff_dup(v_path_241)));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              heff_drop(v_path_241);
              V v_rel_2413 = v_field_2412;
              v_p_2414 = v_rel_2413;
            } else {
              heff_drop(v_field_2412);
              v_p_2414 = v_path_241;
            }
          }
        }
      }
    }
  }
  int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_p_2414, 0)) - ((int64_t)3ULL));
  V v_t_2416 = heff_strSlice(heff_dup(v_p_2414), heff_box_word(v_t_2415), heff_strLength_lent(v_p_2414, 0));
  V v_t_2418;
  if (heff_strEq_c(v_t_2416, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_2414, 0)) - ((int64_t)3ULL));
    v_t_2418 = heff_strSlice(v_p_2414, MK_INT(0LL), heff_box_word(v_t_2417));
  } else {
    v_t_2418 = v_p_2414;
  }
  HeffT3 v_t_2419 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_t_2418; HeffT3 r_ = (g_std_2epath_2eparse_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2420 = v_t_2419.f[0];
    V v_field_2421 = v_t_2419.f[1];
    V v_field_2422 = v_t_2419.f[2];
    V v_d_2423 = v_field_2420;
    heff_drop(v_d_2423);
    V v_a_2424 = v_field_2421;
    V v_xs_2425 = v_field_2422;
    V v_xs_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str1); V a_1 = v_a_2424; V a_2 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2); V b_3 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str3); V a_4 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2425; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2424); heff_drop(b_3); r_; });
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2426));
    V v_x2_2428 = v_t_2427;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str5);
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_xs_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str6); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
    }
    default: return heff_nomatch(v_x2_2428);
    }
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2einside_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2einside_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2einside_entry, 3, 0};

V g_heff_2ebuild_2eload_2einside(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  if (heff_strEq_c_lent(v_d_241, ((V)&g_heff_2ebuild_2eload_2einside_str0), 2)) {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    return NTAG(TAG_True);
  } else {
    V v_st_245 = heff_dup(v_style_243);
    V v_t_246 = (g_std_2epath_2eparse(v_st_245, heff_dup(v_cwd_244)));
    V v_t_247 = (g_std_2epath_2eparse(v_st_245, v_d_241));
    V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
    V v_st_2410 = heff_dup(v_style_243);
    V v_t_2411 = (g_std_2epath_2eparse(v_st_2410, v_cwd_244));
    V v_t_2412 = (g_std_2epath_2eparse(v_st_2410, v_path_242));
    V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
    V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
    return ({ V a_0 = v_style_243; V a_1 = v_t_249; V a_2 = v_t_2414; V r_ = (g_heff_2eutil_2ehostpath_2eisUnder(a_0, a_1, a_2)); heff_drop(v_style_243); r_; });
  }
}
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2einside(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2esameDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2esameDir(V v_h_240, V v_a_241, V v_b_242) {
top: ;
  V v_style_243 = heff_take_field(v_h_240, 3);
  V v_cwd_244 = heff_get_n(v_h_240, 2, 5);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(v_st_245, heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(v_st_245, v_a_241));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_heff_2eutil_2ehostpath_2enormalize(v_style_243, v_t_249));
  V v_st_2411 = heff_dup(v_style_243);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_2411, v_cwd_244));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_2411, v_b_242));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = v_st_2411; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2411); heff_drop(v_t_2414); r_; });
  V v_t_2416 = ({ V a_0 = v_style_243; V a_1 = v_t_2415; V r_ = (g_heff_2eutil_2ehostpath_2enormalize(a_0, a_1)); heff_drop(v_style_243); r_; });
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2410, v_t_2416, 0));
  heff_drop(v_t_2410);
  heff_drop(v_t_2416);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2esameDir(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eheffAt_str0, 3, "lib");
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eheffAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eheffAt_entry, 2, 0};

V g_heff_2ebuild_2eload_2eheffAt(V v_h_240, V v_d_241) {
top: ;
  V v_t_243 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2eload_2eheffAt_lam0, 1, 2, (V[]){heff_dup(v_h_240), heff_dup(v_d_241)}), heff_rfield(v_h_240, 4)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop_rec(v_h_240, 5);
    heff_drop(v_d_241);
    heff_drop(v_t_243);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    V v_st_244 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_245 = (g_std_2epath_2eparse(v_st_244, v_d_241));
    V v_t_246 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ebuild_2eload_2eheffAt_str0)));
    V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
    V v_t_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
    return (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_240), heff_get_n(v_h_240, 0, 5), v_t_248));
  }
}
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eheffAt(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2eload_2esameDir(v_h_240, v_o_242, v_d_241));
}
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str0, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2eload_2elibRead_str1, 3, "lib");
Clo g_heff_2ebuild_2eload_2elibRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2elibRead_entry, 3, 0};

V g_heff_2ebuild_2eload_2elibRead(V v_h_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    heff_drop(v_d_241);
    return heff_get_n(v_h_240, 0, 5);
  }
  case TAG_Right: {
    V v_pk_244 = heff_field(v_x3_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_244, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_t_245 = (g_heff_2ebuild_2eload_2eheffAt(heff_dup(v_h_240), heff_dup(v_d_241)));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        V v_st_246 = heff_dup(heff_rfield(v_h_240, 3));
        V v_t_247 = (g_std_2epath_2eparse(v_st_246, heff_dup(v_d_241)));
        V v_t_248 = (g_std_2epath_2eparse(v_st_246, ((V)&g_heff_2ebuild_2eload_2elibRead_str0)));
        V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
        V v_t_2410 = ({ V a_0 = v_st_246; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); heff_drop(v_t_249); r_; });
        V v_x1_2411 = (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_240), heff_dup(heff_rfield(v_h_240, 0)), v_t_2410));
        if (!(heff_dup(v_x1_2411) == NTAG(TAG_True))) {
          heff_drop(v_x1_2411);
          V v_st_2412 = heff_get_n(v_h_240, 3, 5);
          V v_t_2413 = (g_std_2epath_2eparse(v_st_2412, v_d_241));
          V v_t_2414 = (g_std_2epath_2eparse(v_st_2412, ((V)&g_heff_2ebuild_2eload_2elibRead_str1)));
          V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
          return ({ V a_0 = v_st_2412; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2415); r_; });
        } else {
          heff_drop(v_d_241);
          heff_drop(v_x1_2411);
          return heff_get_n(v_h_240, 0, 5);
        }
      } else {
        heff_drop(v_d_241);
        heff_drop(v_t_245);
        return heff_get_n(v_h_240, 0, 5);
      }
    } else {
      heff_drop(v_d_241);
      return heff_get_n(v_h_240, 0, 5);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2elibRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2elibRead(a[0], a[1], a2); heff_drop(a2); return r;
}

HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_k_242}});
    } else {
      heff_drop_rec(v_k_242, 7);
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2etakeUntil_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      heff_drop(v_rest_244);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_y_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x_240;
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2etakeUntil_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_pkgs_240);
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_stack_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_pkgs_240);
      heff_drop(v_rest_244);
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ebuild_2eload_2etakeUntil(v_path_243, v_stack_241));
      V v_xs_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, v_t_247});
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_t_246);
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(heff_dup(v_pkgs_240), v_path_243));
      V v_t_2414;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k_2413 = v_field_2412;
          v_t_2414 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2413, 6, 7)));
        } else {
          heff_drop(v_field_2412);
          v_t_2414 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2415 = (g_heff_2ebuild_2eload_2ecycleAmong(heff_dup(v_pkgs_240), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2414));
      V v_x2_2416 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_Nothing: {
        return v_x2_2416;
      }
      case TAG_Just: {
        V v_x_2417 = heff_field(v_x1_2415, 0);
        V v_ru_24x1_2415_24Just = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
        heff_drop(v_x2_2416);
        return heff_tag_at_n(v_ru_24x1_2415_24Just, TAG_Just, 1, (V[]){v_x_2417});
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecycleAmong(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str1, 1, "_");
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_244;
  if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
    v_t_244 = heff_dup(v_x_241);
  } else {
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str0), heff_intShow(heff_dup(v_n_242)));
    v_t_244 = heff_strAppend(heff_dup(v_x_241), v_t_243);
  }
  V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_244}));
  V v_x1_246 = (g_list_2eany(v_t_245, v_taken_240));
  if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
    heff_drop(v_x1_246);
    if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
      heff_drop(v_n_242);
      return v_x_241;
    } else {
      V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2efreeName_str1), heff_intShow(v_n_242));
      return heff_strAppend(v_x_241, v_t_247);
    }
  } else {
    heff_drop(v_x1_246);
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2efreeName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str3, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str7, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str11, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str15, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str17, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str18, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str19, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str21, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str22, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str23, 3, ".hf");
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args);
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_from_242)));
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0)))) {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_t_244);
    V v_base_245 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_246 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str2), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
    V v_parts_2411;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_parts_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_248 = heff_field(v_t_247, 0);
      V v_before_249 = heff_field(v_t_247, 1);
      V v_ru_24t_247_24Cons = heff_take_reuse_n(v_t_247, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_248, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str3)), v_before_249});
      v_parts_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2410));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2418 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_245), v_parts_2411));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2418, v_base_245, v_parts_2411, v_w_243}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_244);
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2419 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2420 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2421 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2420; V a_2 = v_project_2419; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2420); r_; });
      V v_t_2455;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str4))) {
        V v_base_2422 = heff_dup(heff_rfield(v_k_2421, 2));
        V v_xs_2423 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str6), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
        V v_parts_2428;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nil: {
          v_parts_2428 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2425 = heff_field(v_t_2424, 0);
          V v_before_2426 = heff_field(v_t_2424, 1);
          V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 3ULL, 2);
          V v_t_2427 = heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2425, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str7)), v_before_2426});
          v_parts_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2427));
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_t_2435 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam1, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2422), v_parts_2428));
        v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2435, v_base_2422, v_parts_2428, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_j_2436 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), v_w_243, MK_INT(0LL), 5);
        V v_t_2437;
        if (heff_intLt_c_lent(v_j_2436, MK_INT(0LL), 2)) {
          heff_drop(v_j_2436);
          v_t_2437 = heff_dup(v_w_243);
        } else {
          v_t_2437 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2436, 6);
        }
        if (heff_strEq_c(v_t_2437, heff_dup(heff_rfield(v_k_2421, 3)))) {
          V v_base_2438 = heff_dup(heff_rfield(v_k_2421, 2));
          V v_xs_2439 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2439));
          V v_parts_2444;
          switch (heff_tag_of(v_t_2440)) {
          case TAG_Nil: {
            v_parts_2444 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2441 = heff_field(v_t_2440, 0);
            V v_before_2442 = heff_field(v_t_2440, 1);
            V v_ru_24t_2440_24Cons = heff_take_reuse_n(v_t_2440, 3ULL, 2);
            V v_t_2443 = heff_tag_at_n(v_ru_24t_2440_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2441, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str11)), v_before_2442});
            v_parts_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2443));
            break;
          }
          default: heff_nomatch(v_t_2440);
          }
          V v_j_2445 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), v_w_243, MK_INT(0LL), 5);
          V v_t_2446;
          if (heff_intLt_c_lent(v_j_2445, MK_INT(0LL), 2)) {
            heff_drop(v_j_2445);
            v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13);
          } else {
            v_t_2446 = heff_strSlice(heff_dup(v_w_243), v_j_2445, heff_strLength_lent(v_w_243, 0));
          }
          V v_m_2447 = heff_strAppend(heff_dup(heff_rfield(v_k_2421, 4)), v_t_2446);
          V v_t_2454 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam2, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2438), v_parts_2444));
          v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2454, v_base_2438, v_parts_2444, v_m_2447}), NTAG(TAG_Nil)});
        } else {
          v_t_2455 = NTAG(TAG_Nil);
        }
      }
      V v_j_2456 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), v_w_243, MK_INT(0LL), 5);
      V v_t_2457;
      if (heff_intLt_c_lent(v_j_2456, MK_INT(0LL), 2)) {
        heff_drop(v_j_2456);
        v_t_2457 = heff_dup(v_w_243);
      } else {
        v_t_2457 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2456, 6);
      }
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str15), v_w_243, MK_INT(0LL), 5);
      V v_t_2459;
      if (heff_intLt_c_lent(v_j_2458, MK_INT(0LL), 2)) {
        heff_drop(v_j_2458);
        v_t_2459 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str16);
      } else {
        v_t_2459 = heff_strSlice(heff_dup(v_w_243), v_j_2458, heff_strLength_lent(v_w_243, 0));
      }
      V v_t_2460 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2421); V a_3 = v_t_2457; V a_4 = v_t_2459; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2457); r_; });
      V v_base_2461 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2462 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str17); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str18), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2462));
      V v_parts_2467;
      switch (heff_tag_of(v_t_2463)) {
      case TAG_Nil: {
        v_parts_2467 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2464 = heff_field(v_t_2463, 0);
        V v_before_2465 = heff_field(v_t_2463, 1);
        V v_ru_24t_2463_24Cons = heff_take_reuse_n(v_t_2463, 3ULL, 2);
        V v_t_2466 = heff_tag_at_n(v_ru_24t_2463_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2464, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str19)), v_before_2465});
        v_parts_2467 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2466));
        break;
      }
      default: heff_nomatch(v_t_2463);
      }
      V v_t_2474 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam3, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2461), v_parts_2467));
      V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2474, v_base_2461, v_parts_2467, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      V v_t_2491;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str20))) {
        V v_x1_2476 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_take_field(v_k_2421, 2), v_from_242));
        if (!(heff_dup(v_x1_2476) == NTAG(TAG_True))) {
          heff_drop(v_x1_2476);
          V v_base_2477 = heff_get_n(v_k_2421, 1, 7);
          V v_xs_2478 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str22), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2478));
          V v_parts_2483;
          switch (heff_tag_of(v_t_2479)) {
          case TAG_Nil: {
            v_parts_2483 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2480 = heff_field(v_t_2479, 0);
            V v_before_2481 = heff_field(v_t_2479, 1);
            V v_ru_24t_2479_24Cons = heff_take_reuse_n(v_t_2479, 3ULL, 2);
            V v_t_2482 = heff_tag_at_n(v_ru_24t_2479_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2480, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23)), v_before_2481});
            v_parts_2483 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2482));
            break;
          }
          default: heff_nomatch(v_t_2479);
          }
          V v_t_2490 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam4, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2477), v_parts_2483));
          v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2490, v_base_2477, v_parts_2483, v_w_243}), NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_w_243);
          heff_drop_rec(v_k_2421, 7);
          heff_drop(v_x1_2476);
          v_t_2491 = NTAG(TAG_Nil);
        }
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_from_242);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2421, 7);
        v_t_2491 = NTAG(TAG_Nil);
      }
      V v_t_2492 = (g_prelude_2e_2b_2b(v_t_2475, v_t_2491));
      V v_t_2493 = (g_prelude_2e_2b_2b(v_t_2460, v_t_2492));
      return (g_prelude_2e_2b_2b(v_t_2455, v_t_2493));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args) {
  V v_d_2412 = args[0];
  V v_p_2413 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2414 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2415 = (g_std_2epath_2eparse(v_st_2414, v_d_2412));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_2414, v_p_2413));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  return ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args) {
  V v_d_2429 = args[0];
  V v_p_2430 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2431 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2432 = (g_std_2epath_2eparse(v_st_2431, v_d_2429));
  V v_t_2433 = (g_std_2epath_2eparse(v_st_2431, v_p_2430));
  V v_t_2434 = (g_std_2epath_2ejoin(v_t_2432, v_t_2433));
  return ({ V a_0 = v_st_2431; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2431); heff_drop(v_t_2434); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args) {
  V v_d_2448 = args[0];
  V v_p_2449 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2450 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2451 = (g_std_2epath_2eparse(v_st_2450, v_d_2448));
  V v_t_2452 = (g_std_2epath_2eparse(v_st_2450, v_p_2449));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  return ({ V a_0 = v_st_2450; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2453); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args) {
  V v_d_2468 = args[0];
  V v_p_2469 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2470 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2471 = (g_std_2epath_2eparse(v_st_2470, v_d_2468));
  V v_t_2472 = (g_std_2epath_2eparse(v_st_2470, v_p_2469));
  V v_t_2473 = (g_std_2epath_2ejoin(v_t_2471, v_t_2472));
  return ({ V a_0 = v_st_2470; V a_1 = v_t_2473; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2470); heff_drop(v_t_2473); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args) {
  V v_d_2484 = args[0];
  V v_p_2485 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2486 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2487 = (g_std_2epath_2eparse(v_st_2486, v_d_2484));
  V v_t_2488 = (g_std_2epath_2eparse(v_st_2486, v_p_2485));
  V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
  return ({ V a_0 = v_st_2486; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2486); heff_drop(v_t_2489); r_; });
}
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str3, 0, "");
Clo g_heff_2ebuild_2eload_2esameButCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameButCase_entry, 2, 0};

V g_heff_2ebuild_2eload_2esameButCase(V v_a_240, V v_b_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24f201346761x152404242(MK_INT(65LL), v_a_240, MK_INT(90LL), MK_INT(32LL), MK_INT(1LL), MK_INT(0LL), heff_strLength_lent(v_a_240, 0)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_246 = (g_list_2emap_24f201346761x152404242(MK_INT(65LL), v_b_241, MK_INT(90LL), MK_INT(32LL), MK_INT(1LL), MK_INT(0LL), heff_strLength_lent(v_b_241, 0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_245, v_t_249, 0));
  heff_drop(v_t_245);
  heff_drop(v_t_249);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eload_2esameButCase(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0, 59, " on the disk: a file system that tells case apart finds no ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1, 10, " is named ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4, 7, " holds ");
HEFF_LIT(g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5, 74, ": names that differ only in case are one file where case is not told apart");

HeffT2 g_heff_2ebuild_2eload_2ecasesIn_24cpr(V v_ps_240, V v_d_241, V v_x_242, V v_ns_243) {
top: ;
  switch (heff_tag_of(v_ns_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_d_241);
    heff_drop(v_x_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_ns2_245 = heff_dup(heff_field(v_ns_243, 1));
    switch (heff_tag_of(v_ns2_245)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Cons: {
        V v_n_246 = heff_field(v_ns_243, 0);
        heff_take_n(v_ns_243, 1ULL, 2);
        if (heff_strEq_c_lent(v_n_246, v_x_242, 0)) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_d_241);
          heff_drop(v_x_242);
          heff_drop(v_n_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          V v_st_248 = heff_get_n(v_ps_240, 5, 6);
          V v_t_249 = (g_std_2epath_2eparse(v_st_248, v_d_241));
          V v_t_2410 = (g_std_2epath_2eparse(v_st_248, heff_dup(v_x_242)));
          V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
          V v_t_2412 = ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
          V v_t_2413 = heff_strAppend(v_n_246, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str0), v_x_242));
          V v_f_2414 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str1), v_t_2413));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ns_243)}});
      }
    }
    case TAG_Cons: {
      heff_take_n(v_ns2_245, 0ULL, 2);
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_x_242);
      V v_t_2419;
      switch (heff_tag_of(v_ns_243)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_ns_243, 0);
        V v_xs_2418 = heff_field(v_ns_243, 1);
        heff_take_n(v_ns_243, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str3); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_ns_243);
      }
      V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str4), heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2eload_2ecasesIn_24cpr_str5)));
      V v_f_2421 = heff_strAppend(v_d_241, v_t_2420);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ns2_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ns_243)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2epackageRead_str1, 10, "package.hf");
Clo g_heff_2ebuild_2eload_2epackageRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epackageRead_entry, 4, 0};

V g_heff_2ebuild_2eload_2epackageRead(V v_h_240, V v_ps_241, V v_src_242, V v_x4_243) {
top: ;
  V v_style_244 = heff_take_field(v_ps_241, 5);
  V v_root_245 = heff_get_n(v_ps_241, 0, 6);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Left: {
    V v_p_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Left = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_h_240);
    V v_st_247 = v_style_244;
    V v_t_248 = (g_std_2epath_2eparse(v_st_247, v_root_245));
    V v_t_249 = (g_std_2epath_2eparse(v_st_247, ((V)&g_heff_2ebuild_2eload_2epackageRead_str0)));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_t_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2411, v_src_242, v_p_246));
    return heff_tag_at_n(v_ru_24x4_243_24Left, TAG_Left, 1, (V[]){v_t_2412});
  }
  case TAG_Right: {
    V v_pk_2413 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Right = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2413, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      V v_x1_2414 = (g_heff_2ebuild_2eload_2eheffAt(v_h_240, heff_dup(v_root_245)));
      if (!(heff_dup(v_x1_2414) == NTAG(TAG_True))) {
        heff_drop_rec(v_pk_2413, 4);
        heff_drop_cell(v_ru_24x4_243_24Right, 1);
        heff_drop(v_x1_2414);
        V v_st_2415 = v_style_244;
        V v_t_2416 = (g_std_2epath_2eparse(v_st_2415, v_root_245));
        V v_t_2417 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2eload_2epackageRead_str1)));
        V v_t_2418 = (g_std_2epath_2ejoin(v_t_2416, v_t_2417));
        V v_t_2419 = ({ V a_0 = v_st_2415; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2418); r_; });
        V v_t_2420 = (g_heff_2ebuild_2eproject_2epackageLit(v_src_242));
        V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2ebuild_2eproject_2eclaimOf(a_0)); heff_drop(v_t_2420); r_; });
        V v_t_2422 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2419, v_src_242, v_t_2421));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2422});
      } else {
        heff_drop(v_style_244);
        heff_drop(v_root_245);
        heff_drop(v_x1_2414);
        return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_2413});
      }
    } else {
      heff_drop(v_h_240);
      heff_drop(v_style_244);
      heff_drop(v_root_245);
      return heff_tag_at_n(v_ru_24x4_243_24Right, TAG_Right, 1, (V[]){v_pk_2413});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2eload_2epackageRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2epackageRead(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_done_244 = heff_take_field(v_st_243, 0);
  V v_errors_245 = heff_get_n(v_st_243, 2, 3);
  V v_t_249;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_246 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_why_247 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_247, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_246, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_246);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_field(v_pkgs_242, 1);
    v_t_2412 = heff_dup(v_y_2411);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_errors_245));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2418;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2415 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      heff_take_n(v_x11_2415, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2417 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2417});
      break;
    }
    default: heff_nomatch(v_x11_2415);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2421;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_pkgs_242, 0);
    v_t_2421 = heff_dup(v_x_2419);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_done_244, v_t_2414, v_ps_240, v_t_2418, v_t_2421});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry, 2, 0};

V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V v_h_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_243 = (g_std_2epath_2eparse_24cpr(v_st_242, heff_dup(v_file_241)));
  V v_t_2413;
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_d_247 = v_field_244;
    V v_a_248 = v_field_245;
    V v_xs_249 = v_field_246;
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_xs_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2410; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
    v_t_2413 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_247, v_a_248, v_t_2412});
  }
  V v_t_2414 = ({ V a_0 = v_st_242; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_2413); r_; });
  V v_st_2415 = heff_dup(heff_rfield(v_h_240, 3));
  HeffT3 v_t_2416 = (g_std_2epath_2eparse_24cpr(v_st_2415, v_file_241));
  V v_t_2426;
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2418 = v_t_2416.f[1];
    V v_field_2419 = v_t_2416.f[2];
    V v_d_2420 = v_field_2417;
    V v_a_2421 = v_field_2418;
    V v_xs_2422 = v_field_2419;
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2422));
    V v_xs_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2423; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    v_t_2426 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2420, v_a_2421, v_t_2425});
  }
  V v_t_2427 = ({ V a_0 = v_st_2415; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2426); r_; });
  return (g_heff_2ebuild_2eload_2erootFrom_24s1152493850x1950659619(v_h_240, v_t_2414, v_t_2427));
}
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0, 3, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(V v_h_240, V v_ps_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_t_243 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_ps_241, 0))));
  V v_t_244 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_str0)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_s_246 = ({ V a_0 = v_st_242; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_245); r_; });
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_246; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_path_247; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_247); r_; });
  V v_c_2412 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1, 2, 3, (V[]){v_c_2412, v_h_240, v_ps_241});
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    heff_take_n(v_x_2415, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop_rec(v_ps_241, 6);
    V f_ = v_k_2414;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    HeffT2 v_t_2418 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2417));
    V v_t_2423;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_p_2421 = v_field_2420;
        v_t_2423 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Left, 1, (V[]){v_p_2421});
      } else {
        heff_drop_cell(v_ru_24x_2415_24Right, 1);
        V v_x_2422 = v_field_2420;
        v_t_2423 = (g_heff_2ebuild_2eproject_2epackageOf(v_x_2422));
      }
    }
    V v_t_2424 = ({ V a_0 = v_h_240; V a_1 = v_ps_241; V a_2 = v_y_2417; V a_3 = v_t_2423; V r_ = (g_heff_2ebuild_2eload_2epackageRead(a_0, a_1, a_2, a_3)); heff_drop(v_y_2417); r_; });
    V v_x_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2424});
    V f_ = v_k_2414;
    args[0] = v_x_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702_lam2, 1, 3, (V[]){v_k_2414, v_h_240, v_ps_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str0, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str3, 8, "heff.sum");
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0, 3, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(v_st_243, heff_dup(v_root_242)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_243, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_path_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_247; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_249 = ({ V a_0 = v_path_248; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_248); r_; });
  V v_c_2413 = heff_tr(heff_call(v_c_249, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1, 2, 3, (V[]){v_c_2413, v_style_241, v_root_242});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(a[0]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_style_241 = heff_env(self)[1];
  V v_root_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 0ULL, 1);
    heff_drop(v_style_241);
    heff_drop(v_root_242);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    V f_ = v_k_2415;
    args[0] = v_t_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2419 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str1); V a_1 = v_y_2419; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str2), v_y_2419, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT2 v_t_2421 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(MK_INT(0LL), v_t_2420));
    V v_x_2432;
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2416_24Right, 1);
        V v_p_2424 = v_field_2423;
        V v_st_2425 = v_style_241;
        V v_t_2426 = (g_std_2epath_2eparse(v_st_2425, v_root_242));
        V v_t_2427 = (g_std_2epath_2eparse(v_st_2425, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str3)));
        V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
        V v_t_2429 = ({ V a_0 = v_st_2425; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); heff_drop(v_t_2428); r_; });
        V v_t_2430 = ({ V a_0 = v_t_2429; V a_1 = v_y_2419; V a_2 = v_p_2424; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2419); r_; });
        v_x_2432 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2430});
      } else {
        heff_drop(v_style_241);
        heff_drop(v_root_242);
        heff_drop(v_y_2419);
        V v_sums_2431 = v_field_2423;
        v_x_2432 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Right, 1, (V[]){v_sums_2431});
      }
    }
    V f_ = v_k_2415;
    args[0] = v_x_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_style_241 = heff_env(self)[1];
  V v_root_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam2, 1, 3, (V[]){v_k_2415, v_style_241, v_root_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry, 7, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(V v_lit_240, V v_lit_241, V v_lit_242, V v_root_243, V v_x3_244, V v_seen_245, V v_errs_246) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam0, 2, 2, (V[]){v_seen_245, v_errs_246});
  }
  case TAG_Cons: {
    V v_n_249 = heff_field(v_x3_244, 0);
    V v_rest_2410 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    V v_path_2411 = heff_take_field(v_n_249, 1);
    V v_version_2412 = heff_take_field(v_n_249, 2);
    V v_by_2413 = heff_get_n(v_n_249, 0, 3);
    if (heff_strEq_c_lent(v_path_2411, v_root_243, 0)) {
      heff_drop(v_path_2411);
      heff_drop(v_version_2412);
      heff_drop(v_by_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_root_243;
      V t_4 = v_rest_2410;
      V t_5 = v_seen_245;
      V t_6 = v_errs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_root_243 = t_3;
      v_x3_244 = t_4;
      v_seen_245 = t_5;
      v_errs_246 = t_6;
      goto top;
    } else {
      V v_t_2414 = (g_list_2eany_24s241416889x826324235(v_path_2411, v_version_2412, v_seen_245));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_path_2411);
        heff_drop(v_version_2412);
        heff_drop(v_by_2413);
        heff_drop(v_t_2414);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_root_243;
        V t_4 = v_rest_2410;
        V t_5 = v_seen_245;
        V t_6 = v_errs_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_root_243 = t_3;
        v_x3_244 = t_4;
        v_seen_245 = t_5;
        v_errs_246 = t_6;
        goto top;
      } else {
        heff_drop(v_t_2414);
        V v_c_2415 = (g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_by_2413, heff_dup(v_path_2411), heff_dup(v_version_2412)));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam1, 2, 10, (V[]){v_c_2415, v_path_2411, v_version_2412, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, heff_dup(v_root_243), v_rest_2410});
      }
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_seen_245 = heff_env(self)[0];
  V v_errs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_245, v_errs_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_path_2411 = heff_env(self)[0];
  V v_version_2412 = heff_env(self)[1];
  V v_seen_245 = heff_env(self)[2];
  V v_errs_246 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_root_243 = heff_env(self)[7];
  V v_rest_2410 = heff_env(self)[8];
  V v_hd_2416 = heff_env(self)[9];
  V v_k_2417 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2411, v_version_2412, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2421));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(v_errs_246, v_t_2423));
    V v_t_2425 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_rest_2410; V a_5 = v_t_2422; V a_6 = v_t_2424; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2425;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2426 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_t_2427 = heff_strAppend(heff_dup(v_path_2411), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_str0), heff_dup(v_version_2412)));
    V v_t_2428 = (g_list_2emap_24s675147852x248982264(v_t_2427, heff_dup(heff_rfield(v_pk_2426, 2))));
    V v_t_2429 = (g_prelude_2e_2b_2b(v_rest_2410, v_t_2428));
    V v_t_2430 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2411, v_version_2412, heff_tag_n(TAG_Just, 1, (V[]){v_pk_2426})});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
    V v_t_2432 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2431));
    V v_t_2433 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_t_2429; V a_5 = v_t_2432; V a_6 = v_errs_246; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2433;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_path_2411 = heff_env(self)[1];
  V v_version_2412 = heff_env(self)[2];
  V v_seen_245 = heff_env(self)[3];
  V v_errs_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_root_243 = heff_env(self)[8];
  V v_rest_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam2, 1, 11, (V[]){v_path_2411, v_version_2412, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, v_root_243, v_rest_2410, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(V v_lit_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_c_2413 = (g_heff_2ebuild_2eload_2ereadEvery_24s1647993723x1864478745(v_t_2412));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam1, 2, 10, (V[]){v_c_2413, v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam4(V self, V *args) {
  V v_x_2471 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_module_2431 = heff_env(self)[1];
  V v_named_2435 = heff_env(self)[2];
  V v_path_2433 = heff_env(self)[3];
  V v_source_2434 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_w_2410 = heff_env(self)[6];
  V v_rs_247 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_stack_243 = heff_env(self)[9];
  V v_from_244 = heff_env(self)[10];
  V v_rest_2411 = heff_env(self)[11];
  V v_hd_2414 = heff_env(self)[12];
  V v_k_2415 = heff_env(self)[13];
  heff_clo_take(self, 14);
  V v_t_2474;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_dup(heff_field(v_x_2471, 0));
    v_t_2474 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2477;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_MkPair: {
    V v_y_2476 = heff_field(v_x_2471, 1);
    heff_take_n(v_x_2471, 2ULL, 2);
    v_t_2477 = v_y_2476;
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2478 = (g_heff_2ebuild_2eload_2epushDone(v_t_2474, heff_dup(v_ps_241), heff_dup(v_module_2431), v_named_2435, v_path_2433, v_source_2434, heff_dup(v_lit_240), v_t_2477));
  V v_m_2479 = v_module_2431;
  V v_t_2480;
  if (heff_strEq_c_lent(v_w_2410, v_m_2479, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2479);
    v_t_2480 = v_rs_247;
  } else {
    v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2479}), v_rs_247});
  }
  V v_t_2481 = (g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2478, v_t_2480));
  V f_ = v_t_2481;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_source_2434 = heff_env(self)[1];
  V v_st_246 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_from_244 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_pkgs_242 = heff_env(self)[6];
  V v_module_2431 = heff_env(self)[7];
  V v_stack_243 = heff_env(self)[8];
  V v_path_2433 = heff_env(self)[9];
  V v_hd_2414 = heff_env(self)[10];
  V v_named_2435 = heff_env(self)[11];
  V v_rs_247 = heff_env(self)[12];
  V v_rest_2411 = heff_env(self)[13];
  V v_k_2415 = heff_env(self)[14];
  heff_clo_take(self, 15);
  V v_t_2460 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(v_source_2434)));
  V v_imps_2461 = heff_get_n(v_t_2460, 0, 4);
  V v_t_2462 = (g_list_2emap_24s1817208647x1282894070(v_imps_2461));
  V v_t_2463 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2462));
  V v_t_2469;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2469 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2464 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    V v_t_2465 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str9), v_why_2464));
    V v_t_2466 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str10), v_t_2465));
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
    V v_t_2468 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2467));
    v_t_2469 = ({ V rv_2 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2470 = (g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(heff_dup(v_lit_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2431), heff_dup(v_stack_243)}), heff_dup(v_path_2433), v_t_2463, v_t_2469, NTAG(TAG_Nil)));
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_hd_2414);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam4, 1, 14, (V[]){v_ps_241, v_module_2431, v_named_2435, v_path_2433, v_source_2434, v_lit_240, v_w_2410, v_rs_247, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nil: {
    V v_places_2417 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_x2_2418 = (g_list_2emap_24s435407392x1528135477(v_places_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str1); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str2), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str3)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str4), heff_strAppend(v_w_2410, v_t_2422));
    V v_e_2424 = heff_strAppend(heff_dup(v_from_244), v_t_2423);
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2424, NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2425));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2428 = (g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2427, v_rs_247));
    V f_ = v_t_2428;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2429 = heff_dup(heff_field(v_x_2416, 0));
    V v_others_2430 = heff_dup(heff_field(v_x_2416, 1));
    V v_module_2431 = heff_take_field(v_f_2429, 3);
    V v_place_2432 = heff_take_field(v_f_2429, 2);
    V v_path_2433 = heff_take_field(v_f_2429, 0);
    V v_source_2434 = heff_take_field(v_f_2429, 1);
    V v_named_2435 = heff_get_n(v_f_2429, 4, 5);
    V v_t_2436 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2431)}));
    V v_t_2437 = (g_list_2eany(v_t_2436, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2416, 2);
      heff_drop(v_others_2430);
      heff_drop_rec(v_place_2432, 4);
      heff_drop(v_path_2433);
      heff_drop(v_source_2434);
      heff_drop(v_named_2435);
      heff_drop(v_t_2437);
      V v_m_2438 = v_module_2431;
      V v_t_2439;
      if (heff_strEq_c_lent(v_w_2410, v_m_2438, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2438);
        v_t_2439 = v_rs_247;
      } else {
        v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2438}), v_rs_247});
      }
      V v_t_2440 = (g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_st_246, v_t_2439));
      V f_ = v_t_2440;
      heff_room[0] = v_hd_2414;
      heff_room[1] = v_k_2415;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2437);
      V v_t_2441 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2431)}));
      V v_t_2442 = (g_list_2eany(v_t_2441, v_stack_243));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2416, 2);
        heff_drop(v_others_2430);
        heff_drop_rec(v_place_2432, 4);
        heff_drop(v_path_2433);
        heff_drop(v_source_2434);
        heff_drop(v_named_2435);
        heff_drop(v_t_2442);
        V v_m_2443 = heff_dup(v_module_2431);
        V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2443), NTAG(TAG_Nil)});
        V v_x2_2446 = (g_prelude_2e_2b_2b(v_t_2444, v_t_2445));
        V v_t_2449;
        switch (heff_tag_of(v_x2_2446)) {
        case TAG_Nil: {
          v_t_2449 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2447 = heff_field(v_x2_2446, 0);
          V v_xs_2448 = heff_field(v_x2_2446, 1);
          heff_take_n(v_x2_2446, 3ULL, 2);
          v_t_2449 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str6); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2446);
        }
        V v_t_2450 = heff_strAppend(v_m_2443, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str7), v_t_2449));
        V v_e_2451 = heff_strAppend(heff_dup(v_from_244), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_str8), v_t_2450));
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2451, NTAG(TAG_Nil)});
        V v_t_2453 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2452));
        V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2455 = v_module_2431;
        V v_t_2456;
        if (heff_strEq_c_lent(v_w_2410, v_m_2455, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2455);
          v_t_2456 = v_rs_247;
        } else {
          v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2455}), v_rs_247});
        }
        V v_t_2457 = (g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2454, v_t_2456));
        V f_ = v_t_2457;
        heff_room[0] = v_hd_2414;
        heff_room[1] = v_k_2415;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2442);
        switch (heff_tag_of(v_others_2430)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2416, 2);
          V v_c_2458 = ({ V a_0 = heff_dup(v_ps_241); V a_1 = heff_take_field(v_place_2432, 1); V b_2 = heff_get_n(v_place_2432, 2, 4); V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          V f_ = v_c_2458;
          heff_room[0] = heff_dup(v_hd_2414);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam3, 1, 15, (V[]){v_lit_240, v_source_2434, v_st_246, v_w_2410, v_from_244, v_ps_241, v_pkgs_242, v_module_2431, v_stack_243, v_path_2433, v_hd_2414, v_named_2435, v_rs_247, v_rest_2411, v_k_2415});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2430_24Cons = heff_take_reuse_n(v_others_2430, 0ULL, 2);
          heff_drop_rec(v_place_2432, 4);
          heff_drop(v_path_2433);
          heff_drop(v_source_2434);
          heff_drop(v_named_2435);
          V v_e_2484 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2416, heff_dup(v_from_244), heff_dup(v_w_2410)));
          V v_t_2485 = heff_tag_at_n(v_ru_24others_2430_24Cons, TAG_Cons, 2, (V[]){v_e_2484, NTAG(TAG_Nil)});
          V v_t_2486 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2485));
          V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2431), heff_take_field(v_st_246, 1)});
          V v_t_2488 = ({ V rv_1 = v_t_2487; V rv_2 = v_t_2486; V rr_ = heff_rec_reuse_nf(v_st_246, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2489 = v_module_2431;
          V v_t_2490;
          if (heff_strEq_c_lent(v_w_2410, v_m_2489, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2489);
            v_t_2490 = v_rs_247;
          } else {
            v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2489}), v_rs_247});
          }
          V v_t_2491 = (g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2488, v_t_2490));
          V f_ = v_t_2491;
          heff_room[0] = v_hd_2414;
          heff_room[1] = v_k_2415;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2430);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677_lam2, 1, 11, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_entry, 6, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422(V v_ps_240, V v_pkgs_241, V v_from_242, V v_before_243, V v_x6_244, V v_st_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_before_243);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam0, 2, 1, (V[]){v_st_245});
  }
  case TAG_Cons: {
    V v_m_248 = heff_field(v_x6_244, 0);
    V v_ms_249 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_248), NTAG(TAG_Nil)});
    V v_c_2411 = (g_heff_2ebuild_2eload_2eloadMany_24s1825461361x345325677(heff_dup(v_before_243), heff_dup(v_ps_240), heff_dup(v_pkgs_241), NTAG(TAG_Nil), heff_dup(v_from_242), v_t_2410, v_st_245, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam1, 2, 7, (V[]){v_c_2411, v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_before_243 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_pkgs_241 = heff_env(self)[3];
  V v_from_242 = heff_env(self)[4];
  V v_ms_249 = heff_env(self)[5];
  V v_hd_2412 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_248, NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_before_243, v_t_2415));
  V v_t_2419;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 2);
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2420 = (g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422(v_ps_240, v_pkgs_241, v_from_242, v_t_2416, v_ms_249, v_t_2419));
  V f_ = v_t_2420;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_m_248 = heff_env(self)[1];
  V v_before_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_pkgs_241 = heff_env(self)[4];
  V v_from_242 = heff_env(self)[5];
  V v_ms_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s552997916x668556422_lam2, 1, 8, (V[]){v_m_248, v_before_243, v_ps_240, v_pkgs_241, v_from_242, v_ms_249, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str2, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str4, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str7, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str8, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str10, 12, ": importing ");
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_imp_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_stack_242);
    heff_drop(v_from_243);
    heff_drop(v_imp_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_c_2413 = (g_heff_2ebuild_2eload_2ereadEvery_24s1647993723x1864478745(v_t_2412));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam1, 2, 10, (V[]){v_c_2413, v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_module_2431 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_named_2435 = heff_env(self)[3];
  V v_path_2433 = heff_env(self)[4];
  V v_source_2434 = heff_env(self)[5];
  V v_w_2410 = heff_env(self)[6];
  V v_rs_247 = heff_env(self)[7];
  V v_pkgs_241 = heff_env(self)[8];
  V v_stack_242 = heff_env(self)[9];
  V v_from_243 = heff_env(self)[10];
  V v_rest_2411 = heff_env(self)[11];
  V v_hd_2414 = heff_env(self)[12];
  V v_k_2415 = heff_env(self)[13];
  heff_clo_take(self, 14);
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2476 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(v_module_2431)}));
  V v_t_2479;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2478 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2479 = v_y_2478;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2480 = (g_heff_2ebuild_2eload_2epushDone(v_t_2475, heff_dup(v_ps_240), heff_dup(v_module_2431), v_named_2435, v_path_2433, v_source_2434, v_t_2476, v_t_2479));
  V v_m_2481 = v_module_2431;
  V v_t_2482;
  if (heff_strEq_c_lent(v_w_2410, v_m_2481, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2481);
    v_t_2482 = v_rs_247;
  } else {
    v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2481}), v_rs_247});
  }
  V v_t_2483 = (g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2480, v_t_2482));
  V f_ = v_t_2483;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_module_2431 = heff_env(self)[1];
  V v_source_2434 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  V v_pkgs_241 = heff_env(self)[7];
  V v_stack_242 = heff_env(self)[8];
  V v_path_2433 = heff_env(self)[9];
  V v_hd_2414 = heff_env(self)[10];
  V v_named_2435 = heff_env(self)[11];
  V v_rs_247 = heff_env(self)[12];
  V v_rest_2411 = heff_env(self)[13];
  V v_k_2415 = heff_env(self)[14];
  heff_clo_take(self, 15);
  V v_t_2460 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(v_module_2431)}));
  V v_t_2461 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2460, heff_dup(v_source_2434)));
  V v_imps_2462 = heff_get_n(v_t_2461, 0, 4);
  V v_t_2463 = (g_list_2emap_24s1817208647x1282894070(v_imps_2462));
  V v_t_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
  V v_t_2470;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2470 = v_st_246;
    break;
  }
  case TAG_Just: {
    V v_why_2465 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    V v_t_2466 = heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str9), v_why_2465));
    V v_t_2467 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str10), v_t_2466));
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2468));
    v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2471 = (g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2431), heff_dup(v_stack_242)}), heff_dup(v_path_2433), heff_dup(v_imp_244), v_t_2464, v_t_2470, NTAG(TAG_Nil)));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_2414);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam4, 1, 14, (V[]){v_imp_244, v_module_2431, v_ps_240, v_named_2435, v_path_2433, v_source_2434, v_w_2410, v_rs_247, v_pkgs_241, v_stack_242, v_from_243, v_rest_2411, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_pkgs_241 = heff_env(self)[1];
  V v_from_243 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_imp_244 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nil: {
    V v_places_2417 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_x2_2418 = (g_list_2emap_24s435407392x1528135477(v_places_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str1); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str2), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str3)));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str4), heff_strAppend(v_w_2410, v_t_2422));
    V v_e_2424 = heff_strAppend(heff_dup(v_from_243), v_t_2423);
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2424, NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2425));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2428 = (g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2427, v_rs_247));
    V f_ = v_t_2428;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2429 = heff_dup(heff_field(v_x_2416, 0));
    V v_others_2430 = heff_dup(heff_field(v_x_2416, 1));
    V v_module_2431 = heff_take_field(v_f_2429, 3);
    V v_place_2432 = heff_take_field(v_f_2429, 2);
    V v_path_2433 = heff_take_field(v_f_2429, 0);
    V v_source_2434 = heff_take_field(v_f_2429, 1);
    V v_named_2435 = heff_get_n(v_f_2429, 4, 5);
    V v_t_2436 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2431)}));
    V v_t_2437 = (g_list_2eany(v_t_2436, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2416, 2);
      heff_drop(v_others_2430);
      heff_drop_rec(v_place_2432, 4);
      heff_drop(v_path_2433);
      heff_drop(v_source_2434);
      heff_drop(v_named_2435);
      heff_drop(v_t_2437);
      V v_m_2438 = v_module_2431;
      V v_t_2439;
      if (heff_strEq_c_lent(v_w_2410, v_m_2438, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2438);
        v_t_2439 = v_rs_247;
      } else {
        v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2438}), v_rs_247});
      }
      V v_t_2440 = (g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_st_246, v_t_2439));
      V f_ = v_t_2440;
      heff_room[0] = v_hd_2414;
      heff_room[1] = v_k_2415;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2437);
      V v_t_2441 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2431)}));
      V v_t_2442 = (g_list_2eany(v_t_2441, v_stack_242));
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2416, 2);
        heff_drop(v_others_2430);
        heff_drop_rec(v_place_2432, 4);
        heff_drop(v_path_2433);
        heff_drop(v_source_2434);
        heff_drop(v_named_2435);
        heff_drop(v_t_2442);
        V v_m_2443 = heff_dup(v_module_2431);
        V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_242)));
        V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2443), NTAG(TAG_Nil)});
        V v_x2_2446 = (g_prelude_2e_2b_2b(v_t_2444, v_t_2445));
        V v_t_2449;
        switch (heff_tag_of(v_x2_2446)) {
        case TAG_Nil: {
          v_t_2449 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2447 = heff_field(v_x2_2446, 0);
          V v_xs_2448 = heff_field(v_x2_2446, 1);
          heff_take_n(v_x2_2446, 3ULL, 2);
          v_t_2449 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str6); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2446);
        }
        V v_t_2450 = heff_strAppend(v_m_2443, heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str7), v_t_2449));
        V v_e_2451 = heff_strAppend(heff_dup(v_from_243), heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_str8), v_t_2450));
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2451, NTAG(TAG_Nil)});
        V v_t_2453 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2452));
        V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2455 = v_module_2431;
        V v_t_2456;
        if (heff_strEq_c_lent(v_w_2410, v_m_2455, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2455);
          v_t_2456 = v_rs_247;
        } else {
          v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2455}), v_rs_247});
        }
        V v_t_2457 = (g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2454, v_t_2456));
        V f_ = v_t_2457;
        heff_room[0] = v_hd_2414;
        heff_room[1] = v_k_2415;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2442);
        switch (heff_tag_of(v_others_2430)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2416, 2);
          V v_c_2458 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = heff_take_field(v_place_2432, 1); V b_2 = heff_get_n(v_place_2432, 2, 4); V r_ = (g_heff_2ebuild_2eload_2epartsNamed_24s986374973x798287971(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          V f_ = v_c_2458;
          heff_room[0] = heff_dup(v_hd_2414);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam3, 1, 15, (V[]){v_imp_244, v_module_2431, v_source_2434, v_st_246, v_w_2410, v_from_243, v_ps_240, v_pkgs_241, v_stack_242, v_path_2433, v_hd_2414, v_named_2435, v_rs_247, v_rest_2411, v_k_2415});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2430_24Cons = heff_take_reuse_n(v_others_2430, 0ULL, 2);
          heff_drop_rec(v_place_2432, 4);
          heff_drop(v_path_2433);
          heff_drop(v_source_2434);
          heff_drop(v_named_2435);
          V v_e_2486 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_240), v_x_2416, heff_dup(v_from_243), heff_dup(v_w_2410)));
          V v_t_2487 = heff_tag_at_n(v_ru_24others_2430_24Cons, TAG_Cons, 2, (V[]){v_e_2486, NTAG(TAG_Nil)});
          V v_t_2488 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2487));
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2431), heff_take_field(v_st_246, 1)});
          V v_t_2490 = ({ V rv_1 = v_t_2489; V rv_2 = v_t_2488; V rr_ = heff_rec_reuse_nf(v_st_246, 1ULL, 3, shape_done__doneMods__errors, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_m_2491 = v_module_2431;
          V v_t_2492;
          if (heff_strEq_c_lent(v_w_2410, v_m_2491, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2491);
            v_t_2492 = v_rs_247;
          } else {
            v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2491}), v_rs_247});
          }
          V v_t_2493 = (g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2490, v_t_2492));
          V f_ = v_t_2493;
          heff_room[0] = v_hd_2414;
          heff_room[1] = v_k_2415;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2430);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_pkgs_241 = heff_env(self)[2];
  V v_from_243 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_stack_242 = heff_env(self)[6];
  V v_imp_244 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s853819491x1103338109_lam2, 1, 11, (V[]){v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_str0, 10, "package.hf");
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam0, 3, 0};
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_entry, 2, 0};

V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163(V v_st_240, V v_d_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, v_d_241));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_str0)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_s_245 = ({ V a_0 = v_st_240; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_path_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_245; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_247 = ({ V a_0 = v_path_246; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_246); r_; });
  V v_c_2411 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam1, 2, 1, (V[]){v_c_2411});
}
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_lam2, 1, 1, (V[]){v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(heff_rfield(v_pl_244, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_244, 4);
    v_x_2422 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_dup(heff_rfield(v_pl_244, 2));
    V v_p_2416;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      v_p_2416 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_t_2413, 0);
      V v_xs_2415 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 3ULL, 2);
      v_p_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
    V v_t_2418 = heff_strSlice(heff_dup(v_p_2416), heff_box_word(v_t_2417), heff_strLength_lent(v_p_2416, 0));
    V v_t_2420;
    if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str2))) {
      int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
      v_t_2420 = heff_strSlice(v_p_2416, MK_INT(0LL), heff_box_word(v_t_2419));
    } else {
      v_t_2420 = v_p_2416;
    }
    V v_t_2421 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_244, 0)), v_s_2412, heff_dup(v_pl_244), heff_get_n(v_pl_244, 3, 4), v_t_2420});
    v_x_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(v_read_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_entry, 7, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam0, 2, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(heff_dup(v_before_244), heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam1, 2, 8, (V[]){v_c_2412, v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_hd_2413 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_before_244, v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2421 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2417, v_ms_2410, v_t_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  V v_before_244 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_ms_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam2, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_str0, 12, "cannot read ");
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam6(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam7(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam5(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry, 3, 0};

V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V v_read_240, V v_h_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(heff_dup(v_h_241), heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam0, 2, 4, (V[]){v_c_243, v_h_241, v_read_240, v_file_242});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam6(V self, V *args) {
  V v_m_2443 = args[0];
  V v_made_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2444 = ({ V a_0 = v_m_2443; V a_1 = v_made_2427; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2443); r_; });
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_s_2447 = v_field_2446;
      return heff_get_n(v_s_2447, 6, 8);
    } else {
      heff_drop(v_field_2446);
      return heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_made_2427 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2452;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_dup(heff_field(v_x_2449, 0));
    v_t_2452 = v_x_2450;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V v_t_2453 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2454 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_m_2455 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2456 = ({ V a_0 = v_m_2455; V a_1 = v_made_2427; HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2455); r_; });
  V v_t_2460;
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      V v_s_2459 = v_field_2458;
      v_t_2460 = heff_get_n(v_s_2459, 6, 8);
    } else {
      heff_drop(v_field_2458);
      v_t_2460 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2463;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_MkPair: {
    V v_y_2462 = heff_field(v_x_2449, 1);
    heff_take_n(v_x_2449, 2ULL, 2);
    v_t_2463 = v_y_2462;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V v_t_2464 = (g_heff_2ebuild_2eload_2epushDone(v_t_2452, heff_dup(v_x_246), v_t_2453, v_t_2454, v_file_242, v_src_2421, v_t_2460, v_t_2463));
  V v_x_2465 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2464; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_src_2421 = heff_env(self)[3];
  V v_read_240 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_made_2427 = heff_get_n(v_x_2426, 0, 3);
  V v_t_2430;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_x_2414, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2431 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  V v_m_2433 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_246), heff_dup(v_file_242)));
  HeffT2 v_t_2434 = ({ V a_0 = v_m_2433; V a_1 = heff_dup(v_made_2427); HeffT2 r_ = (g_list_2efind_24s1218501002x1291750665_24cpr(a_0, a_1)); heff_drop(v_m_2433); r_; });
  V v_t_2438;
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      V v_s_2437 = v_field_2436;
      v_t_2438 = heff_get_n(v_s_2437, 6, 8);
    } else {
      heff_drop(v_field_2436);
      v_t_2438 = heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get());
    }
  }
  V v_t_2439 = (g_heff_2esyntax_2eimport_2eimportsOf(v_t_2438, heff_dup(v_src_2421)));
  V v_imps_2440 = heff_get_n(v_t_2439, 0, 4);
  V v_t_2441 = (g_list_2emap_24s1817208647x1282894070(v_imps_2440));
  V v_t_2442 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2441));
  V v_c_2448 = (g_heff_2ebuild_2eload_2eloadMany_24s397553972x81492228(v_read_240, heff_dup(v_x_246), v_t_2430, v_t_2432, heff_dup(v_file_242), heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam6, 1, 1, (V[]){heff_dup(v_made_2427)}), v_t_2442, heff_dup(g_heff_2ebuild_2eload_2eemptySt_get()), NTAG(TAG_Nil)));
  V f_ = v_c_2448;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam7, 1, 7, (V[]){v_x_246, v_file_242, v_made_2427, v_src_2421, v_x_248, v_x_2414, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_read_240 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_read_240);
    heff_drop(v_hd_244);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_str0), v_file_242), NTAG(TAG_Nil)});
    V v_t_2418 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_t_2417));
    V v_t_2419 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418});
    V v_x_2420 = ({ V a_0 = v_x_246; V a_1 = v_x_248; V a_2 = v_x_2414; V a_3 = v_t_2419; V r_ = (g_heff_2ebuild_2eload_2eloadDone(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); r_; });
    V f_ = v_k_245;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_src_2421 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_dup(heff_field(v_x_2414, 0));
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_c_2425 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(heff_dup(v_read_240), heff_dup(v_x_246), v_t_2424, heff_dup(v_file_242), NTAG(TAG_Nil), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get()), heff_dup(g_heff_2ebuild_2eload_2eemptySt_get())));
    V f_ = v_c_2425;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam5, 1, 8, (V[]){v_x_2414, v_x_246, v_file_242, v_src_2421, v_read_240, v_hd_244, v_x_248, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(v_file_242)}));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam4, 1, 7, (V[]){v_file_242, v_x_246, v_x_248, v_x_2414, v_k_245, v_read_240, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412;
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_249 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      heff_take_n(v_x11_249, 0ULL, 1);
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Just, 1, (V[]){v_p_2411});
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_c_2413 = (g_heff_2ebuild_2eload_2epackagesOf_24s586135542x181689262(heff_dup(v_x_246), v_t_2412));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam3, 1, 6, (V[]){v_read_240, v_file_242, v_hd_244, v_x_246, v_x_248, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2ereadPackageAt_24s399269186x1245866702(v_h_241, heff_dup(v_x_246)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_lam1, 1, 5, (V[]){v_h_241, v_hd_244, v_read_240, v_file_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}