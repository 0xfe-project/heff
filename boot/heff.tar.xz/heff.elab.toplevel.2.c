// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IAnn 21211
#define TAG_IApp 21275
#define TAG_IVar 40993
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_TInf 28962
#define TAG_Throw 56084
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_evidence 1128105991
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_note 9882809
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_unreached 121683306
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656(V, V);
V g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656_clo;
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
V g_heff_2eelab_2eenvironment_2eseeArms(V, V, V);
V g_heff_2eelab_2eenvironment_2eseeArms_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eseeArms_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2etoplevel_2eallL(V, V);
V g_heff_2eelab_2etoplevel_2eallL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_get(void);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_clo;
V g_heff_2eelab_2etoplevel_2eequationsBody(V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_24generate0(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_24generate0_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_24map0(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_24map0_clo;
V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_clo;
HeffT10 g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo;
V g_heff_2eelab_2etoplevel_2etupleFront(V, V);
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleFront_clo;
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_clo;
V g_heff_2eelab_2etoplevel_2etupleTypeRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleTypeRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleTypeRev_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s2098521682x1221164629(V);
V g_list_2emap_24s2098521682x1221164629_entry(V self, V *a);
extern Clo g_list_2emap_24s2098521682x1221164629_clo;
V g_prelude_2etraverse_24s1778157750x1229378888(V);
V g_prelude_2etraverse_24s1778157750x1229378888_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1778157750x1229378888_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eselfTermF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTermF_lam2, 1, 0};
Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTermF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTermF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_strEq_c_lent(v_x_245, v_k_241, 0)) {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
      return heff_tag_n(TAG_SLocal, 1, (V[]){v_d_242});
    } else {
      heff_drop(v_d_242);
      return heff_tag_re_n(v_ru_24t_243_24SGlobal, TAG_SGlobal, 1, 1ULL, (V[]){v_x_245});
    }
  }
  case TAG_SCode: {
    V v_a_246 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_246}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_247});
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_t_243, 0);
    V v_a_249 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_248}));
    V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_249}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2410, v_t_2411});
  }
  case TAG_SLam: {
    V v_dom_2412 = heff_field(v_t_243, 0);
    V v_t2_2413 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2413)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_t2_2413, 0);
      V v_b_2415 = heff_field(v_t2_2413, 1);
      V v_ru_24t2_2413_24MkAbs = heff_take_reuse_n(v_t2_2413, 3ULL, 2);
      V v_t_2416 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2412}));
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2415}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2416, heff_tag_re_n(v_ru_24t2_2413_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2414, v_t_2417})});
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_t2_2413, 0);
      V v_ru_24t2_2413_24AbsConst = heff_take_reuse_n(v_t2_2413, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2412}));
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2418}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2419, heff_tag_at_n(v_ru_24t2_2413_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2420})});
    }
    default: return heff_nomatch(v_t2_2413);
    }
  }
  case TAG_SCons: {
    V v_c_2421 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2423 = heff_take_field(v_c_2421, 2);
    V v_t_2426 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2423, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam0, 1, 2, (V[]){v_xs_2423, v_f_2422}));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_c_2421, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2427});
  }
  case TAG_SProj: {
    V v_e_2428 = heff_field(v_t_243, 0);
    V v_l_2429 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2428}));
    return heff_tag_re_n(v_ru_24t_243_24SProj, TAG_SProj, 2, 2ULL, (V[]){v_t_2430, v_l_2429});
  }
  case TAG_STag: {
    V v_tg_2431 = heff_field(v_t_243, 0);
    V v_argv_2432 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_f_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2436 = heff_arrayGenerate(heff_arrayLength_lent(v_argv_2432, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam1, 1, 2, (V[]){v_argv_2432, v_f_2433}));
    return heff_tag_re_n(v_ru_24t_243_24STag, TAG_STag, 2, 1ULL, (V[]){v_tg_2431, v_t_2436});
  }
  case TAG_SMatch: {
    V v_e_2437 = heff_field(v_t_243, 0);
    V v_cs_2438 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2437}));
    V v_xs_2440 = heff_take_field(v_cs_2438, 2);
    V v_m_2441 = heff_arrayLength_lent(v_xs_2440, 0);
    V v_t_2450;
    if ((heff_peek_word(v_m_2441) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_d_242);
      heff_drop(v_xs_2440);
      v_t_2450 = heff_arrayGenerate(v_m_2441, ((V)&g_heff_2eelab_2etoplevel_2eselfTermF_lam2_clo));
    } else {
      V v_p_2443 = heff_arrayIndex_lent(v_xs_2440, MK_INT(0LL), 2);
      V v_y_2448;
      switch (heff_tag_of(v_p_2443)) {
      case TAG_MkPair: {
        V v_xs_2444 = heff_field(v_p_2443, 0);
        V v_b_2445 = heff_field(v_p_2443, 1);
        V v_ru_24p_2443_24MkPair = heff_take_reuse_n(v_p_2443, 3ULL, 2);
        V v_t_2446 = heff_intAdd_lent(v_d_242, heff_arrayLength_lent(v_xs_2444, 0), 2);
        V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){v_t_2446, v_b_2445}));
        v_y_2448 = heff_tag_re_n(v_ru_24p_2443_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_2444, v_t_2447});
        break;
      }
      default: heff_nomatch(v_p_2443);
      }
      V v_t_2449 = heff_arrayKeepsAs_lent(v_xs_2440, v_y_2448, 0);
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_m_2441);
        heff_drop(v_t_2449);
        v_t_2450 = (g_heff_2eelab_2etoplevel_2eselfTermF_24map0(v_r_240, v_d_242, MK_INT(1LL), heff_arraySet(v_xs_2440, MK_INT(0LL), v_y_2448)));
      } else {
        heff_drop(v_t_2449);
        v_t_2450 = ({ V a_0 = v_xs_2440; V a_1 = v_r_240; V a_2 = v_d_242; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_2441, v_y_2448); V r_ = (g_heff_2eelab_2etoplevel_2eselfTermF_24generate0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_2440); r_; });
      }
    }
    V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_nf(v_cs_2438, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2439, v_t_2451});
  }
  case TAG_SSpecialize: {
    V v_e_2452 = heff_field(v_t_243, 0);
    V v_l_2453 = heff_field(v_t_243, 1);
    V v_v_2454 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2452}));
    V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2454}));
    return heff_tag_re_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, 2ULL, (V[]){v_t_2455, v_l_2453, v_t_2456});
  }
  case TAG_SIs: {
    V v_e_2457 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2457}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2458});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2459 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2459}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2460});
  }
  case TAG_SFix: {
    V v_dom_2461 = heff_field(v_t_243, 0);
    V v_t2_2462 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2462)) {
    case TAG_MkAbs: {
      V v_x_2463 = heff_field(v_t2_2462, 0);
      V v_b_2464 = heff_field(v_t2_2462, 1);
      V v_ru_24t2_2462_24MkAbs = heff_take_reuse_n(v_t2_2462, 3ULL, 2);
      V v_t_2465 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2461}));
      V v_t_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2464}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2465, heff_tag_re_n(v_ru_24t2_2462_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2463, v_t_2466})});
    }
    case TAG_AbsConst: {
      V v_b_2467 = heff_field(v_t2_2462, 0);
      V v_ru_24t2_2462_24AbsConst = heff_take_reuse_n(v_t2_2462, 1ULL, 1);
      V v_t_2468 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2461}));
      V v_t_2469 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2467}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2468, heff_tag_at_n(v_ru_24t2_2462_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2469})});
    }
    default: return heff_nomatch(v_t2_2462);
    }
  }
  case TAG_SImplicit: {
    V v_x_2470 = heff_field(v_t_243, 0);
    V v_e_2471 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2471}));
    return heff_tag_re_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, 1ULL, (V[]){v_x_2470, v_t_2472});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2474 = heff_field(v_t_243, 0);
    V v_ix_2475 = heff_field(v_t_243, 1);
    V v_ty2_2476 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty2_2476}));
    return heff_tag_re_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, 3ULL, (V[]){v_m_2474, v_ix_2475, v_t_2477});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eselfTermF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_xs_2423 = heff_env(self)[0];
  V v_f_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_arrayIndex(v_xs_2423, v_i_2424);
  V f_ = v_f_2422;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args) {
  V v_i_2434 = args[0];
  V v_argv_2432 = heff_env(self)[0];
  V v_f_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_arrayIndex(v_argv_2432, v_i_2434);
  V f_ = v_f_2433;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args) {
  V v_u_2442 = args[0];
  heff_drop(v_u_2442);
  return heff_abandon();
}
Clo g_heff_2eelab_2etoplevel_2eallL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eallL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eallL(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleTypeRev_str0, 12, "builtin.Unit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleTypeRev_str1, 12, "prelude.Pair");
Clo g_heff_2eelab_2etoplevel_2etupleTypeRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleTypeRev_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleTypeRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleTypeRev_str0)}), v_sp_240});
  }
  case TAG_Cons: {
    V v_z_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_c_244 = (g_heff_2eelab_2etoplevel_2etupleFront(heff_dup(v_sp_240), v_rs_243));
    V v_t_247;
    switch (heff_tag_of(v_c_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_c_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_c_244);
    }
    V v_t_2410;
    switch (heff_tag_of(v_z_242)) {
    case TAG_At: {
      V v_s_249 = heff_dup(heff_field(v_z_242, 1));
      v_t_2410 = v_s_249;
      break;
    }
    default: heff_nomatch(v_z_242);
    }
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleTypeRev_str1)}), heff_dup(v_sp_240)});
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_c_244}), v_t_247});
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_z_242}), v_t_2410});
    V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2415 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2414})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleTypeRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleTypeRev(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(V v_f_240, V v_eqs_241, V v_sp_242, V v_z_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_f_240, NTAG(TAG_Nil), heff_dup(v_eqs_241), v_sp_242));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_eqs_241);
      V v_err_248 = v_field_247;
      V v_msg_249 = heff_take_field(v_err_248, 1);
      V v_span_2410 = heff_get_n(v_err_248, 0, 2);
      V v_msg_2411 = v_msg_249;
      V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), v_msg_2411, v_span_2410, NTAG(TAG_Nothing)});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_z_243, 2), 1, (V[]){v_t_2414}));
      return heff_tail(heff_get_n(v_z_243, 1, 3), 2, (V[]){v_t_2415, v_z_244});
    } else {
      V v_b_2416 = v_field_247;
      V v_t_2417 = (g_prelude_2etraverse_24s1778157750x1229378888(heff_dup(v_eqs_241)));
      V v_t_2418 = ({ V a_0 = v_eqs_241; V a_1 = v_t_2417; V r_ = (g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656(a_0, a_1)); heff_drop(v_eqs_241); r_; });
      V v_t_2419 = (g_list_2emap_24s2098521682x1221164629(v_t_2418));
      return (g_heff_2eelab_2eenvironment_2eseeArms(v_t_2419, heff_dup(v_z_243), heff_clo_n(g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_lam0, 1, 3, (V[]){v_b_2416, v_z_243, v_z_244})));
    }
  }
}
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_b_2416 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_drop(v_x_2420);
  heff_clo_take(self, 3);
  V v_t_2421 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2416));
  V f_ = v_t_2421;
  heff_room[0] = v_z_243;
  heff_room[1] = v_z_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str1, 12, "builtin.Unit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str2, 6, "MkPair");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str3, 12, "prelude.Pair");
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V v_nominal_240, V v_sp_241, V v_cs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_cs_242)));
  V v_n_244 = (g_heff_2eelab_2etoplevel_2etupleTypeRev(heff_dup(v_sp_241), v_t_243));
  V v_c_245 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n_244));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam0, 2, 4, (V[]){v_c_245, v_sp_241, v_cs_242, heff_dup(v_nominal_240)});
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_e_2413 = heff_env(self)[0];
  V v_a_2414 = heff_env(self)[1];
  V v_hd_2432 = heff_env(self)[2];
  V v_k_2433 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkChk: {
    V v_f_2435 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 1);
    heff_clo_take(self, 4);
    V f_ = v_f_2435;
    heff_room[0] = v_e_2413;
    heff_room[1] = v_a_2414;
    heff_room[2] = v_hd_2432;
    heff_room[3] = v_k_2433;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_e_2413 = heff_env(self)[1];
  V v_a_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam5, 1, 4, (V[]){v_e_2413, v_a_2414, v_hd_2432, v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam3(V self, V *args) {
  V v_e_2413 = args[0];
  V v_a_2414 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_cs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_sp_2415 = v_sp_241;
  V v_x2_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_242));
  V v_n_2430;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    V v_t_2417 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str0), heff_dup(v_sp_2415), NTAG(TAG_Nil)});
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str1)}), heff_dup(v_sp_2415)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_2418}), heff_dup(v_sp_2415)});
    V v_t_2420 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2417, heff_dup(v_sp_2415)}), v_t_2419});
    V v_i_2421 = heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_2415});
    V v_t_2424;
    switch (heff_tag_of(v_i_2421)) {
    case TAG_At: {
      V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
      v_t_2424 = v_s_2423;
      break;
    }
    default: heff_nomatch(v_i_2421);
    }
    v_n_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
    break;
  }
  case TAG_Cons: {
    V v_z_2425 = heff_field(v_x2_2416, 0);
    V v_rs_2426 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24Cons = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2427 = (g_heff_2eelab_2etoplevel_2etupleFront(heff_dup(v_sp_2415), v_rs_2426));
    V v_t_2428 = heff_tag_re_n(v_ru_24x2_2416_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_z_2425, NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str2), heff_dup(v_sp_2415), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2428})});
    v_n_2430 = heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_sp_2415});
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_c_2431 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_n_2430));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam4, 2, 3, (V[]){v_c_2431, v_e_2413, v_a_2414});
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam7(V self, V *args) {
  V v_c_2442 = args[0];
  V v_a0_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2442, 3, 9); V a_1 = v_a0_2439; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_sp_2411 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  V v_e_2438 = heff_env(self)[2];
  V v_hd_2440 = heff_env(self)[3];
  V v_k_2441 = heff_env(self)[4];
  V v_parts_2436 = heff_env(self)[5];
  V v_v_2437 = heff_env(self)[6];
  V v_t_2447 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2446)));
  switch (heff_tag_of(v_t_2447)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2447, 0ULL, 1);
    heff_clo_take(self, 7);
    heff_drop_tag(v_parts_2436, 1);
    heff_drop(v_v_2437);
    HeffT1 v_t_2449 = ({ V a_0 = v_sp_2411; V a_1 = v_t_2412; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
    {
      V v_field_2450 = v_t_2449.f[0];
      V v_f_2451 = v_field_2450;
      V f_ = v_f_2451;
      heff_room[0] = v_e_2438;
      heff_room[1] = v_x_2446;
      heff_room[2] = v_hd_2440;
      heff_room[3] = v_k_2441;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
  }
  default: {
    heff_clo_take(self, 7);
    heff_drop(v_t_2412);
    heff_drop(v_t_2447);
    V v_t_2474;
    switch (heff_tag_of(v_x_2446)) {
    case TAG_VU: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_2453 = heff_dup(heff_field(v_x_2446, 0));
      switch (heff_tag_of(v_x11_2453)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_2453, 0ULL, 1);
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_2459 = heff_field(v_x11_2453, 0);
        heff_take_n(v_x11_2453, 1ULL, 1);
        v_t_2474 = heff_bool(heff_strEq_c_lent(v_k_2459, ((V)&g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_str3), 2));
        heff_drop(v_k_2459);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_2453, 0ULL, 1);
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2453);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2446);
    }
    if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
      heff_drop(v_sp_2411);
      heff_drop(v_v_2437);
      heff_drop(v_t_2474);
      switch (heff_tag_of(v_parts_2436)) {
      case TAG_MkChk: {
        V v_f_2475 = heff_field(v_parts_2436, 0);
        heff_take_n(v_parts_2436, 1ULL, 1);
        V f_ = v_f_2475;
        heff_room[0] = v_e_2438;
        heff_room[1] = v_x_2446;
        heff_room[2] = v_hd_2440;
        heff_room[3] = v_k_2441;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_2436);
      }
    } else {
      heff_drop_tag(v_parts_2436, 1);
      heff_drop(v_t_2474);
      HeffT1 v_t_2476 = ({ V a_0 = v_sp_2411; V a_1 = v_v_2437; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_2437); r_; });
      {
        V v_field_2477 = v_t_2476.f[0];
        V v_f_2478 = v_field_2477;
        V f_ = v_f_2478;
        heff_room[0] = v_e_2438;
        heff_room[1] = v_x_2446;
        heff_room[2] = v_hd_2440;
        heff_room[3] = v_k_2441;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  }
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam6(V self, V *args) {
  V v_e_2438 = args[0];
  V v_a0_2439 = args[1];
  V v_hd_2440 = args[2];
  V v_k_2441 = args[3];
  V v_sp_2411 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  V v_parts_2436 = heff_env(self)[2];
  V v_v_2437 = heff_env(self)[3];
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam7, 1, 1, (V[]){v_a0_2439})})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2440, 2)), 1, (V[]){v_t_2444}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_2440, 1));
  args[0] = v_t_2445;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam8, 1, 7, (V[]){v_sp_2411, v_t_2412, v_e_2438, v_hd_2440, v_k_2441, v_parts_2436, v_v_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam9(V self, V *args) {
  V v_e_2480 = args[0];
  V v_a_2481 = args[1];
  V v_nominal_240 = heff_env(self)[0];
  V v_j_2479 = heff_env(self)[1];
  V v_t_2482;
  heff_clo_take(self, 2);
  if ((heff_dup(v_nominal_240) == NTAG(TAG_True))) {
    heff_drop(v_nominal_240);
    v_t_2482 = ({ V a_0 = v_j_2479; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop_tag(v_j_2479, 1); r_; });
  } else {
    heff_drop(v_nominal_240);
    v_t_2482 = v_j_2479;
  }
  switch (heff_tag_of(v_t_2482)) {
  case TAG_MkChk: {
    V v_f_2483 = heff_field(v_t_2482, 0);
    heff_take_n(v_t_2482, 1ULL, 1);
    V v_t_2484 = ({ V rv_6 = NTAG(TAG_False); V rr_ = heff_rec_reuse_nf(v_e_2480, 191ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 53247u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
    V f_ = v_f_2483;
    args[0] = v_t_2484;
    args[1] = v_a_2481;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_t_2482);
  }
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_sp_2411 = heff_dup(v_sp_241);
  heff_clo_take(self, 5);
  V v_t_2412 = v_x_248;
  V v_parts_2436 = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam3, 2, 2, (V[]){v_sp_241, v_cs_242})});
  V v_v_2437 = v_x_2410;
  V v_j_2479 = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam6, 4, 4, (V[]){v_sp_2411, v_t_2412, v_parts_2436, v_v_2437})});
  V v_x_2485 = ({ V b_0 = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam9, 2, 2, (V[]){v_nominal_240, v_j_2479})}); V r_ = (g_heff_2eelab_2erules_2eimplicitLams(b_0)); heff_drop(b_0); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_cs_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_t_249 = (g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(heff_dup(v_sp_241), heff_dup(v_cs_242), heff_dup(v_cs_242)));
  heff_clo_take(self, 5);
  V f_ = v_t_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam2, 1, 5, (V[]){v_sp_241, v_x_248, v_cs_242, v_nominal_240, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam1, 1, 5, (V[]){v_sp_241, v_cs_242, v_hd_246, v_nominal_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsBody_entry, 6, 0};

V g_heff_2eelab_2etoplevel_2eequationsBody(V v_name_240, V v_args_241, V v_eqs_242, V v_sp_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eexplicitNames(v_args_241));
  HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_name_240, v_t_246, heff_dup(v_eqs_242), v_sp_243));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_c_2425;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_err_2410 = v_field_249;
      V v_msg_2411 = heff_take_field(v_err_2410, 1);
      V v_span_2412 = heff_get_n(v_err_2410, 0, 2);
      V v_msg_2413 = v_msg_2411;
      v_c_2425 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam0, 2, 2, (V[]){v_msg_2413, v_span_2412});
    } else {
      V v_b_2422 = v_field_249;
      v_c_2425 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam1, 2, 1, (V[]){v_b_2422});
    }
    return heff_tail(v_c_2425, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam2, 1, 3, (V[]){v_eqs_242, v_z_244, v_z_245})});
  }
}
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eequationsBody(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_msg_2413 = heff_env(self)[0];
  V v_span_2412 = heff_env(self)[1];
  V v_malg_2416 = heff_take_field(v_hd_2414, 2);
  V v_bind_2417 = heff_get_n(v_hd_2414, 1, 3);
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), v_msg_2413, v_span_2412, NTAG(TAG_Nothing)});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(v_malg_2416, 1, (V[]){v_t_2420}));
  V f_ = v_bind_2417;
  args[0] = v_t_2421;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_b_2422 = heff_env(self)[0];
  heff_drop(v_hd_2423);
  heff_clo_take(self, 1);
  V f_ = v_k_2424;
  args[0] = v_b_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_drop(v_x_2430);
  V v_n_2433;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_At: {
    V v_n_2431 = heff_field(v_x_2426, 0);
    V v_sp_2432 = heff_field(v_x_2426, 1);
    heff_take_n(v_x_2426, 3ULL, 2);
    v_n_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V v_t_2434 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2433));
  V f_ = v_t_2434;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_eqs_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_t_2427 = (g_prelude_2etraverse_24s1778157750x1229378888(heff_dup(v_eqs_242)));
  heff_clo_take(self, 3);
  V v_t_2428 = ({ V a_0 = v_eqs_242; V a_1 = v_t_2427; V r_ = (g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656(a_0, a_1)); heff_drop(v_eqs_242); r_; });
  V v_t_2429 = (g_list_2emap_24s2098521682x1221164629(v_t_2428));
  return (g_heff_2eelab_2eenvironment_2eseeArms(v_t_2429, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam3, 1, 3, (V[]){v_x_2426, v_z_244, v_z_245})));
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_str0, 54, "an implicit argument an error kept from being inferred");

static V g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_st;
static V g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_init(void) {
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_st)) return g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_val, &g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_st, g_heff_2eelab_2etoplevel_2ebodyPhase_24rec0_init);
}
Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V v_acc_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_242, 0ULL, 5);
      V v_t_249 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_249));
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_242, 0ULL, 5);
      V v_t_2415 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_2415));
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_242, 0ULL, 4);
      V v_t_2420 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_2420));
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_242, 0ULL, 3);
      V v_t_2424 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_2424));
    }
    case TAG_DeclTest: {
      V v_x_2425 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24DeclTest = heff_take_reuse_n(v_n1_242, 1ULL, 2);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2428 = heff_field(v_n_241, 1);
        heff_take_n(v_n_241, 2ULL, 2);
        V v_keys_2429 = heff_take_field(v_acc_240, 2);
        V v_broken_2430 = heff_take_field(v_acc_240, 3);
        V v_watches_2431 = heff_take_field(v_acc_240, 4);
        V v_t_2432 = heff_take_field(v_acc_240, 5);
        V v_spans_2433 = heff_take_field(v_acc_240, 6);
        V v_infos_2434 = heff_take_field(v_acc_240, 7);
        V v_trace_2435 = heff_take_field(v_acc_240, 8);
        V v_unreached_2436 = heff_take_field(v_acc_240, 9);
        V v_t_2437 = heff_tag_at_n(v_ru_24n1_242_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2425, v_sp_2428}), v_t_2432});
        return ({ V rv_2 = v_keys_2429; V rv_3 = v_broken_2430; V rv_4 = v_watches_2431; V rv_5 = v_t_2437; V rv_6 = v_spans_2433; V rv_7 = v_infos_2434; V rv_8 = v_trace_2435; V rv_9 = v_unreached_2436; V rr_ = heff_rec_reuse_nf(v_acc_240, 3ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_DeclWatch: {
      V v_e_2438 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2440 = heff_field(v_n_241, 1);
        heff_take_n(v_n_241, 2ULL, 2);
        V v_t_2441 = heff_tr(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(heff_dup(heff_rfield(v_acc_240, 0)), v_e_2438, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
        return (g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_240, v_sp_2440, v_t_2441));
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(a[0], a[1]);
}

HeffT10 g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_24cpr(V v_acc_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_globals_242 = heff_take_field(v_acc_240, 0);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_diags_244 = (g_heff_2eelab_2etoplevel_2eonceEach(NTAG(TAG_Nil), v_t_243));
    V v_keys_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
    V v_broken_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 3)));
    V v_watches_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 4)));
    V v_tests_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 5)));
    V v_spans_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
    V v_infos_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 7)));
    V v_trace_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 8)));
    V v_unreached_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_240, 9, 10)));
    return ((HeffT10){{v_globals_242, v_diags_244, v_keys_245, v_broken_246, v_watches_247, v_tests_248, v_spans_249, v_infos_2410, v_trace_2411, v_unreached_2412}});
  }
  case TAG_Cons: {
    V v_n_2413 = heff_field(v_x3_241, 0);
    V v_rest_2414 = heff_field(v_x3_241, 1);
    V v_t_2415 = (g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(v_acc_240, heff_dup(v_n_2413)));
    V t_0 = v_t_2415;
    V t_1 = v_rest_2414;
    v_acc_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return ((HeffT10){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_str1, 1, "_");
Clo g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2(V v_tok_240, V v_p_241, V v_acc_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(v_p_241));
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    V v_t_246 = v_field_244;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_it1_247 = heff_field(v_t_246, 0);
      V v_tsp_248 = heff_field(v_t_246, 1);
      V v_ru_24t_246_24At = heff_take_reuse_n(v_t_246, 3ULL, 2);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_PatVar: {
        V v_it11_249 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        if (heff_strEq_c(v_it11_249, ((V)&g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_str0))) {
          return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24t_246_24At, TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_str1), v_tsp_248}), v_acc_242});
        } else {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_tsp_248);
          heff_drop_cell(v_ru_24t_246_24At, 2);
          return v_acc_242;
        }
      }
      case TAG_PatTag: {
        V v_x_2410 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 3);
        return heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24t_246_24At, TAG_MkPair, 2, (V[]){v_x_2410, v_tsp_248}), v_acc_242});
      }
      case TAG_PatOp: {
        heff_take_n(v_it1_247, 0ULL, 3);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatInt: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatFloat: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatString: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatBinary: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatRune: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatRecord: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatWord: {
        heff_take_n(v_it1_247, 0ULL, 1);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      case TAG_PatAs: {
        heff_take_n(v_it1_247, 0ULL, 3);
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_tsp_248);
        heff_drop_cell(v_ru_24t_246_24At, 2);
        return v_acc_242;
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2(a[0], a[1], a[2]);
}