// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_Catch 6517
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_HError 21467
#define TAG_IAnn 21211
#define TAG_IApp 21275
#define TAG_IVar 40993
#define TAG_LNil 57394
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SetField 47531
#define TAG_SpId 35501
#define TAG_TInf 28962
#define TAG_Throw 56084
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_note 9882809
#define LBL_prim 9944941
#define LBL_ret 322331
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V, V, V, V);
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V, V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_heff_2eelab_2erules_2etupleChk(V, V, V, V);
V g_heff_2eelab_2erules_2etupleChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etupleChk_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eequationsBody(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo;
V g_heff_2eelab_2etoplevel_2eerrEntry(V, V, V);
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2(V, V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2etheoryD(V, V, V);
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etheoryD_clo;
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo;
V g_heff_2eelab_2etoplevel_2etupleFront(V, V);
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleFront_clo;
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_clo;
V g_heff_2eelab_2etoplevel_2etuplePartsRev(V, V);
V g_heff_2eelab_2etoplevel_2etuplePartsRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etuplePartsRev_clo;
V g_heff_2eelab_2etoplevel_2etupleTypeRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleTypeRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleTypeRev_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2etraverse_24s1488190221x1768542206(V);
V g_prelude_2etraverse_24s1488190221x1768542206_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1488190221x1768542206_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTermF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTermF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  V v_ty_244 = heff_take_field(v_r_240, 1);
  V v_el_245 = heff_get_n(v_r_240, 0, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SGlobal: {
    V v_x_247 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    if (heff_strEq_c_lent(v_x_247, v_k_241, 0)) {
      heff_drop(v_x_247);
      heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
      return heff_tag_n(TAG_SLocal, 1, (V[]){v_d_242});
    } else {
      heff_drop(v_d_242);
      return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_SGlobal, 1, (V[]){v_x_247});
    }
  }
  case TAG_SCode: {
    V v_a_248 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_el_245);
    V v_t_249 = heff_tr(heff_call(v_ty_244, 2, (V[]){v_d_242, v_a_248}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_249});
  }
  case TAG_SApp: {
    V v_f_2410 = heff_field(v_t_243, 0);
    V v_a_2411 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_ty_244);
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_el_245), 2, (V[]){heff_dup(v_d_242), v_f_2410}));
    V v_t_2413 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_a_2411}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2412, v_t_2413});
  }
  case TAG_SLam: {
    V v_dom_2414 = heff_field(v_t_243, 0);
    V v_t2_2415 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2415)) {
    case TAG_MkAbs: {
      V v_x_2416 = heff_field(v_t2_2415, 0);
      V v_b_2417 = heff_field(v_t2_2415, 1);
      heff_take_n(v_t2_2415, 3ULL, 2);
      V v_t_2418 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_242), v_dom_2414}));
      V v_t_2419 = heff_tr(heff_call(v_el_245, 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2417}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2418, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2416, v_t_2419})});
    }
    case TAG_AbsConst: {
      V v_b_2420 = heff_field(v_t2_2415, 0);
      heff_take_n(v_t2_2415, 1ULL, 1);
      V v_t_2421 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_242), v_dom_2414}));
      V v_t_2422 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_b_2420}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2422})});
    }
    default: return heff_nomatch(v_t2_2415);
    }
  }
  case TAG_SCons: {
    V v_c_2423 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_ty_244);
    V v_keys_2424 = heff_take_field(v_c_2423, 0);
    V v_byName_2425 = heff_take_field(v_c_2423, 1);
    V v_values_2426 = heff_get_n(v_c_2423, 2, 3);
    V v_f_2427 = heff_tr(heff_call(v_el_245, 1, (V[]){v_d_242}));
    V v_xs_2428 = v_values_2426;
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2428, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam0, 1, 2, (V[]){v_xs_2428, v_f_2427}));
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2424, v_byName_2425, v_t_2431})});
  }
  case TAG_SProj: {
    V v_e_2432 = heff_field(v_t_243, 0);
    V v_l_2433 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_ty_244);
    V v_t_2434 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_e_2432}));
    return heff_tag_at_n(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2434, v_l_2433});
  }
  case TAG_STag: {
    V v_tg_2435 = heff_field(v_t_243, 0);
    V v_argv_2436 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_ty_244);
    V v_f_2437 = heff_tr(heff_call(v_el_245, 1, (V[]){v_d_242}));
    V v_t_2440 = heff_arrayGenerate(heff_arrayLength_lent(v_argv_2436, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam1, 1, 2, (V[]){v_argv_2436, v_f_2437}));
    return heff_tag_at_n(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_tg_2435, v_t_2440});
  }
  case TAG_SMatch: {
    V v_e_2441 = heff_field(v_t_243, 0);
    V v_cs_2442 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_ty_244);
    V v_keys_2443 = heff_take_field(v_cs_2442, 0);
    V v_byName_2444 = heff_take_field(v_cs_2442, 1);
    V v_values_2445 = heff_get_n(v_cs_2442, 2, 3);
    V v_t_2446 = heff_tr(heff_call(heff_dup(v_el_245), 2, (V[]){heff_dup(v_d_242), v_e_2441}));
    V v_xs_2447 = v_values_2445;
    V v_t_2454 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2447, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam2, 1, 3, (V[]){v_xs_2447, v_d_242, v_el_245}));
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2446, heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2443, v_byName_2444, v_t_2454})});
  }
  case TAG_SSpecialize: {
    V v_e_2455 = heff_field(v_t_243, 0);
    V v_l_2456 = heff_field(v_t_243, 1);
    V v_v_2457 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_ty_244);
    V v_t_2458 = heff_tr(heff_call(heff_dup(v_el_245), 2, (V[]){heff_dup(v_d_242), v_e_2455}));
    V v_t_2459 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_v_2457}));
    return heff_tag_at_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2458, v_l_2456, v_t_2459});
  }
  case TAG_SIs: {
    V v_e_2460 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_ty_244);
    V v_t_2461 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_e_2460}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2461});
  }
  case TAG_SOpaque: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2462 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_ty_244);
    V v_t_2463 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_e_2462}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2463});
  }
  case TAG_SFix: {
    V v_dom_2464 = heff_field(v_t_243, 0);
    V v_t2_2465 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2465)) {
    case TAG_MkAbs: {
      V v_x_2466 = heff_field(v_t2_2465, 0);
      V v_b_2467 = heff_field(v_t2_2465, 1);
      heff_take_n(v_t2_2465, 3ULL, 2);
      V v_t_2468 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_242), v_dom_2464}));
      V v_t_2469 = heff_tr(heff_call(v_el_245, 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2467}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2468, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2466, v_t_2469})});
    }
    case TAG_AbsConst: {
      V v_b_2470 = heff_field(v_t2_2465, 0);
      heff_take_n(v_t2_2465, 1ULL, 1);
      V v_t_2471 = heff_tr(heff_call(v_ty_244, 2, (V[]){heff_dup(v_d_242), v_dom_2464}));
      V v_t_2472 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_b_2470}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2471, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2472})});
    }
    default: return heff_nomatch(v_t2_2465);
    }
  }
  case TAG_SImplicit: {
    V v_x_2473 = heff_field(v_t_243, 0);
    V v_e_2474 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_ty_244);
    V v_t_2475 = heff_tr(heff_call(v_el_245, 2, (V[]){v_d_242, v_e_2474}));
    return heff_tag_at_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2473, v_t_2475});
  }
  case TAG_SPrim: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2477 = heff_field(v_t_243, 0);
    V v_ix_2478 = heff_field(v_t_243, 1);
    V v_ty2_2479 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_el_245);
    V v_t_2480 = heff_tr(heff_call(v_ty_244, 2, (V[]){v_d_242, v_ty2_2479}));
    return heff_tag_at_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2477, v_ix_2478, v_t_2480});
  }
  case TAG_SLitInt: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SLitBytes: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop(v_d_242);
    heff_drop(v_ty_244);
    heff_drop(v_el_245);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eselfTermF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  V f_ = v_f_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args) {
  V v_i_2438 = args[0];
  V v_argv_2436 = heff_env(self)[0];
  V v_f_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_arrayIndex(v_argv_2436, v_i_2438);
  V f_ = v_f_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args) {
  V v_i_2448 = args[0];
  V v_xs_2447 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_el_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2449 = heff_arrayIndex(v_xs_2447, v_i_2448);
  switch (heff_tag_of(v_p_2449)) {
  case TAG_MkPair: {
    V v_xs_2450 = heff_field(v_p_2449, 0);
    V v_b_2451 = heff_field(v_p_2449, 1);
    V v_ru_24p_2449_24MkPair = heff_take_reuse_n(v_p_2449, 3ULL, 2);
    V v_t_2452 = heff_intAdd(v_d_242, heff_arrayLength_lent(v_xs_2450, 0));
    V v_t_2453 = heff_tr(heff_call(v_el_245, 2, (V[]){v_t_2452, v_b_2451}));
    return heff_tag_at_n(v_ru_24p_2449_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2450, v_t_2453});
  }
  default: return heff_nomatch(v_p_2449);
  }
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveringChk_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2erecoveringChk(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tr(heff_call(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam0, 1, 1, (V[]){heff_dup(v_hd_241)})}));
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_244, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam1, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_247}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam2, 1, 1, (V[]){v_k_242})});
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveringChk(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam3(V self, V *args) {
  V v_e_2411 = args[0];
  V v_a_2412 = args[1];
  V v_hd_2413 = args[2];
  V v_k2_2414 = args[3];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2411);
  heff_drop(v_a_2412);
  V v_bind_2415 = heff_take_field(v_hd_2413, 1);
  V v_malg_2416 = heff_get_n(v_hd_2413, 2, 3);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_d_2410})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(v_malg_2416, 1, (V[]){v_t_2418}));
  V f_ = v_bind_2415;
  args[0] = v_t_2419;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_d_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    V v_t_2420 = ({ V b_0 = heff_tag_at_n(v_ru_24x_249_24Left, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam3, 4, 1, (V[]){v_d_2410})}); V r_ = (g_heff_2eelab_2erules_2erecovering(b_0)); heff_drop(b_0); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_c_2421 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2422 = ({ V a_0 = v_c_2421; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_c_2421); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleTypeRev_str0, 12, "builtin.Unit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleTypeRev_str1, 12, "prelude.Pair");
Clo g_heff_2eelab_2etoplevel_2etupleTypeRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleTypeRev_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleTypeRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleTypeRev_str0)}), v_sp_240});
  }
  case TAG_Cons: {
    V v_z_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleTypeRev_str1)}), heff_dup(v_sp_240)});
    V v_c_245 = (g_heff_2eelab_2etoplevel_2etupleFront(heff_dup(v_sp_240), v_rs_243));
    V v_t_248;
    switch (heff_tag_of(v_c_245)) {
    case TAG_At: {
      V v_s_247 = heff_dup(heff_field(v_c_245, 1));
      v_t_248 = v_s_247;
      break;
    }
    default: heff_nomatch(v_c_245);
    }
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_c_245}), v_t_248});
    V v_t_2412;
    switch (heff_tag_of(v_z_242)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_z_242, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_z_242);
    }
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_z_242}), v_t_2412});
    V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2415 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2414})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleTypeRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleTypeRev(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etuplePartsRev_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etuplePartsRev_str1, 12, "builtin.Unit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etuplePartsRev_str2, 6, "MkPair");
Clo g_heff_2eelab_2etoplevel_2etuplePartsRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etuplePartsRev_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etuplePartsRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etuplePartsRev_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etuplePartsRev_str1)}), heff_dup(v_sp_240)});
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_243}), heff_dup(v_sp_240)});
    V v_t_245 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_242, heff_dup(v_sp_240)}), v_t_244});
    V v_i_246 = heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
    V v_t_249;
    switch (heff_tag_of(v_i_246)) {
    case TAG_At: {
      V v_s_248 = heff_dup(heff_field(v_i_246, 1));
      v_t_249 = v_s_248;
      break;
    }
    default: heff_nomatch(v_i_246);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
  }
  case TAG_Cons: {
    V v_z_2410 = heff_field(v_x2_241, 0);
    V v_rs_2411 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2etupleFront(heff_dup(v_sp_240), v_rs_2411));
    V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_z_2410, NTAG(TAG_Nil)});
    V v_t_2414 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etuplePartsRev_str2), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2413})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etuplePartsRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etuplePartsRev(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_str0, 44, "expected a field setting of the form `x = v`");
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_e_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0, 2, 4, (V[]){v_t_246, heff_dup(v_e_245), heff_dup(v_x_243), heff_dup(v_xsp_244)});
    }
    case TAG_BadFieldSet: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_xsp_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412;
  switch (heff_tag_of(v_e_245)) {
  case TAG_At: {
    V v_s_2411 = heff_field(v_e_245, 1);
    heff_take_n(v_e_245, 2ULL, 2);
    v_t_2412 = v_s_2411;
    break;
  }
  default: heff_nomatch(v_e_245);
  }
  V f_ = v_k_248;
  args[0] = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_243, v_x_249, v_t_2412, v_xsp_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_e_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_xsp_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_246, v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1, 1, 4, (V[]){v_e_245, v_k_248, v_x_243, v_xsp_244})));
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2416 = heff_take_field(v_hd_2414, 1);
  V v_malg_2417 = heff_get_n(v_hd_2414, 2, 3);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(202LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(v_malg_2417, 1, (V[]){v_t_2420}));
  V f_ = v_bind_2416;
  args[0] = v_t_2421;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V v_nominal_240, V v_sp_241, V v_cs_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_cs_242)));
  V v_n_244 = (g_heff_2eelab_2etoplevel_2etupleTypeRev(heff_dup(v_sp_241), v_t_243));
  V v_c_245 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n_244));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam0, 2, 4, (V[]){v_c_245, v_sp_241, v_cs_242, heff_dup(v_nominal_240)});
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_2411 = heff_env(self)[0];
  V v_a_2412 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkChk: {
    V v_f_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V f_ = v_f_2419;
    heff_room[0] = v_e_2411;
    heff_room[1] = v_a_2412;
    heff_room[2] = v_hd_2416;
    heff_room[3] = v_k_2417;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_e_2411 = heff_env(self)[1];
  V v_a_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam5, 1, 4, (V[]){v_e_2411, v_a_2412, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam3(V self, V *args) {
  V v_e_2411 = args[0];
  V v_a_2412 = args[1];
  V v_cs_242 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_242));
  V v_n_2414 = (g_heff_2eelab_2etoplevel_2etuplePartsRev(v_sp_241, v_t_2413));
  V v_c_2415 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_n_2414));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam4, 2, 3, (V[]){v_c_2415, v_e_2411, v_a_2412});
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_j_2420 = ({ V a_0 = heff_dup(v_sp_241); V a_1 = v_x_248; V b_2 = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam3, 2, 2, (V[]){v_cs_242, v_sp_241})}); V a_3 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2etupleChk(a_0, a_1, b_2, a_3)); heff_drop(v_x_248); heff_drop(b_2); heff_drop(v_x_2410); r_; });
  V v_t_2421;
  if ((heff_dup(v_nominal_240) == NTAG(TAG_True))) {
    heff_drop(v_nominal_240);
    v_t_2421 = ({ V a_0 = v_j_2420; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_j_2420); r_; });
  } else {
    heff_drop(v_nominal_240);
    v_t_2421 = v_j_2420;
  }
  V v_x_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2421); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_cs_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(heff_dup(v_sp_241), heff_dup(v_cs_242), heff_dup(v_cs_242)));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam2, 1, 5, (V[]){v_sp_241, v_x_248, v_cs_242, v_nominal_240, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_lam1, 1, 5, (V[]){v_sp_241, v_cs_242, v_hd_246, v_nominal_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etheoryD_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_lam4, 1, 0};
V g_heff_2eelab_2etoplevel_2etheoryD_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etheoryD_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_lam3, 3, 0};
V g_heff_2eelab_2etoplevel_2etheoryD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etheoryD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etheoryD_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etheoryD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etheoryD(V v_name_240, V v_params_241, V v_bodyN_242) {
top: ;
  V v_c_243 = (g_prelude_2etraverse_24s1488190221x1768542206(v_params_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam0, 2, 3, (V[]){v_c_243, heff_dup(v_bodyN_242), v_name_240});
}
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etheoryD(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam4(V self, V *args) {
  V v_u2_2416 = args[0];
  heff_drop(v_u2_2416);
  V v_t_2417 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2417});
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam3(V self, V *args) {
  V v_e_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_e_2412);
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
  V f_ = v_k_2414;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2415, ((V)&g_heff_2eelab_2etoplevel_2etheoryD_lam4_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etheoryD_lam3_clo)}), v_x_2411});
  V v_x2_2419 = ({ V a_0 = v_x_246; V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_ty_2420 = heff_field(v_x2_2419, 0);
    V v_tm_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2420, v_tm_2421, NTAG(TAG_False)});
    V f_ = v_k_245;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_bodyN_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_249;
  switch (heff_tag_of(v_bodyN_242)) {
  case TAG_At: {
    V v_n_247 = heff_field(v_bodyN_242, 0);
    V v_sp_248 = heff_field(v_bodyN_242, 1);
    heff_take_n(v_bodyN_242, 3ULL, 2);
    v_n_249 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_248, v_n_247));
    break;
  }
  default: heff_nomatch(v_bodyN_242);
  }
  V v_c_2410 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_249));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam2, 1, 3, (V[]){v_x_246, v_name_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_bodyN_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam1, 1, 4, (V[]){v_bodyN_242, v_hd_244, v_name_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsBody_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eequationsBody(V v_name_240, V v_args_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2eexplicitNames(v_args_241));
  HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_name_240, v_t_244, v_eqs_242, v_sp_243));
  V v_c_2422;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_err_248 = v_field_247;
      V v_msg_249 = heff_take_field(v_err_248, 1);
      V v_span_2410 = heff_get_n(v_err_248, 0, 2);
      v_c_2422 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam0, 2, 2, (V[]){v_msg_249, v_span_2410});
    } else {
      V v_b_2419 = v_field_247;
      v_c_2422 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam1, 2, 1, (V[]){v_b_2419});
    }
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam2, 2, 1, (V[]){v_c_2422});
}
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eequationsBody(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_msg_249 = heff_env(self)[0];
  V v_span_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2413 = heff_take_field(v_hd_2411, 1);
  V v_malg_2414 = heff_get_n(v_hd_2411, 2, 3);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), v_msg_249, v_span_2410, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(v_malg_2414, 1, (V[]){v_t_2417}));
  V f_ = v_bind_2413;
  args[0] = v_t_2418;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_b_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = v_b_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_2428;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_At: {
    V v_n_2426 = heff_field(v_x_2425, 0);
    V v_sp_2427 = heff_field(v_x_2425, 1);
    heff_take_n(v_x_2425, 3ULL, 2);
    v_n_2428 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2427, v_n_2426));
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_t_2429 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2428));
  V f_ = v_t_2429;
  heff_room[0] = v_hd_2423;
  heff_room[1] = v_k_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam3, 1, 2, (V[]){v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eerrEntry_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eerrEntry_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eerrEntry(V v_g_240, V v_k_241, V v_tyStx_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_t_2411;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_a_249;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      v_a_249 = v_x_246;
    } else {
      if ((v_tag_244 == ((int64_t)1ULL))) {
        V v_x11_247 = v_field_245;
        heff_drop(v_x11_247);
        v_a_249 = heff_abandon();
      } else {
        V v_x_248 = v_field_245;
        v_a_249 = v_x_248;
      }
    }
    v_t_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eerrEntry_lam0, 1, 1, (V[]){v_a_249}), NTAG(TAG_Nothing)));
  }
  HeffT2 v_t_2412 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_t_2418;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2414;
      v_t_2418 = v_x_2415;
    } else {
      if ((v_tag_2413 == ((int64_t)1ULL))) {
        V v_x11_2416 = v_field_2414;
        heff_drop(v_x11_2416);
        v_t_2418 = heff_abandon();
      } else {
        V v_x_2417 = v_field_2414;
        v_t_2418 = v_x_2417;
      }
    }
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_242, v_t_2411, v_t_2418});
}
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eerrEntry(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eerrEntry_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_a_249;
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0, 2, 0};
Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V v_acc_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_242, 0ULL, 5);
      V v_t_249 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_249));
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_242, 0ULL, 5);
      V v_t_2415 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_2415));
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_242, 0ULL, 4);
      V v_t_2420 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_2420));
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_242, 0ULL, 3);
      V v_t_2424 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), heff_dup(v_n_241), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(v_acc_240, v_n_241, v_t_2424));
    }
    case TAG_DeclTest: {
      V v_x_2425 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24DeclTest = heff_take_reuse_n(v_n1_242, 1ULL, 2);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2428 = heff_field(v_n_241, 1);
        heff_take_n(v_n_241, 2ULL, 2);
        V v_t_2429 = heff_tag_at_n(v_ru_24n1_242_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2425, v_sp_2428}), heff_dup(heff_rfield(v_acc_240, 5))});
        return ({ V rv_5 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_acc_240, 479ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_DeclWatch: {
      V v_e_2430 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2432 = heff_field(v_n_241, 1);
        heff_take_n(v_n_241, 2ULL, 2);
        V v_m_2433 = (g_heff_2eelab_2etoplevel_2eelabWatch(heff_dup(heff_rfield(v_acc_240, 0)), v_e_2430));
        V v_t_2436 = heff_tr(heff_call(v_m_2433, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0_clo), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())}));
        return (g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_240, v_sp_2432, v_t_2436));
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_2435 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2435});
}