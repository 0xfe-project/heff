// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_regex_2eperlClass_2edigitRanges_240_get(void);
V g_regex_2eperlClass_2espaceRanges_242_get(void);
V g_regex_2eperlClass_2ewordRanges_241_get(void);

static V g_regex_2eperlClass_2edigitRanges_240_val;
static HEFF_ONCE g_regex_2eperlClass_2edigitRanges_240_st;
static V g_regex_2eperlClass_2edigitRanges_240_init(void) {
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(48LL), MK_INT(57LL)}), NTAG(TAG_Nil)});
}
V g_regex_2eperlClass_2edigitRanges_240_get(void) {
  if (HEFF_DONE(g_regex_2eperlClass_2edigitRanges_240_st)) return g_regex_2eperlClass_2edigitRanges_240_val;
  return heff_global(&g_regex_2eperlClass_2edigitRanges_240_val, &g_regex_2eperlClass_2edigitRanges_240_st, g_regex_2eperlClass_2edigitRanges_240_init);
}

static V g_regex_2eperlClass_2ewordRanges_241_val;
static HEFF_ONCE g_regex_2eperlClass_2ewordRanges_241_st;
static V g_regex_2eperlClass_2ewordRanges_241_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(97LL), MK_INT(122LL)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(95LL), MK_INT(95LL)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(65LL), MK_INT(90LL)}), v_t_241});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(48LL), MK_INT(57LL)}), v_t_242});
}
V g_regex_2eperlClass_2ewordRanges_241_get(void) {
  if (HEFF_DONE(g_regex_2eperlClass_2ewordRanges_241_st)) return g_regex_2eperlClass_2ewordRanges_241_val;
  return heff_global(&g_regex_2eperlClass_2ewordRanges_241_val, &g_regex_2eperlClass_2ewordRanges_241_st, g_regex_2eperlClass_2ewordRanges_241_init);
}

static V g_regex_2eperlClass_2espaceRanges_242_val;
static HEFF_ONCE g_regex_2eperlClass_2espaceRanges_242_st;
static V g_regex_2eperlClass_2espaceRanges_242_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(32LL), MK_INT(32LL)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(12LL), MK_INT(13LL)}), v_t_240});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(9LL), MK_INT(10LL)}), v_t_241});
}
V g_regex_2eperlClass_2espaceRanges_242_get(void) {
  if (HEFF_DONE(g_regex_2eperlClass_2espaceRanges_242_st)) return g_regex_2eperlClass_2espaceRanges_242_val;
  return heff_global(&g_regex_2eperlClass_2espaceRanges_242_val, &g_regex_2eperlClass_2espaceRanges_242_st, g_regex_2eperlClass_2espaceRanges_242_init);
}