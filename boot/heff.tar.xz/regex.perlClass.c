// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_regex_2eperlClass_2edigitRanges_240_get(void);
V g_regex_2eperlClass_2espaceRanges_242_get(void);
V g_regex_2eperlClass_2ewordRanges_241_get(void);
HEFF_TAG_LIT(g_regex_2eperlClass_2edigitRanges_240_lit0, TAG_MkPair, 2, MK_INT(48LL), MK_INT(57LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2edigitRanges_240_lit1, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2edigitRanges_240_lit0), NTAG(TAG_Nil));

static V g_regex_2eperlClass_2edigitRanges_240_val;
static HEFF_ONCE g_regex_2eperlClass_2edigitRanges_240_st;
static V g_regex_2eperlClass_2edigitRanges_240_init(void) {
  return ((V)&g_regex_2eperlClass_2edigitRanges_240_lit1);
}
V g_regex_2eperlClass_2edigitRanges_240_get(void) {
  if (HEFF_DONE(g_regex_2eperlClass_2edigitRanges_240_st)) return g_regex_2eperlClass_2edigitRanges_240_val;
  return heff_global(&g_regex_2eperlClass_2edigitRanges_240_val, &g_regex_2eperlClass_2edigitRanges_240_st, g_regex_2eperlClass_2edigitRanges_240_init);
}
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit0, TAG_MkPair, 2, MK_INT(48LL), MK_INT(57LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit1, TAG_MkPair, 2, MK_INT(65LL), MK_INT(90LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit2, TAG_MkPair, 2, MK_INT(95LL), MK_INT(95LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit3, TAG_MkPair, 2, MK_INT(97LL), MK_INT(122LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit4, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2ewordRanges_241_lit3), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit5, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2ewordRanges_241_lit2), ((V)&g_regex_2eperlClass_2ewordRanges_241_lit4));
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit6, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2ewordRanges_241_lit1), ((V)&g_regex_2eperlClass_2ewordRanges_241_lit5));
HEFF_TAG_LIT(g_regex_2eperlClass_2ewordRanges_241_lit7, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2ewordRanges_241_lit0), ((V)&g_regex_2eperlClass_2ewordRanges_241_lit6));

static V g_regex_2eperlClass_2ewordRanges_241_val;
static HEFF_ONCE g_regex_2eperlClass_2ewordRanges_241_st;
static V g_regex_2eperlClass_2ewordRanges_241_init(void) {
  return ((V)&g_regex_2eperlClass_2ewordRanges_241_lit7);
}
V g_regex_2eperlClass_2ewordRanges_241_get(void) {
  if (HEFF_DONE(g_regex_2eperlClass_2ewordRanges_241_st)) return g_regex_2eperlClass_2ewordRanges_241_val;
  return heff_global(&g_regex_2eperlClass_2ewordRanges_241_val, &g_regex_2eperlClass_2ewordRanges_241_st, g_regex_2eperlClass_2ewordRanges_241_init);
}
HEFF_TAG_LIT(g_regex_2eperlClass_2espaceRanges_242_lit0, TAG_MkPair, 2, MK_INT(9LL), MK_INT(10LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2espaceRanges_242_lit1, TAG_MkPair, 2, MK_INT(12LL), MK_INT(13LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2espaceRanges_242_lit2, TAG_MkPair, 2, MK_INT(32LL), MK_INT(32LL));
HEFF_TAG_LIT(g_regex_2eperlClass_2espaceRanges_242_lit3, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2espaceRanges_242_lit2), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_regex_2eperlClass_2espaceRanges_242_lit4, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2espaceRanges_242_lit1), ((V)&g_regex_2eperlClass_2espaceRanges_242_lit3));
HEFF_TAG_LIT(g_regex_2eperlClass_2espaceRanges_242_lit5, TAG_Cons, 2, ((V)&g_regex_2eperlClass_2espaceRanges_242_lit0), ((V)&g_regex_2eperlClass_2espaceRanges_242_lit4));

static V g_regex_2eperlClass_2espaceRanges_242_val;
static HEFF_ONCE g_regex_2eperlClass_2espaceRanges_242_st;
static V g_regex_2eperlClass_2espaceRanges_242_init(void) {
  return ((V)&g_regex_2eperlClass_2espaceRanges_242_lit5);
}
V g_regex_2eperlClass_2espaceRanges_242_get(void) {
  if (HEFF_DONE(g_regex_2eperlClass_2espaceRanges_242_st)) return g_regex_2eperlClass_2espaceRanges_242_val;
  return heff_global(&g_regex_2eperlClass_2espaceRanges_242_val, &g_regex_2eperlClass_2espaceRanges_242_st, g_regex_2eperlClass_2espaceRanges_242_init);
}