// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Now 25954
#define TAG_Quit 47258
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
V g_co_2eop_24s1554102946x910234624(V, V, V);
V g_co_2eop_24s1554102946x910234624_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_clo;
V g_co_2eop_24s1554102946x910234624_24tok1(V, V, V, V);
V g_co_2eop_24s1554102946x910234624_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_24tok1_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(V);
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968(V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_clo;
V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078(V, V);
V g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066(V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2ewriteInto(V, V);
V g_json_2ewriteInto_entry(V self, V *a);
extern Clo g_json_2ewriteInto_clo;
V g_list_2eany_24s1795474228x706402294(V, V);
V g_list_2eany_24s1795474228x706402294_entry(V self, V *a);
extern Clo g_list_2eany_24s1795474228x706402294_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1441124185x871809048(V, V);
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_clo;
V g_list_2ekeepIf_24s647917584x875728492(V, V);
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_j_242, v_i_241, 0) || heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241)))) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_n_243;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      HeffT2 v_t_244 = heff_strRuneDecode_lent(v_src_240, v_i_241, 0);
      {
        V v_rune_245 = v_t_244.f[0];
        V v_width_246 = v_t_244.f[1];
        V v_t_247;
        if (heff_intLe_c(MK_INT(65536LL), heff_runeToInt(v_rune_245))) {
          v_t_247 = MK_INT(2LL);
        } else {
          v_t_247 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, v_width_246);
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, v_t_247);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eunits16Go(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c_lent(v_line_241, v_l_244, 0)) {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_d_245 = heff_strLength_lent(v_src_240, 0);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), v_src_240, v_i_243, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_247 = v_d_245;
    } else {
      heff_drop(v_d_245);
      v_t_247 = v_j_246;
    }
    return (g_heff_2elsp_2elsp_2eoffset16(v_src_240, v_i_243, v_t_247, v_ch_242));
  } else {
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), v_src_240, v_i_243, 5);
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      heff_drop(v_j_248);
      return heff_strLength_lent(v_src_240, 0);
    } else {
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_j_248, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetGo(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 5, "range");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_span_242 = heff_take_field(v_d_241, 3);
  V v_severity_243 = heff_take_field(v_d_241, 1);
  V v_note_244 = heff_take_field(v_d_241, 4);
  V v_msg_245 = heff_take_field(v_d_241, 2);
  V v_code_246 = heff_get_n(v_d_241, 0, 5);
  V v_t_247 = (g_heff_2elsp_2elsp_2erange(v_src_240, v_span_242));
  V v_t_248;
  switch (heff_tag_of(v_severity_243)) {
  case TAG_SError: {
    v_t_248 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_248 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_248 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_severity_243);
  }
  V v_t_2410;
  switch (heff_tag_of(v_note_244)) {
  case TAG_Nothing: {
    v_t_2410 = v_msg_245;
    break;
  }
  case TAG_Just: {
    V v_n_249 = heff_field(v_note_244, 0);
    heff_take_n(v_note_244, 1ULL, 1);
    v_t_2410 = heff_strAppend(heff_strAppend(v_msg_245, ((V)&g_heff_2elsp_2elsp_2ediagnostic_str0)), v_n_249);
    break;
  }
  default: heff_nomatch(v_note_244);
  }
  V v_ys_2416;
  if (heff_intEq_c_lent(v_code_246, MK_INT(0LL), 2)) {
    heff_drop(v_severity_243);
    heff_drop(v_code_246);
    v_ys_2416 = NTAG(TAG_Nil);
  } else {
    V v_t_2411;
    switch (heff_tag_of(v_severity_243)) {
    case TAG_SError: {
      v_t_2411 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str1);
      break;
    }
    case TAG_SWarning: {
      v_t_2411 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str2);
      break;
    }
    case TAG_SDebug: {
      v_t_2411 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str3);
      break;
    }
    default: heff_nomatch(v_severity_243);
    }
    V v_t_2412 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_246)));
    V v_t_2413 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2412), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str4)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2411, v_t_2413), heff_intShow(v_code_246));
    V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), heff_tag_n(TAG_JString, 1, (V[]){v_t_2414})});
    v_ys_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  }
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_t_248})});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str7), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str8)})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str9), heff_tag_n(TAG_JString, 1, (V[]){v_t_2410})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_ys_2416})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), v_t_247}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2420})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2421});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ediagnostic(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2elsp_2ecatMaybesL_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str2, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str3, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str4, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str5, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2edeclsGo_24dps(V v_x1_240, V v_key_241, V v_above_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_key_241);
    heff_drop(v_above_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_246 = heff_take_field(v_l_244, 1);
    V v_at_247 = heff_get_n(v_l_244, 0, 2);
    V v_l_248 = heff_dup(v_text_246);
    if ((heff_strEq_c(heff_strSlice_lent(v_l_248, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str0)) || heff_strEq_c(heff_strSlice_lent(v_l_248, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str1)))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_text_246);
      heff_drop(v_l_248);
      V v_t_2410;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_2410 = v_at_247;
        break;
      }
      case TAG_Just: {
        V v_x_249 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop(v_at_247);
        v_t_2410 = v_x_249;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_245;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
      V t_3 = v_d_243;
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_l_248);
      V v_l_2411 = heff_dup(v_text_246);
      V v_t_2415;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_2411, 0)))) {
        if (((heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : !(heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)13ULL))))) {
          if ((heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str2)) ? 0 : !heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str3)))) {
            V v_t_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2411, MK_INT(0LL)));
            V v_x1_2414 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), v_t_2412, 2), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str4)) || ({ V v_t_2413 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2411, MK_INT(0LL))); int c_ = ({ V v_t_2429 = heff_strSlice_lent(v_l_2411, MK_INT(0LL), v_t_2413, 2); int c_ = heff_strEq_c_lent(v_t_2429, ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str5), 2); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2413); c_; })));
            heff_drop(v_l_2411);
            heff_drop(v_t_2412);
            v_t_2415 = heff_bool(!(heff_dup(v_x1_2414) == NTAG(TAG_True)));
            heff_drop(v_x1_2414);
          } else {
            heff_drop(v_l_2411);
            v_t_2415 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l_2411);
          v_t_2415 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_l_2411);
        v_t_2415 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = (g_heff_2elsp_2elsp_2ekeyOf(v_text_246));
        V v_x1_2417 = heff_bool(heff_strEq_c_lent(v_t_2416, v_key_241, 0));
        heff_drop(v_t_2416);
        if (!(heff_dup(v_x1_2417) == NTAG(TAG_True))) {
          heff_drop(v_key_241);
          heff_drop(v_x1_2417);
          V v_cut_2419;
          switch (heff_tag_of(v_above_242)) {
          case TAG_Nothing: {
            v_cut_2419 = heff_dup(v_at_247);
            break;
          }
          case TAG_Just: {
            V v_x_2418 = heff_field(v_above_242, 0);
            heff_take_n(v_above_242, 1ULL, 1);
            v_cut_2419 = v_x_2418;
            break;
          }
          default: heff_nomatch(v_above_242);
          }
          V v_n_2420 = v_at_247;
          HeffT2 v_t_2421 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_text_246));
          V v_t_2425;
          {
            V v_field_2422 = v_t_2421.f[0];
            V v_field_2423 = v_t_2421.f[1];
            V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_field_2422, heff_dup(v_n_2420)), heff_intAdd(v_field_2423, v_n_2420)});
            v_t_2425 = heff_rec_n(2, shape_cut__name, (V[]){v_cut_2419, v_t_2424});
          }
          V v_cell_2426 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
          V v_u_2427 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2426));
          heff_drop(v_u_2427);
          V v_t_2428 = ({ V a_0 = v_text_246; V r_ = (g_heff_2elsp_2elsp_2ekeyOf(a_0)); heff_drop(v_text_246); r_; });
          V t_0 = v_rest_245;
          V t_1 = v_t_2428;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_cell_2426;
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          v_d_243 = t_3;
          goto top;
        } else {
          heff_drop(v_above_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_text_246);
          heff_drop(v_at_247);
          heff_drop(v_x1_2417);
          V t_0 = v_rest_245;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_d_243;
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
      } else {
        heff_drop(v_above_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_text_246);
        heff_drop(v_at_247);
        heff_drop(v_t_2415);
        V t_0 = v_rest_245;
        V t_1 = v_key_241;
        V t_2 = NTAG(TAG_Nothing);
        V t_3 = v_d_243;
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edeclsGo_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubSources_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s1441124185x871809048(v_s_242, v_ss_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s647917584x875728492(v_c_241, v_cs_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s647917584x875728492(v_c_242, v_cs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubRoots_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_r_242; V a_1 = v_rs_243; V r_ = (g_list_2ekeepIf_24s689992630x418898235(a_0, a_1)); heff_drop(v_r_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str2, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str3, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 25, "client/registerCapability");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str6, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str7, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str10, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str11, 7, "**/*.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 6, "params");

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str15), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}
V g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_entry, 4, 0};

V g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(v_st_240, heff_dup(v_f_244)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_lam0, 1, 3, (V[]){heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_x_247; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_dup(heff_rfield(v_st_240, 2)), v_f_241));
  V v_project_243 = heff_dup(heff_rfield(v_st_240, 3));
  V v_watch_244 = heff_dup(heff_rfield(v_st_240, 4));
  V v_shutdown_245 = heff_dup(heff_rfield(v_st_240, 5));
  V v_lib_246 = heff_dup(heff_rfield(v_st_240, 6));
  V v_t_247 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_240, 0)), heff_dup(heff_rfield(v_st_240, 1)), v_t_242, v_project_243, v_watch_244, v_shutdown_245, v_lib_246});
  V v_c_248 = (g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(v_t_247, heff_dup(v_f_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam0, 2, 3, (V[]){v_c_248, v_st_240, v_f_241});
}
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam2(V self, V *args) {
  V v_p_2413 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_dup(heff_field(v_p_2413, 0));
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  if (!heff_strEq_c_lent(v_t_2416, v_f_241, 0)) {
    heff_drop(v_t_2416);
    V v_t_2419;
    switch (heff_tag_of(v_p_2413)) {
    case TAG_MkPair: {
      V v_y_2418 = heff_field(v_p_2413, 1);
      heff_take_n(v_p_2413, 2ULL, 2);
      v_t_2419 = v_y_2418;
      break;
    }
    default: heff_nomatch(v_p_2413);
    }
    return ({ V a_0 = v_f_241; V b_1 = heff_get_n(v_t_2419, 1, 2); V r_ = (g_list_2eany_24s1795474228x706402294(a_0, b_1)); heff_drop(v_f_241); heff_drop(b_1); r_; });
  } else {
    heff_drop(v_p_2413);
    heff_drop(v_f_241);
    heff_drop(v_t_2416);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = ({ V b_0 = heff_get_n(v_st_240, 1, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2420 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam2, 1, 1, (V[]){v_f_241}), v_t_2412));
  V v_t_2421 = (g_list_2emap_24s1415906091x1371825187(v_t_2420));
  return ({ V a_0 = v_x_2411; V a_1 = v_t_2421; V a_2 = v_hd_249; V a_3 = v_k_2410; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str3, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str4, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str5, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str6, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str7, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str8, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str13, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str14, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str17, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str18, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str19, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str20, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str22, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str23, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str24, 14, "contentChanges");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str25, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str26, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str27, 21, "textDocument/didClose");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str28, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str29, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str30, 31, "textDocument/publishDiagnostics");
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam2, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam4, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_entry, 5, 0};

V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968(V v_st_240, V v_m_241, V v_p_242, V v_z_243, V v_z_244) {
top: ;
  V v_c_245 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(heff_dup(v_p_242)));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam0, 1, 5, (V[]){heff_dup(v_m_241), v_st_240, v_z_243, v_z_244, v_p_242})});
}
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_z_244;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam2(V self, V *args) {
  V v_n_2498 = args[0];
  return v_n_2498;
}
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam3(V self, V *args) {
  V v_x_24105 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2420 = heff_env(self)[1];
  V v_text_2497 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24106 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_st_240, 2)), heff_dup(v_f_2420), heff_intAdd(v_x_24105, MK_INT(200LL))));
  V v_st_24107 = v_st_240;
  V v_f_24108 = v_f_2420;
  V v_text_24109 = v_text_2497;
  HeffT2 v_t_24110 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_24107, 0), v_f_24108));
  V v_s_24121;
  {
    V v_field_24112 = v_t_24110.f[1];
    int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
    if ((v_tag_24111 == ((int64_t)0ULL))) {
      V v_d_24113 = v_field_24112;
      V v_t_24114 = ({ V rv_1 = v_text_24109; V rr_ = heff_rec_reuse_nf(v_d_24113, 1ULL, 2, shape_uri__text, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_d_24115 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_24107, 0), v_f_24108, v_t_24114));
      V v_due_24116 = heff_take_field(v_st_24107, 2);
      V v_project_24117 = heff_take_field(v_st_24107, 3);
      V v_watch_24118 = heff_take_field(v_st_24107, 4);
      V v_shutdown_24119 = heff_take_field(v_st_24107, 5);
      V v_lib_24120 = heff_take_field(v_st_24107, 6);
      v_s_24121 = ({ V rv_0 = v_d_24115; V rv_2 = v_due_24116; V rv_3 = v_project_24117; V rv_4 = v_watch_24118; V rv_5 = v_shutdown_24119; V rv_6 = v_lib_24120; V rr_ = heff_rec_reuse_nf(v_st_24107, 2ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    } else {
      heff_drop(v_f_24108);
      heff_drop(v_text_24109);
      heff_drop(v_field_24112);
      v_s_24121 = v_st_24107;
    }
  }
  V v_project_24122 = heff_take_field(v_s_24121, 3);
  V v_watch_24123 = heff_take_field(v_s_24121, 4);
  V v_shutdown_24124 = heff_take_field(v_s_24121, 5);
  V v_lib_24125 = heff_take_field(v_s_24121, 6);
  V v_t_24126 = ({ V rv_2 = v_t_24106; V rv_3 = v_project_24122; V rv_4 = v_watch_24123; V rv_5 = v_shutdown_24124; V rv_6 = v_lib_24125; V rr_ = heff_rec_reuse_nf(v_s_24121, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_244;
  args[0] = v_t_24126;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam4(V self, V *args) {
  V v_hd_24136 = args[0];
  V v_k_24137 = args[1];
  heff_drop(v_hd_24136);
  V f_ = v_k_24137;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam5(V self, V *args) {
  V v_x_24139 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2420 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24139);
  V v_st_24140 = v_st_240;
  V v_f_24141 = v_f_2420;
  V v_t_24142 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_st_24140, 2), v_f_24141));
  V v_c_24143 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_st_24140, 1), v_f_24141));
  V v_d_24144 = ({ V a_0 = heff_take_field(v_st_24140, 0); V a_1 = v_f_24141; V r_ = (g_std_2eordmap_2edelete_24s2135745297x1725920174(a_0, a_1)); heff_drop(v_f_24141); r_; });
  V v_project_24145 = heff_take_field(v_st_24140, 3);
  V v_watch_24146 = heff_take_field(v_st_24140, 4);
  V v_shutdown_24147 = heff_take_field(v_st_24140, 5);
  V v_x_24148 = ({ V rv_0 = v_d_24144; V rv_1 = v_c_24143; V rv_2 = v_t_24142; V rv_3 = v_project_24145; V rv_4 = v_watch_24146; V rv_5 = v_shutdown_24147; V rr_ = heff_rec_reuse_nf(v_st_24140, 64ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12288u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_z_244;
  args[0] = v_x_24148;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str0), 2)) {
    heff_drop(v_x_246);
    heff_drop(v_m_241);
    heff_drop(v_p_242);
    V v_t_247 = heff_get_n(v_st_240, 5, 7);
    V v_t_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = MK_INT(0LL);
    } else {
      heff_drop(v_t_247);
      v_t_248 = MK_INT(1LL);
    }
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_z_243, v_z_244));
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str1), 2)) {
      heff_drop(v_x_246);
      heff_drop(v_m_241);
      heff_drop(v_p_242);
      V v_t_2414 = heff_dup(heff_rfield(v_st_240, 4));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str2); V b_1 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_json_2ewriteInto(a_0, b_1)); heff_drop(b_1); r_; });
        V v_a_2416 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
        return (g_co_2eop_24s1554102946x910234624(v_a_2416, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam1, 1, 2, (V[]){v_z_244, v_st_240})));
      } else {
        heff_drop_rec(v_z_243, 3);
        heff_drop(v_t_2414);
        V f_ = v_z_244;
        args[0] = v_st_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str3), 2)) {
        heff_drop(v_x_246);
        heff_drop(v_m_241);
        heff_drop(v_p_242);
        V v_t_2418 = (g_std_2eordmap_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
        V v_t_2419 = (g_list_2emap_24s1415906091x1371825187(v_t_2418));
        return ({ V a_0 = v_st_240; V a_1 = v_t_2419; V a_2 = v_z_243; V a_3 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s130603981x878763758(a_0, a_1, a_2, a_3)); heff_drop(v_t_2419); r_; });
      } else {
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nothing: {
          heff_drop(v_m_241);
          heff_drop_rec(v_z_243, 3);
          heff_drop(v_p_242);
          V f_ = v_z_244;
          args[0] = v_st_240;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2420 = heff_field(v_x_246, 0);
          V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str4), 2)) {
            heff_drop(v_m_241);
            heff_drop_cell(v_ru_24x_246_24Just, 1);
            V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str5), NTAG(TAG_Nil)});
            HeffT2 v_t_2422 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str6), v_t_2421}); V a_1 = heff_dup(v_p_242); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2445;
            {
              V v_field_2424 = v_t_2422.f[1];
              int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
              V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str7), NTAG(TAG_Nil)});
              HeffT2 v_t_2426 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str8), v_t_2425}); V a_1 = v_p_242; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2428 = v_t_2426.f[1];
                int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                V v_t_2436;
                if ((v_tag_2423 == ((int64_t)0ULL))) {
                  V v_it1_2429 = v_field_2424;
                  switch (heff_tag_of(v_it1_2429)) {
                  case TAG_JNull: {
                    v_t_2436 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str9);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2429, 0ULL, 1);
                    v_t_2436 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str10);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2429, 0ULL, 1);
                    v_t_2436 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str11);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2429, 0ULL, 1);
                    v_t_2436 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str12);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2433 = heff_field(v_it1_2429, 0);
                    heff_take_n(v_it1_2429, 1ULL, 1);
                    v_t_2436 = v_s_2433;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2429, 0ULL, 1);
                    v_t_2436 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str13);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2429, 0ULL, 1);
                    v_t_2436 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str14);
                    break;
                  }
                  default: heff_nomatch(v_it1_2429);
                  }
                } else {
                  heff_drop(v_field_2424);
                  v_t_2436 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str15);
                }
                V v_t_2444;
                if ((v_tag_2427 == ((int64_t)0ULL))) {
                  V v_it1_2437 = v_field_2428;
                  switch (heff_tag_of(v_it1_2437)) {
                  case TAG_JNull: {
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str16);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str17);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str18);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str19);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2441 = heff_field(v_it1_2437, 0);
                    heff_take_n(v_it1_2437, 1ULL, 1);
                    v_t_2444 = v_s_2441;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str20);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2437, 0ULL, 1);
                    v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str21);
                    break;
                  }
                  default: heff_nomatch(v_it1_2437);
                  }
                } else {
                  heff_drop(v_field_2428);
                  v_t_2444 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str22);
                }
                v_t_2445 = heff_rec_n(2, shape_uri__text, (V[]){v_t_2436, v_t_2444});
              }
            }
            V v_d_2446 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_240, 0), heff_dup(v_f_2420), v_t_2445));
            V v_due_2447 = heff_take_field(v_st_240, 2);
            V v_project_2448 = heff_take_field(v_st_240, 3);
            V v_watch_2449 = heff_take_field(v_st_240, 4);
            V v_shutdown_2450 = heff_take_field(v_st_240, 5);
            V v_lib_2451 = heff_take_field(v_st_240, 6);
            V v_t_2452 = ({ V rv_0 = v_d_2446; V rv_2 = v_due_2447; V rv_3 = v_project_2448; V rv_4 = v_watch_2449; V rv_5 = v_shutdown_2450; V rv_6 = v_lib_2451; V rr_ = heff_rec_reuse_nf(v_st_240, 2ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
            V v_t_2453 = (g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065(v_t_2452, v_f_2420));
            V f_ = v_t_2453;
            heff_room[0] = v_z_243;
            heff_room[1] = v_z_244;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          } else {
            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str23), 2)) {
              heff_drop(v_m_241);
              V v_p_2454 = v_p_242;
              V v_t_2496;
              switch (heff_tag_of(v_p_2454)) {
              case TAG_JNull: {
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2496 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_p_2454, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2496 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_p_2454, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2496 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_p_2454, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2496 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_p_2454, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2496 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_p_2454, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2496 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                V v_fs_2460 = heff_field(v_p_2454, 0);
                heff_take_n(v_p_2454, 1ULL, 1);
                HeffT2 v_t_2461 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str24); V a_1 = v_fs_2460; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2460); r_; });
                {
                  V v_field_2463 = v_t_2461.f[1];
                  int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                  if ((v_tag_2462 == ((int64_t)0ULL))) {
                    V v_p_2464 = v_field_2463;
                    V v_t_2467;
                    switch (heff_tag_of(v_p_2464)) {
                    case TAG_MkPair: {
                      V v_y_2466 = heff_field(v_p_2464, 1);
                      heff_take_n(v_p_2464, 2ULL, 2);
                      v_t_2467 = v_y_2466;
                      break;
                    }
                    default: heff_nomatch(v_p_2464);
                    }
                    switch (heff_tag_of(v_t_2467)) {
                    case TAG_JNull: {
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2496 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JBool: {
                      heff_take_n(v_t_2467, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2496 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JInt: {
                      heff_take_n(v_t_2467, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2496 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JFloat: {
                      heff_take_na(v_t_2467, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2496 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JString: {
                      heff_take_n(v_t_2467, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2496 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JArray: {
                      V v_xs_2472 = heff_field(v_t_2467, 0);
                      heff_take_n(v_t_2467, 1ULL, 1);
                      V v_x1_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2472));
                      switch (heff_tag_of(v_x1_2473)) {
                      case TAG_Nil: {
                        heff_drop_cell(v_ru_24x_246_24Just, 1);
                        v_t_2496 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Cons: {
                        V v_x_2474 = heff_field(v_x1_2473, 0);
                        heff_take_n(v_x1_2473, 1ULL, 2);
                        switch (heff_tag_of(v_x_2474)) {
                        case TAG_JNull: {
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2496 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JBool: {
                          heff_take_n(v_x_2474, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2496 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JInt: {
                          heff_take_n(v_x_2474, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2496 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JFloat: {
                          heff_take_na(v_x_2474, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2496 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JString: {
                          heff_take_n(v_x_2474, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2496 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JArray: {
                          heff_take_n(v_x_2474, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2496 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JObject: {
                          V v_fs_2481 = heff_field(v_x_2474, 0);
                          heff_take_n(v_x_2474, 1ULL, 1);
                          HeffT2 v_t_2482 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str25); V a_1 = v_fs_2481; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2481); r_; });
                          {
                            V v_field_2484 = v_t_2482.f[1];
                            int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
                            if ((v_tag_2483 == ((int64_t)0ULL))) {
                              V v_p_2485 = v_field_2484;
                              V v_t_2488;
                              switch (heff_tag_of(v_p_2485)) {
                              case TAG_MkPair: {
                                V v_y_2487 = heff_field(v_p_2485, 1);
                                heff_take_n(v_p_2485, 2ULL, 2);
                                v_t_2488 = v_y_2487;
                                break;
                              }
                              default: heff_nomatch(v_p_2485);
                              }
                              switch (heff_tag_of(v_t_2488)) {
                              case TAG_JNull: {
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2496 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JBool: {
                                heff_take_n(v_t_2488, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2496 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JInt: {
                                heff_take_n(v_t_2488, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2496 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JFloat: {
                                heff_take_na(v_t_2488, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2496 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JString: {
                                V v_s_2492 = heff_field(v_t_2488, 0);
                                heff_take_n(v_t_2488, 1ULL, 1);
                                v_t_2496 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_Just, 1, (V[]){v_s_2492});
                                break;
                              }
                              case TAG_JArray: {
                                heff_take_n(v_t_2488, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2496 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JObject: {
                                heff_take_n(v_t_2488, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2496 = NTAG(TAG_Nothing);
                                break;
                              }
                              default: heff_nomatch(v_t_2488);
                              }
                            } else {
                              heff_drop_cell(v_ru_24x_246_24Just, 1);
                              heff_drop(v_field_2484);
                              v_t_2496 = NTAG(TAG_Nothing);
                            }
                          }
                          break;
                        }
                        default: heff_nomatch(v_x_2474);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x1_2473);
                      }
                      break;
                    }
                    case TAG_JObject: {
                      heff_take_n(v_t_2467, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2496 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_t_2467);
                    }
                  } else {
                    heff_drop_cell(v_ru_24x_246_24Just, 1);
                    heff_drop(v_field_2463);
                    v_t_2496 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              default: heff_nomatch(v_p_2454);
              }
              switch (heff_tag_of(v_t_2496)) {
              case TAG_Nothing: {
                heff_drop_rec(v_z_243, 3);
                heff_drop(v_f_2420);
                V f_ = v_z_244;
                args[0] = v_st_240;
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
              case TAG_Just: {
                V v_text_2497 = heff_field(v_t_2496, 0);
                V v_ru_24t_2496_24Just = heff_take_reuse_n(v_t_2496, 1ULL, 1);
                V v_t_2499 = heff_tag_at_n(v_ru_24t_2496_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam2_clo)})});
                V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
                V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
                V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
                V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
                V v_t_24104 = heff_tr(heff_call(heff_take_field(v_z_243, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})}));
                V f_ = heff_get_n(v_z_243, 1, 3);
                heff_room[0] = v_t_24104;
                heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam3, 1, 4, (V[]){v_st_240, v_f_2420, v_text_2497, v_z_244});
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
              default: return heff_nomatch(v_t_2496);
              }
            } else {
              heff_drop(v_p_242);
              heff_drop_cell(v_ru_24x_246_24Just, 1);
              if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str26), 2)) {
                heff_drop(v_m_241);
                V v_t_24127 = (g_heff_2elsp_2elsp_2echeckNow_24s87108213x967683065(v_st_240, v_f_2420));
                V f_ = v_t_24127;
                heff_room[0] = v_z_243;
                heff_room[1] = v_z_244;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str27))) {
                  HeffT2 v_t_24128 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_2420));
                  V v_c_24138;
                  {
                    V v_field_24130 = v_t_24128.f[1];
                    int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
                    if ((v_tag_24129 == ((int64_t)0ULL))) {
                      V v_d_24131 = v_field_24130;
                      V v_t_24132 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_d_24131, 0, 2)});
                      V v_t_24133 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
                      V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str28), v_t_24133}), NTAG(TAG_Nil)});
                      V v_t_24135 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str29), v_t_24132}), v_t_24134});
                      v_c_24138 = heff_tr(g_heff_2elsp_2elsp_2enotify_24s996858955x2134234078(((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_str30), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24135})));
                    } else {
                      heff_drop(v_field_24130);
                      v_c_24138 = ((V)&g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam4_clo);
                    }
                  }
                  V f_ = v_c_24138;
                  heff_room[0] = v_z_243;
                  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_lam5, 1, 3, (V[]){v_st_240, v_f_2420, v_z_244});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                } else {
                  heff_drop_rec(v_z_243, 3);
                  heff_drop(v_f_2420);
                  V f_ = v_z_244;
                  args[0] = v_st_240;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_246);
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_entry, 2, 0};

V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_248 = heff_field(v_x21_245, 1);
      V v_c_249 = (g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(v_st_240, heff_dup(v_f_248), NTAG(TAG_Nothing)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam1, 2, 2, (V[]){v_c_249, heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V v_t_244 = heff_rec_n(2, shape_st__program, (V[]){v_st_240, NTAG(TAG_Nil)});
  V f_ = v_k_243;
  args[0] = v_t_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_program_2414 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2417 = heff_take_field(v_x_2416, 0);
  V v_program_2418 = heff_get_n(v_x_2416, 1, 2);
  V v_st_2419 = v_st_2417;
  V v_program_2420 = (g_prelude_2e_2b_2b(v_program_2414, v_program_2418));
  V f_ = v_k_2411;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_2419, v_program_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_2413 = heff_take_field(v_x_2412, 0);
  V v_program_2414 = heff_get_n(v_x_2412, 1, 2);
  V v_c_2415 = ({ V a_0 = v_st_2413; V a_1 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066(a_0, a_1)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2415;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam3, 1, 2, (V[]){v_program_2414, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_lam2, 1, 3, (V[]){v_rest_246, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}