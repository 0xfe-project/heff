// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_UriPath 39251
#define LBL_at 9882
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_end 310101
#define LBL_local 304503685
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2ekeepIf_24s1441124185x871809048(V, V);
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_clo;
V g_list_2ekeepIf_24s647917584x875728492(V, V);
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_j_242, v_i_241, 0) || heff_intLe_c(heff_strLength_lent(v_src_240, 0), heff_dup(v_i_241)))) {
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_n_243;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      HeffT2 v_t_244 = heff_strRuneDecode_lent(v_src_240, v_i_241, 0);
      {
        V v_rune_245 = v_t_244.f[0];
        V v_width_246 = v_t_244.f[1];
        V v_t_247;
        if (heff_intLe_c(MK_INT(65536LL), heff_runeToInt(v_rune_245))) {
          v_t_247 = MK_INT(2LL);
        } else {
          v_t_247 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, v_width_246);
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, v_t_247);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eunits16Go(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c_lent(v_line_241, v_l_244, 0)) {
    heff_drop(v_line_241);
    heff_drop(v_l_244);
    V v_d_245 = heff_strLength_lent(v_src_240, 0);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), v_src_240, v_i_243, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_247 = v_d_245;
    } else {
      heff_drop(v_d_245);
      v_t_247 = v_j_246;
    }
    return (g_heff_2elsp_2elsp_2eoffset16(v_src_240, v_i_243, v_t_247, v_ch_242));
  } else {
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), v_src_240, v_i_243, 5);
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_line_241);
      heff_drop(v_ch_242);
      heff_drop(v_l_244);
      heff_drop(v_j_248);
      return heff_strLength_lent(v_src_240, 0);
    } else {
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_j_248, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetGo(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 5, "range");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_span_242 = heff_take_field(v_d_241, 3);
  V v_severity_243 = heff_take_field(v_d_241, 1);
  V v_note_244 = heff_take_field(v_d_241, 4);
  V v_msg_245 = heff_take_field(v_d_241, 2);
  V v_code_246 = heff_get_n(v_d_241, 0, 5);
  V v_t_247 = (g_heff_2elsp_2elsp_2erange(v_src_240, v_span_242));
  V v_t_248;
  switch (heff_tag_of(v_severity_243)) {
  case TAG_SError: {
    v_t_248 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_248 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_248 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_severity_243);
  }
  V v_t_2410;
  switch (heff_tag_of(v_note_244)) {
  case TAG_Nothing: {
    v_t_2410 = v_msg_245;
    break;
  }
  case TAG_Just: {
    V v_n_249 = heff_field(v_note_244, 0);
    heff_take_n(v_note_244, 1ULL, 1);
    v_t_2410 = heff_strAppend(heff_strAppend(v_msg_245, ((V)&g_heff_2elsp_2elsp_2ediagnostic_str0)), v_n_249);
    break;
  }
  default: heff_nomatch(v_note_244);
  }
  V v_ys_2416;
  if (heff_intEq_c_lent(v_code_246, MK_INT(0LL), 2)) {
    heff_drop(v_severity_243);
    heff_drop(v_code_246);
    v_ys_2416 = NTAG(TAG_Nil);
  } else {
    V v_t_2411;
    switch (heff_tag_of(v_severity_243)) {
    case TAG_SError: {
      v_t_2411 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str1);
      break;
    }
    case TAG_SWarning: {
      v_t_2411 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str2);
      break;
    }
    case TAG_SDebug: {
      v_t_2411 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str3);
      break;
    }
    default: heff_nomatch(v_severity_243);
    }
    V v_t_2412 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_246)));
    V v_t_2413 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2412), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str4)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2411, v_t_2413), heff_intShow(v_code_246));
    V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), heff_tag_n(TAG_JString, 1, (V[]){v_t_2414})});
    v_ys_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  }
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_t_248})});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str7), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str8)})});
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str9), heff_tag_n(TAG_JString, 1, (V[]){v_t_2410})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_ys_2416})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), v_t_247}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2420})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2421});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ediagnostic(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2elsp_2ecatMaybesL_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str2, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str3, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str4, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str5, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2edeclsGo_24dps(V v_x1_240, V v_key_241, V v_above_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_key_241);
    heff_drop(v_above_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_246 = heff_take_field(v_l_244, 1);
    V v_at_247 = heff_get_n(v_l_244, 0, 2);
    V v_l_248 = heff_dup(v_text_246);
    if ((heff_strEq_c(heff_strSlice_lent(v_l_248, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str0)) || heff_strEq_c(heff_strSlice_lent(v_l_248, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str1)))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_text_246);
      heff_drop(v_l_248);
      V v_t_2410;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_2410 = v_at_247;
        break;
      }
      case TAG_Just: {
        V v_x_249 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop(v_at_247);
        v_t_2410 = v_x_249;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_245;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
      V t_3 = v_d_243;
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_l_248);
      V v_l_2411 = heff_dup(v_text_246);
      V v_t_2415;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_2411, 0)))) {
        if (((heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : !(heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)13ULL))))) {
          if ((heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str2)) ? 0 : !heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str3)))) {
            V v_t_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2411, MK_INT(0LL)));
            V v_x1_2414 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), v_t_2412, 2), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str4)) || ({ V v_t_2413 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2411, MK_INT(0LL))); int c_ = ({ V v_t_2429 = heff_strSlice_lent(v_l_2411, MK_INT(0LL), v_t_2413, 2); int c_ = heff_strEq_c_lent(v_t_2429, ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str5), 2); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2413); c_; })));
            heff_drop(v_l_2411);
            heff_drop(v_t_2412);
            v_t_2415 = heff_bool(!(heff_dup(v_x1_2414) == NTAG(TAG_True)));
            heff_drop(v_x1_2414);
          } else {
            heff_drop(v_l_2411);
            v_t_2415 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l_2411);
          v_t_2415 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_l_2411);
        v_t_2415 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = (g_heff_2elsp_2elsp_2ekeyOf(v_text_246));
        V v_x1_2417 = heff_bool(heff_strEq_c_lent(v_t_2416, v_key_241, 0));
        heff_drop(v_t_2416);
        if (!(heff_dup(v_x1_2417) == NTAG(TAG_True))) {
          heff_drop(v_key_241);
          heff_drop(v_x1_2417);
          V v_cut_2419;
          switch (heff_tag_of(v_above_242)) {
          case TAG_Nothing: {
            v_cut_2419 = heff_dup(v_at_247);
            break;
          }
          case TAG_Just: {
            V v_x_2418 = heff_field(v_above_242, 0);
            heff_take_n(v_above_242, 1ULL, 1);
            v_cut_2419 = v_x_2418;
            break;
          }
          default: heff_nomatch(v_above_242);
          }
          V v_n_2420 = v_at_247;
          HeffT2 v_t_2421 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_text_246));
          V v_t_2425;
          {
            V v_field_2422 = v_t_2421.f[0];
            V v_field_2423 = v_t_2421.f[1];
            V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_field_2422, heff_dup(v_n_2420)), heff_intAdd(v_field_2423, v_n_2420)});
            v_t_2425 = heff_rec_n(2, shape_cut__name, (V[]){v_cut_2419, v_t_2424});
          }
          V v_cell_2426 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
          V v_u_2427 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2426));
          heff_drop(v_u_2427);
          V v_t_2428 = ({ V a_0 = v_text_246; V r_ = (g_heff_2elsp_2elsp_2ekeyOf(a_0)); heff_drop(v_text_246); r_; });
          V t_0 = v_rest_245;
          V t_1 = v_t_2428;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_cell_2426;
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          v_d_243 = t_3;
          goto top;
        } else {
          heff_drop(v_above_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_text_246);
          heff_drop(v_at_247);
          heff_drop(v_x1_2417);
          V t_0 = v_rest_245;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_d_243;
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
      } else {
        heff_drop(v_above_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_text_246);
        heff_drop(v_at_247);
        heff_drop(v_t_2415);
        V t_0 = v_rest_245;
        V t_1 = v_key_241;
        V t_2 = NTAG(TAG_Nothing);
        V t_3 = v_d_243;
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edeclsGo_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubSources_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_s_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s1441124185x871809048(v_s_242, v_ss_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubSources_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s647917584x875728492(v_c_241, v_cs_242));
    V v_u_245 = (g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_c_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s647917584x875728492(v_c_242, v_cs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubRoots_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_r_242; V a_1 = v_rs_243; V r_ = (g_list_2ekeepIf_24s689992630x418898235(a_0, a_1)); heff_drop(v_r_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str2, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str3, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 25, "client/registerCapability");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str6, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str7, 10, "heff-watch");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str10, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str11, 7, "**/*.hf");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 6, "params");

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  V v_t_240 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str1)})});
  V v_t_241 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str2), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str3)})});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str5)})});
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str6), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str7)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str8), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str9)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str10), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str11)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str12), heff_tag_n(TAG_JArray, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str13), heff_tag_n(TAG_JObject, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eregistration_str15), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_2417})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_2418})});
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam2, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam3, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam4, 1, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam5, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam6, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam7, 2, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(V v_e_240, V v_p_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_str1), v_t_242}); V a_1 = v_p_241; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_245;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        heff_drop(v_e_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam0_clo);
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_e_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam1_clo);
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_e_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam2_clo);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        heff_drop(v_e_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam3_clo);
      }
      case TAG_JString: {
        V v_s_2418 = heff_field(v_it1_246, 0);
        V v_ru_24it1_246_24JString = heff_take_reuse_n(v_it1_246, 1ULL, 1);
        V v_t_2420 = heff_tag_at_n(v_ru_24it1_246_24JString, TAG_InR, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_s_2418, ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam4_clo)})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
        return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
      }
      case TAG_JArray: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_e_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam5_clo);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_e_240);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam6_clo);
      }
      default: return heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_e_240);
      heff_drop(v_field_245);
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam7_clo);
    }
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam4(V self, V *args) {
  V v_p_2419 = args[0];
  return v_p_2419;
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam5(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam6(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_lam7(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_entry, 8, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2(V v_tok_240, V v_e_241, V v_a_242, V v_f_243, V v_off_244, V v_t_245, V v_z_246, V v_z_247) {
top: ;
  V v_target_248 = heff_take_field(v_t_245, 0);
  V v_name_249 = heff_get_n(v_t_245, 1, 2);
  V v_st_2410 = heff_take_field(v_a_242, 0);
  V v_program_2411 = heff_get_n(v_a_242, 2, 3);
  V v_t_2412 = heff_dup(heff_rfield(v_target_248, 2));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_t_2413 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_name_249), NTAG(TAG_Nil)});
    V v_c_2414 = (g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(v_e_241, v_st_2410, heff_dup(v_f_243), heff_tag_n(TAG_Just, 1, (V[]){v_t_2413})));
    return heff_tail(v_c_2414, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_lam0, 1, 6, (V[]){v_name_249, v_program_2411, v_target_248, v_f_243, v_z_247, v_off_244})});
  }
  case TAG_Just: {
    V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_e_241);
    heff_drop(v_z_246);
    V v_name_2425 = heff_dup(v_name_249);
    V v_occurrences_2426 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_2411, heff_dup(v_target_248), v_name_249));
    V v_target_2427 = heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_243, v_target_248, v_name_2425, v_occurrences_2426})});
    return heff_tail(v_z_247, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_2410, v_off_244, v_target_2427})});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_24tok2_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_name_249 = heff_env(self)[0];
  V v_program_2411 = heff_env(self)[1];
  V v_target_248 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_off_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_program_2416 = heff_take_field(v_x_2415, 1);
  V v_st_2417 = heff_get_n(v_x_2415, 0, 2);
  V v_name_2418 = heff_dup(v_name_249);
  V v_t_2421;
  switch (heff_tag_of(v_program_2416)) {
  case TAG_Nil: {
    v_t_2421 = v_program_2411;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_program_2411);
    v_t_2421 = v_program_2416;
    break;
  }
  default: heff_nomatch(v_program_2416);
  }
  V v_occurrences_2422 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2421, heff_dup(v_target_248), v_name_249));
  V v_target_2423 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_243, v_target_248, v_name_2418, v_occurrences_2422})});
  V f_ = v_z_247;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2417, v_off_244, v_target_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}