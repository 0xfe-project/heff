// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_start 311115900
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get(void);
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_str0, 8, "gathered");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_str1, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(V v_sp_240) {
top: ;
  V v_t_241 = heff_intShow(heff_get_n(v_sp_240, 0, 2));
  return heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_str1), v_t_241));
}
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_str0, 4, "turn");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_str1, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(V v_sp_240) {
top: ;
  V v_t_241 = heff_intShow(heff_get_n(v_sp_240, 0, 2));
  return heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_str1), v_t_241));
}
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_str0, 112, "a `for` whose turns are gathered, `p <- for ...`, ends each turn in a value: its last statement is an expression");

static V g_heff_2esyntax_2epresyntax_2egathered_2eends_242_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2egathered_2eends_242_st;
static V g_heff_2esyntax_2epresyntax_2egathered_2eends_242_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2egathered_2eends_242_str0);
}
V g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_st)) return g_heff_2esyntax_2epresyntax_2egathered_2eends_242_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2egathered_2eends_242_val, &g_heff_2esyntax_2epresyntax_2egathered_2eends_242_st, g_heff_2esyntax_2epresyntax_2egathered_2eends_242_init);
}