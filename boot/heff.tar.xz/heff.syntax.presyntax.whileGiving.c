// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_ELam 43266
#define TAG_EReturn 59059
#define LBL_depth 296830685
#define LBL_giving 701566649
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo;
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V v_cx_240, V v_c_241, V v_body_242) {
top: ;
  V v_ret_2417;
  switch (heff_tag_of(v_c_241)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_c_241, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_ELam: {
      heff_take_n(v_e1_243, 0ULL, 2);
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        heff_take_n(v_c_241, 0ULL, 2);
        v_ret_2417 = (g_list_2eany_24s2003678755x1820404042(v_body_242));
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      break;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_243, 0ULL, 1);
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        heff_take_n(v_c_241, 0ULL, 2);
        v_ret_2417 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      break;
    }
    default: {
      heff_drop(v_e1_243);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_c_241));
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_x_2415 = v_field_2413;
        V v_y_2416 = v_field_2414;
        heff_drop(v_y_2416);
        if ((heff_dup(v_x_2415) == NTAG(TAG_True))) {
          heff_drop(v_x_2415);
          v_ret_2417 = NTAG(TAG_True);
        } else {
          heff_drop(v_x_2415);
          v_ret_2417 = (g_list_2eany_24s2003678755x1820404042(v_body_242));
        }
      }
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  return ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_ret_2417}); V rr_ = heff_rec_reuse_nf(v_cx_240, 31ULL, 6, shape_names__muts__loop__sp__depth__giving, 1023u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(a[0], a[1], a2); heff_drop(a2); return r;
}