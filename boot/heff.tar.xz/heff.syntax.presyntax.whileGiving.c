// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EVar 52881
#define LBL_depth 296830685
#define LBL_giving 701566649
#define LBL_head 9693863
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
V g_heff_2esyntax_2epresyntax_2ehasReturn(V);
V g_heff_2esyntax_2epresyntax_2ehasReturn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasReturn_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240_clo;
V g_list_2eany_24s1414887908x732433189(V);
V g_list_2eany_24s1414887908x732433189_entry(V self, V *a);
extern Clo g_list_2eany_24s1414887908x732433189_clo;
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240(V v_c_240, V v_body_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2epresyntax_2ehasReturn(v_c_240));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_242);
    return (g_list_2eany_24s1414887908x732433189(v_body_241));
  }
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ewhileGiving_2eret_240(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V v_cx_240, V v_c_241, V v_body_242) {
top: ;
  V v_names_243 = heff_take_field(v_cx_240, 0);
  V v_muts_244 = heff_take_field(v_cx_240, 1);
  V v_loop_245 = heff_take_field(v_cx_240, 2);
  V v_sp_246 = heff_take_field(v_cx_240, 3);
  V v_depth_247 = heff_get_n(v_cx_240, 4, 6);
  V v_t_248 = (g_heff_2esyntax_2epresyntax_2ehasReturn(v_c_241));
  V v_ret_249;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_ret_249 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_248);
    v_ret_249 = (g_list_2eany_24s1414887908x732433189(v_body_242));
  }
  return heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){v_names_243, v_muts_244, v_loop_245, v_sp_246, v_depth_247, heff_tag_n(TAG_Just, 1, (V[]){v_ret_249})});
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr_str0, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr_str1, 1, "#");

HeffT4 g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr(V v_sp_240, V v_cx_241) {
top: ;
  V v_muts_242 = heff_take_field(v_cx_241, 1);
  V v_depth_243 = heff_get_n(v_cx_241, 4, 6);
  V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr_str1), v_t_244));
  V v_f_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_245}), v_sp_240});
  V v_f_247 = v_muts_242;
  V v_f_248 = v_depth_243;
  return ((HeffT4){{v_f_246, v_f_247, NTAG(TAG_True), v_f_248}});
}
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242(V v_sp_240, V v_cx_241) {
top: ;
  HeffT4 v_t_242 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_24cpr(v_sp_240, v_cx_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    return heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_field_243, v_field_244, v_field_245, v_field_246});
  }
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewhileGiving_2eloopJ_242(a[0], a[1]);
}