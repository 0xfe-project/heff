// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Value 50841
#define LBL_limit 304334805
#define LBL_next 9873338
#define LBL_outcome 1272833429
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_top 324559
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_clo;
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_clo;
V g_heff_2ebuild_2etesting_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2etesting_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranOutcome_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo;
V g_heff_2ebuild_2etesting_2esubtestsOfJson(V);
V g_heff_2ebuild_2etesting_2esubtestsOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestsOfJson_clo;
V g_json_2esteps(V, V);
V g_json_2esteps_entry(V self, V *a);
extern Clo g_json_2esteps_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str1, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str2, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str3, 3, " / ");
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0(V v_dir_240, V v_hd_241, V v_j_242, V v_ran_243, V v_sel_244, V v_k_245, V v_x_246) {
top: ;
  V v_x_249;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    heff_take_n(v_x_246, 0ULL, 1);
    v_x_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_248 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Right = heff_take_reuse_n(v_x_246, 1ULL, 1);
    v_x_249 = heff_tag_at_n(v_ru_24x_246_24Right, TAG_Just, 1, (V[]){v_y_248});
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str0))));
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
  V v_a_2413 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam0_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, v_hd_241, heff_clo_n(g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam1, 1, 5, (V[]){v_j_242, v_ran_243, v_x_249, heff_dup(v_sel_244), v_k_245})));
}
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_j_242 = heff_env(self)[0];
  V v_ran_243 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_sel_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    heff_take_n(v_x_2419, 0ULL, 1);
    V v_t_2421 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str1), heff_dup(heff_rfield(v_j_242, 3)), heff_rfield(v_j_242, 4)));
    heff_clo_take(self, 5);
    V v_t_2422 = (g_heff_2ebuild_2etesting_2eranOutcome(v_t_2421, heff_dup(heff_rfield(v_j_242, 5)), v_ran_243, heff_dup(v_x_249)));
    V v_t_2426;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_text_2423 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      V v_t_2424 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      V v_t_2425 = (g_json_2esteps(v_text_2423, v_t_2424));
      v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2ebuild_2etesting_2esubtestsOfJson(a_0)); heff_drop(v_t_2425); r_; });
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2427 = ({ V a_0 = v_sel_244; V a_1 = heff_dup(v_j_242); V a_2 = MK_INT(0LL); V a_3 = v_t_2426; V r_ = (g_heff_2ebuild_2etesting_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_244); r_; });
    V v_x_2428 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_242, 0), heff_get_n(v_j_242, 2, 6), v_t_2422, v_t_2427});
    V f_ = v_k_245;
    args[0] = v_x_2428;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2429)) {
    case TAG_Left: {
      heff_take_n(v_y_2429, 0ULL, 1);
      V v_t_2431 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str2), heff_dup(heff_rfield(v_j_242, 3)), heff_rfield(v_j_242, 4)));
      heff_clo_take(self, 5);
      V v_t_2432 = (g_heff_2ebuild_2etesting_2eranOutcome(v_t_2431, heff_dup(heff_rfield(v_j_242, 5)), v_ran_243, heff_dup(v_x_249)));
      V v_t_2436;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_text_2433 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        V v_t_2434 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        V v_t_2435 = (g_json_2esteps(v_text_2433, v_t_2434));
        v_t_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2ebuild_2etesting_2esubtestsOfJson(a_0)); heff_drop(v_t_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2437 = ({ V a_0 = v_sel_244; V a_1 = heff_dup(v_j_242); V a_2 = MK_INT(0LL); V a_3 = v_t_2436; V r_ = (g_heff_2ebuild_2etesting_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_244); r_; });
      V v_x_2438 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_242, 0), heff_get_n(v_j_242, 2, 6), v_t_2432, v_t_2437});
      V f_ = v_k_245;
      args[0] = v_x_2438;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2429, 0ULL, 1);
      V v_t_2440 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0_str3), heff_dup(heff_rfield(v_j_242, 3)), heff_rfield(v_j_242, 4)));
      heff_clo_take(self, 5);
      V v_t_2441 = (g_heff_2ebuild_2etesting_2eranOutcome(v_t_2440, heff_dup(heff_rfield(v_j_242, 5)), v_ran_243, heff_dup(v_x_249)));
      V v_t_2445;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_text_2442 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        V v_t_2443 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        V v_t_2444 = (g_json_2esteps(v_text_2442, v_t_2443));
        v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2ebuild_2etesting_2esubtestsOfJson(a_0)); heff_drop(v_t_2444); r_; });
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2446 = ({ V a_0 = v_sel_244; V a_1 = heff_dup(v_j_242); V a_2 = MK_INT(0LL); V a_3 = v_t_2445; V r_ = (g_heff_2ebuild_2etesting_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_244); r_; });
      V v_x_2447 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_242, 0), heff_get_n(v_j_242, 2, 6), v_t_2441, v_t_2446});
      V f_ = v_k_245;
      args[0] = v_x_2447;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2429);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_str0, 8, ".outcome");
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_entry, 7, 0};

V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1(V v_dir_240, V v_hd_241, V v_j_242, V v_ran_243, V v_sel_244, V v_k_245, V v_x_246) {
top: ;
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_str0))));
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam0_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2415, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam1, 1, 6, (V[]){v_dir_240, v_hd_241, v_j_242, v_ran_243, heff_dup(v_sel_244), v_k_245})));
}
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1(a[0], a[1], a[2], a[3], a4, a[5], a6); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l1_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_dir_240; V a_1 = v_hd_241; V a_2 = v_j_242; V a_3 = v_ran_243; V a_4 = v_sel_244; V a_5 = v_k_245; V a_6 = heff_tag_re_n(v_ru_24x_2416_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2417}); V r_ = (g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sel_244); r_; });
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2418)) {
    case TAG_Left: {
      V v_err_2419 = heff_field(v_y_2418, 0);
      V v_ru_24y_2418_24Left = heff_take_reuse_n(v_y_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2416_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_dir_240; V a_1 = v_hd_241; V a_2 = v_j_242; V a_3 = v_ran_243; V a_4 = v_sel_244; V a_5 = v_k_245; V a_6 = heff_tag_re_n(v_ru_24y_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2419}); V r_ = (g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sel_244); r_; });
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_y_2418, 0);
      heff_take_n(v_y_2418, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_dir_240; V a_1 = v_hd_241; V a_2 = v_j_242; V a_3 = v_ran_243; V a_4 = v_sel_244; V a_5 = v_k_245; V a_6 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Right, 1, (V[]){v_x_2420}); V r_ = (g_heff_2ebuild_2etesting_2eendedJob_24s450964544x80782992_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sel_244); r_; });
    }
    default: return heff_nomatch(v_y_2418);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}