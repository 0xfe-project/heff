// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_Perform 19235
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_clo;
V g_heff_2ecompile_2emonadic_2ebindAs(V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_clo;
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(V, V, V, V);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_clo;
V g_heff_2ecompile_2emonadic_2ebindAtom(V, V);
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo;
V g_heff_2ecompile_2emonadic_2ebindScrut(V, V);
V g_heff_2ecompile_2emonadic_2ebindScrut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2ebindScrut_clo;
V g_heff_2ecompile_2emonadic_2econdN(V, V, V);
V g_heff_2ecompile_2emonadic_2econdN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2econdN_clo;
V g_heff_2ecompile_2emonadic_2eflatLet(V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_clo;
V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V, V, V, V);
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo;
V g_heff_2ecompile_2emonadic_2einPlace(V);
V g_heff_2ecompile_2emonadic_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2einPlace_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2emonadic_2eoperandsWith(V, V, V);
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo;
V g_heff_2ecompile_2emonadic_2evalue(V);
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2evalue_clo;
V g_list_2eall_24s1139804755x744724287(V);
V g_list_2eall_24s1139804755x744724287_entry(V self, V *a);
extern Clo g_list_2eall_24s1139804755x744724287_clo;
V g_list_2eall_24s1562730082x1519471820(V);
V g_list_2eall_24s1562730082x1519471820_entry(V self, V *a);
extern Clo g_list_2eall_24s1562730082x1519471820_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2etraverse_24s646322350x1809881141(V);
V g_prelude_2etraverse_24s646322350x1809881141_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s646322350x1809881141_clo;
Clo g_heff_2ecompile_2emonadic_2evalue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2evalue_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2evalue(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EBytes: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EBool: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ESet: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EValues: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2evalue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2evalue(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2emonadic_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2einPlace_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2einPlace(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_ERecord: {
    V v_fs_24166 = heff_field(v_x1_240, 0);
    V v_t_24168 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_24166)));
    return ({ V a_0 = v_t_24168; V r_ = (g_list_2eall_24s1139804755x744724287(a_0)); heff_drop(v_t_24168); r_; });
  }
  case TAG_EProj: {
    V v_e_24169 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_e_24169)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_24169);
    }
  }
  case TAG_ETag: {
    V v_args_24213 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_list_2eall_24s1139804755x744724287(v_args_24213);
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EPrimCall: {
    V v_p_24296 = heff_field(v_x1_240, 0);
    V v_args_24297 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_p_24296)) {
    case TAG_IntShl: {
      return NTAG(TAG_False);
    }
    case TAG_IntShr: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndex: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayGenerate: {
      return NTAG(TAG_False);
    }
    case TAG_Keep: {
      return NTAG(TAG_False);
    }
    case TAG_Perform: {
      return NTAG(TAG_False);
    }
    default: {
      HEFF_LAST return g_list_2eall_24s1562730082x1519471820(v_args_24297);
    }
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EBytes: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EBool: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_ESet: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EValues: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EBytes: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2emonadic_2einPlace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2emonadic_2einPlace(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_lam2(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAs(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_ELet: {
    V v_y_242 = heff_field(v_e_240, 0);
    V v_c_243 = heff_field(v_e_240, 1);
    V v_d_244 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_d_244, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam0, 1, 3, (V[]){v_m_245, v_y_242, v_c_243});
  }
  case TAG_ESet: {
    V v_ys_2410 = heff_field(v_e_240, 0);
    V v_c_2411 = heff_field(v_e_240, 1);
    V v_d_2412 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_d_2412, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam1, 1, 3, (V[]){v_m_2413, v_ys_2410, v_c_2411});
  }
  default: {
    V v_t_2418 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_240));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_242, v_c_243, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ys_2410 = heff_env(self)[1];
  V v_c_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2410, v_c_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_lam2(V self, V *args) {
  V v_n_2419 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_str0), heff_intShow(heff_dup(v_n_2419)));
  V v_m_2421 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2420)})}));
  V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){heff_intAdd(v_n_2419, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2420, v_e_240, v_x_2423}), v_n_2424});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAtom_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAtom_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindAtom(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_ELet: {
    V v_y_242 = heff_field(v_e_240, 0);
    V v_c_243 = heff_field(v_e_240, 1);
    V v_d_244 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_245 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_244, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam0, 1, 3, (V[]){v_m_245, v_y_242, v_c_243});
  }
  case TAG_ESet: {
    V v_ys_2410 = heff_field(v_e_240, 0);
    V v_c_2411 = heff_field(v_e_240, 1);
    V v_d_2412 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAtom(v_d_2412, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam1, 1, 3, (V[]){v_m_2413, v_ys_2410, v_c_2411});
  }
  default: {
    V v_t_2457;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    } else {
      heff_drop(v_t_2457);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAtom_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAtom(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_y_242 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_242, v_c_243, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ys_2410 = heff_env(self)[1];
  V v_c_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2410, v_c_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAtom_lam2(V self, V *args) {
  V v_n_2458 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2459 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAtom_str0), heff_intShow(heff_dup(v_n_2458)));
  V v_m_2460 = heff_tr(heff_call(v_k_241, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2459)})}));
  V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){heff_intAdd(v_n_2458, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_n_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2459, v_e_240, v_x_2462}), v_n_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2eoperandsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eoperandsWith_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2eoperandsWith(V v_go_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_243}));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam0, 1, 4, (V[]){v_m_245, v_go_240, v_rest_244, v_k_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eoperandsWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam2(V self, V *args) {
  V v_rest_27_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_a_27_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_27_2410, v_rest_27_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam1(V self, V *args) {
  V v_a_27_2410 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith(v_go_240, v_rest_244, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam2, 1, 2, (V[]){v_k_242, v_a_27_2410})));
}
V g_heff_2ecompile_2emonadic_2eoperandsWith_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2412 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_248, heff_clo_n(g_heff_2ecompile_2emonadic_2eoperandsWith_lam1, 1, 3, (V[]){v_go_240, v_rest_244, v_k_242})));
    V f_ = v_t_2412;
    args[0] = v_n_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2eflatLet(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_a_241, 0);
    V v_c_2410 = heff_field(v_a_241, 1);
    V v_d_2411 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2412 = heff_tag_at_n(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_249, v_c_2410, heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2emonadic_2eflatLet_24dps(v_x_240, v_d_2411, v_b_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EBool: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ESet: {
    V v_ys_2438 = heff_field(v_a_241, 0);
    V v_c_2439 = heff_field(v_a_241, 1);
    V v_d_2440 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ESet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2441 = heff_tag_at_n(v_ru_24a_241_24ESet, TAG_ESet, 3, (V[]){v_ys_2438, v_c_2439, heff_hole()});
    V v_u_2442 = (g_heff_2ecompile_2emonadic_2eflatLet_24dps(v_x_240, v_d_2440, v_b_242, heff_dup(v_cell_2441)));
    heff_drop(v_u_2442);
    return v_cell_2441;
  }
  case TAG_EValues: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eflatLet(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2emonadic_2eflatLet_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2eflatLet_24dps(V v_x_240, V v_a_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EGlobal: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELam: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EApp: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_241, 0);
    V v_c_2411 = heff_field(v_a_241, 1);
    V v_d_2412 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2413 = heff_tag_at_n(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_2410, v_c_2411, heff_hole()});
    V v_u_2414 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_x_240;
    V t_1 = v_d_2412;
    V t_2 = v_b_242;
    V t_3 = v_cell_2413;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EProj: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ETag: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EMatch: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrim: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EPrimCall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ECall: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EInt: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EStr: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBytes: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFixed: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFloat32: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EBool: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_ESet: {
    V v_ys_2439 = heff_field(v_a_241, 0);
    V v_c_2440 = heff_field(v_a_241, 1);
    V v_d_2441 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ESet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    V v_cell_2442 = heff_tag_at_n(v_ru_24a_241_24ESet, TAG_ESet, 3, (V[]){v_ys_2439, v_c_2440, heff_hole()});
    V v_u_2443 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2442));
    heff_drop(v_u_2443);
    V t_0 = v_x_240;
    V t_1 = v_d_2441;
    V t_2 = v_b_242;
    V t_3 = v_cell_2442;
    v_x_240 = t_0;
    v_a_241 = t_1;
    v_b_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  case TAG_EFix: {
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242}));
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2emonadic_2eflatLet_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2eflatLet_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2emonadic_2ebindScrut_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindScrut_lam1(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindScrut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindScrut_entry, 2, 0};

V g_heff_2ecompile_2emonadic_2ebindScrut(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_ELet: {
    V v_y_248 = heff_field(v_e_240, 0);
    V v_c_249 = heff_field(v_e_240, 1);
    V v_d_2410 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2411 = heff_tr(g_heff_2ecompile_2emonadic_2ebindScrut(v_d_2410, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindScrut_lam0, 1, 3, (V[]){v_m_2411, v_y_248, v_c_249});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EBool: {
    V v_c_2439 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return heff_tail(v_k_241, 1, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_c_2439})});
  }
  case TAG_ESet: {
    V v_ys_2440 = heff_field(v_e_240, 0);
    V v_c_2441 = heff_field(v_e_240, 1);
    V v_d_2442 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2443 = heff_tr(g_heff_2ecompile_2emonadic_2ebindScrut(v_d_2442, v_k_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindScrut_lam1, 1, 3, (V[]){v_m_2443, v_ys_2440, v_c_2441});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2emonadic_2ebindAtom(v_e_240, v_k_241);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2emonadic_2ebindScrut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindScrut(a[0], a[1]);
}
V g_heff_2ecompile_2emonadic_2ebindScrut_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_y_248 = heff_env(self)[1];
  V v_c_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_248, v_c_249, v_x_2414}), v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2emonadic_2ebindScrut_lam1(V self, V *args) {
  V v_n_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_ys_2440 = heff_env(self)[1];
  V v_c_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_n_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_n_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2440, v_c_2441, v_x_2446}), v_n_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2econdN_lam7(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2econdN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2econdN_entry, 3, 0};

V g_heff_2ecompile_2emonadic_2econdN(V v_go_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){v_x2_241});
  }
  case TAG_CFalse: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){v_x2_241});
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    V v_b_245 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_244}));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam0, 1, 5, (V[]){v_m_246, v_go_240, v_b_245, v_k_242, v_p_243});
  }
  case TAG_CTest: {
    V v_e_2420 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2421 = heff_tr(heff_call(v_go_240, 1, (V[]){v_e_2420}));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam4, 1, 2, (V[]){v_m_2421, v_k_242});
  }
  case TAG_CNot: {
    V v_c_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_go_240;
    V t_1 = v_c_2428;
    V t_2 = heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam6, 1, 1, (V[]){v_k_242});
    v_go_240 = t_0;
    v_x2_241 = t_1;
    v_k_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2430 = heff_field(v_x2_241, 0);
    V v_b_2431 = heff_field(v_x2_241, 1);
    V v_c_2432 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V t_0 = heff_dup(v_go_240);
    V t_1 = v_a_2430;
    V t_2 = heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam7, 1, 4, (V[]){v_go_240, v_b_2431, v_c_2432, v_k_242});
    v_go_240 = t_0;
    v_x2_241 = t_1;
    v_k_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2econdN(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2emonadic_2econdN_lam3(V self, V *args) {
  V v_a_27_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_a_27_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_a_27_2411, v_a_27_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2econdN_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_a_27_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    V v_t_2418 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_2415, heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam3, 1, 3, (V[]){v_k_242, v_p_243, v_a_27_2411})));
    V f_ = v_t_2418;
    args[0] = v_n_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam1(V self, V *args) {
  V v_a_27_2411 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_m_2412 = heff_tr(heff_call(v_go_240, 1, (V[]){v_b_245}));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam2, 1, 4, (V[]){v_m_2412, v_k_242, v_p_243, v_a_27_2411});
}
V g_heff_2ecompile_2emonadic_2econdN_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_b_245 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    V v_t_2419 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_249, heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam1, 1, 4, (V[]){v_go_240, v_b_245, v_k_242, v_p_243})));
    V f_ = v_t_2419;
    args[0] = v_n_2410;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam5(V self, V *args) {
  V v_e2_2426 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_CTest, 1, (V[]){v_e2_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2econdN_lam4(V self, V *args) {
  V v_n_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_n_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    V v_t_2427 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_2424, heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam5, 1, 1, (V[]){v_k_242})));
    V f_ = v_t_2427;
    args[0] = v_n_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam6(V self, V *args) {
  V v_c2_2429 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_CNot, 1, (V[]){v_c2_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2emonadic_2econdN_lam8(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_c_2432 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_a2_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    heff_take_n(v_x2_2436, 3ULL, 2);
    V v_m_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(v_go_240, v_c_2432));
    V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2438}));
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_MkPair: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_n_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      V f_ = v_k_242;
      heff_room[0] = heff_tag_n(TAG_CIf, 3, (V[]){v_a2_2433, v_x_2437, v_x_2441});
      heff_room[1] = v_n_2442;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_x2_2440);
    }
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2emonadic_2econdN_lam7(V self, V *args) {
  V v_a2_2433 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_b_2431 = heff_env(self)[1];
  V v_c_2432 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_m_2434 = (g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(heff_dup(v_go_240), v_b_2431));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2econdN_lam8, 1, 5, (V[]){v_m_2434, v_go_240, v_c_2432, v_k_242, v_a2_2433});
}
HEFF_LIT(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str0, 2, "t$");
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam3(V self, V *args);
Clo g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry, 4, 0};

V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_ELet: {
    V v_y_244 = heff_field(v_e_243, 0);
    V v_c_245 = heff_field(v_e_243, 1);
    V v_d_246 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_247 = (g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(v_lit_240, v_lit_241, v_lit_242, v_d_246));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam0, 1, 3, (V[]){v_m_247, v_y_244, v_c_245});
  }
  case TAG_ESet: {
    V v_ys_2412 = heff_field(v_e_243, 0);
    V v_c_2413 = heff_field(v_e_243, 1);
    V v_d_2414 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_2415 = (g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(v_lit_240, v_lit_241, v_lit_242, v_d_2414));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam1, 1, 3, (V[]){v_m_2415, v_ys_2412, v_c_2413});
  }
  default: {
    V v_t_2420 = (g_heff_2ecompile_2emonadic_2einPlace(v_e_243));
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam2, 1, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242});
    } else {
      heff_drop(v_t_2420);
      return heff_clo_n(g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam3, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_e_243});
    }
  }
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_y_244 = heff_env(self)[1];
  V v_c_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_244, v_c_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_ys_2412 = heff_env(self)[1];
  V v_c_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_ys_2412, v_c_2413, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam2(V self, V *args) {
  V v_a_2421 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_243, v_lit_240, v_lit_241, v_lit_242}), v_a_2421});
}
V g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_lam3(V self, V *args) {
  V v_n_2422 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2423 = heff_strAppend(((V)&g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557_str0), heff_intShow(heff_dup(v_n_2422)));
  V v_t_2424 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2423)}), v_lit_240, v_lit_241, v_lit_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, v_e_243, v_t_2424}), heff_intAdd(v_n_2422, MK_INT(1LL))});
}
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args);
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2enorm_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_lam13, 2, 0};
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args); static Clo g_heff_2ecompile_2emonadic_2enorm_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_lam14, 2, 0};
Clo g_heff_2ecompile_2emonadic_2enorm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2emonadic_2enorm_entry, 1, 0};

V g_heff_2ecompile_2emonadic_2enorm(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EApp: {
    V v_f_241 = heff_field(v_x1_240, 0);
    V v_args_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_243 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_f_241));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam0, 1, 2, (V[]){v_m_243, v_args_242});
  }
  case TAG_ELet: {
    V v_x_2412 = heff_field(v_x1_240, 0);
    V v_a_2413 = heff_field(v_x1_240, 1);
    V v_b_2414 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_m_2415 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_2413));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam3, 1, 3, (V[]){v_m_2415, v_b_2414, v_x_2412});
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_x1_240, 0);
    V v_ts_2426 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2427 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x1_240_24ERecord, heff_dup(v_fs_2425)));
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_t_2427, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam4, 1, 2, (V[]){v_fs_2425, v_ts_2426})));
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x1_240, 0);
    V v_l_2433 = heff_field(v_x1_240, 1);
    V v_sh_2434 = heff_field(v_x1_240, 2);
    V v_t_2435 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_m_2436 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_e_2432));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam6, 1, 4, (V[]){v_m_2436, v_l_2433, v_sh_2434, v_t_2435});
  }
  case TAG_ETag: {
    V v_t_2442 = heff_field(v_x1_240, 0);
    V v_args_2443 = heff_field(v_x1_240, 1);
    V v_ts_2444 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_2443, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam7, 2, 2, (V[]){v_t_2442, v_ts_2444})));
  }
  case TAG_EMatch: {
    V v_s_2447 = heff_field(v_x1_240, 0);
    V v_arms_2448 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_m_2449 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_s_2447));
    return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam8, 1, 2, (V[]){v_m_2449, v_arms_2448});
  }
  case TAG_EPrimCall: {
    V v_x11_2461 = heff_field(v_x1_240, 0);
    V v_args_2462 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_2462, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam11, 2, 1, (V[]){v_x11_2461})));
  }
  case TAG_ECall: {
    V v_g_2465 = heff_field(v_x1_240, 0);
    V v_args_2466 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_2466, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam12, 2, 1, (V[]){v_g_2465})));
  }
  case TAG_EBool: {
    V v_c_2469 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return (g_heff_2ecompile_2emonadic_2econdN(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_c_2469, ((V)&g_heff_2ecompile_2emonadic_2enorm_lam13_clo)));
  }
  case TAG_EValues: {
    V v_es_2472 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_es_2472, ((V)&g_heff_2ecompile_2emonadic_2enorm_lam14_clo)));
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054(v_x1_240);
  }
  }
}
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2emonadic_2enorm(a[0]);
}
V g_heff_2ecompile_2emonadic_2enorm_lam2(V self, V *args) {
  V v_args_27_249 = args[0];
  V v_n_2410 = args[1];
  V v_f_27_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_248, v_args_27_249}), v_n_2410});
}
V g_heff_2ecompile_2emonadic_2enorm_lam1(V self, V *args) {
  V v_f_27_248 = args[0];
  V v_args_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2emonadic_2eoperandsWith(((V)&g_heff_2ecompile_2emonadic_2enorm_clo), v_args_242, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam2, 2, 1, (V[]){v_f_27_248})));
}
V g_heff_2ecompile_2emonadic_2enorm_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_args_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    V v_t_2411 = heff_tr(g_heff_2ecompile_2emonadic_2ebindAs(v_x_246, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam1, 1, 1, (V[]){v_args_242})));
    V f_ = v_t_2411;
    args[0] = v_n_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_b_2414 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_m_2420 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_2414));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2419}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      V v_x_2424 = (g_heff_2ecompile_2emonadic_2eflatLet(v_x_2412, v_x_2418, v_x_2422));
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2424, v_n_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam5(V self, V *args) {
  V v_n_2431 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2430, v_n_2431});
}
V g_heff_2ecompile_2emonadic_2enorm_lam4(V self, V *args) {
  V v_vs_2428 = args[0];
  V v_fs_2425 = heff_env(self)[0];
  V v_ts_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2425, v_vs_2428));
  V v_x_2430 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2429, v_ts_2426});
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam5, 1, 1, (V[]){v_x_2430});
}
V g_heff_2ecompile_2emonadic_2enorm_lam6(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_l_2433 = heff_env(self)[1];
  V v_sh_2434 = heff_env(self)[2];
  V v_t_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    heff_take_n(v_x2_2438, 3ULL, 2);
    V v_t_2441 = (g_heff_2ecompile_2emonadic_2ebindAs_24s57863345x480979557(v_l_2433, v_sh_2434, v_t_2435, v_x_2439));
    V f_ = v_t_2441;
    args[0] = v_n_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam7(V self, V *args) {
  V v_args_27_2445 = args[0];
  V v_n_2446 = args[1];
  V v_t_2442 = heff_env(self)[0];
  V v_ts_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2442, v_args_27_2445, v_ts_2444}), v_n_2446});
}
V g_heff_2ecompile_2emonadic_2enorm_lam10(V self, V *args) {
  V v_n_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_s_27_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_n_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_n_2459 = heff_field(v_x2_2457, 1);
    V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_2454, v_x_2458}), v_n_2459});
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam9(V self, V *args) {
  V v_s_27_2454 = args[0];
  V v_arms_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2455 = (g_prelude_2etraverse_24s646322350x1809881141(v_arms_2448));
  return heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam10, 1, 2, (V[]){v_m_2455, v_s_27_2454});
}
V g_heff_2ecompile_2emonadic_2enorm_lam8(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_arms_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    heff_take_n(v_x2_2451, 3ULL, 2);
    V v_t_2460 = heff_tr(g_heff_2ecompile_2emonadic_2ebindScrut(v_x_2452, heff_clo_n(g_heff_2ecompile_2emonadic_2enorm_lam9, 1, 1, (V[]){v_arms_2448})));
    V f_ = v_t_2460;
    args[0] = v_n_2453;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2emonadic_2enorm_lam11(V self, V *args) {
  V v_args_27_2463 = args[0];
  V v_n_2464 = args[1];
  V v_x11_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x11_2461, v_args_27_2463}), v_n_2464});
}
V g_heff_2ecompile_2emonadic_2enorm_lam12(V self, V *args) {
  V v_args_27_2467 = args[0];
  V v_n_2468 = args[1];
  V v_g_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2465, v_args_27_2467}), v_n_2468});
}
V g_heff_2ecompile_2emonadic_2enorm_lam13(V self, V *args) {
  V v_c2_2470 = args[0];
  V v_n_2471 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_c2_2470}), v_n_2471});
}
V g_heff_2ecompile_2emonadic_2enorm_lam14(V self, V *args) {
  V v_es_27_2473 = args[0];
  V v_n_2474 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_es_27_2473}), v_n_2474});
}