// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_cmt 308164
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_version 583465758
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__dir[] = {LBL_name, LBL_dir};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V);
V g_heff_2ebuild_2eproject_2eandList(V);
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_clo;
V g_heff_2ebuild_2eproject_2eandList_24acc(V, V);
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo;
HeffT2 g_heff_2ebuild_2eproject_2ebuildOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2echeckHeff_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V, V, V);
V g_heff_2ebuild_2eproject_2efieldsSaid(V);
V g_heff_2ebuild_2eproject_2efieldsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsSaid_clo;
V g_heff_2ebuild_2eproject_2eisName(V);
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisName_clo;
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V, V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames(V);
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo;
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo;
HeffT2 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2enextDecl(V, V);
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enextDecl_clo;
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf4_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(V);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eshipWrong_24cpr(V);
V g_heff_2ebuild_2eproject_2eshowPackage(V);
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eshowPackage_clo;
HeffT2 g_heff_2ebuild_2eproject_2espanGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V);
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2esumLine_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_list_2eall_24s1251569107x847515346(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s1251569107x847515346_entry(V self, V *a);
extern Clo g_list_2eall_24s1251569107x847515346_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24f768999161x1997188166(V, V, V);
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_clo;
V g_list_2emap_24s1703643582x349630108(V, V);
V g_list_2emap_24s1703643582x349630108_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str6, 62, "expected `,` or `]`: an item is a literal, nothing is computed");

HeffT2 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(heff_dup(v_ts_240), v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_ts_240);
      heff_drop(v_acc_242);
      V v_p_247 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_247}});
    } else {
      V v_it1_248 = v_field_245;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_it1_248, 0);
        V v_j_2410 = heff_field(v_it1_248, 1);
        V v_ru_24it1_248_24MkPair = heff_take_reuse_n(v_it1_248, 3ULL, 2);
        V v_t_2414;
        if (heff_intLe_c(MK_INT(0LL), heff_dup(v_j_2410))) {
          if (heff_intLt_c(heff_dup(v_j_2410), heff_arrayLength_lent(v_ts_240, 0))) {
            V v_t_2413 = heff_arrayIndex_lent(v_ts_240, v_j_2410, 0);
            v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
          } else {
            v_t_2414 = NTAG(TAG_Nothing);
          }
        } else {
          v_t_2414 = NTAG(TAG_Nothing);
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_Nothing: {
          heff_drop(v_acc_242);
          heff_drop(v_x_249);
          heff_drop(v_j_2410);
          heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
          int64_t v_i_2415 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
          V v_t_2419;
          if ((((int64_t)0ULL) <= v_i_2415)) {
            if ((v_i_2415 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
              V v_t_2418 = heff_arrayIndex(v_ts_240, heff_box_word(v_i_2415));
              v_t_2419 = heff_get_n(v_t_2418, 2, 7);
            } else {
              heff_drop(v_ts_240);
              v_t_2419 = MK_INT(0LL);
            }
          } else {
            heff_drop(v_ts_240);
            v_t_2419 = MK_INT(0LL);
          }
          V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
        }
        case TAG_Just: {
          V v_t_2421 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          V v_t_2423 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_2421, 0)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2421, 1)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2))));
          if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
            heff_drop_rec(v_t_2421, 7);
            heff_drop(v_t_2423);
            V t_0 = v_ts_240;
            V t_1 = heff_intAdd(v_j_2410, MK_INT(1LL));
            V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_acc_242});
            v_ts_240 = t_0;
            v_i_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          } else {
            heff_drop(v_ts_240);
            heff_drop(v_t_2423);
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2421, 0)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3))) {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_2421, 1)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4))) {
                heff_drop_rec(v_t_2421, 7);
                V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_acc_242})));
                V v_f_2427 = heff_tag_at_n(v_ru_24it1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, heff_intAdd(v_j_2410, MK_INT(1LL))});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2427}});
              } else {
                heff_drop(v_acc_242);
                heff_drop(v_x_249);
                heff_drop(v_j_2410);
                heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
                V v_f_2428 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2421, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
              }
            } else {
              heff_drop(v_acc_242);
              heff_drop(v_x_249);
              heff_drop(v_j_2410);
              heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
              V v_f_2429 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2421, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str6)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2429}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2414)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_248)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2, 23, "expected a field's name");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6, 12, "expected `=`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11, 1, "}");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str13, 62, "expected `,` or `}`: a field is a literal, nothing is computed");

HeffT2 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_246;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0))) {
      V v_t_245 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      v_t_246 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_246 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_i_241);
    heff_drop(v_acc_242);
    int64_t v_i_247 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2411;
    if ((((int64_t)0ULL) <= v_i_247)) {
      if ((v_i_247 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
        V v_t_2410 = heff_arrayIndex(v_ts_240, heff_box_word(v_i_247));
        v_t_2411 = heff_get_n(v_t_2410, 2, 7);
      } else {
        heff_drop(v_ts_240);
        v_t_2411 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_ts_240);
      v_t_2411 = MK_INT(0LL);
    }
    V v_f_2412 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
  }
  case TAG_Just: {
    V v_name_2413 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_2415 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_name_2413, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1)));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_ts_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      heff_drop(v_t_2415);
      V v_f_2416 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_name_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
    } else {
      heff_drop(v_t_2415);
      V v_i_2417 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL));
      V v_t_2421;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2417))) {
        if (heff_intLt_c(heff_dup(v_i_2417), heff_arrayLength_lent(v_ts_240, 0))) {
          V v_t_2420 = heff_arrayIndex_lent(v_ts_240, v_i_2417, 2);
          v_t_2421 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2420});
        } else {
          heff_drop_cell(v_ru_24t_246_24Just, 1);
          heff_drop(v_i_2417);
          v_t_2421 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        heff_drop(v_i_2417);
        v_t_2421 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop(v_i_241);
        heff_drop(v_acc_242);
        heff_drop_rec(v_name_2413, 7);
        int64_t v_i_2422 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
        V v_t_2426;
        if ((((int64_t)0ULL) <= v_i_2422)) {
          if ((v_i_2422 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
            V v_t_2425 = heff_arrayIndex(v_ts_240, heff_box_word(v_i_2422));
            v_t_2426 = heff_get_n(v_t_2425, 2, 7);
          } else {
            heff_drop(v_ts_240);
            v_t_2426 = MK_INT(0LL);
          }
        } else {
          heff_drop(v_ts_240);
          v_t_2426 = MK_INT(0LL);
        }
        V v_f_2427 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2426, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
      }
      case TAG_Just: {
        V v_eq_2428 = heff_field(v_t_2421, 0);
        V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
        V v_t_2431 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_eq_2428, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4)) ? !heff_strEq_c(heff_dup(heff_rfield(v_eq_2428, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5)) : 1));
        if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
          heff_drop(v_ts_240);
          heff_drop(v_i_241);
          heff_drop(v_acc_242);
          heff_drop_rec(v_name_2413, 7);
          heff_drop_cell(v_ru_24t_2421_24Just, 1);
          heff_drop(v_t_2431);
          V v_f_2432 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_eq_2428, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
        } else {
          heff_drop_rec(v_eq_2428, 7);
          heff_drop(v_t_2431);
          HeffT2 v_t_2433 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(2LL))));
          {
            V v_field_2435 = v_t_2433.f[1];
            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
            if ((v_tag_2434 == ((int64_t)0ULL))) {
              heff_drop(v_ts_240);
              heff_drop(v_acc_242);
              heff_drop_rec(v_name_2413, 7);
              heff_drop_cell(v_ru_24t_2421_24Just, 1);
              V v_p_2437 = v_field_2435;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2437}});
            } else {
              V v_it1_2438 = v_field_2435;
              switch (heff_tag_of(v_it1_2438)) {
              case TAG_MkPair: {
                V v_x_2439 = heff_field(v_it1_2438, 0);
                V v_j_2440 = heff_field(v_it1_2438, 1);
                V v_ru_24it1_2438_24MkPair = heff_take_reuse_n(v_it1_2438, 3ULL, 2);
                V v_t_2444;
                if (heff_intLe_c(MK_INT(0LL), heff_dup(v_j_2440))) {
                  if (heff_intLt_c(heff_dup(v_j_2440), heff_arrayLength_lent(v_ts_240, 0))) {
                    V v_t_2443 = heff_arrayIndex_lent(v_ts_240, v_j_2440, 0);
                    v_t_2444 = heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){v_t_2443});
                  } else {
                    heff_drop_cell(v_ru_24t_2421_24Just, 1);
                    v_t_2444 = NTAG(TAG_Nothing);
                  }
                } else {
                  heff_drop_cell(v_ru_24t_2421_24Just, 1);
                  v_t_2444 = NTAG(TAG_Nothing);
                }
                switch (heff_tag_of(v_t_2444)) {
                case TAG_Nothing: {
                  heff_drop(v_acc_242);
                  heff_drop_rec(v_name_2413, 7);
                  heff_drop(v_x_2439);
                  heff_drop(v_j_2440);
                  heff_drop_cell(v_ru_24it1_2438_24MkPair, 2);
                  int64_t v_i_2445 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
                  V v_t_2449;
                  if ((((int64_t)0ULL) <= v_i_2445)) {
                    if ((v_i_2445 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                      V v_t_2448 = heff_arrayIndex(v_ts_240, heff_box_word(v_i_2445));
                      v_t_2449 = heff_get_n(v_t_2448, 2, 7);
                    } else {
                      heff_drop(v_ts_240);
                      v_t_2449 = MK_INT(0LL);
                    }
                  } else {
                    heff_drop(v_ts_240);
                    v_t_2449 = MK_INT(0LL);
                  }
                  V v_f_2450 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2449, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2450}});
                }
                case TAG_Just: {
                  V v_t_2451 = heff_field(v_t_2444, 0);
                  heff_take_n(v_t_2444, 1ULL, 1);
                  V v_t_2453 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_2451, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2451, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9))));
                  if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
                    heff_drop_rec(v_t_2451, 7);
                    heff_drop(v_t_2453);
                    V v_t_2454 = heff_tag_at_n(v_ru_24it1_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_name_2413, 1, 7), v_x_2439});
                    V t_0 = v_ts_240;
                    V t_1 = heff_intAdd(v_j_2440, MK_INT(1LL));
                    V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, v_acc_242});
                    v_ts_240 = t_0;
                    v_i_241 = t_1;
                    v_acc_242 = t_2;
                    goto top;
                  } else {
                    heff_drop(v_ts_240);
                    heff_drop(v_t_2453);
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_2451, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10))) {
                      if (heff_strEq_c(heff_dup(heff_rfield(v_t_2451, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11))) {
                        heff_drop_rec(v_t_2451, 7);
                        V v_t_2457 = heff_tag_at_n(v_ru_24it1_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_name_2413, 1, 7), v_x_2439});
                        V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_acc_242})));
                        V v_f_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2458, heff_intAdd(v_j_2440, MK_INT(1LL))});
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2459}});
                      } else {
                        heff_drop(v_acc_242);
                        heff_drop_rec(v_name_2413, 7);
                        heff_drop(v_x_2439);
                        heff_drop(v_j_2440);
                        heff_drop_cell(v_ru_24it1_2438_24MkPair, 2);
                        V v_f_2460 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2451, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12)});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2460}});
                      }
                    } else {
                      heff_drop(v_acc_242);
                      heff_drop_rec(v_name_2413, 7);
                      heff_drop(v_x_2439);
                      heff_drop(v_j_2440);
                      heff_drop_cell(v_ru_24it1_2438_24MkPair, 2);
                      V v_f_2461 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2451, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str13)});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2461}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_t_2444)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2438)}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2421)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_246)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4, 1, "[");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9, 1, "{");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str11, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");

HeffT2 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V v_ts_240, V v_i_241) {
top: ;
  V v_t_245;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0))) {
      V v_t_244 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
      v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      v_t_245 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_245 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_i_241);
    int64_t v_i_246 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2410;
    if ((((int64_t)0ULL) <= v_i_246)) {
      if ((v_i_246 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
        V v_t_249 = heff_arrayIndex(v_ts_240, heff_box_word(v_i_246));
        v_t_2410 = heff_get_n(v_t_249, 2, 7);
      } else {
        heff_drop(v_ts_240);
        v_t_2410 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_ts_240);
      v_t_2410 = MK_INT(0LL);
    }
    V v_f_2411 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
  }
  case TAG_Just: {
    V v_t_2412 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_2412, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1))) {
      heff_drop(v_ts_240);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      V v_t_2414 = heff_tag_n(TAG_LStr, 2, (V[]){heff_dup(heff_rfield(v_t_2412, 1)), v_t_2412});
      V v_f_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, heff_intAdd(v_i_241, MK_INT(1LL))});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2415}});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_2412, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2))) {
        heff_drop(v_ts_240);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        V v_t_2417 = heff_tag_n(TAG_LTag, 2, (V[]){heff_dup(heff_rfield(v_t_2412, 1)), v_t_2412});
        V v_f_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, heff_intAdd(v_i_241, MK_INT(1LL))});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2418}});
      } else {
        V v_t_2420 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_2412, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2412, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4))));
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop(v_t_2420);
          V v_i_2421 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL));
          V v_t_2425;
          if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2421))) {
            if (heff_intLt_c(heff_dup(v_i_2421), heff_arrayLength_lent(v_ts_240, 0))) {
              V v_t_2424 = heff_arrayIndex_lent(v_ts_240, v_i_2421, 2);
              v_t_2425 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_t_2424});
            } else {
              heff_drop_cell(v_ru_24t_245_24Just, 1);
              heff_drop(v_i_2421);
              v_t_2425 = NTAG(TAG_Nothing);
            }
          } else {
            heff_drop_cell(v_ru_24t_245_24Just, 1);
            heff_drop(v_i_2421);
            v_t_2425 = NTAG(TAG_Nothing);
          }
          switch (heff_tag_of(v_t_2425)) {
          case TAG_Nothing: {
            heff_drop(v_i_241);
            heff_drop_rec(v_t_2412, 7);
            int64_t v_i_2426 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
            V v_t_2430;
            if ((((int64_t)0ULL) <= v_i_2426)) {
              if ((v_i_2426 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                V v_t_2429 = heff_arrayIndex(v_ts_240, heff_box_word(v_i_2426));
                v_t_2430 = heff_get_n(v_t_2429, 2, 7);
              } else {
                heff_drop(v_ts_240);
                v_t_2430 = MK_INT(0LL);
              }
            } else {
              heff_drop(v_ts_240);
              v_t_2430 = MK_INT(0LL);
            }
            V v_f_2431 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2430, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2431}});
          }
          case TAG_Just: {
            V v_next_2432 = heff_field(v_t_2425, 0);
            heff_take_n(v_t_2425, 1ULL, 1);
            if (heff_strEq_c(heff_dup(heff_rfield(v_next_2432, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6))) {
              if (heff_strEq_c(heff_get_n(v_next_2432, 1, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7))) {
                heff_drop(v_ts_240);
                V v_t_2435 = heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_2412});
                V v_f_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, heff_intAdd(v_i_241, MK_INT(2LL))});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2436}});
              } else {
                HeffT2 v_t_2437 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
                {
                  V v_field_2439 = v_t_2437.f[1];
                  int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
                  if ((v_tag_2438 == ((int64_t)0ULL))) {
                    heff_drop_rec(v_t_2412, 7);
                    V v_p_2441 = v_field_2439;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2441}});
                  } else {
                    V v_x21_2442 = v_field_2439;
                    switch (heff_tag_of(v_x21_2442)) {
                    case TAG_MkPair: {
                      V v_xs_2443 = heff_field(v_x21_2442, 0);
                      V v_j_2444 = heff_field(v_x21_2442, 1);
                      V v_ru_24x21_2442_24MkPair = heff_take_reuse_n(v_x21_2442, 3ULL, 2);
                      V v_t_2445 = heff_tag_at_n(v_ru_24x21_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LList, 2, (V[]){v_xs_2443, v_t_2412}), v_j_2444});
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2445}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x21_2442)}});
                    }
                  }
                }
              }
            } else {
              heff_drop_rec(v_next_2432, 7);
              HeffT2 v_t_2446 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
              {
                V v_field_2448 = v_t_2446.f[1];
                int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
                if ((v_tag_2447 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_2412, 7);
                  V v_p_2450 = v_field_2448;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2450}});
                } else {
                  V v_x21_2451 = v_field_2448;
                  switch (heff_tag_of(v_x21_2451)) {
                  case TAG_MkPair: {
                    V v_xs_2452 = heff_field(v_x21_2451, 0);
                    V v_j_2453 = heff_field(v_x21_2451, 1);
                    V v_ru_24x21_2451_24MkPair = heff_take_reuse_n(v_x21_2451, 3ULL, 2);
                    V v_t_2454 = heff_tag_at_n(v_ru_24x21_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LList, 2, (V[]){v_xs_2452, v_t_2412}), v_j_2453});
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2454}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x21_2451)}});
                  }
                }
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2425)}});
          }
        } else {
          heff_drop_cell(v_ru_24t_245_24Just, 1);
          heff_drop(v_t_2420);
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_2412, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8))) {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2412, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9))) {
              HeffT2 v_t_2457 = (g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(v_ts_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_Nil)));
              {
                V v_field_2459 = v_t_2457.f[1];
                int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
                if ((v_tag_2458 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_2412, 7);
                  V v_p_2461 = v_field_2459;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2461}});
                } else {
                  V v_x21_2462 = v_field_2459;
                  switch (heff_tag_of(v_x21_2462)) {
                  case TAG_MkPair: {
                    V v_fs_2463 = heff_field(v_x21_2462, 0);
                    V v_j_2464 = heff_field(v_x21_2462, 1);
                    V v_ru_24x21_2462_24MkPair = heff_take_reuse_n(v_x21_2462, 3ULL, 2);
                    V v_t_2465 = heff_tag_at_n(v_ru_24x21_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LRec, 2, (V[]){v_fs_2463, v_t_2412}), v_j_2464});
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2465}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x21_2462)}});
                  }
                }
              }
            } else {
              heff_drop(v_ts_240);
              heff_drop(v_i_241);
              V v_f_2466 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2466}});
            }
          } else {
            heff_drop(v_ts_240);
            heff_drop(v_i_241);
            V v_f_2467 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str11)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2467}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_245)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str1, 1, ".");

HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V v_v_240) {
top: ;
  V v_it_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str0), heff_dup(v_v_240), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str1), v_v_240, MK_INT(0LL)), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    V v_ru_24it_241_24Cons = heff_take_reuse_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24it_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      V v_ru_24it2_243_24Cons = heff_take_reuse_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24it_241_24Cons, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24it2_243_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_c_246 = heff_field(v_it22_245, 0);
        V v_it222_247 = heff_field(v_it22_245, 1);
        heff_take_n(v_it22_245, 3ULL, 2);
        switch (heff_tag_of(v_it222_247)) {
        case TAG_Nil: {
          V v_t_248 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_a_242)));
          if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
            heff_drop(v_t_248);
            V v_t_249 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_b_244)));
            if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
              heff_drop(v_t_249);
              V v_t_2410 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_c_246)));
              if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
                heff_drop(v_t_2410);
                V v_t_2411 = heff_tag_at_n(v_ru_24it_241_24Cons, TAG_Cons, 2, (V[]){v_c_246, NTAG(TAG_Nil)});
                V v_t_2412 = heff_tag_at_n(v_ru_24it2_243_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, v_t_2411})});
                V v_f_2413 = (g_list_2emap_24s1703643582x349630108(MK_INT(0LL), v_t_2412));
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
              } else {
                heff_drop(v_a_242);
                heff_drop_cell(v_ru_24it_241_24Cons, 2);
                heff_drop(v_b_244);
                heff_drop_cell(v_ru_24it2_243_24Cons, 2);
                heff_drop(v_c_246);
                heff_drop(v_t_2410);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_a_242);
              heff_drop_cell(v_ru_24it_241_24Cons, 2);
              heff_drop(v_b_244);
              heff_drop_cell(v_ru_24it2_243_24Cons, 2);
              heff_drop(v_c_246);
              heff_drop(v_t_249);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_a_242);
            heff_drop_cell(v_ru_24it_241_24Cons, 2);
            heff_drop(v_b_244);
            heff_drop_cell(v_ru_24it2_243_24Cons, 2);
            heff_drop(v_c_246);
            heff_drop(v_t_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_247, 0ULL, 2);
          heff_drop(v_a_242);
          heff_drop_cell(v_ru_24it_241_24Cons, 2);
          heff_drop(v_b_244);
          heff_drop_cell(v_ru_24it2_243_24Cons, 2);
          heff_drop(v_c_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it222_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
Clo g_heff_2ebuild_2eproject_2eversion_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eversion_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eversion(V v_v_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eversion(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eisName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisName_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisName(V v_x_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))) {
        V v_t_244 = (g_list_2emap_24f768999161x1997188166(heff_dup(v_x_240), MK_INT(0LL), heff_strLength(v_x_240)));
        return ({ V a_0 = MK_INT(97LL); V a_1 = MK_INT(122LL); V a_2 = MK_INT(65LL); V a_3 = MK_INT(90LL); V a_4 = MK_INT(48LL); V a_5 = MK_INT(57LL); V a_6 = MK_INT(95LL); V a_7 = MK_INT(95LL); V a_8 = MK_INT(48LL); V a_9 = MK_INT(57LL); V a_10 = MK_INT(95LL); V a_11 = MK_INT(95LL); V a_12 = v_t_244; V r_ = (g_list_2eall_24s1251569107x847515346(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_t_244); r_; });
      } else {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eisName(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eproject_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        V v_s_247 = heff_dup(v_x_241);
        V v_s_248 = heff_strAppend(v_s_247, ((V)&g_heff_2ebuild_2eproject_2eandList_str2));
        return (g_heff_2ebuild_2eproject_2eandList_24acc(v_x12_242, v_s_248));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_24acc_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_f_241, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_241, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_241, 0, 2), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2eproject_2eleftOutNames_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_f_242, 1);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_242, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_242, 0, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_rest_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V v_fields_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x_241)) {
  case TAG_LStr: {
    heff_drop(v_fields_240);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_245 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_245;
      break;
    }
    case TAG_LTag: {
      V v_t_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_247;
      break;
    }
    case TAG_LList: {
      V v_t_249 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_249;
      break;
    }
    case TAG_LRec: {
      V v_t_2411 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_2411;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2413 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
  }
  case TAG_LTag: {
    heff_drop(v_fields_240);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2417 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2417;
      break;
    }
    case TAG_LTag: {
      V v_t_2419 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2419;
      break;
    }
    case TAG_LList: {
      V v_t_2421 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2421;
      break;
    }
    case TAG_LRec: {
      V v_t_2423 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2423;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
  }
  case TAG_LList: {
    heff_drop(v_fields_240);
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2429 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2429;
      break;
    }
    case TAG_LTag: {
      V v_t_2431 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2431;
      break;
    }
    case TAG_LList: {
      V v_t_2433 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2433;
      break;
    }
    case TAG_LRec: {
      V v_t_2435 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2435;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2437 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
  }
  case TAG_LRec: {
    V v_fs_2438 = heff_field(v_x_241, 0);
    V v_t_2439 = heff_field(v_x_241, 1);
    heff_take_n(v_x_241, 3ULL, 2);
    HeffT2 v_t_2440 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(heff_dup(v_t_2439), heff_dup(v_fields_240), v_fs_2438));
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        heff_drop(v_fields_240);
        heff_drop_rec(v_t_2439, 7);
        V v_xs_2444 = v_field_2442;
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_xs_2444}});
      } else {
        heff_drop(v_field_2442);
        V v_msg_2445 = (g_heff_2ebuild_2eproject_2efieldsSaid(v_fields_240));
        V v_f_2446 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2439, 2, 7), v_msg_2445});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str0, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str1, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str2, 23, "expected a list `[...]`");

HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_244;
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_246;
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_248;
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_2410;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
  }
  case TAG_LTag: {
    V v_t_2423;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2416 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2416;
      break;
    }
    case TAG_LTag: {
      V v_t_2418 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2418;
      break;
    }
    case TAG_LList: {
      V v_t_2420 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2420;
      break;
    }
    case TAG_LRec: {
      V v_t_2422 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2422;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
  }
  case TAG_LList: {
    V v_xs_2425 = heff_field(v_x_240, 0);
    heff_take_n(v_x_240, 1ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_xs_2425}});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2430;
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2432;
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2434;
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2436;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2438}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1, 4, "path");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2, 7, "version");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str7, 83, "` cannot be imported by: a name is a lowercase letter, then letters, digits and `_`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str8, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str9, 45, "` is no version: write `a.b.c`, three numbers");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str10, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2), NTAG(TAG_Nothing)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244})});
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(v_t_245, heff_dup(v_x_240)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_2410 = v_field_248;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2410}});
    } else {
      V v_it1_2411 = v_field_248;
      switch (heff_tag_of(v_it1_2411)) {
      case TAG_Nil: {
        V v_t_2420;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2413 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2413;
          break;
        }
        case TAG_LTag: {
          V v_t_2415 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2415;
          break;
        }
        case TAG_LList: {
          V v_t_2417 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2417;
          break;
        }
        case TAG_LRec: {
          V v_t_2419 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2419;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2421 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2420, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
      }
      case TAG_Cons: {
        V v_n_2422 = heff_field(v_it1_2411, 0);
        V v_it12_2423 = heff_field(v_it1_2411, 1);
        heff_take_n(v_it1_2411, 3ULL, 2);
        switch (heff_tag_of(v_it12_2423)) {
        case TAG_Nil: {
          heff_drop(v_n_2422);
          V v_t_2432;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2425 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2425;
            break;
          }
          case TAG_LTag: {
            V v_t_2427 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2427;
            break;
          }
          case TAG_LList: {
            V v_t_2429 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2429;
            break;
          }
          case TAG_LRec: {
            V v_t_2431 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2431;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2433 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2432, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
        }
        case TAG_Cons: {
          V v_p_2434 = heff_field(v_it12_2423, 0);
          V v_it122_2435 = heff_field(v_it12_2423, 1);
          heff_take_n(v_it12_2423, 3ULL, 2);
          switch (heff_tag_of(v_it122_2435)) {
          case TAG_Nil: {
            heff_drop(v_n_2422);
            heff_drop(v_p_2434);
            V v_t_2444;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2437 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2437;
              break;
            }
            case TAG_LTag: {
              V v_t_2439 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2439;
              break;
            }
            case TAG_LList: {
              V v_t_2441 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2441;
              break;
            }
            case TAG_LRec: {
              V v_t_2443 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2443;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2445 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2444, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2445}});
          }
          case TAG_Cons: {
            V v_v_2446 = heff_field(v_it122_2435, 0);
            V v_it1222_2447 = heff_field(v_it122_2435, 1);
            heff_take_n(v_it122_2435, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2447)) {
            case TAG_Nil: {
              heff_drop(v_x_240);
              HeffT2 v_t_2448 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_n_2422)));
              V v_t_2466;
              {
                V v_field_2450 = v_t_2448.f[1];
                int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
                if ((v_tag_2449 == ((int64_t)0ULL))) {
                  heff_drop(v_n_2422);
                  V v_p_2452 = v_field_2450;
                  v_t_2466 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2452});
                } else {
                  V v_n_2453 = v_field_2450;
                  V v_t_2454 = (g_heff_2ebuild_2eproject_2eisName(heff_dup(v_n_2453)));
                  if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
                    heff_drop(v_n_2422);
                    heff_drop(v_t_2454);
                    v_t_2466 = heff_tag_n(TAG_Right, 1, (V[]){v_n_2453});
                  } else {
                    heff_drop(v_t_2454);
                    V v_t_2463;
                    switch (heff_tag_of(v_n_2422)) {
                    case TAG_LStr: {
                      V v_t_2456 = heff_field(v_n_2422, 1);
                      heff_take_n(v_n_2422, 2ULL, 2);
                      v_t_2463 = v_t_2456;
                      break;
                    }
                    case TAG_LTag: {
                      V v_t_2458 = heff_field(v_n_2422, 1);
                      heff_take_n(v_n_2422, 2ULL, 2);
                      v_t_2463 = v_t_2458;
                      break;
                    }
                    case TAG_LList: {
                      V v_t_2460 = heff_field(v_n_2422, 1);
                      heff_take_n(v_n_2422, 2ULL, 2);
                      v_t_2463 = v_t_2460;
                      break;
                    }
                    case TAG_LRec: {
                      V v_t_2462 = heff_field(v_n_2422, 1);
                      heff_take_n(v_n_2422, 2ULL, 2);
                      v_t_2463 = v_t_2462;
                      break;
                    }
                    default: heff_nomatch(v_n_2422);
                    }
                    V v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6), heff_strAppend(v_n_2453, ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str7)));
                    V v_t_2465 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2463, 2, 7), v_t_2464});
                    v_t_2466 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2465});
                  }
                }
              }
              switch (heff_tag_of(v_t_2466)) {
              case TAG_Left: {
                V v_e_2467 = heff_field(v_t_2466, 0);
                heff_take_n(v_t_2466, 1ULL, 1);
                heff_drop(v_p_2434);
                heff_drop(v_v_2446);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2467}});
              }
              case TAG_Right: {
                V v_name_2468 = heff_field(v_t_2466, 0);
                heff_take_n(v_t_2466, 1ULL, 1);
                HeffT2 v_t_2469 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_v_2446)));
                {
                  V v_field_2471 = v_t_2469.f[1];
                  int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                  if ((v_tag_2470 == ((int64_t)0ULL))) {
                    heff_drop(v_p_2434);
                    heff_drop(v_v_2446);
                    heff_drop(v_name_2468);
                    V v_p_2473 = v_field_2471;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2473}});
                  } else {
                    V v_v_2474 = v_field_2471;
                    HeffT2 v_t_2475 = (g_heff_2ebuild_2eproject_2eversion_24cpr(heff_dup(v_v_2474)));
                    {
                      V v_field_2477 = v_t_2475.f[1];
                      int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
                      if ((v_tag_2476 == ((int64_t)0ULL))) {
                        heff_drop(v_v_2446);
                        V v_x_2479 = v_field_2477;
                        heff_drop(v_x_2479);
                        HeffT2 v_t_2480 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_p_2434)));
                        {
                          V v_field_2482 = v_t_2480.f[1];
                          int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
                          if ((v_tag_2481 == ((int64_t)0ULL))) {
                            heff_drop(v_p_2434);
                            heff_drop(v_name_2468);
                            heff_drop(v_v_2474);
                            V v_p_2484 = v_field_2482;
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2484}});
                          } else {
                            V v_path_2485 = v_field_2482;
                            HeffT2 v_t_2486 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_2485), heff_dup(v_v_2474)));
                            {
                              V v_field_2488 = v_t_2486.f[1];
                              int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                              if ((v_tag_2487 == ((int64_t)0ULL))) {
                                heff_drop(v_name_2468);
                                heff_drop(v_v_2474);
                                heff_drop(v_path_2485);
                                V v_why_2490 = v_field_2488;
                                V v_t_2499;
                                switch (heff_tag_of(v_p_2434)) {
                                case TAG_LStr: {
                                  V v_t_2492 = heff_field(v_p_2434, 1);
                                  heff_take_n(v_p_2434, 2ULL, 2);
                                  v_t_2499 = v_t_2492;
                                  break;
                                }
                                case TAG_LTag: {
                                  V v_t_2494 = heff_field(v_p_2434, 1);
                                  heff_take_n(v_p_2434, 2ULL, 2);
                                  v_t_2499 = v_t_2494;
                                  break;
                                }
                                case TAG_LList: {
                                  V v_t_2496 = heff_field(v_p_2434, 1);
                                  heff_take_n(v_p_2434, 2ULL, 2);
                                  v_t_2499 = v_t_2496;
                                  break;
                                }
                                case TAG_LRec: {
                                  V v_t_2498 = heff_field(v_p_2434, 1);
                                  heff_take_n(v_p_2434, 2ULL, 2);
                                  v_t_2499 = v_t_2498;
                                  break;
                                }
                                default: heff_nomatch(v_p_2434);
                                }
                                V v_f_24100 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2499, 2, 7), v_why_2490});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24100}});
                              } else {
                                heff_drop(v_p_2434);
                                heff_drop(v_field_2488);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__path__version, (V[]){v_name_2468, v_path_2485, v_v_2474})}});
                              }
                            }
                          }
                        }
                      } else {
                        heff_drop(v_p_2434);
                        heff_drop(v_name_2468);
                        heff_drop(v_field_2477);
                        V v_t_24109;
                        switch (heff_tag_of(v_v_2446)) {
                        case TAG_LStr: {
                          V v_t_24102 = heff_field(v_v_2446, 1);
                          heff_take_n(v_v_2446, 2ULL, 2);
                          v_t_24109 = v_t_24102;
                          break;
                        }
                        case TAG_LTag: {
                          V v_t_24104 = heff_field(v_v_2446, 1);
                          heff_take_n(v_v_2446, 2ULL, 2);
                          v_t_24109 = v_t_24104;
                          break;
                        }
                        case TAG_LList: {
                          V v_t_24106 = heff_field(v_v_2446, 1);
                          heff_take_n(v_v_2446, 2ULL, 2);
                          v_t_24109 = v_t_24106;
                          break;
                        }
                        case TAG_LRec: {
                          V v_t_24108 = heff_field(v_v_2446, 1);
                          heff_take_n(v_v_2446, 2ULL, 2);
                          v_t_24109 = v_t_24108;
                          break;
                        }
                        default: heff_nomatch(v_v_2446);
                        }
                        V v_t_24110 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str8), heff_strAppend(v_v_2474, ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str9)));
                        V v_f_24111 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24109, 2, 7), v_t_24110});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24111}});
                      }
                    }
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_t_2466)}});
              }
            }
            case TAG_Cons: {
              heff_take_n(v_it1222_2447, 0ULL, 2);
              heff_drop(v_n_2422);
              heff_drop(v_p_2434);
              heff_drop(v_v_2446);
              V v_t_24122;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_24115 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_24122 = v_t_24115;
                break;
              }
              case TAG_LTag: {
                V v_t_24117 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_24122 = v_t_24117;
                break;
              }
              case TAG_LList: {
                V v_t_24119 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_24122 = v_t_24119;
                break;
              }
              case TAG_LRec: {
                V v_t_24121 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_24122 = v_t_24121;
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_f_24123 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24122, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str10)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24123}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it1222_2447)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2435)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2411)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str1, 3, "dir");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str5, 83, "` cannot be imported by: a name is a lowercase letter, then letters, digits and `_`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str6, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_243}), heff_dup(v_x_240)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_248 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_248}});
    } else {
      V v_it1_249 = v_field_246;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_Nil: {
        V v_t_2418;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2411 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2411;
          break;
        }
        case TAG_LTag: {
          V v_t_2413 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2413;
          break;
        }
        case TAG_LList: {
          V v_t_2415 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2415;
          break;
        }
        case TAG_LRec: {
          V v_t_2417 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2417;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2419 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2418, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str2)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
      }
      case TAG_Cons: {
        V v_n_2420 = heff_field(v_it1_249, 0);
        V v_it12_2421 = heff_field(v_it1_249, 1);
        heff_take_n(v_it1_249, 3ULL, 2);
        switch (heff_tag_of(v_it12_2421)) {
        case TAG_Nil: {
          heff_drop(v_n_2420);
          V v_t_2430;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2423 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2423;
            break;
          }
          case TAG_LTag: {
            V v_t_2425 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2425;
            break;
          }
          case TAG_LList: {
            V v_t_2427 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2427;
            break;
          }
          case TAG_LRec: {
            V v_t_2429 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2429;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2431 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2430, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str3)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2431}});
        }
        case TAG_Cons: {
          V v_d_2432 = heff_field(v_it12_2421, 0);
          V v_it122_2433 = heff_field(v_it12_2421, 1);
          heff_take_n(v_it12_2421, 3ULL, 2);
          switch (heff_tag_of(v_it122_2433)) {
          case TAG_Nil: {
            heff_drop(v_x_240);
            HeffT2 v_t_2434 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_n_2420)));
            {
              V v_field_2436 = v_t_2434.f[1];
              int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
              if ((v_tag_2435 == ((int64_t)0ULL))) {
                heff_drop(v_n_2420);
                heff_drop(v_d_2432);
                V v_p_2438 = v_field_2436;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2438}});
              } else {
                V v_n_2439 = v_field_2436;
                V v_t_2440 = (g_heff_2ebuild_2eproject_2eisName(heff_dup(v_n_2439)));
                if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
                  heff_drop(v_n_2420);
                  heff_drop(v_t_2440);
                  HeffT2 v_t_2441 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_d_2432));
                  {
                    V v_field_2443 = v_t_2441.f[1];
                    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                    if ((v_tag_2442 == ((int64_t)0ULL))) {
                      heff_drop(v_n_2439);
                      V v_e_2445 = v_field_2443;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2445}});
                    } else {
                      V v_dir_2446 = v_field_2443;
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(2, shape_name__dir, (V[]){v_n_2439, v_dir_2446})}});
                    }
                  }
                } else {
                  heff_drop(v_d_2432);
                  heff_drop(v_t_2440);
                  V v_t_2455;
                  switch (heff_tag_of(v_n_2420)) {
                  case TAG_LStr: {
                    V v_t_2448 = heff_field(v_n_2420, 1);
                    heff_take_n(v_n_2420, 2ULL, 2);
                    v_t_2455 = v_t_2448;
                    break;
                  }
                  case TAG_LTag: {
                    V v_t_2450 = heff_field(v_n_2420, 1);
                    heff_take_n(v_n_2420, 2ULL, 2);
                    v_t_2455 = v_t_2450;
                    break;
                  }
                  case TAG_LList: {
                    V v_t_2452 = heff_field(v_n_2420, 1);
                    heff_take_n(v_n_2420, 2ULL, 2);
                    v_t_2455 = v_t_2452;
                    break;
                  }
                  case TAG_LRec: {
                    V v_t_2454 = heff_field(v_n_2420, 1);
                    heff_take_n(v_n_2420, 2ULL, 2);
                    v_t_2455 = v_t_2454;
                    break;
                  }
                  default: heff_nomatch(v_n_2420);
                  }
                  V v_t_2456 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str4), heff_strAppend(v_n_2439, ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str5)));
                  V v_f_2457 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2455, 2, 7), v_t_2456});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2457}});
                }
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2433, 0ULL, 2);
            heff_drop(v_n_2420);
            heff_drop(v_d_2432);
            V v_t_2468;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2461 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2468 = v_t_2461;
              break;
            }
            case TAG_LTag: {
              V v_t_2463 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2468 = v_t_2463;
              break;
            }
            case TAG_LList: {
              V v_t_2465 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2468 = v_t_2465;
              break;
            }
            case TAG_LRec: {
              V v_t_2467 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2468 = v_t_2467;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2469 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2468, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str6)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2469}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2433)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2421)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_249)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_names_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_n_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eclaimMsg_str0, 143, "error[E0347]: the package `heff` is heff's own, and this is not the checkout heff is built in or was installed from: name the project otherwise");

static V g_heff_2ebuild_2eproject_2eclaimMsg_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2eclaimMsg_st;
static V g_heff_2ebuild_2eproject_2eclaimMsg_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2eclaimMsg_str0);
}
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2eclaimMsg_st)) return g_heff_2ebuild_2eproject_2eclaimMsg_val;
  return heff_global(&g_heff_2ebuild_2eproject_2eclaimMsg_val, &g_heff_2ebuild_2eproject_2eclaimMsg_st, g_heff_2ebuild_2eproject_2eclaimMsg_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1, 19, "` is required twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3, 19, "` is replaced twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5, 31, "` is replaced, but not required");

HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s634456687x1151454243(heff_dup(v_rxs_240), heff_dup(v_rs_241)));
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_rxs_240);
      heff_drop(v_rs_241);
      heff_drop(v_pxs_242);
      heff_drop(v_ps_243);
      V v_it1_249 = v_field_247;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_MkPair: {
        V v_n_2410 = heff_field(v_it1_249, 0);
        V v_x_2411 = heff_field(v_it1_249, 1);
        heff_take_n(v_it1_249, 3ULL, 2);
        V v_t_2420;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_LStr: {
          V v_t_2413 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2413;
          break;
        }
        case TAG_LTag: {
          V v_t_2415 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2415;
          break;
        }
        case TAG_LList: {
          V v_t_2417 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2417;
          break;
        }
        case TAG_LRec: {
          V v_t_2419 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2419;
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0), heff_strAppend(v_n_2410, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1)));
        V v_f_2422 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2420, 2, 7), v_t_2421});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_249)}});
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2423 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
      HeffT2 v_t_2424 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_2423));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          heff_drop(v_rxs_240);
          heff_drop(v_rs_241);
          heff_drop(v_pxs_242);
          heff_drop(v_ps_243);
          V v_it1_2428 = v_field_2426;
          switch (heff_tag_of(v_it1_2428)) {
          case TAG_MkPair: {
            V v_n_2429 = heff_field(v_it1_2428, 0);
            V v_x_2430 = heff_field(v_it1_2428, 1);
            heff_take_n(v_it1_2428, 3ULL, 2);
            V v_t_2439;
            switch (heff_tag_of(v_x_2430)) {
            case TAG_LStr: {
              V v_t_2432 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2432;
              break;
            }
            case TAG_LTag: {
              V v_t_2434 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2434;
              break;
            }
            case TAG_LList: {
              V v_t_2436 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2436;
              break;
            }
            case TAG_LRec: {
              V v_t_2438 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2438;
              break;
            }
            default: heff_nomatch(v_x_2430);
            }
            V v_t_2440 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2), heff_strAppend(v_n_2429, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3)));
            V v_f_2441 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2439, 2, 7), v_t_2440});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2441}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2428)}});
          }
        } else {
          heff_drop(v_field_2426);
          V v_t_2442 = (g_list_2emap_24s1791433880x1360378684(heff_dup(v_rs_241)));
          V v_t_2443 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
          HeffT2 v_t_2444 = ({ V a_0 = v_t_2442; V a_1 = v_t_2443; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eunrequired_24cpr(a_0, a_1)); heff_drop(v_t_2442); r_; });
          {
            V v_field_2446 = v_t_2444.f[1];
            int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
            if ((v_tag_2445 == ((int64_t)0ULL))) {
              heff_drop(v_rxs_240);
              heff_drop(v_rs_241);
              heff_drop(v_pxs_242);
              heff_drop(v_ps_243);
              V v_it1_2448 = v_field_2446;
              switch (heff_tag_of(v_it1_2448)) {
              case TAG_MkPair: {
                V v_n_2449 = heff_field(v_it1_2448, 0);
                V v_x_2450 = heff_field(v_it1_2448, 1);
                heff_take_n(v_it1_2448, 3ULL, 2);
                V v_t_2459;
                switch (heff_tag_of(v_x_2450)) {
                case TAG_LStr: {
                  V v_t_2452 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2452;
                  break;
                }
                case TAG_LTag: {
                  V v_t_2454 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2454;
                  break;
                }
                case TAG_LList: {
                  V v_t_2456 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2456;
                  break;
                }
                case TAG_LRec: {
                  V v_t_2458 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2458;
                  break;
                }
                default: heff_nomatch(v_x_2450);
                }
                V v_t_2460 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4), heff_strAppend(v_n_2449, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5)));
                V v_f_2461 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2459, 2, 7), v_t_2460});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2461}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2448)}});
              }
            } else {
              heff_drop(v_field_2446);
              HEFF_LAST return g_heff_2ebuild_2eproject_2echeckHeff_24cpr(v_rxs_240, v_rs_241, v_pxs_242, v_ps_243);
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(v_rest_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_field_248);
          V v_p_2410 = v_field_245;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2410}});
        } else {
          V v_y_2411 = v_field_245;
          if ((v_tag_247 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_y_2411);
            V v_p_2413 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2413}});
          } else {
            V v_ys_2414 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_2411, v_ys_2414})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str1, 45, "` is no version: write `a.b.c`, three numbers");

HeffT2 g_heff_2ebuild_2eproject_2epackageOf4_24cpr(V v_m_240, V v_h_241, V v_rq_242, V v_rp_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_m_240));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_h_241);
      heff_drop(v_rq_242);
      heff_drop(v_rp_243);
      V v_p_248 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_248}});
    } else {
      V v_mpath_249 = v_field_246;
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_h_241)));
      V v_t_2432;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_h_241);
          V v_p_2414 = v_field_2412;
          v_t_2432 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2414});
        } else {
          V v_v_2415 = v_field_2412;
          HeffT2 v_t_2416 = (g_heff_2ebuild_2eproject_2eversion_24cpr(heff_dup(v_v_2415)));
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              heff_drop(v_h_241);
              V v_x_2420 = v_field_2418;
              heff_drop(v_x_2420);
              v_t_2432 = heff_tag_n(TAG_Right, 1, (V[]){v_v_2415});
            } else {
              heff_drop(v_field_2418);
              V v_t_2429;
              switch (heff_tag_of(v_h_241)) {
              case TAG_LStr: {
                V v_t_2422 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2429 = v_t_2422;
                break;
              }
              case TAG_LTag: {
                V v_t_2424 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2429 = v_t_2424;
                break;
              }
              case TAG_LList: {
                V v_t_2426 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2429 = v_t_2426;
                break;
              }
              case TAG_LRec: {
                V v_t_2428 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2429 = v_t_2428;
                break;
              }
              default: heff_nomatch(v_h_241);
              }
              V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str0), heff_strAppend(v_v_2415, ((V)&g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str1)));
              V v_t_2431 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2429, 2, 7), v_t_2430});
              v_t_2432 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
            }
          }
        }
      }
      switch (heff_tag_of(v_t_2432)) {
      case TAG_Left: {
        V v_p_2433 = heff_field(v_t_2432, 0);
        heff_take_n(v_t_2432, 1ULL, 1);
        heff_drop(v_rq_242);
        heff_drop(v_rp_243);
        heff_drop(v_mpath_249);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2433}});
      }
      case TAG_Right: {
        V v_hv_2434 = heff_field(v_t_2432, 0);
        heff_take_n(v_t_2432, 1ULL, 1);
        HeffT2 v_t_2435 = (g_heff_2ebuild_2eproject_2eitems_24cpr(v_rq_242));
        {
          V v_field_2437 = v_t_2435.f[1];
          int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
          if ((v_tag_2436 == ((int64_t)0ULL))) {
            heff_drop(v_rp_243);
            heff_drop(v_mpath_249);
            heff_drop(v_hv_2434);
            V v_p_2439 = v_field_2437;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2439}});
          } else {
            V v_rxs_2440 = v_field_2437;
            HeffT2 v_t_2441 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(heff_dup(v_rxs_2440)));
            {
              V v_field_2443 = v_t_2441.f[1];
              int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
              if ((v_tag_2442 == ((int64_t)0ULL))) {
                heff_drop(v_rp_243);
                heff_drop(v_mpath_249);
                heff_drop(v_hv_2434);
                heff_drop(v_rxs_2440);
                V v_p_2445 = v_field_2443;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2445}});
              } else {
                V v_rs_2446 = v_field_2443;
                HeffT2 v_t_2447 = (g_heff_2ebuild_2eproject_2eitems_24cpr(v_rp_243));
                {
                  V v_field_2449 = v_t_2447.f[1];
                  int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                  if ((v_tag_2448 == ((int64_t)0ULL))) {
                    heff_drop(v_mpath_249);
                    heff_drop(v_hv_2434);
                    heff_drop(v_rxs_2440);
                    heff_drop(v_rs_2446);
                    V v_p_2451 = v_field_2449;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2451}});
                  } else {
                    V v_pxs_2452 = v_field_2449;
                    HeffT2 v_t_2453 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(heff_dup(v_pxs_2452)));
                    {
                      V v_field_2455 = v_t_2453.f[1];
                      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                      if ((v_tag_2454 == ((int64_t)0ULL))) {
                        heff_drop(v_mpath_249);
                        heff_drop(v_hv_2434);
                        heff_drop(v_rxs_2440);
                        heff_drop(v_rs_2446);
                        heff_drop(v_pxs_2452);
                        V v_p_2457 = v_field_2455;
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2457}});
                      } else {
                        V v_ps_2458 = v_field_2455;
                        HeffT2 v_t_2459 = (g_heff_2ebuild_2eproject_2echeckNames_24cpr(v_rxs_2440, heff_dup(v_rs_2446), v_pxs_2452, heff_dup(v_ps_2458)));
                        {
                          V v_field_2461 = v_t_2459.f[1];
                          int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                          if ((v_tag_2460 == ((int64_t)0ULL))) {
                            heff_drop(v_mpath_249);
                            heff_drop(v_hv_2434);
                            heff_drop(v_rs_2446);
                            heff_drop(v_ps_2458);
                            V v_p_2463 = v_field_2461;
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2463}});
                          } else {
                            V v_x_2464 = v_field_2461;
                            heff_drop(v_x_2464);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(4, shape_module__heff__require__replace, (V[]){v_mpath_249, v_hv_2434, v_rs_2446, v_ps_2458})}});
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2432)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str0, 6, "module");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str1, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str2, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str3, 7, "replace");
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam0, 1, 0};
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam1, 1, 0};

static V g_heff_2ebuild_2eproject_2epackageFields_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2epackageFields_st;
static V g_heff_2ebuild_2eproject_2epackageFields_init(void) {
  V v_t_240 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str0), NTAG(TAG_Nothing)});
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam0_clo)})});
  V v_t_245 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str3), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_246})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_247});
}
V g_heff_2ebuild_2eproject_2epackageFields_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2epackageFields_st)) return g_heff_2ebuild_2eproject_2epackageFields_val;
  return heff_global(&g_heff_2ebuild_2eproject_2epackageFields_val, &g_heff_2ebuild_2eproject_2epackageFields_st, g_heff_2ebuild_2eproject_2epackageFields_init);
}
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_242});
}
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_244});
}
Clo g_heff_2ebuild_2eproject_2epackageOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epackageOf(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2epackageOf(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eclaimOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eclaimOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eclaimOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Left: {
    return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
  }
  case TAG_Right: {
    V v_x_242 = heff_field(v_x1_240, 0);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()), heff_dup(v_x_242)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        heff_drop(v_x_247);
        return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
      } else {
        V v_x11_248 = v_field_245;
        switch (heff_tag_of(v_x11_248)) {
        case TAG_Nil: {
          return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
        }
        case TAG_Cons: {
          V v_m_249 = heff_field(v_x11_248, 0);
          heff_take_n(v_x11_248, 1ULL, 2);
          V v_t_2419;
          switch (heff_tag_of(v_m_249)) {
          case TAG_LStr: {
            V v_t_2412 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2412;
            break;
          }
          case TAG_LTag: {
            V v_t_2414 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2414;
            break;
          }
          case TAG_LList: {
            V v_t_2416 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2416;
            break;
          }
          case TAG_LRec: {
            V v_t_2418 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2418;
            break;
          }
          default: heff_nomatch(v_m_249);
          }
          return heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2419, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
        }
        default: return heff_nomatch(v_x11_248);
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eclaimOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str0, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str1, 72, "a program ships no `bin`: the heff home's bin/ is where the programs are");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str4, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str6, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str7, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str8, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str9, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str10, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str12, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str13, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str14, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str15, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str16, 92, "` is not a name: a program ships files and directories of the project's root, by their names");

HeffT2 g_heff_2ebuild_2eproject_2eshipWrong_24cpr(V v_n_240) {
top: ;
  if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str0), 2)) {
    heff_drop(v_n_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str1)}});
  } else {
    if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str2), 2)) {
      V v_f_243 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str3), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str4)));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
    } else {
      if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str5), 2)) {
        V v_f_245 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str6), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str7)));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
      } else {
        if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str8), 2)) {
          V v_f_247 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str9), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str10)));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
        } else {
          if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str11), v_n_240, MK_INT(0LL), 5))) {
            V v_f_249 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str12), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str13)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
          } else {
            if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str14), v_n_240, MK_INT(0LL), 5))) {
              V v_f_2411 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str15), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str16)));
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
            } else {
              heff_drop(v_n_240);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_x_241)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_241);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_p_247 = v_field_245;
        V v_x2_248 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
        heff_drop(v_x2_248);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_247}});
      } else {
        V v_n_249 = v_field_245;
        HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2eshipWrong_24cpr(heff_dup(v_n_249)));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_n_249);
            V v_why_2414 = v_field_2412;
            V v_x2_2415 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
            heff_drop(v_x2_2415);
            V v_t_2424;
            switch (heff_tag_of(v_x_241)) {
            case TAG_LStr: {
              V v_t_2417 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2417;
              break;
            }
            case TAG_LTag: {
              V v_t_2419 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2419;
              break;
            }
            case TAG_LList: {
              V v_t_2421 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2421;
              break;
            }
            case TAG_LRec: {
              V v_t_2423 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2423;
              break;
            }
            default: heff_nomatch(v_x_241);
            }
            V v_f_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), v_why_2414});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
          } else {
            heff_drop(v_x_241);
            heff_drop(v_field_2412);
            HeffT2 v_t_2426 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_rest_242));
            {
              V v_field_2428 = v_t_2426.f[1];
              int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
              if ((v_tag_2427 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop(v_n_249);
                V v_p_2430 = v_field_2428;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2430}});
              } else {
                V v_ys_2431 = v_field_2428;
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_n_249, v_ys_2431})}});
              }
            }
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str1, 5, "build");

HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_242 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_240), v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_244 = v_t_242.f[1];
    heff_drop(v_t_242.f[0]);
    heff_drop(v_t_242.f[2]);
    switch (heff_tag_of(v_field_244)) {
    case TAG_Nil: {
      V v_t_246 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      HeffT3 v_t_247 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_246, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2411;
      {
        V v_field_248 = v_t_247.f[0];
        heff_drop(v_t_247.f[1]);
        heff_drop(v_t_247.f[2]);
        v_t_2411 = v_field_248;
      }
      HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(((V)&g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str0), ((V)&g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str1), heff_arrayFromList(v_t_2411), MK_INT(0LL), NTAG(TAG_Nothing)));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_p_2416 = v_field_2414;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2416}});
        } else {
          V v_x_2417 = v_field_2414;
          HEFF_LAST return g_heff_2ebuild_2eproject_2ebuildOf_24cpr(v_x_2417);
        }
      }
    }
    case TAG_Cons: {
      V v_e_2418 = heff_field(v_field_244, 0);
      heff_take_n(v_field_244, 1ULL, 2);
      heff_drop(v_src_240);
      V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_take_field(v_e_2418, 0), heff_get_n(v_e_2418, 2, 3)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
    }
    default: return ((HeffT2){{heff_nomatch(v_field_244)}});
    }
  }
}
Clo g_heff_2ebuild_2eproject_2enewerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewerGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewerGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c(heff_dup(v_y_244), heff_dup(v_x_242))) {
        return NTAG(TAG_True);
      } else {
        if (heff_intEq_c(heff_dup(v_x_242), heff_dup(v_y_244))) {
          V t_0 = v_xs_243;
          V t_1 = v_ys_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2enewerGo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str2, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str4, 1, "/");
Clo g_heff_2ebuild_2eproject_2erepoOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erepoOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2erepoOf(V v_path_240) {
top: ;
  V v_xs_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2erepoOf_str0), heff_dup(v_path_240), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str1), v_path_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_x_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    v_x_245 = heff_dup(v_path_240);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    v_x_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_245, 0)))) {
    if (heff_strEq_c(heff_strSlice_lent(v_x_245, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ebuild_2eproject_2erepoOf_str2))) {
      V v_t_248 = heff_strSlice(heff_dup(v_x_245), MK_INT(1LL), heff_strLength(v_x_245));
      V v_t_249 = (g_heff_2ebuild_2eproject_2eisNumber(v_t_248));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_xs_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2erepoOf_str3), heff_dup(v_path_240), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str4), v_path_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nil: {
          v_t_2414 = heff_dup(v_path_240);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_t_2411, 0);
          heff_take_n(v_t_2411, 1ULL, 2);
          v_t_2414 = v_x_2412;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_path_240, 0)) - heff_unbox_word(heff_strLength(v_t_2414)));
        return heff_strSlice(v_path_240, MK_INT(0LL), heff_box_word((v_t_2415 - ((int64_t)1ULL))));
      } else {
        heff_drop(v_t_249);
        return v_path_240;
      }
    } else {
      heff_drop(v_x_245);
      return v_path_240;
    }
  } else {
    heff_drop(v_x_245);
    return v_path_240;
  }
}
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erepoOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str0, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str1, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str3, 30, "` is no version: write `a.b.c`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str4, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");

HeffT2 g_heff_2ebuild_2eproject_2esumLine_24cpr(V v_at_240, V v_line_241) {
top: ;
  V v_it_242 = (g_prelude_2ewordsFrom(v_line_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_it2_244 = heff_field(v_it_242, 1);
    V v_ru_24it_242_24Cons = heff_take_reuse_n(v_it_242, 3ULL, 2);
    switch (heff_tag_of(v_it2_244)) {
    case TAG_Nil: {
      heff_drop(v_p_243);
      heff_drop_cell(v_ru_24it_242_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str0)})}});
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_it2_244, 0);
      V v_it22_246 = heff_field(v_it2_244, 1);
      heff_take_n(v_it2_244, 3ULL, 2);
      switch (heff_tag_of(v_it22_246)) {
      case TAG_Nil: {
        heff_drop(v_p_243);
        heff_drop_cell(v_ru_24it_242_24Cons, 2);
        heff_drop(v_v_245);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str1)})}});
      }
      case TAG_Cons: {
        V v_h_247 = heff_field(v_it22_246, 0);
        V v_it222_248 = heff_field(v_it22_246, 1);
        heff_take_n(v_it22_246, 3ULL, 2);
        switch (heff_tag_of(v_it222_248)) {
        case TAG_Nil: {
          HeffT2 v_t_249 = (g_heff_2ebuild_2eproject_2eversion_24cpr(heff_dup(v_v_245)));
          {
            V v_field_2411 = v_t_249.f[1];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              heff_drop(v_at_240);
              V v_x_2413 = v_field_2411;
              heff_drop(v_x_2413);
              V v_t_2414 = heff_tag_at_n(v_ru_24it_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_p_243, v_v_245, v_h_247}), NTAG(TAG_Nil)});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2414}});
            } else {
              heff_drop(v_p_243);
              heff_drop_cell(v_ru_24it_242_24Cons, 2);
              heff_drop(v_h_247);
              heff_drop(v_field_2411);
              V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str2), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str3)));
              V v_f_2416 = heff_rec_n(2, shape_at__msg, (V[]){v_at_240, v_t_2415});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
            }
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_248, 0ULL, 2);
          heff_drop(v_p_243);
          heff_drop_cell(v_ru_24it_242_24Cons, 2);
          heff_drop(v_v_245);
          heff_drop(v_h_247);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str4)})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it222_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_242)}});
  }
}

HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2esumLine_24cpr(heff_dup(v_at_240), heff_dup(v_l_242)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_at_240);
        heff_drop(v_l_242);
        heff_drop(v_rest_243);
        V v_p_248 = v_field_246;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_248}});
      } else {
        V v_xs_249 = v_field_246;
        V v_t_2410 = heff_intAdd(v_at_240, heff_strLength(v_l_242));
        HeffT2 v_t_2411 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(heff_intAdd(v_t_2410, MK_INT(1LL)), v_rest_243));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_xs_249);
            V v_x_2415 = v_field_2413;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2415}});
          } else {
            V v_y_2416 = v_field_2413;
            V v_f_2417 = (g_prelude_2e_2b_2b(v_xs_249, v_y_2416));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2417}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ebuild_2eproject_2esumBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2esumBefore_entry, 2, 0};

V g_heff_2ebuild_2eproject_2esumBefore(V v_a_240, V v_b_241) {
top: ;
  if (heff_strLt_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
    heff_drop_rec(v_a_240, 3);
    heff_drop_rec(v_b_241, 3);
    return NTAG(TAG_True);
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
      HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2eversion_24cpr(heff_get_n(v_a_240, 1, 3)));
      V v_t_249;
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_x_248 = v_field_246;
          v_t_249 = v_x_248;
        } else {
          heff_drop(v_field_246);
          v_t_249 = NTAG(TAG_Nil);
        }
      }
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2eversion_24cpr(heff_get_n(v_b_241, 1, 3)));
      V v_t_2415;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2412;
          v_t_2415 = v_x_2414;
        } else {
          heff_drop(v_field_2412);
          v_t_2415 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2416 = ({ V a_0 = v_t_249; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_249); heff_drop(v_t_2415); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2416) == NTAG(TAG_True)));
      heff_drop(v_x1_2416);
      return v_ret_24bool;
    } else {
      heff_drop_rec(v_a_240, 3);
      heff_drop_rec(v_b_241, 3);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2esumBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str1, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str2, 7, "package");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str3, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str4, 1, "=");

HeffT2 g_heff_2ebuild_2eproject_2espanGo_24cpr(V v_ts_240, V v_i_241) {
top: ;
  V v_t_245;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0))) {
      V v_t_244 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
      v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      v_t_245 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_245 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_ts_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_t_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str0))) {
      heff_drop(v_ts_240);
      heff_drop(v_i_241);
      heff_drop_rec(v_t_246, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V v_t_2415 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str1)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 1)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str2)) && ({ V v_i_2410 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)); int c_ = (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2410)) && (heff_intLt_c(heff_dup(v_i_2410), heff_arrayLength_lent(v_ts_240, 0)) && ({ V v_t_2413 = heff_arrayIndex_lent(v_ts_240, v_i_2410, 0); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 0)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str3)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 1)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str4))); heff_drop(v_t_2413); c_; }))); heff_drop(v_i_2410); c_; }))));
      heff_drop_rec(v_t_246, 7);
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        HeffT2 v_t_2416 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(heff_dup(v_ts_240), heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            heff_drop(v_ts_240);
            heff_drop(v_i_241);
            V v_it1_2420 = v_field_2418;
            heff_drop(v_it1_2420);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            V v_it1_2421 = v_field_2418;
            switch (heff_tag_of(v_it1_2421)) {
            case TAG_MkPair: {
              V v_j_2423 = heff_field(v_it1_2421, 1);
              V v_ru_24it1_2421_24MkPair = heff_take_reuse_n(v_it1_2421, 2ULL, 2);
              V v_i_2424 = heff_intAdd(v_i_241, MK_INT(2LL));
              if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2424))) {
                if (heff_intLt_c(heff_dup(v_i_2424), heff_arrayLength_lent(v_ts_240, 0))) {
                  V v_opening_2427 = heff_arrayIndex_lent(v_ts_240, v_i_2424, 2);
                  V v_i_2428 = heff_intSub(v_j_2423, MK_INT(1LL));
                  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2428))) {
                    if (heff_intLt_c(heff_dup(v_i_2428), heff_arrayLength_lent(v_ts_240, 0))) {
                      V v_closing_2431 = heff_arrayIndex(v_ts_240, v_i_2428);
                      V v_f_2432 = heff_tag_at_n(v_ru_24it1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_opening_2427, 2, 7), heff_get_n(v_closing_2431, 3, 7)});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
                    } else {
                      heff_drop(v_ts_240);
                      heff_drop_cell(v_ru_24it1_2421_24MkPair, 2);
                      heff_drop_rec(v_opening_2427, 7);
                      heff_drop(v_i_2428);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  } else {
                    heff_drop(v_ts_240);
                    heff_drop_cell(v_ru_24it1_2421_24MkPair, 2);
                    heff_drop_rec(v_opening_2427, 7);
                    heff_drop(v_i_2428);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                } else {
                  heff_drop(v_ts_240);
                  heff_drop(v_j_2423);
                  heff_drop_cell(v_ru_24it1_2421_24MkPair, 2);
                  heff_drop(v_i_2424);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop(v_ts_240);
                heff_drop(v_j_2423);
                heff_drop_cell(v_ru_24it1_2421_24MkPair, 2);
                heff_drop(v_i_2424);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_it1_2421)}});
            }
          }
        }
      } else {
        heff_drop(v_t_2415);
        V v_t_2433 = (g_heff_2ebuild_2eproject_2enextDecl(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(1LL))));
        V t_0 = v_ts_240;
        V t_1 = v_t_2433;
        v_ts_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_245)}});
  }
}
Clo g_heff_2ebuild_2eproject_2ewithPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ewithPackage_entry, 2, 0};

V g_heff_2ebuild_2eproject_2ewithPackage(V v_src_240, V v_pk_241) {
top: ;
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_240), v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_247;
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    v_t_247 = v_field_244;
  }
  HeffT2 v_t_248 = (g_heff_2ebuild_2eproject_2espanGo_24cpr(heff_arrayFromList(v_t_247), MK_INT(0LL)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_it1_2412 = v_field_2410;
      switch (heff_tag_of(v_it1_2412)) {
      case TAG_MkPair: {
        V v_from_2413 = heff_field(v_it1_2412, 0);
        V v_to_2414 = heff_field(v_it1_2412, 1);
        heff_take_n(v_it1_2412, 3ULL, 2);
        V v_t_2415 = (g_heff_2ebuild_2eproject_2eshowPackage(v_pk_241));
        V v_t_2416 = heff_strSlice(heff_dup(v_src_240), v_to_2414, heff_strLength_lent(v_src_240, 0));
        return heff_strAppend(heff_strSlice(v_src_240, MK_INT(0LL), v_from_2413), heff_strAppend(v_t_2415, v_t_2416));
      }
      default: return heff_nomatch(v_it1_2412);
      }
    } else {
      heff_drop(v_pk_241);
      heff_drop(v_field_2410);
      return v_src_240;
    }
  }
}
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2ewithPackage(a[0], a[1]);
}