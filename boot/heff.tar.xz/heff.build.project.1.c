// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_cmt 308164
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_version 583465758
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__dir[] = {LBL_name, LBL_dir};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V);
V g_heff_2ebuild_2eproject_2eandList(V);
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_clo;
V g_heff_2ebuild_2eproject_2eandList_24acc(V, V);
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo;
HeffT2 g_heff_2ebuild_2eproject_2ebuildOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2echeckHeff_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V, V, V);
V g_heff_2ebuild_2eproject_2efieldsSaid(V);
V g_heff_2ebuild_2eproject_2efieldsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsSaid_clo;
V g_heff_2ebuild_2eproject_2eisNameByte(V);
V g_heff_2ebuild_2eproject_2eisNameByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNameByte_clo;
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames(V);
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo;
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo;
HeffT2 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2enameOf_24cpr(V);
V g_heff_2ebuild_2eproject_2enameRule_get(void);
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2enewerKey(V, V);
V g_heff_2ebuild_2eproject_2enewerKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerKey_clo;
V g_heff_2ebuild_2eproject_2enextDecl(V, V);
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enextDecl_clo;
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf4_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(V);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2erequiredOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eshipWrong_24cpr(V);
V g_heff_2ebuild_2eproject_2eshowPackage(V);
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eshowPackage_clo;
HeffT2 g_heff_2ebuild_2eproject_2espanGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2esumLine_24cpr(V, V);
V g_heff_2ebuild_2eproject_2etestsModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_list_2eall_24s494596359x1928238377(V);
V g_list_2eall_24s494596359x1928238377_entry(V self, V *a);
extern Clo g_list_2eall_24s494596359x1928238377_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f768999161x1997188166(V, V, V);
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_clo;
V g_list_2emap_24s1703643582x349630108(V, V);
V g_list_2emap_24s1703643582x349630108_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str6, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str7, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str8, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str9, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str10, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str11, 42, "the text ends where more of it is expected");

HeffT2 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_acc_242);
      V v_p_247 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_247}});
    } else {
      V v_it1_248 = v_field_245;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_it1_248, 0);
        V v_j_2410 = heff_field(v_it1_248, 1);
        V v_ru_24it1_248_24MkPair = heff_take_reuse_n(v_it1_248, 3ULL, 2);
        if (heff_intLe_c_lent(MK_INT(0LL), v_j_2410, 1)) {
          if (heff_intLt_c(heff_dup(v_j_2410), heff_arrayLength_lent(v_ts_240, 0))) {
            V v_t_2413 = heff_arrayIndex_lent(v_ts_240, v_j_2410, 0);
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 0)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0))) {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 1)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1))) {
                heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
                heff_drop_rec(v_t_2413, 7);
                V t_0 = v_ts_240;
                V t_1 = heff_box_word((heff_unbox_word(v_j_2410) + ((int64_t)1ULL)));
                V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_acc_242});
                v_ts_240 = t_0;
                v_i_241 = t_1;
                v_acc_242 = t_2;
                goto top;
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 0)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2))) {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 1)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3))) {
                    heff_drop_rec(v_t_2413, 7);
                    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_acc_242})));
                    V v_f_2419 = heff_tag_at_n(v_ru_24it1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, heff_box_word((heff_unbox_word(v_j_2410) + ((int64_t)1ULL)))});
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2419}});
                  } else {
                    heff_drop(v_acc_242);
                    heff_drop(v_x_249);
                    heff_drop(v_j_2410);
                    heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
                    V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4)});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
                  }
                } else {
                  heff_drop(v_acc_242);
                  heff_drop(v_x_249);
                  heff_drop(v_j_2410);
                  heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
                  V v_f_2421 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
                }
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 0)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str6))) {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_2413, 1)), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str7))) {
                  heff_drop_rec(v_t_2413, 7);
                  V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_acc_242})));
                  V v_f_2425 = heff_tag_at_n(v_ru_24it1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, heff_box_word((heff_unbox_word(v_j_2410) + ((int64_t)1ULL)))});
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2425}});
                } else {
                  heff_drop(v_acc_242);
                  heff_drop(v_x_249);
                  heff_drop(v_j_2410);
                  heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
                  V v_f_2426 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str8)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
                }
              } else {
                heff_drop(v_acc_242);
                heff_drop(v_x_249);
                heff_drop(v_j_2410);
                heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
                V v_f_2427 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str9)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
              }
            }
          } else {
            heff_drop(v_acc_242);
            heff_drop(v_x_249);
            heff_drop(v_j_2410);
            heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
            int64_t v_i_2428 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
            V v_t_2432;
            if ((((int64_t)0ULL) <= v_i_2428)) {
              if ((v_i_2428 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                V v_t_2431 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2428), 2);
                v_t_2432 = heff_get_n(v_t_2431, 2, 7);
              } else {
                v_t_2432 = MK_INT(0LL);
              }
            } else {
              v_t_2432 = MK_INT(0LL);
            }
            V v_f_2433 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2432, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str10)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
          }
        } else {
          heff_drop(v_acc_242);
          heff_drop(v_x_249);
          heff_drop(v_j_2410);
          heff_drop_cell(v_ru_24it1_248_24MkPair, 2);
          int64_t v_i_2434 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
          V v_t_2438;
          if ((((int64_t)0ULL) <= v_i_2434)) {
            if ((v_i_2434 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
              V v_t_2437 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2434), 2);
              v_t_2438 = heff_get_n(v_t_2437, 2, 7);
            } else {
              v_t_2438 = MK_INT(0LL);
            }
          } else {
            v_t_2438 = MK_INT(0LL);
          }
          V v_f_2439 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str11)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2439}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_248)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6, 1, "}");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10, 1, "}");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str13, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str14, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str15, 12, "expected `=`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str16, 12, "expected `=`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str17, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str18, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str19, 23, "expected a field's name");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str20, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str21, 42, "the text ends where more of it is expected");

HeffT2 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V v_ts_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((((int64_t)0ULL) <= v_i_241)) {
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
      V v_name_245 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_241), 2);
      if (heff_strEq_c(heff_dup(heff_rfield(v_name_245, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0))) {
        int64_t v_i_247 = (v_i_241 + ((int64_t)1ULL));
        if ((((int64_t)0ULL) <= v_i_247)) {
          if ((v_i_247 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
            V v_eq_2410 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_247), 2);
            if (heff_strEq_c(heff_dup(heff_rfield(v_eq_2410, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1))) {
              if (heff_strEq_c(heff_dup(heff_rfield(v_eq_2410, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2))) {
                heff_drop_rec(v_eq_2410, 7);
                HeffT2 v_t_2413 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, heff_intAdd(heff_box_word(v_i_241), MK_INT(2LL))));
                {
                  V v_field_2415 = v_t_2413.f[1];
                  int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                  if ((v_tag_2414 == ((int64_t)0ULL))) {
                    heff_drop(v_acc_242);
                    heff_drop_rec(v_name_245, 7);
                    V v_p_2417 = v_field_2415;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2417}});
                  } else {
                    V v_it1_2418 = v_field_2415;
                    switch (heff_tag_of(v_it1_2418)) {
                    case TAG_MkPair: {
                      V v_x_2419 = heff_field(v_it1_2418, 0);
                      V v_j_2420 = heff_field(v_it1_2418, 1);
                      V v_ru_24it1_2418_24MkPair = heff_take_reuse_n(v_it1_2418, 3ULL, 2);
                      if (heff_intLe_c_lent(MK_INT(0LL), v_j_2420, 1)) {
                        if (heff_intLt_c(heff_dup(v_j_2420), heff_arrayLength_lent(v_ts_240, 0))) {
                          V v_t_2423 = heff_arrayIndex_lent(v_ts_240, v_j_2420, 0);
                          if (heff_strEq_c(heff_dup(heff_rfield(v_t_2423, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3))) {
                            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2423, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4))) {
                              heff_drop_rec(v_t_2423, 7);
                              V v_t_2426 = heff_tag_at_n(v_ru_24it1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_name_245, 1, 7), v_x_2419});
                              V t_0 = v_ts_240;
                              int64_t t_1 = (heff_unbox_word(v_j_2420) + ((int64_t)1ULL));
                              V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_acc_242});
                              v_ts_240 = t_0;
                              v_i_241 = t_1;
                              v_acc_242 = t_2;
                              goto top;
                            } else {
                              if (heff_strEq_c(heff_dup(heff_rfield(v_t_2423, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5))) {
                                if (heff_strEq_c(heff_dup(heff_rfield(v_t_2423, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6))) {
                                  heff_drop_rec(v_t_2423, 7);
                                  V v_t_2429 = heff_tag_at_n(v_ru_24it1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_name_245, 1, 7), v_x_2419});
                                  V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_acc_242})));
                                  V v_f_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, heff_box_word((heff_unbox_word(v_j_2420) + ((int64_t)1ULL)))});
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2431}});
                                } else {
                                  heff_drop(v_acc_242);
                                  heff_drop_rec(v_name_245, 7);
                                  heff_drop(v_x_2419);
                                  heff_drop(v_j_2420);
                                  heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                                  V v_f_2432 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7)});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
                                }
                              } else {
                                heff_drop(v_acc_242);
                                heff_drop_rec(v_name_245, 7);
                                heff_drop(v_x_2419);
                                heff_drop(v_j_2420);
                                heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                                V v_f_2433 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8)});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
                              }
                            }
                          } else {
                            if (heff_strEq_c(heff_dup(heff_rfield(v_t_2423, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9))) {
                              if (heff_strEq_c(heff_dup(heff_rfield(v_t_2423, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10))) {
                                heff_drop_rec(v_t_2423, 7);
                                V v_t_2436 = heff_tag_at_n(v_ru_24it1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_name_245, 1, 7), v_x_2419});
                                V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_acc_242})));
                                V v_f_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, heff_box_word((heff_unbox_word(v_j_2420) + ((int64_t)1ULL)))});
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2438}});
                              } else {
                                heff_drop(v_acc_242);
                                heff_drop_rec(v_name_245, 7);
                                heff_drop(v_x_2419);
                                heff_drop(v_j_2420);
                                heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                                V v_f_2439 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11)});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2439}});
                              }
                            } else {
                              heff_drop(v_acc_242);
                              heff_drop_rec(v_name_245, 7);
                              heff_drop(v_x_2419);
                              heff_drop(v_j_2420);
                              heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                              V v_f_2440 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12)});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2440}});
                            }
                          }
                        } else {
                          heff_drop(v_acc_242);
                          heff_drop_rec(v_name_245, 7);
                          heff_drop(v_x_2419);
                          heff_drop(v_j_2420);
                          heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                          int64_t v_i_2441 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
                          V v_t_2445;
                          if ((((int64_t)0ULL) <= v_i_2441)) {
                            if ((v_i_2441 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                              V v_t_2444 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2441), 2);
                              v_t_2445 = heff_get_n(v_t_2444, 2, 7);
                            } else {
                              v_t_2445 = MK_INT(0LL);
                            }
                          } else {
                            v_t_2445 = MK_INT(0LL);
                          }
                          V v_f_2446 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2445, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str13)});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
                        }
                      } else {
                        heff_drop(v_acc_242);
                        heff_drop_rec(v_name_245, 7);
                        heff_drop(v_x_2419);
                        heff_drop(v_j_2420);
                        heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                        int64_t v_i_2447 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
                        V v_t_2451;
                        if ((((int64_t)0ULL) <= v_i_2447)) {
                          if ((v_i_2447 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                            V v_t_2450 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2447), 2);
                            v_t_2451 = heff_get_n(v_t_2450, 2, 7);
                          } else {
                            v_t_2451 = MK_INT(0LL);
                          }
                        } else {
                          v_t_2451 = MK_INT(0LL);
                        }
                        V v_f_2452 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2451, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str14)});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2452}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_it1_2418)}});
                    }
                  }
                }
              } else {
                heff_drop(v_acc_242);
                heff_drop_rec(v_name_245, 7);
                V v_f_2453 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_eq_2410, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str15)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2453}});
              }
            } else {
              heff_drop(v_acc_242);
              heff_drop_rec(v_name_245, 7);
              V v_f_2454 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_eq_2410, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str16)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2454}});
            }
          } else {
            heff_drop(v_acc_242);
            heff_drop_rec(v_name_245, 7);
            int64_t v_i_2455 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
            V v_t_2459;
            if ((((int64_t)0ULL) <= v_i_2455)) {
              if ((v_i_2455 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                V v_t_2458 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2455), 2);
                v_t_2459 = heff_get_n(v_t_2458, 2, 7);
              } else {
                v_t_2459 = MK_INT(0LL);
              }
            } else {
              v_t_2459 = MK_INT(0LL);
            }
            V v_f_2460 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2459, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str17)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2460}});
          }
        } else {
          heff_drop(v_acc_242);
          heff_drop_rec(v_name_245, 7);
          int64_t v_i_2461 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
          V v_t_2465;
          if ((((int64_t)0ULL) <= v_i_2461)) {
            if ((v_i_2461 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
              V v_t_2464 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2461), 2);
              v_t_2465 = heff_get_n(v_t_2464, 2, 7);
            } else {
              v_t_2465 = MK_INT(0LL);
            }
          } else {
            v_t_2465 = MK_INT(0LL);
          }
          V v_f_2466 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2465, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str18)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2466}});
        }
      } else {
        heff_drop(v_acc_242);
        V v_f_2467 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_name_245, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str19)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2467}});
      }
    } else {
      heff_drop(v_acc_242);
      int64_t v_i_2468 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
      V v_t_2472;
      if ((((int64_t)0ULL) <= v_i_2468)) {
        if ((v_i_2468 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
          V v_t_2471 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2468), 2);
          v_t_2472 = heff_get_n(v_t_2471, 2, 7);
        } else {
          v_t_2472 = MK_INT(0LL);
        }
      } else {
        v_t_2472 = MK_INT(0LL);
      }
      V v_f_2473 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2472, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str20)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2473}});
    }
  } else {
    heff_drop(v_acc_242);
    int64_t v_i_2474 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2478;
    if ((((int64_t)0ULL) <= v_i_2474)) {
      if ((v_i_2474 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
        V v_t_2477 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2474), 2);
        v_t_2478 = heff_get_n(v_t_2477, 2, 7);
      } else {
        v_t_2478 = MK_INT(0LL);
      }
    } else {
      v_t_2478 = MK_INT(0LL);
    }
    V v_f_2479 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2478, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str21)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2479}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3, 1, "[");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9, 1, "{");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str11, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str12, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str13, 1, "{");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str14, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str15, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str16, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str17, 42, "the text ends where more of it is expected");

HeffT2 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V v_ts_240, V v_i_241) {
top: ;
  if (heff_intLe_c_lent(MK_INT(0LL), v_i_241, 1)) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0))) {
      V v_t_244 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0))) {
        V v_t_246 = heff_tag_n(TAG_LStr, 2, (V[]){heff_dup(heff_rfield(v_t_244, 1)), v_t_244});
        V v_f_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_247}});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1))) {
          V v_t_249 = heff_tag_n(TAG_LTag, 2, (V[]){heff_dup(heff_rfield(v_t_244, 1)), v_t_244});
          V v_f_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2410}});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2))) {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3))) {
              int64_t v_i_2413 = (heff_peek_word(v_i_241) + ((int64_t)1ULL));
              if ((((int64_t)0ULL) <= v_i_2413)) {
                if ((v_i_2413 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                  V v_next_2416 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2413), 2);
                  if (heff_strEq_c(heff_dup(heff_rfield(v_next_2416, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4))) {
                    if (heff_strEq_c(heff_get_n(v_next_2416, 1, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5))) {
                      V v_t_2419 = heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_244});
                      V v_f_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, heff_intAdd(v_i_241, MK_INT(2LL))});
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2420}});
                    } else {
                      HeffT2 v_t_2421 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), NTAG(TAG_Nil)));
                      {
                        V v_field_2423 = v_t_2421.f[1];
                        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                        if ((v_tag_2422 == ((int64_t)0ULL))) {
                          heff_drop_rec(v_t_244, 7);
                          V v_p_2425 = v_field_2423;
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2425}});
                        } else {
                          V v_x21_2426 = v_field_2423;
                          switch (heff_tag_of(v_x21_2426)) {
                          case TAG_MkPair: {
                            V v_xs_2427 = heff_field(v_x21_2426, 0);
                            V v_j_2428 = heff_field(v_x21_2426, 1);
                            V v_ru_24x21_2426_24MkPair = heff_take_reuse_n(v_x21_2426, 3ULL, 2);
                            V v_t_2429 = heff_tag_at_n(v_ru_24x21_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LList, 2, (V[]){v_xs_2427, v_t_244}), v_j_2428});
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2429}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x21_2426)}});
                          }
                        }
                      }
                    }
                  } else {
                    heff_drop_rec(v_next_2416, 7);
                    HeffT2 v_t_2430 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), NTAG(TAG_Nil)));
                    {
                      V v_field_2432 = v_t_2430.f[1];
                      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
                      if ((v_tag_2431 == ((int64_t)0ULL))) {
                        heff_drop_rec(v_t_244, 7);
                        V v_p_2434 = v_field_2432;
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2434}});
                      } else {
                        V v_x21_2435 = v_field_2432;
                        switch (heff_tag_of(v_x21_2435)) {
                        case TAG_MkPair: {
                          V v_xs_2436 = heff_field(v_x21_2435, 0);
                          V v_j_2437 = heff_field(v_x21_2435, 1);
                          V v_ru_24x21_2435_24MkPair = heff_take_reuse_n(v_x21_2435, 3ULL, 2);
                          V v_t_2438 = heff_tag_at_n(v_ru_24x21_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LList, 2, (V[]){v_xs_2436, v_t_244}), v_j_2437});
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2438}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x21_2435)}});
                        }
                      }
                    }
                  }
                } else {
                  heff_drop(v_i_241);
                  heff_drop_rec(v_t_244, 7);
                  int64_t v_i_2439 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
                  V v_t_2443;
                  if ((((int64_t)0ULL) <= v_i_2439)) {
                    if ((v_i_2439 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                      V v_t_2442 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2439), 2);
                      v_t_2443 = heff_get_n(v_t_2442, 2, 7);
                    } else {
                      v_t_2443 = MK_INT(0LL);
                    }
                  } else {
                    v_t_2443 = MK_INT(0LL);
                  }
                  V v_f_2444 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2443, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2444}});
                }
              } else {
                heff_drop(v_i_241);
                heff_drop_rec(v_t_244, 7);
                int64_t v_i_2445 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
                V v_t_2449;
                if ((((int64_t)0ULL) <= v_i_2445)) {
                  if ((v_i_2445 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
                    V v_t_2448 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2445), 2);
                    v_t_2449 = heff_get_n(v_t_2448, 2, 7);
                  } else {
                    v_t_2449 = MK_INT(0LL);
                  }
                } else {
                  v_t_2449 = MK_INT(0LL);
                }
                V v_f_2450 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2449, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2450}});
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8))) {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9))) {
                  HeffT2 v_t_2453 = (g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), NTAG(TAG_Nil)));
                  {
                    V v_field_2455 = v_t_2453.f[1];
                    int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                    if ((v_tag_2454 == ((int64_t)0ULL))) {
                      heff_drop_rec(v_t_244, 7);
                      V v_p_2457 = v_field_2455;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2457}});
                    } else {
                      V v_x21_2458 = v_field_2455;
                      switch (heff_tag_of(v_x21_2458)) {
                      case TAG_MkPair: {
                        V v_fs_2459 = heff_field(v_x21_2458, 0);
                        V v_j_2460 = heff_field(v_x21_2458, 1);
                        V v_ru_24x21_2458_24MkPair = heff_take_reuse_n(v_x21_2458, 3ULL, 2);
                        V v_t_2461 = heff_tag_at_n(v_ru_24x21_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LRec, 2, (V[]){v_fs_2459, v_t_244}), v_j_2460});
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2461}});
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x21_2458)}});
                      }
                    }
                  }
                } else {
                  heff_drop(v_i_241);
                  V v_f_2462 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_244, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2462}});
                }
              } else {
                heff_drop(v_i_241);
                V v_f_2463 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_244, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str11)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2463}});
              }
            }
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str12))) {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str13))) {
                HeffT2 v_t_2466 = (g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), NTAG(TAG_Nil)));
                {
                  V v_field_2468 = v_t_2466.f[1];
                  int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
                  if ((v_tag_2467 == ((int64_t)0ULL))) {
                    heff_drop_rec(v_t_244, 7);
                    V v_p_2470 = v_field_2468;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2470}});
                  } else {
                    V v_x21_2471 = v_field_2468;
                    switch (heff_tag_of(v_x21_2471)) {
                    case TAG_MkPair: {
                      V v_fs_2472 = heff_field(v_x21_2471, 0);
                      V v_j_2473 = heff_field(v_x21_2471, 1);
                      V v_ru_24x21_2471_24MkPair = heff_take_reuse_n(v_x21_2471, 3ULL, 2);
                      V v_t_2474 = heff_tag_at_n(v_ru_24x21_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LRec, 2, (V[]){v_fs_2472, v_t_244}), v_j_2473});
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2474}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x21_2471)}});
                    }
                  }
                }
              } else {
                heff_drop(v_i_241);
                V v_f_2475 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_244, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str14)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2475}});
              }
            } else {
              heff_drop(v_i_241);
              V v_f_2476 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_244, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str15)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2476}});
            }
          }
        }
      }
    } else {
      heff_drop(v_i_241);
      int64_t v_i_2477 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
      V v_t_2481;
      if ((((int64_t)0ULL) <= v_i_2477)) {
        if ((v_i_2477 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
          V v_t_2480 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2477), 2);
          v_t_2481 = heff_get_n(v_t_2480, 2, 7);
        } else {
          v_t_2481 = MK_INT(0LL);
        }
      } else {
        v_t_2481 = MK_INT(0LL);
      }
      V v_f_2482 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2481, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str16)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2482}});
    }
  } else {
    heff_drop(v_i_241);
    int64_t v_i_2483 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2487;
    if ((((int64_t)0ULL) <= v_i_2483)) {
      if ((v_i_2483 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)))) {
        V v_t_2486 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2483), 2);
        v_t_2487 = heff_get_n(v_t_2486, 2, 7);
      } else {
        v_t_2487 = MK_INT(0LL);
      }
    } else {
      v_t_2487 = MK_INT(0LL);
    }
    V v_f_2488 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2487, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str17)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2488}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str1, 1, ".");

HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V v_v_240) {
top: ;
  V v_it_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str0); V a_1 = v_v_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str1), v_v_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    V v_ru_24it_241_24Cons = heff_take_reuse_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24it_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      V v_ru_24it2_243_24Cons = heff_take_reuse_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24it_241_24Cons, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24it2_243_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_c_246 = heff_field(v_it22_245, 0);
        V v_it222_247 = heff_field(v_it22_245, 1);
        heff_take_n(v_it22_245, 3ULL, 2);
        switch (heff_tag_of(v_it222_247)) {
        case TAG_Nil: {
          V v_t_248 = (g_heff_2ebuild_2eproject_2eisNumber(v_a_242));
          if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
            heff_drop(v_t_248);
            V v_t_249 = (g_heff_2ebuild_2eproject_2eisNumber(v_b_244));
            if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
              heff_drop(v_t_249);
              V v_t_2410 = (g_heff_2ebuild_2eproject_2eisNumber(v_c_246));
              if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
                heff_drop(v_t_2410);
                V v_t_2411 = heff_tag_at_n(v_ru_24it_241_24Cons, TAG_Cons, 2, (V[]){v_c_246, NTAG(TAG_Nil)});
                V v_t_2412 = heff_tag_at_n(v_ru_24it2_243_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, v_t_2411})});
                V v_f_2413 = (g_list_2emap_24s1703643582x349630108(MK_INT(0LL), v_t_2412));
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
              } else {
                heff_drop(v_a_242);
                heff_drop_cell(v_ru_24it_241_24Cons, 2);
                heff_drop(v_b_244);
                heff_drop_cell(v_ru_24it2_243_24Cons, 2);
                heff_drop(v_c_246);
                heff_drop(v_t_2410);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_a_242);
              heff_drop_cell(v_ru_24it_241_24Cons, 2);
              heff_drop(v_b_244);
              heff_drop_cell(v_ru_24it2_243_24Cons, 2);
              heff_drop(v_c_246);
              heff_drop(v_t_249);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_a_242);
            heff_drop_cell(v_ru_24it_241_24Cons, 2);
            heff_drop(v_b_244);
            heff_drop_cell(v_ru_24it2_243_24Cons, 2);
            heff_drop(v_c_246);
            heff_drop(v_t_248);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_247, 0ULL, 2);
          heff_drop(v_a_242);
          heff_drop_cell(v_ru_24it_241_24Cons, 2);
          heff_drop(v_b_244);
          heff_drop_cell(v_ru_24it2_243_24Cons, 2);
          heff_drop(v_c_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it222_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
Clo g_heff_2ebuild_2eproject_2eversion_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eversion_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eversion(V v_v_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eversion(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str1, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str2, 1, "-");

HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    HeffT2 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
    V v_f_247;
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_244;
        v_f_247 = v_x_246;
      } else {
        heff_drop(v_field_244);
        v_f_247 = NTAG(TAG_Nil);
      }
    }
    return ((HeffT2){{v_f_247, ((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str0)}});
  }
  case TAG_Just: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_MkPair: {
      V v_time_249 = heff_field(v_x21_248, 0);
      V v_commit_2410 = heff_field(v_x21_248, 1);
      V v_t_2411 = heff_strSlice(heff_dup(v_v_240), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str1), v_v_240, MK_INT(0LL), 5));
      HeffT2 v_t_2412 = ({ V a_0 = v_t_2411; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2411); r_; });
      V v_f_2417;
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2416 = v_field_2414;
          v_f_2417 = v_x_2416;
        } else {
          heff_drop(v_field_2414);
          v_f_2417 = NTAG(TAG_Nil);
        }
      }
      V v_f_2418 = heff_strAppend(heff_dup(v_time_249), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str2), heff_dup(v_commit_2410)));
      return ((HeffT2){{v_f_2417, v_f_2418}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ebuild_2eproject_2eisNameByte_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisNameByte_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisNameByte(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intLe_c_lent(MK_INT(97LL), v_c_240, 1) ? (heff_intLe_c_lent(v_c_240, MK_INT(122LL), 2) || (heff_intLe_c_lent(MK_INT(48LL), v_c_240, 1) ? (heff_intLe_c_lent(v_c_240, MK_INT(57LL), 2) || heff_intEq_c_lent(v_c_240, MK_INT(95LL), 2)) : heff_intEq_c_lent(v_c_240, MK_INT(95LL), 2))) : (heff_intLe_c_lent(MK_INT(48LL), v_c_240, 1) ? ((heff_peek_word(v_c_240) <= ((int64_t)57ULL)) || (heff_peek_word(v_c_240) == ((int64_t)95ULL))) : heff_intEq_c_lent(v_c_240, MK_INT(95LL), 2))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eproject_2eisNameByte_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eisNameByte(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str0, 43, "the project's tests are the modules under `");
HEFF_LIT(g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str1, 1, "`");

HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V v_x_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) == ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
  } else {
    if ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))) {
        V v_t_244 = (g_list_2emap_24f768999161x1997188166(v_x_240, MK_INT(0LL), heff_strLength_lent(v_x_240, 0)));
        V v_x1_245 = ({ V a_0 = v_t_244; V r_ = (g_list_2eall_24s494596359x1928238377(a_0)); heff_drop(v_t_244); r_; });
        if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
          heff_drop(v_x1_245);
          if (heff_strEq_c(heff_dup(v_x_240), heff_dup(g_heff_2ebuild_2eproject_2etestsModule_get()))) {
            V v_f_247 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str0), heff_strAppend(heff_dup(g_heff_2ebuild_2eproject_2etestsModule_get()), ((V)&g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str1)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_x1_245);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
        }
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
      }
    } else {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eproject_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        V v_s_247 = heff_dup(v_x_241);
        V v_s_248 = heff_strAppend(v_s_247, ((V)&g_heff_2ebuild_2eproject_2eandList_str2));
        return (g_heff_2ebuild_2eproject_2eandList_24acc(v_x12_242, v_s_248));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_24acc_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_f_241, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_241, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_241, 0, 2), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2eproject_2eleftOutNames_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_f_242, 1);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_242, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_242, 0, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_rest_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V v_fields_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x_241)) {
  case TAG_LStr: {
    heff_drop(v_fields_240);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_245 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_245;
      break;
    }
    case TAG_LTag: {
      V v_t_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_247;
      break;
    }
    case TAG_LList: {
      V v_t_249 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_249;
      break;
    }
    case TAG_LRec: {
      V v_t_2411 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_2411;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2413 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
  }
  case TAG_LTag: {
    heff_drop(v_fields_240);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2417 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2417;
      break;
    }
    case TAG_LTag: {
      V v_t_2419 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2419;
      break;
    }
    case TAG_LList: {
      V v_t_2421 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2421;
      break;
    }
    case TAG_LRec: {
      V v_t_2423 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2423;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
  }
  case TAG_LList: {
    heff_drop(v_fields_240);
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2429 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2429;
      break;
    }
    case TAG_LTag: {
      V v_t_2431 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2431;
      break;
    }
    case TAG_LList: {
      V v_t_2433 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2433;
      break;
    }
    case TAG_LRec: {
      V v_t_2435 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2435;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2437 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
  }
  case TAG_LRec: {
    V v_fs_2438 = heff_field(v_x_241, 0);
    V v_t_2439 = heff_field(v_x_241, 1);
    heff_take_n(v_x_241, 3ULL, 2);
    HeffT2 v_t_2440 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(heff_dup(v_t_2439), heff_dup(v_fields_240), v_fs_2438));
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        heff_drop(v_fields_240);
        heff_drop_rec(v_t_2439, 7);
        V v_xs_2444 = v_field_2442;
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_xs_2444}});
      } else {
        heff_drop(v_field_2442);
        V v_msg_2445 = (g_heff_2ebuild_2eproject_2efieldsSaid(v_fields_240));
        V v_f_2446 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2439, 2, 7), v_msg_2445});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str0, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str1, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str2, 23, "expected a list `[...]`");

HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_244;
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_246;
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_248;
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_2410;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
  }
  case TAG_LTag: {
    V v_t_2423;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2416 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2416;
      break;
    }
    case TAG_LTag: {
      V v_t_2418 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2418;
      break;
    }
    case TAG_LList: {
      V v_t_2420 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2420;
      break;
    }
    case TAG_LRec: {
      V v_t_2422 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2422;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
  }
  case TAG_LList: {
    V v_xs_2425 = heff_field(v_x_240, 0);
    heff_take_n(v_x_240, 1ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_xs_2425}});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2430;
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2432;
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2434;
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2436;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2438}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1, 4, "path");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2, 7, "version");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2), NTAG(TAG_Nothing)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244})});
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(v_t_245, heff_dup(v_x_240)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_2410 = v_field_248;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2410}});
    } else {
      V v_it1_2411 = v_field_248;
      switch (heff_tag_of(v_it1_2411)) {
      case TAG_Nil: {
        V v_t_2420;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2413 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2413;
          break;
        }
        case TAG_LTag: {
          V v_t_2415 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2415;
          break;
        }
        case TAG_LList: {
          V v_t_2417 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2417;
          break;
        }
        case TAG_LRec: {
          V v_t_2419 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2420 = v_t_2419;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2421 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2420, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
      }
      case TAG_Cons: {
        V v_n_2422 = heff_field(v_it1_2411, 0);
        V v_it12_2423 = heff_field(v_it1_2411, 1);
        heff_take_n(v_it1_2411, 3ULL, 2);
        switch (heff_tag_of(v_it12_2423)) {
        case TAG_Nil: {
          heff_drop(v_n_2422);
          V v_t_2432;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2425 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2425;
            break;
          }
          case TAG_LTag: {
            V v_t_2427 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2427;
            break;
          }
          case TAG_LList: {
            V v_t_2429 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2429;
            break;
          }
          case TAG_LRec: {
            V v_t_2431 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2432 = v_t_2431;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2433 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2432, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
        }
        case TAG_Cons: {
          V v_p_2434 = heff_field(v_it12_2423, 0);
          V v_it122_2435 = heff_field(v_it12_2423, 1);
          heff_take_n(v_it12_2423, 3ULL, 2);
          switch (heff_tag_of(v_it122_2435)) {
          case TAG_Nil: {
            heff_drop(v_n_2422);
            heff_drop(v_p_2434);
            V v_t_2444;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2437 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2437;
              break;
            }
            case TAG_LTag: {
              V v_t_2439 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2439;
              break;
            }
            case TAG_LList: {
              V v_t_2441 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2441;
              break;
            }
            case TAG_LRec: {
              V v_t_2443 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2444 = v_t_2443;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2445 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2444, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2445}});
          }
          case TAG_Cons: {
            V v_v_2446 = heff_field(v_it122_2435, 0);
            V v_it1222_2447 = heff_field(v_it122_2435, 1);
            heff_take_n(v_it122_2435, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2447)) {
            case TAG_Nil: {
              heff_drop(v_x_240);
              HeffT2 v_t_2448 = (g_heff_2ebuild_2eproject_2enameOf_24cpr(v_n_2422));
              {
                V v_field_2450 = v_t_2448.f[1];
                int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
                if ((v_tag_2449 == ((int64_t)0ULL))) {
                  heff_drop(v_p_2434);
                  heff_drop(v_v_2446);
                  V v_e_2452 = v_field_2450;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2452}});
                } else {
                  V v_name_2453 = v_field_2450;
                  HeffT2 v_t_2454 = (g_heff_2ebuild_2eproject_2erequiredOf_24cpr(v_v_2446));
                  {
                    V v_field_2456 = v_t_2454.f[1];
                    int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                    if ((v_tag_2455 == ((int64_t)0ULL))) {
                      heff_drop(v_p_2434);
                      heff_drop(v_name_2453);
                      V v_e_2458 = v_field_2456;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2458}});
                    } else {
                      V v_ver_2459 = v_field_2456;
                      HeffT2 v_t_2460 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_p_2434)));
                      {
                        V v_field_2462 = v_t_2460.f[1];
                        int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
                        if ((v_tag_2461 == ((int64_t)0ULL))) {
                          heff_drop(v_p_2434);
                          heff_drop(v_name_2453);
                          heff_drop(v_ver_2459);
                          V v_p_2464 = v_field_2462;
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2464}});
                        } else {
                          V v_path_2465 = v_field_2462;
                          HeffT2 v_t_2466 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_2465), heff_dup(v_ver_2459)));
                          {
                            V v_field_2468 = v_t_2466.f[1];
                            int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
                            if ((v_tag_2467 == ((int64_t)0ULL))) {
                              heff_drop(v_name_2453);
                              heff_drop(v_ver_2459);
                              heff_drop(v_path_2465);
                              V v_why_2470 = v_field_2468;
                              V v_t_2479;
                              switch (heff_tag_of(v_p_2434)) {
                              case TAG_LStr: {
                                V v_t_2472 = heff_field(v_p_2434, 1);
                                heff_take_n(v_p_2434, 2ULL, 2);
                                v_t_2479 = v_t_2472;
                                break;
                              }
                              case TAG_LTag: {
                                V v_t_2474 = heff_field(v_p_2434, 1);
                                heff_take_n(v_p_2434, 2ULL, 2);
                                v_t_2479 = v_t_2474;
                                break;
                              }
                              case TAG_LList: {
                                V v_t_2476 = heff_field(v_p_2434, 1);
                                heff_take_n(v_p_2434, 2ULL, 2);
                                v_t_2479 = v_t_2476;
                                break;
                              }
                              case TAG_LRec: {
                                V v_t_2478 = heff_field(v_p_2434, 1);
                                heff_take_n(v_p_2434, 2ULL, 2);
                                v_t_2479 = v_t_2478;
                                break;
                              }
                              default: heff_nomatch(v_p_2434);
                              }
                              V v_f_2480 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2479, 2, 7), v_why_2470});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2480}});
                            } else {
                              heff_drop(v_p_2434);
                              heff_drop(v_field_2468);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__path__version, (V[]){v_name_2453, v_path_2465, v_ver_2459})}});
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_it1222_2447, 0ULL, 2);
              heff_drop(v_n_2422);
              heff_drop(v_p_2434);
              heff_drop(v_v_2446);
              V v_t_2491;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2484 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2491 = v_t_2484;
                break;
              }
              case TAG_LTag: {
                V v_t_2486 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2491 = v_t_2486;
                break;
              }
              case TAG_LList: {
                V v_t_2488 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2491 = v_t_2488;
                break;
              }
              case TAG_LRec: {
                V v_t_2490 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2491 = v_t_2490;
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_f_2492 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2491, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2492}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it1222_2447)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2435)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2411)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str1, 3, "dir");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str4, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_243}), heff_dup(v_x_240)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_248 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_248}});
    } else {
      V v_it1_249 = v_field_246;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_Nil: {
        V v_t_2418;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2411 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2411;
          break;
        }
        case TAG_LTag: {
          V v_t_2413 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2413;
          break;
        }
        case TAG_LList: {
          V v_t_2415 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2415;
          break;
        }
        case TAG_LRec: {
          V v_t_2417 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2418 = v_t_2417;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2419 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2418, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str2)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
      }
      case TAG_Cons: {
        V v_n_2420 = heff_field(v_it1_249, 0);
        V v_it12_2421 = heff_field(v_it1_249, 1);
        heff_take_n(v_it1_249, 3ULL, 2);
        switch (heff_tag_of(v_it12_2421)) {
        case TAG_Nil: {
          heff_drop(v_n_2420);
          V v_t_2430;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2423 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2423;
            break;
          }
          case TAG_LTag: {
            V v_t_2425 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2425;
            break;
          }
          case TAG_LList: {
            V v_t_2427 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2427;
            break;
          }
          case TAG_LRec: {
            V v_t_2429 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2430 = v_t_2429;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2431 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2430, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str3)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2431}});
        }
        case TAG_Cons: {
          V v_d_2432 = heff_field(v_it12_2421, 0);
          V v_it122_2433 = heff_field(v_it12_2421, 1);
          heff_take_n(v_it12_2421, 3ULL, 2);
          switch (heff_tag_of(v_it122_2433)) {
          case TAG_Nil: {
            heff_drop(v_x_240);
            HeffT2 v_t_2434 = (g_heff_2ebuild_2eproject_2enameOf_24cpr(v_n_2420));
            {
              V v_field_2436 = v_t_2434.f[1];
              int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
              if ((v_tag_2435 == ((int64_t)0ULL))) {
                heff_drop(v_d_2432);
                V v_e_2438 = v_field_2436;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2438}});
              } else {
                V v_name_2439 = v_field_2436;
                HeffT2 v_t_2440 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_d_2432));
                {
                  V v_field_2442 = v_t_2440.f[1];
                  int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                  if ((v_tag_2441 == ((int64_t)0ULL))) {
                    heff_drop(v_name_2439);
                    V v_e_2444 = v_field_2442;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2444}});
                  } else {
                    V v_dir_2445 = v_field_2442;
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(2, shape_name__dir, (V[]){v_name_2439, v_dir_2445})}});
                  }
                }
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2433, 0ULL, 2);
            heff_drop(v_n_2420);
            heff_drop(v_d_2432);
            V v_t_2456;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2449 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2456 = v_t_2449;
              break;
            }
            case TAG_LTag: {
              V v_t_2451 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2456 = v_t_2451;
              break;
            }
            case TAG_LList: {
              V v_t_2453 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2456 = v_t_2453;
              break;
            }
            case TAG_LRec: {
              V v_t_2455 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2456 = v_t_2455;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2457 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2456, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str4)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2457}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2433)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2421)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_249)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_names_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_n_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eclaimMsg_str0, 143, "error[E0347]: the package `heff` is heff's own, and this is not the checkout heff is built in or was installed from: name the project otherwise");

static V g_heff_2ebuild_2eproject_2eclaimMsg_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2eclaimMsg_st;
static V g_heff_2ebuild_2eproject_2eclaimMsg_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2eclaimMsg_str0);
}
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2eclaimMsg_st)) return g_heff_2ebuild_2eproject_2eclaimMsg_val;
  return heff_global(&g_heff_2ebuild_2eproject_2eclaimMsg_val, &g_heff_2ebuild_2eproject_2eclaimMsg_st, g_heff_2ebuild_2eproject_2eclaimMsg_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1, 19, "` is required twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3, 19, "` is replaced twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5, 31, "` is replaced, but not required");

HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s634456687x1151454243(heff_dup(v_rxs_240), heff_dup(v_rs_241)));
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_rxs_240);
      heff_drop(v_rs_241);
      heff_drop(v_pxs_242);
      heff_drop(v_ps_243);
      V v_it1_249 = v_field_247;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_MkPair: {
        V v_n_2410 = heff_field(v_it1_249, 0);
        V v_x_2411 = heff_field(v_it1_249, 1);
        heff_take_n(v_it1_249, 3ULL, 2);
        V v_t_2420;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_LStr: {
          V v_t_2413 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2413;
          break;
        }
        case TAG_LTag: {
          V v_t_2415 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2415;
          break;
        }
        case TAG_LList: {
          V v_t_2417 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2417;
          break;
        }
        case TAG_LRec: {
          V v_t_2419 = heff_field(v_x_2411, 1);
          heff_take_n(v_x_2411, 2ULL, 2);
          v_t_2420 = v_t_2419;
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0), heff_strAppend(v_n_2410, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1)));
        V v_f_2422 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2420, 2, 7), v_t_2421});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_249)}});
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2423 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
      HeffT2 v_t_2424 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_2423));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          heff_drop(v_rxs_240);
          heff_drop(v_rs_241);
          heff_drop(v_pxs_242);
          heff_drop(v_ps_243);
          V v_it1_2428 = v_field_2426;
          switch (heff_tag_of(v_it1_2428)) {
          case TAG_MkPair: {
            V v_n_2429 = heff_field(v_it1_2428, 0);
            V v_x_2430 = heff_field(v_it1_2428, 1);
            heff_take_n(v_it1_2428, 3ULL, 2);
            V v_t_2439;
            switch (heff_tag_of(v_x_2430)) {
            case TAG_LStr: {
              V v_t_2432 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2432;
              break;
            }
            case TAG_LTag: {
              V v_t_2434 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2434;
              break;
            }
            case TAG_LList: {
              V v_t_2436 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2436;
              break;
            }
            case TAG_LRec: {
              V v_t_2438 = heff_field(v_x_2430, 1);
              heff_take_n(v_x_2430, 2ULL, 2);
              v_t_2439 = v_t_2438;
              break;
            }
            default: heff_nomatch(v_x_2430);
            }
            V v_t_2440 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2), heff_strAppend(v_n_2429, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3)));
            V v_f_2441 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2439, 2, 7), v_t_2440});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2441}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2428)}});
          }
        } else {
          heff_drop(v_field_2426);
          V v_t_2442 = (g_list_2emap_24s1791433880x1360378684(heff_dup(v_rs_241)));
          V v_t_2443 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
          HeffT2 v_t_2444 = ({ V a_0 = v_t_2442; V a_1 = v_t_2443; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eunrequired_24cpr(a_0, a_1)); heff_drop(v_t_2442); r_; });
          {
            V v_field_2446 = v_t_2444.f[1];
            int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
            if ((v_tag_2445 == ((int64_t)0ULL))) {
              heff_drop(v_rxs_240);
              heff_drop(v_rs_241);
              heff_drop(v_pxs_242);
              heff_drop(v_ps_243);
              V v_it1_2448 = v_field_2446;
              switch (heff_tag_of(v_it1_2448)) {
              case TAG_MkPair: {
                V v_n_2449 = heff_field(v_it1_2448, 0);
                V v_x_2450 = heff_field(v_it1_2448, 1);
                heff_take_n(v_it1_2448, 3ULL, 2);
                V v_t_2459;
                switch (heff_tag_of(v_x_2450)) {
                case TAG_LStr: {
                  V v_t_2452 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2452;
                  break;
                }
                case TAG_LTag: {
                  V v_t_2454 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2454;
                  break;
                }
                case TAG_LList: {
                  V v_t_2456 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2456;
                  break;
                }
                case TAG_LRec: {
                  V v_t_2458 = heff_field(v_x_2450, 1);
                  heff_take_n(v_x_2450, 2ULL, 2);
                  v_t_2459 = v_t_2458;
                  break;
                }
                default: heff_nomatch(v_x_2450);
                }
                V v_t_2460 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4), heff_strAppend(v_n_2449, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5)));
                V v_f_2461 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2459, 2, 7), v_t_2460});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2461}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2448)}});
              }
            } else {
              heff_drop(v_field_2446);
              HEFF_LAST return g_heff_2ebuild_2eproject_2echeckHeff_24cpr(v_rxs_240, v_rs_241, v_pxs_242, v_ps_243);
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(v_rest_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_field_248);
          V v_p_2410 = v_field_245;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2410}});
        } else {
          V v_y_2411 = v_field_245;
          if ((v_tag_247 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_y_2411);
            V v_p_2413 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2413}});
          } else {
            V v_ys_2414 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_2411, v_ys_2414})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str1, 45, "` is no version: write `a.b.c`, three numbers");

HeffT2 g_heff_2ebuild_2eproject_2epackageOf4_24cpr(V v_m_240, V v_h_241, V v_rq_242, V v_rp_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_m_240));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_h_241);
      heff_drop(v_rq_242);
      heff_drop(v_rp_243);
      V v_p_248 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_248}});
    } else {
      V v_mpath_249 = v_field_246;
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_h_241)));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_h_241);
          heff_drop(v_rq_242);
          heff_drop(v_rp_243);
          heff_drop(v_mpath_249);
          V v_p_2414 = v_field_2412;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2414}});
        } else {
          V v_v_2415 = v_field_2412;
          HeffT2 v_t_2416 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_2415));
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              heff_drop(v_h_241);
              V v_x_2420 = v_field_2418;
              heff_drop(v_x_2420);
              HeffT2 v_t_2421 = (g_heff_2ebuild_2eproject_2eitems_24cpr(v_rq_242));
              {
                V v_field_2423 = v_t_2421.f[1];
                int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                if ((v_tag_2422 == ((int64_t)0ULL))) {
                  heff_drop(v_rp_243);
                  heff_drop(v_mpath_249);
                  heff_drop(v_v_2415);
                  V v_p_2425 = v_field_2423;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2425}});
                } else {
                  V v_rxs_2426 = v_field_2423;
                  HeffT2 v_t_2427 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(heff_dup(v_rxs_2426)));
                  {
                    V v_field_2429 = v_t_2427.f[1];
                    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
                    if ((v_tag_2428 == ((int64_t)0ULL))) {
                      heff_drop(v_rp_243);
                      heff_drop(v_mpath_249);
                      heff_drop(v_v_2415);
                      heff_drop(v_rxs_2426);
                      V v_p_2431 = v_field_2429;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2431}});
                    } else {
                      V v_rs_2432 = v_field_2429;
                      HeffT2 v_t_2433 = (g_heff_2ebuild_2eproject_2eitems_24cpr(v_rp_243));
                      {
                        V v_field_2435 = v_t_2433.f[1];
                        int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                        if ((v_tag_2434 == ((int64_t)0ULL))) {
                          heff_drop(v_mpath_249);
                          heff_drop(v_v_2415);
                          heff_drop(v_rxs_2426);
                          heff_drop(v_rs_2432);
                          V v_p_2437 = v_field_2435;
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2437}});
                        } else {
                          V v_pxs_2438 = v_field_2435;
                          HeffT2 v_t_2439 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(heff_dup(v_pxs_2438)));
                          {
                            V v_field_2441 = v_t_2439.f[1];
                            int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                            if ((v_tag_2440 == ((int64_t)0ULL))) {
                              heff_drop(v_mpath_249);
                              heff_drop(v_v_2415);
                              heff_drop(v_rxs_2426);
                              heff_drop(v_rs_2432);
                              heff_drop(v_pxs_2438);
                              V v_p_2443 = v_field_2441;
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2443}});
                            } else {
                              V v_ps_2444 = v_field_2441;
                              HeffT2 v_t_2445 = (g_heff_2ebuild_2eproject_2echeckNames_24cpr(v_rxs_2426, heff_dup(v_rs_2432), v_pxs_2438, heff_dup(v_ps_2444)));
                              {
                                V v_field_2447 = v_t_2445.f[1];
                                int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
                                if ((v_tag_2446 == ((int64_t)0ULL))) {
                                  heff_drop(v_mpath_249);
                                  heff_drop(v_v_2415);
                                  heff_drop(v_rs_2432);
                                  heff_drop(v_ps_2444);
                                  V v_p_2449 = v_field_2447;
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2449}});
                                } else {
                                  V v_x_2450 = v_field_2447;
                                  heff_drop(v_x_2450);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(4, shape_module__heff__require__replace, (V[]){v_mpath_249, v_v_2415, v_rs_2432, v_ps_2444})}});
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              heff_drop(v_rq_242);
              heff_drop(v_rp_243);
              heff_drop(v_mpath_249);
              heff_drop(v_field_2418);
              V v_t_2459;
              switch (heff_tag_of(v_h_241)) {
              case TAG_LStr: {
                V v_t_2452 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2459 = v_t_2452;
                break;
              }
              case TAG_LTag: {
                V v_t_2454 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2459 = v_t_2454;
                break;
              }
              case TAG_LList: {
                V v_t_2456 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2459 = v_t_2456;
                break;
              }
              case TAG_LRec: {
                V v_t_2458 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2459 = v_t_2458;
                break;
              }
              default: heff_nomatch(v_h_241);
              }
              V v_t_2460 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str0), heff_strAppend(v_v_2415, ((V)&g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str1)));
              V v_f_2461 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2459, 2, 7), v_t_2460});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2461}});
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str0, 6, "module");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str1, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str2, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str3, 7, "replace");
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam0, 1, 0};
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam1, 1, 0};

static V g_heff_2ebuild_2eproject_2epackageFields_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2epackageFields_st;
static V g_heff_2ebuild_2eproject_2epackageFields_init(void) {
  V v_t_240 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str0), NTAG(TAG_Nothing)});
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam0_clo)})});
  V v_t_245 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str3), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_246})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_247});
}
V g_heff_2ebuild_2eproject_2epackageFields_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2epackageFields_st)) return g_heff_2ebuild_2eproject_2epackageFields_val;
  return heff_global(&g_heff_2ebuild_2eproject_2epackageFields_val, &g_heff_2ebuild_2eproject_2epackageFields_st, g_heff_2ebuild_2eproject_2epackageFields_init);
}
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_242});
}
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_244});
}
Clo g_heff_2ebuild_2eproject_2epackageOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epackageOf(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2epackageOf(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eclaimOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eclaimOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eclaimOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Left: {
    return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
  }
  case TAG_Right: {
    V v_x_242 = heff_field(v_x1_240, 0);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()), heff_dup(v_x_242)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        heff_drop(v_x_247);
        return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
      } else {
        V v_x11_248 = v_field_245;
        switch (heff_tag_of(v_x11_248)) {
        case TAG_Nil: {
          return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
        }
        case TAG_Cons: {
          V v_m_249 = heff_field(v_x11_248, 0);
          heff_take_n(v_x11_248, 1ULL, 2);
          V v_t_2419;
          switch (heff_tag_of(v_m_249)) {
          case TAG_LStr: {
            V v_t_2412 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2412;
            break;
          }
          case TAG_LTag: {
            V v_t_2414 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2414;
            break;
          }
          case TAG_LList: {
            V v_t_2416 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2416;
            break;
          }
          case TAG_LRec: {
            V v_t_2418 = heff_field(v_m_249, 1);
            heff_take_n(v_m_249, 2ULL, 2);
            v_t_2419 = v_t_2418;
            break;
          }
          default: heff_nomatch(v_m_249);
          }
          return heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2419, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
        }
        default: return heff_nomatch(v_x11_248);
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eclaimOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str0, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str1, 72, "a program ships no `bin`: the heff home's bin/ is where the programs are");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str4, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str6, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str7, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str8, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str9, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str10, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str12, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str13, 92, "` is not a name: a program ships files and directories of the project's root, by their names");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str14, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str15, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str16, 92, "` is not a name: a program ships files and directories of the project's root, by their names");

HeffT2 g_heff_2ebuild_2eproject_2eshipWrong_24cpr(V v_n_240) {
top: ;
  if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str0), 2)) {
    heff_drop(v_n_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str1)}});
  } else {
    if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str2), 2)) {
      V v_f_243 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str3), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str4)));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
    } else {
      if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str5), 2)) {
        V v_f_245 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str6), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str7)));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
      } else {
        if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str8), 2)) {
          V v_f_247 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str9), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str10)));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
        } else {
          if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str11), v_n_240, MK_INT(0LL), 5))) {
            V v_f_249 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str12), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str13)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
          } else {
            if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str14), v_n_240, MK_INT(0LL), 5))) {
              V v_f_2411 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str15), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str16)));
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
            } else {
              heff_drop(v_n_240);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_x_241)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_241);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_p_247 = v_field_245;
        V v_x2_248 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
        heff_drop(v_x2_248);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_247}});
      } else {
        V v_n_249 = v_field_245;
        HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2eshipWrong_24cpr(heff_dup(v_n_249)));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_n_249);
            V v_why_2414 = v_field_2412;
            V v_x2_2415 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
            heff_drop(v_x2_2415);
            V v_t_2424;
            switch (heff_tag_of(v_x_241)) {
            case TAG_LStr: {
              V v_t_2417 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2417;
              break;
            }
            case TAG_LTag: {
              V v_t_2419 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2419;
              break;
            }
            case TAG_LList: {
              V v_t_2421 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2421;
              break;
            }
            case TAG_LRec: {
              V v_t_2423 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2424 = v_t_2423;
              break;
            }
            default: heff_nomatch(v_x_241);
            }
            V v_f_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), v_why_2414});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
          } else {
            heff_drop(v_x_241);
            heff_drop(v_field_2412);
            HeffT2 v_t_2426 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_rest_242));
            {
              V v_field_2428 = v_t_2426.f[1];
              int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
              if ((v_tag_2427 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop(v_n_249);
                V v_p_2430 = v_field_2428;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2430}});
              } else {
                V v_ys_2431 = v_field_2428;
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_n_249, v_ys_2431})}});
              }
            }
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str1, 5, "build");

HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_242 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_244 = v_t_242.f[1];
    heff_drop(v_t_242.f[0]);
    heff_drop(v_t_242.f[2]);
    switch (heff_tag_of(v_field_244)) {
    case TAG_Nil: {
      V v_t_246 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      HeffT3 v_t_247 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_246, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2411;
      {
        V v_field_248 = v_t_247.f[0];
        heff_drop(v_t_247.f[1]);
        heff_drop(v_t_247.f[2]);
        v_t_2411 = v_field_248;
      }
      HeffT2 v_t_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str1); V b_2 = heff_arrayFromList(v_t_2411); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_p_2416 = v_field_2414;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2416}});
        } else {
          V v_x_2417 = v_field_2414;
          HEFF_LAST return g_heff_2ebuild_2eproject_2ebuildOf_24cpr(v_x_2417);
        }
      }
    }
    case TAG_Cons: {
      V v_e_2418 = heff_field(v_field_244, 0);
      heff_take_n(v_field_244, 1ULL, 2);
      V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_take_field(v_e_2418, 0), heff_get_n(v_e_2418, 2, 3)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
    }
    default: return ((HeffT2){{heff_nomatch(v_field_244)}});
    }
  }
}
Clo g_heff_2ebuild_2eproject_2enewerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewerGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewerGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c_lent(v_y_244, v_x_242, 0)) {
        return NTAG(TAG_True);
      } else {
        if (heff_intEq_c_lent(v_x_242, v_y_244, 0)) {
          V t_0 = v_xs_243;
          V t_1 = v_ys_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2enewerGo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2enewerKey_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewerKey_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewerKey_str2, 0, "");
Clo g_heff_2ebuild_2eproject_2enewerKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewerKey_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewerKey(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x1_240, 0);
    V v_a_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_ys_244 = heff_field(v_x2_241, 0);
      V v_b_245 = heff_field(v_x2_241, 1);
      V v_t_246 = (g_heff_2ebuild_2eproject_2enewerGo(v_xs_242, v_ys_244));
      V v_ret_24bool = heff_bool(((heff_dup(v_t_246) == NTAG(TAG_True)) || ({ V v_x1_247 = (g_heff_2ebuild_2eproject_2enewerGo(v_ys_244, v_xs_242)); int c_ = ((heff_dup(v_x1_247) == NTAG(TAG_True)) ? 0 : (heff_strEq_c_lent(v_a_243, ((V)&g_heff_2ebuild_2eproject_2enewerKey_str0), 2) ? !heff_strEq_c_lent(v_b_245, ((V)&g_heff_2ebuild_2eproject_2enewerKey_str1), 2) : (heff_strEq_c_lent(v_b_245, ((V)&g_heff_2ebuild_2eproject_2enewerKey_str2), 2) ? 0 : heff_strLt_c_lent(v_b_245, v_a_243, 0)))); heff_drop(v_x1_247); c_; })));
      heff_drop(v_t_246);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2enewerKey_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2enewerKey(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str2, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str4, 1, "/");
Clo g_heff_2ebuild_2eproject_2erepoOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erepoOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2erepoOf(V v_path_240) {
top: ;
  V v_xs_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2erepoOf_str0); V a_1 = v_path_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str1), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_x_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    v_x_245 = heff_dup(v_path_240);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    v_x_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_245, 0)))) {
    if (heff_strEq_c(heff_strSlice_lent(v_x_245, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ebuild_2eproject_2erepoOf_str2))) {
      V v_t_248 = heff_strSlice(heff_dup(v_x_245), MK_INT(1LL), heff_strLength(v_x_245));
      V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2ebuild_2eproject_2eisNumber(a_0)); heff_drop(v_t_248); r_; });
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_xs_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2erepoOf_str3); V a_1 = v_path_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str4), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nil: {
          v_t_2414 = heff_dup(v_path_240);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_t_2411, 0);
          heff_take_n(v_t_2411, 1ULL, 2);
          v_t_2414 = v_x_2412;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_path_240, 0)) - heff_unbox_word(heff_strLength(v_t_2414)));
        return heff_strSlice(v_path_240, MK_INT(0LL), heff_box_word((v_t_2415 - ((int64_t)1ULL))));
      } else {
        heff_drop(v_t_249);
        return v_path_240;
      }
    } else {
      heff_drop(v_x_245);
      return v_path_240;
    }
  } else {
    heff_drop(v_x_245);
    return v_path_240;
  }
}
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erepoOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str0, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str1, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str2, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str5, 30, "` is no version: write `a.b.c`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str6, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");

HeffT2 g_heff_2ebuild_2eproject_2esumLine_24cpr(V v_at_240, V v_line_241) {
top: ;
  V v_it_242 = (g_prelude_2ewordsFrom(v_line_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_it2_244 = heff_field(v_it_242, 1);
    V v_ru_24it_242_24Cons = heff_take_reuse_n(v_it_242, 3ULL, 2);
    switch (heff_tag_of(v_it2_244)) {
    case TAG_Nil: {
      heff_drop(v_p_243);
      heff_drop_cell(v_ru_24it_242_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str0)})}});
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_it2_244, 0);
      V v_it22_246 = heff_field(v_it2_244, 1);
      heff_take_n(v_it2_244, 3ULL, 2);
      switch (heff_tag_of(v_it22_246)) {
      case TAG_Nil: {
        heff_drop(v_p_243);
        heff_drop_cell(v_ru_24it_242_24Cons, 2);
        heff_drop(v_v_245);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str1)})}});
      }
      case TAG_Cons: {
        V v_h_247 = heff_field(v_it22_246, 0);
        V v_it222_248 = heff_field(v_it22_246, 1);
        heff_take_n(v_it22_246, 3ULL, 2);
        switch (heff_tag_of(v_it222_248)) {
        case TAG_Nil: {
          V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str2); V a_1 = v_v_245; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str3), v_v_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2410 = (g_heff_2ebuild_2eproject_2epseudoParts(v_t_249));
          HeffT2 v_t_2411 = ({ V a_0 = v_v_245; V a_1 = v_t_2410; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
          V v_t_2416;
          {
            V v_field_2412 = v_t_2411.f[0];
            V v_field_2413 = v_t_2411.f[1];
            V v_x_2414 = v_field_2412;
            V v_y_2415 = v_field_2413;
            heff_drop(v_y_2415);
            v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
          }
          if (heff_intEq_c(v_t_2416, MK_INT(3LL))) {
            heff_drop(v_at_240);
            V v_t_2418 = heff_tag_at_n(v_ru_24it_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_p_243, v_v_245, v_h_247}), NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2418}});
          } else {
            heff_drop(v_p_243);
            heff_drop_cell(v_ru_24it_242_24Cons, 2);
            heff_drop(v_h_247);
            V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str4), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str5)));
            V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){v_at_240, v_t_2419});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_248, 0ULL, 2);
          heff_drop(v_p_243);
          heff_drop_cell(v_ru_24it_242_24Cons, 2);
          heff_drop(v_v_245);
          heff_drop(v_h_247);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str6)})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it222_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_242)}});
  }
}

HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2esumLine_24cpr(heff_dup(v_at_240), v_l_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_at_240);
        heff_drop(v_l_242);
        heff_drop(v_rest_243);
        V v_p_248 = v_field_246;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_248}});
      } else {
        V v_xs_249 = v_field_246;
        V v_t_2410 = heff_intAdd(v_at_240, heff_strLength(v_l_242));
        HeffT2 v_t_2411 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(heff_intAdd(v_t_2410, MK_INT(1LL)), v_rest_243));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_xs_249);
            V v_x_2415 = v_field_2413;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2415}});
          } else {
            V v_y_2416 = v_field_2413;
            V v_f_2417 = (g_prelude_2e_2b_2b(v_xs_249, v_y_2416));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2417}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str1, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str2, 7, "package");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str3, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str4, 1, "=");

HeffT2 g_heff_2ebuild_2eproject_2espanGo_24cpr(V v_ts_240, V v_i_241) {
top: ;
  if (heff_intLe_c_lent(MK_INT(0LL), v_i_241, 1)) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0))) {
      V v_t_244 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str0))) {
        heff_drop(v_i_241);
        heff_drop_rec(v_t_244, 7);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_t_2413 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str1)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 1)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str2)) && ({ int64_t v_i_248 = (heff_peek_word(v_i_241) + ((int64_t)1ULL)); int c_ = ((((int64_t)0ULL) <= v_i_248) && ((v_i_248 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))) && ({ V v_t_2411 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_248), 2); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_t_2411, 0)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str3)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2411, 1)), ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str4))); heff_drop(v_t_2411); c_; }))); c_; }))));
        heff_drop_rec(v_t_244, 7);
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          HeffT2 v_t_2414 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              heff_drop(v_i_241);
              V v_it1_2418 = v_field_2416;
              heff_drop(v_it1_2418);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            } else {
              V v_it1_2419 = v_field_2416;
              switch (heff_tag_of(v_it1_2419)) {
              case TAG_MkPair: {
                V v_j_2421 = heff_field(v_it1_2419, 1);
                V v_ru_24it1_2419_24MkPair = heff_take_reuse_n(v_it1_2419, 2ULL, 2);
                V v_i_2422 = heff_intAdd(v_i_241, MK_INT(2LL));
                if (heff_intLe_c_lent(MK_INT(0LL), v_i_2422, 1)) {
                  if (heff_intLt_c(heff_dup(v_i_2422), heff_arrayLength_lent(v_ts_240, 0))) {
                    V v_opening_2425 = heff_arrayIndex_lent(v_ts_240, v_i_2422, 2);
                    V v_i_2426 = heff_intSub(v_j_2421, MK_INT(1LL));
                    if (heff_intLe_c_lent(MK_INT(0LL), v_i_2426, 1)) {
                      if (heff_intLt_c(heff_dup(v_i_2426), heff_arrayLength_lent(v_ts_240, 0))) {
                        V v_closing_2429 = heff_arrayIndex_lent(v_ts_240, v_i_2426, 2);
                        V v_f_2430 = heff_tag_at_n(v_ru_24it1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_opening_2425, 2, 7), heff_get_n(v_closing_2429, 3, 7)});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
                      } else {
                        heff_drop_cell(v_ru_24it1_2419_24MkPair, 2);
                        heff_drop_rec(v_opening_2425, 7);
                        heff_drop(v_i_2426);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    } else {
                      heff_drop_cell(v_ru_24it1_2419_24MkPair, 2);
                      heff_drop_rec(v_opening_2425, 7);
                      heff_drop(v_i_2426);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  } else {
                    heff_drop(v_j_2421);
                    heff_drop_cell(v_ru_24it1_2419_24MkPair, 2);
                    heff_drop(v_i_2422);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                } else {
                  heff_drop(v_j_2421);
                  heff_drop_cell(v_ru_24it1_2419_24MkPair, 2);
                  heff_drop(v_i_2422);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2419)}});
              }
            }
          }
        } else {
          heff_drop(v_t_2413);
          V v_t_2431 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
          V t_0 = v_ts_240;
          V t_1 = v_t_2431;
          v_ts_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
      }
    } else {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
Clo g_heff_2ebuild_2eproject_2ewithPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ewithPackage_entry, 2, 0};

V g_heff_2ebuild_2eproject_2ewithPackage(V v_src_240, V v_pk_241) {
top: ;
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_247;
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    v_t_247 = v_field_244;
  }
  HeffT2 v_t_248 = ({ V b_0 = heff_arrayFromList(v_t_247); V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2eproject_2espanGo_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_it1_2412 = v_field_2410;
      switch (heff_tag_of(v_it1_2412)) {
      case TAG_MkPair: {
        V v_from_2413 = heff_field(v_it1_2412, 0);
        V v_to_2414 = heff_field(v_it1_2412, 1);
        heff_take_n(v_it1_2412, 3ULL, 2);
        V v_t_2415 = (g_heff_2ebuild_2eproject_2eshowPackage(v_pk_241));
        V v_t_2416 = heff_strSlice(heff_dup(v_src_240), v_to_2414, heff_strLength_lent(v_src_240, 0));
        return heff_strAppend(heff_strSlice(v_src_240, MK_INT(0LL), v_from_2413), heff_strAppend(v_t_2415, v_t_2416));
      }
      default: return heff_nomatch(v_it1_2412);
      }
    } else {
      heff_drop(v_pk_241);
      heff_drop(v_field_2410);
      return v_src_240;
    }
  }
}
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2ewithPackage(a[0], a[1]);
}