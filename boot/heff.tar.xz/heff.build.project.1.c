// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_cmt 308164
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_hash 9690581
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
#define LBL_version 583465758
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(V);
V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_clo;
V g_heff_2ebuild_2eproject_2eandList(V);
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_clo;
V g_heff_2ebuild_2eproject_2eandList_24acc(V, V);
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo;
V g_heff_2ebuild_2eproject_2echeckHeff(V, V, V, V);
V g_heff_2ebuild_2eproject_2echeckHeff_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2echeckHeff_clo;
V g_heff_2ebuild_2eproject_2echeckNames(V, V, V, V);
V g_heff_2ebuild_2eproject_2echeckNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2echeckNames_clo;
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
V g_heff_2ebuild_2eproject_2efieldsAre(V, V);
V g_heff_2ebuild_2eproject_2efieldsAre_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsAre_clo;
V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083(V, V, V);
V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_clo;
V g_heff_2ebuild_2eproject_2efirstNamed(V, V);
V g_heff_2ebuild_2eproject_2efirstNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efirstNamed_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisName(V);
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisName_clo;
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
V g_heff_2ebuild_2eproject_2eitems(V);
V g_heff_2ebuild_2eproject_2eitems_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eitems_clo;
V g_heff_2ebuild_2eproject_2eleftOutNames(V);
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo;
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo;
V g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(V, V);
V g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_clo;
V g_heff_2ebuild_2eproject_2emajorMismatch(V, V);
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo;
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2eproject_2epackageOf4(V, V, V, V);
V g_heff_2ebuild_2eproject_2epackageOf4_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf4_clo;
V g_heff_2ebuild_2eproject_2epastTheEnd(V);
V g_heff_2ebuild_2eproject_2epastTheEnd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epastTheEnd_clo;
V g_heff_2ebuild_2eproject_2ereplaceOf(V);
V g_heff_2ebuild_2eproject_2ereplaceOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ereplaceOf_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_heff_2ebuild_2eproject_2eshowPackage(V);
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eshowPackage_clo;
V g_heff_2ebuild_2eproject_2espanGo(V, V);
V g_heff_2ebuild_2eproject_2espanGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2espanGo_clo;
V g_heff_2ebuild_2eproject_2estr(V);
V g_heff_2ebuild_2eproject_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2estr_clo;
V g_heff_2ebuild_2eproject_2esumBefore(V, V);
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumBefore_clo;
V g_heff_2ebuild_2eproject_2esumLine(V, V);
V g_heff_2ebuild_2eproject_2esumLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2esumLine_clo;
V g_heff_2ebuild_2eproject_2etwiceGo(V, V);
V g_heff_2ebuild_2eproject_2etwiceGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2etwiceGo_clo;
V g_heff_2ebuild_2eproject_2eunrequired(V, V);
V g_heff_2ebuild_2eproject_2eunrequired_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eunrequired_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_list_2eall_24s1821787051x863686734(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s1821787051x863686734_entry(V self, V *a);
extern Clo g_list_2eall_24s1821787051x863686734_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24f1156519715x726760149(V);
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_clo;
V g_list_2emap_24f1649958057x1967137941(V, V, V);
V g_list_2emap_24f1649958057x1967137941_entry(V self, V *a);
extern Clo g_list_2emap_24f1649958057x1967137941_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2emap_24s546447922x1671206170(V, V);
V g_list_2emap_24s546447922x1671206170_entry(V self, V *a);
extern Clo g_list_2emap_24s546447922x1671206170_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s29557946x653938035(V, V);
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2epastTheEnd_str0, 42, "the text ends where more of it is expected");
Clo g_heff_2ebuild_2eproject_2epastTheEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epastTheEnd_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epastTheEnd(V v_ts_240) {
top: ;
  V v_i_241 = heff_intSub(heff_arrayLength(heff_dup(v_ts_240)), MK_INT(1LL));
  V v_x3_245;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength(heff_dup(v_ts_240)))) {
      V v_t_244 = heff_arrayIndex(v_ts_240, v_i_241);
      v_x3_245 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      heff_drop(v_ts_240);
      heff_drop(v_i_241);
      v_x3_245 = NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_ts_240);
    heff_drop(v_i_241);
    v_x3_245 = NTAG(TAG_Nothing);
  }
  V v_t_247;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    v_t_247 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x3_245, 0);
    heff_take_n(v_x3_245, 1ULL, 1);
    v_t_247 = heff_get_n(v_x_246, 2, 7);
    break;
  }
  default: heff_nomatch(v_x3_245);
  }
  return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_t_247, ((V)&g_heff_2ebuild_2eproject_2epastTheEnd_str0)})});
}
V g_heff_2ebuild_2eproject_2epastTheEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2epastTheEnd(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str0, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str1, 23, "expected a field's name");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str2, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str3, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str4, 12, "expected `=`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str5, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str6, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str7, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str8, 1, "}");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str9, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str10, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
Clo g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_entry, 3, 0};

V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_246;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_241))) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength(heff_dup(v_ts_240)))) {
      V v_t_245 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_i_241));
      v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    } else {
      v_t_246 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_246 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_i_241);
    heff_drop(v_acc_242);
    return (g_heff_2ebuild_2eproject_2epastTheEnd(v_ts_240));
  }
  case TAG_Just: {
    V v_name_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_249 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_name_247, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str0)));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_ts_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      heff_drop(v_t_249);
      V v_t_2410 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_name_247, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str1)});
      return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Left, 1, (V[]){v_t_2410});
    } else {
      heff_drop(v_t_249);
      V v_i_2411 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL));
      V v_t_2415;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2411))) {
        if (heff_intLt_c(heff_dup(v_i_2411), heff_arrayLength(heff_dup(v_ts_240)))) {
          V v_t_2414 = heff_arrayIndex(heff_dup(v_ts_240), v_i_2411);
          v_t_2415 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2414});
        } else {
          heff_drop_cell(v_ru_24t_246_24Just, 1);
          heff_drop(v_i_2411);
          v_t_2415 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        heff_drop(v_i_2411);
        v_t_2415 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        heff_drop(v_i_241);
        heff_drop(v_acc_242);
        heff_drop_rec(v_name_247, 7);
        return (g_heff_2ebuild_2eproject_2epastTheEnd(v_ts_240));
      }
      case TAG_Just: {
        V v_eq_2416 = heff_field(v_t_2415, 0);
        V v_ru_24t_2415_24Just = heff_take_reuse_n(v_t_2415, 1ULL, 1);
        V v_x1_2418 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_eq_2416, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_eq_2416, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str3))));
        V v_t_2419 = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
        heff_drop(v_x1_2418);
        if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
          heff_drop(v_ts_240);
          heff_drop(v_i_241);
          heff_drop(v_acc_242);
          heff_drop_rec(v_name_247, 7);
          heff_drop(v_t_2419);
          V v_t_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_eq_2416, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str4)});
          return heff_tag_at_n(v_ru_24t_2415_24Just, TAG_Left, 1, (V[]){v_t_2420});
        } else {
          heff_drop_rec(v_eq_2416, 7);
          heff_drop(v_t_2419);
          V v_it_2421 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467(heff_dup(v_ts_240), heff_intAdd(v_i_241, MK_INT(2LL))));
          switch (heff_tag_of(v_it_2421)) {
          case TAG_Left: {
            V v_p_2422 = heff_field(v_it_2421, 0);
            heff_take_n(v_it_2421, 1ULL, 1);
            heff_drop(v_ts_240);
            heff_drop(v_acc_242);
            heff_drop_rec(v_name_247, 7);
            return heff_tag_at_n(v_ru_24t_2415_24Just, TAG_Left, 1, (V[]){v_p_2422});
          }
          case TAG_Right: {
            V v_it1_2423 = heff_field(v_it_2421, 0);
            V v_ru_24it_2421_24Right = heff_take_reuse_n(v_it_2421, 1ULL, 1);
            switch (heff_tag_of(v_it1_2423)) {
            case TAG_MkPair: {
              V v_x_2424 = heff_field(v_it1_2423, 0);
              V v_j_2425 = heff_field(v_it1_2423, 1);
              V v_ru_24it1_2423_24MkPair = heff_take_reuse_n(v_it1_2423, 3ULL, 2);
              V v_t_2429;
              if (heff_intLe_c(MK_INT(0LL), heff_dup(v_j_2425))) {
                if (heff_intLt_c(heff_dup(v_j_2425), heff_arrayLength(heff_dup(v_ts_240)))) {
                  V v_t_2428 = heff_arrayIndex(heff_dup(v_ts_240), heff_dup(v_j_2425));
                  v_t_2429 = heff_tag_at_n(v_ru_24t_2415_24Just, TAG_Just, 1, (V[]){v_t_2428});
                } else {
                  heff_drop_cell(v_ru_24t_2415_24Just, 1);
                  v_t_2429 = NTAG(TAG_Nothing);
                }
              } else {
                heff_drop_cell(v_ru_24t_2415_24Just, 1);
                v_t_2429 = NTAG(TAG_Nothing);
              }
              switch (heff_tag_of(v_t_2429)) {
              case TAG_Nothing: {
                heff_drop(v_acc_242);
                heff_drop_rec(v_name_247, 7);
                heff_drop_cell(v_ru_24it_2421_24Right, 1);
                heff_drop(v_x_2424);
                heff_drop(v_j_2425);
                heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
                return (g_heff_2ebuild_2eproject_2epastTheEnd(v_ts_240));
              }
              case TAG_Just: {
                V v_t_2430 = heff_field(v_t_2429, 0);
                heff_take_n(v_t_2429, 1ULL, 1);
                V v_t_2432 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_2430, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str5)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2430, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str6))));
                if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24it_2421_24Right, 1);
                  heff_drop_rec(v_t_2430, 7);
                  heff_drop(v_t_2432);
                  V v_t_2433 = heff_tag_at_n(v_ru_24it1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_name_247, 1, 7), v_x_2424});
                  V t_0 = v_ts_240;
                  V t_1 = heff_intAdd(v_j_2425, MK_INT(1LL));
                  V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_acc_242});
                  v_ts_240 = t_0;
                  v_i_241 = t_1;
                  v_acc_242 = t_2;
                  goto top;
                } else {
                  heff_drop(v_ts_240);
                  heff_drop(v_t_2432);
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_2430, 0)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str7))) {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_2430, 1)), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str8))) {
                      heff_drop_rec(v_t_2430, 7);
                      V v_t_2436 = heff_tag_at_n(v_ru_24it1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_name_247, 1, 7), v_x_2424});
                      V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_acc_242})));
                      V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, heff_intAdd(v_j_2425, MK_INT(1LL))});
                      return heff_tag_at_n(v_ru_24it_2421_24Right, TAG_Right, 1, (V[]){v_t_2438});
                    } else {
                      heff_drop(v_acc_242);
                      heff_drop_rec(v_name_247, 7);
                      heff_drop(v_x_2424);
                      heff_drop(v_j_2425);
                      heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
                      V v_t_2439 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2430, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str9)});
                      return heff_tag_at_n(v_ru_24it_2421_24Right, TAG_Left, 1, (V[]){v_t_2439});
                    }
                  } else {
                    heff_drop(v_acc_242);
                    heff_drop_rec(v_name_247, 7);
                    heff_drop(v_x_2424);
                    heff_drop(v_j_2425);
                    heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
                    V v_t_2440 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2430, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_str10)});
                    return heff_tag_at_n(v_ru_24it_2421_24Right, TAG_Left, 1, (V[]){v_t_2440});
                  }
                }
              }
              default: return heff_nomatch(v_t_2429);
              }
            }
            default: return heff_nomatch(v_it1_2423);
            }
          }
          default: return heff_nomatch(v_it_2421);
          }
        }
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_str0, 1, ".");
Clo g_heff_2ebuild_2eproject_2eversion_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eversion_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eversion(V v_v_240) {
top: ;
  V v_it_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2eversion_str0), v_v_240, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    V v_ru_24it_241_24Cons = heff_take_reuse_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24it_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      V v_ru_24it2_243_24Cons = heff_take_reuse_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24it_241_24Cons, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24it2_243_24Cons, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_c_246 = heff_field(v_it22_245, 0);
        V v_it222_247 = heff_field(v_it22_245, 1);
        heff_take_n(v_it22_245, 3ULL, 2);
        switch (heff_tag_of(v_it222_247)) {
        case TAG_Nil: {
          V v_t_248 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_a_242)));
          if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
            heff_drop(v_t_248);
            V v_t_249 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_b_244)));
            if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
              heff_drop(v_t_249);
              V v_t_2410 = (g_heff_2ebuild_2eproject_2eisNumber(heff_dup(v_c_246)));
              if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
                heff_drop(v_t_2410);
                V v_t_2411 = heff_tag_at_n(v_ru_24it_241_24Cons, TAG_Cons, 2, (V[]){v_c_246, NTAG(TAG_Nil)});
                V v_t_2412 = heff_tag_at_n(v_ru_24it2_243_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, v_t_2411})});
                V v_t_2413 = (g_list_2emap_24s546447922x1671206170(MK_INT(0LL), v_t_2412));
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
              } else {
                heff_drop(v_a_242);
                heff_drop_cell(v_ru_24it_241_24Cons, 2);
                heff_drop(v_b_244);
                heff_drop_cell(v_ru_24it2_243_24Cons, 2);
                heff_drop(v_c_246);
                heff_drop(v_t_2410);
                return NTAG(TAG_Nothing);
              }
            } else {
              heff_drop(v_a_242);
              heff_drop_cell(v_ru_24it_241_24Cons, 2);
              heff_drop(v_b_244);
              heff_drop_cell(v_ru_24it2_243_24Cons, 2);
              heff_drop(v_c_246);
              heff_drop(v_t_249);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_a_242);
            heff_drop_cell(v_ru_24it_241_24Cons, 2);
            heff_drop(v_b_244);
            heff_drop_cell(v_ru_24it2_243_24Cons, 2);
            heff_drop(v_c_246);
            heff_drop(v_t_248);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_247, 0ULL, 2);
          heff_drop(v_a_242);
          heff_drop_cell(v_ru_24it_241_24Cons, 2);
          heff_drop(v_b_244);
          heff_drop_cell(v_ru_24it2_243_24Cons, 2);
          heff_drop(v_c_246);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it222_247);
        }
      }
      default: return heff_nomatch(v_it22_245);
      }
    }
    default: return heff_nomatch(v_it2_243);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eversion(a[0]);
}
V g_heff_2ebuild_2eproject_2eisName_lam0(V self, V *args);
Clo g_heff_2ebuild_2eproject_2eisName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisName_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisName(V v_x_240) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_strLength(heff_dup(v_x_240)))) {
    if (heff_intLe_c(MK_INT(97LL), heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)))) {
      if (heff_intLe_c(heff_strByteAt(heff_dup(v_x_240), MK_INT(0LL)), MK_INT(122LL))) {
        V v_t_245 = (g_list_2emap_24f1649958057x1967137941(heff_clo_n(g_heff_2ebuild_2eproject_2eisName_lam0, 1, 1, (V[]){heff_dup(v_x_240)}), MK_INT(0LL), heff_strLength(v_x_240)));
        return ({ V a_0 = MK_INT(97LL); V a_1 = MK_INT(122LL); V a_2 = MK_INT(65LL); V a_3 = MK_INT(90LL); V a_4 = MK_INT(48LL); V a_5 = MK_INT(57LL); V a_6 = MK_INT(95LL); V a_7 = MK_INT(95LL); V a_8 = MK_INT(48LL); V a_9 = MK_INT(57LL); V a_10 = MK_INT(95LL); V a_11 = MK_INT(95LL); V a_12 = v_t_245; V r_ = (g_list_2eall_24s1821787051x863686734(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_t_245); r_; });
      } else {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eisName(a[0]);
}
V g_heff_2ebuild_2eproject_2eisName_lam0(V self, V *args) {
  V v_i_244 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strByteAt(v_x_240, v_i_244);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eproject_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        V v_s_247 = heff_dup(v_x_241);
        V v_s_248 = heff_strAppend(v_s_247, ((V)&g_heff_2ebuild_2eproject_2eandList_str2));
        return (g_heff_2ebuild_2eproject_2eandList_24acc(v_x12_242, v_s_248));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_24acc_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_f_241, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_241, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_241, 0, 2), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2eproject_2eleftOutNames_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_f_242, 1);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_242, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_242, 0, 2), heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_rest_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_str0, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_str1, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_str2, 17, "expected a string");
Clo g_heff_2ebuild_2eproject_2estr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2estr_entry, 1, 0};

V g_heff_2ebuild_2eproject_2estr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_s_241 = heff_field(v_x_240, 0);
    return heff_tag_n(TAG_Right, 1, (V[]){heff_dup(v_s_241)});
  }
  case TAG_LTag: {
    V v_t_2413;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_246);
      break;
    }
    case TAG_LTag: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_248);
      break;
    }
    case TAG_LList: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2410);
      break;
    }
    case TAG_LRec: {
      V v_t_2412 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2412);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2414 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_str0)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2414});
  }
  case TAG_LList: {
    V v_t_2425;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LTag: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LList: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2422);
      break;
    }
    case TAG_LRec: {
      V v_t_2424 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2424);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2426 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2425, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_str1)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2426});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_str2)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2438});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2ebuild_2eproject_2estr_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2estr(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_str0, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_str1, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_str2, 23, "expected a list `[...]`");
Clo g_heff_2ebuild_2eproject_2eitems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eitems_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eitems(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_244);
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_246);
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_248);
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_2410);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_str0)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2412});
  }
  case TAG_LTag: {
    V v_t_2423;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2416 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2416);
      break;
    }
    case TAG_LTag: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LList: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LRec: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2422);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_str1)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2424});
  }
  case TAG_LList: {
    V v_xs_2425 = heff_field(v_x_240, 0);
    return heff_tag_n(TAG_Right, 1, (V[]){heff_dup(v_xs_2425)});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_t_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_str2)});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2438});
  }
  default: return heff_nomatch(v_x_240);
  }
}
V g_heff_2ebuild_2eproject_2eitems_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eitems(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str2, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str3, 8, "version ");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str4, 44, " is fetched from a path without a /vN ending");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str6, 35, " is fetched from a path ending in /");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_str7, 8, "version ");
Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2emajorMismatch_entry, 2, 0};

V g_heff_2ebuild_2eproject_2emajorMismatch(V v_path_240, V v_v_241) {
top: ;
  V v_x2_242 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_v_241)));
  V v_x1_244;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    v_x1_244 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    v_x1_244 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_247;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    v_x2_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    v_x2_247 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_n_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_n_249 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_n_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2412;
  if (heff_intLe_c(MK_INT(2LL), heff_dup(v_n_249))) {
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str0), heff_intShow(v_n_249));
    v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  } else {
    heff_drop(v_n_249);
    v_t_2412 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    V v_xs_2413 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str1), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
    V v_x_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_x_2417 = v_path_240;
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 2);
      heff_drop(v_path_240);
      v_x_2417 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_x_2417)))) {
      if (heff_strEq_c(heff_strSlice(heff_dup(v_x_2417), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str2))) {
        V v_t_2420 = heff_strSlice(heff_dup(v_x_2417), MK_INT(1LL), heff_strLength(v_x_2417));
        V v_t_2421 = (g_heff_2ebuild_2eproject_2eisNumber(v_t_2420));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str3), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str4)));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
        } else {
          heff_drop(v_v_241);
          heff_drop(v_t_2421);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_v_241);
        heff_drop(v_x_2417);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_v_241);
      heff_drop(v_x_2417);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_Just: {
    V v_suffix_2423 = heff_field(v_t_2412, 0);
    V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 1ULL, 1);
    V v_xs_2424 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str5), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    V v_t_2428;
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nil: {
      v_t_2428 = v_path_240;
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 2);
      heff_drop(v_path_240);
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
    if (heff_strEq_c(v_t_2428, heff_dup(v_suffix_2423))) {
      heff_drop(v_v_241);
      heff_drop(v_suffix_2423);
      heff_drop_cell(v_ru_24t_2412_24Just, 1);
      return NTAG(TAG_Nothing);
    } else {
      V v_t_2430 = heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str6), v_suffix_2423));
      return heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_str7), v_t_2430)});
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2emajorMismatch(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2etwiceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2etwiceGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2etwiceGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_seen_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})});
      } else {
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_n_244, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eproject_2etwiceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2etwiceGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2eunrequired_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eunrequired_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eunrequired(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_names_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_n_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})});
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eproject_2eunrequired_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eunrequired(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eclaimMsg_str0, 143, "error[E0347]: the package `heff` is heff's own, and this is not the checkout heff is built in or was installed from: name the project otherwise");

static V g_heff_2ebuild_2eproject_2eclaimMsg_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2eclaimMsg_st;
static V g_heff_2ebuild_2eproject_2eclaimMsg_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2eclaimMsg_str0);
}
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2eclaimMsg_st)) return g_heff_2ebuild_2eproject_2eclaimMsg_val;
  return heff_global(&g_heff_2ebuild_2eproject_2eclaimMsg_val, &g_heff_2ebuild_2eproject_2eclaimMsg_st, g_heff_2ebuild_2eproject_2eclaimMsg_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckHeff_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckHeff_str1, 78, "` is the package `heff`, heff's own, which comes with heff: it is not replaced");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckHeff_str2, 14, "error[E0347]: ");
Clo g_heff_2ebuild_2eproject_2echeckHeff_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2echeckHeff_entry, 4, 0};

V g_heff_2ebuild_2eproject_2echeckHeff(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2emap_24f1156519715x726760149(heff_dup(v_rs_241)));
  V v_t_245 = (g_list_2ezipWith_24s1958630276x749154843(v_pxs_242, v_ps_243));
  V v_it_246 = ({ V a_0 = v_t_244; V a_1 = v_t_245; V r_ = (g_heff_2ebuild_2eproject_2efirstNamed(a_0, a_1)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2ezipWith_24s29557946x653938035(v_rxs_240, v_rs_241));
    V v_it_249 = ({ V a_0 = v_t_247; V a_1 = v_t_248; V r_ = (g_heff_2ebuild_2eproject_2efirstNamed(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
    switch (heff_tag_of(v_it_249)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_Just: {
      V v_it1_2410 = heff_field(v_it_249, 0);
      V v_ru_24it_249_24Just = heff_take_reuse_n(v_it_249, 1ULL, 1);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 2ULL, 2);
        V v_t_2421;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_LStr: {
          V v_t_2414 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2414;
          break;
        }
        case TAG_LTag: {
          V v_t_2416 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2416;
          break;
        }
        case TAG_LList: {
          V v_t_2418 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2418;
          break;
        }
        case TAG_LRec: {
          V v_t_2420 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2420;
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        V v_t_2422 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2421, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())});
        return heff_tag_at_n(v_ru_24it_249_24Just, TAG_Left, 1, (V[]){v_t_2422});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_it_249);
    }
  }
  case TAG_Just: {
    V v_it1_2423 = heff_field(v_it_246, 0);
    V v_ru_24it_246_24Just = heff_take_reuse_n(v_it_246, 1ULL, 1);
    heff_drop(v_rxs_240);
    heff_drop(v_rs_241);
    switch (heff_tag_of(v_it1_2423)) {
    case TAG_MkPair: {
      V v_n_2424 = heff_field(v_it1_2423, 0);
      V v_x_2425 = heff_field(v_it1_2423, 1);
      heff_take_n(v_it1_2423, 3ULL, 2);
      V v_t_2434;
      switch (heff_tag_of(v_x_2425)) {
      case TAG_LStr: {
        V v_t_2427 = heff_field(v_x_2425, 1);
        heff_take_n(v_x_2425, 2ULL, 2);
        v_t_2434 = v_t_2427;
        break;
      }
      case TAG_LTag: {
        V v_t_2429 = heff_field(v_x_2425, 1);
        heff_take_n(v_x_2425, 2ULL, 2);
        v_t_2434 = v_t_2429;
        break;
      }
      case TAG_LList: {
        V v_t_2431 = heff_field(v_x_2425, 1);
        heff_take_n(v_x_2425, 2ULL, 2);
        v_t_2434 = v_t_2431;
        break;
      }
      case TAG_LRec: {
        V v_t_2433 = heff_field(v_x_2425, 1);
        heff_take_n(v_x_2425, 2ULL, 2);
        v_t_2434 = v_t_2433;
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      V v_t_2435 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckHeff_str0), heff_strAppend(v_n_2424, ((V)&g_heff_2ebuild_2eproject_2echeckHeff_str1)));
      V v_t_2436 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2434, 2, 7), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckHeff_str2), v_t_2435)});
      return heff_tag_at_n(v_ru_24it_246_24Just, TAG_Left, 1, (V[]){v_t_2436});
    }
    default: return heff_nomatch(v_it1_2423);
    }
  }
  default: return heff_nomatch(v_it_246);
  }
}
V g_heff_2ebuild_2eproject_2echeckHeff_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2echeckHeff(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str1, 31, "` is replaced, but not required");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str3, 19, "` is replaced twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_str5, 19, "` is required twice");
Clo g_heff_2ebuild_2eproject_2echeckNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2echeckNames_entry, 4, 0};

V g_heff_2ebuild_2eproject_2echeckNames(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s634456687x1151454243(heff_dup(v_rxs_240), heff_dup(v_rs_241)));
  V v_it_245 = (g_heff_2ebuild_2eproject_2etwiceGo(NTAG(TAG_Nil), v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
    V v_it_247 = (g_heff_2ebuild_2eproject_2etwiceGo(NTAG(TAG_Nil), v_t_246));
    switch (heff_tag_of(v_it_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_list_2emap_24s1791433880x1360378684(heff_dup(v_rs_241)));
      V v_t_249 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
      V v_it_2410 = ({ V a_0 = v_t_248; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2eproject_2eunrequired(a_0, a_1)); heff_drop(v_t_248); r_; });
      switch (heff_tag_of(v_it_2410)) {
      case TAG_Nothing: {
        HEFF_LAST return g_heff_2ebuild_2eproject_2echeckHeff(v_rxs_240, v_rs_241, v_pxs_242, v_ps_243);
      }
      case TAG_Just: {
        V v_it1_2411 = heff_field(v_it_2410, 0);
        V v_ru_24it_2410_24Just = heff_take_reuse_n(v_it_2410, 1ULL, 1);
        heff_drop(v_rxs_240);
        heff_drop(v_rs_241);
        heff_drop(v_pxs_242);
        heff_drop(v_ps_243);
        switch (heff_tag_of(v_it1_2411)) {
        case TAG_MkPair: {
          V v_n_2412 = heff_field(v_it1_2411, 0);
          V v_x_2413 = heff_field(v_it1_2411, 1);
          heff_take_n(v_it1_2411, 3ULL, 2);
          V v_t_2422;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_LStr: {
            V v_t_2415 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2415;
            break;
          }
          case TAG_LTag: {
            V v_t_2417 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2417;
            break;
          }
          case TAG_LList: {
            V v_t_2419 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2419;
            break;
          }
          case TAG_LRec: {
            V v_t_2421 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2422 = v_t_2421;
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_str0), heff_strAppend(v_n_2412, ((V)&g_heff_2ebuild_2eproject_2echeckNames_str1)));
          V v_t_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2422, 2, 7), v_t_2423});
          return heff_tag_at_n(v_ru_24it_2410_24Just, TAG_Left, 1, (V[]){v_t_2424});
        }
        default: return heff_nomatch(v_it1_2411);
        }
      }
      default: return heff_nomatch(v_it_2410);
      }
    }
    case TAG_Just: {
      V v_it1_2425 = heff_field(v_it_247, 0);
      V v_ru_24it_247_24Just = heff_take_reuse_n(v_it_247, 1ULL, 1);
      heff_drop(v_rxs_240);
      heff_drop(v_rs_241);
      heff_drop(v_pxs_242);
      heff_drop(v_ps_243);
      switch (heff_tag_of(v_it1_2425)) {
      case TAG_MkPair: {
        V v_n_2426 = heff_field(v_it1_2425, 0);
        V v_x_2427 = heff_field(v_it1_2425, 1);
        heff_take_n(v_it1_2425, 3ULL, 2);
        V v_t_2436;
        switch (heff_tag_of(v_x_2427)) {
        case TAG_LStr: {
          V v_t_2429 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2429;
          break;
        }
        case TAG_LTag: {
          V v_t_2431 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2431;
          break;
        }
        case TAG_LList: {
          V v_t_2433 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2433;
          break;
        }
        case TAG_LRec: {
          V v_t_2435 = heff_field(v_x_2427, 1);
          heff_take_n(v_x_2427, 2ULL, 2);
          v_t_2436 = v_t_2435;
          break;
        }
        default: heff_nomatch(v_x_2427);
        }
        V v_t_2437 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_str2), heff_strAppend(v_n_2426, ((V)&g_heff_2ebuild_2eproject_2echeckNames_str3)));
        V v_t_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), v_t_2437});
        return heff_tag_at_n(v_ru_24it_247_24Just, TAG_Left, 1, (V[]){v_t_2438});
      }
      default: return heff_nomatch(v_it1_2425);
      }
    }
    default: return heff_nomatch(v_it_247);
    }
  }
  case TAG_Just: {
    V v_it1_2439 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    heff_drop(v_rxs_240);
    heff_drop(v_rs_241);
    heff_drop(v_pxs_242);
    heff_drop(v_ps_243);
    switch (heff_tag_of(v_it1_2439)) {
    case TAG_MkPair: {
      V v_n_2440 = heff_field(v_it1_2439, 0);
      V v_x_2441 = heff_field(v_it1_2439, 1);
      heff_take_n(v_it1_2439, 3ULL, 2);
      V v_t_2450;
      switch (heff_tag_of(v_x_2441)) {
      case TAG_LStr: {
        V v_t_2443 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2443;
        break;
      }
      case TAG_LTag: {
        V v_t_2445 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2445;
        break;
      }
      case TAG_LList: {
        V v_t_2447 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2447;
        break;
      }
      case TAG_LRec: {
        V v_t_2449 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2450 = v_t_2449;
        break;
      }
      default: heff_nomatch(v_x_2441);
      }
      V v_t_2451 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_str4), heff_strAppend(v_n_2440, ((V)&g_heff_2ebuild_2eproject_2echeckNames_str5)));
      V v_t_2452 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2450, 2, 7), v_t_2451});
      return heff_tag_at_n(v_ru_24it_245_24Just, TAG_Left, 1, (V[]){v_t_2452});
    }
    default: return heff_nomatch(v_it1_2439);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eproject_2echeckNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2echeckNames(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2eproject_2ereplaceOf(a_0)); heff_drop(v_x_241); r_; });
    V v_x2_244 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(v_rest_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_p_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_x2_244);
      return heff_tag_at_n(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_p_245});
    }
    case TAG_Right: {
      V v_y_246 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Left: {
        V v_p_247 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_y_246);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_p_247});
      }
      case TAG_Right: {
        V v_ys_248 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_248})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str0, 6, "module");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str1, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str2, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str3, 7, "replace");
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam0, 1, 0};
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam1, 1, 0};

static V g_heff_2ebuild_2eproject_2epackageFields_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2epackageFields_st;
static V g_heff_2ebuild_2eproject_2epackageFields_init(void) {
  V v_t_240 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str0), NTAG(TAG_Nothing)});
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam0_clo)})});
  V v_t_245 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str3), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_246})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_247});
}
V g_heff_2ebuild_2eproject_2epackageFields_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2epackageFields_st)) return g_heff_2ebuild_2eproject_2epackageFields_val;
  return heff_global(&g_heff_2ebuild_2eproject_2epackageFields_val, &g_heff_2ebuild_2eproject_2epackageFields_st, g_heff_2ebuild_2eproject_2epackageFields_init);
}
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_242});
}
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_244});
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_str4, 25, "expected a record `{...}`");
Clo g_heff_2ebuild_2eproject_2epackageOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epackageOf(V v_x_240) {
top: ;
  V v_it_241 = (g_heff_2ebuild_2eproject_2efieldsAre(heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()), v_x_240));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Left: {
    V v_p_242 = heff_field(v_it_241, 0);
    V v_ru_24it_241_24Left = heff_take_reuse_n(v_it_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24it_241_24Left, TAG_Left, 1, (V[]){v_p_242});
  }
  case TAG_Right: {
    V v_it1_243 = heff_field(v_it_241, 0);
    V v_ru_24it_241_24Right = heff_take_reuse_n(v_it_241, 1ULL, 1);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_Nil: {
      V v_t_2412;
      switch (heff_tag_of(v_x_240)) {
      case TAG_LStr: {
        V v_t_245 = heff_field(v_x_240, 1);
        v_t_2412 = heff_dup(v_t_245);
        break;
      }
      case TAG_LTag: {
        V v_t_247 = heff_field(v_x_240, 1);
        v_t_2412 = heff_dup(v_t_247);
        break;
      }
      case TAG_LList: {
        V v_t_249 = heff_field(v_x_240, 1);
        v_t_2412 = heff_dup(v_t_249);
        break;
      }
      case TAG_LRec: {
        V v_t_2411 = heff_field(v_x_240, 1);
        v_t_2412 = heff_dup(v_t_2411);
        break;
      }
      default: heff_nomatch(v_x_240);
      }
      V v_t_2413 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str0)});
      return heff_tag_at_n(v_ru_24it_241_24Right, TAG_Left, 1, (V[]){v_t_2413});
    }
    case TAG_Cons: {
      V v_m_2414 = heff_field(v_it1_243, 0);
      V v_it12_2415 = heff_field(v_it1_243, 1);
      heff_take_n(v_it1_243, 3ULL, 2);
      switch (heff_tag_of(v_it12_2415)) {
      case TAG_Nil: {
        heff_drop(v_m_2414);
        V v_t_2424;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2417 = heff_field(v_x_240, 1);
          v_t_2424 = heff_dup(v_t_2417);
          break;
        }
        case TAG_LTag: {
          V v_t_2419 = heff_field(v_x_240, 1);
          v_t_2424 = heff_dup(v_t_2419);
          break;
        }
        case TAG_LList: {
          V v_t_2421 = heff_field(v_x_240, 1);
          v_t_2424 = heff_dup(v_t_2421);
          break;
        }
        case TAG_LRec: {
          V v_t_2423 = heff_field(v_x_240, 1);
          v_t_2424 = heff_dup(v_t_2423);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str1)});
        return heff_tag_at_n(v_ru_24it_241_24Right, TAG_Left, 1, (V[]){v_t_2425});
      }
      case TAG_Cons: {
        V v_h_2426 = heff_field(v_it12_2415, 0);
        V v_it122_2427 = heff_field(v_it12_2415, 1);
        heff_take_n(v_it12_2415, 3ULL, 2);
        switch (heff_tag_of(v_it122_2427)) {
        case TAG_Nil: {
          heff_drop(v_m_2414);
          heff_drop(v_h_2426);
          V v_t_2436;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2429 = heff_field(v_x_240, 1);
            v_t_2436 = heff_dup(v_t_2429);
            break;
          }
          case TAG_LTag: {
            V v_t_2431 = heff_field(v_x_240, 1);
            v_t_2436 = heff_dup(v_t_2431);
            break;
          }
          case TAG_LList: {
            V v_t_2433 = heff_field(v_x_240, 1);
            v_t_2436 = heff_dup(v_t_2433);
            break;
          }
          case TAG_LRec: {
            V v_t_2435 = heff_field(v_x_240, 1);
            v_t_2436 = heff_dup(v_t_2435);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2437 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str2)});
          return heff_tag_at_n(v_ru_24it_241_24Right, TAG_Left, 1, (V[]){v_t_2437});
        }
        case TAG_Cons: {
          V v_rq_2438 = heff_field(v_it122_2427, 0);
          V v_it1222_2439 = heff_field(v_it122_2427, 1);
          heff_take_n(v_it122_2427, 3ULL, 2);
          switch (heff_tag_of(v_it1222_2439)) {
          case TAG_Nil: {
            heff_drop(v_m_2414);
            heff_drop(v_h_2426);
            heff_drop(v_rq_2438);
            V v_t_2448;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2441 = heff_field(v_x_240, 1);
              v_t_2448 = heff_dup(v_t_2441);
              break;
            }
            case TAG_LTag: {
              V v_t_2443 = heff_field(v_x_240, 1);
              v_t_2448 = heff_dup(v_t_2443);
              break;
            }
            case TAG_LList: {
              V v_t_2445 = heff_field(v_x_240, 1);
              v_t_2448 = heff_dup(v_t_2445);
              break;
            }
            case TAG_LRec: {
              V v_t_2447 = heff_field(v_x_240, 1);
              v_t_2448 = heff_dup(v_t_2447);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_t_2449 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2448, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str3)});
            return heff_tag_at_n(v_ru_24it_241_24Right, TAG_Left, 1, (V[]){v_t_2449});
          }
          case TAG_Cons: {
            V v_rp_2450 = heff_field(v_it1222_2439, 0);
            V v_it12222_2451 = heff_field(v_it1222_2439, 1);
            heff_take_n(v_it1222_2439, 3ULL, 2);
            switch (heff_tag_of(v_it12222_2451)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24it_241_24Right, 1);
              return ({ V a_0 = v_m_2414; V a_1 = v_h_2426; V a_2 = v_rq_2438; V a_3 = v_rp_2450; V r_ = (g_heff_2ebuild_2eproject_2epackageOf4(a_0, a_1, a_2, a_3)); heff_drop(v_m_2414); heff_drop(v_h_2426); heff_drop(v_rq_2438); heff_drop(v_rp_2450); r_; });
            }
            case TAG_Cons: {
              heff_take_n(v_it12222_2451, 0ULL, 2);
              heff_drop(v_m_2414);
              heff_drop(v_h_2426);
              heff_drop(v_rq_2438);
              heff_drop(v_rp_2450);
              V v_t_2462;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2455 = heff_field(v_x_240, 1);
                v_t_2462 = heff_dup(v_t_2455);
                break;
              }
              case TAG_LTag: {
                V v_t_2457 = heff_field(v_x_240, 1);
                v_t_2462 = heff_dup(v_t_2457);
                break;
              }
              case TAG_LList: {
                V v_t_2459 = heff_field(v_x_240, 1);
                v_t_2462 = heff_dup(v_t_2459);
                break;
              }
              case TAG_LRec: {
                V v_t_2461 = heff_field(v_x_240, 1);
                v_t_2462 = heff_dup(v_t_2461);
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_t_2463 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2462, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_str4)});
              return heff_tag_at_n(v_ru_24it_241_24Right, TAG_Left, 1, (V[]){v_t_2463});
            }
            default: return heff_nomatch(v_it12222_2451);
            }
          }
          default: return heff_nomatch(v_it1222_2439);
          }
        }
        default: return heff_nomatch(v_it122_2427);
        }
      }
      default: return heff_nomatch(v_it12_2415);
      }
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2epackageOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2eclaimOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eclaimOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eclaimOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Left: {
    return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
  }
  case TAG_Right: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x1_243 = (g_heff_2ebuild_2eproject_2efieldsAre(heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()), v_x_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      heff_take_n(v_x1_243, 0ULL, 1);
      return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
    }
    case TAG_Right: {
      V v_x11_245 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      switch (heff_tag_of(v_x11_245)) {
      case TAG_Nil: {
        return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
      }
      case TAG_Cons: {
        V v_m_246 = heff_field(v_x11_245, 0);
        heff_take_n(v_x11_245, 1ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_m_246)) {
        case TAG_LStr: {
          V v_t_249 = heff_field(v_m_246, 1);
          heff_take_n(v_m_246, 2ULL, 2);
          v_t_2416 = v_t_249;
          break;
        }
        case TAG_LTag: {
          V v_t_2411 = heff_field(v_m_246, 1);
          heff_take_n(v_m_246, 2ULL, 2);
          v_t_2416 = v_t_2411;
          break;
        }
        case TAG_LList: {
          V v_t_2413 = heff_field(v_m_246, 1);
          heff_take_n(v_m_246, 2ULL, 2);
          v_t_2416 = v_t_2413;
          break;
        }
        case TAG_LRec: {
          V v_t_2415 = heff_field(v_m_246, 1);
          heff_take_n(v_m_246, 2ULL, 2);
          v_t_2416 = v_t_2415;
          break;
        }
        default: heff_nomatch(v_m_246);
        }
        return heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2416, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
      }
      default: return heff_nomatch(v_x11_245);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eclaimOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2enewerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewerGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewerGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c(heff_dup(v_y_244), heff_dup(v_x_242))) {
        return NTAG(TAG_True);
      } else {
        if (heff_intEq_c(heff_dup(v_x_242), heff_dup(v_y_244))) {
          V t_0 = v_xs_243;
          V t_1 = v_ys_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2enewerGo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str2, 1, "/");
Clo g_heff_2ebuild_2eproject_2erepoOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erepoOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2erepoOf(V v_path_240) {
top: ;
  V v_xs_241 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2erepoOf_str0), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_x_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    v_x_245 = heff_dup(v_path_240);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    v_x_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_x_245)))) {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_245), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ebuild_2eproject_2erepoOf_str1))) {
      V v_t_248 = heff_strSlice(heff_dup(v_x_245), MK_INT(1LL), heff_strLength(v_x_245));
      V v_t_249 = (g_heff_2ebuild_2eproject_2eisNumber(v_t_248));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_xs_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eproject_2erepoOf_str2), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nil: {
          v_t_2414 = heff_dup(v_path_240);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_t_2411, 0);
          heff_take_n(v_t_2411, 1ULL, 2);
          v_t_2414 = v_x_2412;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        V v_t_2415 = heff_intSub(heff_strLength(heff_dup(v_path_240)), heff_strLength(v_t_2414));
        return heff_strSlice(v_path_240, MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL)));
      } else {
        heff_drop(v_t_249);
        return v_path_240;
      }
    } else {
      heff_drop(v_x_245);
      return v_path_240;
    }
  } else {
    heff_drop(v_x_245);
    return v_path_240;
  }
}
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erepoOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str0, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str1, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str3, 30, "` is no version: write `a.b.c`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_str4, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
Clo g_heff_2ebuild_2eproject_2esumLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2esumLine_entry, 2, 0};

V g_heff_2ebuild_2eproject_2esumLine(V v_at_240, V v_line_241) {
top: ;
  V v_it_242 = (g_prelude_2ewordsFrom(v_line_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_it2_244 = heff_field(v_it_242, 1);
    V v_ru_24it_242_24Cons = heff_take_reuse_n(v_it_242, 3ULL, 2);
    switch (heff_tag_of(v_it2_244)) {
    case TAG_Nil: {
      heff_drop(v_p_243);
      heff_drop_cell(v_ru_24it_242_24Cons, 2);
      return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_str0)})});
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_it2_244, 0);
      V v_it22_246 = heff_field(v_it2_244, 1);
      heff_take_n(v_it2_244, 3ULL, 2);
      switch (heff_tag_of(v_it22_246)) {
      case TAG_Nil: {
        heff_drop(v_p_243);
        heff_drop_cell(v_ru_24it_242_24Cons, 2);
        heff_drop(v_v_245);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_str1)})});
      }
      case TAG_Cons: {
        V v_h_247 = heff_field(v_it22_246, 0);
        V v_it222_248 = heff_field(v_it22_246, 1);
        heff_take_n(v_it22_246, 3ULL, 2);
        switch (heff_tag_of(v_it222_248)) {
        case TAG_Nil: {
          V v_t_249 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_v_245)));
          switch (heff_tag_of(v_t_249)) {
          case TAG_Nothing: {
            heff_drop(v_p_243);
            heff_drop_cell(v_ru_24it_242_24Cons, 2);
            heff_drop(v_h_247);
            V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2esumLine_str2), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eproject_2esumLine_str3)));
            return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, v_t_2410})});
          }
          case TAG_Just: {
            V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 0ULL, 1);
            heff_drop(v_at_240);
            V v_t_2412 = heff_tag_at_n(v_ru_24it_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_p_243, v_v_245, v_h_247}), NTAG(TAG_Nil)});
            return heff_tag_at_n(v_ru_24t_249_24Just, TAG_Right, 1, (V[]){v_t_2412});
          }
          default: return heff_nomatch(v_t_249);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_248, 0ULL, 2);
          heff_drop(v_p_243);
          heff_drop_cell(v_ru_24it_242_24Cons, 2);
          heff_drop(v_v_245);
          heff_drop(v_h_247);
          return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_str4)})});
        }
        default: return heff_nomatch(v_it222_248);
        }
      }
      default: return heff_nomatch(v_it22_246);
      }
    }
    default: return heff_nomatch(v_it2_244);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2ebuild_2eproject_2esumLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2esumLine(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2esumBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2esumBefore_entry, 2, 0};

V g_heff_2ebuild_2eproject_2esumBefore(V v_a_240, V v_b_241) {
top: ;
  if (heff_strLt_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
    heff_drop_rec(v_a_240, 3);
    heff_drop_rec(v_b_241, 3);
    return NTAG(TAG_True);
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
      V v_x2_244 = (g_heff_2ebuild_2eproject_2eversion(heff_get_n(v_a_240, 1, 3)));
      V v_t_246;
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        v_t_246 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_245 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        v_t_246 = v_x_245;
        break;
      }
      default: heff_nomatch(v_x2_244);
      }
      V v_x2_247 = (g_heff_2ebuild_2eproject_2eversion(heff_get_n(v_b_241, 1, 3)));
      V v_t_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_t_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_x1_2410 = ({ V a_0 = v_t_246; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_t_249); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
      heff_drop(v_x1_2410);
      return v_ret_24bool;
    } else {
      heff_drop_rec(v_a_240, 3);
      heff_drop_rec(v_b_241, 3);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2eproject_2esumBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2esumBefore(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2ewithPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ewithPackage_entry, 2, 0};

V g_heff_2ebuild_2eproject_2ewithPackage(V v_src_240, V v_pk_241) {
top: ;
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_l_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_240), v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_244 = heff_arrayFromList(heff_get_n(v_l_243, 0, 3));
  V v_it_245 = (g_heff_2ebuild_2eproject_2espanGo(v_t_244, MK_INT(0LL)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_pk_241);
    return v_src_240;
  }
  case TAG_Just: {
    V v_it1_246 = heff_field(v_it_245, 0);
    heff_take_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_from_247 = heff_field(v_it1_246, 0);
      V v_to_248 = heff_field(v_it1_246, 1);
      heff_take_n(v_it1_246, 3ULL, 2);
      V v_t_249 = (g_heff_2ebuild_2eproject_2eshowPackage(v_pk_241));
      V v_t_2410 = heff_strSlice(heff_dup(v_src_240), v_to_248, heff_strLength(heff_dup(v_src_240)));
      return heff_strAppend(heff_strSlice(v_src_240, MK_INT(0LL), v_from_247), heff_strAppend(v_t_249, v_t_2410));
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2ewithPackage(a[0], a[1]);
}