// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_hash 9690581
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_version 583465758
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_name__dir[] = {LBL_name, LBL_dir};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423(V);
V g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V);
V g_heff_2ebuild_2eproject_2eandList(V);
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_clo;
V g_heff_2ebuild_2eproject_2eandList_24acc(V, V);
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo;
V g_heff_2ebuild_2eproject_2ebuildOf_24rec1_get(void);
V g_heff_2ebuild_2eproject_2ebuildOf_24rec3_get(void);
HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
HeffT3 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2eproject_2efirstNamed_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisMajorPart(V);
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo;
HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V);
HeffT3 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames(V);
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo;
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo;
HeffT3 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2enameOf_24cpr(V);
V g_heff_2ebuild_2eproject_2enameRule_get(void);
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2enextDecl(V, V);
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enextDecl_clo;
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V);
HeffT3 g_heff_2ebuild_2eproject_2espanGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
V g_heff_2ebuild_2eproject_2etestsModule_get(void);
HeffT3 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V, V);
HeffT3 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V, V);
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_list_2eall_24s1411948616x47436528(V, V, V);
V g_list_2eall_24s1411948616x47436528_entry(V self, V *a);
extern Clo g_list_2eall_24s1411948616x47436528_clo;
V g_list_2eall_24s494596359x1928238377(V);
V g_list_2eall_24s494596359x1928238377_entry(V self, V *a);
extern Clo g_list_2eall_24s494596359x1928238377_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f2081800072x871100793(V);
V g_list_2emap_24f2081800072x871100793_entry(V self, V *a);
extern Clo g_list_2emap_24f2081800072x871100793_clo;
V g_list_2emap_24f768999161x1997188166(V, V, V);
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2emap_24s890213172x1049425163(V);
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s29557946x653938035(V, V);
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2ewords_2ewordsFrom_240(V, V, V, V);
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5, 42, "the text ends where more of it is expected");

HeffT3 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_acc_242);
      heff_drop(v_field_246);
      V v_p_247 = v_field_245;
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_p_247, MK_INT(0LL)}});
    } else {
      V v_x_248 = v_field_245;
      V v_j_249 = v_field_246;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_j_249, 1) && heff_intLt_c_lent(v_j_249, heff_arrayLength_lent(v_ts_240, 0), 2))) {
        V v_t_2410 = heff_arrayIndex_lent(v_ts_240, v_j_249, 0);
        V v_kind_2411 = heff_take_field(v_t_2410, 0);
        V v_text_2412 = heff_take_field(v_t_2410, 1);
        V v_start_2413 = heff_get_n(v_t_2410, 2, 7);
        if ((heff_strEq_c_lent(v_kind_2411, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0), 2) && heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1), 2))) {
          heff_drop(v_kind_2411);
          heff_drop(v_text_2412);
          heff_drop(v_start_2413);
          V t_0 = v_ts_240;
          V t_1 = heff_box_word((heff_unbox_word(v_j_249) + ((int64_t)1ULL)));
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_acc_242});
          v_ts_240 = t_0;
          v_i_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          if ((heff_strEq_c_lent(v_kind_2411, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2), 2) && heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3), 2))) {
            heff_drop(v_kind_2411);
            heff_drop(v_text_2412);
            heff_drop(v_start_2413);
            V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_acc_242})));
            int64_t v_f_2415 = (heff_unbox_word(v_j_249) + ((int64_t)1ULL));
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2414, heff_box_word(v_f_2415)}});
          } else {
            heff_drop(v_acc_242);
            heff_drop(v_x_248);
            heff_drop(v_j_249);
            heff_drop(v_kind_2411);
            heff_drop(v_text_2412);
            V v_f_2416 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2413, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4)});
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2416, MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_acc_242);
        heff_drop(v_x_248);
        heff_drop(v_j_249);
        int64_t v_i_2417 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
        V v_t_2419;
        if (((((int64_t)0ULL) <= v_i_2417) && (v_i_2417 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
          V v_t_2418 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_2417), 2);
          v_t_2419 = heff_get_n(v_t_2418, 2, 7);
        } else {
          v_t_2419 = MK_INT(0LL);
        }
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5)}), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1, 23, "expected a field's name");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4, 12, "expected `=`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8, 1, "}");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12, 42, "the text ends where more of it is expected");

HeffT3 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V v_ts_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if (((((int64_t)0ULL) <= v_i_241) && (v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_name_243 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_241), 2);
    V v_kind_244 = heff_take_field(v_name_243, 0);
    V v_start_245 = heff_take_field(v_name_243, 2);
    V v_text_246 = heff_get_n(v_name_243, 1, 7);
    if (!heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0), 2)) {
      heff_drop(v_acc_242);
      heff_drop(v_kind_244);
      heff_drop(v_text_246);
      V v_f_247 = heff_rec_n(2, shape_at__msg, (V[]){v_start_245, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1)});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_247, MK_INT(0LL)}});
    } else {
      heff_drop(v_kind_244);
      heff_drop(v_start_245);
      int64_t v_i_248 = (v_i_241 + ((int64_t)1ULL));
      if (((((int64_t)0ULL) <= v_i_248) && (v_i_248 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
        V v_eq_249 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_248), 2);
        V v_kind_2410 = heff_take_field(v_eq_249, 0);
        V v_text_2411 = heff_take_field(v_eq_249, 1);
        V v_start_2412 = heff_get_n(v_eq_249, 2, 7);
        if ((heff_strEq_c_lent(v_kind_2410, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2), 2) ? !heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3), 2) : 1)) {
          heff_drop(v_acc_242);
          heff_drop(v_text_246);
          heff_drop(v_kind_2410);
          heff_drop(v_text_2411);
          V v_f_2413 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2412, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4)});
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2413, MK_INT(0LL)}});
        } else {
          heff_drop(v_kind_2410);
          heff_drop(v_text_2411);
          heff_drop(v_start_2412);
          HeffT3 v_t_2414 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, heff_box_word((v_i_241 + ((int64_t)2ULL)))));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              heff_drop(v_acc_242);
              heff_drop(v_text_246);
              heff_drop(v_field_2417);
              V v_p_2418 = v_field_2416;
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_p_2418, MK_INT(0LL)}});
            } else {
              V v_x_2419 = v_field_2416;
              V v_j_2420 = v_field_2417;
              if ((heff_intLe_c_lent(MK_INT(0LL), v_j_2420, 1) && heff_intLt_c_lent(v_j_2420, heff_arrayLength_lent(v_ts_240, 0), 2))) {
                V v_t_2421 = heff_arrayIndex_lent(v_ts_240, v_j_2420, 0);
                V v_kind_2422 = heff_take_field(v_t_2421, 0);
                V v_text_2423 = heff_take_field(v_t_2421, 1);
                V v_start_2424 = heff_get_n(v_t_2421, 2, 7);
                if ((heff_strEq_c_lent(v_kind_2422, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5), 2) && heff_strEq_c_lent(v_text_2423, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6), 2))) {
                  heff_drop(v_kind_2422);
                  heff_drop(v_text_2423);
                  heff_drop(v_start_2424);
                  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_text_246, v_x_2419}), v_acc_242});
                  V t_0 = v_ts_240;
                  int64_t t_1 = (heff_unbox_word(v_j_2420) + ((int64_t)1ULL));
                  V t_2 = v_t_2425;
                  v_ts_240 = t_0;
                  v_i_241 = t_1;
                  v_acc_242 = t_2;
                  goto top;
                } else {
                  if ((heff_strEq_c_lent(v_kind_2422, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7), 2) && heff_strEq_c_lent(v_text_2423, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8), 2))) {
                    heff_drop(v_kind_2422);
                    heff_drop(v_text_2423);
                    heff_drop(v_start_2424);
                    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_text_246, v_x_2419}), NTAG(TAG_Nil)});
                    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(v_t_2426, v_acc_242));
                    int64_t v_f_2428 = (heff_unbox_word(v_j_2420) + ((int64_t)1ULL));
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2427, heff_box_word(v_f_2428)}});
                  } else {
                    heff_drop(v_acc_242);
                    heff_drop(v_text_246);
                    heff_drop(v_x_2419);
                    heff_drop(v_j_2420);
                    heff_drop(v_kind_2422);
                    heff_drop(v_text_2423);
                    V v_f_2429 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2424, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9)});
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2429, MK_INT(0LL)}});
                  }
                }
              } else {
                heff_drop(v_acc_242);
                heff_drop(v_text_246);
                heff_drop(v_x_2419);
                heff_drop(v_j_2420);
                int64_t v_i_2430 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
                V v_t_2432;
                if (((((int64_t)0ULL) <= v_i_2430) && (v_i_2430 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
                  V v_t_2431 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_2430), 2);
                  v_t_2432 = heff_get_n(v_t_2431, 2, 7);
                } else {
                  v_t_2432 = MK_INT(0LL);
                }
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2432, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10)}), MK_INT(0LL)}});
              }
            }
          }
        }
      } else {
        heff_drop(v_acc_242);
        heff_drop(v_text_246);
        int64_t v_i_2433 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
        V v_t_2435;
        if (((((int64_t)0ULL) <= v_i_2433) && (v_i_2433 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
          V v_t_2434 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_2433), 2);
          v_t_2435 = heff_get_n(v_t_2434, 2, 7);
        } else {
          v_t_2435 = MK_INT(0LL);
        }
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2435, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11)}), MK_INT(0LL)}});
      }
    }
  } else {
    heff_drop(v_acc_242);
    int64_t v_i_2436 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2438;
    if (((((int64_t)0ULL) <= v_i_2436) && (v_i_2436 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
      V v_t_2437 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_2436), 2);
      v_t_2438 = heff_get_n(v_t_2437, 2, 7);
    } else {
      v_t_2438 = MK_INT(0LL);
    }
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12)}), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3, 1, "[");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8, 1, "{");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10, 42, "the text ends where more of it is expected");

HeffT3 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V v_ts_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if (((((int64_t)0ULL) <= v_i_241) && (v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_242 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_241), 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0))) {
      V v_f_243 = heff_tag_n(TAG_LStr, 2, (V[]){heff_dup(heff_rfield(v_t_242, 1)), v_t_242});
      int64_t v_f_244 = (v_i_241 + ((int64_t)1ULL));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_243, heff_box_word(v_f_244)}});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1))) {
        V v_f_245 = heff_tag_n(TAG_LTag, 2, (V[]){heff_dup(heff_rfield(v_t_242, 1)), v_t_242});
        int64_t v_f_246 = (v_i_241 + ((int64_t)1ULL));
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_245, heff_box_word(v_f_246)}});
      } else {
        if ((heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_t_242, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3)))) {
          int64_t v_i_247 = (v_i_241 + ((int64_t)1ULL));
          if (((((int64_t)0ULL) <= v_i_247) && (v_i_247 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
            V v_next_248 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_247), 2);
            V v_kind_249 = heff_take_field(v_next_248, 0);
            V v_text_2410 = heff_get_n(v_next_248, 1, 7);
            if ((heff_strEq_c_lent(v_kind_249, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4), 2) && heff_strEq_c_lent(v_text_2410, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5), 2))) {
              heff_drop(v_kind_249);
              heff_drop(v_text_2410);
              int64_t v_f_2411 = (v_i_241 + ((int64_t)2ULL));
              V v_t_2412 = heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_242});
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2412, heff_box_word(v_f_2411)}});
            } else {
              heff_drop(v_kind_249);
              heff_drop(v_text_2410);
              HeffT3 v_t_2413 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(v_ts_240, heff_box_word((v_i_241 + ((int64_t)1ULL))), NTAG(TAG_Nil)));
              {
                V v_field_2415 = v_t_2413.f[1];
                V v_field_2416 = v_t_2413.f[2];
                int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_242, 7);
                  heff_drop(v_field_2416);
                  V v_p_2417 = v_field_2415;
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_p_2417, MK_INT(0LL)}});
                } else {
                  V v_xs_2418 = v_field_2415;
                  V v_j_2419 = v_field_2416;
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_LList, 2, (V[]){v_xs_2418, v_t_242}), v_j_2419}});
                }
              }
            }
          } else {
            heff_drop_rec(v_t_242, 7);
            int64_t v_i_2420 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
            V v_t_2422;
            if (((((int64_t)0ULL) <= v_i_2420) && (v_i_2420 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
              V v_t_2421 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_2420), 2);
              v_t_2422 = heff_get_n(v_t_2421, 2, 7);
            } else {
              v_t_2422 = MK_INT(0LL);
            }
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6)}), MK_INT(0LL)}});
          }
        } else {
          if ((heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7)) && heff_strEq_c(heff_dup(heff_rfield(v_t_242, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8)))) {
            HeffT3 v_t_2423 = (g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(v_ts_240, heff_box_word((v_i_241 + ((int64_t)1ULL))), NTAG(TAG_Nil)));
            {
              V v_field_2425 = v_t_2423.f[1];
              V v_field_2426 = v_t_2423.f[2];
              int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
              if ((v_tag_2424 == ((int64_t)0ULL))) {
                heff_drop_rec(v_t_242, 7);
                heff_drop(v_field_2426);
                V v_p_2427 = v_field_2425;
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_p_2427, MK_INT(0LL)}});
              } else {
                V v_fs_2428 = v_field_2425;
                V v_j_2429 = v_field_2426;
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_LRec, 2, (V[]){v_fs_2428, v_t_242}), v_j_2429}});
              }
            }
          } else {
            V v_f_2430 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_242, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9)});
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2430, MK_INT(0LL)}});
          }
        }
      }
    }
  } else {
    int64_t v_i_2431 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2433;
    if (((((int64_t)0ULL) <= v_i_2431) && (v_i_2431 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
      V v_t_2432 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_2431), 2);
      v_t_2433 = heff_get_n(v_t_2432, 2, 7);
    } else {
      v_t_2433 = MK_INT(0LL);
    }
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2433, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10)}), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str1, 1, ".");

HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V v_v_240) {
top: ;
  V v_it_241 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str1), v_v_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT5){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_a_242);
      return ((HeffT5){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_a_242);
        heff_drop(v_b_244);
        return ((HeffT5){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_c_246 = heff_field(v_it22_245, 0);
        V v_it222_247 = heff_field(v_it22_245, 1);
        heff_take_n(v_it22_245, 3ULL, 2);
        switch (heff_tag_of(v_it222_247)) {
        case TAG_Nil: {
          if ((((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_a_242, 0))) && ({ V v_t_248 = (g_list_2emap_24f768999161x1997188166(v_a_242, MK_INT(0LL), heff_strLength_lent(v_a_242, 0))); int c_ = ({ V v_c_2428 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_248)); int c_ = ((heff_dup(v_c_2428) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_a_242, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_a_242, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_2428); c_; }); heff_drop(v_t_248); c_; })) && (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_b_244, 0))) && ({ V v_t_249 = (g_list_2emap_24f768999161x1997188166(v_b_244, MK_INT(0LL), heff_strLength_lent(v_b_244, 0))); int c_ = ({ V v_c_2429 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_249)); int c_ = ((heff_dup(v_c_2429) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_b_244, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_b_244, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_2429); c_; }); heff_drop(v_t_249); c_; })) && ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_c_246, 0))) && ({ V v_t_2410 = (g_list_2emap_24f768999161x1997188166(v_c_246, MK_INT(0LL), heff_strLength_lent(v_c_246, 0))); int c_ = ({ V v_c_2430 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_2410)); int c_ = ((heff_dup(v_c_2430) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_c_246, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_c_246, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_2430); c_; }); heff_drop(v_t_2410); c_; }))))) {
            HeffT2 v_t_2411 = ({ V a_0 = v_a_242; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_a_242); r_; });
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              V v_t_2415;
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                V v_a_2414 = v_field_2413;
                v_t_2415 = v_a_2414;
              } else {
                heff_drop(v_field_2413);
                v_t_2415 = MK_INT(0LL);
              }
              HeffT2 v_t_2416 = ({ V a_0 = v_b_244; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_b_244); r_; });
              {
                V v_field_2418 = v_t_2416.f[1];
                int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                V v_t_2420;
                if ((v_tag_2417 == ((int64_t)0ULL))) {
                  V v_a_2419 = v_field_2418;
                  v_t_2420 = v_a_2419;
                } else {
                  heff_drop(v_field_2418);
                  v_t_2420 = MK_INT(0LL);
                }
                HeffT2 v_t_2421 = ({ V a_0 = v_c_246; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_c_246); r_; });
                {
                  V v_field_2423 = v_t_2421.f[1];
                  int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                  V v_t_2425;
                  if ((v_tag_2422 == ((int64_t)0ULL))) {
                    V v_a_2424 = v_field_2423;
                    v_t_2425 = v_a_2424;
                  } else {
                    heff_drop(v_field_2423);
                    v_t_2425 = MK_INT(0LL);
                  }
                  return ((HeffT5){{heff_word_i64(((int64_t)0ULL)), v_t_2415, v_t_2420, v_t_2425, NTAG(TAG_Nil)}});
                }
              }
            }
          } else {
            heff_drop(v_a_242);
            heff_drop(v_b_244);
            heff_drop(v_c_246);
            return ((HeffT5){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_247, 0ULL, 2);
          heff_drop(v_a_242);
          heff_drop(v_b_244);
          heff_drop(v_c_246);
          return ((HeffT5){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
        }
        default: return ((HeffT5){{heff_nomatch(v_it222_247)}});
        }
      }
      default: return ((HeffT5){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT5){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT5){{heff_nomatch(v_it_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str1, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str2, 1, "-");

HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    HeffT5 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
    {
      V v_field_244 = v_t_242.f[1];
      V v_field_245 = v_t_242.f[2];
      V v_field_246 = v_t_242.f[3];
      V v_field_247 = v_t_242.f[4];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      V v_t_2410;
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_245, heff_tag_n(TAG_Cons, 2, (V[]){v_field_246, v_field_247})});
        V v_x_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_244, v_t_248});
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_244);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        v_t_2410 = NTAG(TAG_Nil);
      }
      return ((HeffT2){{v_t_2410, ((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str0)}});
    }
  }
  case TAG_Just: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_time_2412 = heff_field(v_x21_2411, 0);
      V v_commit_2413 = heff_field(v_x21_2411, 1);
      V v_t_2414 = heff_strSlice_lent(v_v_240, MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str1), v_v_240, MK_INT(0LL), 5), 6);
      HeffT5 v_t_2415 = ({ V a_0 = v_t_2414; HeffT5 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2414); r_; });
      {
        V v_field_2417 = v_t_2415.f[1];
        V v_field_2418 = v_t_2415.f[2];
        V v_field_2419 = v_t_2415.f[3];
        V v_field_2420 = v_t_2415.f[4];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_t_2423;
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_field_2419, v_field_2420})});
          V v_x_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2417, v_t_2421});
          v_t_2423 = v_x_2422;
        } else {
          heff_drop(v_field_2417);
          heff_drop(v_field_2418);
          heff_drop(v_field_2419);
          heff_drop(v_field_2420);
          v_t_2423 = NTAG(TAG_Nil);
        }
        V v_f_2424 = heff_strAppend(heff_strAppend(heff_dup(v_time_2412), ((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str2)), heff_dup(v_commit_2413));
        return ((HeffT2){{v_t_2423, v_f_2424}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_2411)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eisMajorPart_str0, 1, "v");
Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisMajorPart_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisMajorPart(V v_x_240) {
top: ;
  if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if (heff_strEq_c(heff_strSlice_lent(v_x_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ebuild_2eproject_2eisMajorPart_str0))) {
      V v_s_241 = heff_strSlice_lent(v_x_240, MK_INT(1LL), heff_strLength_lent(v_x_240, 0), 6);
      V v_ret_24bool = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_241, 0))) && ({ V v_t_242 = (g_list_2emap_24f768999161x1997188166(v_s_241, MK_INT(0LL), heff_strLength_lent(v_s_241, 0))); int c_ = ({ V v_c_243 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_242)); int c_ = ((heff_dup(v_c_243) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_s_241, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_s_241, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_243); c_; }); heff_drop(v_t_242); c_; })));
      heff_drop(v_s_241);
      return v_ret_24bool;
    } else {
      return NTAG(TAG_False);
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eisMajorPart(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str0, 43, "the project's tests are the modules under `");
HEFF_LIT(g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str1, 1, "`");

HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V v_x_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) == ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
  } else {
    if (((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL)) : 1)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
    } else {
      V v_t_241 = (g_list_2emap_24f768999161x1997188166(v_x_240, MK_INT(0LL), heff_strLength_lent(v_x_240, 0)));
      V v_x1_242 = ({ V a_0 = v_t_241; V r_ = (g_list_2eall_24s494596359x1928238377(a_0)); heff_drop(v_t_241); r_; });
      if (!(heff_dup(v_x1_242) == NTAG(TAG_True))) {
        heff_drop(v_x1_242);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
      } else {
        heff_drop(v_x1_242);
        if (heff_strEq_c(heff_dup(v_x_240), heff_dup(g_heff_2ebuild_2eproject_2etestsModule_get()))) {
          V v_f_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str0), heff_dup(g_heff_2ebuild_2eproject_2etestsModule_get())), ((V)&g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str1));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
        } else {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eproject_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2eproject_2eandList_str1)), heff_dup(v_y_245));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2eproject_2eandList_str2));
        return (g_heff_2ebuild_2eproject_2eandList_24acc(v_x12_242, v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_24acc_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_243)) {
        case TAG_Cons: {
          V v_y_246 = heff_field(v_x12_243, 0);
          V v_t_248 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str1));
          return heff_strAppend(v_t_248, heff_dup(v_y_246));
        }
        default: return heff_nomatch(v_x12_243);
        }
      }
      case TAG_Cons: {
        V v_s_2411 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2411;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_left_243 = heff_take_field(v_f_241, 1);
    V v_name_244 = heff_get_n(v_f_241, 0, 2);
    V v_t_245 = v_left_243;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_245, 0ULL, 1);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_244, heff_hole()});
      V v_u_248 = (g_heff_2ebuild_2eproject_2eleftOutNames_24dps(v_rest_242, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_left_244 = heff_take_field(v_f_242, 1);
    V v_name_245 = heff_get_n(v_f_242, 0, 2);
    V v_t_246 = v_left_244;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_245, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
      V t_0 = v_rest_243;
      V t_1 = v_u_249;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2eleftOutNames_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str6, 2, " (");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str7, 17, " may be left out)");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str8, 15, "the fields are ");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str9, 15, ", in this order");

HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V v_fields_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x_241)) {
  case TAG_LStr: {
    heff_drop(v_fields_240);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_245 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_245);
      break;
    }
    case TAG_LTag: {
      V v_t_247 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_247);
      break;
    }
    case TAG_LList: {
      V v_t_249 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_249);
      break;
    }
    case TAG_LRec: {
      V v_t_2411 = heff_field(v_x_241, 1);
      v_t_2412 = heff_dup(v_t_2411);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2413 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
  }
  case TAG_LTag: {
    heff_drop(v_fields_240);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2417 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2417);
      break;
    }
    case TAG_LTag: {
      V v_t_2419 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2419);
      break;
    }
    case TAG_LList: {
      V v_t_2421 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2421);
      break;
    }
    case TAG_LRec: {
      V v_t_2423 = heff_field(v_x_241, 1);
      v_t_2424 = heff_dup(v_t_2423);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
  }
  case TAG_LList: {
    heff_drop(v_fields_240);
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2429 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2429);
      break;
    }
    case TAG_LTag: {
      V v_t_2431 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2431);
      break;
    }
    case TAG_LList: {
      V v_t_2433 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2433);
      break;
    }
    case TAG_LRec: {
      V v_t_2435 = heff_field(v_x_241, 1);
      v_t_2436 = heff_dup(v_t_2435);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2437 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
  }
  case TAG_LRec: {
    V v_fs_2438 = heff_field(v_x_241, 0);
    V v_t_2439 = heff_field(v_x_241, 1);
    HeffT2 v_t_2440 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(heff_dup(v_t_2439), heff_dup(v_fields_240), heff_dup(v_fs_2438)));
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        heff_drop(v_fields_240);
        V v_xs_2443 = v_field_2442;
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_xs_2443}});
      } else {
        heff_drop(v_field_2442);
        V v_fields_2444 = v_fields_240;
        V v_x2_2445 = (g_list_2emap_24s890213172x1049425163(heff_dup(v_fields_2444)));
        V v_t_2448;
        switch (heff_tag_of(v_x2_2445)) {
        case TAG_Nil: {
          v_t_2448 = ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str3);
          break;
        }
        case TAG_Cons: {
          V v_x_2446 = heff_field(v_x2_2445, 0);
          V v_xs_2447 = heff_field(v_x2_2445, 1);
          heff_take_n(v_x2_2445, 3ULL, 2);
          v_t_2448 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str4); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2445);
        }
        V v_x1_2449 = (g_heff_2ebuild_2eproject_2eleftOutNames(heff_dup(v_fields_2444)));
        V v_t_2454;
        switch (heff_tag_of(v_x1_2449)) {
        case TAG_Nil: {
          heff_drop(v_fields_2444);
          v_t_2454 = ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str5);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2449, 0ULL, 2);
          V v_t_2452 = (g_heff_2ebuild_2eproject_2eleftOutNames(v_fields_2444));
          V v_t_2453 = ({ V a_0 = v_t_2452; V r_ = (g_heff_2ebuild_2eproject_2eandList(a_0)); heff_drop(v_t_2452); r_; });
          v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str6), v_t_2453), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str7));
          break;
        }
        default: heff_nomatch(v_x1_2449);
        }
        V v_t_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str8), v_t_2448), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str9));
        V v_msg_2456 = heff_strAppend(v_t_2455, v_t_2454);
        V v_f_2457 = heff_rec_n(2, shape_at__msg, (V[]){heff_dup(heff_rfield(v_t_2439, 2)), v_msg_2456});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2457}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str0, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str1, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str2, 23, "expected a list `[...]`");

HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_244);
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_246);
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_248);
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2411 = heff_dup(v_t_2410);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
  }
  case TAG_LTag: {
    V v_t_2423;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2416 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2416);
      break;
    }
    case TAG_LTag: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LList: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LRec: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2423 = heff_dup(v_t_2422);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
  }
  case TAG_LList: {
    V v_xs_2425 = heff_field(v_x_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_dup(v_xs_2425)}});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2438}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1, 4, "path");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2, 7, "version");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str7, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str8, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str9, 45, "` is no version: write `a.b.c`, three numbers");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str10, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2), NTAG(TAG_Nothing)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244})});
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(v_t_245, v_x_240));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_p_249 = v_field_248;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_249}});
    } else {
      V v_it1_2410 = v_field_248;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_Nil: {
        V v_t_2419;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2412 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2412);
          break;
        }
        case TAG_LTag: {
          V v_t_2414 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2414);
          break;
        }
        case TAG_LList: {
          V v_t_2416 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2416);
          break;
        }
        case TAG_LRec: {
          V v_t_2418 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2418);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2419, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
      }
      case TAG_Cons: {
        V v_n_2421 = heff_field(v_it1_2410, 0);
        V v_it12_2422 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        switch (heff_tag_of(v_it12_2422)) {
        case TAG_Nil: {
          heff_drop(v_n_2421);
          V v_t_2431;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2424 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2424);
            break;
          }
          case TAG_LTag: {
            V v_t_2426 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2426);
            break;
          }
          case TAG_LList: {
            V v_t_2428 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2428);
            break;
          }
          case TAG_LRec: {
            V v_t_2430 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2430);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2432 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2431, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
        }
        case TAG_Cons: {
          V v_p_2433 = heff_field(v_it12_2422, 0);
          V v_it122_2434 = heff_field(v_it12_2422, 1);
          heff_take_n(v_it12_2422, 3ULL, 2);
          switch (heff_tag_of(v_it122_2434)) {
          case TAG_Nil: {
            heff_drop(v_n_2421);
            heff_drop(v_p_2433);
            V v_t_2443;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2436 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2436);
              break;
            }
            case TAG_LTag: {
              V v_t_2438 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2438);
              break;
            }
            case TAG_LList: {
              V v_t_2440 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2440);
              break;
            }
            case TAG_LRec: {
              V v_t_2442 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2442);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2444 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2443, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2444}});
          }
          case TAG_Cons: {
            V v_v_2445 = heff_field(v_it122_2434, 0);
            V v_it1222_2446 = heff_field(v_it122_2434, 1);
            heff_take_n(v_it122_2434, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2446)) {
            case TAG_Nil: {
              HeffT2 v_t_2447 = ({ V a_0 = v_n_2421; HeffT2 r_ = (g_heff_2ebuild_2eproject_2enameOf_24cpr(a_0)); heff_drop(v_n_2421); r_; });
              {
                V v_field_2449 = v_t_2447.f[1];
                int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                if ((v_tag_2448 == ((int64_t)0ULL))) {
                  heff_drop(v_p_2433);
                  heff_drop(v_v_2445);
                  V v_e_2450 = v_field_2449;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2450}});
                } else {
                  V v_name_2451 = v_field_2449;
                  V v_x_2452 = v_v_2445;
                  HeffT2 v_t_2453 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_x_2452));
                  {
                    V v_field_2455 = v_t_2453.f[1];
                    int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                    V v_t_2478;
                    if ((v_tag_2454 == ((int64_t)0ULL))) {
                      heff_drop(v_x_2452);
                      V v_p_2456 = v_field_2455;
                      v_t_2478 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2456});
                    } else {
                      V v_v_2457 = v_field_2455;
                      V v_t_2458 = ({ V a_0 = v_v_2457; V b_1 = ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str7), v_v_2457, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
                      V v_t_2459 = ({ V a_0 = v_t_2458; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_2458); r_; });
                      HeffT2 v_t_2460 = ({ V a_0 = v_v_2457; V a_1 = v_t_2459; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_2459); r_; });
                      {
                        V v_field_2461 = v_t_2460.f[0];
                        V v_field_2462 = v_t_2460.f[1];
                        V v_x_2463 = v_field_2461;
                        V v_y_2464 = v_field_2462;
                        heff_drop(v_y_2464);
                        V v_t_2465 = v_x_2463;
                        V v_t_2466 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2465; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2465); r_; });
                        if (heff_intEq_c(v_t_2466, MK_INT(3LL))) {
                          heff_drop(v_x_2452);
                          v_t_2478 = heff_tag_n(TAG_Right, 1, (V[]){v_v_2457});
                        } else {
                          V v_t_2475;
                          switch (heff_tag_of(v_x_2452)) {
                          case TAG_LStr: {
                            V v_t_2468 = heff_field(v_x_2452, 1);
                            heff_take_n(v_x_2452, 2ULL, 2);
                            v_t_2475 = v_t_2468;
                            break;
                          }
                          case TAG_LTag: {
                            V v_t_2470 = heff_field(v_x_2452, 1);
                            heff_take_n(v_x_2452, 2ULL, 2);
                            v_t_2475 = v_t_2470;
                            break;
                          }
                          case TAG_LList: {
                            V v_t_2472 = heff_field(v_x_2452, 1);
                            heff_take_n(v_x_2452, 2ULL, 2);
                            v_t_2475 = v_t_2472;
                            break;
                          }
                          case TAG_LRec: {
                            V v_t_2474 = heff_field(v_x_2452, 1);
                            heff_take_n(v_x_2452, 2ULL, 2);
                            v_t_2475 = v_t_2474;
                            break;
                          }
                          default: heff_nomatch(v_x_2452);
                          }
                          V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str8), v_v_2457), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str9));
                          V v_t_2477 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2475, 2, 7), v_t_2476});
                          v_t_2478 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2477});
                        }
                      }
                    }
                    switch (heff_tag_of(v_t_2478)) {
                    case TAG_Left: {
                      V v_e_2479 = heff_field(v_t_2478, 0);
                      heff_take_n(v_t_2478, 1ULL, 1);
                      heff_drop(v_p_2433);
                      heff_drop(v_name_2451);
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2479}});
                    }
                    case TAG_Right: {
                      V v_ver_2480 = heff_field(v_t_2478, 0);
                      heff_take_n(v_t_2478, 1ULL, 1);
                      HeffT2 v_t_2481 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_p_2433));
                      {
                        V v_field_2483 = v_t_2481.f[1];
                        int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
                        if ((v_tag_2482 == ((int64_t)0ULL))) {
                          heff_drop(v_p_2433);
                          heff_drop(v_name_2451);
                          heff_drop(v_ver_2480);
                          V v_p_2484 = v_field_2483;
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2484}});
                        } else {
                          V v_path_2485 = v_field_2483;
                          HeffT2 v_t_2486 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_2485), heff_dup(v_ver_2480)));
                          {
                            V v_field_2488 = v_t_2486.f[1];
                            int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                            if ((v_tag_2487 == ((int64_t)0ULL))) {
                              heff_drop(v_name_2451);
                              heff_drop(v_ver_2480);
                              heff_drop(v_path_2485);
                              V v_why_2489 = v_field_2488;
                              V v_t_2498;
                              switch (heff_tag_of(v_p_2433)) {
                              case TAG_LStr: {
                                V v_t_2491 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2498 = v_t_2491;
                                break;
                              }
                              case TAG_LTag: {
                                V v_t_2493 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2498 = v_t_2493;
                                break;
                              }
                              case TAG_LList: {
                                V v_t_2495 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2498 = v_t_2495;
                                break;
                              }
                              case TAG_LRec: {
                                V v_t_2497 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2498 = v_t_2497;
                                break;
                              }
                              default: heff_nomatch(v_p_2433);
                              }
                              V v_f_2499 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2498, 2, 7), v_why_2489});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2499}});
                            } else {
                              heff_drop(v_p_2433);
                              heff_drop(v_field_2488);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__path__version, (V[]){v_name_2451, v_path_2485, v_ver_2480})}});
                            }
                          }
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_t_2478)}});
                    }
                  }
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_it1222_2446, 0ULL, 2);
              heff_drop(v_n_2421);
              heff_drop(v_p_2433);
              heff_drop(v_v_2445);
              V v_t_24110;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_24103 = heff_field(v_x_240, 1);
                v_t_24110 = heff_dup(v_t_24103);
                break;
              }
              case TAG_LTag: {
                V v_t_24105 = heff_field(v_x_240, 1);
                v_t_24110 = heff_dup(v_t_24105);
                break;
              }
              case TAG_LList: {
                V v_t_24107 = heff_field(v_x_240, 1);
                v_t_24110 = heff_dup(v_t_24107);
                break;
              }
              case TAG_LRec: {
                V v_t_24109 = heff_field(v_x_240, 1);
                v_t_24110 = heff_dup(v_t_24109);
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_f_24111 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24110, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str10)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24111}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it1222_2446)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2434)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2422)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2410)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      V v_t_246 = (g_list_2eany_24s1006624359x760861690(v_n_244, v_names_240));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_246);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_n_244), heff_dup(v_x_245)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eclaimMsg_str0, 143, "error[E0347]: the package `heff` is heff's own, and this is not the checkout heff is built in or was installed from: name the project otherwise");

static V g_heff_2ebuild_2eproject_2eclaimMsg_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2eclaimMsg_st;
static V g_heff_2ebuild_2eproject_2eclaimMsg_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2eclaimMsg_str0);
}
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2eclaimMsg_st)) return g_heff_2ebuild_2eproject_2eclaimMsg_val;
  return heff_global(&g_heff_2ebuild_2eproject_2eclaimMsg_val, &g_heff_2ebuild_2eproject_2eclaimMsg_st, g_heff_2ebuild_2eproject_2eclaimMsg_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1, 19, "` is required twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3, 19, "` is replaced twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5, 31, "` is replaced, but not required");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str6, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str7, 78, "` is the package `heff`, heff's own, which comes with heff: it is not replaced");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str8, 14, "error[E0347]: ");

HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s634456687x1151454243(heff_dup(v_rxs_240), heff_dup(v_rs_241)));
  HeffT3 v_t_245 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_rxs_240);
      heff_drop(v_rs_241);
      heff_drop(v_pxs_242);
      heff_drop(v_ps_243);
      V v_n_249 = v_field_247;
      V v_x_2410 = v_field_248;
      V v_t_2419;
      switch (heff_tag_of(v_x_2410)) {
      case TAG_LStr: {
        V v_t_2412 = heff_field(v_x_2410, 1);
        heff_take_n(v_x_2410, 2ULL, 2);
        v_t_2419 = v_t_2412;
        break;
      }
      case TAG_LTag: {
        V v_t_2414 = heff_field(v_x_2410, 1);
        heff_take_n(v_x_2410, 2ULL, 2);
        v_t_2419 = v_t_2414;
        break;
      }
      case TAG_LList: {
        V v_t_2416 = heff_field(v_x_2410, 1);
        heff_take_n(v_x_2410, 2ULL, 2);
        v_t_2419 = v_t_2416;
        break;
      }
      case TAG_LRec: {
        V v_t_2418 = heff_field(v_x_2410, 1);
        heff_take_n(v_x_2410, 2ULL, 2);
        v_t_2419 = v_t_2418;
        break;
      }
      default: heff_nomatch(v_x_2410);
      }
      V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0), v_n_249), ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1));
      V v_f_2421 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2419, 2, 7), v_t_2420});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
    } else {
      heff_drop(v_field_247);
      heff_drop(v_field_248);
      V v_t_2422 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
      HeffT3 v_t_2423 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_2422));
      {
        V v_field_2425 = v_t_2423.f[1];
        V v_field_2426 = v_t_2423.f[2];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          heff_drop(v_rxs_240);
          heff_drop(v_rs_241);
          heff_drop(v_pxs_242);
          heff_drop(v_ps_243);
          V v_n_2427 = v_field_2425;
          V v_x_2428 = v_field_2426;
          V v_t_2437;
          switch (heff_tag_of(v_x_2428)) {
          case TAG_LStr: {
            V v_t_2430 = heff_field(v_x_2428, 1);
            heff_take_n(v_x_2428, 2ULL, 2);
            v_t_2437 = v_t_2430;
            break;
          }
          case TAG_LTag: {
            V v_t_2432 = heff_field(v_x_2428, 1);
            heff_take_n(v_x_2428, 2ULL, 2);
            v_t_2437 = v_t_2432;
            break;
          }
          case TAG_LList: {
            V v_t_2434 = heff_field(v_x_2428, 1);
            heff_take_n(v_x_2428, 2ULL, 2);
            v_t_2437 = v_t_2434;
            break;
          }
          case TAG_LRec: {
            V v_t_2436 = heff_field(v_x_2428, 1);
            heff_take_n(v_x_2428, 2ULL, 2);
            v_t_2437 = v_t_2436;
            break;
          }
          default: heff_nomatch(v_x_2428);
          }
          V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2), v_n_2427), ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3));
          V v_f_2439 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), v_t_2438});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2439}});
        } else {
          heff_drop(v_field_2425);
          heff_drop(v_field_2426);
          V v_t_2440 = (g_list_2emap_24s1791433880x1360378684(heff_dup(v_rs_241)));
          V v_t_2441 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
          HeffT3 v_t_2442 = ({ V a_0 = v_t_2440; V a_1 = v_t_2441; HeffT3 r_ = (g_heff_2ebuild_2eproject_2eunrequired_24cpr(a_0, a_1)); heff_drop(v_t_2440); heff_drop(v_t_2441); r_; });
          {
            V v_field_2444 = v_t_2442.f[1];
            V v_field_2445 = v_t_2442.f[2];
            int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
            if ((v_tag_2443 == ((int64_t)0ULL))) {
              heff_drop(v_rxs_240);
              heff_drop(v_rs_241);
              heff_drop(v_pxs_242);
              heff_drop(v_ps_243);
              V v_n_2446 = v_field_2444;
              V v_x_2447 = v_field_2445;
              V v_t_2456;
              switch (heff_tag_of(v_x_2447)) {
              case TAG_LStr: {
                V v_t_2449 = heff_field(v_x_2447, 1);
                heff_take_n(v_x_2447, 2ULL, 2);
                v_t_2456 = v_t_2449;
                break;
              }
              case TAG_LTag: {
                V v_t_2451 = heff_field(v_x_2447, 1);
                heff_take_n(v_x_2447, 2ULL, 2);
                v_t_2456 = v_t_2451;
                break;
              }
              case TAG_LList: {
                V v_t_2453 = heff_field(v_x_2447, 1);
                heff_take_n(v_x_2447, 2ULL, 2);
                v_t_2456 = v_t_2453;
                break;
              }
              case TAG_LRec: {
                V v_t_2455 = heff_field(v_x_2447, 1);
                heff_take_n(v_x_2447, 2ULL, 2);
                v_t_2456 = v_t_2455;
                break;
              }
              default: heff_nomatch(v_x_2447);
              }
              V v_t_2457 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4), v_n_2446), ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5));
              V v_f_2458 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2456, 2, 7), v_t_2457});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2458}});
            } else {
              heff_drop(v_field_2444);
              heff_drop(v_field_2445);
              V v_rxs_2459 = v_rxs_240;
              V v_rs_2460 = v_rs_241;
              V v_pxs_2461 = v_pxs_242;
              V v_ps_2462 = v_ps_243;
              V v_t_2463 = (g_list_2emap_24f2081800072x871100793(heff_dup(v_rs_2460)));
              V v_t_2464 = (g_list_2ezipWith_24s1958630276x749154843(v_pxs_2461, v_ps_2462));
              HeffT3 v_t_2465 = ({ V a_0 = v_t_2463; V a_1 = v_t_2464; HeffT3 r_ = (g_heff_2ebuild_2eproject_2efirstNamed_24cpr(a_0, a_1)); heff_drop(v_t_2463); heff_drop(v_t_2464); r_; });
              {
                V v_field_2467 = v_t_2465.f[1];
                V v_field_2468 = v_t_2465.f[2];
                int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                if ((v_tag_2466 == ((int64_t)0ULL))) {
                  heff_drop(v_rxs_2459);
                  heff_drop(v_rs_2460);
                  V v_n_2469 = v_field_2467;
                  V v_x_2470 = v_field_2468;
                  V v_t_2479;
                  switch (heff_tag_of(v_x_2470)) {
                  case TAG_LStr: {
                    V v_t_2472 = heff_field(v_x_2470, 1);
                    heff_take_n(v_x_2470, 2ULL, 2);
                    v_t_2479 = v_t_2472;
                    break;
                  }
                  case TAG_LTag: {
                    V v_t_2474 = heff_field(v_x_2470, 1);
                    heff_take_n(v_x_2470, 2ULL, 2);
                    v_t_2479 = v_t_2474;
                    break;
                  }
                  case TAG_LList: {
                    V v_t_2476 = heff_field(v_x_2470, 1);
                    heff_take_n(v_x_2470, 2ULL, 2);
                    v_t_2479 = v_t_2476;
                    break;
                  }
                  case TAG_LRec: {
                    V v_t_2478 = heff_field(v_x_2470, 1);
                    heff_take_n(v_x_2470, 2ULL, 2);
                    v_t_2479 = v_t_2478;
                    break;
                  }
                  default: heff_nomatch(v_x_2470);
                  }
                  V v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str6), v_n_2469), ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str7));
                  V v_f_2481 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2479, 2, 7), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str8), v_t_2480)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2481}});
                } else {
                  heff_drop(v_field_2467);
                  heff_drop(v_field_2468);
                  V v_t_2482 = (g_list_2ezipWith_24s29557946x653938035(v_rxs_2459, v_rs_2460));
                  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()), NTAG(TAG_Nil)});
                  HeffT3 v_t_2484 = ({ V a_0 = v_t_2483; V a_1 = v_t_2482; HeffT3 r_ = (g_heff_2ebuild_2eproject_2efirstNamed_24cpr(a_0, a_1)); heff_drop_tag(v_t_2483, 2); heff_drop(v_t_2482); r_; });
                  {
                    V v_field_2486 = v_t_2484.f[1];
                    V v_field_2487 = v_t_2484.f[2];
                    int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
                    if ((v_tag_2485 == ((int64_t)0ULL))) {
                      V v_it11_2488 = v_field_2486;
                      heff_drop(v_it11_2488);
                      V v_x_2489 = v_field_2487;
                      V v_t_2498;
                      switch (heff_tag_of(v_x_2489)) {
                      case TAG_LStr: {
                        V v_t_2491 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_2498 = v_t_2491;
                        break;
                      }
                      case TAG_LTag: {
                        V v_t_2493 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_2498 = v_t_2493;
                        break;
                      }
                      case TAG_LList: {
                        V v_t_2495 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_2498 = v_t_2495;
                        break;
                      }
                      case TAG_LRec: {
                        V v_t_2497 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_2498 = v_t_2497;
                        break;
                      }
                      default: heff_nomatch(v_x_2489);
                      }
                      V v_f_2499 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2498, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2499}});
                    } else {
                      heff_drop(v_field_2486);
                      heff_drop(v_field_2487);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str1, 3, "dir");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str4, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x_243 = v_x_241;
    V v_t_244 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str0), NTAG(TAG_Nothing)});
    V v_t_245 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str1), NTAG(TAG_Nothing)});
    V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    HeffT2 v_t_247 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246}), v_x_243));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_x1_2458;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        V v_p_2410 = v_field_249;
        v_x1_2458 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2410});
      } else {
        V v_it1_2411 = v_field_249;
        switch (heff_tag_of(v_it1_2411)) {
        case TAG_Nil: {
          V v_t_2420;
          switch (heff_tag_of(v_x_243)) {
          case TAG_LStr: {
            V v_t_2413 = heff_field(v_x_243, 1);
            heff_take_n(v_x_243, 2ULL, 2);
            v_t_2420 = v_t_2413;
            break;
          }
          case TAG_LTag: {
            V v_t_2415 = heff_field(v_x_243, 1);
            heff_take_n(v_x_243, 2ULL, 2);
            v_t_2420 = v_t_2415;
            break;
          }
          case TAG_LList: {
            V v_t_2417 = heff_field(v_x_243, 1);
            heff_take_n(v_x_243, 2ULL, 2);
            v_t_2420 = v_t_2417;
            break;
          }
          case TAG_LRec: {
            V v_t_2419 = heff_field(v_x_243, 1);
            heff_take_n(v_x_243, 2ULL, 2);
            v_t_2420 = v_t_2419;
            break;
          }
          default: heff_nomatch(v_x_243);
          }
          V v_t_2421 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2420, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str2)});
          v_x1_2458 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
          break;
        }
        case TAG_Cons: {
          V v_n_2422 = heff_field(v_it1_2411, 0);
          V v_it12_2423 = heff_field(v_it1_2411, 1);
          heff_take_n(v_it1_2411, 3ULL, 2);
          switch (heff_tag_of(v_it12_2423)) {
          case TAG_Nil: {
            heff_drop(v_n_2422);
            V v_t_2432;
            switch (heff_tag_of(v_x_243)) {
            case TAG_LStr: {
              V v_t_2425 = heff_field(v_x_243, 1);
              heff_take_n(v_x_243, 2ULL, 2);
              v_t_2432 = v_t_2425;
              break;
            }
            case TAG_LTag: {
              V v_t_2427 = heff_field(v_x_243, 1);
              heff_take_n(v_x_243, 2ULL, 2);
              v_t_2432 = v_t_2427;
              break;
            }
            case TAG_LList: {
              V v_t_2429 = heff_field(v_x_243, 1);
              heff_take_n(v_x_243, 2ULL, 2);
              v_t_2432 = v_t_2429;
              break;
            }
            case TAG_LRec: {
              V v_t_2431 = heff_field(v_x_243, 1);
              heff_take_n(v_x_243, 2ULL, 2);
              v_t_2432 = v_t_2431;
              break;
            }
            default: heff_nomatch(v_x_243);
            }
            V v_t_2433 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2432, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str3)});
            v_x1_2458 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2433});
            break;
          }
          case TAG_Cons: {
            V v_d_2434 = heff_field(v_it12_2423, 0);
            V v_it122_2435 = heff_field(v_it12_2423, 1);
            heff_take_n(v_it12_2423, 3ULL, 2);
            switch (heff_tag_of(v_it122_2435)) {
            case TAG_Nil: {
              heff_drop(v_x_243);
              HeffT2 v_t_2436 = ({ V a_0 = v_n_2422; HeffT2 r_ = (g_heff_2ebuild_2eproject_2enameOf_24cpr(a_0)); heff_drop(v_n_2422); r_; });
              {
                V v_field_2438 = v_t_2436.f[1];
                int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
                if ((v_tag_2437 == ((int64_t)0ULL))) {
                  heff_drop(v_d_2434);
                  V v_e_2439 = v_field_2438;
                  v_x1_2458 = heff_tag_n(TAG_Left, 1, (V[]){v_e_2439});
                } else {
                  V v_name_2440 = v_field_2438;
                  HeffT2 v_t_2441 = ({ V a_0 = v_d_2434; HeffT2 r_ = (g_heff_2ebuild_2eproject_2estr_24cpr(a_0)); heff_drop(v_d_2434); r_; });
                  {
                    V v_field_2443 = v_t_2441.f[1];
                    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                    if ((v_tag_2442 == ((int64_t)0ULL))) {
                      heff_drop(v_name_2440);
                      V v_e_2444 = v_field_2443;
                      v_x1_2458 = heff_tag_n(TAG_Left, 1, (V[]){v_e_2444});
                    } else {
                      V v_dir_2445 = v_field_2443;
                      v_x1_2458 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_name__dir, (V[]){v_name_2440, v_dir_2445})});
                    }
                  }
                }
              }
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_it122_2435, 0ULL, 2);
              heff_drop(v_n_2422);
              heff_drop(v_d_2434);
              V v_t_2456;
              switch (heff_tag_of(v_x_243)) {
              case TAG_LStr: {
                V v_t_2449 = heff_field(v_x_243, 1);
                heff_take_n(v_x_243, 2ULL, 2);
                v_t_2456 = v_t_2449;
                break;
              }
              case TAG_LTag: {
                V v_t_2451 = heff_field(v_x_243, 1);
                heff_take_n(v_x_243, 2ULL, 2);
                v_t_2456 = v_t_2451;
                break;
              }
              case TAG_LList: {
                V v_t_2453 = heff_field(v_x_243, 1);
                heff_take_n(v_x_243, 2ULL, 2);
                v_t_2456 = v_t_2453;
                break;
              }
              case TAG_LRec: {
                V v_t_2455 = heff_field(v_x_243, 1);
                heff_take_n(v_x_243, 2ULL, 2);
                v_t_2456 = v_t_2455;
                break;
              }
              default: heff_nomatch(v_x_243);
              }
              V v_t_2457 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2456, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr_str4)});
              v_x1_2458 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2457});
              break;
            }
            default: heff_nomatch(v_it122_2435);
            }
            break;
          }
          default: heff_nomatch(v_it12_2423);
          }
          break;
        }
        default: heff_nomatch(v_it1_2411);
        }
      }
      HeffT2 v_t_2459 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(v_rest_242));
      {
        V v_field_2461 = v_t_2459.f[1];
        int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
        switch (heff_tag_of(v_x1_2458)) {
        case TAG_Left: {
          V v_p_2462 = heff_field(v_x1_2458, 0);
          heff_take_n(v_x1_2458, 1ULL, 1);
          heff_drop(v_field_2461);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2462}});
        }
        case TAG_Right: {
          V v_y_2463 = heff_field(v_x1_2458, 0);
          heff_take_n(v_x1_2458, 1ULL, 1);
          if ((v_tag_2460 == ((int64_t)0ULL))) {
            heff_drop(v_y_2463);
            V v_p_2464 = v_field_2461;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2464}});
          } else {
            V v_ys_2465 = v_field_2461;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_Cons, 2, (V[]){v_y_2463, v_ys_2465})}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2458)}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str0, 6, "module");
HEFF_REC_LIT(g_heff_2ebuild_2eproject_2epackageFields_lit_v_t_240, 2, shape_name__left, ((V)&g_heff_2ebuild_2eproject_2epackageFields_str0), NTAG(TAG_Nothing));
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str1, 4, "heff");
HEFF_REC_LIT(g_heff_2ebuild_2eproject_2epackageFields_lit_v_t_241, 2, shape_name__left, ((V)&g_heff_2ebuild_2eproject_2epackageFields_str1), NTAG(TAG_Nothing));
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str2, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str3, 7, "replace");
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam0, 1, 0};
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam1, 1, 0};

static V g_heff_2ebuild_2eproject_2epackageFields_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2epackageFields_st;
static V g_heff_2ebuild_2eproject_2epackageFields_init(void) {
  V v_t_240 = ((V)&g_heff_2ebuild_2eproject_2epackageFields_lit_v_t_240);
  V v_t_241 = ((V)&g_heff_2ebuild_2eproject_2epackageFields_lit_v_t_241);
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam0_clo)})});
  V v_t_245 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str3), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_246})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_247});
}
V g_heff_2ebuild_2eproject_2epackageFields_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2epackageFields_st)) return g_heff_2ebuild_2eproject_2epackageFields_val;
  return heff_global(&g_heff_2ebuild_2eproject_2epackageFields_val, &g_heff_2ebuild_2eproject_2epackageFields_st, g_heff_2ebuild_2eproject_2epackageFields_init);
}
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_242});
}
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_244});
}
Clo g_heff_2ebuild_2eproject_2epackageOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epackageOf(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2epackageOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str0, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str1, 72, "a program ships no `bin`: the heff home's bin/ is where the programs are");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str6, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str8, 92, "` is not a name: a program ships files and directories of the project's root, by their names");

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_241);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_p_246 = v_field_245;
        V v_x2_247 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
        heff_drop(v_x2_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_246}});
      } else {
        V v_n_248 = v_field_245;
        V v_n_249 = heff_dup(v_n_248);
        V v_t_2411;
        if (heff_strEq_c_lent(v_n_249, ((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str0), 2)) {
          heff_drop(v_n_249);
          v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str1)});
        } else {
          if ((heff_strEq_c_lent(v_n_249, ((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str2), 2) || (heff_strEq_c_lent(v_n_249, ((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str3), 2) || (heff_strEq_c_lent(v_n_249, ((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str4), 2) || (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str5), v_n_249, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str6), v_n_249, MK_INT(0LL), 5))))))) {
            V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str7), v_n_249), ((V)&g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr_str8));
            v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
          } else {
            heff_drop(v_n_249);
            v_t_2411 = NTAG(TAG_Nothing);
          }
        }
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nothing: {
          heff_drop(v_x_241);
          HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_rest_242));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24Cons, 2);
              heff_drop(v_n_248);
              V v_p_2415 = v_field_2414;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2415}});
            } else {
              V v_ys_2416 = v_field_2414;
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_n_248, v_ys_2416})}});
            }
          }
        }
        case TAG_Just: {
          V v_why_2417 = heff_field(v_t_2411, 0);
          heff_take_n(v_t_2411, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_n_248);
          V v_x2_2418 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
          heff_drop(v_x2_2418);
          V v_t_2427;
          switch (heff_tag_of(v_x_241)) {
          case TAG_LStr: {
            V v_t_2420 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2427 = v_t_2420;
            break;
          }
          case TAG_LTag: {
            V v_t_2422 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2427 = v_t_2422;
            break;
          }
          case TAG_LList: {
            V v_t_2424 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2427 = v_t_2424;
            break;
          }
          case TAG_LRec: {
            V v_t_2426 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2427 = v_t_2426;
            break;
          }
          default: heff_nomatch(v_x_241);
          }
          V v_f_2428 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2427, 2, 7), v_why_2417});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2411)}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr_str1, 24, "a directory is not empty");

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_241);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_p_246 = v_field_245;
        V v_x2_247 = (g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423(v_rest_242));
        heff_drop(v_x2_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_246}});
      } else {
        V v_d_248 = v_field_245;
        if (heff_strEq_c_lent(v_d_248, ((V)&g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr_str0), 2)) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_d_248);
          V v_x2_249 = (g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423(v_rest_242));
          heff_drop(v_x2_249);
          V v_t_2418;
          switch (heff_tag_of(v_x_241)) {
          case TAG_LStr: {
            V v_t_2411 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2418 = v_t_2411;
            break;
          }
          case TAG_LTag: {
            V v_t_2413 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2418 = v_t_2413;
            break;
          }
          case TAG_LList: {
            V v_t_2415 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2418 = v_t_2415;
            break;
          }
          case TAG_LRec: {
            V v_t_2417 = heff_field(v_x_241, 1);
            heff_take_n(v_x_241, 2ULL, 2);
            v_t_2418 = v_t_2417;
            break;
          }
          default: heff_nomatch(v_x_241);
          }
          V v_f_2419 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2418, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr_str1)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
        } else {
          heff_drop(v_x_241);
          HeffT2 v_t_2420 = (g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr(v_rest_242));
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24Cons, 2);
              heff_drop(v_d_248);
              V v_p_2423 = v_field_2422;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2423}});
            } else {
              V v_ys_2424 = v_field_2422;
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_d_248, v_ys_2424})}});
            }
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24rec1_str0, 4, "fuel");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24rec1_str1, 5, "False");
V g_heff_2ebuild_2eproject_2ebuildOf_24rec1_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2ebuildOf_24rec1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_24rec1_lam0, 1, 0};

static V g_heff_2ebuild_2eproject_2ebuildOf_24rec1_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2ebuildOf_24rec1_st;
static V g_heff_2ebuild_2eproject_2ebuildOf_24rec1_init(void) {
  return heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec1_str0), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec1_lam0_clo)})});
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec1_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2ebuildOf_24rec1_st)) return g_heff_2ebuild_2eproject_2ebuildOf_24rec1_val;
  return heff_global(&g_heff_2ebuild_2eproject_2ebuildOf_24rec1_val, &g_heff_2ebuild_2eproject_2ebuildOf_24rec1_st, g_heff_2ebuild_2eproject_2ebuildOf_24rec1_init);
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec1_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return heff_tag_n(TAG_LTag, 2, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec1_str1), v_t_240});
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24rec3_str0, 7, "libDirs");
V g_heff_2ebuild_2eproject_2ebuildOf_24rec3_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2ebuildOf_24rec3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_24rec3_lam0, 1, 0};

static V g_heff_2ebuild_2eproject_2ebuildOf_24rec3_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2ebuildOf_24rec3_st;
static V g_heff_2ebuild_2eproject_2ebuildOf_24rec3_init(void) {
  return heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec3_str0), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec3_lam0_clo)})});
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec3_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2ebuildOf_24rec3_st)) return g_heff_2ebuild_2eproject_2ebuildOf_24rec3_val;
  return heff_global(&g_heff_2ebuild_2eproject_2ebuildOf_24rec3_val, &g_heff_2ebuild_2eproject_2ebuildOf_24rec3_st, g_heff_2ebuild_2eproject_2ebuildOf_24rec3_init);
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec3_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_240});
}
Clo g_heff_2ebuild_2eproject_2enewerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewerGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewerGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c_lent(v_y_244, v_x_242, 0)) {
        return NTAG(TAG_True);
      } else {
        if (heff_intEq_c_lent(v_x_242, v_y_244, 0)) {
          V t_0 = v_xs_243;
          V t_1 = v_ys_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2enewerGo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str3, 1, "/");
Clo g_heff_2ebuild_2eproject_2erepoOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erepoOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2erepoOf(V v_path_240) {
top: ;
  V v_xs_241 = ({ V a_0 = v_path_240; V b_1 = ((V)&g_heff_2ebuild_2eproject_2erepoOf_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str1), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_t_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    v_t_245 = heff_dup(v_path_240);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ebuild_2eproject_2eisMajorPart(a_0)); heff_drop(v_t_245); r_; });
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_xs_247 = ({ V a_0 = v_path_240; V b_1 = ((V)&g_heff_2ebuild_2eproject_2erepoOf_str2); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str3), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nil: {
      v_t_2411 = heff_dup(v_path_240);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 2);
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_240, 0)) - heff_unbox_word(heff_strLength(v_t_2411)));
    return heff_strSlice(v_path_240, MK_INT(0LL), heff_box_word((v_t_2412 - ((int64_t)1ULL))));
  } else {
    heff_drop(v_t_246);
    return v_path_240;
  }
}
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erepoOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2esumGo_24cpr_str0, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumGo_24cpr_str1, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumGo_24cpr_str2, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumGo_24cpr_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumGo_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumGo_24cpr_str5, 30, "` is no version: write `a.b.c`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumGo_24cpr_str6, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");

HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_at_244 = heff_dup(v_at_240);
    V v_line_245 = heff_dup(v_l_242);
    V v_it_246 = ({ V a_0 = v_line_245; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_line_245); r_; });
    V v_t_2426;
    switch (heff_tag_of(v_it_246)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_at_244);
      v_t_2426 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      V v_p_247 = heff_field(v_it_246, 0);
      V v_it2_248 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 2);
      switch (heff_tag_of(v_it2_248)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_p_247);
        v_t_2426 = heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_244, ((V)&g_heff_2ebuild_2eproject_2esumGo_24cpr_str0)})});
        break;
      }
      case TAG_Cons: {
        V v_v_249 = heff_field(v_it2_248, 0);
        V v_it22_2410 = heff_field(v_it2_248, 1);
        heff_take_n(v_it2_248, 3ULL, 2);
        switch (heff_tag_of(v_it22_2410)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_p_247);
          heff_drop(v_v_249);
          v_t_2426 = heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_244, ((V)&g_heff_2ebuild_2eproject_2esumGo_24cpr_str1)})});
          break;
        }
        case TAG_Cons: {
          V v_h_2411 = heff_field(v_it22_2410, 0);
          V v_it222_2412 = heff_field(v_it22_2410, 1);
          heff_take_n(v_it22_2410, 3ULL, 2);
          switch (heff_tag_of(v_it222_2412)) {
          case TAG_Nil: {
            V v_t_2413 = ({ V a_0 = v_v_249; V b_1 = ((V)&g_heff_2ebuild_2eproject_2esumGo_24cpr_str2); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2esumGo_24cpr_str3), v_v_249, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
            V v_t_2414 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_2413); r_; });
            HeffT2 v_t_2415 = ({ V a_0 = v_v_249; V a_1 = v_t_2414; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
            {
              V v_field_2416 = v_t_2415.f[0];
              V v_field_2417 = v_t_2415.f[1];
              V v_x_2418 = v_field_2416;
              V v_y_2419 = v_field_2417;
              heff_drop(v_y_2419);
              V v_t_2420 = v_x_2418;
              V v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2420; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
              if (heff_intEq_c(v_t_2421, MK_INT(3LL))) {
                heff_drop(v_at_244);
                V v_t_2422 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_p_247, v_v_249, v_h_2411}), NTAG(TAG_Nil)});
                v_t_2426 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2422});
              } else {
                heff_drop_cell(v_ru_24x2_241_24Cons, 2);
                heff_drop(v_p_247);
                heff_drop(v_h_2411);
                V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2esumGo_24cpr_str4), v_v_249), ((V)&g_heff_2ebuild_2eproject_2esumGo_24cpr_str5));
                v_t_2426 = heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_244, v_t_2423})});
              }
            }
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_it222_2412, 0ULL, 2);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_p_247);
            heff_drop(v_v_249);
            heff_drop(v_h_2411);
            v_t_2426 = heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_at_244, ((V)&g_heff_2ebuild_2eproject_2esumGo_24cpr_str6)})});
            break;
          }
          default: heff_nomatch(v_it222_2412);
          }
          break;
        }
        default: heff_nomatch(v_it22_2410);
        }
        break;
      }
      default: heff_nomatch(v_it2_248);
      }
      break;
    }
    default: heff_nomatch(v_it_246);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Left: {
      V v_p_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      heff_drop(v_at_240);
      heff_drop(v_l_242);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2427}});
    }
    case TAG_Right: {
      V v_xs_2428 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      V v_t_2429 = heff_intAdd(v_at_240, heff_strLength(v_l_242));
      HeffT2 v_t_2430 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(heff_intAdd(v_t_2429, MK_INT(1LL)), v_rest_243));
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          heff_drop(v_xs_2428);
          V v_x_2433 = v_field_2432;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2433}});
        } else {
          V v_y_2434 = v_field_2432;
          V v_t_2435 = (g_prelude_2e_2b_2b(v_xs_2428, v_y_2434));
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2435}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2426)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str1, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str2, 7, "package");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str3, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str4, 1, "=");

HeffT3 g_heff_2ebuild_2eproject_2espanGo_24cpr(V v_ts_240, V v_i_241) {
top: ;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_i_241, 1) && heff_intLt_c_lent(v_i_241, heff_arrayLength_lent(v_ts_240, 0), 2))) {
    V v_t_242 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
    V v_kind_243 = heff_take_field(v_t_242, 0);
    V v_text_244 = heff_get_n(v_t_242, 1, 7);
    if (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str0), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_kind_243);
      heff_drop(v_text_244);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    } else {
      if (heff_strEq_c(v_kind_243, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str1))) {
        if (heff_strEq_c(v_text_244, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str2))) {
          int64_t v_i_245 = (heff_peek_word(v_i_241) + ((int64_t)1ULL));
          if (((((int64_t)0ULL) <= v_i_245) && (v_i_245 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
            V v_t_246 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_245), 2);
            V v_kind_247 = heff_take_field(v_t_246, 0);
            V v_text_248 = heff_get_n(v_t_246, 1, 7);
            if ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str3), 2) && heff_strEq_c_lent(v_text_248, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str4), 2))) {
              heff_drop(v_kind_247);
              heff_drop(v_text_248);
              HeffT3 v_t_249 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, heff_box_word((heff_peek_word(v_i_241) + ((int64_t)2ULL)))));
              {
                V v_field_2411 = v_t_249.f[1];
                V v_field_2412 = v_t_249.f[2];
                int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
                if ((v_tag_2410 == ((int64_t)0ULL))) {
                  heff_drop(v_i_241);
                  heff_drop(v_field_2412);
                  V v_it1_2413 = v_field_2411;
                  heff_drop(v_it1_2413);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                } else {
                  V v_it11_2414 = v_field_2411;
                  heff_drop(v_it11_2414);
                  V v_j_2415 = v_field_2412;
                  int64_t v_i_2416 = (heff_unbox_word(v_i_241) + ((int64_t)2ULL));
                  if (((((int64_t)0ULL) <= v_i_2416) && (v_i_2416 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
                    V v_opening_2417 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_2416), 2);
                    V v_i_2418 = heff_intSub(v_j_2415, MK_INT(1LL));
                    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2418, 1) && heff_intLt_c_lent(v_i_2418, heff_arrayLength_lent(v_ts_240, 0), 2))) {
                      V v_closing_2419 = heff_arrayIndex_lent(v_ts_240, v_i_2418, 2);
                      V v_f_2420 = heff_get_n(v_opening_2417, 2, 7);
                      V v_f_2421 = heff_get_n(v_closing_2419, 3, 7);
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2420, v_f_2421}});
                    } else {
                      heff_drop_rec(v_opening_2417, 7);
                      heff_drop(v_i_2418);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  } else {
                    heff_drop(v_j_2415);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              }
            } else {
              heff_drop(v_kind_247);
              heff_drop(v_text_248);
              V v_t_2422 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
              V t_0 = v_ts_240;
              V t_1 = v_t_2422;
              v_ts_240 = t_0;
              v_i_241 = t_1;
              goto top;
            }
          } else {
            V v_t_2423 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
            V t_0 = v_ts_240;
            V t_1 = v_t_2423;
            v_ts_240 = t_0;
            v_i_241 = t_1;
            goto top;
          }
        } else {
          V v_t_2424 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
          V t_0 = v_ts_240;
          V t_1 = v_t_2424;
          v_ts_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
      } else {
        heff_drop(v_text_244);
        V v_t_2425 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
        V t_0 = v_ts_240;
        V t_1 = v_t_2425;
        v_ts_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  } else {
    heff_drop(v_i_241);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
}