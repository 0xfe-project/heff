// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_cmt 308164
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_version 583465758
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__dir[] = {LBL_name, LBL_dir};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V);
V g_heff_2ebuild_2eproject_2eandList(V);
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_clo;
V g_heff_2ebuild_2eproject_2eandList_24acc(V, V);
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo;
HeffT2 g_heff_2ebuild_2eproject_2ebuildOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2echeckHeff_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
V g_heff_2ebuild_2eproject_2eclaimOf(V);
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eclaimOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V, V, V);
V g_heff_2ebuild_2eproject_2efieldsSaid(V);
V g_heff_2ebuild_2eproject_2efieldsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsSaid_clo;
V g_heff_2ebuild_2eproject_2eisMajorPart(V);
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo;
HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames(V);
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo;
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V, V);
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo;
HeffT2 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2enameOf_24cpr(V);
V g_heff_2ebuild_2eproject_2enameRule_get(void);
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2enextDecl(V, V);
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enextDecl_clo;
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf4_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(V);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2erequiredOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eshipWrong_24cpr(V);
V g_heff_2ebuild_2eproject_2eshowPackage(V);
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eshowPackage_clo;
HeffT2 g_heff_2ebuild_2eproject_2espanGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2esumLine_24cpr(V, V);
V g_heff_2ebuild_2eproject_2etestsModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_list_2eall_24s1411948616x47436528(V, V, V);
V g_list_2eall_24s1411948616x47436528_entry(V self, V *a);
extern Clo g_list_2eall_24s1411948616x47436528_clo;
V g_list_2eall_24s494596359x1928238377(V);
V g_list_2eall_24s494596359x1928238377_entry(V self, V *a);
extern Clo g_list_2eall_24s494596359x1928238377_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f768999161x1997188166(V, V, V);
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_clo;
V g_list_2emap_24s1703643582x349630108(V, V);
V g_list_2emap_24s1703643582x349630108_entry(V self, V *a);
extern Clo g_list_2emap_24s1703643582x349630108_clo;
V g_list_2emap_24s1791433880x1360378684(V);
V g_list_2emap_24s1791433880x1360378684_entry(V self, V *a);
extern Clo g_list_2emap_24s1791433880x1360378684_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s634456687x1151454243(V, V);
V g_list_2ezipWith_24s634456687x1151454243_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4, 62, "expected `,` or `]`: an item is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5, 42, "the text ends where more of it is expected");

HeffT2 g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(V v_ts_240, V v_i_241, V v_acc_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_acc_242);
      V v_p_246 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_246}});
    } else {
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_it1_247, 0);
        V v_j_249 = heff_field(v_it1_247, 1);
        V v_ru_24it1_247_24MkPair = heff_take_reuse_n(v_it1_247, 3ULL, 2);
        if ((heff_intLe_c_lent(MK_INT(0LL), v_j_249, 1) && heff_intLt_c(heff_dup(v_j_249), heff_arrayLength_lent(v_ts_240, 0)))) {
          V v_t_2410 = heff_arrayIndex_lent(v_ts_240, v_j_249, 0);
          V v_kind_2411 = heff_take_field(v_t_2410, 0);
          V v_text_2412 = heff_take_field(v_t_2410, 1);
          V v_start_2413 = heff_get_n(v_t_2410, 2, 7);
          if ((heff_strEq_c_lent(v_kind_2411, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str0), 2) && heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str1), 2))) {
            heff_drop_cell(v_ru_24it1_247_24MkPair, 2);
            heff_drop(v_kind_2411);
            heff_drop(v_text_2412);
            heff_drop(v_start_2413);
            V t_0 = v_ts_240;
            V t_1 = heff_box_word((heff_unbox_word(v_j_249) + ((int64_t)1ULL)));
            V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_acc_242});
            v_ts_240 = t_0;
            v_i_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          } else {
            if ((heff_strEq_c_lent(v_kind_2411, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str2), 2) && heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str3), 2))) {
              heff_drop(v_kind_2411);
              heff_drop(v_text_2412);
              heff_drop(v_start_2413);
              V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_acc_242})));
              V v_f_2415 = heff_tag_at_n(v_ru_24it1_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, heff_box_word((heff_unbox_word(v_j_249) + ((int64_t)1ULL)))});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2415}});
            } else {
              heff_drop(v_acc_242);
              heff_drop(v_x_248);
              heff_drop(v_j_249);
              heff_drop_cell(v_ru_24it1_247_24MkPair, 2);
              heff_drop(v_kind_2411);
              heff_drop(v_text_2412);
              V v_f_2416 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2413, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str4)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
            }
          }
        } else {
          heff_drop(v_acc_242);
          heff_drop(v_x_248);
          heff_drop(v_j_249);
          heff_drop_cell(v_ru_24it1_247_24MkPair, 2);
          int64_t v_i_2417 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
          V v_t_2419;
          if (((((int64_t)0ULL) <= v_i_2417) && (v_i_2417 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
            V v_t_2418 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2417), 2);
            v_t_2419 = heff_get_n(v_t_2418, 2, 7);
          } else {
            v_t_2419 = MK_INT(0LL);
          }
          V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr_str5)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_247)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1, 23, "expected a field's name");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4, 12, "expected `=`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6, 1, ",");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8, 1, "}");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9, 62, "expected `,` or `}`: a field is a literal, nothing is computed");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12, 42, "the text ends where more of it is expected");

HeffT2 g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(V v_ts_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if (((((int64_t)0ULL) <= v_i_241) && (v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_name_243 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_241), 2);
    V v_kind_244 = heff_take_field(v_name_243, 0);
    V v_start_245 = heff_take_field(v_name_243, 2);
    V v_text_246 = heff_get_n(v_name_243, 1, 7);
    if (!heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str0), 2)) {
      heff_drop(v_acc_242);
      heff_drop(v_kind_244);
      heff_drop(v_text_246);
      V v_f_247 = heff_rec_n(2, shape_at__msg, (V[]){v_start_245, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str1)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
    } else {
      heff_drop(v_kind_244);
      heff_drop(v_start_245);
      int64_t v_i_248 = (v_i_241 + ((int64_t)1ULL));
      if (((((int64_t)0ULL) <= v_i_248) && (v_i_248 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
        V v_eq_249 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_248), 2);
        V v_kind_2410 = heff_take_field(v_eq_249, 0);
        V v_text_2411 = heff_take_field(v_eq_249, 1);
        V v_start_2412 = heff_get_n(v_eq_249, 2, 7);
        if ((heff_strEq_c_lent(v_kind_2410, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str2), 2) ? !heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str3), 2) : 1)) {
          heff_drop(v_acc_242);
          heff_drop(v_text_246);
          heff_drop(v_kind_2410);
          heff_drop(v_text_2411);
          V v_f_2413 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2412, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str4)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
        } else {
          heff_drop(v_kind_2410);
          heff_drop(v_text_2411);
          heff_drop(v_start_2412);
          HeffT2 v_t_2414 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, heff_intAdd(heff_box_word(v_i_241), MK_INT(2LL))));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              heff_drop(v_acc_242);
              heff_drop(v_text_246);
              V v_p_2417 = v_field_2416;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2417}});
            } else {
              V v_it1_2418 = v_field_2416;
              switch (heff_tag_of(v_it1_2418)) {
              case TAG_MkPair: {
                V v_x_2419 = heff_field(v_it1_2418, 0);
                V v_j_2420 = heff_field(v_it1_2418, 1);
                V v_ru_24it1_2418_24MkPair = heff_take_reuse_n(v_it1_2418, 3ULL, 2);
                if ((heff_intLe_c_lent(MK_INT(0LL), v_j_2420, 1) && heff_intLt_c(heff_dup(v_j_2420), heff_arrayLength_lent(v_ts_240, 0)))) {
                  V v_t_2421 = heff_arrayIndex_lent(v_ts_240, v_j_2420, 0);
                  V v_kind_2422 = heff_take_field(v_t_2421, 0);
                  V v_text_2423 = heff_take_field(v_t_2421, 1);
                  V v_start_2424 = heff_get_n(v_t_2421, 2, 7);
                  if ((heff_strEq_c_lent(v_kind_2422, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str5), 2) && heff_strEq_c_lent(v_text_2423, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str6), 2))) {
                    heff_drop(v_kind_2422);
                    heff_drop(v_text_2423);
                    heff_drop(v_start_2424);
                    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_text_246, v_x_2419}), v_acc_242});
                    V t_0 = v_ts_240;
                    int64_t t_1 = (heff_unbox_word(v_j_2420) + ((int64_t)1ULL));
                    V t_2 = v_t_2425;
                    v_ts_240 = t_0;
                    v_i_241 = t_1;
                    v_acc_242 = t_2;
                    goto top;
                  } else {
                    if ((heff_strEq_c_lent(v_kind_2422, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str7), 2) && heff_strEq_c_lent(v_text_2423, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str8), 2))) {
                      heff_drop(v_kind_2422);
                      heff_drop(v_text_2423);
                      heff_drop(v_start_2424);
                      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24it1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_text_246, v_x_2419}), v_acc_242});
                      V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2426));
                      V v_f_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, heff_box_word((heff_unbox_word(v_j_2420) + ((int64_t)1ULL)))});
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2428}});
                    } else {
                      heff_drop(v_acc_242);
                      heff_drop(v_text_246);
                      heff_drop(v_x_2419);
                      heff_drop(v_j_2420);
                      heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                      heff_drop(v_kind_2422);
                      heff_drop(v_text_2423);
                      V v_f_2429 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2424, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str9)});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2429}});
                    }
                  }
                } else {
                  heff_drop(v_acc_242);
                  heff_drop(v_text_246);
                  heff_drop(v_x_2419);
                  heff_drop(v_j_2420);
                  heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                  int64_t v_i_2430 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
                  V v_t_2432;
                  if (((((int64_t)0ULL) <= v_i_2430) && (v_i_2430 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
                    V v_t_2431 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2430), 2);
                    v_t_2432 = heff_get_n(v_t_2431, 2, 7);
                  } else {
                    v_t_2432 = MK_INT(0LL);
                  }
                  V v_f_2433 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2432, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str10)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2418)}});
              }
            }
          }
        }
      } else {
        heff_drop(v_acc_242);
        heff_drop(v_text_246);
        int64_t v_i_2434 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
        V v_t_2436;
        if (((((int64_t)0ULL) <= v_i_2434) && (v_i_2434 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
          V v_t_2435 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2434), 2);
          v_t_2436 = heff_get_n(v_t_2435, 2, 7);
        } else {
          v_t_2436 = MK_INT(0LL);
        }
        V v_f_2437 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2436, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str11)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
      }
    }
  } else {
    heff_drop(v_acc_242);
    int64_t v_i_2438 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2440;
    if (((((int64_t)0ULL) <= v_i_2438) && (v_i_2438 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
      V v_t_2439 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2438), 2);
      v_t_2440 = heff_get_n(v_t_2439, 2, 7);
    } else {
      v_t_2440 = MK_INT(0LL);
    }
    V v_f_2441 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2440, ((V)&g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr_str12)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2441}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3, 1, "[");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7, 5, "punct");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8, 1, "{");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9, 83, "a manifest holds strings, tags `X`, lists `[...]` and records `{...}`, nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10, 42, "the text ends where more of it is expected");

HeffT2 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V v_ts_240, V v_i_241) {
top: ;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_i_241, 1) && heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0)))) {
    V v_t_242 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str0))) {
      V v_t_243 = heff_tag_n(TAG_LStr, 2, (V[]){heff_dup(heff_rfield(v_t_242, 1)), v_t_242});
      V v_f_244 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_244}});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str1))) {
        V v_t_245 = heff_tag_n(TAG_LTag, 2, (V[]){heff_dup(heff_rfield(v_t_242, 1)), v_t_242});
        V v_f_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_246}});
      } else {
        if ((heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_t_242, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str3)))) {
          int64_t v_i_247 = (heff_peek_word(v_i_241) + ((int64_t)1ULL));
          if (((((int64_t)0ULL) <= v_i_247) && (v_i_247 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
            V v_next_248 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_247), 2);
            V v_kind_249 = heff_take_field(v_next_248, 0);
            V v_text_2410 = heff_get_n(v_next_248, 1, 7);
            if ((heff_strEq_c_lent(v_kind_249, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str4), 2) && heff_strEq_c_lent(v_text_2410, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str5), 2))) {
              heff_drop(v_kind_249);
              heff_drop(v_text_2410);
              V v_t_2411 = heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_242});
              V v_f_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_intAdd(v_i_241, MK_INT(2LL))});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2412}});
            } else {
              heff_drop(v_kind_249);
              heff_drop(v_text_2410);
              HeffT2 v_t_2413 = (g_heff_2ebuild_2eproject_2eitemsGo_24s1210724508x1587976252_24cpr(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), NTAG(TAG_Nil)));
              {
                V v_field_2415 = v_t_2413.f[1];
                int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
                if ((v_tag_2414 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_t_242, 7);
                  V v_p_2416 = v_field_2415;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2416}});
                } else {
                  V v_x21_2417 = v_field_2415;
                  switch (heff_tag_of(v_x21_2417)) {
                  case TAG_MkPair: {
                    V v_xs_2418 = heff_field(v_x21_2417, 0);
                    V v_j_2419 = heff_field(v_x21_2417, 1);
                    V v_ru_24x21_2417_24MkPair = heff_take_reuse_n(v_x21_2417, 3ULL, 2);
                    V v_t_2420 = heff_tag_at_n(v_ru_24x21_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LList, 2, (V[]){v_xs_2418, v_t_242}), v_j_2419});
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2420}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x21_2417)}});
                  }
                }
              }
            }
          } else {
            heff_drop(v_i_241);
            heff_drop_rec(v_t_242, 7);
            int64_t v_i_2421 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
            V v_t_2423;
            if (((((int64_t)0ULL) <= v_i_2421) && (v_i_2421 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
              V v_t_2422 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2421), 2);
              v_t_2423 = heff_get_n(v_t_2422, 2, 7);
            } else {
              v_t_2423 = MK_INT(0LL);
            }
            V v_f_2424 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str6)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
          }
        } else {
          if ((heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str7)) && heff_strEq_c(heff_dup(heff_rfield(v_t_242, 1)), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str8)))) {
            HeffT2 v_t_2425 = (g_heff_2ebuild_2eproject_2efieldsGo_24s1902555314x968481083_24cpr(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), NTAG(TAG_Nil)));
            {
              V v_field_2427 = v_t_2425.f[1];
              int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
              if ((v_tag_2426 == ((int64_t)0ULL))) {
                heff_drop_rec(v_t_242, 7);
                V v_p_2428 = v_field_2427;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2428}});
              } else {
                V v_x21_2429 = v_field_2427;
                switch (heff_tag_of(v_x21_2429)) {
                case TAG_MkPair: {
                  V v_fs_2430 = heff_field(v_x21_2429, 0);
                  V v_j_2431 = heff_field(v_x21_2429, 1);
                  V v_ru_24x21_2429_24MkPair = heff_take_reuse_n(v_x21_2429, 3ULL, 2);
                  V v_t_2432 = heff_tag_at_n(v_ru_24x21_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_LRec, 2, (V[]){v_fs_2430, v_t_242}), v_j_2431});
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2432}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x21_2429)}});
                }
              }
            }
          } else {
            heff_drop(v_i_241);
            V v_f_2433 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_242, 2, 7), ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str9)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
          }
        }
      }
    }
  } else {
    heff_drop(v_i_241);
    int64_t v_i_2434 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
    V v_t_2436;
    if (((((int64_t)0ULL) <= v_i_2434) && (v_i_2434 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
      V v_t_2435 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_2434), 2);
      v_t_2436 = heff_get_n(v_t_2435, 2, 7);
    } else {
      v_t_2436 = MK_INT(0LL);
    }
    V v_f_2437 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2436, ((V)&g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr_str10)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eversion_24cpr_str1, 1, ".");

HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V v_v_240) {
top: ;
  V v_it_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str0); V a_1 = v_v_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eversion_24cpr_str1), v_v_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    V v_ru_24it_241_24Cons = heff_take_reuse_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24it_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      V v_ru_24it2_243_24Cons = heff_take_reuse_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24it_241_24Cons, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24it2_243_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_c_246 = heff_field(v_it22_245, 0);
        V v_it222_247 = heff_field(v_it22_245, 1);
        heff_take_n(v_it22_245, 3ULL, 2);
        switch (heff_tag_of(v_it222_247)) {
        case TAG_Nil: {
          if ((((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_a_242, 0))) && ({ V v_t_248 = (g_list_2emap_24f768999161x1997188166(v_a_242, MK_INT(0LL), heff_strLength_lent(v_a_242, 0))); int c_ = ({ V v_c_2416 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_248)); int c_ = ((heff_dup(v_c_2416) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_a_242, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_a_242, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_2416); c_; }); heff_drop(v_t_248); c_; })) && (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_b_244, 0))) && ({ V v_t_249 = (g_list_2emap_24f768999161x1997188166(v_b_244, MK_INT(0LL), heff_strLength_lent(v_b_244, 0))); int c_ = ({ V v_c_2417 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_249)); int c_ = ((heff_dup(v_c_2417) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_b_244, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_b_244, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_2417); c_; }); heff_drop(v_t_249); c_; })) && ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_c_246, 0))) && ({ V v_t_2410 = (g_list_2emap_24f768999161x1997188166(v_c_246, MK_INT(0LL), heff_strLength_lent(v_c_246, 0))); int c_ = ({ V v_c_2418 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_2410)); int c_ = ((heff_dup(v_c_2418) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_c_246, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_c_246, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_2418); c_; }); heff_drop(v_t_2410); c_; }))))) {
            V v_t_2411 = heff_tag_at_n(v_ru_24it_241_24Cons, TAG_Cons, 2, (V[]){v_c_246, NTAG(TAG_Nil)});
            V v_t_2412 = heff_tag_at_n(v_ru_24it2_243_24Cons, TAG_Cons, 2, (V[]){v_a_242, heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, v_t_2411})});
            V v_f_2413 = (g_list_2emap_24s1703643582x349630108(MK_INT(0LL), v_t_2412));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
          } else {
            heff_drop(v_a_242);
            heff_drop_cell(v_ru_24it_241_24Cons, 2);
            heff_drop(v_b_244);
            heff_drop_cell(v_ru_24it2_243_24Cons, 2);
            heff_drop(v_c_246);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_247, 0ULL, 2);
          heff_drop(v_a_242);
          heff_drop_cell(v_ru_24it_241_24Cons, 2);
          heff_drop(v_b_244);
          heff_drop_cell(v_ru_24it2_243_24Cons, 2);
          heff_drop(v_c_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it222_247)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
Clo g_heff_2ebuild_2eproject_2eversion_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eversion_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eversion(V v_v_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eversion(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str1, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str2, 1, "-");

HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    HeffT2 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
    V v_f_246;
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_245 = v_field_244;
        v_f_246 = v_x_245;
      } else {
        heff_drop(v_field_244);
        v_f_246 = NTAG(TAG_Nil);
      }
    }
    return ((HeffT2){{v_f_246, ((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str0)}});
  }
  case TAG_Just: {
    V v_x21_247 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_247)) {
    case TAG_MkPair: {
      V v_time_248 = heff_field(v_x21_247, 0);
      V v_commit_249 = heff_field(v_x21_247, 1);
      V v_t_2410 = heff_strSlice(heff_dup(v_v_240), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str1), v_v_240, MK_INT(0LL), 5));
      HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2410); r_; });
      V v_f_2415;
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2413;
          v_f_2415 = v_x_2414;
        } else {
          heff_drop(v_field_2413);
          v_f_2415 = NTAG(TAG_Nil);
        }
      }
      V v_f_2416 = heff_strAppend(heff_dup(v_time_248), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ekeyFrom_24cpr_str2), heff_dup(v_commit_249)));
      return ((HeffT2){{v_f_2415, v_f_2416}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eisMajorPart_str0, 1, "v");
Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisMajorPart_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisMajorPart(V v_x_240) {
top: ;
  if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    if (heff_strEq_c(heff_strSlice_lent(v_x_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ebuild_2eproject_2eisMajorPart_str0))) {
      V v_s_241 = heff_strSlice(heff_dup(v_x_240), MK_INT(1LL), heff_strLength_lent(v_x_240, 0));
      V v_ret_24bool = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_241, 0))) && ({ V v_t_242 = (g_list_2emap_24f768999161x1997188166(v_s_241, MK_INT(0LL), heff_strLength_lent(v_s_241, 0))); int c_ = ({ V v_c_243 = (g_list_2eall_24s1411948616x47436528(MK_INT(48LL), MK_INT(57LL), v_t_242)); int c_ = ((heff_dup(v_c_243) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_s_241, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_s_241, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_c_243); c_; }); heff_drop(v_t_242); c_; })));
      heff_drop(v_s_241);
      return v_ret_24bool;
    } else {
      return NTAG(TAG_False);
    }
  } else {
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eisMajorPart(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str0, 43, "the project's tests are the modules under `");
HEFF_LIT(g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str1, 1, "`");

HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V v_x_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) == ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
  } else {
    if (((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL)) : 1)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
    } else {
      V v_t_241 = (g_list_2emap_24f768999161x1997188166(v_x_240, MK_INT(0LL), heff_strLength_lent(v_x_240, 0)));
      V v_x1_242 = ({ V a_0 = v_t_241; V r_ = (g_list_2eall_24s494596359x1928238377(a_0)); heff_drop(v_t_241); r_; });
      if (!(heff_dup(v_x1_242) == NTAG(TAG_True))) {
        heff_drop(v_x1_242);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ebuild_2eproject_2enameRule_get())}});
      } else {
        heff_drop(v_x1_242);
        if (heff_strEq_c(heff_dup(v_x_240), heff_dup(g_heff_2ebuild_2eproject_2etestsModule_get()))) {
          V v_f_243 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str0), heff_strAppend(heff_dup(g_heff_2ebuild_2eproject_2etestsModule_get()), ((V)&g_heff_2ebuild_2eproject_2ewhyNoName_24cpr_str1)));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
        } else {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2eproject_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_str1), heff_dup(v_y_245)));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_dup(v_x_241);
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2eproject_2eandList_str2));
        return (g_heff_2ebuild_2eproject_2eandList_24acc(v_x12_242, v_s_2410));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str1, 5, " and ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eandList_24acc_str2, 2, ", ");
Clo g_heff_2ebuild_2eproject_2eandList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eandList_24acc_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eandList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_243)) {
        case TAG_Cons: {
          V v_y_246 = heff_field(v_x12_243, 0);
          V v_t_248 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str1), heff_dup(v_y_246)));
          return heff_strAppend(v_acc_241, v_t_248);
        }
        default: return heff_nomatch(v_x12_243);
        }
      }
      case TAG_Cons: {
        V v_s_2411 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2412 = heff_strAppend(v_s_2411, ((V)&g_heff_2ebuild_2eproject_2eandList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2412;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eandList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eandList_24acc(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_left_243 = heff_take_field(v_f_241, 1);
    V v_name_244 = heff_get_n(v_f_241, 0, 2);
    switch (heff_tag_of(v_left_243)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_left_243, 0ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_244, heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2eproject_2eleftOutNames_24dps(v_rest_242, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_left_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eleftOutNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry, 2, 0};

V g_heff_2ebuild_2eproject_2eleftOutNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_left_244 = heff_take_field(v_f_242, 1);
    V v_name_245 = heff_get_n(v_f_242, 0, 2);
    switch (heff_tag_of(v_left_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_left_244, 0ULL, 1);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_245, heff_hole()});
      V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_243;
      V t_1 = v_cell_247;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_left_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eleftOutNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eleftOutNames_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V v_fields_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x_241)) {
  case TAG_LStr: {
    heff_drop(v_fields_240);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_245 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_245;
      break;
    }
    case TAG_LTag: {
      V v_t_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_247;
      break;
    }
    case TAG_LList: {
      V v_t_249 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_249;
      break;
    }
    case TAG_LRec: {
      V v_t_2411 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2412 = v_t_2411;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2413 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2412, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
  }
  case TAG_LTag: {
    heff_drop(v_fields_240);
    V v_t_2424;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2417 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2417;
      break;
    }
    case TAG_LTag: {
      V v_t_2419 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2419;
      break;
    }
    case TAG_LList: {
      V v_t_2421 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2421;
      break;
    }
    case TAG_LRec: {
      V v_t_2423 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2424 = v_t_2423;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2425 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2424, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
  }
  case TAG_LList: {
    heff_drop(v_fields_240);
    V v_t_2436;
    switch (heff_tag_of(v_x_241)) {
    case TAG_LStr: {
      V v_t_2429 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2429;
      break;
    }
    case TAG_LTag: {
      V v_t_2431 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2431;
      break;
    }
    case TAG_LList: {
      V v_t_2433 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2433;
      break;
    }
    case TAG_LRec: {
      V v_t_2435 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_2436 = v_t_2435;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_f_2437 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2436, 2, 7), ((V)&g_heff_2ebuild_2eproject_2efieldsAre_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
  }
  case TAG_LRec: {
    V v_fs_2438 = heff_field(v_x_241, 0);
    V v_t_2439 = heff_field(v_x_241, 1);
    heff_take_n(v_x_241, 3ULL, 2);
    HeffT2 v_t_2440 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(heff_dup(v_t_2439), heff_dup(v_fields_240), v_fs_2438));
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        heff_drop(v_fields_240);
        heff_drop_rec(v_t_2439, 7);
        V v_xs_2443 = v_field_2442;
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_xs_2443}});
      } else {
        heff_drop(v_field_2442);
        V v_msg_2444 = (g_heff_2ebuild_2eproject_2efieldsSaid(v_fields_240));
        V v_f_2445 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2439, 2, 7), v_msg_2444});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2445}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str0, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str1, 23, "expected a list `[...]`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eitems_24cpr_str2, 23, "expected a list `[...]`");

HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_244;
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_246;
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_248;
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_2410;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
  }
  case TAG_LTag: {
    V v_t_2423;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2416 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2416;
      break;
    }
    case TAG_LTag: {
      V v_t_2418 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2418;
      break;
    }
    case TAG_LList: {
      V v_t_2420 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2420;
      break;
    }
    case TAG_LRec: {
      V v_t_2422 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2423 = v_t_2422;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2424 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2423, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
  }
  case TAG_LList: {
    V v_xs_2425 = heff_field(v_x_240, 0);
    heff_take_n(v_x_240, 1ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_xs_2425}});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2430;
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2432;
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2434;
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2436;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2eitems_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2438}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1, 4, "path");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2, 7, "version");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str2), NTAG(TAG_Nothing)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244})});
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(v_t_245, heff_dup(v_x_240)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_249 = v_field_248;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_249}});
    } else {
      V v_it1_2410 = v_field_248;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_Nil: {
        V v_t_2419;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2412 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2419 = v_t_2412;
          break;
        }
        case TAG_LTag: {
          V v_t_2414 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2419 = v_t_2414;
          break;
        }
        case TAG_LList: {
          V v_t_2416 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2419 = v_t_2416;
          break;
        }
        case TAG_LRec: {
          V v_t_2418 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2419 = v_t_2418;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2419, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str3)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
      }
      case TAG_Cons: {
        V v_n_2421 = heff_field(v_it1_2410, 0);
        V v_it12_2422 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        switch (heff_tag_of(v_it12_2422)) {
        case TAG_Nil: {
          heff_drop(v_n_2421);
          V v_t_2431;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2424 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2431 = v_t_2424;
            break;
          }
          case TAG_LTag: {
            V v_t_2426 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2431 = v_t_2426;
            break;
          }
          case TAG_LList: {
            V v_t_2428 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2431 = v_t_2428;
            break;
          }
          case TAG_LRec: {
            V v_t_2430 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2431 = v_t_2430;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2432 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2431, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str4)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
        }
        case TAG_Cons: {
          V v_p_2433 = heff_field(v_it12_2422, 0);
          V v_it122_2434 = heff_field(v_it12_2422, 1);
          heff_take_n(v_it12_2422, 3ULL, 2);
          switch (heff_tag_of(v_it122_2434)) {
          case TAG_Nil: {
            heff_drop(v_n_2421);
            heff_drop(v_p_2433);
            V v_t_2443;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2436 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2443 = v_t_2436;
              break;
            }
            case TAG_LTag: {
              V v_t_2438 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2443 = v_t_2438;
              break;
            }
            case TAG_LList: {
              V v_t_2440 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2443 = v_t_2440;
              break;
            }
            case TAG_LRec: {
              V v_t_2442 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2443 = v_t_2442;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2444 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2443, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str5)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2444}});
          }
          case TAG_Cons: {
            V v_v_2445 = heff_field(v_it122_2434, 0);
            V v_it1222_2446 = heff_field(v_it122_2434, 1);
            heff_take_n(v_it122_2434, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2446)) {
            case TAG_Nil: {
              heff_drop(v_x_240);
              HeffT2 v_t_2447 = (g_heff_2ebuild_2eproject_2enameOf_24cpr(v_n_2421));
              {
                V v_field_2449 = v_t_2447.f[1];
                int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                if ((v_tag_2448 == ((int64_t)0ULL))) {
                  heff_drop(v_p_2433);
                  heff_drop(v_v_2445);
                  V v_e_2450 = v_field_2449;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2450}});
                } else {
                  V v_name_2451 = v_field_2449;
                  HeffT2 v_t_2452 = (g_heff_2ebuild_2eproject_2erequiredOf_24cpr(v_v_2445));
                  {
                    V v_field_2454 = v_t_2452.f[1];
                    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
                    if ((v_tag_2453 == ((int64_t)0ULL))) {
                      heff_drop(v_p_2433);
                      heff_drop(v_name_2451);
                      V v_e_2455 = v_field_2454;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2455}});
                    } else {
                      V v_ver_2456 = v_field_2454;
                      HeffT2 v_t_2457 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_p_2433)));
                      {
                        V v_field_2459 = v_t_2457.f[1];
                        int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
                        if ((v_tag_2458 == ((int64_t)0ULL))) {
                          heff_drop(v_p_2433);
                          heff_drop(v_name_2451);
                          heff_drop(v_ver_2456);
                          V v_p_2460 = v_field_2459;
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2460}});
                        } else {
                          V v_path_2461 = v_field_2459;
                          HeffT2 v_t_2462 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_2461), heff_dup(v_ver_2456)));
                          {
                            V v_field_2464 = v_t_2462.f[1];
                            int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                            if ((v_tag_2463 == ((int64_t)0ULL))) {
                              heff_drop(v_name_2451);
                              heff_drop(v_ver_2456);
                              heff_drop(v_path_2461);
                              V v_why_2465 = v_field_2464;
                              V v_t_2474;
                              switch (heff_tag_of(v_p_2433)) {
                              case TAG_LStr: {
                                V v_t_2467 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2474 = v_t_2467;
                                break;
                              }
                              case TAG_LTag: {
                                V v_t_2469 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2474 = v_t_2469;
                                break;
                              }
                              case TAG_LList: {
                                V v_t_2471 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2474 = v_t_2471;
                                break;
                              }
                              case TAG_LRec: {
                                V v_t_2473 = heff_field(v_p_2433, 1);
                                heff_take_n(v_p_2433, 2ULL, 2);
                                v_t_2474 = v_t_2473;
                                break;
                              }
                              default: heff_nomatch(v_p_2433);
                              }
                              V v_f_2475 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2474, 2, 7), v_why_2465});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2475}});
                            } else {
                              heff_drop(v_p_2433);
                              heff_drop(v_field_2464);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_name__path__version, (V[]){v_name_2451, v_path_2461, v_ver_2456})}});
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_it1222_2446, 0ULL, 2);
              heff_drop(v_n_2421);
              heff_drop(v_p_2433);
              heff_drop(v_v_2445);
              V v_t_2486;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2479 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2486 = v_t_2479;
                break;
              }
              case TAG_LTag: {
                V v_t_2481 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2486 = v_t_2481;
                break;
              }
              case TAG_LList: {
                V v_t_2483 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2486 = v_t_2483;
                break;
              }
              case TAG_LRec: {
                V v_t_2485 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2486 = v_t_2485;
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_f_2487 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2486, 2, 7), ((V)&g_heff_2ebuild_2eproject_2erequireOf_24cpr_str6)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2487}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it1222_2446)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2434)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2422)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2410)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str1, 3, "dir");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str4, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_243}), heff_dup(v_x_240)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_247 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_247}});
    } else {
      V v_it1_248 = v_field_246;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_Nil: {
        V v_t_2417;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2410 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2417 = v_t_2410;
          break;
        }
        case TAG_LTag: {
          V v_t_2412 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2417 = v_t_2412;
          break;
        }
        case TAG_LList: {
          V v_t_2414 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2417 = v_t_2414;
          break;
        }
        case TAG_LRec: {
          V v_t_2416 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2417 = v_t_2416;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2418 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2417, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str2)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
      }
      case TAG_Cons: {
        V v_n_2419 = heff_field(v_it1_248, 0);
        V v_it12_2420 = heff_field(v_it1_248, 1);
        heff_take_n(v_it1_248, 3ULL, 2);
        switch (heff_tag_of(v_it12_2420)) {
        case TAG_Nil: {
          heff_drop(v_n_2419);
          V v_t_2429;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2422 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2429 = v_t_2422;
            break;
          }
          case TAG_LTag: {
            V v_t_2424 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2429 = v_t_2424;
            break;
          }
          case TAG_LList: {
            V v_t_2426 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2429 = v_t_2426;
            break;
          }
          case TAG_LRec: {
            V v_t_2428 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2429 = v_t_2428;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2430 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2429, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str3)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
        }
        case TAG_Cons: {
          V v_d_2431 = heff_field(v_it12_2420, 0);
          V v_it122_2432 = heff_field(v_it12_2420, 1);
          heff_take_n(v_it12_2420, 3ULL, 2);
          switch (heff_tag_of(v_it122_2432)) {
          case TAG_Nil: {
            heff_drop(v_x_240);
            HeffT2 v_t_2433 = (g_heff_2ebuild_2eproject_2enameOf_24cpr(v_n_2419));
            {
              V v_field_2435 = v_t_2433.f[1];
              int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
              if ((v_tag_2434 == ((int64_t)0ULL))) {
                heff_drop(v_d_2431);
                V v_e_2436 = v_field_2435;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2436}});
              } else {
                V v_name_2437 = v_field_2435;
                HeffT2 v_t_2438 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_d_2431));
                {
                  V v_field_2440 = v_t_2438.f[1];
                  int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                  if ((v_tag_2439 == ((int64_t)0ULL))) {
                    heff_drop(v_name_2437);
                    V v_e_2441 = v_field_2440;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2441}});
                  } else {
                    V v_dir_2442 = v_field_2440;
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(2, shape_name__dir, (V[]){v_name_2437, v_dir_2442})}});
                  }
                }
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2432, 0ULL, 2);
            heff_drop(v_n_2419);
            heff_drop(v_d_2431);
            V v_t_2453;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2446 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2453 = v_t_2446;
              break;
            }
            case TAG_LTag: {
              V v_t_2448 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2453 = v_t_2448;
              break;
            }
            case TAG_LList: {
              V v_t_2450 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2453 = v_t_2450;
              break;
            }
            case TAG_LRec: {
              V v_t_2452 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2453 = v_t_2452;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2454 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2453, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ereplaceOf_24cpr_str4)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2454}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2432)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2420)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_248)}});
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eunrequired_24cpr(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_names_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_n_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eclaimMsg_str0, 143, "error[E0347]: the package `heff` is heff's own, and this is not the checkout heff is built in or was installed from: name the project otherwise");

static V g_heff_2ebuild_2eproject_2eclaimMsg_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2eclaimMsg_st;
static V g_heff_2ebuild_2eproject_2eclaimMsg_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2eclaimMsg_str0);
}
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2eclaimMsg_st)) return g_heff_2ebuild_2eproject_2eclaimMsg_val;
  return heff_global(&g_heff_2ebuild_2eproject_2eclaimMsg_val, &g_heff_2ebuild_2eproject_2eclaimMsg_st, g_heff_2ebuild_2eproject_2eclaimMsg_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1, 19, "` is required twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3, 19, "` is replaced twice");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5, 31, "` is replaced, but not required");

HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s634456687x1151454243(heff_dup(v_rxs_240), heff_dup(v_rs_241)));
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_rxs_240);
      heff_drop(v_rs_241);
      heff_drop(v_pxs_242);
      heff_drop(v_ps_243);
      V v_it1_248 = v_field_247;
      switch (heff_tag_of(v_it1_248)) {
      case TAG_MkPair: {
        V v_n_249 = heff_field(v_it1_248, 0);
        V v_x_2410 = heff_field(v_it1_248, 1);
        heff_take_n(v_it1_248, 3ULL, 2);
        V v_t_2419;
        switch (heff_tag_of(v_x_2410)) {
        case TAG_LStr: {
          V v_t_2412 = heff_field(v_x_2410, 1);
          heff_take_n(v_x_2410, 2ULL, 2);
          v_t_2419 = v_t_2412;
          break;
        }
        case TAG_LTag: {
          V v_t_2414 = heff_field(v_x_2410, 1);
          heff_take_n(v_x_2410, 2ULL, 2);
          v_t_2419 = v_t_2414;
          break;
        }
        case TAG_LList: {
          V v_t_2416 = heff_field(v_x_2410, 1);
          heff_take_n(v_x_2410, 2ULL, 2);
          v_t_2419 = v_t_2416;
          break;
        }
        case TAG_LRec: {
          V v_t_2418 = heff_field(v_x_2410, 1);
          heff_take_n(v_x_2410, 2ULL, 2);
          v_t_2419 = v_t_2418;
          break;
        }
        default: heff_nomatch(v_x_2410);
        }
        V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str0), heff_strAppend(v_n_249, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str1)));
        V v_f_2421 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2419, 2, 7), v_t_2420});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_248)}});
      }
    } else {
      heff_drop(v_field_247);
      V v_t_2422 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
      HeffT2 v_t_2423 = (g_heff_2ebuild_2eproject_2etwiceGo_24cpr(NTAG(TAG_Nil), v_t_2422));
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          heff_drop(v_rxs_240);
          heff_drop(v_rs_241);
          heff_drop(v_pxs_242);
          heff_drop(v_ps_243);
          V v_it1_2426 = v_field_2425;
          switch (heff_tag_of(v_it1_2426)) {
          case TAG_MkPair: {
            V v_n_2427 = heff_field(v_it1_2426, 0);
            V v_x_2428 = heff_field(v_it1_2426, 1);
            heff_take_n(v_it1_2426, 3ULL, 2);
            V v_t_2437;
            switch (heff_tag_of(v_x_2428)) {
            case TAG_LStr: {
              V v_t_2430 = heff_field(v_x_2428, 1);
              heff_take_n(v_x_2428, 2ULL, 2);
              v_t_2437 = v_t_2430;
              break;
            }
            case TAG_LTag: {
              V v_t_2432 = heff_field(v_x_2428, 1);
              heff_take_n(v_x_2428, 2ULL, 2);
              v_t_2437 = v_t_2432;
              break;
            }
            case TAG_LList: {
              V v_t_2434 = heff_field(v_x_2428, 1);
              heff_take_n(v_x_2428, 2ULL, 2);
              v_t_2437 = v_t_2434;
              break;
            }
            case TAG_LRec: {
              V v_t_2436 = heff_field(v_x_2428, 1);
              heff_take_n(v_x_2428, 2ULL, 2);
              v_t_2437 = v_t_2436;
              break;
            }
            default: heff_nomatch(v_x_2428);
            }
            V v_t_2438 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str2), heff_strAppend(v_n_2427, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str3)));
            V v_f_2439 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), v_t_2438});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2439}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2426)}});
          }
        } else {
          heff_drop(v_field_2425);
          V v_t_2440 = (g_list_2emap_24s1791433880x1360378684(heff_dup(v_rs_241)));
          V v_t_2441 = (g_list_2ezipWith_24s1958630276x749154843(heff_dup(v_pxs_242), heff_dup(v_ps_243)));
          HeffT2 v_t_2442 = ({ V a_0 = v_t_2440; V a_1 = v_t_2441; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eunrequired_24cpr(a_0, a_1)); heff_drop(v_t_2440); r_; });
          {
            V v_field_2444 = v_t_2442.f[1];
            int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
            if ((v_tag_2443 == ((int64_t)0ULL))) {
              heff_drop(v_rxs_240);
              heff_drop(v_rs_241);
              heff_drop(v_pxs_242);
              heff_drop(v_ps_243);
              V v_it1_2445 = v_field_2444;
              switch (heff_tag_of(v_it1_2445)) {
              case TAG_MkPair: {
                V v_n_2446 = heff_field(v_it1_2445, 0);
                V v_x_2447 = heff_field(v_it1_2445, 1);
                heff_take_n(v_it1_2445, 3ULL, 2);
                V v_t_2456;
                switch (heff_tag_of(v_x_2447)) {
                case TAG_LStr: {
                  V v_t_2449 = heff_field(v_x_2447, 1);
                  heff_take_n(v_x_2447, 2ULL, 2);
                  v_t_2456 = v_t_2449;
                  break;
                }
                case TAG_LTag: {
                  V v_t_2451 = heff_field(v_x_2447, 1);
                  heff_take_n(v_x_2447, 2ULL, 2);
                  v_t_2456 = v_t_2451;
                  break;
                }
                case TAG_LList: {
                  V v_t_2453 = heff_field(v_x_2447, 1);
                  heff_take_n(v_x_2447, 2ULL, 2);
                  v_t_2456 = v_t_2453;
                  break;
                }
                case TAG_LRec: {
                  V v_t_2455 = heff_field(v_x_2447, 1);
                  heff_take_n(v_x_2447, 2ULL, 2);
                  v_t_2456 = v_t_2455;
                  break;
                }
                default: heff_nomatch(v_x_2447);
                }
                V v_t_2457 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str4), heff_strAppend(v_n_2446, ((V)&g_heff_2ebuild_2eproject_2echeckNames_24cpr_str5)));
                V v_f_2458 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2456, 2, 7), v_t_2457});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2458}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it1_2445)}});
              }
            } else {
              heff_drop(v_field_2444);
              HEFF_LAST return g_heff_2ebuild_2eproject_2echeckHeff_24cpr(v_rxs_240, v_rs_241, v_pxs_242, v_ps_243);
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2ereplaceOf_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(v_rest_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_field_248);
          V v_p_249 = v_field_245;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_249}});
        } else {
          V v_y_2410 = v_field_245;
          if ((v_tag_247 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_y_2410);
            V v_p_2411 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2411}});
          } else {
            V v_ys_2412 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_2410, v_ys_2412})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str1, 45, "` is no version: write `a.b.c`, three numbers");

HeffT2 g_heff_2ebuild_2eproject_2epackageOf4_24cpr(V v_m_240, V v_h_241, V v_rq_242, V v_rp_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_m_240));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_h_241);
      heff_drop(v_rq_242);
      heff_drop(v_rp_243);
      V v_p_247 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_247}});
    } else {
      V v_mpath_248 = v_field_246;
      HeffT2 v_t_249 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_h_241)));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop(v_h_241);
          heff_drop(v_rq_242);
          heff_drop(v_rp_243);
          heff_drop(v_mpath_248);
          V v_p_2412 = v_field_2411;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2412}});
        } else {
          V v_v_2413 = v_field_2411;
          HeffT2 v_t_2414 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              heff_drop(v_h_241);
              V v_x_2417 = v_field_2416;
              heff_drop(v_x_2417);
              HeffT2 v_t_2418 = (g_heff_2ebuild_2eproject_2eitems_24cpr(v_rq_242));
              {
                V v_field_2420 = v_t_2418.f[1];
                int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                if ((v_tag_2419 == ((int64_t)0ULL))) {
                  heff_drop(v_rp_243);
                  heff_drop(v_mpath_248);
                  heff_drop(v_v_2413);
                  V v_p_2421 = v_field_2420;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2421}});
                } else {
                  V v_rxs_2422 = v_field_2420;
                  HeffT2 v_t_2423 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(heff_dup(v_rxs_2422)));
                  {
                    V v_field_2425 = v_t_2423.f[1];
                    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                    if ((v_tag_2424 == ((int64_t)0ULL))) {
                      heff_drop(v_rp_243);
                      heff_drop(v_mpath_248);
                      heff_drop(v_v_2413);
                      heff_drop(v_rxs_2422);
                      V v_p_2426 = v_field_2425;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2426}});
                    } else {
                      V v_rs_2427 = v_field_2425;
                      HeffT2 v_t_2428 = (g_heff_2ebuild_2eproject_2eitems_24cpr(v_rp_243));
                      {
                        V v_field_2430 = v_t_2428.f[1];
                        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                        if ((v_tag_2429 == ((int64_t)0ULL))) {
                          heff_drop(v_mpath_248);
                          heff_drop(v_v_2413);
                          heff_drop(v_rxs_2422);
                          heff_drop(v_rs_2427);
                          V v_p_2431 = v_field_2430;
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2431}});
                        } else {
                          V v_pxs_2432 = v_field_2430;
                          HeffT2 v_t_2433 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(heff_dup(v_pxs_2432)));
                          {
                            V v_field_2435 = v_t_2433.f[1];
                            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                            if ((v_tag_2434 == ((int64_t)0ULL))) {
                              heff_drop(v_mpath_248);
                              heff_drop(v_v_2413);
                              heff_drop(v_rxs_2422);
                              heff_drop(v_rs_2427);
                              heff_drop(v_pxs_2432);
                              V v_p_2436 = v_field_2435;
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2436}});
                            } else {
                              V v_ps_2437 = v_field_2435;
                              HeffT2 v_t_2438 = (g_heff_2ebuild_2eproject_2echeckNames_24cpr(v_rxs_2422, heff_dup(v_rs_2427), v_pxs_2432, heff_dup(v_ps_2437)));
                              {
                                V v_field_2440 = v_t_2438.f[1];
                                int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                                if ((v_tag_2439 == ((int64_t)0ULL))) {
                                  heff_drop(v_mpath_248);
                                  heff_drop(v_v_2413);
                                  heff_drop(v_rs_2427);
                                  heff_drop(v_ps_2437);
                                  V v_p_2441 = v_field_2440;
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2441}});
                                } else {
                                  V v_x_2442 = v_field_2440;
                                  heff_drop(v_x_2442);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(4, shape_module__heff__require__replace, (V[]){v_mpath_248, v_v_2413, v_rs_2427, v_ps_2437})}});
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              heff_drop(v_rq_242);
              heff_drop(v_rp_243);
              heff_drop(v_mpath_248);
              heff_drop(v_field_2416);
              V v_t_2451;
              switch (heff_tag_of(v_h_241)) {
              case TAG_LStr: {
                V v_t_2444 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2451 = v_t_2444;
                break;
              }
              case TAG_LTag: {
                V v_t_2446 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2451 = v_t_2446;
                break;
              }
              case TAG_LList: {
                V v_t_2448 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2451 = v_t_2448;
                break;
              }
              case TAG_LRec: {
                V v_t_2450 = heff_field(v_h_241, 1);
                heff_take_n(v_h_241, 2ULL, 2);
                v_t_2451 = v_t_2450;
                break;
              }
              default: heff_nomatch(v_h_241);
              }
              V v_t_2452 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str0), heff_strAppend(v_v_2413, ((V)&g_heff_2ebuild_2eproject_2epackageOf4_24cpr_str1)));
              V v_f_2453 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2451, 2, 7), v_t_2452});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2453}});
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str0, 6, "module");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str1, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str2, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageFields_str3, 7, "replace");
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam0, 1, 0};
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args); static Clo g_heff_2ebuild_2eproject_2epackageFields_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageFields_lam1, 1, 0};

static V g_heff_2ebuild_2eproject_2epackageFields_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2epackageFields_st;
static V g_heff_2ebuild_2eproject_2epackageFields_init(void) {
  V v_t_240 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str0), NTAG(TAG_Nothing)});
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam0_clo)})});
  V v_t_245 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_str3), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2epackageFields_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_246})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_247});
}
V g_heff_2ebuild_2eproject_2epackageFields_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2epackageFields_st)) return g_heff_2ebuild_2eproject_2epackageFields_val;
  return heff_global(&g_heff_2ebuild_2eproject_2epackageFields_val, &g_heff_2ebuild_2eproject_2epackageFields_st, g_heff_2ebuild_2eproject_2epackageFields_init);
}
V g_heff_2ebuild_2eproject_2epackageFields_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_242});
}
V g_heff_2ebuild_2eproject_2epackageFields_lam1(V self, V *args) {
  V v_t_244 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_244});
}
Clo g_heff_2ebuild_2eproject_2epackageOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epackageOf(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2epackageOf(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eclaimOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eclaimOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eclaimOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Left: {
    return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
  }
  case TAG_Right: {
    V v_x_242 = heff_field(v_x1_240, 0);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()), heff_dup(v_x_242)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        heff_drop(v_x_246);
        return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
      } else {
        V v_x11_247 = v_field_245;
        switch (heff_tag_of(v_x11_247)) {
        case TAG_Nil: {
          return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
        }
        case TAG_Cons: {
          V v_m_248 = heff_field(v_x11_247, 0);
          heff_take_n(v_x11_247, 1ULL, 2);
          V v_t_2418;
          switch (heff_tag_of(v_m_248)) {
          case TAG_LStr: {
            V v_t_2411 = heff_field(v_m_248, 1);
            heff_take_n(v_m_248, 2ULL, 2);
            v_t_2418 = v_t_2411;
            break;
          }
          case TAG_LTag: {
            V v_t_2413 = heff_field(v_m_248, 1);
            heff_take_n(v_m_248, 2ULL, 2);
            v_t_2418 = v_t_2413;
            break;
          }
          case TAG_LList: {
            V v_t_2415 = heff_field(v_m_248, 1);
            heff_take_n(v_m_248, 2ULL, 2);
            v_t_2418 = v_t_2415;
            break;
          }
          case TAG_LRec: {
            V v_t_2417 = heff_field(v_m_248, 1);
            heff_take_n(v_m_248, 2ULL, 2);
            v_t_2418 = v_t_2417;
            break;
          }
          default: heff_nomatch(v_m_248);
          }
          return heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2418, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
        }
        default: return heff_nomatch(v_x11_247);
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2eclaimOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eclaimOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str0, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str1, 72, "a program ships no `bin`: the heff home's bin/ is where the programs are");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str6, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str8, 92, "` is not a name: a program ships files and directories of the project's root, by their names");

HeffT2 g_heff_2ebuild_2eproject_2eshipWrong_24cpr(V v_n_240) {
top: ;
  if (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str0), 2)) {
    heff_drop(v_n_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str1)}});
  } else {
    if ((heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str2), 2) || (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str3), 2) || (heff_strEq_c_lent(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str4), 2) || (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str5), v_n_240, MK_INT(0LL), 5)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str6), v_n_240, MK_INT(0LL), 5))))))) {
      V v_f_241 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str7), heff_strAppend(v_n_240, ((V)&g_heff_2ebuild_2eproject_2eshipWrong_24cpr_str8)));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_241}});
    } else {
      heff_drop(v_n_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_x_241)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_241);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_p_246 = v_field_245;
        V v_x2_247 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
        heff_drop(v_x2_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_246}});
      } else {
        V v_n_248 = v_field_245;
        HeffT2 v_t_249 = (g_heff_2ebuild_2eproject_2eshipWrong_24cpr(heff_dup(v_n_248)));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_n_248);
            V v_why_2412 = v_field_2411;
            V v_x2_2413 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(v_rest_242));
            heff_drop(v_x2_2413);
            V v_t_2422;
            switch (heff_tag_of(v_x_241)) {
            case TAG_LStr: {
              V v_t_2415 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2422 = v_t_2415;
              break;
            }
            case TAG_LTag: {
              V v_t_2417 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2422 = v_t_2417;
              break;
            }
            case TAG_LList: {
              V v_t_2419 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2422 = v_t_2419;
              break;
            }
            case TAG_LRec: {
              V v_t_2421 = heff_field(v_x_241, 1);
              heff_take_n(v_x_241, 2ULL, 2);
              v_t_2422 = v_t_2421;
              break;
            }
            default: heff_nomatch(v_x_241);
            }
            V v_f_2423 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2422, 2, 7), v_why_2412});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
          } else {
            heff_drop(v_x_241);
            heff_drop(v_field_2411);
            HeffT2 v_t_2424 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_rest_242));
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              if ((v_tag_2425 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop(v_n_248);
                V v_p_2427 = v_field_2426;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2427}});
              } else {
                V v_ys_2428 = v_field_2426;
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_n_248, v_ys_2428})}});
              }
            }
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str1, 5, "build");

HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_242 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_244 = v_t_242.f[1];
    heff_drop(v_t_242.f[0]);
    heff_drop(v_t_242.f[2]);
    switch (heff_tag_of(v_field_244)) {
    case TAG_Nil: {
      V v_t_246 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      HeffT3 v_t_247 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_246, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2411;
      {
        V v_field_248 = v_t_247.f[0];
        heff_drop(v_t_247.f[1]);
        heff_drop(v_t_247.f[2]);
        v_t_2411 = v_field_248;
      }
      HeffT2 v_t_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eproject_2ereadBuild_24cpr_str1); V b_2 = heff_arrayFromList(v_t_2411); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_p_2415 = v_field_2414;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2415}});
        } else {
          V v_x_2416 = v_field_2414;
          HEFF_LAST return g_heff_2ebuild_2eproject_2ebuildOf_24cpr(v_x_2416);
        }
      }
    }
    case TAG_Cons: {
      V v_e_2417 = heff_field(v_field_244, 0);
      heff_take_n(v_field_244, 1ULL, 2);
      V v_start_2419 = heff_take_field(v_e_2417, 0);
      V v_msg_2420 = heff_get_n(v_e_2417, 2, 3);
      V v_f_2421 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2419, v_msg_2420});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
    }
    default: return ((HeffT2){{heff_nomatch(v_field_244)}});
    }
  }
}
Clo g_heff_2ebuild_2eproject_2enewerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewerGo_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewerGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      if (heff_intLt_c_lent(v_y_244, v_x_242, 0)) {
        return NTAG(TAG_True);
      } else {
        if (heff_intEq_c_lent(v_x_242, v_y_244, 0)) {
          V t_0 = v_xs_243;
          V t_1 = v_ys_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2enewerGo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2erepoOf_str3, 1, "/");
Clo g_heff_2ebuild_2eproject_2erepoOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erepoOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2erepoOf(V v_path_240) {
top: ;
  V v_xs_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2erepoOf_str0); V a_1 = v_path_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str1), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_t_245;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    v_t_245 = heff_dup(v_path_240);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ebuild_2eproject_2eisMajorPart(a_0)); heff_drop(v_t_245); r_; });
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_xs_247 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2erepoOf_str2); V a_1 = v_path_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2erepoOf_str3), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nil: {
      v_t_2411 = heff_dup(v_path_240);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 2);
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_240, 0)) - heff_unbox_word(heff_strLength(v_t_2411)));
    return heff_strSlice(v_path_240, MK_INT(0LL), heff_box_word((v_t_2412 - ((int64_t)1ULL))));
  } else {
    heff_drop(v_t_246);
    return v_path_240;
  }
}
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erepoOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str0, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str1, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str2, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str5, 30, "` is no version: write `a.b.c`");
HEFF_LIT(g_heff_2ebuild_2eproject_2esumLine_24cpr_str6, 68, "a line of heff.sum is a path, a version and a tree, and nothing else");

HeffT2 g_heff_2ebuild_2eproject_2esumLine_24cpr(V v_at_240, V v_line_241) {
top: ;
  V v_it_242 = (g_prelude_2ewordsFrom(v_line_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_it_242, 0);
    V v_it2_244 = heff_field(v_it_242, 1);
    V v_ru_24it_242_24Cons = heff_take_reuse_n(v_it_242, 3ULL, 2);
    switch (heff_tag_of(v_it2_244)) {
    case TAG_Nil: {
      heff_drop(v_p_243);
      heff_drop_cell(v_ru_24it_242_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str0)})}});
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_it2_244, 0);
      V v_it22_246 = heff_field(v_it2_244, 1);
      heff_take_n(v_it2_244, 3ULL, 2);
      switch (heff_tag_of(v_it22_246)) {
      case TAG_Nil: {
        heff_drop(v_p_243);
        heff_drop_cell(v_ru_24it_242_24Cons, 2);
        heff_drop(v_v_245);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str1)})}});
      }
      case TAG_Cons: {
        V v_h_247 = heff_field(v_it22_246, 0);
        V v_it222_248 = heff_field(v_it22_246, 1);
        heff_take_n(v_it22_246, 3ULL, 2);
        switch (heff_tag_of(v_it222_248)) {
        case TAG_Nil: {
          V v_t_249 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str2); V a_1 = v_v_245; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str3), v_v_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2410 = (g_heff_2ebuild_2eproject_2epseudoParts(v_t_249));
          HeffT2 v_t_2411 = ({ V a_0 = v_v_245; V a_1 = v_t_2410; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
          V v_t_2416;
          {
            V v_field_2412 = v_t_2411.f[0];
            V v_field_2413 = v_t_2411.f[1];
            V v_x_2414 = v_field_2412;
            V v_y_2415 = v_field_2413;
            heff_drop(v_y_2415);
            v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
          }
          if (heff_intEq_c(v_t_2416, MK_INT(3LL))) {
            heff_drop(v_at_240);
            V v_t_2417 = heff_tag_at_n(v_ru_24it_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_p_243, v_v_245, v_h_247}), NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2417}});
          } else {
            heff_drop(v_p_243);
            heff_drop_cell(v_ru_24it_242_24Cons, 2);
            heff_drop(v_h_247);
            V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str4), heff_strAppend(v_v_245, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str5)));
            V v_f_2419 = heff_rec_n(2, shape_at__msg, (V[]){v_at_240, v_t_2418});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_248, 0ULL, 2);
          heff_drop(v_p_243);
          heff_drop_cell(v_ru_24it_242_24Cons, 2);
          heff_drop(v_v_245);
          heff_drop(v_h_247);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_at_240, ((V)&g_heff_2ebuild_2eproject_2esumLine_24cpr_str6)})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it222_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_242)}});
  }
}

HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2esumLine_24cpr(heff_dup(v_at_240), v_l_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_at_240);
        heff_drop(v_l_242);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_p_247 = v_field_246;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_247}});
      } else {
        V v_xs_248 = v_field_246;
        V v_t_249 = heff_intAdd(v_at_240, heff_strLength(v_l_242));
        HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(heff_intAdd(v_t_249, MK_INT(1LL)), v_rest_243));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_xs_248);
            V v_x_2413 = v_field_2412;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2413}});
          } else {
            V v_y_2414 = v_field_2412;
            V v_f_2415 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_241_24Cons, v_xs_248, v_y_2414));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2415}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str1, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str2, 7, "package");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str3, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2espanGo_24cpr_str4, 1, "=");

HeffT2 g_heff_2ebuild_2eproject_2espanGo_24cpr(V v_ts_240, V v_i_241) {
top: ;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_i_241, 1) && heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0)))) {
    V v_t_242 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
    V v_kind_243 = heff_take_field(v_t_242, 0);
    V v_text_244 = heff_get_n(v_t_242, 1, 7);
    if (heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str0), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_kind_243);
      heff_drop(v_text_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      if (heff_strEq_c(v_kind_243, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str1))) {
        if (heff_strEq_c(v_text_244, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str2))) {
          int64_t v_i_245 = (heff_peek_word(v_i_241) + ((int64_t)1ULL));
          if (((((int64_t)0ULL) <= v_i_245) && (v_i_245 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
            V v_t_246 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_245), 2);
            V v_kind_247 = heff_take_field(v_t_246, 0);
            V v_text_248 = heff_get_n(v_t_246, 1, 7);
            if ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str3), 2) && heff_strEq_c_lent(v_text_248, ((V)&g_heff_2ebuild_2eproject_2espanGo_24cpr_str4), 2))) {
              heff_drop(v_kind_247);
              heff_drop(v_text_248);
              HeffT2 v_t_249 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_240, heff_intAdd(heff_dup(v_i_241), MK_INT(2LL))));
              {
                V v_field_2411 = v_t_249.f[1];
                int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
                if ((v_tag_2410 == ((int64_t)0ULL))) {
                  heff_drop(v_i_241);
                  V v_it1_2412 = v_field_2411;
                  heff_drop(v_it1_2412);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                } else {
                  V v_it1_2413 = v_field_2411;
                  switch (heff_tag_of(v_it1_2413)) {
                  case TAG_MkPair: {
                    V v_j_2415 = heff_field(v_it1_2413, 1);
                    V v_ru_24it1_2413_24MkPair = heff_take_reuse_n(v_it1_2413, 2ULL, 2);
                    V v_i_2416 = heff_intAdd(v_i_241, MK_INT(2LL));
                    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2416, 1) && heff_intLt_c(heff_dup(v_i_2416), heff_arrayLength_lent(v_ts_240, 0)))) {
                      V v_opening_2417 = heff_arrayIndex_lent(v_ts_240, v_i_2416, 2);
                      V v_i_2418 = heff_intSub(v_j_2415, MK_INT(1LL));
                      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2418, 1) && heff_intLt_c(heff_dup(v_i_2418), heff_arrayLength_lent(v_ts_240, 0)))) {
                        V v_closing_2419 = heff_arrayIndex_lent(v_ts_240, v_i_2418, 2);
                        V v_f_2420 = heff_tag_at_n(v_ru_24it1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_opening_2417, 2, 7), heff_get_n(v_closing_2419, 3, 7)});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
                      } else {
                        heff_drop_cell(v_ru_24it1_2413_24MkPair, 2);
                        heff_drop_rec(v_opening_2417, 7);
                        heff_drop(v_i_2418);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    } else {
                      heff_drop(v_j_2415);
                      heff_drop_cell(v_ru_24it1_2413_24MkPair, 2);
                      heff_drop(v_i_2416);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_it1_2413)}});
                  }
                }
              }
            } else {
              heff_drop(v_kind_247);
              heff_drop(v_text_248);
              V v_t_2421 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
              V t_0 = v_ts_240;
              V t_1 = v_t_2421;
              v_ts_240 = t_0;
              v_i_241 = t_1;
              goto top;
            }
          } else {
            V v_t_2422 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
            V t_0 = v_ts_240;
            V t_1 = v_t_2422;
            v_ts_240 = t_0;
            v_i_241 = t_1;
            goto top;
          }
        } else {
          V v_t_2423 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
          V t_0 = v_ts_240;
          V t_1 = v_t_2423;
          v_ts_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
      } else {
        heff_drop(v_text_244);
        V v_t_2424 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)))));
        V t_0 = v_ts_240;
        V t_1 = v_t_2424;
        v_ts_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  } else {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
Clo g_heff_2ebuild_2eproject_2ewithPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ewithPackage_entry, 2, 0};

V g_heff_2ebuild_2eproject_2ewithPackage(V v_src_240, V v_pk_241) {
top: ;
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_247;
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    v_t_247 = v_field_244;
  }
  HeffT2 v_t_248 = ({ V b_0 = heff_arrayFromList(v_t_247); V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2eproject_2espanGo_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_it1_2411 = v_field_2410;
      switch (heff_tag_of(v_it1_2411)) {
      case TAG_MkPair: {
        V v_from_2412 = heff_field(v_it1_2411, 0);
        V v_to_2413 = heff_field(v_it1_2411, 1);
        heff_take_n(v_it1_2411, 3ULL, 2);
        V v_t_2414 = (g_heff_2ebuild_2eproject_2eshowPackage(v_pk_241));
        V v_t_2415 = heff_strSlice(heff_dup(v_src_240), v_to_2413, heff_strLength_lent(v_src_240, 0));
        return heff_strAppend(heff_strSlice(v_src_240, MK_INT(0LL), v_from_2412), heff_strAppend(v_t_2414, v_t_2415));
      }
      default: return heff_nomatch(v_it1_2411);
      }
    } else {
      heff_drop(v_pk_241);
      heff_drop(v_field_2410);
      return v_src_240;
    }
  }
}
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2ewithPackage(a[0], a[1]);
}