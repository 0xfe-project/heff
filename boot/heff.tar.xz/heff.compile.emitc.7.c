// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define LBL_arg 306384
#define LBL_arity 294440695
#define LBL_defs 9574869
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_lams 9809570
#define LBL_lprotos 613175609
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_shapes 1043573789
#define LBL_source 1050636102
#define LBL_strs 10036521
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
V g_heff_2ecompile_2eemitc_2eargC(V, V, V);
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargC_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V, V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2egetterOf(V, V);
V g_heff_2ecompile_2eemitc_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egetterOf_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2epartCount(V, V);
V g_heff_2ecompile_2eemitc_2epartCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartCount_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
V g_heff_2ecompile_2eemitc_2eshapeLit(V, V);
V g_heff_2ecompile_2eemitc_2eshapeLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeLit_clo;
V g_heff_2ecompile_2eemitc_2etakeLines(V, V);
V g_heff_2ecompile_2eemitc_2etakeLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etakeLines_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2emap_24f1801471045x554404499(V, V, V, V);
V g_list_2emap_24f1801471045x554404499_entry(V self, V *a);
extern Clo g_list_2emap_24f1801471045x554404499_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s577269653x49010166(V);
V g_list_2emap_24s577269653x49010166_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1814128165x1680687847(V, V, V, V, V);
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1814128165x1680687847_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2eemitc_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemS(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_str1, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_str3, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_str4, 6, "shape_");
Clo g_heff_2ecompile_2eemitc_2eshapeLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eshapeLit(V v_ls_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s420582357x1720502382(heff_dup(v_ls_240)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_o_246 = heff_dup(heff_rfield(v_s_241, 0));
  V v_x2_247 = (g_list_2emap_24s420582357x1720502382(v_ls_240));
  V v_k_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_k_2410 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_k_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_ps_2411 = heff_take_field(v_s_241, 6);
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2eownHas(heff_dup(v_o_246), heff_dup(v_k_2410), v_ps_2411));
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_o_246);
    heff_drop(v_k_2410);
    heff_drop(v_t_2412);
    v_t_2413 = v_ps_2411;
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_246, v_k_2410}), v_ps_2411});
  }
  V v_t_2414 = ({ V rv_6 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_241, 191ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 53247u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeLit_str4), v_t_245), v_t_2414});
}
V g_heff_2ecompile_2eemitc_2eshapeLit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeLit(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str0, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str1, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str3, 4, "V a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str4, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str5, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str6, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str7, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str8, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str9, 3, " a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str11, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str12, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str13, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str14, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str15, 4, "V a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str16, 2, "b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str17, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str18, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str19, 4, "V b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str20, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str21, 12, "heff_drop(b_");
V g_heff_2ecompile_2eemitc_2eargC_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eargC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargC_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eargC(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Given: {
    V v_e_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_m_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_243}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam0, 1, 2, (V[]){v_m_244, v_i_241});
  }
  case TAG_GivenU: {
    V v_r_2414 = heff_field(v_x3_242, 0);
    V v_e_2415 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_2416 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2415}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam1, 1, 3, (V[]){v_m_2416, v_i_241, v_r_2414});
  }
  case TAG_LentVar: {
    V v_x_2429 = heff_field(v_x3_242, 0);
    V v_drops_2430 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    heff_drop_rec(v_k_240, 3);
    V v_t_2431 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2429, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eargC_str10)));
    V v_v_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str11), v_t_2431);
    V v_post_2433 = (g_list_2emap_24s577269653x49010166(v_drops_2430));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam2, 1, 3, (V[]){v_i_241, v_v_2432, v_post_2433});
  }
  case TAG_LentValue: {
    V v_e_2439 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2439}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam3, 1, 2, (V[]){v_m_2440, v_i_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eargC(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eargC_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str0), heff_intShow(heff_dup(v_i_241)));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str1), heff_strAppend(v_x_247, ((V)&g_heff_2ecompile_2eemitc_2eargC_str2)));
    V v_t_2411 = heff_strAppend(heff_intShow(v_i_241), v_t_2410);
    V v_t_2412 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str3), v_t_2411), NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_249, v_t_2412, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_r_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str4), heff_intShow(heff_dup(v_i_241)));
    V v_t_2423;
    switch (heff_tag_of(v_r_2414)) {
    case TAG_RepV: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str5);
      break;
    }
    case TAG_RepFix: {
      V v_w_2422 = heff_field(v_r_2414, 0);
      heff_take_n(v_r_2414, 1ULL, 1);
      v_t_2423 = ({ V a_0 = v_w_2422; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2422); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str6);
      break;
    }
    default: heff_nomatch(v_r_2414);
    }
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str7), heff_strAppend(v_x_2419, ((V)&g_heff_2ecompile_2eemitc_2eargC_str8)));
    V v_t_2425 = heff_strAppend(heff_intShow(v_i_241), v_t_2424);
    V v_t_2426 = heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str9), v_t_2425));
    V v_t_2427 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
    V v_x_2428 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2421, v_t_2427, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_lam2(V self, V *args) {
  V v_s_2434 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_v_2432 = heff_env(self)[1];
  V v_post_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str12), heff_intShow(heff_dup(v_i_241)));
  V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str13), heff_strAppend(v_v_2432, ((V)&g_heff_2ecompile_2eemitc_2eargC_str14)));
  V v_t_2437 = heff_strAppend(heff_intShow(v_i_241), v_t_2436);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str15), v_t_2437), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2435, v_t_2438, v_post_2433}), v_s_2434});
}
V g_heff_2ecompile_2eemitc_2eargC_lam3(V self, V *args) {
  V v_s_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_s_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str16), heff_intShow(heff_dup(v_i_241)));
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str17), heff_strAppend(v_x_2443, ((V)&g_heff_2ecompile_2eemitc_2eargC_str18)));
    V v_t_2447 = heff_strAppend(heff_intShow(heff_dup(v_i_241)), v_t_2446);
    V v_t_2448 = heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str19), v_t_2447), NTAG(TAG_Nil)});
    V v_t_2449 = heff_strAppend(heff_intShow(v_i_241), ((V)&g_heff_2ecompile_2eemitc_2eargC_str20));
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str21), v_t_2449), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2445, v_t_2448, v_t_2450}), v_s_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str1, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str3, 10, "heff_room[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str4, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str6, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str7, 62, ", heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str8, 10, "heff_room[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str9, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str12, 8, ", (V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str13, 3, "});");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str14, 21, "return heff_tail(f_, ");
Clo g_heff_2ecompile_2eemitc_2eroomed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eroomed_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eroomed(V v_vs_240) {
top: ;
  V v_x2_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_x2_243 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_vs_240, 0));
    v_x2_243 = heff_tag_n(TAG_Just, 1, (V[]){v_x_241});
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eroomed_str2)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2edrop(MK_INT(1LL), heff_dup(v_vs_240)));
  V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(2LL))));
  V v_t_2411 = (g_list_2ezipWith_24s1814128165x1680687847(((V)&g_heff_2ecompile_2eemitc_2eroomed_str3), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str4), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str5), v_t_248, v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2413 = heff_intShow(heff_intSub(v_t_2412, MK_INT(1LL)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2eroomed_str7)));
  V v_t_2415 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2416 = heff_intShow(heff_intSub(v_t_2415, MK_INT(1LL)));
  V v_t_2417 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_240); r_; });
  V v_x2_2418 = (g_list_2emap_24f1801471045x554404499(((V)&g_heff_2ecompile_2eemitc_2eroomed_str8), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str9), MK_INT(0LL), heff_intSub(v_t_2417, MK_INT(2LL))));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str11); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str12), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2eroomed_str13)));
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str14), heff_strAppend(v_t_2416, v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2424})));
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2425));
}
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eroomed(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str3, 11, "heff_field(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str4, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str6, 20, "heff_dup(heff_field(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str7, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str8, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str9, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efieldLine_str10, 4, "  V ");
Clo g_heff_2ecompile_2eemitc_2efieldLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efieldLine_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2efieldLine(V v_sv_240, V v_plain_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_i_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_v_243), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str0)));
    V v_t_2410;
    if ((heff_dup(v_plain_241) == NTAG(TAG_True))) {
      V v_t_246 = heff_strAppend(heff_intShow(heff_dup(v_i_244)), ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str1));
      V v_t_247 = heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str2), v_t_246));
      v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str3), v_t_247);
    } else {
      V v_t_248 = heff_strAppend(heff_intShow(heff_dup(v_i_244)), ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str4));
      V v_t_249 = heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str5), v_t_248));
      v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str6), v_t_249);
    }
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str7), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2efieldLine_str8)));
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str9), v_t_245), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efieldLine_str10), v_t_2412);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2efieldLine(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str0, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str1, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str3, 12, "heff_take_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str5, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str6, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str7, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str8, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str9, 21, " = heff_take_reuse_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etakeLines_str10, 2, "V ");
Clo g_heff_2ecompile_2eemitc_2etakeLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etakeLines_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etakeLines(V v_sv_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_TakeNone: {
    heff_drop(v_sv_240);
    return NTAG(TAG_Nil);
  }
  case TAG_TakeN: {
    V v_mask_242 = heff_field(v_x2_241, 0);
    V v_n_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24TakeN = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_intShow(v_n_243), ((V)&g_heff_2ecompile_2eemitc_2etakeLines_str0));
    V v_t_245 = heff_strAppend(heff_intShow(v_mask_242), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str1), v_t_244));
    V v_t_246 = heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str2), v_t_245));
    return heff_tag_at_n(v_ru_24x2_241_24TakeN, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str3), v_t_246), NTAG(TAG_Nil)});
  }
  case TAG_TakeKeep: {
    V v_ru_247 = heff_field(v_x2_241, 0);
    V v_mask_248 = heff_field(v_x2_241, 1);
    V v_n_249 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2emangleW(v_ru_247, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etakeLines_str4)));
    V v_t_2411 = heff_strAppend(heff_intShow(v_n_249), ((V)&g_heff_2ecompile_2eemitc_2etakeLines_str5));
    V v_t_2412 = heff_strAppend(heff_intShow(v_mask_248), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str6), v_t_2411));
    V v_t_2413 = heff_strAppend(v_sv_240, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str7), v_t_2412));
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str8), v_t_2410), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str9), v_t_2413));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etakeLines_str10), v_t_2414), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etakeLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etakeLines(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2egetterOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2egetterOf_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2egetterOf_str2, 4, "_get");
HEFF_LIT(g_heff_2ecompile_2eemitc_2egetterOf_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2egetterOf_str4, 5, "gget_");
Clo g_heff_2ecompile_2eemitc_2egetterOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2egetterOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2egetterOf(V v_ce_240, V v_key_241) {
top: ;
  V v_t_242 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 0, 5);
  V v_x3_243 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_242; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_242); r_; });
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2egetterOf_str0)));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2egetterOf_str1), v_t_244), ((V)&g_heff_2ecompile_2eemitc_2egetterOf_str2));
  }
  case TAG_Just: {
    heff_take_n(v_x3_243, 0ULL, 1);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2egetterOf_str3)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2egetterOf_str4), v_t_246);
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eemitc_2egetterOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2egetterOf(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2emoduleParts_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emoduleParts_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2emoduleParts(V v_size_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_m_242 = heff_field(v_x2_241, 0);
    V v_ps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemitc_2emoduleParts_lam0, 2, 1, (V[]){v_size_240}), MK_INT(0LL), v_ps_243));
    V v_b_248 = (g_heff_2ecompile_2eemitc_2epartCount(v_t_247, MK_INT(1LL)));
    if (heff_intEq_c(heff_dup(v_b_248), MK_INT(1LL))) {
      heff_drop(v_b_248);
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_ps_243}), NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return (g_heff_2ecompile_2eemitc_2epartsFrom(v_m_242, v_b_248, v_ps_243, MK_INT(0LL)));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emoduleParts(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2emoduleParts_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_p_245 = args[1];
  V v_size_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(v_size_240, 1, (V[]){v_p_245}));
  return heff_intAdd(v_n_244, v_t_246);
}
Clo g_heff_2ecompile_2eemitc_2emergeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emergeKept_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2emergeKept(V v_o_240, V v_k_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), heff_take_field(v_k_241, 5), heff_take_field(v_s_242, 2)));
  V v_t_244 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), heff_take_field(v_k_241, 4), heff_take_field(v_s_242, 3)));
  V v_t_245 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), heff_take_field(v_k_241, 3), heff_take_field(v_s_242, 5)));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), heff_take_field(v_k_241, 6), heff_take_field(v_s_242, 6)));
  V v_t_247 = (g_heff_2ecompile_2eemitc_2epushOwn(v_o_240, heff_get_n(v_k_241, 7, 8), heff_take_field(v_s_242, 7)));
  return ({ V rv_2 = v_t_243; V rv_3 = v_t_244; V rv_5 = v_t_245; V rv_6 = v_t_246; V rv_7 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_242, 19ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emergeKept(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eoutputOf_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eoutputOf(V v_runtime_240, V v_provs_241, V v_ending_242, V v_l_243) {
top: ;
  V v_defs_244 = heff_take_field(v_l_243, 0);
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), heff_dup(v_defs_244)));
  V v_names_247 = (g_list_2efoldl_24s1659194469x1936830512(v_t_245, v_t_246));
  V v_t_248 = ({ V a_0 = heff_dup(v_provs_241); V a_1 = heff_take_field(v_l_243, 1); V a_2 = v_names_247; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_247); r_; });
  V v_t_249 = (g_heff_2ecompile_2eemitc_2eprogramCE(v_runtime_240, v_provs_241, v_ending_242, v_defs_244, v_t_248));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_249, heff_get_n(v_l_243, 2, 3)});
}
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eoutputOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckOut_str0, 18, "#define HEFF_CHECK");
Clo g_heff_2ecompile_2eemitc_2echeckOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckOut_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckOut(V v_runtime_240, V v_exports_241, V v_l_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckOut_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_clo), 2, (V[]){v_exports_241, heff_dup(heff_rfield(v_l_242, 0))}));
  V v_ending_245 = heff_rec_n(2, shape_prefix__end, (V[]){v_t_243, v_t_244});
  V v_defs_246 = heff_take_field(v_l_242, 0);
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), heff_dup(v_defs_246)));
  V v_names_249 = (g_list_2efoldl_24s1659194469x1936830512(v_t_247, v_t_248));
  V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = heff_take_field(v_l_242, 1); V a_2 = v_names_249; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_249); r_; });
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2eprogramCE(v_runtime_240, NTAG(TAG_Nil), v_ending_245, v_defs_246, v_t_2410));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_2411, heff_get_n(v_l_242, 2, 3)});
}
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2echeckOut(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecatMaybesC(a[0]);
}