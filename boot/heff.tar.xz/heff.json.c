// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ejson_2eescapeAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ejson_2eescapeAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ejson_2eescapeAt_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ejson_2eescapeAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ejson_2eescapeAt_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ejson_2eescapeAt_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2ejson_2eescapeAt_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ejson_2eescapeAt_str7 = {{0x80000000u, K_STR, 0}, 16, 16, {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2ejson_2eescapeAt_str8 = {{0x80000000u, K_STR, 0}, 16, 16, {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ejson_2eescapeAt_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {92, 117, 48, 48}};
Clo g_heff_2ejson_2eescapeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ejson_2eescapeAt_entry, 2, 0};

V g_heff_2ejson_2eescapeAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_242);
    return ((V)&g_heff_2ejson_2eescapeAt_str0);
  }
  case TAG_False: {
    heff_drop(v_t_242);
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_t_243);
      return ((V)&g_heff_2ejson_2eescapeAt_str1);
    }
    case TAG_False: {
      heff_drop(v_t_243);
      V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_t_244);
        return ((V)&g_heff_2ejson_2eescapeAt_str2);
      }
      case TAG_False: {
        heff_drop(v_t_244);
        V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          heff_drop(v_t_245);
          return ((V)&g_heff_2ejson_2eescapeAt_str3);
        }
        case TAG_False: {
          heff_drop(v_t_245);
          V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL));
          switch (heff_tag_of(v_t_246)) {
          case TAG_True: {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            heff_drop(v_t_246);
            return ((V)&g_heff_2ejson_2eescapeAt_str4);
          }
          case TAG_False: {
            heff_drop(v_t_246);
            V v_t_247 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(8LL));
            switch (heff_tag_of(v_t_247)) {
            case TAG_True: {
              heff_drop(v_s_240);
              heff_drop(v_i_241);
              heff_drop(v_t_247);
              return ((V)&g_heff_2ejson_2eescapeAt_str5);
            }
            case TAG_False: {
              heff_drop(v_t_247);
              V v_t_248 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(12LL));
              switch (heff_tag_of(v_t_248)) {
              case TAG_True: {
                heff_drop(v_s_240);
                heff_drop(v_i_241);
                heff_drop(v_t_248);
                return ((V)&g_heff_2ejson_2eescapeAt_str6);
              }
              case TAG_False: {
                heff_drop(v_t_248);
                V v_t_249 = heff_intLt(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL));
                switch (heff_tag_of(v_t_249)) {
                case TAG_True: {
                  heff_drop(v_t_249);
                  V v_c_2410 = heff_strCharCode(v_s_240, v_i_241);
                  V v_d_2411 = heff_intDiv(heff_dup(v_c_2410), MK_INT(16LL));
                  V v_t_2412 = heff_strSlice(((V)&g_heff_2ejson_2eescapeAt_str7), heff_dup(v_d_2411), heff_intAdd(v_d_2411, MK_INT(1LL)));
                  V v_d_2413 = heff_intMod(v_c_2410, MK_INT(16LL));
                  V v_t_2414 = heff_strSlice(((V)&g_heff_2ejson_2eescapeAt_str8), heff_dup(v_d_2413), heff_intAdd(v_d_2413, MK_INT(1LL)));
                  return heff_strAppend(((V)&g_heff_2ejson_2eescapeAt_str9), heff_strAppend(v_t_2412, v_t_2414));
                }
                case TAG_False: {
                  heff_drop(v_t_249);
                  return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
                }
                default: return heff_nomatch(v_t_249);
                }
              }
              default: return heff_nomatch(v_t_248);
              }
            }
            default: return heff_nomatch(v_t_247);
            }
          }
          default: return heff_nomatch(v_t_246);
          }
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ejson_2eescapeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ejson_2eescapeAt(a[0], a[1]);
}
Clo g_heff_2ejson_2eescapeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ejson_2eescapeGo_entry, 3, 0};

V g_heff_2ejson_2eescapeGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_t_243);
    return v_acc_242;
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_244 = heff_strAppend(v_acc_242, (g_heff_2ejson_2eescapeAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ejson_2eescapeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ejson_2eescapeGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ejson_2estringify_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 117, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2ejson_2estringify_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2ejson_2estringify_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2ejson_2estringify_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
Clo g_heff_2ejson_2estringify_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ejson_2estringify_entry, 1, 0};

V g_heff_2ejson_2estringify(V v_j_240) {
top: ;
  switch (heff_tag_of(v_j_240)) {
  case TAG_JNull: {
    return ((V)&g_heff_2ejson_2estringify_str0);
  }
  case TAG_JBool: {
    V v_b_241 = heff_field(v_j_240, 0);
    switch (heff_tag_of(v_b_241)) {
    case TAG_True: {
      return ((V)&g_heff_2ejson_2estringify_str1);
    }
    case TAG_False: {
      return ((V)&g_heff_2ejson_2estringify_str2);
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_JInt: {
    V v_i_242 = heff_field(v_j_240, 0);
    return heff_intShow(heff_dup(v_i_242));
  }
  case TAG_JFloat: {
    V v_x_243 = heff_field(v_j_240, 0);
    return heff_floatShow(heff_dup(v_x_243));
  }
  case TAG_JString: {
    V v_s_244 = heff_field(v_j_240, 0);
    V v_t_245 = (g_heff_2ejson_2eescapeGo(heff_dup(v_s_244), MK_INT(0LL), ((V)&g_heff_2ejson_2estringify_str3)));
    return heff_strAppend(((V)&g_heff_2ejson_2estringify_str4), heff_strAppend(v_t_245, ((V)&g_heff_2ejson_2estringify_str5)));
  }
  case TAG_JArray: {
    V v_xs_246 = heff_field(v_j_240, 0);
    V v_x2_247 = (g_prelude_2emap(((V)&g_heff_2ejson_2estringify_clo), heff_dup(v_xs_246)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      heff_drop(v_x2_247);
      v_t_2410 = ((V)&g_heff_2ejson_2estringify_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take(v_x2_247, 3ULL);
      v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s540(a_0, a_1)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strAppend(((V)&g_heff_2ejson_2estringify_str7), heff_strAppend(v_t_2410, ((V)&g_heff_2ejson_2estringify_str8)));
  }
  case TAG_JObject: {
    V v_fs_2411 = heff_field(v_j_240, 0);
    V v_x2_2412 = (g_prelude_2emap_24s829(heff_dup(v_fs_2411)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      heff_drop(v_x2_2412);
      v_t_2415 = ((V)&g_heff_2ejson_2estringify_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take(v_x2_2412, 3ULL);
      v_t_2415 = ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s540(a_0, a_1)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    return heff_strAppend(((V)&g_heff_2ejson_2estringify_str10), heff_strAppend(v_t_2415, ((V)&g_heff_2ejson_2estringify_str11)));
  }
  default: return heff_nomatch(v_j_240);
  }
}
V g_heff_2ejson_2estringify_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ejson_2estringify(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ejson_2eat_lam0(V self, V *args);
Clo g_heff_2ejson_2eat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ejson_2eat_entry, 2, 0};

V g_heff_2ejson_2eat(V v_x1_240, V v_j_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_Just, 1, (V[]){v_j_241});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ks_243 = heff_field(v_x1_240, 1);
    V v_t_2419;
    switch (heff_tag_of(v_j_241)) {
    case TAG_JNull: {
      heff_drop(v_j_241);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take(v_j_241, 0ULL);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take(v_j_241, 0ULL);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take(v_j_241, 0ULL);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take(v_j_241, 0ULL);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take(v_j_241, 0ULL);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_249 = heff_field(v_j_241, 0);
      V v_ru_24j_241_24JObject = heff_take_reuse(v_j_241, 1ULL);
      V v_t_2414 = ({ V a_0 = heff_clo(g_heff_2ejson_2eat_lam0, 1, 1, (V[]){heff_dup(v_k_242)}); V a_1 = v_fs_249; V r_ = (g_prelude_2efind(a_0, a_1)); heff_drop(v_fs_249); r_; });
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop(v_ru_24j_241_24JObject);
        heff_drop(v_t_2414);
        v_t_2419 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2415 = heff_field(v_t_2414, 0);
        heff_take(v_t_2414, 1ULL);
        V v_t_2418;
        switch (heff_tag_of(v_p_2415)) {
        case TAG_MkPair: {
          V v_y_2417 = heff_field(v_p_2415, 1);
          heff_take(v_p_2415, 2ULL);
          v_t_2418 = v_y_2417;
          break;
        }
        default: heff_nomatch(v_p_2415);
        }
        v_t_2419 = heff_tag_at(v_ru_24j_241_24JObject, TAG_Just, 1, (V[]){v_t_2418});
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      break;
    }
    default: heff_nomatch(v_j_241);
    }
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      heff_drop(v_t_2419);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_2420 = heff_field(v_t_2419, 0);
      heff_take(v_t_2419, 1ULL);
      V t_0 = v_ks_243;
      V t_1 = v_v_2420;
      v_x1_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ejson_2eat_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ejson_2eat(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ejson_2eat_lam0(V self, V *args) {
  V v_p_2410 = args[0];
  V v_k_242 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2413;
  switch (heff_tag_of(v_p_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    heff_take(v_p_2410, 1ULL);
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_p_2410);
  }
  return heff_strEq(v_t_2413, v_k_242);
}