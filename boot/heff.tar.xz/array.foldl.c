// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_prevEnd 2061122539
#define LBL_startLine 1642416498
#define LBL_tok 324554
V g_array_2efoldl_2efoldlFrom_240(V, V, V, V);
V g_array_2efoldl_2efoldlFrom_240_entry(V self, V *a);
extern Clo g_array_2efoldl_2efoldlFrom_240_clo;
V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019(V, V, V, V, V);
V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_entry(V self, V *a);
extern Clo g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepCmt(V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepCmt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepCmt_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepTok(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_clo;
V g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1_clo;
Clo g_array_2efoldl_2efoldlFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_array_2efoldl_2efoldlFrom_240_entry, 4, 0};

V g_array_2efoldl_2efoldlFrom_240(V v_xs_240, V v_f_241, V v_box_24i_242, V v_acc_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_acc_243, v_t_244}));
      V t_0 = v_xs_240;
      V t_1 = v_f_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_245;
      v_xs_240 = t_0;
      v_f_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_f_241);
      return v_acc_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_acc_243, v_t_244}));
    V t_0 = v_xs_240;
    V t_1 = v_f_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = v_t_245;
    v_xs_240 = t_0;
    v_f_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  } else {
    heff_drop(v_f_241);
    return v_acc_243;
  }
}
V g_array_2efoldl_2efoldlFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_array_2efoldl_2efoldlFrom_240(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_clo = {{0x80000000u, K_CLO, 0}, g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_entry, 5, 0};

V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019(V v_lit_240, V v_lit_241, V v_xs_242, V v_box_24i_243, V v_acc_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  if ((((int64_t)0ULL) <= v_i_243)) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_xs_242, 0)))) {
      V v_a_245 = heff_arrayIndexIn_lent(v_xs_242, heff_box_word(v_i_243), 2);
      V v_src_246 = heff_dup(v_lit_240);
      V v_elems_247 = heff_dup(v_lit_241);
      V v_st_248 = v_acc_244;
      V v_e_249 = v_a_245;
      V v_t_2410 = heff_dup(heff_rfield(v_e_249, 2));
      V v_t_2414;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_src_246);
        V v_t_2411 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
        v_t_2414 = (g_heff_2esyntax_2efmt_2etokens_2estepCmt(v_elems_247, v_st_248, v_e_249, v_t_2411));
        break;
      }
      case TAG_Just: {
        V v_t_2412 = heff_field(v_t_2410, 0);
        V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
        heff_drop(v_elems_247);
        V v_t_2413 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
        v_t_2414 = ({ V a_0 = v_ru_24t_2410_24Just; V a_1 = v_src_246; V a_2 = v_st_248; V a_3 = v_e_249; V a_4 = v_t_2413; V a_5 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_src_246); r_; });
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = v_t_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_xs_242 = t_2;
      v_i_243 = t_3;
      v_acc_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return v_acc_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_xs_242, 0)))) {
    V v_a_245 = heff_arrayIndex_lent(v_xs_242, heff_box_word(v_i_243), 2);
    V v_src_246 = heff_dup(v_lit_240);
    V v_elems_247 = heff_dup(v_lit_241);
    V v_st_248 = v_acc_244;
    V v_e_249 = v_a_245;
    V v_t_2410 = heff_dup(heff_rfield(v_e_249, 2));
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      heff_drop(v_src_246);
      V v_t_2411 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
      v_t_2414 = (g_heff_2esyntax_2efmt_2etokens_2estepCmt(v_elems_247, v_st_248, v_e_249, v_t_2411));
      break;
    }
    case TAG_Just: {
      V v_t_2412 = heff_field(v_t_2410, 0);
      V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
      heff_drop(v_elems_247);
      V v_t_2413 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_st_248, 0))) && heff_intLe_c(MK_INT(2LL), heff_intSub(heff_dup(heff_rfield(v_e_249, 4)), heff_dup(heff_rfield(v_st_248, 0))))));
      v_t_2414 = ({ V a_0 = v_ru_24t_2410_24Just; V a_1 = v_src_246; V a_2 = v_st_248; V a_3 = v_e_249; V a_4 = v_t_2413; V a_5 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2etokens_2estepTok_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_src_246); r_; });
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = v_t_2414;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_xs_242 = t_2;
    v_i_243 = t_3;
    v_acc_244 = t_4;
    goto top;
  } else {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_acc_244;
  }
}
V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}