// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_MkArm 55352
#define TAG_MkArmJs 44527
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_arity 294440695
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_fresh 299054408
#define LBL_globals 352931696
#define LBL_gs 10067
#define LBL_info 9732469
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_module 878357911
#define LBL_names 305943394
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_prims 308293287
#define LBL_refs 9991943
#define LBL_self 10021907
#define LBL_text 10052084
#define LBL_used 10094724
#define LBL_ver 326173
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_entries__fresh[] = {LBL_entries, LBL_fresh};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_info[] = {LBL_info};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_js__pre__env[] = {LBL_js, LBL_pre, LBL_env};
static uint32_t shape_lines__env[] = {LBL_lines, LBL_env};
static uint32_t shape_lines__globals[] = {LBL_lines, LBL_globals};
static uint32_t shape_lines__params[] = {LBL_lines, LBL_params};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V, V, V, V);
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo;
V g_heff_2ecompile_2eemit_2earmBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_clo;
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2eassembled(V, V, V);
V g_heff_2ecompile_2eemit_2eassembled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eassembled_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
V g_heff_2ecompile_2eemit_2ebindName(V, V);
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindName_clo;
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo;
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo;
V g_heff_2ecompile_2eemit_2ebundleProvider(V, V);
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo;
V g_heff_2ecompile_2eemit_2ecallName(V, V);
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallName_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecompileProgramKept(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo;
V g_heff_2ecompile_2eemit_2econdCode(V);
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdCode_clo;
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2edefCodeOf(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2edefCodeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edefCodeOf_clo;
V g_heff_2ecompile_2eemit_2edefFun(V, V, V, V);
V g_heff_2ecompile_2eemit_2edefFun_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edefFun_clo;
V g_heff_2ecompile_2eemit_2eeagerCode(V, V);
V g_heff_2ecompile_2eemit_2eeagerCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eeagerCode_clo;
V g_heff_2ecompile_2eemit_2eemitKept(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKept_clo;
V g_heff_2ecompile_2eemit_2eemitKeptIn(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKeptIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKeptIn_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemit_2efindProv(V, V);
V g_heff_2ecompile_2eemit_2efindProv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efindProv_clo;
V g_heff_2ecompile_2eemit_2efixedCode(V, V);
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efixedCode_clo;
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2einlinable(V, V, V, V);
V g_heff_2ecompile_2eemit_2einlinable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einlinable_clo;
V g_heff_2ecompile_2eemit_2eisIdent(V);
V g_heff_2ecompile_2eemit_2eisIdent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eisIdent_clo;
V g_heff_2ecompile_2eemit_2ejsAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ejsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsAt_clo;
V g_heff_2ecompile_2eemit_2ejsNameOf(V, V);
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo;
V g_heff_2ecompile_2eemit_2ejsPick(V, V, V);
V g_heff_2ecompile_2eemit_2ejsPick_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsPick_clo;
V g_heff_2ecompile_2eemit_2ekeptCode(V, V, V);
V g_heff_2ecompile_2eemit_2ekeptCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptCode_clo;
V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246(V, V);
V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_clo;
V g_heff_2ecompile_2eemit_2ekeptOfDef(V, V, V);
V g_heff_2ecompile_2eemit_2ekeptOfDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptOfDef_clo;
V g_heff_2ecompile_2eemit_2ekeptOutput(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ekeptOutput_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptOutput_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2eletDeclarations(V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo;
V g_heff_2ecompile_2eemit_2elooped(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elooped_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemit_2enamed(V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_clo;
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_clo;
V g_heff_2ecompile_2eemit_2enamedAs(V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_clo;
V g_heff_2ecompile_2eemit_2enamesIn(V, V);
V g_heff_2ecompile_2eemit_2enamesIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamesIn_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
V g_heff_2ecompile_2eemit_2eoperatorGo(V, V, V);
V g_heff_2ecompile_2eemit_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eoperatorGo_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU(V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo;
V g_heff_2ecompile_2eemit_2eprimUnary(V);
V g_heff_2ecompile_2eemit_2eprimUnary_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUnary_clo;
V g_heff_2ecompile_2eemit_2eprimUses(V, V);
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUses_clo;
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V, V, V, V);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_24dps_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereturnCond(V, V);
V g_heff_2ecompile_2eemit_2ereturnCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnCond_clo;
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2esetStmt(V, V, V, V);
V g_heff_2ecompile_2eemit_2esetStmt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esetStmt_clo;
V g_heff_2ecompile_2eemit_2esharedGo(V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esharedGo_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(V, V, V);
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_clo;
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo;
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2euncurryGo(V, V);
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2euncurryGo_clo;
V g_heff_2ecompile_2eemit_2eunsnocGo(V, V);
V g_heff_2ecompile_2eemit_2eunsnocGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eunsnocGo_clo;
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
V g_heff_2ecompile_2eemit_2ewordOf(V);
V g_heff_2ecompile_2eemit_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ewordOf_clo;
V g_heff_2ecompile_2eemit_2ewrapper(V, V, V, V);
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ewrapper_clo;
V g_heff_2ecompile_2eimperative_2efirstNamesTl(V);
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop(V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2eusedOnceNext(V, V, V);
V g_heff_2ecompile_2eimperative_2eusedOnceNext_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eusedOnceNext_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2elower_2ejsDef(V, V);
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ejsDef_clo;
V g_heff_2ecompile_2elower_2elowerProgramKept(V, V, V, V);
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1721003522x874107866(V, V);
V g_list_2eany_24s1721003522x874107866_entry(V self, V *a);
extern Clo g_list_2eany_24s1721003522x874107866_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24f1668687542x1574966783(V, V, V, V);
V g_list_2efilter_24f1668687542x1574966783_entry(V self, V *a);
extern Clo g_list_2efilter_24f1668687542x1574966783_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f226312210x181720981(V, V, V, V);
V g_list_2efoldl_24f226312210x181720981_entry(V self, V *a);
extern Clo g_list_2efoldl_24f226312210x181720981_clo;
V g_list_2efoldl_24s135909237x326578890(V, V);
V g_list_2efoldl_24s135909237x326578890_entry(V self, V *a);
extern Clo g_list_2efoldl_24s135909237x326578890_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s25420611x1990549631(V, V);
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25420611x1990549631_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1457339348x592422294(V, V, V);
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_clo;
V g_list_2emap_24f881582358x206177481(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f881582358x206177481_entry(V self, V *a);
extern Clo g_list_2emap_24f881582358x206177481_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s1585362143x1323498048(V);
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s270076267x1966815767(V, V, V, V, V);
V g_list_2emap_24s270076267x1966815767_entry(V self, V *a);
extern Clo g_list_2emap_24s270076267x1966815767_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s879212241x321667329(V, V, V, V, V, V, V, V);
V g_list_2emap_24s879212241x321667329_entry(V self, V *a);
extern Clo g_list_2emap_24s879212241x321667329_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ecompile_2eemit_2eunsnocGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eunsnocGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eunsnocGo(V v_x1_240, V v_y_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_y_241});
  }
  case TAG_Cons: {
    V v_z_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2eemit_2eunsnocGo(v_rest_243, v_z_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_ini_245 = heff_field(v_x2_244, 0);
      V v_lst_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_241, v_ini_245}), v_lst_246});
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eunsnocGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eunsnocGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2eoperatorGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eoperatorGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241))) {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    V v_t_245 = (g_heff_2ecompile_2eemit_2ewordOf(heff_strByteAt(heff_dup(v_x_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_w_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_246, v_acc_242});
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
}
V g_heff_2ecompile_2eemit_2eoperatorGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eoperatorGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eisIdent_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eisIdent_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eisIdent_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eisIdent_str3, 1, "x");
Clo g_heff_2ecompile_2eemit_2eisIdent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eisIdent_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eisIdent(V v_x_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x_240), ((V)&g_heff_2ecompile_2eemit_2eisIdent_str0))) {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  } else {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_x_240)), MK_INT(1LL));
    V v_t_243 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x_240), v_t_242));
    V v_t_244 = ({ V a_0 = heff_dup(v_x_240); V a_1 = v_t_243; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_s_245 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_244, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eisIdent_str1)));
    V v_t_247;
    if (heff_strEq_c(heff_dup(v_s_245), ((V)&g_heff_2ecompile_2eemit_2eisIdent_str2))) {
      heff_drop(v_s_245);
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eisIdent_str3);
    } else {
      v_t_247 = v_s_245;
    }
    V v_t_248 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_247));
    return heff_strEq(v_t_248, v_x_240);
  }
}
V g_heff_2ecompile_2eemit_2eisIdent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eisIdent(a[0]);
}
Clo g_heff_2ecompile_2eemit_2ebindFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebindFrom_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ebindFrom(V v_env_240, V v_x_241, V v_base_242, V v_i_243) {
top: ;
  V v_t_245;
  if (heff_intEq_c(heff_dup(v_i_243), MK_INT(0LL))) {
    v_t_245 = heff_dup(v_base_242);
  } else {
    v_t_245 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
  }
  V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(v_t_245, heff_rfield(v_env_240, 2)));
  V v_t_248;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_246);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    V t_0 = v_env_240;
    V t_1 = v_x_241;
    V t_2 = v_base_242;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    v_env_240 = t_0;
    v_x_241 = t_1;
    v_base_242 = t_2;
    v_i_243 = t_3;
    goto top;
  } else {
    heff_drop(v_t_248);
    V v_t_2410;
    if (heff_intEq_c(heff_dup(v_i_243), MK_INT(0LL))) {
      v_t_2410 = heff_dup(v_base_242);
    } else {
      v_t_2410 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
    }
    V v_v_2412;
    if (heff_intEq_c(heff_dup(v_i_243), MK_INT(0LL))) {
      heff_drop(v_i_243);
      v_v_2412 = v_base_242;
    } else {
      v_v_2412 = heff_strAppend(v_base_242, heff_intShow(v_i_243));
    }
    V v_t_2413 = (g_map_2einsert_24s1341440536x470972936(v_x_241, heff_dup(v_v_2412), heff_take_field(v_env_240, 1)));
    V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_v_2412, NTAG(TAG_MkUnit), heff_take_field(v_env_240, 2)));
    V v_t_2415 = ({ V rv_1 = v_t_2413; V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_env_240, 25ULL, 5, shape_gs__names__used__self__inl, 963u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_rec_n(2, shape_js__env, (V[]){v_t_2410, v_t_2415});
  }
}
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebindFrom(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str3, 11, ".toString()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str4, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str7, 7, "BigInt(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_str8, 8, ".length)");
V g_heff_2ecompile_2eemit_2eprimUnary_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_lam0, 1, 0};
V g_heff_2ecompile_2eemit_2eprimUnary_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_lam1, 1, 0};
Clo g_heff_2ecompile_2eemit_2eprimUnary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eprimUnary(V v_x1_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str0))) {
    heff_drop(v_x1_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimUnary_lam0_clo)});
  } else {
    if (heff_strEq_c(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str4))) {
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimUnary_lam1_clo)});
    } else {
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimUnary_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimUnary(a[0]);
}
V g_heff_2ecompile_2eemit_2eprimUnary_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_t_245;
  if (heff_intLt_c(heff_dup(heff_rfield(v_a_242, 1)), MK_INT(3LL))) {
    V v_t_244 = heff_strAppend(heff_get_n(v_a_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str1));
    v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_str2), v_t_244);
  } else {
    v_t_245 = heff_get_n(v_a_242, 0, 2);
  }
  return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str3)), MK_INT(3LL)});
}
V g_heff_2ecompile_2eemit_2eprimUnary_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_t_2410;
  if (heff_intLt_c(heff_dup(heff_rfield(v_a_247, 1)), MK_INT(3LL))) {
    V v_t_249 = heff_strAppend(heff_get_n(v_a_247, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str5));
    v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_str6), v_t_249);
  } else {
    v_t_2410 = heff_get_n(v_a_247, 0, 2);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_str7), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str8)));
  return heff_rec_n(2, shape_code__prec, (V[]){v_t_2411, MK_INT(3LL)});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str0, 4, "true");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str1, 5, "false");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str4, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str9, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str13, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str14, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str19, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str20, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str23, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str24, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str26, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str28, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str29, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str30, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str31, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str32, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str34, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str35, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str36, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str37, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str38, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str39, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str40, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str41, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str44, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str45, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str47, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str48, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str49, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str50, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str51, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str52, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str53, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str54, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str55, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str56, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str57, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str58, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str59, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str60, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str61, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str62, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str63, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str64, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str65, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str66, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str67, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str68, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str69, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str70, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str71, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str72, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str73, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str74, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str75, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str76, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str77, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str78, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str79, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str80, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str81, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str82, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str83, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str84, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str85, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str86, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str87, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str88, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str89, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str90, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str91, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str92, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str93, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str94, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str95, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str96, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str97, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str98, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str99, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str100, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str101, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str102, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str103, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str104, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str105, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str106, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str107, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str108, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str109, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str110, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str111, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str112, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str113, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str114, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str115, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str116, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str117, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str118, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str119, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str120, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str121, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str122, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str123, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str124, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str125, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str126, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str127, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str128, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str129, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str130, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str131, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str132, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str133, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str134, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str135, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str136, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str137, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str138, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str139, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str140, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str141, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str142, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str143, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str144, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str145, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str146, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str147, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str148, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str149, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str150, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str151, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str152, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str153, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str154, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str155, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str156, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str157, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str158, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str159, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str160, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str161, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str162, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str163, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str164, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str165, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str166, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str167, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str168, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str169, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str170, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str171, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str172, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str173, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str174, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str175, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str176, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str177, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str178, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str179, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str180, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str181, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str182, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str183, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str184, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str185, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str186, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str187, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str188, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str189, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str190, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str191, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str192, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str193, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str194, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str195, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str196, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str197, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str198, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str199, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str200, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str201, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str202, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str203, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str204, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str205, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str206, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str207, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str208, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str209, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str210, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str211, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str212, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_str213, 1, "(");
Clo g_heff_2ecompile_2eemit_2econdCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2econdCode(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JTrue: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2econdCode_str0), MK_INT(4LL)});
  }
  case TAG_JFalse: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2econdCode_str1), MK_INT(4LL)});
  }
  case TAG_JRel: {
    V v_s_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_rec_n(2, shape_code__prec, (V[]){v_s_241, MK_INT(3LL)});
  }
  case TAG_JNot: {
    V v_q_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_c_243 = (g_heff_2ecompile_2eemit_2econdCode(v_q_242));
    V v_t_246;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_243, 1)), MK_INT(4LL))) {
      V v_t_245 = heff_strAppend(heff_get_n(v_c_243, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str2));
      v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str3), v_t_245);
    } else {
      v_t_246 = heff_get_n(v_c_243, 0, 2);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str4), v_t_246), MK_INT(4LL)});
  }
  case TAG_JIf: {
    V v_c_247 = heff_field(v_x1_240, 0);
    V v_t_248 = heff_field(v_x1_240, 1);
    V v_x13_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x13_249)) {
    case TAG_JTrue: {
      switch (heff_tag_of(v_t_248)) {
      case TAG_JTrue: {
        V v_c_2410 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_2413;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2410, 1)), MK_INT(1LL))) {
          V v_t_2412 = heff_strAppend(heff_get_n(v_c_2410, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str5));
          v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str6), v_t_2412);
        } else {
          v_t_2413 = heff_get_n(v_c_2410, 0, 2);
        }
        V v_c_2414 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_2417;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2414, 1)), MK_INT(1LL))) {
          V v_t_2416 = heff_strAppend(heff_get_n(v_c_2414, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str7));
          v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str8), v_t_2416);
        } else {
          v_t_2417 = heff_get_n(v_c_2414, 0, 2);
        }
        V v_t_2418 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str9), v_t_2417));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2418, MK_INT(1LL)});
      }
      case TAG_JFalse: {
        V v_c_2419 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_2422;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2419, 1)), MK_INT(2LL))) {
          V v_t_2421 = heff_strAppend(heff_get_n(v_c_2419, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str10));
          v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str11), v_t_2421);
        } else {
          v_t_2422 = heff_get_n(v_c_2419, 0, 2);
        }
        V v_c_2423 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_2426;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2423, 1)), MK_INT(2LL))) {
          V v_t_2425 = heff_strAppend(heff_get_n(v_c_2423, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str12));
          v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str13), v_t_2425);
        } else {
          v_t_2426 = heff_get_n(v_c_2423, 0, 2);
        }
        V v_t_2427 = heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str14), v_t_2426));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2427, MK_INT(2LL)});
      }
      case TAG_JRel: {
        V v_c_2429 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_2432;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2429, 1)), MK_INT(1LL))) {
          V v_t_2431 = heff_strAppend(heff_get_n(v_c_2429, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str15));
          v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str16), v_t_2431);
        } else {
          v_t_2432 = heff_get_n(v_c_2429, 0, 2);
        }
        V v_c_2433 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_2436;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2433, 1)), MK_INT(1LL))) {
          V v_t_2435 = heff_strAppend(heff_get_n(v_c_2433, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str17));
          v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str18), v_t_2435);
        } else {
          v_t_2436 = heff_get_n(v_c_2433, 0, 2);
        }
        V v_t_2437 = heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str19), v_t_2436));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2437, MK_INT(1LL)});
      }
      case TAG_JNot: {
        V v_c_2439 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_2442;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2439, 1)), MK_INT(1LL))) {
          V v_t_2441 = heff_strAppend(heff_get_n(v_c_2439, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str20));
          v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str21), v_t_2441);
        } else {
          v_t_2442 = heff_get_n(v_c_2439, 0, 2);
        }
        V v_c_2443 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_2446;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2443, 1)), MK_INT(1LL))) {
          V v_t_2445 = heff_strAppend(heff_get_n(v_c_2443, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str22));
          v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str23), v_t_2445);
        } else {
          v_t_2446 = heff_get_n(v_c_2443, 0, 2);
        }
        V v_t_2447 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str24), v_t_2446));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2447, MK_INT(1LL)});
      }
      case TAG_JIf: {
        V v_c_2451 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_2454;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2451, 1)), MK_INT(1LL))) {
          V v_t_2453 = heff_strAppend(heff_get_n(v_c_2451, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str25));
          v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str26), v_t_2453);
        } else {
          v_t_2454 = heff_get_n(v_c_2451, 0, 2);
        }
        V v_c_2455 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_2458;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2455, 1)), MK_INT(1LL))) {
          V v_t_2457 = heff_strAppend(heff_get_n(v_c_2455, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str27));
          v_t_2458 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str28), v_t_2457);
        } else {
          v_t_2458 = heff_get_n(v_c_2455, 0, 2);
        }
        V v_t_2459 = heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str29), v_t_2458));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2459, MK_INT(1LL)});
      }
      case TAG_JSeq: {
        V v_c_2463 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_2466;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2463, 1)), MK_INT(1LL))) {
          V v_t_2465 = heff_strAppend(heff_get_n(v_c_2463, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str30));
          v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str31), v_t_2465);
        } else {
          v_t_2466 = heff_get_n(v_c_2463, 0, 2);
        }
        V v_c_2467 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_2470;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2467, 1)), MK_INT(1LL))) {
          V v_t_2469 = heff_strAppend(heff_get_n(v_c_2467, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str32));
          v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str33), v_t_2469);
        } else {
          v_t_2470 = heff_get_n(v_c_2467, 0, 2);
        }
        V v_t_2471 = heff_strAppend(v_t_2466, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str34), v_t_2470));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2471, MK_INT(1LL)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_JFalse: {
      V v_c_2472 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
      V v_t_2475;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2472, 1)), MK_INT(2LL))) {
        V v_t_2474 = heff_strAppend(heff_get_n(v_c_2472, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str35));
        v_t_2475 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str36), v_t_2474);
      } else {
        v_t_2475 = heff_get_n(v_c_2472, 0, 2);
      }
      V v_c_2476 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
      V v_t_2479;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2476, 1)), MK_INT(2LL))) {
        V v_t_2478 = heff_strAppend(heff_get_n(v_c_2476, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str37));
        v_t_2479 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str38), v_t_2478);
      } else {
        v_t_2479 = heff_get_n(v_c_2476, 0, 2);
      }
      V v_t_2480 = heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str39), v_t_2479));
      return heff_rec_n(2, shape_code__prec, (V[]){v_t_2480, MK_INT(2LL)});
    }
    case TAG_JRel: {
      switch (heff_tag_of(v_t_248)) {
      case TAG_JTrue: {
        V v_c_2482 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_2485;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2482, 1)), MK_INT(1LL))) {
          V v_t_2484 = heff_strAppend(heff_get_n(v_c_2482, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str40));
          v_t_2485 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str41), v_t_2484);
        } else {
          v_t_2485 = heff_get_n(v_c_2482, 0, 2);
        }
        V v_c_2486 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_2489;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2486, 1)), MK_INT(1LL))) {
          V v_t_2488 = heff_strAppend(heff_get_n(v_c_2486, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str42));
          v_t_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str43), v_t_2488);
        } else {
          v_t_2489 = heff_get_n(v_c_2486, 0, 2);
        }
        V v_t_2490 = heff_strAppend(v_t_2485, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str44), v_t_2489));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2490, MK_INT(1LL)});
      }
      case TAG_JFalse: {
        V v_c_2491 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_2494;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2491, 1)), MK_INT(2LL))) {
          V v_t_2493 = heff_strAppend(heff_get_n(v_c_2491, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str45));
          v_t_2494 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str46), v_t_2493);
        } else {
          v_t_2494 = heff_get_n(v_c_2491, 0, 2);
        }
        V v_c_2495 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_2498;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2495, 1)), MK_INT(2LL))) {
          V v_t_2497 = heff_strAppend(heff_get_n(v_c_2495, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str47));
          v_t_2498 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str48), v_t_2497);
        } else {
          v_t_2498 = heff_get_n(v_c_2495, 0, 2);
        }
        V v_t_2499 = heff_strAppend(v_t_2494, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str49), v_t_2498));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2499, MK_INT(2LL)});
      }
      case TAG_JRel: {
        V v_c_24101 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24104;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24101, 1)), MK_INT(1LL))) {
          V v_t_24103 = heff_strAppend(heff_get_n(v_c_24101, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str50));
          v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str51), v_t_24103);
        } else {
          v_t_24104 = heff_get_n(v_c_24101, 0, 2);
        }
        V v_c_24105 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24108;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24105, 1)), MK_INT(0LL))) {
          V v_t_24107 = heff_strAppend(heff_get_n(v_c_24105, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str52));
          v_t_24108 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str53), v_t_24107);
        } else {
          v_t_24108 = heff_get_n(v_c_24105, 0, 2);
        }
        V v_c_24109 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24112;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24109, 1)), MK_INT(0LL))) {
          V v_t_24111 = heff_strAppend(heff_get_n(v_c_24109, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str54));
          v_t_24112 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str55), v_t_24111);
        } else {
          v_t_24112 = heff_get_n(v_c_24109, 0, 2);
        }
        V v_t_24113 = heff_strAppend(v_t_24108, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str56), v_t_24112));
        V v_t_24114 = heff_strAppend(v_t_24104, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str57), v_t_24113));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24114, MK_INT(0LL)});
      }
      case TAG_JNot: {
        V v_c_24116 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24119;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24116, 1)), MK_INT(1LL))) {
          V v_t_24118 = heff_strAppend(heff_get_n(v_c_24116, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str58));
          v_t_24119 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str59), v_t_24118);
        } else {
          v_t_24119 = heff_get_n(v_c_24116, 0, 2);
        }
        V v_c_24120 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24123;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24120, 1)), MK_INT(0LL))) {
          V v_t_24122 = heff_strAppend(heff_get_n(v_c_24120, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str60));
          v_t_24123 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str61), v_t_24122);
        } else {
          v_t_24123 = heff_get_n(v_c_24120, 0, 2);
        }
        V v_c_24124 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24127;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24124, 1)), MK_INT(0LL))) {
          V v_t_24126 = heff_strAppend(heff_get_n(v_c_24124, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str62));
          v_t_24127 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str63), v_t_24126);
        } else {
          v_t_24127 = heff_get_n(v_c_24124, 0, 2);
        }
        V v_t_24128 = heff_strAppend(v_t_24123, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str64), v_t_24127));
        V v_t_24129 = heff_strAppend(v_t_24119, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str65), v_t_24128));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24129, MK_INT(0LL)});
      }
      case TAG_JIf: {
        V v_c_24133 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24136;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24133, 1)), MK_INT(1LL))) {
          V v_t_24135 = heff_strAppend(heff_get_n(v_c_24133, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str66));
          v_t_24136 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str67), v_t_24135);
        } else {
          v_t_24136 = heff_get_n(v_c_24133, 0, 2);
        }
        V v_c_24137 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24140;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24137, 1)), MK_INT(0LL))) {
          V v_t_24139 = heff_strAppend(heff_get_n(v_c_24137, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str68));
          v_t_24140 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str69), v_t_24139);
        } else {
          v_t_24140 = heff_get_n(v_c_24137, 0, 2);
        }
        V v_c_24141 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24144;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24141, 1)), MK_INT(0LL))) {
          V v_t_24143 = heff_strAppend(heff_get_n(v_c_24141, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str70));
          v_t_24144 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str71), v_t_24143);
        } else {
          v_t_24144 = heff_get_n(v_c_24141, 0, 2);
        }
        V v_t_24145 = heff_strAppend(v_t_24140, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str72), v_t_24144));
        V v_t_24146 = heff_strAppend(v_t_24136, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str73), v_t_24145));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24146, MK_INT(0LL)});
      }
      case TAG_JSeq: {
        V v_c_24150 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24153;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24150, 1)), MK_INT(1LL))) {
          V v_t_24152 = heff_strAppend(heff_get_n(v_c_24150, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str74));
          v_t_24153 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str75), v_t_24152);
        } else {
          v_t_24153 = heff_get_n(v_c_24150, 0, 2);
        }
        V v_c_24154 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24157;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24154, 1)), MK_INT(0LL))) {
          V v_t_24156 = heff_strAppend(heff_get_n(v_c_24154, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str76));
          v_t_24157 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str77), v_t_24156);
        } else {
          v_t_24157 = heff_get_n(v_c_24154, 0, 2);
        }
        V v_c_24158 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24161;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24158, 1)), MK_INT(0LL))) {
          V v_t_24160 = heff_strAppend(heff_get_n(v_c_24158, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str78));
          v_t_24161 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str79), v_t_24160);
        } else {
          v_t_24161 = heff_get_n(v_c_24158, 0, 2);
        }
        V v_t_24162 = heff_strAppend(v_t_24157, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str80), v_t_24161));
        V v_t_24163 = heff_strAppend(v_t_24153, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str81), v_t_24162));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24163, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_JNot: {
      switch (heff_tag_of(v_t_248)) {
      case TAG_JTrue: {
        V v_c_24165 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24168;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24165, 1)), MK_INT(1LL))) {
          V v_t_24167 = heff_strAppend(heff_get_n(v_c_24165, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str82));
          v_t_24168 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str83), v_t_24167);
        } else {
          v_t_24168 = heff_get_n(v_c_24165, 0, 2);
        }
        V v_c_24169 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24172;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24169, 1)), MK_INT(1LL))) {
          V v_t_24171 = heff_strAppend(heff_get_n(v_c_24169, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str84));
          v_t_24172 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str85), v_t_24171);
        } else {
          v_t_24172 = heff_get_n(v_c_24169, 0, 2);
        }
        V v_t_24173 = heff_strAppend(v_t_24168, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str86), v_t_24172));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24173, MK_INT(1LL)});
      }
      case TAG_JFalse: {
        V v_c_24174 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_24177;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24174, 1)), MK_INT(2LL))) {
          V v_t_24176 = heff_strAppend(heff_get_n(v_c_24174, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str87));
          v_t_24177 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str88), v_t_24176);
        } else {
          v_t_24177 = heff_get_n(v_c_24174, 0, 2);
        }
        V v_c_24178 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24181;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24178, 1)), MK_INT(2LL))) {
          V v_t_24180 = heff_strAppend(heff_get_n(v_c_24178, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str89));
          v_t_24181 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str90), v_t_24180);
        } else {
          v_t_24181 = heff_get_n(v_c_24178, 0, 2);
        }
        V v_t_24182 = heff_strAppend(v_t_24177, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str91), v_t_24181));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24182, MK_INT(2LL)});
      }
      case TAG_JRel: {
        V v_c_24184 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24187;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24184, 1)), MK_INT(1LL))) {
          V v_t_24186 = heff_strAppend(heff_get_n(v_c_24184, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str92));
          v_t_24187 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str93), v_t_24186);
        } else {
          v_t_24187 = heff_get_n(v_c_24184, 0, 2);
        }
        V v_c_24188 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24191;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24188, 1)), MK_INT(0LL))) {
          V v_t_24190 = heff_strAppend(heff_get_n(v_c_24188, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str94));
          v_t_24191 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str95), v_t_24190);
        } else {
          v_t_24191 = heff_get_n(v_c_24188, 0, 2);
        }
        V v_c_24192 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24195;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24192, 1)), MK_INT(0LL))) {
          V v_t_24194 = heff_strAppend(heff_get_n(v_c_24192, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str96));
          v_t_24195 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str97), v_t_24194);
        } else {
          v_t_24195 = heff_get_n(v_c_24192, 0, 2);
        }
        V v_t_24196 = heff_strAppend(v_t_24191, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str98), v_t_24195));
        V v_t_24197 = heff_strAppend(v_t_24187, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str99), v_t_24196));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24197, MK_INT(0LL)});
      }
      case TAG_JNot: {
        V v_c_24199 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24202;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24199, 1)), MK_INT(1LL))) {
          V v_t_24201 = heff_strAppend(heff_get_n(v_c_24199, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str100));
          v_t_24202 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str101), v_t_24201);
        } else {
          v_t_24202 = heff_get_n(v_c_24199, 0, 2);
        }
        V v_c_24203 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24206;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24203, 1)), MK_INT(0LL))) {
          V v_t_24205 = heff_strAppend(heff_get_n(v_c_24203, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str102));
          v_t_24206 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str103), v_t_24205);
        } else {
          v_t_24206 = heff_get_n(v_c_24203, 0, 2);
        }
        V v_c_24207 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24210;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24207, 1)), MK_INT(0LL))) {
          V v_t_24209 = heff_strAppend(heff_get_n(v_c_24207, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str104));
          v_t_24210 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str105), v_t_24209);
        } else {
          v_t_24210 = heff_get_n(v_c_24207, 0, 2);
        }
        V v_t_24211 = heff_strAppend(v_t_24206, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str106), v_t_24210));
        V v_t_24212 = heff_strAppend(v_t_24202, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str107), v_t_24211));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24212, MK_INT(0LL)});
      }
      case TAG_JIf: {
        V v_c_24216 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24219;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24216, 1)), MK_INT(1LL))) {
          V v_t_24218 = heff_strAppend(heff_get_n(v_c_24216, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str108));
          v_t_24219 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str109), v_t_24218);
        } else {
          v_t_24219 = heff_get_n(v_c_24216, 0, 2);
        }
        V v_c_24220 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24223;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24220, 1)), MK_INT(0LL))) {
          V v_t_24222 = heff_strAppend(heff_get_n(v_c_24220, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str110));
          v_t_24223 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str111), v_t_24222);
        } else {
          v_t_24223 = heff_get_n(v_c_24220, 0, 2);
        }
        V v_c_24224 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24227;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24224, 1)), MK_INT(0LL))) {
          V v_t_24226 = heff_strAppend(heff_get_n(v_c_24224, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str112));
          v_t_24227 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str113), v_t_24226);
        } else {
          v_t_24227 = heff_get_n(v_c_24224, 0, 2);
        }
        V v_t_24228 = heff_strAppend(v_t_24223, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str114), v_t_24227));
        V v_t_24229 = heff_strAppend(v_t_24219, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str115), v_t_24228));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24229, MK_INT(0LL)});
      }
      case TAG_JSeq: {
        V v_c_24233 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24236;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24233, 1)), MK_INT(1LL))) {
          V v_t_24235 = heff_strAppend(heff_get_n(v_c_24233, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str116));
          v_t_24236 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str117), v_t_24235);
        } else {
          v_t_24236 = heff_get_n(v_c_24233, 0, 2);
        }
        V v_c_24237 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24240;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24237, 1)), MK_INT(0LL))) {
          V v_t_24239 = heff_strAppend(heff_get_n(v_c_24237, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str118));
          v_t_24240 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str119), v_t_24239);
        } else {
          v_t_24240 = heff_get_n(v_c_24237, 0, 2);
        }
        V v_c_24241 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24244;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24241, 1)), MK_INT(0LL))) {
          V v_t_24243 = heff_strAppend(heff_get_n(v_c_24241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str120));
          v_t_24244 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str121), v_t_24243);
        } else {
          v_t_24244 = heff_get_n(v_c_24241, 0, 2);
        }
        V v_t_24245 = heff_strAppend(v_t_24240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str122), v_t_24244));
        V v_t_24246 = heff_strAppend(v_t_24236, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str123), v_t_24245));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24246, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_JIf: {
      switch (heff_tag_of(v_t_248)) {
      case TAG_JTrue: {
        V v_c_24250 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24253;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24250, 1)), MK_INT(1LL))) {
          V v_t_24252 = heff_strAppend(heff_get_n(v_c_24250, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str124));
          v_t_24253 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str125), v_t_24252);
        } else {
          v_t_24253 = heff_get_n(v_c_24250, 0, 2);
        }
        V v_c_24254 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24257;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24254, 1)), MK_INT(1LL))) {
          V v_t_24256 = heff_strAppend(heff_get_n(v_c_24254, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str126));
          v_t_24257 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str127), v_t_24256);
        } else {
          v_t_24257 = heff_get_n(v_c_24254, 0, 2);
        }
        V v_t_24258 = heff_strAppend(v_t_24253, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str128), v_t_24257));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24258, MK_INT(1LL)});
      }
      case TAG_JFalse: {
        V v_c_24259 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_24262;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24259, 1)), MK_INT(2LL))) {
          V v_t_24261 = heff_strAppend(heff_get_n(v_c_24259, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str129));
          v_t_24262 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str130), v_t_24261);
        } else {
          v_t_24262 = heff_get_n(v_c_24259, 0, 2);
        }
        V v_c_24263 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24266;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24263, 1)), MK_INT(2LL))) {
          V v_t_24265 = heff_strAppend(heff_get_n(v_c_24263, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str131));
          v_t_24266 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str132), v_t_24265);
        } else {
          v_t_24266 = heff_get_n(v_c_24263, 0, 2);
        }
        V v_t_24267 = heff_strAppend(v_t_24262, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str133), v_t_24266));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24267, MK_INT(2LL)});
      }
      case TAG_JRel: {
        V v_c_24269 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24272;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24269, 1)), MK_INT(1LL))) {
          V v_t_24271 = heff_strAppend(heff_get_n(v_c_24269, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str134));
          v_t_24272 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str135), v_t_24271);
        } else {
          v_t_24272 = heff_get_n(v_c_24269, 0, 2);
        }
        V v_c_24273 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24276;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24273, 1)), MK_INT(0LL))) {
          V v_t_24275 = heff_strAppend(heff_get_n(v_c_24273, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str136));
          v_t_24276 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str137), v_t_24275);
        } else {
          v_t_24276 = heff_get_n(v_c_24273, 0, 2);
        }
        V v_c_24277 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24280;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24277, 1)), MK_INT(0LL))) {
          V v_t_24279 = heff_strAppend(heff_get_n(v_c_24277, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str138));
          v_t_24280 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str139), v_t_24279);
        } else {
          v_t_24280 = heff_get_n(v_c_24277, 0, 2);
        }
        V v_t_24281 = heff_strAppend(v_t_24276, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str140), v_t_24280));
        V v_t_24282 = heff_strAppend(v_t_24272, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str141), v_t_24281));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24282, MK_INT(0LL)});
      }
      case TAG_JNot: {
        V v_c_24284 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24287;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24284, 1)), MK_INT(1LL))) {
          V v_t_24286 = heff_strAppend(heff_get_n(v_c_24284, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str142));
          v_t_24287 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str143), v_t_24286);
        } else {
          v_t_24287 = heff_get_n(v_c_24284, 0, 2);
        }
        V v_c_24288 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24291;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24288, 1)), MK_INT(0LL))) {
          V v_t_24290 = heff_strAppend(heff_get_n(v_c_24288, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str144));
          v_t_24291 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str145), v_t_24290);
        } else {
          v_t_24291 = heff_get_n(v_c_24288, 0, 2);
        }
        V v_c_24292 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24295;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24292, 1)), MK_INT(0LL))) {
          V v_t_24294 = heff_strAppend(heff_get_n(v_c_24292, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str146));
          v_t_24295 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str147), v_t_24294);
        } else {
          v_t_24295 = heff_get_n(v_c_24292, 0, 2);
        }
        V v_t_24296 = heff_strAppend(v_t_24291, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str148), v_t_24295));
        V v_t_24297 = heff_strAppend(v_t_24287, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str149), v_t_24296));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24297, MK_INT(0LL)});
      }
      case TAG_JIf: {
        V v_c_24301 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24304;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24301, 1)), MK_INT(1LL))) {
          V v_t_24303 = heff_strAppend(heff_get_n(v_c_24301, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str150));
          v_t_24304 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str151), v_t_24303);
        } else {
          v_t_24304 = heff_get_n(v_c_24301, 0, 2);
        }
        V v_c_24305 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24308;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24305, 1)), MK_INT(0LL))) {
          V v_t_24307 = heff_strAppend(heff_get_n(v_c_24305, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str152));
          v_t_24308 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str153), v_t_24307);
        } else {
          v_t_24308 = heff_get_n(v_c_24305, 0, 2);
        }
        V v_c_24309 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24312;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24309, 1)), MK_INT(0LL))) {
          V v_t_24311 = heff_strAppend(heff_get_n(v_c_24309, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str154));
          v_t_24312 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str155), v_t_24311);
        } else {
          v_t_24312 = heff_get_n(v_c_24309, 0, 2);
        }
        V v_t_24313 = heff_strAppend(v_t_24308, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str156), v_t_24312));
        V v_t_24314 = heff_strAppend(v_t_24304, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str157), v_t_24313));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24314, MK_INT(0LL)});
      }
      case TAG_JSeq: {
        V v_c_24318 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24321;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24318, 1)), MK_INT(1LL))) {
          V v_t_24320 = heff_strAppend(heff_get_n(v_c_24318, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str158));
          v_t_24321 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str159), v_t_24320);
        } else {
          v_t_24321 = heff_get_n(v_c_24318, 0, 2);
        }
        V v_c_24322 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24325;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24322, 1)), MK_INT(0LL))) {
          V v_t_24324 = heff_strAppend(heff_get_n(v_c_24322, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str160));
          v_t_24325 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str161), v_t_24324);
        } else {
          v_t_24325 = heff_get_n(v_c_24322, 0, 2);
        }
        V v_c_24326 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24329;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24326, 1)), MK_INT(0LL))) {
          V v_t_24328 = heff_strAppend(heff_get_n(v_c_24326, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str162));
          v_t_24329 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str163), v_t_24328);
        } else {
          v_t_24329 = heff_get_n(v_c_24326, 0, 2);
        }
        V v_t_24330 = heff_strAppend(v_t_24325, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str164), v_t_24329));
        V v_t_24331 = heff_strAppend(v_t_24321, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str165), v_t_24330));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24331, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_JSeq: {
      switch (heff_tag_of(v_t_248)) {
      case TAG_JTrue: {
        V v_c_24335 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24338;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24335, 1)), MK_INT(1LL))) {
          V v_t_24337 = heff_strAppend(heff_get_n(v_c_24335, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str166));
          v_t_24338 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str167), v_t_24337);
        } else {
          v_t_24338 = heff_get_n(v_c_24335, 0, 2);
        }
        V v_c_24339 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24342;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24339, 1)), MK_INT(1LL))) {
          V v_t_24341 = heff_strAppend(heff_get_n(v_c_24339, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str168));
          v_t_24342 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str169), v_t_24341);
        } else {
          v_t_24342 = heff_get_n(v_c_24339, 0, 2);
        }
        V v_t_24343 = heff_strAppend(v_t_24338, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str170), v_t_24342));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24343, MK_INT(1LL)});
      }
      case TAG_JFalse: {
        V v_c_24344 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_JNot, 1, (V[]){v_c_247})));
        V v_t_24347;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24344, 1)), MK_INT(2LL))) {
          V v_t_24346 = heff_strAppend(heff_get_n(v_c_24344, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str171));
          v_t_24347 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str172), v_t_24346);
        } else {
          v_t_24347 = heff_get_n(v_c_24344, 0, 2);
        }
        V v_c_24348 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24351;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24348, 1)), MK_INT(2LL))) {
          V v_t_24350 = heff_strAppend(heff_get_n(v_c_24348, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str173));
          v_t_24351 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str174), v_t_24350);
        } else {
          v_t_24351 = heff_get_n(v_c_24348, 0, 2);
        }
        V v_t_24352 = heff_strAppend(v_t_24347, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str175), v_t_24351));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24352, MK_INT(2LL)});
      }
      case TAG_JRel: {
        V v_c_24354 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24357;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24354, 1)), MK_INT(1LL))) {
          V v_t_24356 = heff_strAppend(heff_get_n(v_c_24354, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str176));
          v_t_24357 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str177), v_t_24356);
        } else {
          v_t_24357 = heff_get_n(v_c_24354, 0, 2);
        }
        V v_c_24358 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24361;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24358, 1)), MK_INT(0LL))) {
          V v_t_24360 = heff_strAppend(heff_get_n(v_c_24358, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str178));
          v_t_24361 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str179), v_t_24360);
        } else {
          v_t_24361 = heff_get_n(v_c_24358, 0, 2);
        }
        V v_c_24362 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24365;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24362, 1)), MK_INT(0LL))) {
          V v_t_24364 = heff_strAppend(heff_get_n(v_c_24362, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str180));
          v_t_24365 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str181), v_t_24364);
        } else {
          v_t_24365 = heff_get_n(v_c_24362, 0, 2);
        }
        V v_t_24366 = heff_strAppend(v_t_24361, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str182), v_t_24365));
        V v_t_24367 = heff_strAppend(v_t_24357, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str183), v_t_24366));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24367, MK_INT(0LL)});
      }
      case TAG_JNot: {
        V v_c_24369 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24372;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24369, 1)), MK_INT(1LL))) {
          V v_t_24371 = heff_strAppend(heff_get_n(v_c_24369, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str184));
          v_t_24372 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str185), v_t_24371);
        } else {
          v_t_24372 = heff_get_n(v_c_24369, 0, 2);
        }
        V v_c_24373 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24376;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24373, 1)), MK_INT(0LL))) {
          V v_t_24375 = heff_strAppend(heff_get_n(v_c_24373, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str186));
          v_t_24376 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str187), v_t_24375);
        } else {
          v_t_24376 = heff_get_n(v_c_24373, 0, 2);
        }
        V v_c_24377 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24380;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24377, 1)), MK_INT(0LL))) {
          V v_t_24379 = heff_strAppend(heff_get_n(v_c_24377, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str188));
          v_t_24380 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str189), v_t_24379);
        } else {
          v_t_24380 = heff_get_n(v_c_24377, 0, 2);
        }
        V v_t_24381 = heff_strAppend(v_t_24376, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str190), v_t_24380));
        V v_t_24382 = heff_strAppend(v_t_24372, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str191), v_t_24381));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24382, MK_INT(0LL)});
      }
      case TAG_JIf: {
        V v_c_24386 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24389;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24386, 1)), MK_INT(1LL))) {
          V v_t_24388 = heff_strAppend(heff_get_n(v_c_24386, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str192));
          v_t_24389 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str193), v_t_24388);
        } else {
          v_t_24389 = heff_get_n(v_c_24386, 0, 2);
        }
        V v_c_24390 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24393;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24390, 1)), MK_INT(0LL))) {
          V v_t_24392 = heff_strAppend(heff_get_n(v_c_24390, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str194));
          v_t_24393 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str195), v_t_24392);
        } else {
          v_t_24393 = heff_get_n(v_c_24390, 0, 2);
        }
        V v_c_24394 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24397;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24394, 1)), MK_INT(0LL))) {
          V v_t_24396 = heff_strAppend(heff_get_n(v_c_24394, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str196));
          v_t_24397 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str197), v_t_24396);
        } else {
          v_t_24397 = heff_get_n(v_c_24394, 0, 2);
        }
        V v_t_24398 = heff_strAppend(v_t_24393, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str198), v_t_24397));
        V v_t_24399 = heff_strAppend(v_t_24389, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str199), v_t_24398));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24399, MK_INT(0LL)});
      }
      case TAG_JSeq: {
        V v_c_24403 = (g_heff_2ecompile_2eemit_2econdCode(v_c_247));
        V v_t_24406;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24403, 1)), MK_INT(1LL))) {
          V v_t_24405 = heff_strAppend(heff_get_n(v_c_24403, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str200));
          v_t_24406 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str201), v_t_24405);
        } else {
          v_t_24406 = heff_get_n(v_c_24403, 0, 2);
        }
        V v_c_24407 = (g_heff_2ecompile_2eemit_2econdCode(v_t_248));
        V v_t_24410;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24407, 1)), MK_INT(0LL))) {
          V v_t_24409 = heff_strAppend(heff_get_n(v_c_24407, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str202));
          v_t_24410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str203), v_t_24409);
        } else {
          v_t_24410 = heff_get_n(v_c_24407, 0, 2);
        }
        V v_c_24411 = (g_heff_2ecompile_2eemit_2econdCode(v_x13_249));
        V v_t_24414;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24411, 1)), MK_INT(0LL))) {
          V v_t_24413 = heff_strAppend(heff_get_n(v_c_24411, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str204));
          v_t_24414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str205), v_t_24413);
        } else {
          v_t_24414 = heff_get_n(v_c_24411, 0, 2);
        }
        V v_t_24415 = heff_strAppend(v_t_24410, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str206), v_t_24414));
        V v_t_24416 = heff_strAppend(v_t_24406, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str207), v_t_24415));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24416, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_x13_249);
    }
  }
  case TAG_JSeq: {
    V v_x_24417 = heff_field(v_x1_240, 0);
    V v_a_24418 = heff_field(v_x1_240, 1);
    V v_q_24419 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_c_24420 = (g_heff_2ecompile_2eemit_2econdCode(v_q_24419));
    V v_t_24423;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_24420, 1)), MK_INT(1LL))) {
      V v_t_24422 = heff_strAppend(heff_get_n(v_c_24420, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str208));
      v_t_24423 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str209), v_t_24422);
    } else {
      v_t_24423 = heff_get_n(v_c_24420, 0, 2);
    }
    V v_t_24424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str210), heff_strAppend(v_t_24423, ((V)&g_heff_2ecompile_2eemit_2econdCode_str211)));
    V v_t_24425 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str212), heff_strAppend(v_a_24418, v_t_24424));
    V v_t_24426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str213), heff_strAppend(v_x_24417, v_t_24425));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_24426, MK_INT(4LL)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str5, 4, "let ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str6, 1, ";");
Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eletDeclarations_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eletDeclarations(V v_ind_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x2_244 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_x2_248 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_241));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str4); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str5), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str6)));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_t_2412), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eletDeclarations(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2earmJs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2earmJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmJs_entry, 6, 0};

V g_heff_2ecompile_2eemit_2earmJs(V v_sc_240, V v_ind_241, V v_tag_242, V v_vs_243, V v_parts_244, V v_lines_245) {
top: ;
  V v_t_248 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eemit_2earmJs_lam0, 1, 1, (V[]){heff_dup(v_parts_244)}), v_vs_243));
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_vs_243);
    heff_drop(v_t_248);
    V v_t_249 = heff_tr(heff_call(v_lines_245, 2, (V[]){heff_get_n(v_sc_240, 1, 3), heff_intAdd(v_ind_241, MK_INT(2LL))}));
    return heff_tag_n(TAG_MkArmJs, 3, (V[]){v_tag_242, NTAG(TAG_True), v_t_249});
  } else {
    heff_drop(v_t_248);
    V v_t_2410 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), heff_dup(heff_rfield(v_sc_240, 1))});
    V v_t_2411 = (g_list_2efoldl_24s135909237x326578890(v_t_2410, v_vs_243));
    return (g_heff_2ecompile_2eemit_2earmBound(v_sc_240, v_ind_241, v_tag_242, v_lines_245, v_t_2411));
  }
}
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eemit_2earmJs(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eemit_2earmJs_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_parts_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_v_246; V a_1 = v_parts_244; V r_ = (g_list_2eany_24s1721003522x874107866(a_0, a_1)); heff_drop(v_parts_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str3, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str7, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str8, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str12, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str13, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str14, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str15, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str16, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str19, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str23, 1, "}");
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemit_2esharedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esharedGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2esharedGo(V v_ind_240, V v_before_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    heff_drop(v_before_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArmJs: {
      V v_a2_246 = heff_dup(heff_field(v_a_243, 1));
      V v_ls_247 = heff_dup(heff_field(v_a_243, 2));
      if ((heff_dup(v_a2_246) == NTAG(TAG_True))) {
        heff_drop(v_a2_246);
        V v_t_2423 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), v_before_241));
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_ls_247);
          heff_drop(v_t_2423);
          V t_0 = v_ind_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241});
          V t_2 = v_rest_244;
          v_ind_240 = t_0;
          v_before_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_t_2423);
          V v_t_2439 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam1, 1, 1, (V[]){heff_dup(v_a_243)}), heff_dup(v_rest_244)));
          V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam2, 1, 1, (V[]){heff_dup(v_ind_240)}), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_243), v_t_2439})));
          V v_x2_2453 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str16)));
          V v_t_2456;
          switch (heff_tag_of(v_x2_2453)) {
          case TAG_Nil: {
            v_t_2456 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str17);
            break;
          }
          case TAG_Cons: {
            V v_x_2454 = heff_field(v_x2_2453, 0);
            V v_xs_2455 = heff_field(v_x2_2453, 1);
            heff_take_n(v_x2_2453, 3ULL, 2);
            v_t_2456 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str18); V a_1 = v_x_2454; V a_2 = v_xs_2455; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2455); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2453);
          }
          V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2456, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str19)), NTAG(TAG_Nil)});
          V v_x2_2458 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str20)));
          V v_t_2461;
          switch (heff_tag_of(v_x2_2458)) {
          case TAG_Nil: {
            v_t_2461 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str21);
            break;
          }
          case TAG_Cons: {
            V v_x_2459 = heff_field(v_x2_2458, 0);
            V v_xs_2460 = heff_field(v_x2_2458, 1);
            heff_take_n(v_x2_2458, 3ULL, 2);
            v_t_2461 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str22); V a_1 = v_x_2459; V a_2 = v_xs_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2458);
          }
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str23)), NTAG(TAG_Nil)});
          V v_t_2463 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
          V v_t_2464 = (g_prelude_2e_2b_2b(v_t_2462, v_t_2463));
          V v_t_2465 = (g_prelude_2e_2b_2b(v_ls_247, v_t_2464));
          V v_t_2466 = (g_prelude_2e_2b_2b(v_t_2457, v_t_2465));
          return (g_prelude_2e_2b_2b(v_t_2452, v_t_2466));
        }
      } else {
        heff_drop(v_a2_246);
        V v_t_2467 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
        return (g_prelude_2e_2b_2b(v_ls_247, v_t_2467));
      }
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esharedGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args) {
  V v_b_248 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2410 = heff_field(v_a_243, 1);
    V v_ls_2411 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    if ((heff_dup(v_x12_2410) == NTAG(TAG_True))) {
      heff_drop(v_x12_2410);
      V v_t_2414;
      switch (heff_tag_of(v_ls_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_ls_2411, 0);
        V v_xs_2413 = heff_field(v_ls_2411, 1);
        heff_take_n(v_ls_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2411);
      }
      V v_t_2421;
      switch (heff_tag_of(v_b_248)) {
      case TAG_MkArmJs: {
        V v_x12_2416 = heff_field(v_b_248, 1);
        V v_ls_2417 = heff_field(v_b_248, 2);
        heff_take_n(v_b_248, 6ULL, 3);
        if ((heff_dup(v_x12_2416) == NTAG(TAG_True))) {
          heff_drop(v_x12_2416);
          V v_t_2420;
          switch (heff_tag_of(v_ls_2417)) {
          case TAG_Nil: {
            v_t_2420 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str2);
            break;
          }
          case TAG_Cons: {
            V v_x_2418 = heff_field(v_ls_2417, 0);
            V v_xs_2419 = heff_field(v_ls_2417, 1);
            heff_take_n(v_ls_2417, 3ULL, 2);
            v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str3); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
            break;
          }
          default: heff_nomatch(v_ls_2417);
          }
          v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
        } else {
          heff_drop(v_x12_2416);
          heff_drop(v_ls_2417);
          v_t_2421 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_b_248);
      }
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop(v_t_2414);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_k2_2422 = heff_field(v_t_2421, 0);
        heff_take_n(v_t_2421, 1ULL, 1);
        return heff_strEq(v_t_2414, v_k2_2422);
      }
      default: return heff_nomatch(v_t_2421);
      }
    } else {
      heff_drop(v_b_248);
      heff_drop(v_x12_2410);
      heff_drop(v_ls_2411);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args) {
  V v_b_2424 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2426 = heff_field(v_a_243, 1);
    V v_ls_2427 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    if ((heff_dup(v_x12_2426) == NTAG(TAG_True))) {
      heff_drop(v_x12_2426);
      V v_t_2430;
      switch (heff_tag_of(v_ls_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_ls_2427, 0);
        V v_xs_2429 = heff_field(v_ls_2427, 1);
        heff_take_n(v_ls_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str5); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2427);
      }
      V v_t_2437;
      switch (heff_tag_of(v_b_2424)) {
      case TAG_MkArmJs: {
        V v_x12_2432 = heff_field(v_b_2424, 1);
        V v_ls_2433 = heff_field(v_b_2424, 2);
        heff_take_n(v_b_2424, 6ULL, 3);
        if ((heff_dup(v_x12_2432) == NTAG(TAG_True))) {
          heff_drop(v_x12_2432);
          V v_t_2436;
          switch (heff_tag_of(v_ls_2433)) {
          case TAG_Nil: {
            v_t_2436 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str6);
            break;
          }
          case TAG_Cons: {
            V v_x_2434 = heff_field(v_ls_2433, 0);
            V v_xs_2435 = heff_field(v_ls_2433, 1);
            heff_take_n(v_ls_2433, 3ULL, 2);
            v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str7); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
            break;
          }
          default: heff_nomatch(v_ls_2433);
          }
          v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2436});
        } else {
          heff_drop(v_x12_2432);
          heff_drop(v_ls_2433);
          v_t_2437 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_b_2424);
      }
      switch (heff_tag_of(v_t_2437)) {
      case TAG_Nothing: {
        heff_drop(v_t_2430);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_k2_2438 = heff_field(v_t_2437, 0);
        heff_take_n(v_t_2437, 1ULL, 1);
        return heff_strEq(v_t_2430, v_k2_2438);
      }
      default: return heff_nomatch(v_t_2437);
      }
    } else {
      heff_drop(v_b_2424);
      heff_drop(v_x12_2426);
      heff_drop(v_ls_2427);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args) {
  V v_b_2440 = args[0];
  V v_ind_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2441 = (g_list_2ereplicate(heff_intAdd(v_ind_240, MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str8)));
  V v_t_2444;
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_Nil: {
    v_t_2444 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_xs_2443 = heff_field(v_x2_2441, 1);
    heff_take_n(v_x2_2441, 3ULL, 2);
    v_t_2444 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str10); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2441);
  }
  V v_t_2448;
  switch (heff_tag_of(v_b_2440)) {
  case TAG_MkArmJs: {
    V v_t_2445 = heff_field(v_b_2440, 0);
    heff_take_n(v_b_2440, 1ULL, 3);
    v_t_2448 = v_t_2445;
    break;
  }
  default: heff_nomatch(v_b_2440);
  }
  V v_t_2449 = (g_heff_2ecompile_2eemit_2equoteGo(v_t_2448, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str11)));
  V v_t_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str12), heff_strAppend(v_t_2449, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str13)));
  V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str14), heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str15)));
  return heff_strAppend(v_t_2444, v_t_2451);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str5, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str6, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esetStmt_str7, 1, ";");
Clo g_heff_2ecompile_2eemit_2esetStmt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esetStmt_entry, 4, 0};

V g_heff_2ecompile_2eemit_2esetStmt(V v_ind_240, V v_st_241, V v_x_242, V v_env_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), heff_dup(heff_rfield(v_st_241, 1))));
  V v_x2_245 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2esetStmt_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_x_242)), MK_INT(1LL));
  V v_t_2410 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x_242), v_t_249));
  V v_t_2411 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_s_2412 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_2411, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2esetStmt_str3)));
  V v_t_2414;
  if (heff_strEq_c(heff_dup(v_s_2412), ((V)&g_heff_2ecompile_2eemit_2esetStmt_str4))) {
    heff_drop(v_s_2412);
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2esetStmt_str5);
  } else {
    v_t_2414 = v_s_2412;
  }
  V v_d_2415 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2414));
  V v_x2_2416 = (g_map_2elookup_24s1546226666x2146984184(v_x_242, heff_rfield(v_env_243, 1)));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nothing: {
    v_t_2418 = v_d_2415;
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    heff_take_n(v_x2_2416, 1ULL, 1);
    heff_drop(v_d_2415);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_st_241, 0)), 0, 2);
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esetStmt_str6), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2esetStmt_str7)));
  V v_t_2421 = heff_strAppend(v_t_248, heff_strAppend(v_t_2418, v_t_2420));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_244, v_t_2422));
  V v_t_2424 = ({ V a_0 = v_env_243; V b_1 = heff_get_n(v_st_241, 1, 2); V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, b_1)); heff_drop(b_1); r_; });
  return heff_rec_n(2, shape_lines__env, (V[]){v_t_2423, v_t_2424});
}
V g_heff_2ecompile_2eemit_2esetStmt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esetStmt(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eemit_2einlinable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2einlinable_entry, 4, 0};

V g_heff_2ecompile_2eemit_2einlinable(V v_x_240, V v_o_241, V v_rest_242, V v_after_243) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_t_2418;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_t_2418 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_245 = heff_field(v_after_243, 0);
        v_t_2418 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_245));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_246 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_246)) {
      case TAG_SLet: {
        V v_o_249 = heff_field(v_st_246, 1);
        heff_take_n(v_st_246, 2ULL, 2);
        v_t_2418 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_249));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_246, 0ULL, 1);
        v_t_2418 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2412 = heff_field(v_st_246, 1);
        heff_take_n(v_st_246, 2ULL, 2);
        v_t_2418 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2412));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_246, 0ULL, 3);
        v_t_2418 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2416 = heff_field(v_st_246, 0);
        heff_take_n(v_st_246, 1ULL, 2);
        v_t_2418 = ({ V a_0 = v_v_2416; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2416); r_; });
        break;
      }
      default: heff_nomatch(v_st_246);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_t_2422;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2421 = heff_field(v_after_243, 0);
      v_t_2422 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2421, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2422));
    return ({ V a_0 = v_x_240; V a_1 = v_t_2418; V a_2 = v_t_2423; V r_ = (g_heff_2ecompile_2eimperative_2eusedOnceNext(a_0, a_1, a_2)); heff_drop(v_t_2418); heff_drop(v_t_2423); r_; });
  }
  case TAG_OCall: {
    V v_t_2439;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_t_2439 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2426 = heff_field(v_after_243, 0);
        v_t_2439 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2426));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2427 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2427)) {
      case TAG_SLet: {
        V v_o_2430 = heff_field(v_st_2427, 1);
        heff_take_n(v_st_2427, 2ULL, 2);
        v_t_2439 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2430));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2427, 0ULL, 1);
        v_t_2439 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2433 = heff_field(v_st_2427, 1);
        heff_take_n(v_st_2427, 2ULL, 2);
        v_t_2439 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2433));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2427, 0ULL, 3);
        v_t_2439 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2437 = heff_field(v_st_2427, 0);
        heff_take_n(v_st_2427, 1ULL, 2);
        v_t_2439 = ({ V a_0 = v_v_2437; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2437); r_; });
        break;
      }
      default: heff_nomatch(v_st_2427);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2441 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2440; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2440); r_; });
    V v_t_2443;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2442 = heff_field(v_after_243, 0);
      v_t_2443 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2442, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2441, v_t_2443));
    return ({ V a_0 = v_x_240; V a_1 = v_t_2439; V a_2 = v_t_2444; V r_ = (g_heff_2ecompile_2eimperative_2eusedOnceNext(a_0, a_1, a_2)); heff_drop(v_t_2439); heff_drop(v_t_2444); r_; });
  }
  case TAG_OApply: {
    V v_t_2460;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_t_2460 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2447 = heff_field(v_after_243, 0);
        v_t_2460 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2447));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2448 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2448)) {
      case TAG_SLet: {
        V v_o_2451 = heff_field(v_st_2448, 1);
        heff_take_n(v_st_2448, 2ULL, 2);
        v_t_2460 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2451));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2448, 0ULL, 1);
        v_t_2460 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2454 = heff_field(v_st_2448, 1);
        heff_take_n(v_st_2448, 2ULL, 2);
        v_t_2460 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2454));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2448, 0ULL, 3);
        v_t_2460 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2458 = heff_field(v_st_2448, 0);
        heff_take_n(v_st_2448, 1ULL, 2);
        v_t_2460 = ({ V a_0 = v_v_2458; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2458); r_; });
        break;
      }
      default: heff_nomatch(v_st_2448);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2462 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2461; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2461); r_; });
    V v_t_2464;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2464 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2463 = heff_field(v_after_243, 0);
      v_t_2464 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2463, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_t_2465 = (g_prelude_2e_2b_2b(v_t_2462, v_t_2464));
    return ({ V a_0 = v_x_240; V a_1 = v_t_2460; V a_2 = v_t_2465; V r_ = (g_heff_2ecompile_2eimperative_2eusedOnceNext(a_0, a_1, a_2)); heff_drop(v_t_2460); heff_drop(v_t_2465); r_; });
  }
  case TAG_OPrim: {
    V v_t_2481;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_t_2481 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2468 = heff_field(v_after_243, 0);
        v_t_2481 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2468));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2469 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2469)) {
      case TAG_SLet: {
        V v_o_2472 = heff_field(v_st_2469, 1);
        heff_take_n(v_st_2469, 2ULL, 2);
        v_t_2481 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2472));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2469, 0ULL, 1);
        v_t_2481 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2475 = heff_field(v_st_2469, 1);
        heff_take_n(v_st_2469, 2ULL, 2);
        v_t_2481 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2475));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2469, 0ULL, 3);
        v_t_2481 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2479 = heff_field(v_st_2469, 0);
        heff_take_n(v_st_2469, 1ULL, 2);
        v_t_2481 = ({ V a_0 = v_v_2479; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2479); r_; });
        break;
      }
      default: heff_nomatch(v_st_2469);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2483 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2482; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2482); r_; });
    V v_t_2485;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2485 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2484 = heff_field(v_after_243, 0);
      v_t_2485 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2484, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_t_2486 = (g_prelude_2e_2b_2b(v_t_2483, v_t_2485));
    return ({ V a_0 = v_x_240; V a_1 = v_t_2481; V a_2 = v_t_2486; V r_ = (g_heff_2ecompile_2eimperative_2eusedOnceNext(a_0, a_1, a_2)); heff_drop(v_t_2481); heff_drop(v_t_2486); r_; });
  }
  case TAG_OAbandon: {
    V v_t_24100;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_t_24100 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2487 = heff_field(v_after_243, 0);
        v_t_24100 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2487));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2488 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2488)) {
      case TAG_SLet: {
        V v_o_2491 = heff_field(v_st_2488, 1);
        heff_take_n(v_st_2488, 2ULL, 2);
        v_t_24100 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2491));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2488, 0ULL, 1);
        v_t_24100 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2494 = heff_field(v_st_2488, 1);
        heff_take_n(v_st_2488, 2ULL, 2);
        v_t_24100 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2494));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2488, 0ULL, 3);
        v_t_24100 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2498 = heff_field(v_st_2488, 0);
        heff_take_n(v_st_2488, 1ULL, 2);
        v_t_24100 = ({ V a_0 = v_v_2498; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2498); r_; });
        break;
      }
      default: heff_nomatch(v_st_2488);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_24101 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_24102 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24101; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_24101); r_; });
    V v_t_24104;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_24104 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_24103 = heff_field(v_after_243, 0);
      v_t_24104 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_24103, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_t_24105 = (g_prelude_2e_2b_2b(v_t_24102, v_t_24104));
    return ({ V a_0 = v_x_240; V a_1 = v_t_24100; V a_2 = v_t_24105; V r_ = (g_heff_2ecompile_2eimperative_2eusedOnceNext(a_0, a_1, a_2)); heff_drop(v_t_24100); heff_drop(v_t_24105); r_; });
  }
  case TAG_OBool: {
    heff_drop(v_x_240);
    heff_drop(v_rest_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eemit_2einlinable_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2einlinable(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_str0, 0, "");
Clo g_heff_2ecompile_2eemit_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamed_entry, 4, 0};

V g_heff_2ecompile_2eemit_2enamed(V v_env_240, V v_ind_241, V v_base_242, V v_c_243) {
top: ;
  V v_c_244 = heff_dup(heff_rfield(v_c_243, 0));
  if (heff_strEq_c(heff_dup(v_c_244), ((V)&g_heff_2ecompile_2eemit_2enamed_str0))) {
    heff_drop(v_c_244);
    V v_t_246 = (g_heff_2ecompile_2eemit_2ebindName(v_env_240, v_base_242));
    return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_246));
  } else {
    V v_t_247 = (g_heff_2ecompile_2eemit_2eatomGo(v_c_244, MK_INT(0LL)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_ind_241);
      heff_drop(v_base_242);
      heff_drop(v_t_247);
      return heff_rec_n(3, shape_js__pre__env, (V[]){heff_get_n(v_c_243, 0, 2), NTAG(TAG_Nil), v_env_240});
    } else {
      heff_drop(v_t_247);
      V v_t_248 = (g_heff_2ecompile_2eemit_2ebindName(v_env_240, v_base_242));
      return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_248));
    }
  }
}
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamed(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str2, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str3, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str4, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str5, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str6, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str7, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str8, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str9, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str11, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str12, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str14, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str15, 14, "Uint8Array.of(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str16, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str18, 12, "Math.fround(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str19, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str20, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str22, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str25, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str26, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str27, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str28, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str30, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str31, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str32, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str33, 9, ", a: [] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str35, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str36, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str38, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str39, 6, ", a: [");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str40, 3, "] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str41, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str42, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str43, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str44, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str45, 2, ": ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str47, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str48, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str49, 2, " }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str50, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str51, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str52, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str53, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str54, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str55, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str56, 1, "[");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str57, 1, "]");
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry, 3, 0};

V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    heff_drop(v_ind_241);
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_243), heff_rfield(v_env_240, 4)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_x_243)), MK_INT(1LL));
      V v_t_246 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x_243), v_t_245));
      V v_t_247 = ({ V a_0 = heff_dup(v_x_243); V a_1 = v_t_246; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_246); r_; });
      V v_s_248 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_247, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str0)));
      V v_t_2410;
      if (heff_strEq_c(heff_dup(v_s_248), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str1))) {
        heff_drop(v_s_248);
        v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str2);
      } else {
        v_t_2410 = v_s_248;
      }
      V v_d_2411 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2410));
      V v_x2_2412 = ({ V a_0 = heff_dup(v_x_243); V b_1 = heff_get_n(v_env_240, 1, 5); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2414;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        v_t_2414 = v_d_2411;
        break;
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        heff_drop(v_d_2411);
        v_t_2414 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      return heff_rec_n(2, shape_code__prec, (V[]){v_t_2414, MK_INT(3LL)});
    }
    case TAG_Just: {
      V v_c_2415 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop_rec(v_env_240, 5);
      return v_c_2415;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_SGlobal: {
    V v_g_2416 = heff_field(v_x4_242, 0);
    heff_drop(v_ind_241);
    V v_t_2417 = ({ V a_0 = heff_dup(v_g_2416); V b_1 = heff_get_n(v_env_240, 0, 5); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_code_2421;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      v_code_2421 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str3);
      break;
    }
    case TAG_Just: {
      V v_i_2418 = heff_field(v_t_2417, 0);
      heff_take_n(v_t_2417, 1ULL, 1);
      if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_2418, 1)))) {
        v_code_2421 = heff_strAppend(heff_get_n(v_i_2418, 0, 4), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str4));
      } else {
        V v_t_2420 = heff_take_field(v_i_2418, 2);
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop(v_t_2420);
          v_code_2421 = heff_strAppend(heff_get_n(v_i_2418, 0, 4), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str5));
        } else {
          heff_drop(v_t_2420);
          v_code_2421 = heff_get_n(v_i_2418, 0, 4);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2421, MK_INT(3LL)});
  }
  case TAG_SInt: {
    V v_i_2422 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_s_2423 = heff_intShow(heff_dup(v_i_2422));
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_2423), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str6))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2423, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str7)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2423, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str8)), MK_INT(3LL)});
    }
  }
  case TAG_SFloat: {
    V v_x_2425 = heff_tget_v(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_s_2426 = heff_floatShow(v_x_2425);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_2426), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str9))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2426, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2426, MK_INT(3LL)});
    }
  }
  case TAG_SStr: {
    V v_s_2428 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2429 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_s_2428), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str10)));
    V v_code_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str11), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str12)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2430, MK_INT(3LL)});
  }
  case TAG_SBytes: {
    V v_s_2431 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2432 = heff_intSub(heff_strLength(heff_dup(v_s_2431)), MK_INT(1LL));
    V v_x2_2433 = (g_list_2emap_24f1457339348x592422294(heff_dup(v_s_2431), MK_INT(0LL), v_t_2432));
    V v_t_2436;
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_Nil: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      V v_xs_2435 = heff_field(v_x2_2433, 1);
      heff_take_n(v_x2_2433, 3ULL, 2);
      v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str14); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2433);
    }
    V v_code_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str15), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str16)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2437, MK_INT(3LL)});
  }
  case TAG_SFixed: {
    V v_w_2438 = heff_field(v_x4_242, 0);
    V v_n_2439 = heff_field(v_x4_242, 1);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    return (g_heff_2ecompile_2eemit_2efixedCode(v_w_2438, heff_dup(v_n_2439)));
  }
  case TAG_SFloat32: {
    V v_x_2440 = heff_tget_v(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2441 = heff_strAppend(heff_floatShow(v_x_2440), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str17));
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str18), v_t_2441), MK_INT(3LL)});
  }
  case TAG_SPrimFn: {
    V v_p_2442 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str19), heff_strAppend(heff_dup(v_p_2442), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str20)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2443, MK_INT(3LL)});
  }
  case TAG_SLam: {
    V v_xs_2444 = heff_field(v_x4_242, 0);
    V v_x42_2445 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_2445)) {
    case TAG_MkBlock: {
      V v_t_2446 = heff_field(v_x42_2445, 0);
      V v_t_2447 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_env_240, 23ULL, 5, shape_gs__names__used__self__inl, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_2448 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_2447});
      V v_rb_2449 = (g_list_2efoldl_24s135909237x326578890(v_t_2448, heff_dup(v_xs_2444)));
      V v_x2_2450 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str21), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str22), heff_take_field(v_rb_2449, 0)));
      V v_t_2453;
      switch (heff_tag_of(v_x2_2450)) {
      case TAG_Nil: {
        v_t_2453 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str23);
        break;
      }
      case TAG_Cons: {
        V v_x_2451 = heff_field(v_x2_2450, 0);
        V v_xs_2452 = heff_field(v_x2_2450, 1);
        heff_take_n(v_x2_2450, 3ULL, 2);
        v_t_2453 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str24); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2450);
      }
      V v_t_2454 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(heff_get_n(v_rb_2449, 1, 2), v_ind_241, v_t_2446));
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2453, v_t_2454), MK_INT(0LL)});
    }
    default: return heff_nomatch(v_x42_2445);
    }
  }
  case TAG_STag: {
    V v_t_2455 = heff_field(v_x4_242, 0);
    V v_x42_2456 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_2456)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 5);
      heff_drop(v_ind_241);
      if (heff_strEq_c(heff_dup(v_t_2455), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str25))) {
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str26), MK_INT(3LL)});
      } else {
        if (heff_strEq_c(heff_dup(v_t_2455), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str27))) {
          return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str28), MK_INT(3LL)});
        } else {
          V v_t_2460 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_t_2455), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str29)));
          V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str30), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str31)));
          V v_code_2462 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str32), heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str33)));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2462, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_t_2465 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_t_2455), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str34)));
      V v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str35), heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str36)));
      V v_x2_2469 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_x42_2456)));
      V v_t_2472;
      switch (heff_tag_of(v_x2_2469)) {
      case TAG_Nil: {
        v_t_2472 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str37);
        break;
      }
      case TAG_Cons: {
        V v_x_2470 = heff_field(v_x2_2469, 0);
        V v_xs_2471 = heff_field(v_x2_2469, 1);
        heff_take_n(v_x2_2469, 3ULL, 2);
        v_t_2472 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str38); V a_1 = v_x_2470; V a_2 = v_xs_2471; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2471); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2469);
      }
      V v_t_2473 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str39), heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str40)));
      V v_code_2474 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str41), heff_strAppend(v_t_2466, v_t_2473));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2474, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x42_2456);
    }
  }
  case TAG_SRec: {
    V v_fs_2475 = heff_field(v_x4_242, 0);
    V v_x2_2485 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_fs_2475)));
    V v_t_2488;
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_Nil: {
      v_t_2488 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str46);
      break;
    }
    case TAG_Cons: {
      V v_x_2486 = heff_field(v_x2_2485, 0);
      V v_xs_2487 = heff_field(v_x2_2485, 1);
      heff_take_n(v_x2_2485, 3ULL, 2);
      v_t_2488 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str47); V a_1 = v_x_2486; V a_2 = v_xs_2487; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2487); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2485);
    }
    V v_code_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str48), heff_strAppend(v_t_2488, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str49)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2489, MK_INT(3LL)});
  }
  case TAG_SProj: {
    V v_v_2490 = heff_field(v_x4_242, 0);
    V v_l_2491 = heff_field(v_x4_242, 1);
    V v_c_2494 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_2490));
    V v_t_2497;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2494, 1)), MK_INT(3LL))) {
      V v_t_2496 = heff_strAppend(heff_get_n(v_c_2494, 0, 2), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str50));
      v_t_2497 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str51), v_t_2496);
    } else {
      v_t_2497 = heff_get_n(v_c_2494, 0, 2);
    }
    V v_t_2498 = (g_heff_2ecompile_2eemit_2eisIdent(heff_dup(v_l_2491)));
    V v_t_24101;
    if ((heff_dup(v_t_2498) == NTAG(TAG_True))) {
      heff_drop(v_t_2498);
      v_t_24101 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str52), heff_dup(v_l_2491));
    } else {
      heff_drop(v_t_2498);
      V v_t_2499 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_l_2491), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str53)));
      V v_t_24100 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str54), heff_strAppend(v_t_2499, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str55)));
      v_t_24101 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str56), heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str57)));
    }
    V v_code_24102 = heff_strAppend(v_t_2497, v_t_24101);
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_24102, MK_INT(3LL)});
  }
  case TAG_SPrim: {
    V v_p_24103 = heff_field(v_x4_242, 0);
    V v_as_24104 = heff_field(v_x4_242, 1);
    return (g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(v_env_240, v_ind_241, heff_dup(v_p_24103), heff_dup(v_as_24104)));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0(V self, V *args) {
  V v_a_2467 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_2467; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_2467); r_; });
  return heff_get_n(v_t_2468, 0, 2);
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1(V self, V *args) {
  V v_f_2477 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2477)) {
  case TAG_MkPair: {
    V v_l_2478 = heff_field(v_f_2477, 0);
    V v_v_2479 = heff_field(v_f_2477, 1);
    heff_take_n(v_f_2477, 3ULL, 2);
    V v_t_2480 = (g_heff_2ecompile_2eemit_2eisIdent(heff_dup(v_l_2478)));
    V v_t_2482;
    if ((heff_dup(v_t_2480) == NTAG(TAG_True))) {
      heff_drop(v_t_2480);
      v_t_2482 = v_l_2478;
    } else {
      heff_drop(v_t_2480);
      V v_t_2481 = (g_heff_2ecompile_2eemit_2equoteGo(v_l_2478, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str42)));
      v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str43), heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str44)));
    }
    V v_t_2483 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2479; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2479); r_; });
    V v_t_2484 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str45), heff_get_n(v_t_2483, 0, 2));
    return heff_strAppend(v_t_2482, v_t_2484);
  }
  default: return heff_nomatch(v_f_2477);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str0, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str4, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str5, 1, ")");
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V v_env_240, V v_ind_241, V v_c_242, V v_as_243) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0, 2, 2, (V[]){v_env_240, v_ind_241}), v_c_242, v_as_243));
}
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0(V self, V *args) {
  V v_c2_244 = args[0];
  V v_a_245 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248;
  if (heff_intLt_c(heff_dup(heff_rfield(v_c2_244, 1)), MK_INT(3LL))) {
    V v_t_247 = heff_strAppend(heff_get_n(v_c2_244, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str0));
    v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str1), v_t_247);
  } else {
    v_t_248 = heff_get_n(v_c2_244, 0, 2);
  }
  V v_t_249 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_245; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_245); r_; });
  V v_t_2410 = heff_strAppend(heff_get_n(v_t_249, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str2));
  V v_c_2411 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str3), v_t_2410));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str4), heff_strAppend(v_c_2411, ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str5)));
  return heff_rec_n(2, shape_code__prec, (V[]){v_t_2412, MK_INT(3LL)});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str3, 6, "break;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str8, 18, "default: $nomatch(");
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
  V v_x2_2418 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str4)));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str7));
  V v_t_2423 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str8), v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  V v_t_2425 = (g_heff_2ecompile_2eemit_2eswitchLines(heff_dup(v_sc_242), v_ind_240, v_t_2417, v_t_2424, NTAG(TAG_Nil)));
  return heff_rec_n(2, shape_lines__env, (V[]){v_t_2425, heff_get_n(v_sc_242, 1, 3)});
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_lam1(V self, V *args) {
  V v_e_249 = args[0];
  V v_i_2410 = args[1];
  V v_ss_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V a_0 = v_e_249; V a_1 = heff_dup(v_i_2410); V a_2 = v_ss_246; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  V v_x2_2412 = (g_list_2ereplicate(v_i_2410, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str0)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str2); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_str3)), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(heff_get_n(v_t_2411, 0, 2), v_t_2416));
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_tag_244 = heff_field(v_arm_243, 0);
    V v_vs_245 = heff_field(v_arm_243, 1);
    V v_ss_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 7ULL, 3);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_246)));
    V v_t_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_247); r_; });
    return ({ V a_0 = v_sc_242; V a_1 = v_ind_240; V a_2 = v_tag_244; V a_3 = v_vs_245; V a_4 = v_t_248; V a_5 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_lam1, 2, 1, (V[]){v_ss_246}); V r_ = (g_heff_2ecompile_2eemit_2earmJs(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_arm_243);
  }
}
Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry, 4, 0};

V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V v_env_240, V v_ind_241, V v_x4_242, V v_after_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_241);
    return heff_rec_n(2, shape_lines__env, (V[]){NTAG(TAG_Nil), v_env_240});
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_rest_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_SLet: {
      V v_x_246 = heff_field(v_x41_244, 0);
      V v_o_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eemit_2einlinable(heff_dup(v_x_246), v_o_247, heff_dup(v_rest_245), v_after_243));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_t_248);
        V v_c_249 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_o_247; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_247); r_; });
        V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_x_246, v_c_249, heff_take_field(v_env_240, 4)));
        V v_env_2411 = ({ V rv_4 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_env_240, 15ULL, 5, shape_gs__names__used__self__inl, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        V t_0 = v_env_2411;
        V t_1 = v_ind_241;
        V t_2 = v_rest_245;
        V t_3 = v_after_243;
        v_env_240 = t_0;
        v_ind_241 = t_1;
        v_x4_242 = t_2;
        v_after_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_248);
        V v_p_2412 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V b_2 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_SLet, 2, (V[]){v_x_246, v_o_247}); V r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_b_2413 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(heff_take_field(v_p_2412, 1), v_ind_241, v_rest_245, v_after_243));
        V v_t_2414 = (g_prelude_2e_2b_2b(heff_get_n(v_p_2412, 0, 2), heff_take_field(v_b_2413, 0)));
        return ({ V rv_0 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_b_2413, 2ULL, 2, shape_lines__env, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
    }
    case TAG_SDecl: {
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V v_p_2416 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; V r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 1); r_; });
      V v_b_2417 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(heff_take_field(v_p_2416, 1), v_ind_241, v_rest_245, v_after_243));
      V v_t_2418 = (g_prelude_2e_2b_2b(heff_get_n(v_p_2416, 0, 2), heff_take_field(v_b_2417, 0)));
      return ({ V rv_0 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_b_2417, 2ULL, 2, shape_lines__env, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    }
    case TAG_SSet: {
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V v_p_2421 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; V r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 2); r_; });
      V v_b_2422 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(heff_take_field(v_p_2421, 1), v_ind_241, v_rest_245, v_after_243));
      V v_t_2423 = (g_prelude_2e_2b_2b(heff_get_n(v_p_2421, 0, 2), heff_take_field(v_b_2422, 0)));
      return ({ V rv_0 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_b_2422, 2ULL, 2, shape_lines__env, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    }
    case TAG_SIf: {
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V v_p_2427 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; V r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 3); r_; });
      V v_b_2428 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(heff_take_field(v_p_2427, 1), v_ind_241, v_rest_245, v_after_243));
      V v_t_2429 = (g_prelude_2e_2b_2b(heff_get_n(v_p_2427, 0, 2), heff_take_field(v_b_2428, 0)));
      return ({ V rv_0 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_b_2428, 2ULL, 2, shape_lines__env, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    }
    case TAG_SCase: {
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      V v_p_2432 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; V r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 2); r_; });
      V v_b_2433 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(heff_take_field(v_p_2432, 1), v_ind_241, v_rest_245, v_after_243));
      V v_t_2434 = (g_prelude_2e_2b_2b(heff_get_n(v_p_2432, 0, 2), heff_take_field(v_b_2433, 0)));
      return ({ V rv_0 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_b_2433, 2ULL, 2, shape_lines__env, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str38, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str39, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str40, 7, "return ");
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V v_env_240, V v_ind_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 1); r_; });
    V v_t_249 = heff_strAppend(heff_get_n(v_t_248, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3));
    V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4), v_t_249));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    V v_g_2411 = heff_dup(heff_field(v_o_242, 0));
    V v_as_2412 = heff_dup(heff_field(v_o_242, 1));
    V v_t_2442;
    switch (heff_tag_of(v_as_2412)) {
    case TAG_Nil: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2413 = heff_dup(heff_field(v_as_2412, 0));
      V v_x12_2414 = heff_dup(heff_field(v_as_2412, 1));
      switch (heff_tag_of(v_x11_2413)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2427 = heff_field(v_x11_2413, 0);
        V v_x112_2428 = heff_field(v_x11_2413, 1);
        heff_take_n(v_x11_2413, 3ULL, 3);
        switch (heff_tag_of(v_x112_2428)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2414)) {
          case TAG_Nil: {
            v_t_2442 = heff_strEq(v_t_2427, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2414, 0ULL, 2);
            heff_drop(v_t_2427);
            v_t_2442 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2414);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2428, 0ULL, 2);
          heff_drop(v_x12_2414);
          heff_drop(v_t_2427);
          v_t_2442 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2428);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2413, 0ULL, 4);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2413);
      }
      break;
    }
    default: heff_nomatch(v_as_2412);
    }
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_g_2411);
      heff_drop(v_as_2412);
      heff_drop(v_t_2442);
      V v_x2_2443 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6)));
      V v_t_2446;
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_Nil: {
        v_t_2446 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_xs_2445 = heff_field(v_x2_2443, 1);
        heff_take_n(v_x2_2443, 3ULL, 2);
        v_t_2446 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2443);
      }
      V v_t_2447 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 2); r_; });
      V v_t_2448 = heff_strAppend(heff_get_n(v_t_2447, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9));
      V v_t_2449 = heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10), v_t_2448));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    } else {
      heff_drop_tag(v_o_242, 2);
      heff_drop(v_t_2442);
      V v_x2_2450 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11)));
      V v_t_2453;
      switch (heff_tag_of(v_x2_2450)) {
      case TAG_Nil: {
        v_t_2453 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2451 = heff_field(v_x2_2450, 0);
        V v_xs_2452 = heff_field(v_x2_2450, 1);
        heff_take_n(v_x2_2450, 3ULL, 2);
        v_t_2453 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2450);
      }
      V v_t_2454 = (g_heff_2ecompile_2eemit_2ecallName(heff_dup(v_env_240), v_g_2411));
      V v_x2_2457 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_2412));
      V v_t_2460;
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_Nil: {
        v_t_2460 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_xs_2459 = heff_field(v_x2_2457, 1);
        heff_take_n(v_x2_2457, 3ULL, 2);
        v_t_2460 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2457);
      }
      V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17)));
      V v_t_2462 = heff_strAppend(heff_strAppend(v_t_2454, v_t_2461), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18));
      V v_t_2463 = heff_strAppend(v_t_2453, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19), v_t_2462));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
    }
  }
  case TAG_OApply: {
    V v_f_2464 = heff_field(v_o_242, 0);
    V v_as_2465 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OApply = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2495;
    switch (heff_tag_of(v_as_2465)) {
    case TAG_Nil: {
      v_t_2495 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2466 = heff_dup(heff_field(v_as_2465, 0));
      V v_x12_2467 = heff_dup(heff_field(v_as_2465, 1));
      switch (heff_tag_of(v_x11_2466)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2466, 0ULL, 2);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2466, 0ULL, 1);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2466, 0ULL, 2);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2480 = heff_field(v_x11_2466, 0);
        V v_x112_2481 = heff_field(v_x11_2466, 1);
        heff_take_n(v_x11_2466, 3ULL, 3);
        switch (heff_tag_of(v_x112_2481)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2467)) {
          case TAG_Nil: {
            v_t_2495 = heff_strEq(v_t_2480, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2467, 0ULL, 2);
            heff_drop(v_t_2480);
            v_t_2495 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2467);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2481, 0ULL, 2);
          heff_drop(v_x12_2467);
          heff_drop(v_t_2480);
          v_t_2495 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2481);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2466, 0ULL, 2);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2466, 0ULL, 4);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2466, 0ULL, 2);
        heff_drop(v_x12_2467);
        v_t_2495 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2466);
      }
      break;
    }
    default: heff_nomatch(v_as_2465);
    }
    if ((heff_dup(v_t_2495) == NTAG(TAG_True))) {
      heff_drop(v_as_2465);
      heff_drop_cell(v_ru_24o_242_24OApply, 2);
      heff_drop(v_t_2495);
      V v_ac_2496 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_f_2464; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2464); r_; });
      V v_f_2497 = (g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21), MK_INT(3LL), v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22)));
      V v_t_2498 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_2497, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23), v_ac_2496));
      HEFF_LAST return g_heff_2ecompile_2eemit_2ebounceGive(v_ind_241, v_f_2497, v_t_2498);
    } else {
      heff_drop(v_t_2495);
      switch (heff_tag_of(v_as_2465)) {
      case TAG_Nil: {
        V v_x2_2499 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24)));
        V v_t_24102;
        switch (heff_tag_of(v_x2_2499)) {
        case TAG_Nil: {
          v_t_24102 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25);
          break;
        }
        case TAG_Cons: {
          V v_x_24100 = heff_field(v_x2_2499, 0);
          V v_xs_24101 = heff_field(v_x2_2499, 1);
          heff_take_n(v_x2_2499, 3ULL, 2);
          v_t_24102 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26); V a_1 = v_x_24100; V a_2 = v_xs_24101; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24101); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2499);
        }
        V v_t_24103 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_f_2464; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2464); r_; });
        V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27));
        V v_t_24105 = heff_strAppend(v_t_24102, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28), v_t_24104));
        return heff_tag_at_n(v_ru_24o_242_24OApply, TAG_Cons, 2, (V[]){v_t_24105, NTAG(TAG_Nil)});
      }
      case TAG_Cons: {
        V v_x_24106 = heff_field(v_as_2465, 0);
        V v_rest_24107 = heff_field(v_as_2465, 1);
        heff_take_n(v_as_2465, 3ULL, 2);
        heff_drop_cell(v_ru_24o_242_24OApply, 2);
        V v_t_24108 = (g_heff_2ecompile_2eemit_2eunsnocGo(v_rest_24107, v_x_24106));
        switch (heff_tag_of(v_t_24108)) {
        case TAG_MkPair: {
          V v_ini_24109 = heff_field(v_t_24108, 0);
          V v_a_24110 = heff_field(v_t_24108, 1);
          heff_take_n(v_t_24108, 3ULL, 2);
          V v_t_24111 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_f_2464; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2464); r_; });
          V v_fc_24112 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_t_24111; V a_3 = v_ini_24109; V r_ = (g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(a_0, a_1, a_2, a_3)); heff_drop(v_ini_24109); r_; });
          V v_ac_24113 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_a_24110; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_24110); r_; });
          V v_f_24114 = (g_heff_2ecompile_2eemit_2enamed(v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29), v_fc_24112));
          V v_t_24115 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_24114, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30), v_ac_24113));
          HEFF_LAST return g_heff_2ecompile_2eemit_2ebounceGive(v_ind_241, v_f_24114, v_t_24115);
        }
        default: return heff_nomatch(v_t_24108);
        }
      }
      default: return heff_nomatch(v_as_2465);
      }
    }
  }
  case TAG_OPrim: {
    V v_x2_24118 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31)));
    V v_t_24121;
    switch (heff_tag_of(v_x2_24118)) {
    case TAG_Nil: {
      v_t_24121 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32);
      break;
    }
    case TAG_Cons: {
      V v_x_24119 = heff_field(v_x2_24118, 0);
      V v_xs_24120 = heff_field(v_x2_24118, 1);
      heff_take_n(v_x2_24118, 3ULL, 2);
      v_t_24121 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33); V a_1 = v_x_24119; V a_2 = v_xs_24120; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24120); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24118);
    }
    V v_t_24122 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 2); r_; });
    V v_t_24123 = heff_strAppend(heff_get_n(v_t_24122, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34));
    V v_t_24124 = heff_strAppend(v_t_24121, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35), v_t_24123));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    V v_x2_24125 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36)));
    V v_t_24128;
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_Nil: {
      v_t_24128 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str37);
      break;
    }
    case TAG_Cons: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_xs_24127 = heff_field(v_x2_24125, 1);
      heff_take_n(v_x2_24125, 3ULL, 2);
      v_t_24128 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str38); V a_1 = v_x_24126; V a_2 = v_xs_24127; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24127); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24125);
    }
    V v_t_24129 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    V v_t_24130 = heff_strAppend(heff_get_n(v_t_24129, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str39));
    V v_t_24131 = heff_strAppend(v_t_24128, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str40), v_t_24130));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_24132 = heff_field(v_o_242, 0);
    heff_take_n(v_o_242, 1ULL, 1);
    V v_t_24133 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(v_env_240, heff_dup(v_ind_241), v_c_24132));
    return (g_heff_2ecompile_2eemit_2ereturnCond(v_ind_241, v_t_24133));
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_lam0(V self, V *args) {
  V v_a_2455 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_2455; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_2455); r_; });
  return heff_get_n(v_t_2456, 0, 2);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str2, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str4, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str5, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str6, 0, "");
Clo g_heff_2ecompile_2eemit_2edefFun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edefFun_entry, 4, 0};

V g_heff_2ecompile_2eemit_2edefFun(V v_key_240, V v_i_241, V v_t_242, V v_r_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemit_2eloops(v_t_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    HEFF_LAST return g_heff_2ecompile_2eemit_2elooped(v_key_240, v_i_241, v_t_242, v_r_243);
  } else {
    heff_drop(v_key_240);
    heff_drop(v_t_244);
    V v_t_245 = heff_take_field(v_r_243, 0);
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemit_2edefFun_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_t_245, 0);
      V v_xs_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edefFun_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_249 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(heff_get_n(v_r_243, 1, 2), MK_INT(0LL), v_t_242));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str2), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2edefFun_str3)));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str4), heff_strAppend(v_t_248, v_t_2410));
    V v_t_2412 = heff_strAppend(heff_get_n(v_i_241, 0, 4), v_t_2411);
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str5), v_t_2412), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefFun_str6), v_t_2413});
  }
}
V g_heff_2ecompile_2eemit_2edefFun_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2edefFun(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str0, 15, " = $lazy(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str1, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str2, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str6, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str7, 0, "");
Clo g_heff_2ecompile_2eemit_2edefCodeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edefCodeOf_entry, 5, 0};

V g_heff_2ecompile_2eemit_2edefCodeOf(V v_gs_240, V v_met_241, V v_key_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_DefFun: {
    V v_xs_245 = heff_field(v_x4_243, 0);
    V v_x42_246 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_246)) {
    case TAG_MkBlock: {
      V v_t_247 = heff_field(v_x42_246, 0);
      V v_t_248 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_map_2eempty_get())});
      V v_t_249 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_248});
      V v_r_2410 = (g_list_2efoldl_24s135909237x326578890(v_t_249, heff_dup(v_xs_245)));
      V v_t_2411 = (g_heff_2ecompile_2eemit_2edefFun(v_key_242, v_i_244, v_t_247, heff_dup(v_r_2410)));
      return heff_rec_n(2, shape_lines__params, (V[]){v_t_2411, heff_get_n(v_r_2410, 0, 2)});
    }
    default: return heff_nomatch(v_x42_246);
    }
  }
  case TAG_DefVal: {
    V v_x41_2412 = heff_field(v_x4_243, 0);
    heff_drop(v_key_242);
    switch (heff_tag_of(v_x41_2412)) {
    case TAG_MkBlock: {
      V v_t_2413 = heff_field(v_x41_2412, 0);
      V v_t_2414 = heff_take_field(v_i_244, 2);
      V v_t_2425;
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_map_2eempty_get())});
        V v_t_2416 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(v_t_2415, MK_INT(0LL), v_t_2413));
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str0), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str1)));
        V v_t_2418 = heff_strAppend(heff_get_n(v_i_244, 0, 4), v_t_2417);
        V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str2), v_t_2418), NTAG(TAG_Nil)});
        v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str3), v_t_2419});
      } else {
        heff_drop(v_t_2414);
        V v_t_2420 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_map_2eempty_get())});
        V v_t_2421 = (g_heff_2ecompile_2eemit_2eeagerCode(v_t_2420, v_t_2413));
        V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str4), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str5)));
        V v_t_2423 = heff_strAppend(heff_get_n(v_i_244, 0, 4), v_t_2422);
        V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str6), v_t_2423), NTAG(TAG_Nil)});
        v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str7), v_t_2424});
      }
      return heff_rec_n(2, shape_lines__params, (V[]){v_t_2425, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x41_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemit_2edefCodeOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2edefCodeOf(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str1, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str4, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str5, 1, "(");
Clo g_heff_2ecompile_2eemit_2eprimUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUses_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimUses(V v_m_240, V v_part_241) {
top: ;
  switch (heff_tag_of(v_part_241)) {
  case TAG_PartVal: {
    V v_part1_242 = heff_field(v_part_241, 0);
    switch (heff_tag_of(v_part1_242)) {
    case TAG_SVar: {
      return v_m_240;
    }
    case TAG_SGlobal: {
      return v_m_240;
    }
    case TAG_SInt: {
      return v_m_240;
    }
    case TAG_SFloat: {
      return v_m_240;
    }
    case TAG_SStr: {
      return v_m_240;
    }
    case TAG_SBytes: {
      return v_m_240;
    }
    case TAG_SFixed: {
      return v_m_240;
    }
    case TAG_SFloat32: {
      return v_m_240;
    }
    case TAG_SPrimFn: {
      V v_p_2412 = heff_field(v_part1_242, 0);
      V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str0), heff_strAppend(heff_dup(v_p_2412), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str1)));
      return (g_map_2einsert_24s1341440536x470972936(v_t_2413, NTAG(TAG_MkUnit), v_m_240));
    }
    case TAG_SLam: {
      return v_m_240;
    }
    case TAG_STag: {
      return v_m_240;
    }
    case TAG_SRec: {
      return v_m_240;
    }
    case TAG_SProj: {
      return v_m_240;
    }
    case TAG_SPrim: {
      V v_p_2425 = heff_field(v_part1_242, 0);
      V v_as_2426 = heff_field(v_part1_242, 1);
      V v_t_2427 = (g_heff_2ecompile_2eemit_2ecallsHelper(heff_dup(v_p_2425), v_as_2426));
      if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
        heff_drop(v_t_2427);
        V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str2), heff_strAppend(heff_dup(v_p_2425), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str3)));
        return (g_map_2einsert_24s1341440536x470972936(v_t_2428, NTAG(TAG_MkUnit), v_m_240));
      } else {
        heff_drop(v_t_2427);
        return v_m_240;
      }
    }
    default: return heff_nomatch(v_part1_242);
    }
  }
  case TAG_PartOp: {
    V v_part1_2429 = heff_field(v_part_241, 0);
    switch (heff_tag_of(v_part1_2429)) {
    case TAG_OSimple: {
      return v_m_240;
    }
    case TAG_OCall: {
      return v_m_240;
    }
    case TAG_OApply: {
      return v_m_240;
    }
    case TAG_OPrim: {
      V v_p_2435 = heff_field(v_part1_2429, 0);
      V v_as_2436 = heff_field(v_part1_2429, 1);
      V v_t_2437 = (g_heff_2ecompile_2eemit_2ecallsHelper(heff_dup(v_p_2435), v_as_2436));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_t_2437);
        V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str4), heff_strAppend(heff_dup(v_p_2435), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str5)));
        return (g_map_2einsert_24s1341440536x470972936(v_t_2438, NTAG(TAG_MkUnit), v_m_240));
      } else {
        heff_drop(v_t_2437);
        return v_m_240;
      }
    }
    case TAG_OAbandon: {
      return v_m_240;
    }
    case TAG_OBool: {
      return v_m_240;
    }
    default: return heff_nomatch(v_part1_2429);
    }
  }
  default: return heff_nomatch(v_part_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eprimUses(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsPick_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsPick_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsPick_str2, 1, "x");
Clo g_heff_2ecompile_2eemit_2ejsPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsPick_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ejsPick(V v_shorts_240, V v_key_241, V v_s_242) {
top: ;
  V v_x_243 = (g_list_2efoldl_24f226312210x181720981(MK_INT(1LL), MK_INT(0LL), heff_dup(v_s_242), v_shorts_240));
  if (heff_intLt_c(MK_INT(1LL), v_x_243)) {
    heff_drop(v_s_242);
    V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_key_241)), MK_INT(1LL));
    V v_t_246 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_key_241), v_t_245));
    V v_t_247 = ({ V a_0 = v_key_241; V a_1 = v_t_246; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_s_248 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_247, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ejsPick_str0)));
    V v_t_2410;
    if (heff_strEq_c(heff_dup(v_s_248), ((V)&g_heff_2ecompile_2eemit_2ejsPick_str1))) {
      heff_drop(v_s_248);
      v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2ejsPick_str2);
    } else {
      v_t_2410 = v_s_248;
    }
    return (g_heff_2ecompile_2eemit_2esafeRes(v_t_2410));
  } else {
    heff_drop(v_key_241);
    return v_s_242;
  }
}
V g_heff_2ecompile_2eemit_2ejsPick_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2ejsPick(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsNameOf_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsNameOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsNameOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsNameOf_str3, 1, "x");
Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsNameOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ejsNameOf(V v_shorts_240, V v_key_241) {
top: ;
  V v_xs_242 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str0), heff_dup(v_key_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x0_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_x0_246 = heff_dup(v_key_241);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_x0_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_x0_246)), MK_INT(1LL));
  V v_t_248 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x0_246), v_t_247));
  V v_t_249 = ({ V a_0 = v_x0_246; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_s_2410 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_249, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str1)));
  V v_t_2412;
  if (heff_strEq_c(heff_dup(v_s_2410), ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str2))) {
    heff_drop(v_s_2410);
    v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str3);
  } else {
    v_t_2412 = v_s_2410;
  }
  V v_t_2413 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2412));
  return (g_heff_2ecompile_2eemit_2ejsPick(v_shorts_240, v_key_241, v_t_2413));
}
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2ejsNameOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2ekeptCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ekeptCode_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ekeptCode(V v_v_240, V v_d_241, V v_c_242) {
top: ;
  V v_t_2411;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_x13_245 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_x13_245)) {
    case TAG_DefFun: {
      V v_x132_247 = heff_field(v_x13_245, 1);
      switch (heff_tag_of(v_x132_247)) {
      case TAG_MkBlock: {
        V v_t_248 = heff_field(v_x132_247, 0);
        v_t_2411 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_248, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x132_247);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x131_249 = heff_field(v_x13_245, 0);
      switch (heff_tag_of(v_x131_249)) {
      case TAG_MkBlock: {
        V v_t_2410 = heff_field(v_x131_249, 0);
        v_t_2411 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2410, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x131_249);
      }
      break;
    }
    default: heff_nomatch(v_x13_245);
    }
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_t_2412 = (g_list_2emap_24s1585362143x1323498048(v_t_2411));
  V v_t_2413 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2412));
  V v_t_2422;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_x13_2416 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_x13_2416)) {
    case TAG_DefFun: {
      V v_x132_2418 = heff_field(v_x13_2416, 1);
      switch (heff_tag_of(v_x132_2418)) {
      case TAG_MkBlock: {
        V v_t_2419 = heff_field(v_x132_2418, 0);
        v_t_2422 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2419, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x132_2418);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x131_2420 = heff_field(v_x13_2416, 0);
      switch (heff_tag_of(v_x131_2420)) {
      case TAG_MkBlock: {
        V v_t_2421 = heff_field(v_x131_2420, 0);
        v_t_2422 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2421, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x131_2420);
      }
      break;
    }
    default: heff_nomatch(v_x13_2416);
    }
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_m_2423 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s398854970x1533504811(a_0, a_1)); heff_drop(v_t_2422); r_; });
  V v_t_2424 = ({ V a_0 = v_m_2423; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2423); r_; });
  V v_t_2425 = (g_list_2emap_24s1937570095x2110149801(v_t_2424));
  return heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_v_240, heff_dup(heff_rfield(v_c_242, 0)), heff_get_n(v_c_242, 1, 2), v_t_2413, v_t_2425});
}
V g_heff_2ecompile_2eemit_2ekeptCode_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ekeptCode(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemit_2ekeptOfDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ekeptOfDef_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ekeptOfDef(V v_p_240, V v_v_241, V v_d_242) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_d_242)) {
  case TAG_MkDef: {
    V v_k_243 = heff_field(v_d_242, 0);
    v_t_246 = heff_dup(v_k_243);
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(v_t_246, heff_rfield(v_p_240, 0)));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop_rec(v_p_240, 1);
    return (g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246(v_v_241, v_d_242));
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_249 = (g_heff_2ecompile_2eemit_2enamesIn(heff_dup(v_p_240), v_d_242));
    V v_t_2413;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDef: {
      V v_k_2410 = heff_field(v_d_242, 0);
      v_t_2413 = heff_dup(v_k_2410);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_t_2417;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDef: {
      V v_b_2416 = heff_field(v_d_242, 2);
      v_t_2417 = heff_dup(v_b_2416);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_t_2418 = ({ V a_0 = heff_get_n(v_p_240, 0, 1); V a_1 = v_t_249; V a_2 = v_t_2413; V a_3 = v_t_2417; V a_4 = v_i_248; V r_ = (g_heff_2ecompile_2eemit_2edefCodeOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2417); r_; });
    HEFF_LAST return g_heff_2ecompile_2eemit_2ekeptCode(v_v_241, v_d_242, v_t_2418);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2eemit_2ekeptOfDef_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2ekeptOfDef(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eemit_2ejsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsAt_entry, 6, 0};

V g_heff_2ecompile_2eemit_2ejsAt(V v_p_240, V v_kept_241, V v_acc_242, V v_d_243, V v_own_244, V v_v_245) {
top: ;
  V v_x2_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_243, 0)), v_kept_241));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    V v_key_247 = heff_dup(heff_rfield(v_d_243, 0));
    V v_t_248 = (g_heff_2ecompile_2elower_2ejsDef(v_d_243, v_own_244));
    V v_k_249 = ({ V a_0 = v_p_240; V a_1 = v_v_245; V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2ekeptOfDef(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_key_247), heff_dup(v_k_249)}), heff_take_field(v_acc_242, 0)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_key_247, v_k_249}), heff_get_n(v_acc_242, 1, 2)});
    return heff_rec_n(2, shape_entries__fresh, (V[]){v_t_2410, v_t_2411});
  }
  case TAG_Just: {
    V v_k_2412 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_2412, 0)), heff_dup(v_v_245))) {
      heff_drop(v_p_240);
      heff_drop(v_own_244);
      heff_drop(v_v_245);
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_d_243, 0, 3), v_k_2412});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_acc_242, 0)});
      return ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 2, shape_entries__fresh, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    } else {
      heff_drop_rec(v_k_2412, 5);
      V v_key_2416 = heff_dup(heff_rfield(v_d_243, 0));
      V v_t_2417 = (g_heff_2ecompile_2elower_2ejsDef(v_d_243, v_own_244));
      V v_k_2418 = ({ V a_0 = v_p_240; V a_1 = v_v_245; V a_2 = v_t_2417; V r_ = (g_heff_2ecompile_2eemit_2ekeptOfDef(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_key_2416), heff_dup(v_k_2418)}), heff_take_field(v_acc_242, 0)});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_key_2416, v_k_2418}), heff_get_n(v_acc_242, 1, 2)});
      return heff_rec_n(2, shape_entries__fresh, (V[]){v_t_2419, v_t_2420});
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemit_2ejsAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ejsAt(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str1, 1, "\012");
V g_heff_2ecompile_2eemit_2eassembled_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eassembled_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eassembled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eassembled_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eassembled(V v_p_240, V v_es_241, V v_curried_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_241)));
  V v_code_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eassembled_lam0, 2, 2, (V[]){heff_dup(v_p_240), heff_dup(v_curried_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_241));
  V v_xs_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s25420611x1990549631(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_uses_2415 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2414; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2414); r_; });
  V v_xs_2416 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get());
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
  V v_helpers_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eassembled_lam1, 2, 1, (V[]){v_uses_2415}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2417; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  V v_x2_2425 = (g_prelude_2e_2b_2b(heff_dup(v_helpers_2424), heff_dup(v_code_2412)));
  V v_t_2428;
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_Nil: {
    v_t_2428 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_xs_2427 = heff_field(v_x2_2425, 1);
    heff_take_n(v_x2_2425, 3ULL, 2);
    v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str1); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2425);
  }
  V v_t_2429 = (g_heff_2ecompile_2eemit_2eruntime(v_t_2428));
  V v_t_2430 = (g_prelude_2e_2b_2b(v_helpers_2424, v_code_2412));
  V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2430));
  return heff_rec_n(2, shape_lines__globals, (V[]){v_t_2431, heff_get_n(v_p_240, 0, 1)});
}
V g_heff_2ecompile_2eemit_2eassembled_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eassembled(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2eassembled_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_p_240 = heff_env(self)[0];
  V v_curried_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411;
  switch (heff_tag_of(v_x_245)) {
  case TAG_MkPair: {
    V v_key_246 = heff_field(v_x_245, 0);
    V v_k_247 = heff_field(v_x_245, 1);
    heff_take_n(v_x_245, 3ULL, 2);
    V v_t_248 = ({ V a_0 = heff_dup(v_key_246); V b_1 = heff_get_n(v_p_240, 0, 1); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_curried_242);
      heff_drop(v_key_246);
      v_t_2411 = heff_get_n(v_k_247, 1, 5);
      break;
    }
    case TAG_Just: {
      V v_i_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2410 = ({ V a_0 = v_curried_242; V a_1 = v_key_246; V a_2 = v_i_249; V a_3 = heff_take_field(v_k_247, 2); V r_ = (g_heff_2ecompile_2eemit_2ewrapper(a_0, a_1, a_2, a_3)); heff_drop(v_curried_242); r_; });
      v_t_2411 = (g_prelude_2e_2b_2b(heff_get_n(v_k_247, 1, 5), v_t_2410));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  return (g_prelude_2e_2b_2b(v_t_2411, v_acc_244));
}
V g_heff_2ecompile_2eemit_2eassembled_lam1(V self, V *args) {
  V v_acc_2418 = args[0];
  V v_x_2419 = args[1];
  V v_uses_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_MkPair: {
    V v_p_2420 = heff_field(v_x_2419, 0);
    V v_i_2421 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 3ULL, 2);
    V v_t_2422 = (g_heff_2ecompile_2eemit_2euncurryGo(NTAG(TAG_Nil), heff_get_n(v_i_2421, 1, 2)));
    v_t_2423 = ({ V a_0 = v_uses_2415; V a_1 = v_p_2420; V a_2 = v_t_2422; V r_ = (g_heff_2ecompile_2eemit_2eprimHelperU(a_0, a_1, a_2)); heff_drop(v_uses_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  return (g_prelude_2e_2b_2b(v_t_2423, v_acc_2418));
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eemitKept_str3, 1, "x");
V g_heff_2ecompile_2eemit_2eemitKept_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eemitKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eemitKept_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eemitKept(V v_facts_240, V v_defs_241, V v_roots_242, V v_kept_243) {
top: ;
  V v_keys_244 = (g_list_2emap_24s1835183789x486277886(heff_dup(v_defs_241)));
  V v_shorts_245 = (g_list_2emap_24s879212241x321667329(((V)&g_heff_2ecompile_2eemit_2eemitKept_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eemitKept_str1), ((V)&g_heff_2ecompile_2eemit_2eemitKept_str2), ((V)&g_heff_2ecompile_2eemit_2eemitKept_str3), heff_dup(v_keys_244)));
  V v_t_248 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eemitKept_lam0, 2, 2, (V[]){v_shorts_245, v_facts_240}); V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_keys_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_keys_244); r_; });
  return ({ V a_0 = heff_rec_n(1, shape_info, (V[]){v_t_248}); V a_1 = v_defs_241; V a_2 = v_roots_242; V a_3 = v_kept_243; V r_ = (g_heff_2ecompile_2eemit_2eemitKeptIn(a_0, a_1, a_2, a_3)); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2eemitKept(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemit_2eemitKept_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_k_247 = args[1];
  V v_shorts_245 = heff_env(self)[0];
  V v_facts_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_shorts_245; V a_1 = v_facts_240; V a_2 = v_acc_246; V a_3 = v_k_247; V r_ = (g_heff_2ecompile_2eemit_2einfoOne(a_0, a_1, a_2, a_3)); heff_drop(v_shorts_245); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str0, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str1, 44, "  $performer = (p, k) => perform(p, now(k));");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str2, 22, "  return $tr(entry());");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str3, 16, "  let depth = 0;");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str4, 129, "  const now = (k) => (x) => { x = $tr(x); if (depth > 1000) { depth = 0; later(() => $tr(k(x))); return; } depth++; $tr(k(x)); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str5, 34, "const $run = (entry, perform) => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str6, 92, "  const later = typeof setImmediate === \"function\" \? setImmediate : (f) => setTimeout(f, 0);");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str7, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str8, 15, "let $performer;");

static V g_heff_2ecompile_2eemit_2erunStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2erunStr_st;
static V g_heff_2ecompile_2eemit_2erunStr_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str6), v_t_242})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunStr_str7); V a_1 = ((V)&g_heff_2ecompile_2eemit_2erunStr_str8); V a_2 = v_t_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_243, 2); r_; });
}
V g_heff_2ecompile_2eemit_2erunStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2erunStr_st)) return g_heff_2ecompile_2eemit_2erunStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2erunStr_val, &g_heff_2ecompile_2eemit_2erunStr_st, g_heff_2ecompile_2eemit_2erunStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esumStr_str0, 77, "const $sum = (l, r) => (p, k) => p.$ === \"InL\" \? l(p.a[0], k) : r(p.a[0], k);");

static V g_heff_2ecompile_2eemit_2esumStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2esumStr_st;
static V g_heff_2ecompile_2eemit_2esumStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2esumStr_str0);
}
V g_heff_2ecompile_2eemit_2esumStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2esumStr_st)) return g_heff_2ecompile_2eemit_2esumStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2esumStr_val, &g_heff_2ecompile_2eemit_2esumStr_st, g_heff_2ecompile_2eemit_2esumStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eexportNameOf_str0, 13, "export const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eexportNameOf_str1, 1, " ");
Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eexportNameOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eexportNameOf(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(13LL)), ((V)&g_heff_2ecompile_2eemit_2eexportNameOf_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength(heff_dup(v_l_240)));
    V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eexportNameOf_str1), v_t_242, MK_INT(0LL)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength(v_l_240));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_strSlice(v_l_240, MK_INT(13LL), heff_intAdd(MK_INT(13LL), v_i_245));
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_246});
    }
    default: return heff_nomatch(v_t_243);
    }
  } else {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eexportNameOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str0, 12, ".provider.js");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str1, 11, " = (() => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str2, 8, "const $p");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str3, 3, "// ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str4, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str5, 13, "export const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str6, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str7, 7, "import ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str8, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str9, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str12, 9, "return { ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str13, 3, " };");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str14, 5, "})();");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str16, 1, "\012");
Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleProvider_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleProvider(V v_i_240, V v_p_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_take_field(v_p_241, 0), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str0));
  V v_t_243 = heff_strAppend(heff_intShow(v_i_240), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str1));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str2), v_t_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str3), v_t_242), v_t_244});
  V v_t_246 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str4), heff_dup(heff_rfield(v_p_241, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_list_2emap_24f881582358x206177481(MK_INT(0LL), MK_INT(13LL), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str5), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str6), MK_INT(13LL), MK_INT(0LL), MK_INT(7LL), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str7), v_t_246));
  V v_t_248 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str8), heff_get_n(v_p_241, 1, 2), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_249 = (g_list_2emap_24s732475005x1616712052(v_t_248));
  V v_x2_2410 = (g_list_2efilter_24f1668687542x1574966783(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str9), v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str11); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str12), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str13)));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str14), NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b(v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2415})));
  V v_x2_2417 = (g_prelude_2e_2b_2b(v_t_245, v_t_2416));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str15);
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str16); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleProvider(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_cell_246;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleAll_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovsForGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprovsForGo(V v_available_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_md_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2efindProv(v_md_242, v_available_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_available_240;
      V t_1 = v_rest_243;
      v_available_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_p_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_p_245, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eemit_2eprovsForGo_24dps(v_available_240, v_rest_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprovsForGo(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecompileProgramKept_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecompileProgramKept_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecompileProgramKept_str2, 1, ".");
Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileProgramKept_entry, 7, 0};

V g_heff_2ecompile_2eemit_2ecompileProgramKept(V v_available_240, V v_g_241, V v_key_242, V v_eff_243, V v_vers_244, V v_ks_245, V v_kept_246) {
top: ;
  V v_t_247 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_243));
  V v_xs_248 = (g_list_2emap_24s270076267x1966815767(((V)&g_heff_2ecompile_2eemit_2ecompileProgramKept_str0), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ecompileProgramKept_str1), ((V)&g_heff_2ecompile_2eemit_2ecompileProgramKept_str2), v_t_247));
  V v_t_249 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = (g_heff_2ecompile_2eemit_2eprovsForGo(v_available_240, v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2elower_2elowerProgramKept(v_g_241, heff_dup(v_key_242), v_vers_244, v_ks_245));
  return ({ V a_0 = v_t_2410; V a_1 = v_eff_243; V a_2 = v_key_242; V a_3 = v_kept_246; V a_4 = v_t_2411; V r_ = (g_heff_2ecompile_2eemit_2ekeptOutput(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_242); r_; });
}
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a6 = a[6]; V r = g_heff_2ecompile_2eemit_2ecompileProgramKept(a0, a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a0); heff_drop(a6); return r;
}