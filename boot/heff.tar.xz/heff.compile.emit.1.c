// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_MkArmJs 44527
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_emitted 749050271
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_fresh 299054408
#define LBL_globals 352931696
#define LBL_gs 10067
#define LBL_info 9732469
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_module 878357911
#define LBL_names 305943394
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_prims 308293287
#define LBL_refs 9991943
#define LBL_self 10021907
#define LBL_text 10052084
#define LBL_used 10094724
#define LBL_ver 326173
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_emitted__fresh[] = {LBL_emitted, LBL_fresh};
static uint32_t shape_entries__fresh[] = {LBL_entries, LBL_fresh};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_js__pre__env[] = {LBL_js, LBL_pre, LBL_env};
static uint32_t shape_lines__env[] = {LBL_lines, LBL_env};
static uint32_t shape_lines__globals[] = {LBL_lines, LBL_globals};
static uint32_t shape_lines__params[] = {LBL_lines, LBL_params};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V, V, V, V);
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo;
V g_heff_2ecompile_2eemit_2earmBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_clo;
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2eassembled(V, V, V);
V g_heff_2ecompile_2eemit_2eassembled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eassembled_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo;
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ebounceGive_24tok2(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_24tok2_clo;
V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo;
V g_heff_2ecompile_2eemit_2ebundleProvider(V, V);
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo;
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_clo;
V g_heff_2ecompile_2eemit_2ecallsHelper(V, V);
V g_heff_2ecompile_2eemit_2ecallsHelper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallsHelper_clo;
HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecompileProgramKept(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo;
V g_heff_2ecompile_2eemit_2econdCode(V);
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdCode_clo;
HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2edefCodeOf(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2edefCodeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edefCodeOf_clo;
V g_heff_2ecompile_2eemit_2edefFun(V, V, V, V);
V g_heff_2ecompile_2eemit_2edefFun_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edefFun_clo;
V g_heff_2ecompile_2eemit_2eeagerCode(V, V);
V g_heff_2ecompile_2eemit_2eeagerCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eeagerCode_clo;
V g_heff_2ecompile_2eemit_2eemitKept(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKept_clo;
HeffT2 g_heff_2ecompile_2eemit_2eemitKept_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
HeffT2 g_heff_2ecompile_2eemit_2efindProv_24cpr(V, V);
V g_heff_2ecompile_2eemit_2efixedCode(V, V);
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efixedCode_clo;
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
V g_heff_2ecompile_2eemit_2einlinable(V, V, V, V);
V g_heff_2ecompile_2eemit_2einlinable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einlinable_clo;
V g_heff_2ecompile_2eemit_2ejsAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ejsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsAt_clo;
V g_heff_2ecompile_2eemit_2ejsNameOf(V, V);
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo;
V g_heff_2ecompile_2eemit_2ejsPick(V, V, V);
V g_heff_2ecompile_2eemit_2ejsPick_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsPick_clo;
V g_heff_2ecompile_2eemit_2ejsVer(V, V, V);
V g_heff_2ecompile_2eemit_2ejsVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsVer_clo;
V g_heff_2ecompile_2eemit_2ekeptCode(V, V, V);
V g_heff_2ecompile_2eemit_2ekeptCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptCode_clo;
V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246(V, V);
V g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246_clo;
V g_heff_2ecompile_2eemit_2ekeptOfDef(V, V, V);
V g_heff_2ecompile_2eemit_2ekeptOfDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptOfDef_clo;
V g_heff_2ecompile_2eemit_2ekeptOutput(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ekeptOutput_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptOutput_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2eletDeclarations(V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo;
HeffT2 g_heff_2ecompile_2eemit_2eletStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elooped_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemit_2enamed(V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_clo;
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_clo;
V g_heff_2ecompile_2eemit_2enamedAs(V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_clo;
V g_heff_2ecompile_2eemit_2enamesIn(V, V);
V g_heff_2ecompile_2eemit_2enamesIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamesIn_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU(V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU_24tok2(V, V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_24tok2_clo;
V g_heff_2ecompile_2eemit_2eprimUses(V, V);
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUses_clo;
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(V, V, V, V);
V g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584_clo;
V g_heff_2ecompile_2eemit_2eprojSuffix(V);
V g_heff_2ecompile_2eemit_2eprojSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprojSuffix_clo;
V g_heff_2ecompile_2eemit_2epropName(V);
V g_heff_2ecompile_2eemit_2epropName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2epropName_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_24dps_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereserved_get(void);
V g_heff_2ecompile_2eemit_2ereturnCond(V, V);
V g_heff_2ecompile_2eemit_2ereturnCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnCond_clo;
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeFrom(V);
V g_heff_2ecompile_2eemit_2esafeFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeFrom_clo;
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
HeffT2 g_heff_2ecompile_2eemit_2esetStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo(V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esharedGo_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo;
HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo;
HeffT2 g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2euncurryGo(V, V);
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2euncurryGo_clo;
HeffT2 g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
V g_heff_2ecompile_2eemit_2ewrapper(V, V, V, V);
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ewrapper_clo;
V g_heff_2ecompile_2eimperative_2efirstNamesTl(V);
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop(V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(V, V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2elower_2ejsDef(V, V);
V g_heff_2ecompile_2elower_2ejsDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ejsDef_clo;
V g_heff_2ecompile_2elower_2elowerProgramKept(V, V, V, V);
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1663632568x709545076(V, V, V, V);
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1663632568x709545076_clo;
V g_list_2efoldl_24f2029054136x351940068(V, V, V, V);
V g_list_2efoldl_24f2029054136x351940068_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2029054136x351940068_clo;
V g_list_2efoldl_24f2082849937x387822498(V, V, V, V);
V g_list_2efoldl_24f2082849937x387822498_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2082849937x387822498_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s2018454372x1607369768(V, V, V, V, V, V, V);
V g_list_2efoldl_24s2018454372x1607369768_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2018454372x1607369768_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s25420611x1990549631(V, V);
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25420611x1990549631_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s963266017x1719814548(V, V);
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a);
extern Clo g_list_2efoldl_24s963266017x1719814548_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1457339348x592422294(V, V, V);
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_clo;
V g_list_2emap_24f1952774010x636070089(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s1585362143x1323498048(V);
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;

HeffT2 g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(V v_x1_240, V v_y_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_y_241}});
  }
  case TAG_Cons: {
    V v_z_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(v_rest_243, v_z_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_ini_247 = v_field_245;
      V v_lst_248 = v_field_246;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_241, v_ini_247}), v_lst_248}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esafeFrom_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esafeFrom_str1, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eemit_2esafeFrom_str2, 1, "_");
Clo g_heff_2ecompile_2eemit_2esafeFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esafeFrom_entry, 1, 0};

V g_heff_2ecompile_2eemit_2esafeFrom(V v_s_240) {
top: ;
  V v_s_241;
  if (heff_strEq_c_lent(v_s_240, ((V)&g_heff_2ecompile_2eemit_2esafeFrom_str0), 2)) {
    heff_drop(v_s_240);
    v_s_241 = ((V)&g_heff_2ecompile_2eemit_2esafeFrom_str1);
  } else {
    v_s_241 = v_s_240;
  }
  V v_t_242 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_s_241)}));
  V v_t_243 = ({ V a_0 = v_t_242; V b_1 = heff_dup(g_heff_2ecompile_2eemit_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  if (((heff_dup(v_t_243) == NTAG(TAG_True)) || ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_241, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_s_241, MK_INT(0LL), 2)) <= ((int64_t)57ULL))))) {
    heff_drop(v_t_243);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esafeFrom_str2), v_s_241);
  } else {
    heff_drop(v_t_243);
    return v_s_241;
  }
}
V g_heff_2ecompile_2eemit_2esafeFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esafeFrom(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2epropName_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2epropName_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2epropName_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2epropName_str3, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2epropName_str4, 1, "\"");
Clo g_heff_2ecompile_2eemit_2epropName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2epropName_entry, 1, 0};

V g_heff_2ecompile_2eemit_2epropName(V v_x_240) {
top: ;
  if ((heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eemit_2epropName_str0), 2) ? 0 : ({ int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)1ULL)); int c_ = ({ V v_t_242 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x_240, heff_box_word(v_t_241))); int c_ = ({ V v_t_243 = (g_heff_2ecompile_2eemit_2espellAt(heff_dup(v_x_240), v_t_242)); int c_ = ({ V v_t_244 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_243, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2epropName_str1))); int c_ = ({ V v_t_246 = (g_heff_2ecompile_2eemit_2esafeFrom(heff_dup(v_t_244))); int c_ = heff_strEq_c_lent(v_t_246, v_x_240, 0); heff_drop(v_t_246); c_; }); heff_drop(v_t_244); c_; }); heff_drop(v_t_243); c_; }); heff_drop(v_t_242); c_; }); c_; }))) {
    return v_x_240;
  } else {
    V v_t_245 = ({ V a_0 = v_x_240; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2epropName_str2); V r_ = (g_heff_2ecompile_2eemit_2equoteGo(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epropName_str3), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2epropName_str4)));
  }
}
V g_heff_2ecompile_2eemit_2epropName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2epropName(a[0]);
}
Clo g_heff_2ecompile_2eemit_2ebindFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebindFrom_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ebindFrom(V v_env_240, V v_x_241, V v_base_242, V v_i_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(v_env_240, v_x_241, v_base_242, v_i_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_rec_n(2, shape_js__env, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebindFrom(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str0, 4, "true");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str1, 5, "false");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str4, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str9, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str14, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str15, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str16, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str17, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str19, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str20, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str21, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str22, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str24, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str26, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str29, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str32, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str33, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str34, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str35, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str36, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str37, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str38, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str39, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str42, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str43, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str44, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str45, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str46, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str47, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str48, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str49, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str50, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str51, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str52, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str53, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str54, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str55, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str56, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str57, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str58, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str59, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str60, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str61, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str62, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str63, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str64, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str65, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str66, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str67, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str68, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str69, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str70, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str71, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str72, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str73, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str74, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str75, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str76, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str77, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str78, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str79, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str80, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str81, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str82, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str83, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str84, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str85, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str86, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str87, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str88, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str89, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str90, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str91, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str92, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str93, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str94, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str95, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str96, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str97, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str98, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str99, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str100, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str101, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str102, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str103, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str104, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str105, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str106, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str107, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str108, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str109, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str110, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str111, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str112, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str113, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str114, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str115, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str116, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str117, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str118, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str119, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str120, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str121, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str122, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str123, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str124, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str125, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str126, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str127, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str128, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str129, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str130, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str131, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str132, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str133, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str134, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str135, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str136, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str137, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str138, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str139, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str140, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str141, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str142, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str143, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str144, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str145, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str146, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str147, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str148, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str149, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str150, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str151, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str152, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str153, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str154, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str155, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str156, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str157, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str158, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str159, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str160, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str161, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str162, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str163, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str164, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str165, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str166, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str167, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str168, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str169, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str170, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str171, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str172, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str173, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str174, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str175, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str176, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str177, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str178, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str179, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str180, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str181, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str182, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str183, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str184, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str185, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str186, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str187, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str188, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str189, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str190, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str191, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str192, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str193, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str194, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str195, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str196, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str197, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str198, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str199, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str200, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str201, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str202, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str203, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str204, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str205, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str206, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str207, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str208, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str209, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str210, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str211, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str212, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str213, 1, "(");

HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JTrue: {
    return ((HeffT2){{((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str0), MK_INT(4LL)}});
  }
  case TAG_JFalse: {
    return ((HeffT2){{((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str1), MK_INT(4LL)}});
  }
  case TAG_JRel: {
    V v_s_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{v_s_241, MK_INT(3LL)}});
  }
  case TAG_JNot: {
    V v_q_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_243 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_q_242));
    V v_t_246;
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      if (heff_intLt_c(v_field_245, MK_INT(4LL))) {
        v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str2), heff_strAppend(v_field_244, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str3)));
      } else {
        v_t_246 = v_field_244;
      }
    }
    V v_f_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str4), v_t_246);
    return ((HeffT2){{v_f_247, MK_INT(4LL)}});
  }
  case TAG_JIf: {
    V v_c_248 = heff_field(v_x1_240, 0);
    V v_t_249 = heff_field(v_x1_240, 1);
    V v_x13_2410 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x13_2410)) {
    case TAG_JTrue: {
      switch (heff_tag_of(v_t_249)) {
      case TAG_JTrue: {
        HeffT2 v_t_2411 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_2414;
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          if (heff_intLt_c(v_field_2413, MK_INT(1LL))) {
            v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str5), heff_strAppend(v_field_2412, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str6)));
          } else {
            v_t_2414 = v_field_2412;
          }
        }
        HeffT2 v_t_2415 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2418;
        {
          V v_field_2416 = v_t_2415.f[0];
          V v_field_2417 = v_t_2415.f[1];
          if (heff_intLt_c(v_field_2417, MK_INT(1LL))) {
            v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str7), heff_strAppend(v_field_2416, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str8)));
          } else {
            v_t_2418 = v_field_2416;
          }
        }
        V v_f_2419 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str9), v_t_2418));
        return ((HeffT2){{v_f_2419, MK_INT(1LL)}});
      }
      case TAG_JFalse: {
        HeffT2 v_t_2420 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2423;
        {
          V v_field_2421 = v_t_2420.f[0];
          V v_field_2422 = v_t_2420.f[1];
          if (heff_intLt_c(v_field_2422, MK_INT(2LL))) {
            v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str10), heff_strAppend(v_field_2421, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str11)));
          } else {
            v_t_2423 = v_field_2421;
          }
        }
        HeffT2 v_t_2424 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2427;
        {
          V v_field_2425 = v_t_2424.f[0];
          V v_field_2426 = v_t_2424.f[1];
          if (heff_intLt_c(v_field_2426, MK_INT(2LL))) {
            v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str12), heff_strAppend(v_field_2425, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str13)));
          } else {
            v_t_2427 = v_field_2425;
          }
        }
        V v_f_2428 = heff_strAppend(v_t_2423, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str14), v_t_2427));
        return ((HeffT2){{v_f_2428, MK_INT(2LL)}});
      }
      case TAG_JRel: {
        HeffT2 v_t_2430 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2433;
        {
          V v_field_2431 = v_t_2430.f[0];
          V v_field_2432 = v_t_2430.f[1];
          if (heff_intLt_c(v_field_2432, MK_INT(1LL))) {
            v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str15), heff_strAppend(v_field_2431, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str16)));
          } else {
            v_t_2433 = v_field_2431;
          }
        }
        HeffT2 v_t_2434 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_2437;
        {
          V v_field_2435 = v_t_2434.f[0];
          V v_field_2436 = v_t_2434.f[1];
          if (heff_intLt_c(v_field_2436, MK_INT(1LL))) {
            v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str17), heff_strAppend(v_field_2435, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str18)));
          } else {
            v_t_2437 = v_field_2435;
          }
        }
        V v_f_2438 = heff_strAppend(v_t_2433, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str19), v_t_2437));
        return ((HeffT2){{v_f_2438, MK_INT(1LL)}});
      }
      case TAG_JNot: {
        HeffT2 v_t_2440 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2443;
        {
          V v_field_2441 = v_t_2440.f[0];
          V v_field_2442 = v_t_2440.f[1];
          if (heff_intLt_c(v_field_2442, MK_INT(1LL))) {
            v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str20), heff_strAppend(v_field_2441, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str21)));
          } else {
            v_t_2443 = v_field_2441;
          }
        }
        HeffT2 v_t_2444 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_2447;
        {
          V v_field_2445 = v_t_2444.f[0];
          V v_field_2446 = v_t_2444.f[1];
          if (heff_intLt_c(v_field_2446, MK_INT(1LL))) {
            v_t_2447 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str22), heff_strAppend(v_field_2445, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str23)));
          } else {
            v_t_2447 = v_field_2445;
          }
        }
        V v_f_2448 = heff_strAppend(v_t_2443, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str24), v_t_2447));
        return ((HeffT2){{v_f_2448, MK_INT(1LL)}});
      }
      case TAG_JIf: {
        HeffT2 v_t_2452 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2455;
        {
          V v_field_2453 = v_t_2452.f[0];
          V v_field_2454 = v_t_2452.f[1];
          if (heff_intLt_c(v_field_2454, MK_INT(1LL))) {
            v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str25), heff_strAppend(v_field_2453, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str26)));
          } else {
            v_t_2455 = v_field_2453;
          }
        }
        HeffT2 v_t_2456 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_2459;
        {
          V v_field_2457 = v_t_2456.f[0];
          V v_field_2458 = v_t_2456.f[1];
          if (heff_intLt_c(v_field_2458, MK_INT(1LL))) {
            v_t_2459 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str27), heff_strAppend(v_field_2457, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str28)));
          } else {
            v_t_2459 = v_field_2457;
          }
        }
        V v_f_2460 = heff_strAppend(v_t_2455, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str29), v_t_2459));
        return ((HeffT2){{v_f_2460, MK_INT(1LL)}});
      }
      case TAG_JSeq: {
        HeffT2 v_t_2464 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2467;
        {
          V v_field_2465 = v_t_2464.f[0];
          V v_field_2466 = v_t_2464.f[1];
          if (heff_intLt_c(v_field_2466, MK_INT(1LL))) {
            v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str30), heff_strAppend(v_field_2465, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str31)));
          } else {
            v_t_2467 = v_field_2465;
          }
        }
        HeffT2 v_t_2468 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_2471;
        {
          V v_field_2469 = v_t_2468.f[0];
          V v_field_2470 = v_t_2468.f[1];
          if (heff_intLt_c(v_field_2470, MK_INT(1LL))) {
            v_t_2471 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str32), heff_strAppend(v_field_2469, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str33)));
          } else {
            v_t_2471 = v_field_2469;
          }
        }
        V v_f_2472 = heff_strAppend(v_t_2467, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str34), v_t_2471));
        return ((HeffT2){{v_f_2472, MK_INT(1LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_249)}});
      }
    }
    case TAG_JFalse: {
      HeffT2 v_t_2473 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
      V v_t_2476;
      {
        V v_field_2474 = v_t_2473.f[0];
        V v_field_2475 = v_t_2473.f[1];
        if (heff_intLt_c(v_field_2475, MK_INT(2LL))) {
          v_t_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str35), heff_strAppend(v_field_2474, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str36)));
        } else {
          v_t_2476 = v_field_2474;
        }
      }
      HeffT2 v_t_2477 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
      V v_t_2480;
      {
        V v_field_2478 = v_t_2477.f[0];
        V v_field_2479 = v_t_2477.f[1];
        if (heff_intLt_c(v_field_2479, MK_INT(2LL))) {
          v_t_2480 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str37), heff_strAppend(v_field_2478, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str38)));
        } else {
          v_t_2480 = v_field_2478;
        }
      }
      V v_f_2481 = heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str39), v_t_2480));
      return ((HeffT2){{v_f_2481, MK_INT(2LL)}});
    }
    case TAG_JRel: {
      switch (heff_tag_of(v_t_249)) {
      case TAG_JTrue: {
        HeffT2 v_t_2483 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_2486;
        {
          V v_field_2484 = v_t_2483.f[0];
          V v_field_2485 = v_t_2483.f[1];
          if (heff_intLt_c(v_field_2485, MK_INT(1LL))) {
            v_t_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str40), heff_strAppend(v_field_2484, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str41)));
          } else {
            v_t_2486 = v_field_2484;
          }
        }
        HeffT2 v_t_2487 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2490;
        {
          V v_field_2488 = v_t_2487.f[0];
          V v_field_2489 = v_t_2487.f[1];
          if (heff_intLt_c(v_field_2489, MK_INT(1LL))) {
            v_t_2490 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str42), heff_strAppend(v_field_2488, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str43)));
          } else {
            v_t_2490 = v_field_2488;
          }
        }
        V v_f_2491 = heff_strAppend(v_t_2486, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str44), v_t_2490));
        return ((HeffT2){{v_f_2491, MK_INT(1LL)}});
      }
      case TAG_JFalse: {
        HeffT2 v_t_2492 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2495;
        {
          V v_field_2493 = v_t_2492.f[0];
          V v_field_2494 = v_t_2492.f[1];
          if (heff_intLt_c(v_field_2494, MK_INT(2LL))) {
            v_t_2495 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str45), heff_strAppend(v_field_2493, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str46)));
          } else {
            v_t_2495 = v_field_2493;
          }
        }
        HeffT2 v_t_2496 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2499;
        {
          V v_field_2497 = v_t_2496.f[0];
          V v_field_2498 = v_t_2496.f[1];
          if (heff_intLt_c(v_field_2498, MK_INT(2LL))) {
            v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str47), heff_strAppend(v_field_2497, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str48)));
          } else {
            v_t_2499 = v_field_2497;
          }
        }
        V v_f_24100 = heff_strAppend(v_t_2495, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str49), v_t_2499));
        return ((HeffT2){{v_f_24100, MK_INT(2LL)}});
      }
      case TAG_JRel: {
        HeffT2 v_t_24102 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24105;
        {
          V v_field_24103 = v_t_24102.f[0];
          V v_field_24104 = v_t_24102.f[1];
          if (heff_intLt_c(v_field_24104, MK_INT(1LL))) {
            v_t_24105 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str50), heff_strAppend(v_field_24103, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str51)));
          } else {
            v_t_24105 = v_field_24103;
          }
        }
        HeffT2 v_t_24106 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24109;
        {
          V v_field_24107 = v_t_24106.f[0];
          V v_field_24108 = v_t_24106.f[1];
          if (heff_intLt_c(v_field_24108, MK_INT(0LL))) {
            v_t_24109 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str52), heff_strAppend(v_field_24107, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str53)));
          } else {
            v_t_24109 = v_field_24107;
          }
        }
        HeffT2 v_t_24110 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24113;
        {
          V v_field_24111 = v_t_24110.f[0];
          V v_field_24112 = v_t_24110.f[1];
          if (heff_intLt_c(v_field_24112, MK_INT(0LL))) {
            v_t_24113 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str54), heff_strAppend(v_field_24111, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str55)));
          } else {
            v_t_24113 = v_field_24111;
          }
        }
        V v_t_24114 = heff_strAppend(v_t_24109, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str56), v_t_24113));
        V v_f_24115 = heff_strAppend(v_t_24105, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str57), v_t_24114));
        return ((HeffT2){{v_f_24115, MK_INT(0LL)}});
      }
      case TAG_JNot: {
        HeffT2 v_t_24117 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24120;
        {
          V v_field_24118 = v_t_24117.f[0];
          V v_field_24119 = v_t_24117.f[1];
          if (heff_intLt_c(v_field_24119, MK_INT(1LL))) {
            v_t_24120 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str58), heff_strAppend(v_field_24118, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str59)));
          } else {
            v_t_24120 = v_field_24118;
          }
        }
        HeffT2 v_t_24121 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24124;
        {
          V v_field_24122 = v_t_24121.f[0];
          V v_field_24123 = v_t_24121.f[1];
          if (heff_intLt_c(v_field_24123, MK_INT(0LL))) {
            v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str60), heff_strAppend(v_field_24122, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str61)));
          } else {
            v_t_24124 = v_field_24122;
          }
        }
        HeffT2 v_t_24125 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24128;
        {
          V v_field_24126 = v_t_24125.f[0];
          V v_field_24127 = v_t_24125.f[1];
          if (heff_intLt_c(v_field_24127, MK_INT(0LL))) {
            v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str62), heff_strAppend(v_field_24126, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str63)));
          } else {
            v_t_24128 = v_field_24126;
          }
        }
        V v_t_24129 = heff_strAppend(v_t_24124, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str64), v_t_24128));
        V v_f_24130 = heff_strAppend(v_t_24120, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str65), v_t_24129));
        return ((HeffT2){{v_f_24130, MK_INT(0LL)}});
      }
      case TAG_JIf: {
        HeffT2 v_t_24134 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24137;
        {
          V v_field_24135 = v_t_24134.f[0];
          V v_field_24136 = v_t_24134.f[1];
          if (heff_intLt_c(v_field_24136, MK_INT(1LL))) {
            v_t_24137 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str66), heff_strAppend(v_field_24135, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str67)));
          } else {
            v_t_24137 = v_field_24135;
          }
        }
        HeffT2 v_t_24138 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24141;
        {
          V v_field_24139 = v_t_24138.f[0];
          V v_field_24140 = v_t_24138.f[1];
          if (heff_intLt_c(v_field_24140, MK_INT(0LL))) {
            v_t_24141 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str68), heff_strAppend(v_field_24139, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str69)));
          } else {
            v_t_24141 = v_field_24139;
          }
        }
        HeffT2 v_t_24142 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24145;
        {
          V v_field_24143 = v_t_24142.f[0];
          V v_field_24144 = v_t_24142.f[1];
          if (heff_intLt_c(v_field_24144, MK_INT(0LL))) {
            v_t_24145 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str70), heff_strAppend(v_field_24143, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str71)));
          } else {
            v_t_24145 = v_field_24143;
          }
        }
        V v_t_24146 = heff_strAppend(v_t_24141, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str72), v_t_24145));
        V v_f_24147 = heff_strAppend(v_t_24137, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str73), v_t_24146));
        return ((HeffT2){{v_f_24147, MK_INT(0LL)}});
      }
      case TAG_JSeq: {
        HeffT2 v_t_24151 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24154;
        {
          V v_field_24152 = v_t_24151.f[0];
          V v_field_24153 = v_t_24151.f[1];
          if (heff_intLt_c(v_field_24153, MK_INT(1LL))) {
            v_t_24154 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str74), heff_strAppend(v_field_24152, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str75)));
          } else {
            v_t_24154 = v_field_24152;
          }
        }
        HeffT2 v_t_24155 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24158;
        {
          V v_field_24156 = v_t_24155.f[0];
          V v_field_24157 = v_t_24155.f[1];
          if (heff_intLt_c(v_field_24157, MK_INT(0LL))) {
            v_t_24158 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str76), heff_strAppend(v_field_24156, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str77)));
          } else {
            v_t_24158 = v_field_24156;
          }
        }
        HeffT2 v_t_24159 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24162;
        {
          V v_field_24160 = v_t_24159.f[0];
          V v_field_24161 = v_t_24159.f[1];
          if (heff_intLt_c(v_field_24161, MK_INT(0LL))) {
            v_t_24162 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str78), heff_strAppend(v_field_24160, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str79)));
          } else {
            v_t_24162 = v_field_24160;
          }
        }
        V v_t_24163 = heff_strAppend(v_t_24158, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str80), v_t_24162));
        V v_f_24164 = heff_strAppend(v_t_24154, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str81), v_t_24163));
        return ((HeffT2){{v_f_24164, MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_249)}});
      }
    }
    case TAG_JNot: {
      switch (heff_tag_of(v_t_249)) {
      case TAG_JTrue: {
        HeffT2 v_t_24166 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24169;
        {
          V v_field_24167 = v_t_24166.f[0];
          V v_field_24168 = v_t_24166.f[1];
          if (heff_intLt_c(v_field_24168, MK_INT(1LL))) {
            v_t_24169 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str82), heff_strAppend(v_field_24167, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str83)));
          } else {
            v_t_24169 = v_field_24167;
          }
        }
        HeffT2 v_t_24170 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24173;
        {
          V v_field_24171 = v_t_24170.f[0];
          V v_field_24172 = v_t_24170.f[1];
          if (heff_intLt_c(v_field_24172, MK_INT(1LL))) {
            v_t_24173 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str84), heff_strAppend(v_field_24171, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str85)));
          } else {
            v_t_24173 = v_field_24171;
          }
        }
        V v_f_24174 = heff_strAppend(v_t_24169, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str86), v_t_24173));
        return ((HeffT2){{v_f_24174, MK_INT(1LL)}});
      }
      case TAG_JFalse: {
        HeffT2 v_t_24175 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_24178;
        {
          V v_field_24176 = v_t_24175.f[0];
          V v_field_24177 = v_t_24175.f[1];
          if (heff_intLt_c(v_field_24177, MK_INT(2LL))) {
            v_t_24178 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str87), heff_strAppend(v_field_24176, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str88)));
          } else {
            v_t_24178 = v_field_24176;
          }
        }
        HeffT2 v_t_24179 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24182;
        {
          V v_field_24180 = v_t_24179.f[0];
          V v_field_24181 = v_t_24179.f[1];
          if (heff_intLt_c(v_field_24181, MK_INT(2LL))) {
            v_t_24182 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str89), heff_strAppend(v_field_24180, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str90)));
          } else {
            v_t_24182 = v_field_24180;
          }
        }
        V v_f_24183 = heff_strAppend(v_t_24178, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str91), v_t_24182));
        return ((HeffT2){{v_f_24183, MK_INT(2LL)}});
      }
      case TAG_JRel: {
        HeffT2 v_t_24185 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24188;
        {
          V v_field_24186 = v_t_24185.f[0];
          V v_field_24187 = v_t_24185.f[1];
          if (heff_intLt_c(v_field_24187, MK_INT(1LL))) {
            v_t_24188 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str92), heff_strAppend(v_field_24186, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str93)));
          } else {
            v_t_24188 = v_field_24186;
          }
        }
        HeffT2 v_t_24189 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24192;
        {
          V v_field_24190 = v_t_24189.f[0];
          V v_field_24191 = v_t_24189.f[1];
          if (heff_intLt_c(v_field_24191, MK_INT(0LL))) {
            v_t_24192 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str94), heff_strAppend(v_field_24190, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str95)));
          } else {
            v_t_24192 = v_field_24190;
          }
        }
        HeffT2 v_t_24193 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24196;
        {
          V v_field_24194 = v_t_24193.f[0];
          V v_field_24195 = v_t_24193.f[1];
          if (heff_intLt_c(v_field_24195, MK_INT(0LL))) {
            v_t_24196 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str96), heff_strAppend(v_field_24194, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str97)));
          } else {
            v_t_24196 = v_field_24194;
          }
        }
        V v_t_24197 = heff_strAppend(v_t_24192, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str98), v_t_24196));
        V v_f_24198 = heff_strAppend(v_t_24188, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str99), v_t_24197));
        return ((HeffT2){{v_f_24198, MK_INT(0LL)}});
      }
      case TAG_JNot: {
        HeffT2 v_t_24200 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24203;
        {
          V v_field_24201 = v_t_24200.f[0];
          V v_field_24202 = v_t_24200.f[1];
          if (heff_intLt_c(v_field_24202, MK_INT(1LL))) {
            v_t_24203 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str100), heff_strAppend(v_field_24201, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str101)));
          } else {
            v_t_24203 = v_field_24201;
          }
        }
        HeffT2 v_t_24204 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24207;
        {
          V v_field_24205 = v_t_24204.f[0];
          V v_field_24206 = v_t_24204.f[1];
          if (heff_intLt_c(v_field_24206, MK_INT(0LL))) {
            v_t_24207 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str102), heff_strAppend(v_field_24205, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str103)));
          } else {
            v_t_24207 = v_field_24205;
          }
        }
        HeffT2 v_t_24208 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24211;
        {
          V v_field_24209 = v_t_24208.f[0];
          V v_field_24210 = v_t_24208.f[1];
          if (heff_intLt_c(v_field_24210, MK_INT(0LL))) {
            v_t_24211 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str104), heff_strAppend(v_field_24209, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str105)));
          } else {
            v_t_24211 = v_field_24209;
          }
        }
        V v_t_24212 = heff_strAppend(v_t_24207, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str106), v_t_24211));
        V v_f_24213 = heff_strAppend(v_t_24203, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str107), v_t_24212));
        return ((HeffT2){{v_f_24213, MK_INT(0LL)}});
      }
      case TAG_JIf: {
        HeffT2 v_t_24217 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24220;
        {
          V v_field_24218 = v_t_24217.f[0];
          V v_field_24219 = v_t_24217.f[1];
          if (heff_intLt_c(v_field_24219, MK_INT(1LL))) {
            v_t_24220 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str108), heff_strAppend(v_field_24218, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str109)));
          } else {
            v_t_24220 = v_field_24218;
          }
        }
        HeffT2 v_t_24221 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24224;
        {
          V v_field_24222 = v_t_24221.f[0];
          V v_field_24223 = v_t_24221.f[1];
          if (heff_intLt_c(v_field_24223, MK_INT(0LL))) {
            v_t_24224 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str110), heff_strAppend(v_field_24222, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str111)));
          } else {
            v_t_24224 = v_field_24222;
          }
        }
        HeffT2 v_t_24225 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24228;
        {
          V v_field_24226 = v_t_24225.f[0];
          V v_field_24227 = v_t_24225.f[1];
          if (heff_intLt_c(v_field_24227, MK_INT(0LL))) {
            v_t_24228 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str112), heff_strAppend(v_field_24226, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str113)));
          } else {
            v_t_24228 = v_field_24226;
          }
        }
        V v_t_24229 = heff_strAppend(v_t_24224, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str114), v_t_24228));
        V v_f_24230 = heff_strAppend(v_t_24220, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str115), v_t_24229));
        return ((HeffT2){{v_f_24230, MK_INT(0LL)}});
      }
      case TAG_JSeq: {
        HeffT2 v_t_24234 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24237;
        {
          V v_field_24235 = v_t_24234.f[0];
          V v_field_24236 = v_t_24234.f[1];
          if (heff_intLt_c(v_field_24236, MK_INT(1LL))) {
            v_t_24237 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str116), heff_strAppend(v_field_24235, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str117)));
          } else {
            v_t_24237 = v_field_24235;
          }
        }
        HeffT2 v_t_24238 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24241;
        {
          V v_field_24239 = v_t_24238.f[0];
          V v_field_24240 = v_t_24238.f[1];
          if (heff_intLt_c(v_field_24240, MK_INT(0LL))) {
            v_t_24241 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str118), heff_strAppend(v_field_24239, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str119)));
          } else {
            v_t_24241 = v_field_24239;
          }
        }
        HeffT2 v_t_24242 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24245;
        {
          V v_field_24243 = v_t_24242.f[0];
          V v_field_24244 = v_t_24242.f[1];
          if (heff_intLt_c(v_field_24244, MK_INT(0LL))) {
            v_t_24245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str120), heff_strAppend(v_field_24243, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str121)));
          } else {
            v_t_24245 = v_field_24243;
          }
        }
        V v_t_24246 = heff_strAppend(v_t_24241, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str122), v_t_24245));
        V v_f_24247 = heff_strAppend(v_t_24237, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str123), v_t_24246));
        return ((HeffT2){{v_f_24247, MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_249)}});
      }
    }
    case TAG_JIf: {
      switch (heff_tag_of(v_t_249)) {
      case TAG_JTrue: {
        HeffT2 v_t_24251 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24254;
        {
          V v_field_24252 = v_t_24251.f[0];
          V v_field_24253 = v_t_24251.f[1];
          if (heff_intLt_c(v_field_24253, MK_INT(1LL))) {
            v_t_24254 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str124), heff_strAppend(v_field_24252, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str125)));
          } else {
            v_t_24254 = v_field_24252;
          }
        }
        HeffT2 v_t_24255 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24258;
        {
          V v_field_24256 = v_t_24255.f[0];
          V v_field_24257 = v_t_24255.f[1];
          if (heff_intLt_c(v_field_24257, MK_INT(1LL))) {
            v_t_24258 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str126), heff_strAppend(v_field_24256, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str127)));
          } else {
            v_t_24258 = v_field_24256;
          }
        }
        V v_f_24259 = heff_strAppend(v_t_24254, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str128), v_t_24258));
        return ((HeffT2){{v_f_24259, MK_INT(1LL)}});
      }
      case TAG_JFalse: {
        HeffT2 v_t_24260 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_24263;
        {
          V v_field_24261 = v_t_24260.f[0];
          V v_field_24262 = v_t_24260.f[1];
          if (heff_intLt_c(v_field_24262, MK_INT(2LL))) {
            v_t_24263 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str129), heff_strAppend(v_field_24261, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str130)));
          } else {
            v_t_24263 = v_field_24261;
          }
        }
        HeffT2 v_t_24264 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24267;
        {
          V v_field_24265 = v_t_24264.f[0];
          V v_field_24266 = v_t_24264.f[1];
          if (heff_intLt_c(v_field_24266, MK_INT(2LL))) {
            v_t_24267 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str131), heff_strAppend(v_field_24265, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str132)));
          } else {
            v_t_24267 = v_field_24265;
          }
        }
        V v_f_24268 = heff_strAppend(v_t_24263, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str133), v_t_24267));
        return ((HeffT2){{v_f_24268, MK_INT(2LL)}});
      }
      case TAG_JRel: {
        HeffT2 v_t_24270 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24273;
        {
          V v_field_24271 = v_t_24270.f[0];
          V v_field_24272 = v_t_24270.f[1];
          if (heff_intLt_c(v_field_24272, MK_INT(1LL))) {
            v_t_24273 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str134), heff_strAppend(v_field_24271, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str135)));
          } else {
            v_t_24273 = v_field_24271;
          }
        }
        HeffT2 v_t_24274 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24277;
        {
          V v_field_24275 = v_t_24274.f[0];
          V v_field_24276 = v_t_24274.f[1];
          if (heff_intLt_c(v_field_24276, MK_INT(0LL))) {
            v_t_24277 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str136), heff_strAppend(v_field_24275, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str137)));
          } else {
            v_t_24277 = v_field_24275;
          }
        }
        HeffT2 v_t_24278 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24281;
        {
          V v_field_24279 = v_t_24278.f[0];
          V v_field_24280 = v_t_24278.f[1];
          if (heff_intLt_c(v_field_24280, MK_INT(0LL))) {
            v_t_24281 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str138), heff_strAppend(v_field_24279, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str139)));
          } else {
            v_t_24281 = v_field_24279;
          }
        }
        V v_t_24282 = heff_strAppend(v_t_24277, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str140), v_t_24281));
        V v_f_24283 = heff_strAppend(v_t_24273, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str141), v_t_24282));
        return ((HeffT2){{v_f_24283, MK_INT(0LL)}});
      }
      case TAG_JNot: {
        HeffT2 v_t_24285 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24288;
        {
          V v_field_24286 = v_t_24285.f[0];
          V v_field_24287 = v_t_24285.f[1];
          if (heff_intLt_c(v_field_24287, MK_INT(1LL))) {
            v_t_24288 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str142), heff_strAppend(v_field_24286, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str143)));
          } else {
            v_t_24288 = v_field_24286;
          }
        }
        HeffT2 v_t_24289 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24292;
        {
          V v_field_24290 = v_t_24289.f[0];
          V v_field_24291 = v_t_24289.f[1];
          if (heff_intLt_c(v_field_24291, MK_INT(0LL))) {
            v_t_24292 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str144), heff_strAppend(v_field_24290, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str145)));
          } else {
            v_t_24292 = v_field_24290;
          }
        }
        HeffT2 v_t_24293 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24296;
        {
          V v_field_24294 = v_t_24293.f[0];
          V v_field_24295 = v_t_24293.f[1];
          if (heff_intLt_c(v_field_24295, MK_INT(0LL))) {
            v_t_24296 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str146), heff_strAppend(v_field_24294, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str147)));
          } else {
            v_t_24296 = v_field_24294;
          }
        }
        V v_t_24297 = heff_strAppend(v_t_24292, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str148), v_t_24296));
        V v_f_24298 = heff_strAppend(v_t_24288, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str149), v_t_24297));
        return ((HeffT2){{v_f_24298, MK_INT(0LL)}});
      }
      case TAG_JIf: {
        HeffT2 v_t_24302 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24305;
        {
          V v_field_24303 = v_t_24302.f[0];
          V v_field_24304 = v_t_24302.f[1];
          if (heff_intLt_c(v_field_24304, MK_INT(1LL))) {
            v_t_24305 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str150), heff_strAppend(v_field_24303, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str151)));
          } else {
            v_t_24305 = v_field_24303;
          }
        }
        HeffT2 v_t_24306 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24309;
        {
          V v_field_24307 = v_t_24306.f[0];
          V v_field_24308 = v_t_24306.f[1];
          if (heff_intLt_c(v_field_24308, MK_INT(0LL))) {
            v_t_24309 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str152), heff_strAppend(v_field_24307, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str153)));
          } else {
            v_t_24309 = v_field_24307;
          }
        }
        HeffT2 v_t_24310 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24313;
        {
          V v_field_24311 = v_t_24310.f[0];
          V v_field_24312 = v_t_24310.f[1];
          if (heff_intLt_c(v_field_24312, MK_INT(0LL))) {
            v_t_24313 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str154), heff_strAppend(v_field_24311, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str155)));
          } else {
            v_t_24313 = v_field_24311;
          }
        }
        V v_t_24314 = heff_strAppend(v_t_24309, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str156), v_t_24313));
        V v_f_24315 = heff_strAppend(v_t_24305, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str157), v_t_24314));
        return ((HeffT2){{v_f_24315, MK_INT(0LL)}});
      }
      case TAG_JSeq: {
        HeffT2 v_t_24319 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24322;
        {
          V v_field_24320 = v_t_24319.f[0];
          V v_field_24321 = v_t_24319.f[1];
          if (heff_intLt_c(v_field_24321, MK_INT(1LL))) {
            v_t_24322 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str158), heff_strAppend(v_field_24320, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str159)));
          } else {
            v_t_24322 = v_field_24320;
          }
        }
        HeffT2 v_t_24323 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24326;
        {
          V v_field_24324 = v_t_24323.f[0];
          V v_field_24325 = v_t_24323.f[1];
          if (heff_intLt_c(v_field_24325, MK_INT(0LL))) {
            v_t_24326 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str160), heff_strAppend(v_field_24324, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str161)));
          } else {
            v_t_24326 = v_field_24324;
          }
        }
        HeffT2 v_t_24327 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24330;
        {
          V v_field_24328 = v_t_24327.f[0];
          V v_field_24329 = v_t_24327.f[1];
          if (heff_intLt_c(v_field_24329, MK_INT(0LL))) {
            v_t_24330 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str162), heff_strAppend(v_field_24328, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str163)));
          } else {
            v_t_24330 = v_field_24328;
          }
        }
        V v_t_24331 = heff_strAppend(v_t_24326, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str164), v_t_24330));
        V v_f_24332 = heff_strAppend(v_t_24322, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str165), v_t_24331));
        return ((HeffT2){{v_f_24332, MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_249)}});
      }
    }
    case TAG_JSeq: {
      switch (heff_tag_of(v_t_249)) {
      case TAG_JTrue: {
        HeffT2 v_t_24336 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24339;
        {
          V v_field_24337 = v_t_24336.f[0];
          V v_field_24338 = v_t_24336.f[1];
          if (heff_intLt_c(v_field_24338, MK_INT(1LL))) {
            v_t_24339 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str166), heff_strAppend(v_field_24337, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str167)));
          } else {
            v_t_24339 = v_field_24337;
          }
        }
        HeffT2 v_t_24340 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24343;
        {
          V v_field_24341 = v_t_24340.f[0];
          V v_field_24342 = v_t_24340.f[1];
          if (heff_intLt_c(v_field_24342, MK_INT(1LL))) {
            v_t_24343 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str168), heff_strAppend(v_field_24341, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str169)));
          } else {
            v_t_24343 = v_field_24341;
          }
        }
        V v_f_24344 = heff_strAppend(v_t_24339, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str170), v_t_24343));
        return ((HeffT2){{v_f_24344, MK_INT(1LL)}});
      }
      case TAG_JFalse: {
        HeffT2 v_t_24345 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_24348;
        {
          V v_field_24346 = v_t_24345.f[0];
          V v_field_24347 = v_t_24345.f[1];
          if (heff_intLt_c(v_field_24347, MK_INT(2LL))) {
            v_t_24348 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str171), heff_strAppend(v_field_24346, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str172)));
          } else {
            v_t_24348 = v_field_24346;
          }
        }
        HeffT2 v_t_24349 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24352;
        {
          V v_field_24350 = v_t_24349.f[0];
          V v_field_24351 = v_t_24349.f[1];
          if (heff_intLt_c(v_field_24351, MK_INT(2LL))) {
            v_t_24352 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str173), heff_strAppend(v_field_24350, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str174)));
          } else {
            v_t_24352 = v_field_24350;
          }
        }
        V v_f_24353 = heff_strAppend(v_t_24348, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str175), v_t_24352));
        return ((HeffT2){{v_f_24353, MK_INT(2LL)}});
      }
      case TAG_JRel: {
        HeffT2 v_t_24355 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24358;
        {
          V v_field_24356 = v_t_24355.f[0];
          V v_field_24357 = v_t_24355.f[1];
          if (heff_intLt_c(v_field_24357, MK_INT(1LL))) {
            v_t_24358 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str176), heff_strAppend(v_field_24356, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str177)));
          } else {
            v_t_24358 = v_field_24356;
          }
        }
        HeffT2 v_t_24359 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24362;
        {
          V v_field_24360 = v_t_24359.f[0];
          V v_field_24361 = v_t_24359.f[1];
          if (heff_intLt_c(v_field_24361, MK_INT(0LL))) {
            v_t_24362 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str178), heff_strAppend(v_field_24360, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str179)));
          } else {
            v_t_24362 = v_field_24360;
          }
        }
        HeffT2 v_t_24363 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24366;
        {
          V v_field_24364 = v_t_24363.f[0];
          V v_field_24365 = v_t_24363.f[1];
          if (heff_intLt_c(v_field_24365, MK_INT(0LL))) {
            v_t_24366 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str180), heff_strAppend(v_field_24364, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str181)));
          } else {
            v_t_24366 = v_field_24364;
          }
        }
        V v_t_24367 = heff_strAppend(v_t_24362, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str182), v_t_24366));
        V v_f_24368 = heff_strAppend(v_t_24358, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str183), v_t_24367));
        return ((HeffT2){{v_f_24368, MK_INT(0LL)}});
      }
      case TAG_JNot: {
        HeffT2 v_t_24370 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24373;
        {
          V v_field_24371 = v_t_24370.f[0];
          V v_field_24372 = v_t_24370.f[1];
          if (heff_intLt_c(v_field_24372, MK_INT(1LL))) {
            v_t_24373 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str184), heff_strAppend(v_field_24371, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str185)));
          } else {
            v_t_24373 = v_field_24371;
          }
        }
        HeffT2 v_t_24374 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24377;
        {
          V v_field_24375 = v_t_24374.f[0];
          V v_field_24376 = v_t_24374.f[1];
          if (heff_intLt_c(v_field_24376, MK_INT(0LL))) {
            v_t_24377 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str186), heff_strAppend(v_field_24375, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str187)));
          } else {
            v_t_24377 = v_field_24375;
          }
        }
        HeffT2 v_t_24378 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24381;
        {
          V v_field_24379 = v_t_24378.f[0];
          V v_field_24380 = v_t_24378.f[1];
          if (heff_intLt_c(v_field_24380, MK_INT(0LL))) {
            v_t_24381 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str188), heff_strAppend(v_field_24379, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str189)));
          } else {
            v_t_24381 = v_field_24379;
          }
        }
        V v_t_24382 = heff_strAppend(v_t_24377, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str190), v_t_24381));
        V v_f_24383 = heff_strAppend(v_t_24373, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str191), v_t_24382));
        return ((HeffT2){{v_f_24383, MK_INT(0LL)}});
      }
      case TAG_JIf: {
        HeffT2 v_t_24387 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24390;
        {
          V v_field_24388 = v_t_24387.f[0];
          V v_field_24389 = v_t_24387.f[1];
          if (heff_intLt_c(v_field_24389, MK_INT(1LL))) {
            v_t_24390 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str192), heff_strAppend(v_field_24388, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str193)));
          } else {
            v_t_24390 = v_field_24388;
          }
        }
        HeffT2 v_t_24391 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24394;
        {
          V v_field_24392 = v_t_24391.f[0];
          V v_field_24393 = v_t_24391.f[1];
          if (heff_intLt_c(v_field_24393, MK_INT(0LL))) {
            v_t_24394 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str194), heff_strAppend(v_field_24392, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str195)));
          } else {
            v_t_24394 = v_field_24392;
          }
        }
        HeffT2 v_t_24395 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24398;
        {
          V v_field_24396 = v_t_24395.f[0];
          V v_field_24397 = v_t_24395.f[1];
          if (heff_intLt_c(v_field_24397, MK_INT(0LL))) {
            v_t_24398 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str196), heff_strAppend(v_field_24396, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str197)));
          } else {
            v_t_24398 = v_field_24396;
          }
        }
        V v_t_24399 = heff_strAppend(v_t_24394, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str198), v_t_24398));
        V v_f_24400 = heff_strAppend(v_t_24390, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str199), v_t_24399));
        return ((HeffT2){{v_f_24400, MK_INT(0LL)}});
      }
      case TAG_JSeq: {
        HeffT2 v_t_24404 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_24407;
        {
          V v_field_24405 = v_t_24404.f[0];
          V v_field_24406 = v_t_24404.f[1];
          if (heff_intLt_c(v_field_24406, MK_INT(1LL))) {
            v_t_24407 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str200), heff_strAppend(v_field_24405, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str201)));
          } else {
            v_t_24407 = v_field_24405;
          }
        }
        HeffT2 v_t_24408 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_24411;
        {
          V v_field_24409 = v_t_24408.f[0];
          V v_field_24410 = v_t_24408.f[1];
          if (heff_intLt_c(v_field_24410, MK_INT(0LL))) {
            v_t_24411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str202), heff_strAppend(v_field_24409, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str203)));
          } else {
            v_t_24411 = v_field_24409;
          }
        }
        HeffT2 v_t_24412 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_24415;
        {
          V v_field_24413 = v_t_24412.f[0];
          V v_field_24414 = v_t_24412.f[1];
          if (heff_intLt_c(v_field_24414, MK_INT(0LL))) {
            v_t_24415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str204), heff_strAppend(v_field_24413, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str205)));
          } else {
            v_t_24415 = v_field_24413;
          }
        }
        V v_t_24416 = heff_strAppend(v_t_24411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str206), v_t_24415));
        V v_f_24417 = heff_strAppend(v_t_24407, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str207), v_t_24416));
        return ((HeffT2){{v_f_24417, MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x13_2410)}});
    }
  }
  case TAG_JSeq: {
    V v_x_24418 = heff_field(v_x1_240, 0);
    V v_a_24419 = heff_field(v_x1_240, 1);
    V v_q_24420 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_24421 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_q_24420));
    V v_t_24424;
    {
      V v_field_24422 = v_t_24421.f[0];
      V v_field_24423 = v_t_24421.f[1];
      if (heff_intLt_c(v_field_24423, MK_INT(1LL))) {
        v_t_24424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str208), heff_strAppend(v_field_24422, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str209)));
      } else {
        v_t_24424 = v_field_24422;
      }
    }
    V v_t_24425 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str210), heff_strAppend(v_t_24424, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str211)));
    V v_t_24426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str212), heff_strAppend(v_a_24419, v_t_24425));
    V v_f_24427 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str213), heff_strAppend(v_x_24418, v_t_24426));
    return ((HeffT2){{v_f_24427, MK_INT(4LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eemit_2econdCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2econdCode(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_code__prec, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str5, 4, "let ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str6, 1, ";");
Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eletDeclarations_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eletDeclarations(V v_ind_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x2_244 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_x2_248 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_241));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str4); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str5), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str6)));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_t_2412), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eletDeclarations(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2earmJs_str0, 0, "");
V g_heff_2ecompile_2eemit_2earmJs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2earmJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmJs_entry, 6, 0};

V g_heff_2ecompile_2eemit_2earmJs(V v_sc_240, V v_ind_241, V v_tag_242, V v_vs_243, V v_parts_244, V v_lines_245) {
top: ;
  V v_t_248 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eemit_2earmJs_lam0, 1, 1, (V[]){heff_dup(v_parts_244)}), v_vs_243));
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_vs_243);
    heff_drop(v_t_248);
    V v_t_249 = heff_tr(heff_call(v_lines_245, 2, (V[]){heff_get_n(v_sc_240, 1, 3), heff_intAdd(v_ind_241, MK_INT(2LL))}));
    return heff_tag_n(TAG_MkArmJs, 3, (V[]){v_tag_242, NTAG(TAG_True), v_t_249});
  } else {
    heff_drop(v_t_248);
    V v_t_2410 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), heff_dup(heff_rfield(v_sc_240, 1))});
    V v_t_2411 = (g_list_2efoldl_24s2018454372x1607369768(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2earmJs_str0), MK_INT(0LL), v_t_2410, v_vs_243));
    return (g_heff_2ecompile_2eemit_2earmBound(v_sc_240, v_ind_241, v_tag_242, v_lines_245, v_t_2411));
  }
}
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eemit_2earmJs(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eemit_2earmJs_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_parts_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_v_246; V a_1 = v_parts_244; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_v_246); heff_drop(v_parts_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str3, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str7, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str8, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str12, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str13, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str14, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str15, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str16, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str19, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str23, 1, "}");
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemit_2esharedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esharedGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2esharedGo(V v_ind_240, V v_before_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    heff_drop(v_before_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArmJs: {
      V v_a2_246 = heff_dup(heff_field(v_a_243, 1));
      V v_ls_247 = heff_dup(heff_field(v_a_243, 2));
      if ((heff_dup(v_a2_246) == NTAG(TAG_True))) {
        heff_drop(v_a2_246);
        V v_t_2421 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), v_before_241));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_ls_247);
          heff_drop(v_t_2421);
          V t_0 = v_ind_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241});
          V t_2 = v_rest_244;
          v_ind_240 = t_0;
          v_before_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_t_2421);
          V v_t_2435 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam1, 1, 1, (V[]){heff_dup(v_a_243)}), heff_dup(v_rest_244)));
          V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam2, 1, 1, (V[]){heff_dup(v_ind_240)}), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_243), v_t_2435})));
          V v_x2_2449 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str16)));
          V v_t_2452;
          switch (heff_tag_of(v_x2_2449)) {
          case TAG_Nil: {
            v_t_2452 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str17);
            break;
          }
          case TAG_Cons: {
            V v_x_2450 = heff_field(v_x2_2449, 0);
            V v_xs_2451 = heff_field(v_x2_2449, 1);
            heff_take_n(v_x2_2449, 3ULL, 2);
            v_t_2452 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str18); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2449);
          }
          V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str19)), NTAG(TAG_Nil)});
          V v_x2_2454 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str20)));
          V v_t_2457;
          switch (heff_tag_of(v_x2_2454)) {
          case TAG_Nil: {
            v_t_2457 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str21);
            break;
          }
          case TAG_Cons: {
            V v_x_2455 = heff_field(v_x2_2454, 0);
            V v_xs_2456 = heff_field(v_x2_2454, 1);
            heff_take_n(v_x2_2454, 3ULL, 2);
            v_t_2457 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str22); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2454);
          }
          V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str23)), NTAG(TAG_Nil)});
          V v_t_2459 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
          V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2458, v_t_2459));
          V v_t_2461 = (g_prelude_2e_2b_2b(v_ls_247, v_t_2460));
          V v_t_2462 = (g_prelude_2e_2b_2b(v_t_2453, v_t_2461));
          return (g_prelude_2e_2b_2b(v_t_2448, v_t_2462));
        }
      } else {
        heff_drop(v_a2_246);
        V v_t_2463 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
        return (g_prelude_2e_2b_2b(v_ls_247, v_t_2463));
      }
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esharedGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args) {
  V v_b_248 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2410 = heff_field(v_a_243, 1);
    V v_ls_2411 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    if ((heff_dup(v_x12_2410) == NTAG(TAG_True))) {
      heff_drop(v_x12_2410);
      V v_t_2414;
      switch (heff_tag_of(v_ls_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_ls_2411, 0);
        V v_xs_2413 = heff_field(v_ls_2411, 1);
        heff_take_n(v_ls_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2411);
      }
      switch (heff_tag_of(v_b_248)) {
      case TAG_MkArmJs: {
        V v_x12_2416 = heff_field(v_b_248, 1);
        V v_ls_2417 = heff_field(v_b_248, 2);
        heff_take_n(v_b_248, 6ULL, 3);
        if ((heff_dup(v_x12_2416) == NTAG(TAG_True))) {
          heff_drop(v_x12_2416);
          V v_k2_2420;
          switch (heff_tag_of(v_ls_2417)) {
          case TAG_Nil: {
            v_k2_2420 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str2);
            break;
          }
          case TAG_Cons: {
            V v_x_2418 = heff_field(v_ls_2417, 0);
            V v_xs_2419 = heff_field(v_ls_2417, 1);
            heff_take_n(v_ls_2417, 3ULL, 2);
            v_k2_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str3); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
            break;
          }
          default: heff_nomatch(v_ls_2417);
          }
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2414, v_k2_2420, 0));
          heff_drop(v_t_2414);
          heff_drop(v_k2_2420);
          return v_ret_24bool;
        } else {
          heff_drop(v_t_2414);
          heff_drop(v_x12_2416);
          heff_drop(v_ls_2417);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_b_248);
      }
    } else {
      heff_drop(v_b_248);
      heff_drop(v_x12_2410);
      heff_drop(v_ls_2411);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args) {
  V v_b_2422 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2424 = heff_field(v_a_243, 1);
    V v_ls_2425 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    if ((heff_dup(v_x12_2424) == NTAG(TAG_True))) {
      heff_drop(v_x12_2424);
      V v_t_2428;
      switch (heff_tag_of(v_ls_2425)) {
      case TAG_Nil: {
        v_t_2428 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_ls_2425, 0);
        V v_xs_2427 = heff_field(v_ls_2425, 1);
        heff_take_n(v_ls_2425, 3ULL, 2);
        v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str5); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2425);
      }
      switch (heff_tag_of(v_b_2422)) {
      case TAG_MkArmJs: {
        V v_x12_2430 = heff_field(v_b_2422, 1);
        V v_ls_2431 = heff_field(v_b_2422, 2);
        heff_take_n(v_b_2422, 6ULL, 3);
        if ((heff_dup(v_x12_2430) == NTAG(TAG_True))) {
          heff_drop(v_x12_2430);
          V v_k2_2434;
          switch (heff_tag_of(v_ls_2431)) {
          case TAG_Nil: {
            v_k2_2434 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str6);
            break;
          }
          case TAG_Cons: {
            V v_x_2432 = heff_field(v_ls_2431, 0);
            V v_xs_2433 = heff_field(v_ls_2431, 1);
            heff_take_n(v_ls_2431, 3ULL, 2);
            v_k2_2434 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str7); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
            break;
          }
          default: heff_nomatch(v_ls_2431);
          }
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2428, v_k2_2434, 0));
          heff_drop(v_t_2428);
          heff_drop(v_k2_2434);
          return v_ret_24bool;
        } else {
          heff_drop(v_t_2428);
          heff_drop(v_x12_2430);
          heff_drop(v_ls_2431);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_b_2422);
      }
    } else {
      heff_drop(v_b_2422);
      heff_drop(v_x12_2424);
      heff_drop(v_ls_2425);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args) {
  V v_b_2436 = args[0];
  V v_ind_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2437 = (g_list_2ereplicate(heff_intAdd(v_ind_240, MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str8)));
  V v_t_2440;
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_Nil: {
    v_t_2440 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_xs_2439 = heff_field(v_x2_2437, 1);
    heff_take_n(v_x2_2437, 3ULL, 2);
    v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str10); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2437);
  }
  V v_t_2444;
  switch (heff_tag_of(v_b_2436)) {
  case TAG_MkArmJs: {
    V v_t_2441 = heff_field(v_b_2436, 0);
    heff_take_n(v_b_2436, 1ULL, 3);
    v_t_2444 = v_t_2441;
    break;
  }
  default: heff_nomatch(v_b_2436);
  }
  V v_t_2445 = ({ V a_0 = v_t_2444; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str11); V r_ = (g_heff_2ecompile_2eemit_2equoteGo(a_0, a_1, a_2)); heff_drop(v_t_2444); r_; });
  V v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str12), heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str13)));
  V v_t_2447 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str14), heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str15)));
  return heff_strAppend(v_t_2440, v_t_2447);
}
Clo g_heff_2ecompile_2eemit_2einlinable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2einlinable_entry, 4, 0};

V g_heff_2ecompile_2eemit_2einlinable(V v_x_240, V v_o_241, V v_rest_242, V v_after_243) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_next_2418;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_next_2418 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_245 = heff_field(v_after_243, 0);
        v_next_2418 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_245));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_246 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_246)) {
      case TAG_SLet: {
        V v_o_249 = heff_field(v_st_246, 1);
        V v_ru_24st_246_24SLet = heff_take_reuse_n(v_st_246, 2ULL, 2);
        v_next_2418 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_246_24SLet, v_o_249));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_246, 0ULL, 1);
        v_next_2418 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2412 = heff_field(v_st_246, 1);
        V v_ru_24st_246_24SSet = heff_take_reuse_n(v_st_246, 2ULL, 2);
        v_next_2418 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_246_24SSet, v_o_2412));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_246, 0ULL, 3);
        v_next_2418 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2416 = heff_field(v_st_246, 0);
        heff_take_n(v_st_246, 1ULL, 2);
        v_next_2418 = ({ V a_0 = v_v_2416; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2416); r_; });
        break;
      }
      default: heff_nomatch(v_st_246);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_t_2422;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2421 = heff_field(v_after_243, 0);
      v_t_2422 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2421, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_rest_2423 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2422));
    V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_next_2418; V r_ = (g_list_2efoldl_24f2029054136x351940068(a_0, a_1, a_2, a_3)); heff_drop(v_next_2418); r_; });
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_2424, MK_INT(1LL), 2) && ({ V v_t_24112 = (g_list_2efoldl_24f1663632568x709545076(MK_INT(1LL), MK_INT(0LL), v_x_240, v_rest_2423)); int c_ = heff_intEq_c_lent(v_t_24112, MK_INT(1LL), 2); heff_drop(v_t_24112); c_; })));
    heff_drop(v_rest_2423);
    heff_drop(v_t_2424);
    return v_ret_24bool;
  }
  case TAG_OCall: {
    V v_next_2440;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_next_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2427 = heff_field(v_after_243, 0);
        v_next_2440 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2427));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2428 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2428)) {
      case TAG_SLet: {
        V v_o_2431 = heff_field(v_st_2428, 1);
        V v_ru_24st_2428_24SLet = heff_take_reuse_n(v_st_2428, 2ULL, 2);
        v_next_2440 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2428_24SLet, v_o_2431));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2428, 0ULL, 1);
        v_next_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2434 = heff_field(v_st_2428, 1);
        V v_ru_24st_2428_24SSet = heff_take_reuse_n(v_st_2428, 2ULL, 2);
        v_next_2440 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2428_24SSet, v_o_2434));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2428, 0ULL, 3);
        v_next_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2438 = heff_field(v_st_2428, 0);
        heff_take_n(v_st_2428, 1ULL, 2);
        v_next_2440 = ({ V a_0 = v_v_2438; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2438); r_; });
        break;
      }
      default: heff_nomatch(v_st_2428);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2442 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2441; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2441); r_; });
    V v_t_2444;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2444 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2443 = heff_field(v_after_243, 0);
      v_t_2444 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2443, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_rest_2445 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2444));
    V v_t_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_next_2440; V r_ = (g_list_2efoldl_24f2029054136x351940068(a_0, a_1, a_2, a_3)); heff_drop(v_next_2440); r_; });
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_2446, MK_INT(1LL), 2) && ({ V v_t_24113 = (g_list_2efoldl_24f1663632568x709545076(MK_INT(1LL), MK_INT(0LL), v_x_240, v_rest_2445)); int c_ = heff_intEq_c_lent(v_t_24113, MK_INT(1LL), 2); heff_drop(v_t_24113); c_; })));
    heff_drop(v_rest_2445);
    heff_drop(v_t_2446);
    return v_ret_24bool;
  }
  case TAG_OApply: {
    V v_next_2462;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_next_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2449 = heff_field(v_after_243, 0);
        v_next_2462 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2449));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2450 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2450)) {
      case TAG_SLet: {
        V v_o_2453 = heff_field(v_st_2450, 1);
        V v_ru_24st_2450_24SLet = heff_take_reuse_n(v_st_2450, 2ULL, 2);
        v_next_2462 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2450_24SLet, v_o_2453));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2450, 0ULL, 1);
        v_next_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2456 = heff_field(v_st_2450, 1);
        V v_ru_24st_2450_24SSet = heff_take_reuse_n(v_st_2450, 2ULL, 2);
        v_next_2462 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2450_24SSet, v_o_2456));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2450, 0ULL, 3);
        v_next_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2460 = heff_field(v_st_2450, 0);
        heff_take_n(v_st_2450, 1ULL, 2);
        v_next_2462 = ({ V a_0 = v_v_2460; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2460); r_; });
        break;
      }
      default: heff_nomatch(v_st_2450);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2464 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2463; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2463); r_; });
    V v_t_2466;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2466 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2465 = heff_field(v_after_243, 0);
      v_t_2466 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2465, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_rest_2467 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2466));
    V v_t_2468 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_next_2462; V r_ = (g_list_2efoldl_24f2029054136x351940068(a_0, a_1, a_2, a_3)); heff_drop(v_next_2462); r_; });
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_2468, MK_INT(1LL), 2) && ({ V v_t_24114 = (g_list_2efoldl_24f1663632568x709545076(MK_INT(1LL), MK_INT(0LL), v_x_240, v_rest_2467)); int c_ = heff_intEq_c_lent(v_t_24114, MK_INT(1LL), 2); heff_drop(v_t_24114); c_; })));
    heff_drop(v_rest_2467);
    heff_drop(v_t_2468);
    return v_ret_24bool;
  }
  case TAG_OPrim: {
    V v_next_2484;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_next_2484 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2471 = heff_field(v_after_243, 0);
        v_next_2484 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2471));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2472 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2472)) {
      case TAG_SLet: {
        V v_o_2475 = heff_field(v_st_2472, 1);
        V v_ru_24st_2472_24SLet = heff_take_reuse_n(v_st_2472, 2ULL, 2);
        v_next_2484 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2472_24SLet, v_o_2475));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2472, 0ULL, 1);
        v_next_2484 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2478 = heff_field(v_st_2472, 1);
        V v_ru_24st_2472_24SSet = heff_take_reuse_n(v_st_2472, 2ULL, 2);
        v_next_2484 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2472_24SSet, v_o_2478));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2472, 0ULL, 3);
        v_next_2484 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2482 = heff_field(v_st_2472, 0);
        heff_take_n(v_st_2472, 1ULL, 2);
        v_next_2484 = ({ V a_0 = v_v_2482; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2482); r_; });
        break;
      }
      default: heff_nomatch(v_st_2472);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2485 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2486 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2485; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_2485); r_; });
    V v_t_2488;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2488 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2487 = heff_field(v_after_243, 0);
      v_t_2488 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2487, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_rest_2489 = (g_prelude_2e_2b_2b(v_t_2486, v_t_2488));
    V v_t_2490 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_next_2484; V r_ = (g_list_2efoldl_24f2029054136x351940068(a_0, a_1, a_2, a_3)); heff_drop(v_next_2484); r_; });
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_2490, MK_INT(1LL), 2) && ({ V v_t_24115 = (g_list_2efoldl_24f1663632568x709545076(MK_INT(1LL), MK_INT(0LL), v_x_240, v_rest_2489)); int c_ = heff_intEq_c_lent(v_t_24115, MK_INT(1LL), 2); heff_drop(v_t_24115); c_; })));
    heff_drop(v_rest_2489);
    heff_drop(v_t_2490);
    return v_ret_24bool;
  }
  case TAG_OAbandon: {
    V v_next_24104;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_next_24104 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_2491 = heff_field(v_after_243, 0);
        v_next_24104 = (g_heff_2ecompile_2eimperative_2efirstNamesTl(v_t_2491));
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2492 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2492)) {
      case TAG_SLet: {
        V v_o_2495 = heff_field(v_st_2492, 1);
        V v_ru_24st_2492_24SLet = heff_take_reuse_n(v_st_2492, 2ULL, 2);
        v_next_24104 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2492_24SLet, v_o_2495));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2492, 0ULL, 1);
        v_next_24104 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2498 = heff_field(v_st_2492, 1);
        V v_ru_24st_2492_24SSet = heff_take_reuse_n(v_st_2492, 2ULL, 2);
        v_next_24104 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2492_24SSet, v_o_2498));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2492, 0ULL, 3);
        v_next_24104 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_24102 = heff_field(v_st_2492, 0);
        heff_take_n(v_st_2492, 1ULL, 2);
        v_next_24104 = ({ V a_0 = v_v_24102; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_24102); r_; });
        break;
      }
      default: heff_nomatch(v_st_2492);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_24105 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_24106 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24105; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_24105); r_; });
    V v_t_24108;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_24108 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_24107 = heff_field(v_after_243, 0);
      v_t_24108 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_24107, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_rest_24109 = (g_prelude_2e_2b_2b(v_t_24106, v_t_24108));
    V v_t_24110 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_next_24104; V r_ = (g_list_2efoldl_24f2029054136x351940068(a_0, a_1, a_2, a_3)); heff_drop(v_next_24104); r_; });
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_24110, MK_INT(1LL), 2) && ({ V v_t_24116 = (g_list_2efoldl_24f1663632568x709545076(MK_INT(1LL), MK_INT(0LL), v_x_240, v_rest_24109)); int c_ = heff_intEq_c_lent(v_t_24116, MK_INT(1LL), 2); heff_drop(v_t_24116); c_; })));
    heff_drop(v_rest_24109);
    heff_drop(v_t_24110);
    return v_ret_24bool;
  }
  case TAG_OBool: {
    heff_drop(v_rest_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eemit_2einlinable_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2einlinable(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_str2, 0, "");
Clo g_heff_2ecompile_2eemit_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamed_entry, 4, 0};

V g_heff_2ecompile_2eemit_2enamed(V v_env_240, V v_ind_241, V v_base_242, V v_c_243) {
top: ;
  V v_c_244 = heff_dup(heff_rfield(v_c_243, 0));
  if (!heff_strEq_c_lent(v_c_244, ((V)&g_heff_2ecompile_2eemit_2enamed_str0), 2)) {
    V v_t_245 = ({ V a_0 = v_c_244; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemit_2eatomGo(a_0, a_1)); heff_drop(v_c_244); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_ind_241);
      heff_drop(v_base_242);
      heff_drop(v_t_245);
      return heff_rec_n(3, shape_js__pre__env, (V[]){heff_get_n(v_c_243, 0, 2), NTAG(TAG_Nil), v_env_240});
    } else {
      heff_drop(v_t_245);
      V v_x0_246 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_base_242), MK_INT(0LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_x0_246, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_246, heff_box_word(v_t_247)));
      V v_t_249 = ({ V a_0 = v_x0_246; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2enamed_str1); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
      V v_t_2411 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2410));
      V v_t_2412 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_240, v_base_242, v_t_2411, MK_INT(0LL)));
      return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_2412));
    }
  } else {
    heff_drop(v_c_244);
    V v_x0_2413 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_base_242), MK_INT(0LL)));
    int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_x0_2413, 0)) - ((int64_t)1ULL));
    V v_t_2415 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2413, heff_box_word(v_t_2414)));
    V v_t_2416 = ({ V a_0 = v_x0_2413; V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = ({ V a_0 = v_t_2416; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2enamed_str2); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2417));
    V v_t_2419 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_240, v_base_242, v_t_2418, MK_INT(0LL)));
    return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_2419));
  }
}
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamed(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str1, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str2, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str3, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str4, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str5, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str6, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str7, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str9, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str10, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str12, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str13, 14, "Uint8Array.of(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str14, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str16, 12, "Math.fround(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str17, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str18, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str20, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str21, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str24, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str25, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str26, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str27, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str29, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str30, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str31, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str32, 9, ", a: [] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str34, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str35, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str37, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str38, 6, ", a: [");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str39, 3, "] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str40, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str41, 2, ": ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str42, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str43, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str44, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str45, 2, " }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str47, 1, ")");
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry, 3, 0};

V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    heff_drop(v_ind_241);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_env_240, 4), v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_rec(v_env_240, 5);
        V v_c_247 = v_field_246;
        return v_c_247;
      } else {
        heff_drop(v_field_246);
        int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_x_243, 0)) - ((int64_t)1ULL));
        V v_t_249 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x_243, heff_box_word(v_t_248)));
        V v_t_2410 = ({ V a_0 = heff_dup(v_x_243); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_249); r_; });
        V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str0); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
        V v_d_2412 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2411));
        HeffT2 v_t_2413 = ({ V b_0 = heff_get_n(v_env_240, 1, 5); V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          V v_t_2417;
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            heff_drop(v_d_2412);
            V v_x_2416 = v_field_2415;
            v_t_2417 = v_x_2416;
          } else {
            heff_drop(v_field_2415);
            v_t_2417 = v_d_2412;
          }
          return heff_rec_n(2, shape_code__prec, (V[]){v_t_2417, MK_INT(3LL)});
        }
      }
    }
  }
  case TAG_SGlobal: {
    V v_g_2418 = heff_field(v_x4_242, 0);
    heff_drop(v_ind_241);
    HeffT2 v_t_2419 = ({ V b_0 = heff_get_n(v_env_240, 0, 5); V a_1 = v_g_2418; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_code_2426;
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_i_2422 = v_field_2421;
        V v_arity_2423 = heff_take_field(v_i_2422, 1);
        V v_js_2424 = heff_take_field(v_i_2422, 0);
        V v_lazy_2425 = heff_get_n(v_i_2422, 2, 4);
        if (heff_intLe_c(MK_INT(2LL), v_arity_2423)) {
          heff_drop(v_lazy_2425);
          v_code_2426 = heff_strAppend(v_js_2424, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str1));
        } else {
          if ((heff_dup(v_lazy_2425) == NTAG(TAG_True))) {
            heff_drop(v_lazy_2425);
            v_code_2426 = heff_strAppend(v_js_2424, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str2));
          } else {
            heff_drop(v_lazy_2425);
            v_code_2426 = v_js_2424;
          }
        }
      } else {
        heff_drop(v_field_2421);
        v_code_2426 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str3);
      }
    }
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2426, MK_INT(3LL)});
  }
  case TAG_SInt: {
    V v_i_2427 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_s_2428 = heff_intShow(heff_dup(v_i_2427));
    if (heff_strEq_c(heff_strSlice_lent(v_s_2428, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str4))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2428, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str5)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2428, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str6)), MK_INT(3LL)});
    }
  }
  case TAG_SFloat: {
    V v_x_2429 = heff_tget_v(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_s_2430 = heff_floatShow(v_x_2429);
    if (heff_strEq_c(heff_strSlice_lent(v_s_2430, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str7))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2430, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2430, MK_INT(3LL)});
    }
  }
  case TAG_SStr: {
    V v_s_2431 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2432 = (g_heff_2ecompile_2eemit_2equoteGo(v_s_2431, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str8)));
    V v_code_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str9), heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str10)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2433, MK_INT(3LL)});
  }
  case TAG_SBytes: {
    V v_s_2434 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_s_2434, 0)) - ((int64_t)1ULL));
    V v_x2_2436 = (g_list_2emap_24f1457339348x592422294(v_s_2434, MK_INT(0LL), heff_box_word(v_t_2435)));
    V v_t_2439;
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str12); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2436);
    }
    V v_code_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str13), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str14)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2440, MK_INT(3LL)});
  }
  case TAG_SFixed: {
    V v_w_2441 = heff_field(v_x4_242, 0);
    V v_n_2442 = heff_field(v_x4_242, 1);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    return (g_heff_2ecompile_2eemit_2efixedCode(v_w_2441, heff_dup(v_n_2442)));
  }
  case TAG_SFloat32: {
    V v_x_2443 = heff_tget_v(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2444 = heff_strAppend(heff_floatShow(v_x_2443), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str15));
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str16), v_t_2444), MK_INT(3LL)});
  }
  case TAG_SPrimFn: {
    V v_p_2445 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str17), heff_strAppend(heff_dup(v_p_2445), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str18)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2446, MK_INT(3LL)});
  }
  case TAG_SLam: {
    V v_xs_2447 = heff_field(v_x4_242, 0);
    V v_x42_2448 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_2448)) {
    case TAG_MkBlock: {
      V v_t_2449 = heff_field(v_x42_2448, 0);
      V v_t_2450 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_env_240, 23ULL, 5, shape_gs__names__used__self__inl, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_2451 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_2450});
      V v_rb_2452 = (g_list_2efoldl_24s2018454372x1607369768(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str19), MK_INT(0LL), v_t_2451, heff_dup(v_xs_2447)));
      V v_js_2453 = heff_take_field(v_rb_2452, 0);
      V v_env_2454 = heff_get_n(v_rb_2452, 1, 2);
      V v_x2_2455 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str20), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str21), v_js_2453));
      V v_t_2458;
      switch (heff_tag_of(v_x2_2455)) {
      case TAG_Nil: {
        v_t_2458 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str22);
        break;
      }
      case TAG_Cons: {
        V v_x_2456 = heff_field(v_x2_2455, 0);
        V v_xs_2457 = heff_field(v_x2_2455, 1);
        heff_take_n(v_x2_2455, 3ULL, 2);
        v_t_2458 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str23); V a_1 = v_x_2456; V a_2 = v_xs_2457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2457); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2455);
      }
      V v_t_2459 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(v_env_2454, v_ind_241, v_t_2449));
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2458, v_t_2459), MK_INT(0LL)});
    }
    default: return heff_nomatch(v_x42_2448);
    }
  }
  case TAG_STag: {
    V v_t_2460 = heff_field(v_x4_242, 0);
    V v_x42_2461 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_2461)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 5);
      heff_drop(v_ind_241);
      if (heff_strEq_c_lent(v_t_2460, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str24), 2)) {
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str25), MK_INT(3LL)});
      } else {
        if (heff_strEq_c_lent(v_t_2460, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str26), 2)) {
          return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str27), MK_INT(3LL)});
        } else {
          V v_t_2463 = (g_heff_2ecompile_2eemit_2equoteGo(v_t_2460, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str28)));
          V v_t_2464 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str29), heff_strAppend(v_t_2463, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str30)));
          V v_code_2465 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str31), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str32)));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2465, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_t_2468 = (g_heff_2ecompile_2eemit_2equoteGo(v_t_2460, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str33)));
      V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str34), heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str35)));
      V v_x2_2472 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_x42_2461)));
      V v_t_2475;
      switch (heff_tag_of(v_x2_2472)) {
      case TAG_Nil: {
        v_t_2475 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str36);
        break;
      }
      case TAG_Cons: {
        V v_x_2473 = heff_field(v_x2_2472, 0);
        V v_xs_2474 = heff_field(v_x2_2472, 1);
        heff_take_n(v_x2_2472, 3ULL, 2);
        v_t_2475 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str37); V a_1 = v_x_2473; V a_2 = v_xs_2474; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2474); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2472);
      }
      V v_t_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str38), heff_strAppend(v_t_2475, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str39)));
      V v_code_2477 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str40), heff_strAppend(v_t_2469, v_t_2476));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2477, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x42_2461);
    }
  }
  case TAG_SRec: {
    V v_fs_2478 = heff_field(v_x4_242, 0);
    V v_x2_2486 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_fs_2478)));
    V v_t_2489;
    switch (heff_tag_of(v_x2_2486)) {
    case TAG_Nil: {
      v_t_2489 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str42);
      break;
    }
    case TAG_Cons: {
      V v_x_2487 = heff_field(v_x2_2486, 0);
      V v_xs_2488 = heff_field(v_x2_2486, 1);
      heff_take_n(v_x2_2486, 3ULL, 2);
      v_t_2489 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str43); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2486);
    }
    V v_code_2490 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str44), heff_strAppend(v_t_2489, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str45)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2490, MK_INT(3LL)});
  }
  case TAG_SProj: {
    V v_v_2491 = heff_field(v_x4_242, 0);
    V v_l_2492 = heff_field(v_x4_242, 1);
    V v_c_2495 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_2491));
    V v_prec_2496 = heff_take_field(v_c_2495, 1);
    V v_code_2497 = heff_get_n(v_c_2495, 0, 2);
    V v_t_2498;
    if (heff_intLt_c(v_prec_2496, MK_INT(3LL))) {
      v_t_2498 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str46), heff_strAppend(v_code_2497, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str47)));
    } else {
      v_t_2498 = v_code_2497;
    }
    V v_t_2499 = (g_heff_2ecompile_2eemit_2eprojSuffix(heff_dup(v_l_2492)));
    V v_code_24100 = heff_strAppend(v_t_2498, v_t_2499);
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_24100, MK_INT(3LL)});
  }
  case TAG_SPrim: {
    V v_p_24101 = heff_field(v_x4_242, 0);
    V v_args_24102 = heff_field(v_x4_242, 1);
    return (g_heff_2ecompile_2eemit_2eprimVal_24s365469421x1470802584(v_env_240, v_ind_241, heff_dup(v_p_24101), heff_dup(v_args_24102)));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0(V self, V *args) {
  V v_a_2470 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_2470; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_2470); r_; });
  return heff_get_n(v_t_2471, 0, 2);
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1(V self, V *args) {
  V v_f_2480 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2480)) {
  case TAG_MkPair: {
    V v_l_2481 = heff_field(v_f_2480, 0);
    V v_v_2482 = heff_field(v_f_2480, 1);
    heff_take_n(v_f_2480, 3ULL, 2);
    V v_t_2483 = (g_heff_2ecompile_2eemit_2epropName(v_l_2481));
    V v_t_2484 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2482; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2482); r_; });
    V v_t_2485 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str41), heff_get_n(v_t_2484, 0, 2));
    return heff_strAppend(v_t_2483, v_t_2485);
  }
  default: return heff_nomatch(v_f_2480);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str4, 1, ")");
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(V v_env_240, V v_ind_241, V v_g_242, V v_args_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_env_240, 0), v_g_242));
  V v_t_2412;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_g_242);
      V v_i_247 = v_field_246;
      v_t_2412 = heff_get_n(v_i_247, 0, 4);
    } else {
      heff_drop(v_field_246);
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_g_242, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_g_242, heff_box_word(v_t_248)));
      V v_t_2410 = ({ V a_0 = v_g_242; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_249); r_; });
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str0); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      v_t_2412 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2411));
    }
  }
  V v_x2_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str2); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str3), heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str4)));
  return heff_strAppend(v_t_2412, v_t_2419);
}
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_2413; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_2413); r_; });
  return heff_get_n(v_t_2414, 0, 2);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str4, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str5, 1, ")");
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V v_env_240, V v_ind_241, V v_c_242, V v_args_243) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0, 2, 2, (V[]){v_env_240, v_ind_241}), v_c_242, v_args_243));
}
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0(V self, V *args) {
  V v_c2_244 = args[0];
  V v_a_245 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_prec_246 = heff_take_field(v_c2_244, 1);
  V v_code_247 = heff_get_n(v_c2_244, 0, 2);
  V v_t_248;
  if (heff_intLt_c(v_prec_246, MK_INT(3LL))) {
    v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str0), heff_strAppend(v_code_247, ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str1)));
  } else {
    v_t_248 = v_code_247;
  }
  V v_t_249 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_245; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_245); r_; });
  V v_t_2410 = heff_strAppend(heff_get_n(v_t_249, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str2));
  V v_c_2411 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str3), v_t_2410));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str4), heff_strAppend(v_c_2411, ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str5)));
  return heff_rec_n(2, shape_code__prec, (V[]){v_t_2412, MK_INT(3LL)});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str1, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str4, 4, "let ");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str5, 1, ";");
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SLet: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_o_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(heff_dup(v_env_240), heff_dup(v_ind_241), v_o_244));
    return (g_heff_2ecompile_2eemit_2eletStmt_24cpr(v_ind_241, v_t_245, heff_dup(v_x_243), v_env_240));
  }
  case TAG_SDecl: {
    V v_x_246 = heff_field(v_x4_242, 0);
    V v_x0_247 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_246), MK_INT(0LL)));
    int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_x0_247, 0)) - ((int64_t)1ULL));
    V v_t_249 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_247, heff_box_word(v_t_248)));
    V v_t_2410 = ({ V a_0 = v_x0_247; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str0); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2411));
    HeffT2 v_t_2413 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(v_env_240, heff_dup(v_x_246), v_t_2412, MK_INT(0LL)));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x2_2416 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str1)));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str3); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str4), heff_strAppend(v_field_2414, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str5)));
      V v_f_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, v_t_2420), NTAG(TAG_Nil)});
      return ((HeffT2){{v_f_2421, v_field_2415}});
    }
  }
  case TAG_SSet: {
    V v_x_2422 = heff_field(v_x4_242, 0);
    V v_o_2423 = heff_field(v_x4_242, 1);
    V v_t_2424 = (g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(heff_dup(v_env_240), heff_dup(v_ind_241), v_o_2423));
    return (g_heff_2ecompile_2eemit_2esetStmt_24cpr(v_ind_241, v_t_2424, heff_dup(v_x_2422), v_env_240));
  }
  case TAG_SIf: {
    V v_c_2425 = heff_field(v_x4_242, 0);
    V v_ts_2426 = heff_field(v_x4_242, 1);
    V v_fs_2427 = heff_field(v_x4_242, 2);
    V v_t_2428 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), heff_dup(v_c_2425)));
    V v_f_2433 = heff_tr(g_heff_2ecompile_2eemit_2eifLines(heff_dup(v_ind_241), v_t_2428, heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam0, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_ts_2426)}), heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam1, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_fs_2427)})));
    V v_t_2434 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), v_ind_241, heff_dup(v_c_2425)));
    V v_t_2435 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_t_2434); r_; });
    V v_f_2436 = ({ V a_0 = v_env_240; V a_1 = v_t_2435; V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, a_1)); heff_drop(v_t_2435); r_; });
    return ((HeffT2){{v_f_2433, v_f_2436}});
  }
  case TAG_SCase: {
    V v_v_2437 = heff_field(v_x4_242, 0);
    V v_arms_2438 = heff_field(v_x4_242, 1);
    V v_t_2439 = (g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(v_env_240, heff_dup(v_ind_241), heff_dup(v_v_2437)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(v_ind_241, heff_dup(v_arms_2438), v_t_2439);
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ts_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = ({ V a_0 = v_env_240; V a_1 = v_i_2429; V a_2 = v_ts_2426; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  return heff_get_n(v_t_2430, 0, 2);
}
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_fs_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = ({ V a_0 = v_env_240; V a_1 = v_i_2431; V a_2 = v_fs_2427; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  return heff_get_n(v_t_2432, 0, 2);
}

HeffT2 g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(V v_env_240, V v_ind_241, V v_x4_242, V v_after_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_env_240}});
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_rest_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_SLet: {
      V v_x_246 = heff_field(v_x41_244, 0);
      V v_o_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2eemit_2einlinable(v_x_246, v_o_247, heff_dup(v_rest_245), v_after_243));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_t_248);
        V v_c_249 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_o_247; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop(v_o_247); r_; });
        V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_env_240, 4), v_x_246, v_c_249));
        V v_env_2411 = ({ V rv_4 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_env_240, 15ULL, 5, shape_gs__names__used__self__inl, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        V t_0 = v_env_2411;
        V t_1 = v_ind_241;
        V t_2 = v_rest_245;
        V t_3 = v_after_243;
        v_env_240 = t_0;
        v_ind_241 = t_1;
        v_x4_242 = t_2;
        v_after_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_248);
        V v_t_2412 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_o_247; V r_ = (g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(a_0, a_1, a_2)); heff_drop(v_o_247); r_; });
        HeffT2 v_t_2413 = (g_heff_2ecompile_2eemit_2eletStmt_24cpr(heff_dup(v_ind_241), v_t_2412, v_x_246, v_env_240));
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          HeffT2 v_t_2416 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(v_field_2415, v_ind_241, v_rest_245, v_after_243));
          {
            V v_field_2417 = v_t_2416.f[0];
            V v_field_2418 = v_t_2416.f[1];
            V v_f_2419 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_242_24Cons, v_field_2414, v_field_2417));
            return ((HeffT2){{v_f_2419, v_field_2418}});
          }
        }
      }
    }
    case TAG_SDecl: {
      HeffT2 v_t_2421 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 1); r_; });
      {
        V v_field_2422 = v_t_2421.f[0];
        V v_field_2423 = v_t_2421.f[1];
        HeffT2 v_t_2424 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(v_field_2423, v_ind_241, v_rest_245, v_after_243));
        {
          V v_field_2425 = v_t_2424.f[0];
          V v_field_2426 = v_t_2424.f[1];
          V v_f_2427 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_242_24Cons, v_field_2422, v_field_2425));
          return ((HeffT2){{v_f_2427, v_field_2426}});
        }
      }
    }
    case TAG_SSet: {
      HeffT2 v_t_2430 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 2); r_; });
      {
        V v_field_2431 = v_t_2430.f[0];
        V v_field_2432 = v_t_2430.f[1];
        HeffT2 v_t_2433 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(v_field_2432, v_ind_241, v_rest_245, v_after_243));
        {
          V v_field_2434 = v_t_2433.f[0];
          V v_field_2435 = v_t_2433.f[1];
          V v_f_2436 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_242_24Cons, v_field_2431, v_field_2434));
          return ((HeffT2){{v_f_2436, v_field_2435}});
        }
      }
    }
    case TAG_SIf: {
      HeffT2 v_t_2440 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 3); r_; });
      {
        V v_field_2441 = v_t_2440.f[0];
        V v_field_2442 = v_t_2440.f[1];
        HeffT2 v_t_2443 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(v_field_2442, v_ind_241, v_rest_245, v_after_243));
        {
          V v_field_2444 = v_t_2443.f[0];
          V v_field_2445 = v_t_2443.f[1];
          V v_f_2446 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_242_24Cons, v_field_2441, v_field_2444));
          return ((HeffT2){{v_f_2446, v_field_2445}});
        }
      }
    }
    case TAG_SCase: {
      HeffT2 v_t_2449 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_x41_244; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_x41_244, 2); r_; });
      {
        V v_field_2450 = v_t_2449.f[0];
        V v_field_2451 = v_t_2449.f[1];
        HeffT2 v_t_2452 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(v_field_2451, v_ind_241, v_rest_245, v_after_243));
        {
          V v_field_2453 = v_t_2452.f[0];
          V v_field_2454 = v_t_2452.f[1];
          V v_f_2455 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_242_24Cons, v_field_2450, v_field_2453));
          return ((HeffT2){{v_f_2455, v_field_2454}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry, 4, 0};

V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V v_env_240, V v_ind_241, V v_x4_242, V v_after_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(v_env_240, v_ind_241, v_x4_242, v_after_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_rec_n(2, shape_lines__env, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36, 7, "return ");
Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V v_env_240, V v_ind_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 1); r_; });
    V v_t_249 = heff_strAppend(heff_get_n(v_t_248, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3));
    V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4), v_t_249));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    V v_g_2411 = heff_dup(heff_field(v_o_242, 0));
    V v_args_2412 = heff_dup(heff_field(v_o_242, 1));
    V v_t_2442;
    switch (heff_tag_of(v_args_2412)) {
    case TAG_Nil: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2413 = heff_dup(heff_field(v_args_2412, 0));
      V v_x12_2414 = heff_dup(heff_field(v_args_2412, 1));
      switch (heff_tag_of(v_x11_2413)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2427 = heff_field(v_x11_2413, 0);
        V v_x112_2428 = heff_field(v_x11_2413, 1);
        heff_take_n(v_x11_2413, 3ULL, 3);
        switch (heff_tag_of(v_x112_2428)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2414)) {
          case TAG_Nil: {
            v_t_2442 = heff_bool(heff_strEq_c_lent(v_t_2427, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5), 2));
            heff_drop(v_t_2427);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2414, 0ULL, 2);
            heff_drop(v_t_2427);
            v_t_2442 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2414);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2428, 0ULL, 2);
          heff_drop(v_x12_2414);
          heff_drop(v_t_2427);
          v_t_2442 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2428);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2413, 0ULL, 4);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2413);
      }
      break;
    }
    default: heff_nomatch(v_args_2412);
    }
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_g_2411);
      heff_drop(v_args_2412);
      heff_drop(v_t_2442);
      V v_x2_2443 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6)));
      V v_t_2446;
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_Nil: {
        v_t_2446 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_xs_2445 = heff_field(v_x2_2443, 1);
        heff_take_n(v_x2_2443, 3ULL, 2);
        v_t_2446 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2443);
      }
      V v_t_2447 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 2); r_; });
      V v_t_2448 = heff_strAppend(heff_get_n(v_t_2447, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9));
      V v_t_2449 = heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10), v_t_2448));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    } else {
      heff_drop_tag(v_o_242, 2);
      heff_drop(v_t_2442);
      V v_x2_2450 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11)));
      V v_t_2453;
      switch (heff_tag_of(v_x2_2450)) {
      case TAG_Nil: {
        v_t_2453 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2451 = heff_field(v_x2_2450, 0);
        V v_xs_2452 = heff_field(v_x2_2450, 1);
        heff_take_n(v_x2_2450, 3ULL, 2);
        v_t_2453 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2450);
      }
      V v_t_2454 = (g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(v_env_240, v_ind_241, v_g_2411, v_args_2412));
      V v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14), heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15)));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2453, v_t_2455), NTAG(TAG_Nil)});
    }
  }
  case TAG_OApply: {
    V v_f_2456 = heff_field(v_o_242, 0);
    V v_args_2457 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OApply = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2487;
    switch (heff_tag_of(v_args_2457)) {
    case TAG_Nil: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2458 = heff_dup(heff_field(v_args_2457, 0));
      V v_x12_2459 = heff_dup(heff_field(v_args_2457, 1));
      switch (heff_tag_of(v_x11_2458)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2458, 0ULL, 2);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2458, 0ULL, 1);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2458, 0ULL, 2);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2472 = heff_field(v_x11_2458, 0);
        V v_x112_2473 = heff_field(v_x11_2458, 1);
        heff_take_n(v_x11_2458, 3ULL, 3);
        switch (heff_tag_of(v_x112_2473)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2459)) {
          case TAG_Nil: {
            v_t_2487 = heff_bool(heff_strEq_c_lent(v_t_2472, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16), 2));
            heff_drop(v_t_2472);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2459, 0ULL, 2);
            heff_drop(v_t_2472);
            v_t_2487 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2459);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2473, 0ULL, 2);
          heff_drop(v_x12_2459);
          heff_drop(v_t_2472);
          v_t_2487 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2473);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2458, 0ULL, 2);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2458, 0ULL, 4);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2458, 0ULL, 2);
        heff_drop(v_x12_2459);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2458);
      }
      break;
    }
    default: heff_nomatch(v_args_2457);
    }
    if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
      heff_drop(v_args_2457);
      heff_drop(v_t_2487);
      V v_ac_2488 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_f_2456; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2456); r_; });
      V v_f_2489 = (g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17), MK_INT(3LL), v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18)));
      V v_t_2490 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_2489, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19), v_ac_2488));
      return (g_heff_2ecompile_2eemit_2ebounceGive_24tok2(v_ru_24o_242_24OApply, v_ind_241, v_f_2489, v_t_2490));
    } else {
      heff_drop(v_t_2487);
      switch (heff_tag_of(v_args_2457)) {
      case TAG_Nil: {
        V v_x2_2491 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20)));
        V v_t_2494;
        switch (heff_tag_of(v_x2_2491)) {
        case TAG_Nil: {
          v_t_2494 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21);
          break;
        }
        case TAG_Cons: {
          V v_x_2492 = heff_field(v_x2_2491, 0);
          V v_xs_2493 = heff_field(v_x2_2491, 1);
          heff_take_n(v_x2_2491, 3ULL, 2);
          v_t_2494 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22); V a_1 = v_x_2492; V a_2 = v_xs_2493; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2493); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2491);
        }
        V v_t_2495 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_f_2456; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2456); r_; });
        V v_t_2496 = heff_strAppend(heff_get_n(v_t_2495, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23));
        V v_t_2497 = heff_strAppend(v_t_2494, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24), v_t_2496));
        return heff_tag_at_n(v_ru_24o_242_24OApply, TAG_Cons, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
      }
      case TAG_Cons: {
        V v_x_2498 = heff_field(v_args_2457, 0);
        V v_rest_2499 = heff_field(v_args_2457, 1);
        heff_take_n(v_args_2457, 3ULL, 2);
        HeffT2 v_t_24100 = (g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(v_rest_2499, v_x_2498));
        {
          V v_field_24101 = v_t_24100.f[0];
          V v_field_24102 = v_t_24100.f[1];
          V v_ini_24103 = v_field_24101;
          V v_a_24104 = v_field_24102;
          V v_t_24105 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_f_2456; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2456); r_; });
          V v_fc_24106 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_t_24105; V a_3 = v_ini_24103; V r_ = (g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(a_0, a_1, a_2, a_3)); heff_drop(v_ini_24103); r_; });
          V v_ac_24107 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_a_24104; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_24104); r_; });
          V v_f_24108 = (g_heff_2ecompile_2eemit_2enamed(v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25), v_fc_24106));
          V v_t_24109 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_24108, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26), v_ac_24107));
          return (g_heff_2ecompile_2eemit_2ebounceGive_24tok2(v_ru_24o_242_24OApply, v_ind_241, v_f_24108, v_t_24109));
        }
      }
      default: return heff_nomatch(v_args_2457);
      }
    }
  }
  case TAG_OPrim: {
    V v_x2_24112 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27)));
    V v_t_24115;
    switch (heff_tag_of(v_x2_24112)) {
    case TAG_Nil: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28);
      break;
    }
    case TAG_Cons: {
      V v_x_24113 = heff_field(v_x2_24112, 0);
      V v_xs_24114 = heff_field(v_x2_24112, 1);
      heff_take_n(v_x2_24112, 3ULL, 2);
      v_t_24115 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29); V a_1 = v_x_24113; V a_2 = v_xs_24114; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24114); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24112);
    }
    V v_t_24116 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 2); r_; });
    V v_t_24117 = heff_strAppend(heff_get_n(v_t_24116, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30));
    V v_t_24118 = heff_strAppend(v_t_24115, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31), v_t_24117));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    V v_x2_24119 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32)));
    V v_t_24122;
    switch (heff_tag_of(v_x2_24119)) {
    case TAG_Nil: {
      v_t_24122 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33);
      break;
    }
    case TAG_Cons: {
      V v_x_24120 = heff_field(v_x2_24119, 0);
      V v_xs_24121 = heff_field(v_x2_24119, 1);
      heff_take_n(v_x2_24119, 3ULL, 2);
      v_t_24122 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34); V a_1 = v_x_24120; V a_2 = v_xs_24121; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24121); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24119);
    }
    V v_t_24123 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    V v_t_24124 = heff_strAppend(heff_get_n(v_t_24123, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35));
    V v_t_24125 = heff_strAppend(v_t_24122, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36), v_t_24124));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24125, NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_24126 = heff_field(v_o_242, 0);
    heff_take_n(v_o_242, 1ULL, 1);
    V v_t_24127 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(v_env_240, heff_dup(v_ind_241), v_c_24126));
    return (g_heff_2ecompile_2eemit_2ereturnCond(v_ind_241, v_t_24127));
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str2, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str4, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str5, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefFun_str6, 0, "");
Clo g_heff_2ecompile_2eemit_2edefFun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edefFun_entry, 4, 0};

V g_heff_2ecompile_2eemit_2edefFun(V v_key_240, V v_i_241, V v_t_242, V v_r_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemit_2eloops(v_t_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    HEFF_LAST return g_heff_2ecompile_2eemit_2elooped(v_key_240, v_i_241, v_t_242, v_r_243);
  } else {
    heff_drop(v_key_240);
    heff_drop(v_t_244);
    V v_t_245 = heff_take_field(v_r_243, 0);
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemit_2edefFun_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_t_245, 0);
      V v_xs_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edefFun_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_249 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(heff_get_n(v_r_243, 1, 2), MK_INT(0LL), v_t_242));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str2), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2edefFun_str3)));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str4), heff_strAppend(v_t_248, v_t_2410));
    V v_t_2412 = heff_strAppend(heff_get_n(v_i_241, 0, 4), v_t_2411);
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str5), v_t_2412), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefFun_str6), v_t_2413});
  }
}
V g_heff_2ecompile_2eemit_2edefFun_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2edefFun(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str1, 15, " = $lazy(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str2, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str5, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str6, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str7, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edefCodeOf_str8, 0, "");
Clo g_heff_2ecompile_2eemit_2edefCodeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edefCodeOf_entry, 5, 0};

V g_heff_2ecompile_2eemit_2edefCodeOf(V v_gs_240, V v_met_241, V v_key_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_DefFun: {
    V v_xs_245 = heff_field(v_x4_243, 0);
    V v_x42_246 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_246)) {
    case TAG_MkBlock: {
      V v_t_247 = heff_field(v_x42_246, 0);
      V v_t_248 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_std_2emap_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_std_2emap_2eempty_get())});
      V v_t_249 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_248});
      V v_r_2410 = (g_list_2efoldl_24s2018454372x1607369768(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str0), MK_INT(0LL), v_t_249, heff_dup(v_xs_245)));
      V v_t_2411 = (g_heff_2ecompile_2eemit_2edefFun(v_key_242, v_i_244, v_t_247, heff_dup(v_r_2410)));
      return heff_rec_n(2, shape_lines__params, (V[]){v_t_2411, heff_get_n(v_r_2410, 0, 2)});
    }
    default: return heff_nomatch(v_x42_246);
    }
  }
  case TAG_DefVal: {
    V v_x41_2412 = heff_field(v_x4_243, 0);
    heff_drop(v_key_242);
    switch (heff_tag_of(v_x41_2412)) {
    case TAG_MkBlock: {
      V v_t_2413 = heff_field(v_x41_2412, 0);
      V v_t_2414 = heff_take_field(v_i_244, 2);
      V v_t_2425;
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_std_2emap_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_std_2emap_2eempty_get())});
        V v_t_2416 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(v_t_2415, MK_INT(0LL), v_t_2413));
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str1), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str2)));
        V v_t_2418 = heff_strAppend(heff_get_n(v_i_244, 0, 4), v_t_2417);
        V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str3), v_t_2418), NTAG(TAG_Nil)});
        v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str4), v_t_2419});
      } else {
        heff_drop(v_t_2414);
        V v_t_2420 = heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_240, heff_dup(g_std_2emap_2eempty_get()), v_met_241, NTAG(TAG_Nothing), heff_dup(g_std_2emap_2eempty_get())});
        V v_t_2421 = (g_heff_2ecompile_2eemit_2eeagerCode(v_t_2420, v_t_2413));
        V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str5), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str6)));
        V v_t_2423 = heff_strAppend(heff_get_n(v_i_244, 0, 4), v_t_2422);
        V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str7), v_t_2423), NTAG(TAG_Nil)});
        v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefCodeOf_str8), v_t_2424});
      }
      return heff_rec_n(2, shape_lines__params, (V[]){v_t_2425, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x41_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemit_2edefCodeOf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2edefCodeOf(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str1, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str4, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUses_str5, 1, "(");
Clo g_heff_2ecompile_2eemit_2eprimUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUses_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimUses(V v_m_240, V v_part_241) {
top: ;
  switch (heff_tag_of(v_part_241)) {
  case TAG_PartVal: {
    V v_part1_242 = heff_field(v_part_241, 0);
    switch (heff_tag_of(v_part1_242)) {
    case TAG_SVar: {
      return v_m_240;
    }
    case TAG_SGlobal: {
      return v_m_240;
    }
    case TAG_SInt: {
      return v_m_240;
    }
    case TAG_SFloat: {
      return v_m_240;
    }
    case TAG_SStr: {
      return v_m_240;
    }
    case TAG_SBytes: {
      return v_m_240;
    }
    case TAG_SFixed: {
      return v_m_240;
    }
    case TAG_SFloat32: {
      return v_m_240;
    }
    case TAG_SPrimFn: {
      V v_p_2412 = heff_field(v_part1_242, 0);
      V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str0), heff_strAppend(heff_dup(v_p_2412), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str1)));
      return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_2413, NTAG(TAG_MkUnit)));
    }
    case TAG_SLam: {
      return v_m_240;
    }
    case TAG_STag: {
      return v_m_240;
    }
    case TAG_SRec: {
      return v_m_240;
    }
    case TAG_SProj: {
      return v_m_240;
    }
    case TAG_SPrim: {
      V v_p_2425 = heff_field(v_part1_242, 0);
      V v_args_2426 = heff_field(v_part1_242, 1);
      V v_t_2427 = (g_heff_2ecompile_2eemit_2ecallsHelper(v_p_2425, v_args_2426));
      if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
        heff_drop(v_t_2427);
        V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str2), heff_strAppend(heff_dup(v_p_2425), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str3)));
        return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_2428, NTAG(TAG_MkUnit)));
      } else {
        heff_drop(v_t_2427);
        return v_m_240;
      }
    }
    default: return heff_nomatch(v_part1_242);
    }
  }
  case TAG_PartOp: {
    V v_part1_2429 = heff_field(v_part_241, 0);
    switch (heff_tag_of(v_part1_2429)) {
    case TAG_OSimple: {
      return v_m_240;
    }
    case TAG_OCall: {
      return v_m_240;
    }
    case TAG_OApply: {
      return v_m_240;
    }
    case TAG_OPrim: {
      V v_p_2435 = heff_field(v_part1_2429, 0);
      V v_args_2436 = heff_field(v_part1_2429, 1);
      V v_t_2437 = (g_heff_2ecompile_2eemit_2ecallsHelper(v_p_2435, v_args_2436));
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_t_2437);
        V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str4), heff_strAppend(heff_dup(v_p_2435), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str5)));
        return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_t_2438, NTAG(TAG_MkUnit)));
      } else {
        heff_drop(v_t_2437);
        return v_m_240;
      }
    }
    case TAG_OAbandon: {
      return v_m_240;
    }
    case TAG_OBool: {
      return v_m_240;
    }
    default: return heff_nomatch(v_part1_2429);
    }
  }
  default: return heff_nomatch(v_part_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eprimUses(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsPick_str0, 0, "");
Clo g_heff_2ecompile_2eemit_2ejsPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsPick_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ejsPick(V v_shorts_240, V v_key_241, V v_s_242) {
top: ;
  V v_x_243 = (g_list_2efoldl_24f2082849937x387822498(MK_INT(1LL), MK_INT(0LL), v_s_242, v_shorts_240));
  if (heff_intLt_c(MK_INT(1LL), v_x_243)) {
    heff_drop(v_s_242);
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_key_241, 0)) - ((int64_t)1ULL));
    V v_t_245 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_key_241, heff_box_word(v_t_244)));
    V v_t_246 = ({ V a_0 = v_key_241; V a_1 = v_t_245; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2ejsPick_str0); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    return (g_heff_2ecompile_2eemit_2esafeFrom(v_t_247));
  } else {
    heff_drop(v_key_241);
    return v_s_242;
  }
}
V g_heff_2ecompile_2eemit_2ejsPick_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2ejsPick(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsNameOf_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsNameOf_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsNameOf_str2, 0, "");
Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsNameOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ejsNameOf(V v_shorts_240, V v_key_241) {
top: ;
  V v_xs_242 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str0); V a_1 = v_key_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str1), v_key_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x0_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_x0_246 = heff_dup(v_key_241);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_x0_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_x0_246, 0)) - ((int64_t)1ULL));
  V v_t_248 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_246, heff_box_word(v_t_247)));
  V v_t_249 = ({ V a_0 = v_x0_246; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str2); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2410));
  return (g_heff_2ecompile_2eemit_2ejsPick(v_shorts_240, v_key_241, v_t_2411));
}
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2ejsNameOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2ekeptCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ekeptCode_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ekeptCode(V v_v_240, V v_d_241, V v_c_242) {
top: ;
  V v_lines_243 = heff_take_field(v_c_242, 0);
  V v_params_244 = heff_get_n(v_c_242, 1, 2);
  V v_t_2413;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_x13_247 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_x13_247)) {
    case TAG_DefFun: {
      V v_x132_249 = heff_field(v_x13_247, 1);
      switch (heff_tag_of(v_x132_249)) {
      case TAG_MkBlock: {
        V v_t_2410 = heff_field(v_x132_249, 0);
        v_t_2413 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2410, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x132_249);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x131_2411 = heff_field(v_x13_247, 0);
      switch (heff_tag_of(v_x131_2411)) {
      case TAG_MkBlock: {
        V v_t_2412 = heff_field(v_x131_2411, 0);
        v_t_2413 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2412, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x131_2411);
      }
      break;
    }
    default: heff_nomatch(v_x13_247);
    }
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_t_2414 = (g_list_2emap_24s1585362143x1323498048(v_t_2413));
  V v_t_2415 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2414));
  V v_t_2424;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_x13_2418 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_x13_2418)) {
    case TAG_DefFun: {
      V v_x132_2420 = heff_field(v_x13_2418, 1);
      switch (heff_tag_of(v_x132_2420)) {
      case TAG_MkBlock: {
        V v_t_2421 = heff_field(v_x132_2420, 0);
        v_t_2424 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2421, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x132_2420);
      }
      break;
    }
    case TAG_DefVal: {
      V v_x131_2422 = heff_field(v_x13_2418, 0);
      switch (heff_tag_of(v_x131_2422)) {
      case TAG_MkBlock: {
        V v_t_2423 = heff_field(v_x131_2422, 0);
        v_t_2424 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2423, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x131_2422);
      }
      break;
    }
    default: heff_nomatch(v_x13_2418);
    }
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_m_2425 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s398854970x1533504811(a_0, a_1)); heff_drop(v_t_2424); r_; });
  V v_t_2426 = ({ V a_0 = v_m_2425; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2425); r_; });
  V v_t_2427 = (g_list_2emap_24s1937570095x2110149801(v_t_2426));
  return heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_v_240, v_lines_243, v_params_244, v_t_2415, v_t_2427});
}
V g_heff_2ecompile_2eemit_2ekeptCode_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ekeptCode(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemit_2ekeptOfDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ekeptOfDef_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ekeptOfDef(V v_p_240, V v_v_241, V v_d_242) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_d_242)) {
  case TAG_MkDef: {
    V v_k_243 = heff_field(v_d_242, 0);
    v_t_246 = heff_dup(v_k_243);
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_p_240, 0); V a_1 = v_t_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_i_2410 = v_field_249;
      V v_t_2411 = (g_heff_2ecompile_2eemit_2enamesIn(heff_dup(v_p_240), v_d_242));
      V v_t_2415;
      switch (heff_tag_of(v_d_242)) {
      case TAG_MkDef: {
        V v_k_2412 = heff_field(v_d_242, 0);
        v_t_2415 = heff_dup(v_k_2412);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      V v_t_2419;
      switch (heff_tag_of(v_d_242)) {
      case TAG_MkDef: {
        V v_b_2418 = heff_field(v_d_242, 2);
        v_t_2419 = heff_dup(v_b_2418);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      V v_t_2420 = ({ V a_0 = heff_get_n(v_p_240, 0, 1); V a_1 = v_t_2411; V a_2 = v_t_2415; V a_3 = v_t_2419; V a_4 = v_i_2410; V r_ = (g_heff_2ecompile_2eemit_2edefCodeOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2419); r_; });
      HEFF_LAST return g_heff_2ecompile_2eemit_2ekeptCode(v_v_241, v_d_242, v_t_2420);
    } else {
      heff_drop_rec(v_p_240, 1);
      heff_drop(v_field_249);
      return (g_heff_2ecompile_2eemit_2ekeptCode_24s1077118626x1059221246(v_v_241, v_d_242));
    }
  }
}
V g_heff_2ecompile_2eemit_2ekeptOfDef_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2ekeptOfDef(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eemit_2ejsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsAt_entry, 6, 0};

V g_heff_2ecompile_2eemit_2ejsAt(V v_p_240, V v_kept_241, V v_acc_242, V v_d_243, V v_own_244, V v_v_245) {
top: ;
  V v_entries_246 = heff_take_field(v_acc_242, 0);
  V v_fresh_247 = heff_get_n(v_acc_242, 1, 2);
  HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_kept_241, heff_rfield(v_d_243, 0)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_k_2411 = v_field_2410;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2411, 0)), heff_dup(v_v_245))) {
        heff_drop(v_p_240);
        heff_drop(v_own_244);
        heff_drop(v_v_245);
        V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_d_243, 0, 3), v_k_2411});
        return heff_rec_n(2, shape_entries__fresh, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_entries_246}), v_fresh_247});
      } else {
        heff_drop_rec(v_k_2411, 5);
        V v_key_2413 = heff_dup(heff_rfield(v_d_243, 0));
        V v_t_2414 = (g_heff_2ecompile_2elower_2ejsDef(v_d_243, v_own_244));
        V v_k_2415 = ({ V a_0 = v_p_240; V a_1 = v_v_245; V a_2 = v_t_2414; V r_ = (g_heff_2ecompile_2eemit_2ekeptOfDef(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_key_2413), heff_dup(v_k_2415)}), v_entries_246});
        V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_key_2413, v_k_2415}), v_fresh_247});
        return heff_rec_n(2, shape_entries__fresh, (V[]){v_t_2416, v_t_2417});
      }
    } else {
      heff_drop(v_field_2410);
      V v_key_2418 = heff_dup(heff_rfield(v_d_243, 0));
      V v_t_2419 = (g_heff_2ecompile_2elower_2ejsDef(v_d_243, v_own_244));
      V v_k_2420 = ({ V a_0 = v_p_240; V a_1 = v_v_245; V a_2 = v_t_2419; V r_ = (g_heff_2ecompile_2eemit_2ekeptOfDef(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
      V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_key_2418), heff_dup(v_k_2420)}), v_entries_246});
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_key_2418, v_k_2420}), v_fresh_247});
      return heff_rec_n(2, shape_entries__fresh, (V[]){v_t_2421, v_t_2422});
    }
  }
}
V g_heff_2ecompile_2eemit_2ejsAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ejsAt(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str1, 1, "\012");
V g_heff_2ecompile_2eemit_2eassembled_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eassembled_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eassembled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eassembled_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eassembled(V v_p_240, V v_es_241, V v_curried_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_241)));
  V v_code_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eassembled_lam0, 2, 2, (V[]){heff_dup(v_p_240), heff_dup(v_curried_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_241));
  V v_xs_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s25420611x1990549631(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_uses_2419 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2418; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2418); r_; });
  V v_xs_2420 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get());
  V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
  V v_helpers_2428 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eassembled_lam1, 2, 1, (V[]){v_uses_2419}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
  V v_x2_2429 = (g_prelude_2e_2b_2b(heff_dup(v_helpers_2428), heff_dup(v_code_2416)));
  V v_t_2432;
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    v_t_2432 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_xs_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str1); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2429);
  }
  V v_t_2433 = ({ V a_0 = v_t_2432; V r_ = (g_heff_2ecompile_2eemit_2eruntime(a_0)); heff_drop(v_t_2432); r_; });
  V v_t_2434 = (g_prelude_2e_2b_2b(v_helpers_2428, v_code_2416));
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2434));
  return heff_rec_n(2, shape_lines__globals, (V[]){v_t_2435, heff_get_n(v_p_240, 0, 1)});
}
V g_heff_2ecompile_2eemit_2eassembled_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2eassembled(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2eassembled_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_p_240 = heff_env(self)[0];
  V v_curried_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415;
  switch (heff_tag_of(v_x_245)) {
  case TAG_MkPair: {
    V v_key_246 = heff_field(v_x_245, 0);
    V v_k_247 = heff_field(v_x_245, 1);
    V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
    V v_lines_248 = heff_take_field(v_k_247, 1);
    V v_params_249 = heff_get_n(v_k_247, 2, 5);
    HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_p_240, 0, 1); V a_1 = v_key_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_i_2413 = v_field_2412;
        V v_t_2414 = ({ V a_0 = v_curried_242; V a_1 = v_key_246; V a_2 = v_i_2413; V a_3 = v_params_249; V r_ = (g_heff_2ecompile_2eemit_2ewrapper(a_0, a_1, a_2, a_3)); heff_drop(v_curried_242); heff_drop(v_key_246); r_; });
        v_t_2415 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x_245_24MkPair, v_lines_248, v_t_2414));
      } else {
        heff_drop(v_curried_242);
        heff_drop(v_key_246);
        heff_drop_cell(v_ru_24x_245_24MkPair, 2);
        heff_drop(v_params_249);
        heff_drop(v_field_2412);
        v_t_2415 = v_lines_248;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  return (g_prelude_2e_2b_2b(v_t_2415, v_acc_244));
}
V g_heff_2ecompile_2eemit_2eassembled_lam1(V self, V *args) {
  V v_acc_2422 = args[0];
  V v_x_2423 = args[1];
  V v_uses_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkPair: {
    V v_p_2424 = heff_field(v_x_2423, 0);
    V v_i_2425 = heff_field(v_x_2423, 1);
    V v_ru_24x_2423_24MkPair = heff_take_reuse_n(v_x_2423, 3ULL, 2);
    V v_t_2426 = (g_heff_2ecompile_2eemit_2euncurryGo(NTAG(TAG_Nil), heff_get_n(v_i_2425, 1, 2)));
    v_t_2427 = ({ V a_0 = v_ru_24x_2423_24MkPair; V a_1 = v_uses_2419; V a_2 = v_p_2424; V a_3 = v_t_2426; V r_ = (g_heff_2ecompile_2eemit_2eprimHelperU_24tok2(a_0, a_1, a_2, a_3)); heff_drop(v_uses_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  return (g_prelude_2e_2b_2b(v_t_2427, v_acc_2422));
}
V g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(V v_p_240, V v_defs_241, V v_roots_242, V v_kept_243) {
top: ;
  V v_t_244 = heff_rec_n(2, shape_entries__fresh, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_acc_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr_lam0, 2, 2, (V[]){heff_dup(v_p_240), heff_dup(v_kept_243)}), v_t_244, v_defs_241));
  V v_entries_2413 = heff_take_field(v_acc_2412, 0);
  V v_fresh_2414 = heff_get_n(v_acc_2412, 1, 2);
  V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_entries_2413)));
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_entries_2413));
  V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s963266017x1719814548(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_xs_2418 = (g_prelude_2e_2b_2b(v_t_2417, v_roots_242));
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2418; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2418); r_; });
  V v_f_2420 = ({ V a_0 = v_p_240; V a_1 = v_t_2415; V a_2 = v_t_2419; V r_ = (g_heff_2ecompile_2eemit_2eassembled(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  V v_f_2421 = v_fresh_2414;
  return ((HeffT2){{v_f_2420, v_f_2421}});
}
V g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_d_246 = args[1];
  V v_p_240 = heff_env(self)[0];
  V v_kept_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_own_247 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL), heff_dup(heff_rfield(v_d_246, 2))));
  V v_t_2410;
  switch (heff_tag_of(v_own_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_dup(heff_field(v_own_247, 0));
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_own_247);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemit_2ejsVer(heff_dup(v_p_240), heff_dup(heff_rfield(v_d_246, 0)), v_t_2410));
  return ({ V a_0 = v_p_240; V a_1 = v_kept_243; V a_2 = v_acc_245; V a_3 = v_d_246; V a_4 = v_own_247; V a_5 = v_t_2411; V r_ = (g_heff_2ecompile_2eemit_2ejsAt(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_kept_243); r_; });
}
Clo g_heff_2ecompile_2eemit_2eemitKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eemitKept_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eemitKept(V v_facts_240, V v_defs_241, V v_roots_242, V v_kept_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2eemitKept_24cpr(v_facts_240, v_defs_241, v_roots_242, v_kept_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_rec_n(2, shape_emitted__fresh, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2eemitKept(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str0, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str1, 44, "  $performer = (p, k) => perform(p, now(k));");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str2, 22, "  return $tr(entry());");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str3, 16, "  let depth = 0;");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str4, 129, "  const now = (k) => (x) => { x = $tr(x); if (depth > 1000) { depth = 0; later(() => $tr(k(x))); return; } depth++; $tr(k(x)); };");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str5, 34, "const $run = (entry, perform) => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str6, 92, "  const later = typeof setImmediate === \"function\" \? setImmediate : (f) => setTimeout(f, 0);");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str7, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str8, 15, "let $performer;");

static V g_heff_2ecompile_2eemit_2erunStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2erunStr_st;
static V g_heff_2ecompile_2eemit_2erunStr_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str6), v_t_242})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunStr_str7); V a_1 = ((V)&g_heff_2ecompile_2eemit_2erunStr_str8); V a_2 = v_t_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_243, 2); r_; });
}
V g_heff_2ecompile_2eemit_2erunStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2erunStr_st)) return g_heff_2ecompile_2eemit_2erunStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2erunStr_val, &g_heff_2ecompile_2eemit_2erunStr_st, g_heff_2ecompile_2eemit_2erunStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esumStr_str0, 77, "const $sum = (l, r) => (p, k) => p.$ === \"InL\" \? l(p.a[0], k) : r(p.a[0], k);");

static V g_heff_2ecompile_2eemit_2esumStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2esumStr_st;
static V g_heff_2ecompile_2eemit_2esumStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2esumStr_str0);
}
V g_heff_2ecompile_2eemit_2esumStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2esumStr_st)) return g_heff_2ecompile_2eemit_2esumStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2esumStr_val, &g_heff_2ecompile_2eemit_2esumStr_st, g_heff_2ecompile_2eemit_2esumStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eexportNameOf_str0, 13, "export const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eexportNameOf_str1, 1, " ");
Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eexportNameOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eexportNameOf(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2ecompile_2eemit_2eexportNameOf_str0))) {
    V v_t_241 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength_lent(v_l_240, 0));
    V v_j_242 = heff_strFind(((V)&g_heff_2ecompile_2eemit_2eexportNameOf_str1), v_t_241, MK_INT(0LL));
    if (heff_intLt_c_lent(v_j_242, MK_INT(0LL), 2)) {
      heff_drop(v_j_242);
      V v_t_243 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength_lent(v_l_240, 0));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
    } else {
      V v_t_244 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_intAdd(MK_INT(13LL), v_j_242));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    }
  } else {
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eexportNameOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str0, 3, "// ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str1, 12, ".provider.js");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str2, 11, " = (() => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str3, 8, "const $p");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str4, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str6, 13, "export const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str7, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str8, 7, "import ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str9, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str10, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str11, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str14, 9, "return { ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str15, 3, " };");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str16, 5, "})();");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str18, 1, "\012");
Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleProvider_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleProvider(V v_i_240, V v_p_241) {
top: ;
  V v_module_242 = heff_take_field(v_p_241, 0);
  V v_text_243 = heff_get_n(v_p_241, 1, 2);
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str0), heff_strAppend(v_module_242, ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str1)));
  V v_t_245 = heff_strAppend(heff_intShow(v_i_240), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str2));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str3), v_t_245), NTAG(TAG_Nil)});
  V v_s_247 = heff_dup(v_text_243);
  V v_t_248 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str4); V a_1 = v_s_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str5), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_247); r_; });
  V v_t_249 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(13LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str6); V a_3 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str7); V b_4 = MK_INT(13LL); V b_5 = MK_INT(0LL); V b_6 = MK_INT(7LL); V b_7 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str8); V a_8 = v_t_248; V r_ = (g_list_2emap_24f1952774010x636070089(b_0, b_1, b_2, a_3, b_4, b_5, b_6, b_7, a_8)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_6); heff_drop(b_7); r_; });
  V v_text_2410 = v_text_243;
  V v_t_2411 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str9); V a_1 = v_text_2410; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str10), v_text_2410, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_2410); r_; });
  V v_t_2412 = (g_list_2emap_24s732475005x1616712052(v_t_2411));
  V v_x2_2413 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str11); V a_3 = v_t_2412; V r_ = (g_list_2ekeepIf_24f428638463x2144521938(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2416;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_xs_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str13); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str14), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str15)));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str16), NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2418})));
  V v_x2_2420 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246}), v_t_2419));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str17);
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str18); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleProvider(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_cell_246;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleAll_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2eemit_2efindProv_24cpr(V v_md_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(v_md_240))) {
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_242}});
    } else {
      heff_drop_rec(v_p_242, 2);
      V t_0 = v_md_240;
      V t_1 = v_rest_243;
      v_md_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovsForGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprovsForGo(V v_available_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_available_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_md_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_md_242; V a_1 = heff_dup(v_available_240); HeffT2 r_ = (g_heff_2ecompile_2eemit_2efindProv_24cpr(a_0, a_1)); heff_drop(v_md_242); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_p_247 = v_field_246;
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_p_247, heff_hole()});
        V v_u_249 = (g_heff_2ecompile_2eemit_2eprovsForGo_24dps(v_available_240, v_rest_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_246);
        V t_0 = v_available_240;
        V t_1 = v_rest_243;
        v_available_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprovsForGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecompileProgramKept_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecompileProgramKept_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecompileProgramKept_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecompileProgramKept_str3, 1, ".");
Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileProgramKept_entry, 7, 0};

V g_heff_2ecompile_2eemit_2ecompileProgramKept(V v_available_240, V v_g_241, V v_key_242, V v_eff_243, V v_vers_244, V v_ks_245, V v_kept_246) {
top: ;
  V v_t_247 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_243));
  V v_xs_248 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ecompileProgramKept_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2ecompileProgramKept_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ecompile_2eemit_2ecompileProgramKept_str2); V a_5 = ((V)&g_heff_2ecompile_2eemit_2ecompileProgramKept_str3); V a_6 = v_t_247; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
  V v_t_249 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = (g_heff_2ecompile_2eemit_2eprovsForGo(v_available_240, v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2elower_2elowerProgramKept(v_g_241, heff_dup(v_key_242), v_vers_244, v_ks_245));
  return ({ V a_0 = v_t_2410; V a_1 = v_eff_243; V a_2 = v_key_242; V a_3 = v_kept_246; V a_4 = v_t_2411; V r_ = (g_heff_2ecompile_2eemit_2ekeptOutput(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_242); r_; });
}
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ecompile_2eemit_2ecompileProgramKept(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}