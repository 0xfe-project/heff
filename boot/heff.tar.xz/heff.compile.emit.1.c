// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_MkArmJs 44527
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_cond 9554921
#define LBL_decls 296817955
#define LBL_env 310119
#define LBL_globals 352931696
#define LBL_gs 10067
#define LBL_info 9732469
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_module 878357911
#define LBL_names 305943394
#define LBL_op 10312
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_prims 308293287
#define LBL_refs 9991943
#define LBL_self 10021907
#define LBL_stmts 311127493
#define LBL_text 10052084
#define LBL_used 10094724
#define LBL_val 326043
#define LBL_ver 326173
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_js__pre__env[] = {LBL_js, LBL_pre, LBL_env};
static uint32_t shape_lines__env[] = {LBL_lines, LBL_env};
static uint32_t shape_lines__globals[] = {LBL_lines, LBL_globals};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
V g_heff_2ecompile_2eemit_2eapplied(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eapplied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eapplied_clo;
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V, V, V, V);
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo;
V g_heff_2ecompile_2eemit_2earmBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_clo;
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2eassembled(V, V, V);
V g_heff_2ecompile_2eemit_2eassembled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eassembled_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(V, V, V);
V g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271_clo;
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ebounceGive_24tok2(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_24tok2_clo;
V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo;
V g_heff_2ecompile_2eemit_2ebundleProvider(V, V);
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo;
V g_heff_2ecompile_2eemit_2ecallCode(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecallCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallCode_clo;
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_clo;
HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
V g_heff_2ecompile_2eemit_2ecellVal(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecellVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellVal_clo;
V g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729(V, V, V);
V g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_clo;
V g_heff_2ecompile_2eemit_2econdCode(V);
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdCode_clo;
HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V);
V g_heff_2ecompile_2eemit_2econdGo(V, V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_clo;
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
HeffT2 g_heff_2ecompile_2eemit_2edefCodeOf_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2efindProv_24cpr(V, V);
V g_heff_2ecompile_2eemit_2efixedCode(V, V);
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efixedCode_clo;
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
V g_heff_2ecompile_2eemit_2ejk_get(void);
V g_heff_2ecompile_2eemit_2ekeptOfDef(V, V, V);
V g_heff_2ecompile_2eemit_2ekeptOfDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ekeptOfDef_clo;
HeffT2 g_heff_2ecompile_2eemit_2eletBound_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations(V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo;
V g_heff_2ecompile_2eemit_2enamed(V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_clo;
V g_heff_2ecompile_2eemit_2enamedAs(V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_clo;
V g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487(V, V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU(V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimRel_24cpr(V);
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_24dps_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereturnCond(V, V);
V g_heff_2ecompile_2eemit_2ereturnCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnCond_clo;
V g_heff_2ecompile_2eemit_2ereturnLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_clo;
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemit_2escrutOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_clo;
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
HeffT2 g_heff_2ecompile_2eemit_2esetStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo(V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esharedGo_clo;
V g_heff_2ecompile_2eemit_2estepOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_clo;
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo;
HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2euncurryGo(V, V);
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2euncurryGo_clo;
HeffT2 g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(V, V);
V g_heff_2ecompile_2eemit_2evalGo(V, V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_clo;
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eprims_2ejsPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimJs(V);
V g_heff_2ecompile_2eprims_2eprimJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimJs_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s2118756600x1920057229(V, V);
V g_list_2efoldl_24s2118756600x1920057229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2118756600x1920057229_clo;
V g_list_2efoldl_24s25420611x1990549631(V, V);
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25420611x1990549631_clo;
V g_list_2efoldl_24s398854970x1533504811(V, V);
V g_list_2efoldl_24s398854970x1533504811_entry(V self, V *a);
extern Clo g_list_2efoldl_24s398854970x1533504811_clo;
V g_list_2efoldl_24s509733942x1507005169(V, V, V, V);
V g_list_2efoldl_24s509733942x1507005169_entry(V self, V *a);
extern Clo g_list_2efoldl_24s509733942x1507005169_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1457339348x592422294(V, V, V);
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_clo;
V g_list_2emap_24f1952774010x636070089(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_clo;
V g_list_2emap_24s1325317589x1506218481(V, V, V);
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_clo;
V g_list_2emap_24s1455783996x1449538216(V);
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_clo;
V g_list_2emap_24s1585362143x1323498048(V);
V g_list_2emap_24s1585362143x1323498048_entry(V self, V *a);
extern Clo g_list_2emap_24s1585362143x1323498048_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;

HeffT2 g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(V v_x1_240, V v_y_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_y_241}});
  }
  case TAG_Cons: {
    V v_z_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(v_rest_243, v_z_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_ini_247 = v_field_245;
      V v_lst_248 = v_field_246;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_241, v_ini_247}), v_lst_248}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eemit_2ebindFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebindFrom_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ebindFrom(V v_env_240, V v_x_241, V v_base_242, V v_i_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(v_env_240, v_x_241, v_base_242, v_i_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_rec_n(2, shape_js__env, (V[]){v_field_245, v_field_246});
  }
}
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebindFrom(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str0, 4, "true");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str1, 5, "false");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str4, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str9, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str14, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str15, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str16, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str17, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str19, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str20, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str21, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str22, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str24, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str26, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str29, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str32, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str33, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str34, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str35, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str36, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str37, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str38, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str39, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str42, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str44, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str45, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str47, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdCode_24cpr_str48, 1, ")");

HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JTrue: {
    return ((HeffT2){{((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str0), MK_INT(4LL)}});
  }
  case TAG_JFalse: {
    return ((HeffT2){{((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str1), MK_INT(4LL)}});
  }
  case TAG_JRel: {
    V v_s_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{v_s_241, MK_INT(3LL)}});
  }
  case TAG_JNot: {
    V v_q_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_243 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_q_242));
    V v_t_246;
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      if (heff_intLt_c(v_field_245, MK_INT(4LL))) {
        v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str2), v_field_244), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str3));
      } else {
        v_t_246 = v_field_244;
      }
    }
    V v_f_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str4), v_t_246);
    return ((HeffT2){{v_f_247, MK_INT(4LL)}});
  }
  case TAG_JIf: {
    V v_c_248 = heff_field(v_x1_240, 0);
    V v_t_249 = heff_field(v_x1_240, 1);
    V v_x13_2410 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x13_2410)) {
    case TAG_JTrue: {
      switch (heff_tag_of(v_t_249)) {
      case TAG_JTrue: {
        HeffT2 v_t_2411 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_2414;
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          if (heff_intLt_c(v_field_2413, MK_INT(1LL))) {
            v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str5), v_field_2412), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str6));
          } else {
            v_t_2414 = v_field_2412;
          }
        }
        HeffT2 v_t_2415 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2418;
        {
          V v_field_2416 = v_t_2415.f[0];
          V v_field_2417 = v_t_2415.f[1];
          if (heff_intLt_c(v_field_2417, MK_INT(1LL))) {
            v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str7), v_field_2416), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str8));
          } else {
            v_t_2418 = v_field_2416;
          }
        }
        V v_f_2419 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str9)), v_t_2418);
        return ((HeffT2){{v_f_2419, MK_INT(1LL)}});
      }
      case TAG_JFalse: {
        HeffT2 v_t_2420 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2423;
        {
          V v_field_2421 = v_t_2420.f[0];
          V v_field_2422 = v_t_2420.f[1];
          if (heff_intLt_c(v_field_2422, MK_INT(2LL))) {
            v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str10), v_field_2421), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str11));
          } else {
            v_t_2423 = v_field_2421;
          }
        }
        HeffT2 v_t_2424 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2427;
        {
          V v_field_2425 = v_t_2424.f[0];
          V v_field_2426 = v_t_2424.f[1];
          if (heff_intLt_c(v_field_2426, MK_INT(2LL))) {
            v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str12), v_field_2425), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str13));
          } else {
            v_t_2427 = v_field_2425;
          }
        }
        V v_f_2428 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str14)), v_t_2427);
        return ((HeffT2){{v_f_2428, MK_INT(2LL)}});
      }
      default: {
        HeffT2 v_t_2429 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2432;
        {
          V v_field_2430 = v_t_2429.f[0];
          V v_field_2431 = v_t_2429.f[1];
          if (heff_intLt_c(v_field_2431, MK_INT(1LL))) {
            v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str15), v_field_2430), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str16));
          } else {
            v_t_2432 = v_field_2430;
          }
        }
        HeffT2 v_t_2433 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_2436;
        {
          V v_field_2434 = v_t_2433.f[0];
          V v_field_2435 = v_t_2433.f[1];
          if (heff_intLt_c(v_field_2435, MK_INT(1LL))) {
            v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str17), v_field_2434), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str18));
          } else {
            v_t_2436 = v_field_2434;
          }
        }
        V v_f_2437 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str19)), v_t_2436);
        return ((HeffT2){{v_f_2437, MK_INT(1LL)}});
      }
      }
    }
    case TAG_JFalse: {
      HeffT2 v_t_2438 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
      V v_t_2441;
      {
        V v_field_2439 = v_t_2438.f[0];
        V v_field_2440 = v_t_2438.f[1];
        if (heff_intLt_c(v_field_2440, MK_INT(2LL))) {
          v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str20), v_field_2439), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str21));
        } else {
          v_t_2441 = v_field_2439;
        }
      }
      HeffT2 v_t_2442 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
      V v_t_2445;
      {
        V v_field_2443 = v_t_2442.f[0];
        V v_field_2444 = v_t_2442.f[1];
        if (heff_intLt_c(v_field_2444, MK_INT(2LL))) {
          v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str22), v_field_2443), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str23));
        } else {
          v_t_2445 = v_field_2443;
        }
      }
      V v_f_2446 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str24)), v_t_2445);
      return ((HeffT2){{v_f_2446, MK_INT(2LL)}});
    }
    default: {
      switch (heff_tag_of(v_t_249)) {
      case TAG_JTrue: {
        HeffT2 v_t_2447 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_2450;
        {
          V v_field_2448 = v_t_2447.f[0];
          V v_field_2449 = v_t_2447.f[1];
          if (heff_intLt_c(v_field_2449, MK_INT(1LL))) {
            v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str25), v_field_2448), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str26));
          } else {
            v_t_2450 = v_field_2448;
          }
        }
        HeffT2 v_t_2451 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2454;
        {
          V v_field_2452 = v_t_2451.f[0];
          V v_field_2453 = v_t_2451.f[1];
          if (heff_intLt_c(v_field_2453, MK_INT(1LL))) {
            v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str27), v_field_2452), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str28));
          } else {
            v_t_2454 = v_field_2452;
          }
        }
        V v_f_2455 = heff_strAppend(heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str29)), v_t_2454);
        return ((HeffT2){{v_f_2455, MK_INT(1LL)}});
      }
      case TAG_JFalse: {
        HeffT2 v_t_2456 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(heff_tag_n(TAG_JNot, 1, (V[]){v_c_248})));
        V v_t_2459;
        {
          V v_field_2457 = v_t_2456.f[0];
          V v_field_2458 = v_t_2456.f[1];
          if (heff_intLt_c(v_field_2458, MK_INT(2LL))) {
            v_t_2459 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str30), v_field_2457), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str31));
          } else {
            v_t_2459 = v_field_2457;
          }
        }
        HeffT2 v_t_2460 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2463;
        {
          V v_field_2461 = v_t_2460.f[0];
          V v_field_2462 = v_t_2460.f[1];
          if (heff_intLt_c(v_field_2462, MK_INT(2LL))) {
            v_t_2463 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str32), v_field_2461), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str33));
          } else {
            v_t_2463 = v_field_2461;
          }
        }
        V v_f_2464 = heff_strAppend(heff_strAppend(v_t_2459, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str34)), v_t_2463);
        return ((HeffT2){{v_f_2464, MK_INT(2LL)}});
      }
      default: {
        HeffT2 v_t_2465 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_248));
        V v_t_2468;
        {
          V v_field_2466 = v_t_2465.f[0];
          V v_field_2467 = v_t_2465.f[1];
          if (heff_intLt_c(v_field_2467, MK_INT(1LL))) {
            v_t_2468 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str35), v_field_2466), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str36));
          } else {
            v_t_2468 = v_field_2466;
          }
        }
        HeffT2 v_t_2469 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_t_249));
        V v_t_2472;
        {
          V v_field_2470 = v_t_2469.f[0];
          V v_field_2471 = v_t_2469.f[1];
          if (heff_intLt_c(v_field_2471, MK_INT(0LL))) {
            v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str37), v_field_2470), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str38));
          } else {
            v_t_2472 = v_field_2470;
          }
        }
        V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str39)), v_t_2472);
        HeffT2 v_t_2474 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x13_2410));
        V v_t_2477;
        {
          V v_field_2475 = v_t_2474.f[0];
          V v_field_2476 = v_t_2474.f[1];
          if (heff_intLt_c(v_field_2476, MK_INT(0LL))) {
            v_t_2477 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str40), v_field_2475), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str41));
          } else {
            v_t_2477 = v_field_2475;
          }
        }
        V v_f_2478 = heff_strAppend(heff_strAppend(v_t_2473, ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str42)), v_t_2477);
        return ((HeffT2){{v_f_2478, MK_INT(0LL)}});
      }
      }
    }
    }
  }
  case TAG_JSeq: {
    V v_x_2479 = heff_field(v_x1_240, 0);
    V v_a_2480 = heff_field(v_x1_240, 1);
    V v_q_2481 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2482 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str43), v_x_2479), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str44));
    V v_t_2483 = heff_strAppend(heff_strAppend(v_t_2482, v_a_2480), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str45));
    HeffT2 v_t_2484 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_q_2481));
    V v_t_2487;
    {
      V v_field_2485 = v_t_2484.f[0];
      V v_field_2486 = v_t_2484.f[1];
      if (heff_intLt_c(v_field_2486, MK_INT(1LL))) {
        v_t_2487 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str46), v_field_2485), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str47));
      } else {
        v_t_2487 = v_field_2485;
      }
    }
    V v_f_2488 = heff_strAppend(heff_strAppend(v_t_2483, v_t_2487), ((V)&g_heff_2ecompile_2eemit_2econdCode_24cpr_str48));
    return ((HeffT2){{v_f_2488, MK_INT(4LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eemit_2econdCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2econdCode(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_code__prec, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str5, 4, "let ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eletDeclarations_str6, 1, ";");
Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eletDeclarations_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eletDeclarations(V v_ind_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x2_244 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_x2_248 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_241));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str4); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str5)), v_t_2411);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str6)), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eletDeclarations(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str0, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str1, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str2, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str3, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str4, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str5, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str6, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str8, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str9, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str12, 14, "Uint8Array.of(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str14, 12, "Math.fround(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str16, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str17, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str19, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str22, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str23, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str24, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str25, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str27, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str28, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str29, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str30, 9, ", a: [] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str32, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str33, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str34, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str35, 6, ", a: [");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str37, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str38, 3, "] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str41, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str42, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str43, 2, ": ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str44, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str45, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str46, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str47, 2, " }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str48, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str49, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str50, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str51, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str52, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str53, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str54, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str55, 1, "[");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_str56, 1, "]");
V g_heff_2ecompile_2eemit_2evalGo_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2evalGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2evalGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2evalGo_entry, 4, 0};

V g_heff_2ecompile_2eemit_2evalGo(V v_r_240, V v_env_241, V v_ind_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SVar: {
    V v_x_244 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop(v_ind_242);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_241, 4), v_x_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_rec(v_env_241, 5);
        V v_c_248 = v_field_247;
        return v_c_248;
      } else {
        heff_drop(v_field_247);
        V v_d_249 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_x_244)));
        HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_env_241, 1, 5); V a_1 = v_x_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          V v_t_2414;
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop(v_d_249);
            V v_x_2413 = v_field_2412;
            v_t_2414 = v_x_2413;
          } else {
            heff_drop(v_field_2412);
            v_t_2414 = v_d_249;
          }
          return heff_rec_n(2, shape_code__prec, (V[]){v_t_2414, MK_INT(3LL)});
        }
      }
    }
  }
  case TAG_SGlobal: {
    V v_g_2415 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop(v_ind_242);
    HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_env_241, 0, 5); V a_1 = v_g_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_code_2423;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_i_2419 = v_field_2418;
        V v_arity_2420 = heff_take_field(v_i_2419, 1);
        V v_js_2421 = heff_take_field(v_i_2419, 0);
        V v_lazy_2422 = heff_get_n(v_i_2419, 2, 4);
        if (heff_intLe_c(MK_INT(2LL), v_arity_2420)) {
          heff_drop(v_lazy_2422);
          v_code_2423 = heff_strAppend(v_js_2421, ((V)&g_heff_2ecompile_2eemit_2evalGo_str0));
        } else {
          if ((heff_dup(v_lazy_2422) == NTAG(TAG_True))) {
            heff_drop(v_lazy_2422);
            v_code_2423 = heff_strAppend(v_js_2421, ((V)&g_heff_2ecompile_2eemit_2evalGo_str1));
          } else {
            heff_drop(v_lazy_2422);
            v_code_2423 = v_js_2421;
          }
        }
      } else {
        heff_drop(v_field_2418);
        v_code_2423 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str2);
      }
    }
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2423, MK_INT(3LL)});
  }
  case TAG_SInt: {
    V v_i_2424 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    V v_s_2425 = heff_intShow(heff_dup(v_i_2424));
    if (heff_strEq_c(heff_strSlice_lent(v_s_2425, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2evalGo_str3))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2425, ((V)&g_heff_2ecompile_2eemit_2evalGo_str4)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2425, ((V)&g_heff_2ecompile_2eemit_2evalGo_str5)), MK_INT(3LL)});
    }
  }
  case TAG_SFloat: {
    V v_x_2426 = heff_tget_v(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    V v_s_2427 = heff_floatShow(v_x_2426);
    if (heff_strEq_c(heff_strSlice_lent(v_s_2427, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2evalGo_str6))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2427, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2427, MK_INT(3LL)});
    }
  }
  case TAG_SStr: {
    V v_s_2428 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    V v_t_2429 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_s_2428), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_str7)));
    V v_code_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str8), v_t_2429), ((V)&g_heff_2ecompile_2eemit_2evalGo_str9));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2430, MK_INT(3LL)});
  }
  case TAG_SBytes: {
    V v_s_2431 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_s_2431, 0)) - ((int64_t)1ULL));
    V v_x2_2433 = (g_list_2emap_24f1457339348x592422294(v_s_2431, MK_INT(0LL), heff_box_word(v_t_2432)));
    V v_t_2436;
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_Nil: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      V v_xs_2435 = heff_field(v_x2_2433, 1);
      heff_take_n(v_x2_2433, 3ULL, 2);
      v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str11); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2433);
    }
    V v_code_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str12), v_t_2436), ((V)&g_heff_2ecompile_2eemit_2evalGo_str13));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2437, MK_INT(3LL)});
  }
  case TAG_SFixed: {
    V v_w_2438 = heff_field(v_x4_243, 0);
    V v_n_2439 = heff_field(v_x4_243, 1);
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    return (g_heff_2ecompile_2eemit_2efixedCode(v_w_2438, heff_dup(v_n_2439)));
  }
  case TAG_SFloat32: {
    V v_x_2440 = heff_tget_v(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str14), heff_floatShow(v_x_2440));
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemit_2evalGo_str15)), MK_INT(3LL)});
  }
  case TAG_SPrimFn: {
    V v_p_2442 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    V v_t_2443 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_2442));
    V v_code_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str16), v_t_2443), ((V)&g_heff_2ecompile_2eemit_2evalGo_str17));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2444, MK_INT(3LL)});
  }
  case TAG_SLam: {
    V v_xs_2445 = heff_field(v_x4_243, 0);
    V v_x42_2446 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_2446)) {
    case TAG_MkBlock: {
      V v_t_2447 = heff_field(v_x42_2446, 0);
      V v_t_2448 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_env_241, 23ULL, 5, shape_gs__names__used__self__inl, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_2449 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_2448});
      V v_rb_2450 = (g_list_2efoldl_24s509733942x1507005169(MK_INT(0LL), MK_INT(0LL), v_t_2449, heff_dup(v_xs_2445)));
      V v_js_2451 = heff_take_field(v_rb_2450, 0);
      V v_env_2452 = heff_get_n(v_rb_2450, 1, 2);
      V v_x2_2453 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ecompile_2eemit_2evalGo_str18), ((V)&g_heff_2ecompile_2eemit_2evalGo_str19), v_js_2451));
      V v_t_2456;
      switch (heff_tag_of(v_x2_2453)) {
      case TAG_Nil: {
        v_t_2456 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_2454 = heff_field(v_x2_2453, 0);
        V v_xs_2455 = heff_field(v_x2_2453, 1);
        heff_take_n(v_x2_2453, 3ULL, 2);
        v_t_2456 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str21); V a_1 = v_x_2454; V a_2 = v_xs_2455; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2455); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2453);
      }
      V v_t_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 6), 3, (V[]){v_env_2452, v_ind_242, heff_dup(v_t_2447)}));
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2456, v_t_2457), MK_INT(0LL)});
    }
    default: return heff_nomatch(v_x42_2446);
    }
  }
  case TAG_STag: {
    V v_t_2458 = heff_field(v_x4_243, 0);
    V v_x42_2459 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_2459)) {
    case TAG_Nil: {
      heff_drop_rec(v_r_240, 6);
      heff_drop_rec(v_env_241, 5);
      heff_drop(v_ind_242);
      if (heff_strEq_c_lent(v_t_2458, ((V)&g_heff_2ecompile_2eemit_2evalGo_str22), 2)) {
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_str23), MK_INT(3LL)});
      } else {
        if (heff_strEq_c_lent(v_t_2458, ((V)&g_heff_2ecompile_2eemit_2evalGo_str24), 2)) {
          return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_str25), MK_INT(3LL)});
        } else {
          V v_t_2461 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_t_2458), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_str26)));
          V v_t_2462 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str27), v_t_2461), ((V)&g_heff_2ecompile_2eemit_2evalGo_str28));
          V v_code_2463 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str29), v_t_2462), ((V)&g_heff_2ecompile_2eemit_2evalGo_str30));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2463, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_t_2466 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_t_2458), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_str31)));
      V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str32), v_t_2466), ((V)&g_heff_2ecompile_2eemit_2evalGo_str33));
      V v_t_2468 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str34), v_t_2467), ((V)&g_heff_2ecompile_2eemit_2evalGo_str35));
      V v_x2_2471 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_lam0, 1, 3, (V[]){v_r_240, v_env_241, v_ind_242}), heff_dup(v_x42_2459)));
      V v_t_2474;
      switch (heff_tag_of(v_x2_2471)) {
      case TAG_Nil: {
        v_t_2474 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str36);
        break;
      }
      case TAG_Cons: {
        V v_x_2472 = heff_field(v_x2_2471, 0);
        V v_xs_2473 = heff_field(v_x2_2471, 1);
        heff_take_n(v_x2_2471, 3ULL, 2);
        v_t_2474 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str37); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2471);
      }
      V v_code_2475 = heff_strAppend(heff_strAppend(v_t_2468, v_t_2474), ((V)&g_heff_2ecompile_2eemit_2evalGo_str38));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2475, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x42_2459);
    }
  }
  case TAG_SRec: {
    V v_fs_2476 = heff_field(v_x4_243, 0);
    V v_x2_2484 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_lam1, 1, 3, (V[]){v_r_240, v_env_241, v_ind_242}), heff_dup(v_fs_2476)));
    V v_t_2487;
    switch (heff_tag_of(v_x2_2484)) {
    case TAG_Nil: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str44);
      break;
    }
    case TAG_Cons: {
      V v_x_2485 = heff_field(v_x2_2484, 0);
      V v_xs_2486 = heff_field(v_x2_2484, 1);
      heff_take_n(v_x2_2484, 3ULL, 2);
      v_t_2487 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_str45); V a_1 = v_x_2485; V a_2 = v_xs_2486; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2486); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2484);
    }
    V v_code_2488 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str46), v_t_2487), ((V)&g_heff_2ecompile_2eemit_2evalGo_str47));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2488, MK_INT(3LL)});
  }
  case TAG_SProj: {
    V v_v_2489 = heff_field(v_x4_243, 0);
    V v_l_2490 = heff_field(v_x4_243, 1);
    V v_c_2493 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, heff_dup(v_v_2489)}));
    V v_prec_2494 = heff_take_field(v_c_2493, 1);
    V v_code_2495 = heff_get_n(v_c_2493, 0, 2);
    V v_t_2496;
    if (heff_intLt_c(v_prec_2494, MK_INT(3LL))) {
      v_t_2496 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str48), v_code_2495), ((V)&g_heff_2ecompile_2eemit_2evalGo_str49));
    } else {
      v_t_2496 = v_code_2495;
    }
    V v_t_2499;
    if ((heff_strEq_c_lent(v_l_2490, ((V)&g_heff_2ecompile_2eemit_2evalGo_str50), 2) ? 0 : ({ V v_t_24107 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_l_2490))); int c_ = heff_strEq_c_lent(v_t_24107, v_l_2490, 0); heff_drop(v_t_24107); c_; }))) {
      v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str51), heff_dup(v_l_2490));
    } else {
      V v_t_2497 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_l_2490), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_str52)));
      V v_t_2498 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str53), v_t_2497), ((V)&g_heff_2ecompile_2eemit_2evalGo_str54));
      v_t_2499 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str55), v_t_2498), ((V)&g_heff_2ecompile_2eemit_2evalGo_str56));
    }
    V v_code_24100 = heff_strAppend(v_t_2496, v_t_2499);
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_24100, MK_INT(3LL)});
  }
  case TAG_SPrim: {
    V v_p_24101 = heff_field(v_x4_243, 0);
    V v_args_24102 = heff_field(v_x4_243, 1);
    V v_t_24103 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_24101, v_args_24102));
    if ((heff_dup(v_t_24103) == NTAG(TAG_True))) {
      heff_drop(v_t_24103);
      HEFF_LAST return g_heff_2ecompile_2eemit_2ecellVal(v_r_240, v_env_241, v_ind_242, v_args_24102);
    } else {
      heff_drop(v_t_24103);
      V v_t_24104 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 2, (V[]){v_env_241, v_ind_242}));
      V v_t_24105 = (g_list_2emap(v_t_24104, heff_dup(v_args_24102)));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_24101, v_t_24105));
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemit_2evalGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2evalGo(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemit_2evalGo_lam0(V self, V *args) {
  V v_a_2469 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_ind_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, v_a_2469}));
  return heff_get_n(v_t_2470, 0, 2);
}
V g_heff_2ecompile_2eemit_2evalGo_lam1(V self, V *args) {
  V v_f_2478 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_ind_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_f_2478)) {
  case TAG_MkPair: {
    V v_l_2479 = heff_field(v_f_2478, 0);
    V v_v_2480 = heff_field(v_f_2478, 1);
    heff_take_n(v_f_2478, 3ULL, 2);
    V v_t_2482;
    if ((heff_strEq_c_lent(v_l_2479, ((V)&g_heff_2ecompile_2eemit_2evalGo_str39), 2) ? 0 : ({ V v_t_24106 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_l_2479))); int c_ = heff_strEq_c_lent(v_t_24106, v_l_2479, 0); heff_drop(v_t_24106); c_; }))) {
      v_t_2482 = v_l_2479;
    } else {
      V v_t_2481 = (g_heff_2ecompile_2eemit_2equoteGo(v_l_2479, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_str40)));
      v_t_2482 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_str41), v_t_2481), ((V)&g_heff_2ecompile_2eemit_2evalGo_str42));
    }
    V v_t_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, v_v_2480}));
    return heff_strAppend(heff_strAppend(v_t_2482, ((V)&g_heff_2ecompile_2eemit_2evalGo_str43)), heff_get_n(v_t_2483, 0, 2));
  }
  default: return heff_nomatch(v_f_2478);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_str3, 1, ")");
V g_heff_2ecompile_2eemit_2ecallCode_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecallCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallCode_entry, 5, 0};

V g_heff_2ecompile_2eemit_2ecallCode(V v_r_240, V v_env_241, V v_ind_242, V v_g_243, V v_args_244) {
top: ;
  HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_241, 0), v_g_243));
  V v_t_249;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_g_243);
      V v_i_248 = v_field_247;
      v_t_249 = heff_get_n(v_i_248, 0, 4);
    } else {
      heff_drop(v_field_247);
      v_t_249 = (g_heff_2ecompile_2eemit_2esafe(v_g_243));
    }
  }
  V v_x2_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecallCode_lam0, 1, 3, (V[]){v_r_240, v_env_241, v_ind_242}), v_args_244));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2ecallCode_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecallCode_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2ecallCode_str2)), v_t_2415);
  return heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ecallCode_str3));
}
V g_heff_2ecompile_2eemit_2ecallCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecallCode(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eemit_2ecallCode_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_ind_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, v_a_2410}));
  return heff_get_n(v_t_2411, 0, 2);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_str4, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_str5, 1, ")");
V g_heff_2ecompile_2eemit_2eapplied_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eapplied_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eapplied_entry, 5, 0};

V g_heff_2ecompile_2eemit_2eapplied(V v_r_240, V v_env_241, V v_ind_242, V v_c_243, V v_args_244) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2eapplied_lam0, 2, 3, (V[]){v_r_240, v_env_241, v_ind_242}), v_c_243, v_args_244));
}
V g_heff_2ecompile_2eemit_2eapplied_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eemit_2eapplied(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eemit_2eapplied_lam0(V self, V *args) {
  V v_c2_245 = args[0];
  V v_a_246 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_ind_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_prec_247 = heff_take_field(v_c2_245, 1);
  V v_code_248 = heff_get_n(v_c2_245, 0, 2);
  V v_t_249;
  if (heff_intLt_c(v_prec_247, MK_INT(3LL))) {
    v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_str0), v_code_248), ((V)&g_heff_2ecompile_2eemit_2eapplied_str1));
  } else {
    v_t_249 = v_code_248;
  }
  V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, v_a_246}));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2eapplied_str2)), heff_get_n(v_t_2410, 0, 2));
  V v_c_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eapplied_str3));
  V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_str4), v_c_2412), ((V)&g_heff_2ecompile_2eemit_2eapplied_str5));
  return heff_rec_n(2, shape_code__prec, (V[]){v_t_2413, MK_INT(3LL)});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str2, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2econdGo_str9, 13, ".$ === \"True\"");
Clo g_heff_2ecompile_2eemit_2econdGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdGo_entry, 4, 0};

V g_heff_2ecompile_2eemit_2econdGo(V v_r_240, V v_env_241, V v_ind_242, V v_x4_243) {
top: ;
  V v_val_244 = heff_take_field(v_r_240, 0);
  V v_cond_245 = heff_take_field(v_r_240, 2);
  V v_op_246 = heff_get_n(v_r_240, 1, 6);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_PTrue: {
    heff_drop(v_env_241);
    heff_drop(v_ind_242);
    heff_drop(v_val_244);
    heff_drop(v_cond_245);
    heff_drop(v_op_246);
    return NTAG(TAG_JTrue);
  }
  case TAG_PFalse: {
    heff_drop(v_env_241);
    heff_drop(v_ind_242);
    heff_drop(v_val_244);
    heff_drop(v_cond_245);
    heff_drop(v_op_246);
    return NTAG(TAG_JFalse);
  }
  case TAG_PRel: {
    V v_p_247 = heff_field(v_x4_243, 0);
    V v_a_248 = heff_field(v_x4_243, 1);
    V v_b_249 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    heff_drop(v_cond_245);
    heff_drop(v_op_246);
    V v_c_2410 = heff_tr(heff_call(heff_dup(v_val_244), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), v_a_248}));
    V v_prec_2411 = heff_take_field(v_c_2410, 1);
    V v_code_2412 = heff_get_n(v_c_2410, 0, 2);
    V v_t_2413;
    if (heff_intLt_c(v_prec_2411, MK_INT(2LL))) {
      v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_str0), v_code_2412), ((V)&g_heff_2ecompile_2eemit_2econdGo_str1));
    } else {
      v_t_2413 = v_code_2412;
    }
    HeffT2 v_t_2414 = ({ V a_0 = v_p_247; HeffT2 r_ = (g_heff_2ecompile_2eemit_2eprimRel_24cpr(a_0)); heff_drop(v_p_247); r_; });
    V v_t_2418;
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        V v_x_2417 = v_field_2416;
        v_t_2418 = v_x_2417;
      } else {
        heff_drop(v_field_2416);
        v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2econdGo_str2);
      }
    }
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2econdGo_str3)), v_t_2418);
    V v_c_2420 = heff_tr(heff_call(v_val_244, 3, (V[]){v_env_241, v_ind_242, v_b_249}));
    V v_prec_2421 = heff_take_field(v_c_2420, 1);
    V v_code_2422 = heff_get_n(v_c_2420, 0, 2);
    V v_t_2423;
    if (heff_intLt_c(v_prec_2421, MK_INT(2LL))) {
      v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_str4), v_code_2422), ((V)&g_heff_2ecompile_2eemit_2econdGo_str5));
    } else {
      v_t_2423 = v_code_2422;
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2econdGo_str6)), v_t_2423);
    return heff_tag_n(TAG_JRel, 1, (V[]){v_t_2424});
  }
  case TAG_PBool: {
    V v_v_2425 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24PBool = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_cond_245);
    heff_drop(v_op_246);
    V v_c_2426 = heff_tr(heff_call(v_val_244, 3, (V[]){v_env_241, v_ind_242, v_v_2425}));
    V v_prec_2427 = heff_take_field(v_c_2426, 1);
    V v_code_2428 = heff_get_n(v_c_2426, 0, 2);
    V v_t_2429;
    if (heff_intLt_c(v_prec_2427, MK_INT(3LL))) {
      v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdGo_str7), v_code_2428), ((V)&g_heff_2ecompile_2eemit_2econdGo_str8));
    } else {
      v_t_2429 = v_code_2428;
    }
    return heff_tag_at_n(v_ru_24x4_243_24PBool, TAG_JRel, 1, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemit_2econdGo_str9))});
  }
  case TAG_PNot: {
    V v_c_2430 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24PNot = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_val_244);
    heff_drop(v_op_246);
    V v_t_2431 = heff_tr(heff_call(v_cond_245, 3, (V[]){v_env_241, v_ind_242, v_c_2430}));
    return heff_tag_at_n(v_ru_24x4_243_24PNot, TAG_JNot, 1, (V[]){v_t_2431});
  }
  case TAG_PIf: {
    V v_a_2432 = heff_field(v_x4_243, 0);
    V v_b_2433 = heff_field(v_x4_243, 1);
    V v_c_2434 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24PIf = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_val_244);
    heff_drop(v_op_246);
    V v_t_2435 = heff_tr(heff_call(heff_dup(v_cond_245), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), v_a_2432}));
    V v_t_2436 = heff_tr(heff_call(heff_dup(v_cond_245), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), v_b_2433}));
    V v_t_2437 = heff_tr(heff_call(v_cond_245, 3, (V[]){v_env_241, v_ind_242, v_c_2434}));
    return heff_tag_at_n(v_ru_24x4_243_24PIf, TAG_JIf, 3, (V[]){v_t_2435, v_t_2436, v_t_2437});
  }
  case TAG_PLet: {
    V v_x_2438 = heff_field(v_x4_243, 0);
    V v_o_2439 = heff_field(v_x4_243, 1);
    V v_c_2440 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24PLet = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_val_244);
    V v_t_2441 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2438), MK_INT(0LL)));
    V v_t_2442 = (g_heff_2ecompile_2eemit_2esafe(v_t_2441));
    HeffT2 v_t_2443 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(heff_dup(v_env_241), v_x_2438, v_t_2442, MK_INT(0LL)));
    {
      V v_field_2444 = v_t_2443.f[0];
      V v_field_2445 = v_t_2443.f[1];
      V v_t_2446 = heff_tr(heff_call(v_op_246, 3, (V[]){v_env_241, heff_dup(v_ind_242), v_o_2439}));
      V v_t_2447 = heff_tr(heff_call(v_cond_245, 3, (V[]){v_field_2445, v_ind_242, v_c_2440}));
      return heff_tag_at_n(v_ru_24x4_243_24PLet, TAG_JSeq, 3, (V[]){v_field_2444, heff_get_n(v_t_2446, 0, 2), v_t_2447});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemit_2econdGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2earmJs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2earmJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmJs_entry, 6, 0};

V g_heff_2ecompile_2eemit_2earmJs(V v_sc_240, V v_ind_241, V v_tag_242, V v_vs_243, V v_parts_244, V v_lines_245) {
top: ;
  V v_t_248 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eemit_2earmJs_lam0, 1, 1, (V[]){heff_dup(v_parts_244)}), v_vs_243));
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_vs_243);
    heff_drop(v_t_248);
    V v_t_249 = heff_tr(heff_call(v_lines_245, 2, (V[]){heff_get_n(v_sc_240, 1, 3), heff_intAdd(v_ind_241, MK_INT(2LL))}));
    return heff_tag_n(TAG_MkArmJs, 3, (V[]){v_tag_242, NTAG(TAG_True), v_t_249});
  } else {
    heff_drop(v_t_248);
    V v_t_2410 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), heff_dup(heff_rfield(v_sc_240, 1))});
    V v_t_2411 = (g_list_2efoldl_24s509733942x1507005169(MK_INT(0LL), MK_INT(0LL), v_t_2410, v_vs_243));
    return (g_heff_2ecompile_2eemit_2earmBound(v_sc_240, v_ind_241, v_tag_242, v_lines_245, v_t_2411));
  }
}
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eemit_2earmJs(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eemit_2earmJs_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_parts_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_v_246; V a_1 = v_parts_244; V r_ = (g_list_2eany_24s1877524499x1789047582(a_0, a_1)); heff_drop(v_v_246); heff_drop(v_parts_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str3, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str7, 8, "default:");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str9, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str10, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str11, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str12, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str14, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str16, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str17, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str20, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str21, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esharedGo_str24, 1, "}");
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemit_2esharedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esharedGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2esharedGo(V v_ind_240, V v_before_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    heff_drop(v_before_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArmJs: {
      V v_a2_246 = heff_dup(heff_field(v_a_243, 1));
      V v_ls_247 = heff_dup(heff_field(v_a_243, 2));
      if ((heff_dup(v_a2_246) == NTAG(TAG_True))) {
        heff_drop(v_a2_246);
        V v_t_2421 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), v_before_241));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_ls_247);
          heff_drop(v_t_2421);
          V t_0 = v_ind_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241});
          V t_2 = v_rest_244;
          v_ind_240 = t_0;
          v_before_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_t_2421);
          V v_f_2434 = heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam1, 1, 1, (V[]){heff_dup(v_ind_240)});
          V v_t_2448 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam2, 1, 1, (V[]){heff_dup(v_a_243)}), heff_dup(v_rest_244)));
          V v_t_2449 = heff_tr(heff_call(heff_dup(v_f_2434), 1, (V[]){heff_dup(v_a_243)}));
          V v_t_2450 = (g_list_2emap(v_f_2434, v_t_2448));
          V v_x2_2451 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str17)));
          V v_t_2454;
          switch (heff_tag_of(v_x2_2451)) {
          case TAG_Nil: {
            v_t_2454 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str18);
            break;
          }
          case TAG_Cons: {
            V v_x_2452 = heff_field(v_x2_2451, 0);
            V v_xs_2453 = heff_field(v_x2_2451, 1);
            heff_take_n(v_x2_2451, 3ULL, 2);
            v_t_2454 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str19); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2451);
          }
          V v_t_2455 = heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str20));
          V v_x2_2456 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str21)));
          V v_t_2459;
          switch (heff_tag_of(v_x2_2456)) {
          case TAG_Nil: {
            v_t_2459 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str22);
            break;
          }
          case TAG_Cons: {
            V v_x_2457 = heff_field(v_x2_2456, 0);
            V v_xs_2458 = heff_field(v_x2_2456, 1);
            heff_take_n(v_x2_2456, 3ULL, 2);
            v_t_2459 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str23); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2456);
          }
          V v_t_2460 = heff_strAppend(v_t_2459, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str24));
          V v_ys_2461 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
          V v_ys_2462 = (g_prelude_2e_2b_2b(v_ls_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_ys_2461})));
          return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2450}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_ys_2462})));
        }
      } else {
        heff_drop(v_a2_246);
        V v_t_2463 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
        return (g_prelude_2e_2b_2b(v_ls_247, v_t_2463));
      }
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esharedGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args) {
  V v_b_248 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2410 = heff_field(v_a_243, 1);
    V v_ls_2411 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    if ((heff_dup(v_x12_2410) == NTAG(TAG_True))) {
      heff_drop(v_x12_2410);
      V v_t_2414;
      switch (heff_tag_of(v_ls_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_ls_2411, 0);
        V v_xs_2413 = heff_field(v_ls_2411, 1);
        heff_take_n(v_ls_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2411);
      }
      switch (heff_tag_of(v_b_248)) {
      case TAG_MkArmJs: {
        V v_x12_2416 = heff_field(v_b_248, 1);
        V v_ls_2417 = heff_field(v_b_248, 2);
        heff_take_n(v_b_248, 6ULL, 3);
        if ((heff_dup(v_x12_2416) == NTAG(TAG_True))) {
          heff_drop(v_x12_2416);
          V v_k2_2420;
          switch (heff_tag_of(v_ls_2417)) {
          case TAG_Nil: {
            v_k2_2420 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str2);
            break;
          }
          case TAG_Cons: {
            V v_x_2418 = heff_field(v_ls_2417, 0);
            V v_xs_2419 = heff_field(v_ls_2417, 1);
            heff_take_n(v_ls_2417, 3ULL, 2);
            v_k2_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str3); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
            break;
          }
          default: heff_nomatch(v_ls_2417);
          }
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2414, v_k2_2420, 0));
          heff_drop(v_t_2414);
          heff_drop(v_k2_2420);
          return v_ret_24bool;
        } else {
          heff_drop(v_t_2414);
          heff_drop(v_x12_2416);
          heff_drop(v_ls_2417);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_b_248);
      }
    } else {
      heff_drop(v_b_248);
      heff_drop(v_x12_2410);
      heff_drop(v_ls_2411);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args) {
  V v_b_2422 = args[0];
  V v_ind_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2423 = (g_list_2ereplicate(heff_intAdd(v_ind_240, MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str4)));
  V v_t_2426;
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    v_t_2426 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_xs_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str6); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2423);
  }
  V v_tag_2430;
  switch (heff_tag_of(v_b_2422)) {
  case TAG_MkArmJs: {
    V v_t_2427 = heff_field(v_b_2422, 0);
    heff_take_n(v_b_2422, 1ULL, 3);
    v_tag_2430 = v_t_2427;
    break;
  }
  default: heff_nomatch(v_b_2422);
  }
  V v_t_2433;
  if (heff_strEq_c(heff_dup(v_tag_2430), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
    heff_drop(v_tag_2430);
    v_t_2433 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str7);
  } else {
    V v_t_2431 = (g_heff_2ecompile_2eemit_2equoteGo(v_tag_2430, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str8)));
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str9), v_t_2431), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str10));
    v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str11), v_t_2432), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str12));
  }
  return heff_strAppend(v_t_2426, v_t_2433);
}
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args) {
  V v_b_2435 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2437 = heff_field(v_a_243, 1);
    V v_ls_2438 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    if ((heff_dup(v_x12_2437) == NTAG(TAG_True))) {
      heff_drop(v_x12_2437);
      V v_t_2441;
      switch (heff_tag_of(v_ls_2438)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_ls_2438, 0);
        V v_xs_2440 = heff_field(v_ls_2438, 1);
        heff_take_n(v_ls_2438, 3ULL, 2);
        v_t_2441 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str14); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2438);
      }
      switch (heff_tag_of(v_b_2435)) {
      case TAG_MkArmJs: {
        V v_x12_2443 = heff_field(v_b_2435, 1);
        V v_ls_2444 = heff_field(v_b_2435, 2);
        heff_take_n(v_b_2435, 6ULL, 3);
        if ((heff_dup(v_x12_2443) == NTAG(TAG_True))) {
          heff_drop(v_x12_2443);
          V v_k2_2447;
          switch (heff_tag_of(v_ls_2444)) {
          case TAG_Nil: {
            v_k2_2447 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str15);
            break;
          }
          case TAG_Cons: {
            V v_x_2445 = heff_field(v_ls_2444, 0);
            V v_xs_2446 = heff_field(v_ls_2444, 1);
            heff_take_n(v_ls_2444, 3ULL, 2);
            v_k2_2447 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str16); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
            break;
          }
          default: heff_nomatch(v_ls_2444);
          }
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2441, v_k2_2447, 0));
          heff_drop(v_t_2441);
          heff_drop(v_k2_2447);
          return v_ret_24bool;
        } else {
          heff_drop(v_t_2441);
          heff_drop(v_x12_2443);
          heff_drop(v_ls_2444);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_b_2435);
      }
    } else {
      heff_drop(v_b_2435);
      heff_drop(v_x12_2437);
      heff_drop(v_ls_2438);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_a_243);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24cpr_str3, 4, "let ");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24cpr_str4, 1, ";");
V g_heff_2ecompile_2eemit_2estmtGo_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2estmtGo_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24cpr(V v_r_240, V v_env_241, V v_ind_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_SLet: {
    V v_x_244 = heff_field(v_x4_243, 0);
    V v_o_245 = heff_field(v_x4_243, 1);
    V v_st_246 = (g_heff_2ecompile_2eemit_2estepOf(v_r_240, heff_dup(v_env_241), heff_dup(v_ind_242), heff_dup(v_o_245)));
    V v_env_247 = (g_list_2efoldl_24s2118756600x1920057229(v_env_241, heff_rfield(v_st_246, 1)));
    V v_t_248 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_244), MK_INT(0LL)));
    V v_t_249 = (g_heff_2ecompile_2eemit_2esafe(v_t_248));
    V v_t_2410 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_247, heff_dup(v_x_244), v_t_249, MK_INT(0LL)));
    return (g_heff_2ecompile_2eemit_2eletBound_24cpr(v_ind_242, v_st_246, v_t_2410));
  }
  case TAG_SOnce: {
    V v_x_2411 = heff_field(v_x4_243, 0);
    V v_o_2412 = heff_field(v_x4_243, 1);
    V v_c_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 6), 3, (V[]){heff_dup(v_env_241), v_ind_242, heff_dup(v_o_2412)}));
    V v_t_2414 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_env_241, 4), heff_dup(v_x_2411), v_c_2413));
    V v_f_2415 = ({ V rv_4 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_env_241, 15ULL, 5, shape_gs__names__used__self__inl, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{NTAG(TAG_Nil), v_f_2415}});
  }
  case TAG_SDecl: {
    V v_x_2416 = heff_field(v_x4_243, 0);
    heff_drop_rec(v_r_240, 6);
    V v_t_2417 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2416), MK_INT(0LL)));
    V v_t_2418 = (g_heff_2ecompile_2eemit_2esafe(v_t_2417));
    HeffT2 v_t_2419 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(v_env_241, heff_dup(v_x_2416), v_t_2418, MK_INT(0LL)));
    {
      V v_field_2420 = v_t_2419.f[0];
      V v_field_2421 = v_t_2419.f[1];
      V v_x2_2422 = (g_list_2ereplicate(v_ind_242, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24cpr_str0)));
      V v_t_2425;
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24cpr_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_xs_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24cpr_str2); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2422);
      }
      V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24cpr_str3)), v_field_2420);
      V v_f_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24cpr_str4)), NTAG(TAG_Nil)});
      return ((HeffT2){{v_f_2427, v_field_2421}});
    }
  }
  case TAG_SSet: {
    V v_x_2428 = heff_field(v_x4_243, 0);
    V v_o_2429 = heff_field(v_x4_243, 1);
    V v_t_2430 = (g_heff_2ecompile_2eemit_2estepOf(v_r_240, heff_dup(v_env_241), heff_dup(v_ind_242), heff_dup(v_o_2429)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2esetStmt_24cpr(v_ind_242, v_t_2430, heff_dup(v_x_2428), v_env_241);
  }
  case TAG_SIf: {
    V v_c_2431 = heff_field(v_x4_243, 0);
    V v_ts_2432 = heff_field(v_x4_243, 1);
    V v_fs_2433 = heff_field(v_x4_243, 2);
    V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), heff_dup(v_c_2431)}));
    V v_f_2439 = heff_tr(g_heff_2ecompile_2eemit_2eifLines(heff_dup(v_ind_242), v_t_2434, heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24cpr_lam0, 1, 3, (V[]){heff_dup(v_r_240), heff_dup(v_env_241), heff_dup(v_ts_2432)}), heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24cpr_lam1, 1, 3, (V[]){heff_dup(v_r_240), heff_dup(v_env_241), heff_dup(v_fs_2433)})));
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 6), 3, (V[]){heff_dup(v_env_241), v_ind_242, heff_dup(v_c_2431)}));
    V v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_t_2440); r_; });
    V v_f_2442 = ({ V a_0 = v_env_241; V a_1 = v_t_2441; V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, a_1)); heff_drop(v_t_2441); r_; });
    return ((HeffT2){{v_f_2439, v_f_2442}});
  }
  case TAG_SCase: {
    V v_v_2443 = heff_field(v_x4_243, 0);
    V v_arms_2444 = heff_field(v_x4_243, 1);
    V v_t_2445 = (g_heff_2ecompile_2eemit_2escrutOf(heff_dup(v_r_240), v_env_241, heff_dup(v_ind_242), heff_dup(v_v_2443)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2ecaseStmt_24cpr(v_r_240, v_ind_242, heff_dup(v_arms_2444), v_t_2445);
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ecompile_2eemit_2estmtGo_24cpr_lam0(V self, V *args) {
  V v_i_2435 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_ts_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 5, 6), 4, (V[]){v_env_241, v_i_2435, v_ts_2432, NTAG(TAG_Nothing)}));
  return heff_get_n(v_t_2436, 0, 2);
}
V g_heff_2ecompile_2eemit_2estmtGo_24cpr_lam1(V self, V *args) {
  V v_i_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_fs_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 5, 6), 4, (V[]){v_env_241, v_i_2437, v_fs_2433, NTAG(TAG_Nothing)}));
  return heff_get_n(v_t_2438, 0, 2);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_str0, 0, "");
Clo g_heff_2ecompile_2eemit_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamed_entry, 4, 0};

V g_heff_2ecompile_2eemit_2enamed(V v_env_240, V v_ind_241, V v_base_242, V v_c_243) {
top: ;
  V v_c_244 = heff_dup(heff_rfield(v_c_243, 0));
  if (!heff_strEq_c_lent(v_c_244, ((V)&g_heff_2ecompile_2eemit_2enamed_str0), 2)) {
    V v_t_245 = ({ V a_0 = v_c_244; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemit_2eatomGo(a_0, a_1)); heff_drop(v_c_244); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_ind_241);
      heff_drop(v_base_242);
      heff_drop(v_t_245);
      return heff_rec_n(3, shape_js__pre__env, (V[]){heff_get_n(v_c_243, 0, 2), NTAG(TAG_Nil), v_env_240});
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_base_242), MK_INT(0LL)));
      V v_t_247 = (g_heff_2ecompile_2eemit_2esafe(v_t_246));
      V v_t_248 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_240, v_base_242, v_t_247, MK_INT(0LL)));
      return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_248));
    }
  } else {
    heff_drop(v_c_244);
    V v_t_249 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_base_242), MK_INT(0LL)));
    V v_t_2410 = (g_heff_2ecompile_2eemit_2esafe(v_t_249));
    V v_t_2411 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_240, v_base_242, v_t_2410, MK_INT(0LL)));
    return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_2411));
  }
}
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamed(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str5, 1, ";");
Clo g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_entry, 4, 0};

V g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487(V v_lit_240, V v_lit_241, V v_ind_242, V v_nb_243) {
top: ;
  V v_js_244 = heff_take_field(v_nb_243, 0);
  V v_env_245 = heff_get_n(v_nb_243, 1, 2);
  V v_x2_246 = (g_list_2ereplicate(v_ind_242, ((V)&g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str3)), heff_dup(v_js_244));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str4)), v_lit_240);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_str5)), NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__pre__env, (V[]){v_js_244, v_t_2412, v_env_245});
}
V g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str3, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str4, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str5, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str6, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str9, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str10, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str11, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str14, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str15, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str16, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str17, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str18, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str19, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str20, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str21, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str22, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str23, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str26, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str27, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str28, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str29, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str30, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str33, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str34, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str35, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str38, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_str39, 1, ";");
Clo g_heff_2ecompile_2eemit_2ereturnLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ereturnLines_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ereturnLines(V v_r_240, V v_env_241, V v_ind_242, V v_o_243) {
top: ;
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    V v_x2_245 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str0)));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 6), 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str3)), heff_get_n(v_t_249, 0, 2));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str4)), NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    V v_g_2411 = heff_dup(heff_field(v_o_243, 0));
    V v_args_2412 = heff_dup(heff_field(v_o_243, 1));
    V v_t_2442;
    switch (heff_tag_of(v_args_2412)) {
    case TAG_Nil: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2413 = heff_dup(heff_field(v_args_2412, 0));
      V v_x12_2414 = heff_dup(heff_field(v_args_2412, 1));
      switch (heff_tag_of(v_x11_2413)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2413, 0ULL, 1);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2427 = heff_field(v_x11_2413, 0);
        V v_x112_2428 = heff_field(v_x11_2413, 1);
        heff_take_n(v_x11_2413, 3ULL, 3);
        switch (heff_tag_of(v_x112_2428)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2414)) {
          case TAG_Nil: {
            v_t_2442 = heff_bool(heff_strEq_c_lent(v_t_2427, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str5), 2));
            heff_drop(v_t_2427);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2414, 0ULL, 2);
            heff_drop(v_t_2427);
            v_t_2442 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2414);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2428, 0ULL, 2);
          heff_drop(v_x12_2414);
          heff_drop(v_t_2427);
          v_t_2442 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2428);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2413, 0ULL, 4);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2413, 0ULL, 2);
        heff_drop(v_x12_2414);
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2413);
      }
      break;
    }
    default: heff_nomatch(v_args_2412);
    }
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_g_2411);
      heff_drop(v_args_2412);
      heff_drop(v_t_2442);
      V v_x2_2443 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str6)));
      V v_t_2446;
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_Nil: {
        v_t_2446 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_xs_2445 = heff_field(v_x2_2443, 1);
        heff_take_n(v_x2_2443, 3ULL, 2);
        v_t_2446 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str8); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2443);
      }
      V v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 6), 3, (V[]){v_env_241, v_ind_242, v_o_243}));
      V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str9)), heff_get_n(v_t_2447, 0, 2));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str10)), NTAG(TAG_Nil)});
    } else {
      heff_drop_tag(v_o_243, 2);
      heff_drop(v_t_2442);
      V v_x2_2449 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str11)));
      V v_t_2452;
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_Nil: {
        v_t_2452 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_xs_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        v_t_2452 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str13); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2449);
      }
      V v_t_2453 = (g_heff_2ecompile_2eemit_2ecallCode(v_r_240, v_env_241, v_ind_242, v_g_2411, v_args_2412));
      V v_t_2454 = heff_strAppend(heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str14)), v_t_2453);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str15)), NTAG(TAG_Nil)});
    }
  }
  case TAG_OApply: {
    V v_f_2455 = heff_field(v_o_243, 0);
    V v_args_2456 = heff_field(v_o_243, 1);
    V v_ru_24o_243_24OApply = heff_take_reuse_n(v_o_243, 3ULL, 2);
    V v_t_2486;
    switch (heff_tag_of(v_args_2456)) {
    case TAG_Nil: {
      v_t_2486 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2457 = heff_dup(heff_field(v_args_2456, 0));
      V v_x12_2458 = heff_dup(heff_field(v_args_2456, 1));
      switch (heff_tag_of(v_x11_2457)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2457, 0ULL, 2);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2457, 0ULL, 1);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2457, 0ULL, 2);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2471 = heff_field(v_x11_2457, 0);
        V v_x112_2472 = heff_field(v_x11_2457, 1);
        heff_take_n(v_x11_2457, 3ULL, 3);
        switch (heff_tag_of(v_x112_2472)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2458)) {
          case TAG_Nil: {
            v_t_2486 = heff_bool(heff_strEq_c_lent(v_t_2471, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str16), 2));
            heff_drop(v_t_2471);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2458, 0ULL, 2);
            heff_drop(v_t_2471);
            v_t_2486 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2458);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2472, 0ULL, 2);
          heff_drop(v_x12_2458);
          heff_drop(v_t_2471);
          v_t_2486 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2472);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2457, 0ULL, 2);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2457, 0ULL, 4);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2457, 0ULL, 2);
        heff_drop(v_x12_2458);
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2457);
      }
      break;
    }
    default: heff_nomatch(v_args_2456);
    }
    if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
      heff_drop(v_args_2456);
      heff_drop(v_t_2486);
      V v_ac_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), v_f_2455}));
      V v_t_2488 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str17); V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemit_2eatomGo(b_0, a_1)); heff_drop(b_0); r_; });
      V v_f_2492;
      if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
        heff_drop(v_t_2488);
        v_f_2492 = heff_rec_n(3, shape_js__pre__env, (V[]){((V)&g_heff_2ecompile_2eemit_2ereturnLines_str18), NTAG(TAG_Nil), v_env_241});
      } else {
        heff_drop(v_t_2488);
        V v_t_2489 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2ereturnLines_str19), MK_INT(0LL)));
        V v_t_2490 = (g_heff_2ecompile_2eemit_2esafe(v_t_2489));
        V v_t_2491 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_241, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str20), v_t_2490, MK_INT(0LL)));
        v_f_2492 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str21); V b_1 = MK_INT(3LL); V a_2 = heff_dup(v_ind_242); V a_3 = v_t_2491; V r_ = (g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
      }
      V v_t_2493 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_2492, 2)), heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str22), v_ac_2487));
      HEFF_LAST return g_heff_2ecompile_2eemit_2ebounceGive_24tok2(v_ru_24o_243_24OApply, v_ind_242, v_f_2492, v_t_2493);
    } else {
      heff_drop(v_t_2486);
      switch (heff_tag_of(v_args_2456)) {
      case TAG_Nil: {
        V v_x2_2494 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str23)));
        V v_t_2497;
        switch (heff_tag_of(v_x2_2494)) {
        case TAG_Nil: {
          v_t_2497 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str24);
          break;
        }
        case TAG_Cons: {
          V v_x_2495 = heff_field(v_x2_2494, 0);
          V v_xs_2496 = heff_field(v_x2_2494, 1);
          heff_take_n(v_x2_2494, 3ULL, 2);
          v_t_2497 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str25); V a_1 = v_x_2495; V a_2 = v_xs_2496; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2496); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2494);
        }
        V v_t_2498 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, v_f_2455}));
        V v_t_2499 = heff_strAppend(heff_strAppend(v_t_2497, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str26)), heff_get_n(v_t_2498, 0, 2));
        return heff_tag_at_n(v_ru_24o_243_24OApply, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2499, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str27)), NTAG(TAG_Nil)});
      }
      case TAG_Cons: {
        V v_x_24100 = heff_field(v_args_2456, 0);
        V v_rest_24101 = heff_field(v_args_2456, 1);
        heff_take_n(v_args_2456, 3ULL, 2);
        HeffT2 v_t_24102 = (g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(v_rest_24101, v_x_24100));
        {
          V v_field_24103 = v_t_24102.f[0];
          V v_field_24104 = v_t_24102.f[1];
          V v_ini_24105 = v_field_24103;
          V v_a_24106 = v_field_24104;
          V v_t_24107 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), v_f_2455}));
          V v_fc_24108 = ({ V a_0 = heff_dup(v_r_240); V a_1 = heff_dup(v_env_241); V a_2 = heff_dup(v_ind_242); V a_3 = v_t_24107; V a_4 = v_ini_24105; V r_ = (g_heff_2ecompile_2eemit_2eapplied(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ini_24105); r_; });
          V v_ac_24109 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), v_a_24106}));
          V v_f_24110 = (g_heff_2ecompile_2eemit_2enamed(v_env_241, heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str28), v_fc_24108));
          V v_t_24111 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_24110, 2)), heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str29), v_ac_24109));
          HEFF_LAST return g_heff_2ecompile_2eemit_2ebounceGive_24tok2(v_ru_24o_243_24OApply, v_ind_242, v_f_24110, v_t_24111);
        }
      }
      default: return heff_nomatch(v_args_2456);
      }
    }
  }
  case TAG_OPrim: {
    V v_x2_24114 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str30)));
    V v_t_24117;
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_Nil: {
      v_t_24117 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_xs_24116 = heff_field(v_x2_24114, 1);
      heff_take_n(v_x2_24114, 3ULL, 2);
      v_t_24117 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str32); V a_1 = v_x_24115; V a_2 = v_xs_24116; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24116); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24114);
    }
    V v_t_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 6), 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    V v_t_24119 = heff_strAppend(heff_strAppend(v_t_24117, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str33)), heff_get_n(v_t_24118, 0, 2));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24119, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str34)), NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    V v_x2_24120 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str35)));
    V v_t_24123;
    switch (heff_tag_of(v_x2_24120)) {
    case TAG_Nil: {
      v_t_24123 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str36);
      break;
    }
    case TAG_Cons: {
      V v_x_24121 = heff_field(v_x2_24120, 0);
      V v_xs_24122 = heff_field(v_x2_24120, 1);
      heff_take_n(v_x2_24120, 3ULL, 2);
      v_t_24123 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str37); V a_1 = v_x_24121; V a_2 = v_xs_24122; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24122); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24120);
    }
    V v_t_24124 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 6), 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    V v_t_24125 = heff_strAppend(heff_strAppend(v_t_24123, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str38)), heff_get_n(v_t_24124, 0, 2));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24125, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_str39)), NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_24126 = heff_field(v_o_243, 0);
    heff_take_n(v_o_243, 1ULL, 1);
    V v_t_24127 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 6), 3, (V[]){v_env_241, heff_dup(v_ind_242), v_c_24126}));
    return (g_heff_2ecompile_2eemit_2ereturnCond(v_ind_242, v_t_24127));
  }
  default: return heff_nomatch(v_o_243);
  }
}
V g_heff_2ecompile_2eemit_2ereturnLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ereturnLines(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str0, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str1, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str2, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str3, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str4, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str7, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str8, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str9, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str10, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str11, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str12, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str13, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str14, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str15, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str16, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str17, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str18, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str19, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str20, 9, "undefined");
Clo g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729(V v_env_240, V v_ind_241, V v_args_242) {
top: ;
  switch (heff_tag_of(v_args_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str0), MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_args_242, 0);
    V v_args2_244 = heff_field(v_args_242, 1);
    switch (heff_tag_of(v_args2_244)) {
    case TAG_Nil: {
      heff_drop(v_env_240);
      heff_drop(v_ind_241);
      return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str1), MK_INT(3LL)});
    }
    case TAG_Cons: {
      V v_args21_245 = heff_field(v_args2_244, 0);
      V v_args22_246 = heff_field(v_args2_244, 1);
      switch (heff_tag_of(v_args21_245)) {
      case TAG_SVar: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str2), MK_INT(3LL)});
      }
      case TAG_SGlobal: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str3), MK_INT(3LL)});
      }
      case TAG_SInt: {
        V v_k_249 = heff_field(v_args21_245, 0);
        switch (heff_tag_of(v_args22_246)) {
        case TAG_Nil: {
          heff_drop(v_env_240);
          heff_drop(v_ind_241);
          return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str4), MK_INT(3LL)});
        }
        case TAG_Cons: {
          V v_v_2410 = heff_field(v_args22_246, 0);
          V v_args222_2411 = heff_field(v_args22_246, 1);
          switch (heff_tag_of(v_args222_2411)) {
          case TAG_Nil: {
            V v_c_2412 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(heff_dup(v_env_240), heff_dup(v_ind_241), v_d_243));
            V v_prec_2413 = heff_take_field(v_c_2412, 1);
            V v_code_2414 = heff_get_n(v_c_2412, 0, 2);
            V v_t_2415;
            if (heff_intLt_c(v_prec_2413, MK_INT(3LL))) {
              v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str5), v_code_2414), ((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str6));
            } else {
              v_t_2415 = v_code_2414;
            }
            V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str7)), heff_intShow(heff_dup(v_k_249)));
            V v_c_2417 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_2410));
            V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str8)), heff_get_n(v_c_2417, 0, 2));
            return heff_rec_n(2, shape_code__prec, (V[]){v_t_2418, MK_INT(0LL)});
          }
          case TAG_Cons: {
            heff_drop(v_env_240);
            heff_drop(v_ind_241);
            return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str9), MK_INT(3LL)});
          }
          default: return heff_nomatch(v_args222_2411);
          }
        }
        default: return heff_nomatch(v_args22_246);
        }
      }
      case TAG_SFloat: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str10), MK_INT(3LL)});
      }
      case TAG_SStr: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str11), MK_INT(3LL)});
      }
      case TAG_SBytes: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str12), MK_INT(3LL)});
      }
      case TAG_SFixed: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str13), MK_INT(3LL)});
      }
      case TAG_SFloat32: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str14), MK_INT(3LL)});
      }
      case TAG_SPrimFn: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str15), MK_INT(3LL)});
      }
      case TAG_SLam: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str16), MK_INT(3LL)});
      }
      case TAG_STag: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str17), MK_INT(3LL)});
      }
      case TAG_SRec: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str18), MK_INT(3LL)});
      }
      case TAG_SProj: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str19), MK_INT(3LL)});
      }
      case TAG_SPrim: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_str20), MK_INT(3LL)});
      }
      default: return heff_nomatch(v_args21_245);
      }
    }
    default: return heff_nomatch(v_args2_244);
    }
  }
  default: return heff_nomatch(v_args_242);
  }
}
V g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str0, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str1, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str2, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str3, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str4, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str5, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str6, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str8, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str9, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str12, 14, "Uint8Array.of(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str14, 12, "Math.fround(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str16, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str17, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str19, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str22, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str23, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str24, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str25, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str27, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str28, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str29, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str30, 9, ", a: [] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str32, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str33, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str34, 5, "{ $: ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str35, 6, ", a: [");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str37, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str38, 3, "] }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str41, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str42, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str43, 2, ": ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str44, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str45, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str46, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str47, 2, " }");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str48, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str49, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str50, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str51, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str52, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str53, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str54, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str55, 1, "[");
HEFF_LIT(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str56, 1, "]");
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry, 3, 0};

V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    heff_drop(v_ind_241);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_240, 4), v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_rec(v_env_240, 5);
        V v_c_247 = v_field_246;
        return v_c_247;
      } else {
        heff_drop(v_field_246);
        V v_d_248 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_x_243)));
        HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_env_240, 1, 5); V a_1 = v_x_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          V v_t_2413;
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop(v_d_248);
            V v_x_2412 = v_field_2411;
            v_t_2413 = v_x_2412;
          } else {
            heff_drop(v_field_2411);
            v_t_2413 = v_d_248;
          }
          return heff_rec_n(2, shape_code__prec, (V[]){v_t_2413, MK_INT(3LL)});
        }
      }
    }
  }
  case TAG_SGlobal: {
    V v_g_2414 = heff_field(v_x4_242, 0);
    heff_drop(v_ind_241);
    HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_env_240, 0, 5); V a_1 = v_g_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_code_2422;
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_i_2418 = v_field_2417;
        V v_arity_2419 = heff_take_field(v_i_2418, 1);
        V v_js_2420 = heff_take_field(v_i_2418, 0);
        V v_lazy_2421 = heff_get_n(v_i_2418, 2, 4);
        if (heff_intLe_c(MK_INT(2LL), v_arity_2419)) {
          heff_drop(v_lazy_2421);
          v_code_2422 = heff_strAppend(v_js_2420, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str0));
        } else {
          if ((heff_dup(v_lazy_2421) == NTAG(TAG_True))) {
            heff_drop(v_lazy_2421);
            v_code_2422 = heff_strAppend(v_js_2420, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str1));
          } else {
            heff_drop(v_lazy_2421);
            v_code_2422 = v_js_2420;
          }
        }
      } else {
        heff_drop(v_field_2417);
        v_code_2422 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str2);
      }
    }
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2422, MK_INT(3LL)});
  }
  case TAG_SInt: {
    V v_i_2423 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_s_2424 = heff_intShow(heff_dup(v_i_2423));
    if (heff_strEq_c(heff_strSlice_lent(v_s_2424, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str3))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2424, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str4)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_2424, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str5)), MK_INT(3LL)});
    }
  }
  case TAG_SFloat: {
    V v_x_2425 = heff_tget_v(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_s_2426 = heff_floatShow(v_x_2425);
    if (heff_strEq_c(heff_strSlice_lent(v_s_2426, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str6))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2426, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_2426, MK_INT(3LL)});
    }
  }
  case TAG_SStr: {
    V v_s_2427 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2428 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_s_2427), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str7)));
    V v_code_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str8), v_t_2428), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str9));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2429, MK_INT(3LL)});
  }
  case TAG_SBytes: {
    V v_s_2430 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_s_2430, 0)) - ((int64_t)1ULL));
    V v_x2_2432 = (g_list_2emap_24f1457339348x592422294(v_s_2430, MK_INT(0LL), heff_box_word(v_t_2431)));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_Nil: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_xs_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str11); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2432);
    }
    V v_code_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str12), v_t_2435), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str13));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2436, MK_INT(3LL)});
  }
  case TAG_SFixed: {
    V v_w_2437 = heff_field(v_x4_242, 0);
    V v_n_2438 = heff_field(v_x4_242, 1);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    return (g_heff_2ecompile_2eemit_2efixedCode(v_w_2437, heff_dup(v_n_2438)));
  }
  case TAG_SFloat32: {
    V v_x_2439 = heff_tget_v(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str14), heff_floatShow(v_x_2439));
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str15)), MK_INT(3LL)});
  }
  case TAG_SPrimFn: {
    V v_p_2441 = heff_field(v_x4_242, 0);
    heff_drop_rec(v_env_240, 5);
    heff_drop(v_ind_241);
    V v_t_2442 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_2441));
    V v_code_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str16), v_t_2442), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str17));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2443, MK_INT(3LL)});
  }
  case TAG_SLam: {
    V v_xs_2444 = heff_field(v_x4_242, 0);
    V v_x42_2445 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_2445)) {
    case TAG_MkBlock: {
      V v_t_2446 = heff_field(v_x42_2445, 0);
      V v_t_2447 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_env_240, 23ULL, 5, shape_gs__names__used__self__inl, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_2448 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_2447});
      V v_rb_2449 = (g_list_2efoldl_24s509733942x1507005169(MK_INT(0LL), MK_INT(0LL), v_t_2448, heff_dup(v_xs_2444)));
      V v_js_2450 = heff_take_field(v_rb_2449, 0);
      V v_env_2451 = heff_get_n(v_rb_2449, 1, 2);
      V v_x2_2452 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str18), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str19), v_js_2450));
      V v_t_2455;
      switch (heff_tag_of(v_x2_2452)) {
      case TAG_Nil: {
        v_t_2455 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_2453 = heff_field(v_x2_2452, 0);
        V v_xs_2454 = heff_field(v_x2_2452, 1);
        heff_take_n(v_x2_2452, 3ULL, 2);
        v_t_2455 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str21); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2452);
      }
      V v_t_2456 = (g_heff_2ecompile_2eemit_2ebodyGo_24s987832514x1752441271(v_env_2451, v_ind_241, heff_dup(v_t_2446)));
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2455, v_t_2456), MK_INT(0LL)});
    }
    default: return heff_nomatch(v_x42_2445);
    }
  }
  case TAG_STag: {
    V v_t_2457 = heff_field(v_x4_242, 0);
    V v_x42_2458 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_2458)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 5);
      heff_drop(v_ind_241);
      if (heff_strEq_c_lent(v_t_2457, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str22), 2)) {
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str23), MK_INT(3LL)});
      } else {
        if (heff_strEq_c_lent(v_t_2457, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str24), 2)) {
          return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str25), MK_INT(3LL)});
        } else {
          V v_t_2460 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_t_2457), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str26)));
          V v_t_2461 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str27), v_t_2460), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str28));
          V v_code_2462 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str29), v_t_2461), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str30));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2462, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_t_2465 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_t_2457), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str31)));
      V v_t_2466 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str32), v_t_2465), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str33));
      V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str34), v_t_2466), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str35));
      V v_x2_2470 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_x42_2458)));
      V v_t_2473;
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_Nil: {
        v_t_2473 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str36);
        break;
      }
      case TAG_Cons: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_xs_2472 = heff_field(v_x2_2470, 1);
        heff_take_n(v_x2_2470, 3ULL, 2);
        v_t_2473 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str37); V a_1 = v_x_2471; V a_2 = v_xs_2472; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2472); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2470);
      }
      V v_code_2474 = heff_strAppend(heff_strAppend(v_t_2467, v_t_2473), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str38));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2474, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x42_2458);
    }
  }
  case TAG_SRec: {
    V v_fs_2475 = heff_field(v_x4_242, 0);
    V v_x2_2483 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_fs_2475)));
    V v_t_2486;
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_Nil: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str44);
      break;
    }
    case TAG_Cons: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      V v_xs_2485 = heff_field(v_x2_2483, 1);
      heff_take_n(v_x2_2483, 3ULL, 2);
      v_t_2486 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str45); V a_1 = v_x_2484; V a_2 = v_xs_2485; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2485); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2483);
    }
    V v_code_2487 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str46), v_t_2486), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str47));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2487, MK_INT(3LL)});
  }
  case TAG_SProj: {
    V v_v_2488 = heff_field(v_x4_242, 0);
    V v_l_2489 = heff_field(v_x4_242, 1);
    V v_c_2492 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_2488));
    V v_prec_2493 = heff_take_field(v_c_2492, 1);
    V v_code_2494 = heff_get_n(v_c_2492, 0, 2);
    V v_t_2495;
    if (heff_intLt_c(v_prec_2493, MK_INT(3LL))) {
      v_t_2495 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str48), v_code_2494), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str49));
    } else {
      v_t_2495 = v_code_2494;
    }
    V v_t_2498;
    if ((heff_strEq_c_lent(v_l_2489, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str50), 2) ? 0 : ({ V v_t_24106 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_l_2489))); int c_ = heff_strEq_c_lent(v_t_24106, v_l_2489, 0); heff_drop(v_t_24106); c_; }))) {
      v_t_2498 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str51), heff_dup(v_l_2489));
    } else {
      V v_t_2496 = (g_heff_2ecompile_2eemit_2equoteGo(heff_dup(v_l_2489), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str52)));
      V v_t_2497 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str53), v_t_2496), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str54));
      v_t_2498 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str55), v_t_2497), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str56));
    }
    V v_code_2499 = heff_strAppend(v_t_2495, v_t_2498);
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2499, MK_INT(3LL)});
  }
  case TAG_SPrim: {
    V v_p_24100 = heff_field(v_x4_242, 0);
    V v_args_24101 = heff_field(v_x4_242, 1);
    V v_t_24102 = (g_heff_2ecompile_2eemit_2ecellPrim(v_p_24100, v_args_24101));
    if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
      heff_drop(v_t_24102);
      HEFF_LAST return g_heff_2ecompile_2eemit_2ecellVal_24s1833585932x697338729(v_env_240, v_ind_241, v_args_24101);
    } else {
      heff_drop(v_t_24102);
      V v_t_24104 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam2, 1, 2, (V[]){v_env_240, v_ind_241}), heff_dup(v_args_24101)));
      return (g_heff_2ecompile_2eemit_2eprimCall(v_p_24100, v_t_24104));
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam0(V self, V *args) {
  V v_a_2468 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_2468; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_2468); r_; });
  return heff_get_n(v_t_2469, 0, 2);
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam1(V self, V *args) {
  V v_f_2477 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2477)) {
  case TAG_MkPair: {
    V v_l_2478 = heff_field(v_f_2477, 0);
    V v_v_2479 = heff_field(v_f_2477, 1);
    heff_take_n(v_f_2477, 3ULL, 2);
    V v_t_2481;
    if ((heff_strEq_c_lent(v_l_2478, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str39), 2) ? 0 : ({ V v_t_24105 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_l_2478))); int c_ = heff_strEq_c_lent(v_t_24105, v_l_2478, 0); heff_drop(v_t_24105); c_; }))) {
      v_t_2481 = v_l_2478;
    } else {
      V v_t_2480 = (g_heff_2ecompile_2eemit_2equoteGo(v_l_2478, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str40)));
      v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str41), v_t_2480), ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str42));
    }
    V v_t_2482 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_2479; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_2479); r_; });
    return heff_strAppend(heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_str43)), heff_get_n(v_t_2482, 0, 2));
  }
  default: return heff_nomatch(v_f_2477);
  }
}
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_lam2(V self, V *args) {
  V v_v_24103 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_24103; V r_ = (g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_v_24103); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str3, 1, ")");
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(V v_env_240, V v_ind_241, V v_g_242, V v_args_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_240, 0), v_g_242));
  V v_t_248;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_g_242);
      V v_i_247 = v_field_246;
      v_t_248 = heff_get_n(v_i_247, 0, 4);
    } else {
      heff_drop(v_field_246);
      v_t_248 = (g_heff_2ecompile_2eemit_2esafe(v_g_242));
    }
  }
  V v_x2_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_args_243));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str2)), v_t_2414);
  return heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_str3));
}
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_249; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_249); r_; });
  return heff_get_n(v_t_2410, 0, 2);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str4, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str5, 1, ")");
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(V v_env_240, V v_ind_241, V v_c_242, V v_args_243) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0, 2, 2, (V[]){v_env_240, v_ind_241}), v_c_242, v_args_243));
}
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_lam0(V self, V *args) {
  V v_c2_244 = args[0];
  V v_a_245 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_prec_246 = heff_take_field(v_c2_244, 1);
  V v_code_247 = heff_get_n(v_c2_244, 0, 2);
  V v_t_248;
  if (heff_intLt_c(v_prec_246, MK_INT(3LL))) {
    v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str0), v_code_247), ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str1));
  } else {
    v_t_248 = v_code_247;
  }
  V v_t_249 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_a_245; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_245); r_; });
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str2)), heff_get_n(v_t_249, 0, 2));
  V v_c_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str3));
  V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str4), v_c_2411), ((V)&g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037_str5));
  return heff_rec_n(2, shape_code__prec, (V[]){v_t_2412, MK_INT(3LL)});
}

HeffT2 g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(V v_env_240, V v_ind_241, V v_x4_242, V v_after_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_env_240}});
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x4_242, 0);
    V v_rest_245 = heff_field(v_x4_242, 1);
    HeffT2 v_t_246 = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(v_env_240, heff_dup(v_ind_241), v_st_244));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      HeffT2 v_t_249 = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(v_field_248, v_ind_241, v_rest_245, v_after_243));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_f_2412 = (g_prelude_2e_2b_2b(v_field_247, v_field_2410));
        return ((HeffT2){{v_f_2412, v_field_2411}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str3, 4, "let ");
HEFF_LIT(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str4, 1, ";");
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SLet: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_o_244 = heff_field(v_x4_242, 1);
    V v_st_245 = (g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(heff_dup(v_env_240), heff_dup(v_ind_241), v_o_244));
    V v_env_246 = (g_list_2efoldl_24s2118756600x1920057229(v_env_240, heff_rfield(v_st_245, 1)));
    V v_t_247 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_243), MK_INT(0LL)));
    V v_t_248 = (g_heff_2ecompile_2eemit_2esafe(v_t_247));
    V v_t_249 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_246, heff_dup(v_x_243), v_t_248, MK_INT(0LL)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2eletBound_24cpr(v_ind_241, v_st_245, v_t_249);
  }
  case TAG_SOnce: {
    V v_x_2410 = heff_field(v_x4_242, 0);
    V v_o_2411 = heff_field(v_x4_242, 1);
    V v_c_2412 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(heff_dup(v_env_240), v_ind_241, v_o_2411));
    V v_t_2413 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_env_240, 4), heff_dup(v_x_2410), v_c_2412));
    V v_f_2414 = ({ V rv_4 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_env_240, 15ULL, 5, shape_gs__names__used__self__inl, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{NTAG(TAG_Nil), v_f_2414}});
  }
  case TAG_SDecl: {
    V v_x_2415 = heff_field(v_x4_242, 0);
    V v_t_2416 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2415), MK_INT(0LL)));
    V v_t_2417 = (g_heff_2ecompile_2eemit_2esafe(v_t_2416));
    HeffT2 v_t_2418 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(v_env_240, heff_dup(v_x_2415), v_t_2417, MK_INT(0LL)));
    {
      V v_field_2419 = v_t_2418.f[0];
      V v_field_2420 = v_t_2418.f[1];
      V v_x2_2421 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str0)));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str2); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str3)), v_field_2419);
      V v_f_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_str4)), NTAG(TAG_Nil)});
      return ((HeffT2){{v_f_2426, v_field_2420}});
    }
  }
  case TAG_SSet: {
    V v_x_2427 = heff_field(v_x4_242, 0);
    V v_o_2428 = heff_field(v_x4_242, 1);
    V v_t_2429 = (g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(heff_dup(v_env_240), heff_dup(v_ind_241), v_o_2428));
    return (g_heff_2ecompile_2eemit_2esetStmt_24cpr(v_ind_241, v_t_2429, heff_dup(v_x_2427), v_env_240));
  }
  case TAG_SIf: {
    V v_c_2430 = heff_field(v_x4_242, 0);
    V v_ts_2431 = heff_field(v_x4_242, 1);
    V v_fs_2432 = heff_field(v_x4_242, 2);
    V v_t_2433 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), heff_dup(v_c_2430)));
    V v_f_2447 = heff_tr(g_heff_2ecompile_2eemit_2eifLines(heff_dup(v_ind_241), v_t_2433, heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam0, 1, 2, (V[]){heff_dup(v_ts_2431), heff_dup(v_env_240)}), heff_clo_n(g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam1, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_fs_2432)})));
    V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eemit_2ejk_get(), 2)), 3, (V[]){heff_dup(v_env_240), v_ind_241, heff_dup(v_c_2430)}));
    V v_t_2449 = ({ V a_0 = v_t_2448; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_t_2448); r_; });
    V v_f_2450 = ({ V a_0 = v_env_240; V a_1 = v_t_2449; V r_ = (g_list_2efoldl_24s2118756600x1920057229(a_0, a_1)); heff_drop(v_t_2449); r_; });
    return ((HeffT2){{v_f_2447, v_f_2450}});
  }
  case TAG_SCase: {
    V v_v_2451 = heff_field(v_x4_242, 0);
    V v_arms_2452 = heff_field(v_x4_242, 1);
    V v_t_2453 = (g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(v_env_240, heff_dup(v_ind_241), heff_dup(v_v_2451)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2ecaseStmt_24s990066287x122383707_24cpr(v_ind_241, heff_dup(v_arms_2452), v_t_2453);
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam0(V self, V *args) {
  V v_i_2434 = args[0];
  V v_ts_2431 = heff_env(self)[0];
  V v_env_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444;
  switch (heff_tag_of(v_ts_2431)) {
  case TAG_Nil: {
    heff_drop(v_i_2434);
    v_t_2444 = heff_rec_n(2, shape_lines__env, (V[]){NTAG(TAG_Nil), v_env_240});
    break;
  }
  case TAG_Cons: {
    V v_st_2435 = heff_field(v_ts_2431, 0);
    V v_rest_2436 = heff_field(v_ts_2431, 1);
    V v_ru_24ts_2431_24Cons = heff_take_reuse_n(v_ts_2431, 3ULL, 2);
    HeffT2 v_t_2437 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_i_2434); V a_2 = v_st_2435; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(a_0, a_1, a_2)); heff_drop(v_st_2435); r_; });
    {
      V v_field_2438 = v_t_2437.f[0];
      V v_field_2439 = v_t_2437.f[1];
      HeffT2 v_t_2440 = ({ V a_0 = v_field_2439; V a_1 = v_i_2434; V a_2 = v_rest_2436; V b_3 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(a_0, a_1, a_2, b_3)); heff_drop(v_rest_2436); heff_drop(b_3); r_; });
      {
        V v_field_2441 = v_t_2440.f[0];
        V v_field_2442 = v_t_2440.f[1];
        V v_t_2443 = (g_prelude_2e_2b_2b_24tok2(v_ru_24ts_2431_24Cons, v_field_2438, v_field_2441));
        v_t_2444 = heff_rec_n(2, shape_lines__env, (V[]){v_t_2443, v_field_2442});
      }
    }
    break;
  }
  default: heff_nomatch(v_ts_2431);
  }
  return heff_get_n(v_t_2444, 0, 2);
}
V g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr_lam1(V self, V *args) {
  V v_i_2445 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_fs_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eemit_2ejk_get(), 5)), 4, (V[]){v_env_240, v_i_2445, v_fs_2432, NTAG(TAG_Nothing)}));
  return heff_get_n(v_t_2446, 0, 2);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21, 6, "$force");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str38, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str39, 1, ";");
Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V v_env_240, V v_ind_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 1); r_; });
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3)), heff_get_n(v_t_248, 0, 2));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4)), NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    V v_g_2410 = heff_dup(heff_field(v_o_242, 0));
    V v_args_2411 = heff_dup(heff_field(v_o_242, 1));
    V v_t_2441;
    switch (heff_tag_of(v_args_2411)) {
    case TAG_Nil: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2412 = heff_dup(heff_field(v_args_2411, 0));
      V v_x12_2413 = heff_dup(heff_field(v_args_2411, 1));
      switch (heff_tag_of(v_x11_2412)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2412, 0ULL, 2);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2412, 0ULL, 2);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2426 = heff_field(v_x11_2412, 0);
        V v_x112_2427 = heff_field(v_x11_2412, 1);
        heff_take_n(v_x11_2412, 3ULL, 3);
        switch (heff_tag_of(v_x112_2427)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2413)) {
          case TAG_Nil: {
            v_t_2441 = heff_bool(heff_strEq_c_lent(v_t_2426, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5), 2));
            heff_drop(v_t_2426);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2413, 0ULL, 2);
            heff_drop(v_t_2426);
            v_t_2441 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2413);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2427, 0ULL, 2);
          heff_drop(v_x12_2413);
          heff_drop(v_t_2426);
          v_t_2441 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2427);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2412, 0ULL, 2);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2412, 0ULL, 4);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2412, 0ULL, 2);
        heff_drop(v_x12_2413);
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2412);
      }
      break;
    }
    default: heff_nomatch(v_args_2411);
    }
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_g_2410);
      heff_drop(v_args_2411);
      heff_drop(v_t_2441);
      V v_x2_2442 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6)));
      V v_t_2445;
      switch (heff_tag_of(v_x2_2442)) {
      case TAG_Nil: {
        v_t_2445 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2443 = heff_field(v_x2_2442, 0);
        V v_xs_2444 = heff_field(v_x2_2442, 1);
        heff_take_n(v_x2_2442, 3ULL, 2);
        v_t_2445 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2442);
      }
      V v_t_2446 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 2); r_; });
      V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9)), heff_get_n(v_t_2446, 0, 2));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10)), NTAG(TAG_Nil)});
    } else {
      heff_drop_tag(v_o_242, 2);
      heff_drop(v_t_2441);
      V v_x2_2448 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11)));
      V v_t_2451;
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_Nil: {
        v_t_2451 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        V v_xs_2450 = heff_field(v_x2_2448, 1);
        heff_take_n(v_x2_2448, 3ULL, 2);
        v_t_2451 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2448);
      }
      V v_t_2452 = (g_heff_2ecompile_2eemit_2ecallCode_24s703615014x23343426(v_env_240, v_ind_241, v_g_2410, v_args_2411));
      V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14)), v_t_2452);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15)), NTAG(TAG_Nil)});
    }
  }
  case TAG_OApply: {
    V v_f_2454 = heff_field(v_o_242, 0);
    V v_args_2455 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OApply = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2485;
    switch (heff_tag_of(v_args_2455)) {
    case TAG_Nil: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2456 = heff_dup(heff_field(v_args_2455, 0));
      V v_x12_2457 = heff_dup(heff_field(v_args_2455, 1));
      switch (heff_tag_of(v_x11_2456)) {
      case TAG_SVar: {
        heff_take_n(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_2456, 0ULL, 2);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_2456, 0ULL, 1);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_2456, 0ULL, 2);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2470 = heff_field(v_x11_2456, 0);
        V v_x112_2471 = heff_field(v_x11_2456, 1);
        heff_take_n(v_x11_2456, 3ULL, 3);
        switch (heff_tag_of(v_x112_2471)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2457)) {
          case TAG_Nil: {
            v_t_2485 = heff_bool(heff_strEq_c_lent(v_t_2470, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16), 2));
            heff_drop(v_t_2470);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x12_2457, 0ULL, 2);
            heff_drop(v_t_2470);
            v_t_2485 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2457);
          }
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x112_2471, 0ULL, 2);
          heff_drop(v_x12_2457);
          heff_drop(v_t_2470);
          v_t_2485 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2471);
        }
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_2456, 0ULL, 2);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_2456, 0ULL, 4);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_2456, 0ULL, 2);
        heff_drop(v_x12_2457);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2456);
      }
      break;
    }
    default: heff_nomatch(v_args_2455);
    }
    if ((heff_dup(v_t_2485) == NTAG(TAG_True))) {
      heff_drop(v_args_2455);
      heff_drop(v_t_2485);
      V v_ac_2486 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_f_2454; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2454); r_; });
      V v_t_2487 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17); V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemit_2eatomGo(b_0, a_1)); heff_drop(b_0); r_; });
      V v_f_2491;
      if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
        heff_drop(v_t_2487);
        v_f_2491 = heff_rec_n(3, shape_js__pre__env, (V[]){((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18), NTAG(TAG_Nil), v_env_240});
      } else {
        heff_drop(v_t_2487);
        V v_t_2488 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19), MK_INT(0LL)));
        V v_t_2489 = (g_heff_2ecompile_2eemit_2esafe(v_t_2488));
        V v_t_2490 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_240, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20), v_t_2489, MK_INT(0LL)));
        v_f_2491 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21); V b_1 = MK_INT(3LL); V a_2 = heff_dup(v_ind_241); V a_3 = v_t_2490; V r_ = (g_heff_2ecompile_2eemit_2enamedAs_24s2053204186x1653225487(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
      }
      V v_t_2492 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_2491, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22), v_ac_2486));
      return (g_heff_2ecompile_2eemit_2ebounceGive_24tok2(v_ru_24o_242_24OApply, v_ind_241, v_f_2491, v_t_2492));
    } else {
      heff_drop(v_t_2485);
      switch (heff_tag_of(v_args_2455)) {
      case TAG_Nil: {
        V v_x2_2493 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23)));
        V v_t_2496;
        switch (heff_tag_of(v_x2_2493)) {
        case TAG_Nil: {
          v_t_2496 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24);
          break;
        }
        case TAG_Cons: {
          V v_x_2494 = heff_field(v_x2_2493, 0);
          V v_xs_2495 = heff_field(v_x2_2493, 1);
          heff_take_n(v_x2_2493, 3ULL, 2);
          v_t_2496 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25); V a_1 = v_x_2494; V a_2 = v_xs_2495; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2495); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2493);
        }
        V v_t_2497 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_f_2454; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2454); r_; });
        V v_t_2498 = heff_strAppend(heff_strAppend(v_t_2496, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26)), heff_get_n(v_t_2497, 0, 2));
        return heff_tag_at_n(v_ru_24o_242_24OApply, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2498, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27)), NTAG(TAG_Nil)});
      }
      case TAG_Cons: {
        V v_x_2499 = heff_field(v_args_2455, 0);
        V v_rest_24100 = heff_field(v_args_2455, 1);
        heff_take_n(v_args_2455, 3ULL, 2);
        HeffT2 v_t_24101 = (g_heff_2ecompile_2eemit_2eunsnocGo_24cpr(v_rest_24100, v_x_2499));
        {
          V v_field_24102 = v_t_24101.f[0];
          V v_field_24103 = v_t_24101.f[1];
          V v_ini_24104 = v_field_24102;
          V v_a_24105 = v_field_24103;
          V v_t_24106 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_f_2454; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_f_2454); r_; });
          V v_fc_24107 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_t_24106; V a_3 = v_ini_24104; V r_ = (g_heff_2ecompile_2eemit_2eapplied_24s694046302x1915851037(a_0, a_1, a_2, a_3)); heff_drop(v_ini_24104); r_; });
          V v_ac_24108 = ({ V a_0 = heff_dup(v_env_240); V a_1 = heff_dup(v_ind_241); V a_2 = v_a_24105; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_a_24105); r_; });
          V v_f_24109 = (g_heff_2ecompile_2eemit_2enamed(v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28), v_fc_24107));
          V v_t_24110 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_24109, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29), v_ac_24108));
          return (g_heff_2ecompile_2eemit_2ebounceGive_24tok2(v_ru_24o_242_24OApply, v_ind_241, v_f_24109, v_t_24110));
        }
      }
      default: return heff_nomatch(v_args_2455);
      }
    }
  }
  case TAG_OPrim: {
    V v_x2_24113 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30)));
    V v_t_24116;
    switch (heff_tag_of(v_x2_24113)) {
    case TAG_Nil: {
      v_t_24116 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_24114 = heff_field(v_x2_24113, 0);
      V v_xs_24115 = heff_field(v_x2_24113, 1);
      heff_take_n(v_x2_24113, 3ULL, 2);
      v_t_24116 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32); V a_1 = v_x_24114; V a_2 = v_xs_24115; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24115); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24113);
    }
    V v_t_24117 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_o_242; V r_ = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(a_0, a_1, a_2)); heff_drop_tag(v_o_242, 2); r_; });
    V v_t_24118 = heff_strAppend(heff_strAppend(v_t_24116, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33)), heff_get_n(v_t_24117, 0, 2));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24118, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34)), NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    V v_x2_24119 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35)));
    V v_t_24122;
    switch (heff_tag_of(v_x2_24119)) {
    case TAG_Nil: {
      v_t_24122 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36);
      break;
    }
    case TAG_Cons: {
      V v_x_24120 = heff_field(v_x2_24119, 0);
      V v_xs_24121 = heff_field(v_x2_24119, 1);
      heff_take_n(v_x2_24119, 3ULL, 2);
      v_t_24122 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str37); V a_1 = v_x_24120; V a_2 = v_xs_24121; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24121); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24119);
    }
    V v_t_24123 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    V v_t_24124 = heff_strAppend(heff_strAppend(v_t_24122, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str38)), heff_get_n(v_t_24123, 0, 2));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24124, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str39)), NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_24125 = heff_field(v_o_242, 0);
    heff_take_n(v_o_242, 1ULL, 1);
    V v_t_24126 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(v_env_240, heff_dup(v_ind_241), v_c_24125));
    return (g_heff_2ecompile_2eemit_2ereturnCond(v_ind_241, v_t_24126));
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ekeptOfDef_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ekeptOfDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ekeptOfDef_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ekeptOfDef(V v_p_240, V v_v_241, V v_d_242) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_d_242)) {
  case TAG_MkDef: {
    V v_k_243 = heff_dup(heff_field(v_d_242, 0));
    v_t_246 = v_k_243;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_p_240, 0); V a_1 = v_t_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_i_2410 = v_field_249;
      V v_v_2411 = v_v_241;
      V v_d_2412 = heff_dup(v_d_242);
      V v_p_2413 = heff_dup(v_p_240);
      V v_d_2414 = heff_dup(v_d_242);
      V v_t_2418;
      switch (heff_tag_of(v_d_2414)) {
      case TAG_MkDef: {
        V v_k_2415 = heff_dup(heff_field(v_d_2414, 0));
        v_t_2418 = v_k_2415;
        break;
      }
      default: heff_nomatch(v_d_2414);
      }
      V v_t_2427;
      switch (heff_tag_of(v_d_2414)) {
      case TAG_MkDef: {
        V v_x13_2421 = heff_field(v_d_2414, 2);
        heff_take_n(v_d_2414, 4ULL, 3);
        switch (heff_tag_of(v_x13_2421)) {
        case TAG_DefFun: {
          V v_x132_2423 = heff_field(v_x13_2421, 1);
          heff_take_n(v_x13_2421, 2ULL, 2);
          switch (heff_tag_of(v_x132_2423)) {
          case TAG_MkBlock: {
            V v_t_2424 = heff_field(v_x132_2423, 0);
            heff_take_n(v_x132_2423, 1ULL, 1);
            v_t_2427 = ({ V a_0 = v_t_2424; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2424); r_; });
            break;
          }
          default: heff_nomatch(v_x132_2423);
          }
          break;
        }
        case TAG_DefVal: {
          V v_x131_2425 = heff_field(v_x13_2421, 0);
          heff_take_n(v_x13_2421, 1ULL, 1);
          switch (heff_tag_of(v_x131_2425)) {
          case TAG_MkBlock: {
            V v_t_2426 = heff_field(v_x131_2425, 0);
            heff_take_n(v_x131_2425, 1ULL, 1);
            v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2426); r_; });
            break;
          }
          default: heff_nomatch(v_x131_2425);
          }
          break;
        }
        default: heff_nomatch(v_x13_2421);
        }
        break;
      }
      default: heff_nomatch(v_d_2414);
      }
      V v_t_2428 = (g_list_2emap_24s1455783996x1449538216(v_t_2427));
      V v_t_2429 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2428));
      HeffT2 v_t_2430 = ({ V a_0 = heff_rfield(v_p_2413, 0); V a_1 = v_t_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
      V v_t_2434;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_i_2433 = v_field_2432;
          v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_i_2433, 0, 4)});
        } else {
          heff_drop(v_field_2432);
          v_t_2434 = NTAG(TAG_Nothing);
        }
      }
      V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ekeptOfDef_lam0, 1, 1, (V[]){v_p_2413}), v_t_2429));
      V v_xs_2441 = (g_heff_2ecompile_2eemit_2ecatMaybesL(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2440})));
      V v_t_2442 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2441; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2441); r_; });
      V v_t_2446;
      switch (heff_tag_of(v_d_242)) {
      case TAG_MkDef: {
        V v_k_2443 = heff_dup(heff_field(v_d_242, 0));
        v_t_2446 = v_k_2443;
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      V v_t_2450;
      switch (heff_tag_of(v_d_242)) {
      case TAG_MkDef: {
        V v_b_2449 = heff_field(v_d_242, 2);
        heff_take_n(v_d_242, 4ULL, 3);
        v_t_2450 = v_b_2449;
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      HeffT2 v_t_2451 = (g_heff_2ecompile_2eemit_2edefCodeOf_24cpr(heff_get_n(v_p_240, 0, 1), v_t_2442, v_t_2446, v_t_2450, v_i_2410));
      {
        V v_field_2452 = v_t_2451.f[0];
        V v_field_2453 = v_t_2451.f[1];
        V v_t_2462;
        switch (heff_tag_of(v_d_2412)) {
        case TAG_MkDef: {
          V v_x13_2456 = heff_dup(heff_field(v_d_2412, 2));
          switch (heff_tag_of(v_x13_2456)) {
          case TAG_DefFun: {
            V v_x132_2458 = heff_field(v_x13_2456, 1);
            heff_take_n(v_x13_2456, 2ULL, 2);
            switch (heff_tag_of(v_x132_2458)) {
            case TAG_MkBlock: {
              V v_t_2459 = heff_field(v_x132_2458, 0);
              heff_take_n(v_x132_2458, 1ULL, 1);
              v_t_2462 = ({ V a_0 = v_t_2459; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2459); r_; });
              break;
            }
            default: heff_nomatch(v_x132_2458);
            }
            break;
          }
          case TAG_DefVal: {
            V v_x131_2460 = heff_field(v_x13_2456, 0);
            heff_take_n(v_x13_2456, 1ULL, 1);
            switch (heff_tag_of(v_x131_2460)) {
            case TAG_MkBlock: {
              V v_t_2461 = heff_field(v_x131_2460, 0);
              heff_take_n(v_x131_2460, 1ULL, 1);
              v_t_2462 = ({ V a_0 = v_t_2461; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2461); r_; });
              break;
            }
            default: heff_nomatch(v_x131_2460);
            }
            break;
          }
          default: heff_nomatch(v_x13_2456);
          }
          break;
        }
        default: heff_nomatch(v_d_2412);
        }
        V v_t_2463 = (g_list_2emap_24s1585362143x1323498048(v_t_2462));
        V v_t_2464 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2463));
        V v_t_2473;
        switch (heff_tag_of(v_d_2412)) {
        case TAG_MkDef: {
          V v_x13_2467 = heff_field(v_d_2412, 2);
          heff_take_n(v_d_2412, 4ULL, 3);
          switch (heff_tag_of(v_x13_2467)) {
          case TAG_DefFun: {
            V v_x132_2469 = heff_field(v_x13_2467, 1);
            heff_take_n(v_x13_2467, 2ULL, 2);
            switch (heff_tag_of(v_x132_2469)) {
            case TAG_MkBlock: {
              V v_t_2470 = heff_field(v_x132_2469, 0);
              heff_take_n(v_x132_2469, 1ULL, 1);
              v_t_2473 = ({ V a_0 = v_t_2470; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2470); r_; });
              break;
            }
            default: heff_nomatch(v_x132_2469);
            }
            break;
          }
          case TAG_DefVal: {
            V v_x131_2471 = heff_field(v_x13_2467, 0);
            heff_take_n(v_x13_2467, 1ULL, 1);
            switch (heff_tag_of(v_x131_2471)) {
            case TAG_MkBlock: {
              V v_t_2472 = heff_field(v_x131_2471, 0);
              heff_take_n(v_x131_2471, 1ULL, 1);
              v_t_2473 = ({ V a_0 = v_t_2472; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2472); r_; });
              break;
            }
            default: heff_nomatch(v_x131_2471);
            }
            break;
          }
          default: heff_nomatch(v_x13_2467);
          }
          break;
        }
        default: heff_nomatch(v_d_2412);
        }
        V v_m_2474 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2473; V r_ = (g_list_2efoldl_24s398854970x1533504811(a_0, a_1)); heff_drop(v_t_2473); r_; });
        V v_t_2475 = ({ V a_0 = v_m_2474; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2474); r_; });
        V v_t_2476 = (g_list_2emap_24s1937570095x2110149801(v_t_2475));
        return heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_v_2411, v_field_2452, v_field_2453, v_t_2464, v_t_2476});
      }
    } else {
      heff_drop_rec(v_p_240, 1);
      heff_drop(v_field_249);
      V v_v_2477 = v_v_241;
      V v_d_2478 = v_d_242;
      V v_t_2487;
      switch (heff_tag_of(v_d_2478)) {
      case TAG_MkDef: {
        V v_x13_2481 = heff_dup(heff_field(v_d_2478, 2));
        switch (heff_tag_of(v_x13_2481)) {
        case TAG_DefFun: {
          V v_x132_2483 = heff_field(v_x13_2481, 1);
          heff_take_n(v_x13_2481, 2ULL, 2);
          switch (heff_tag_of(v_x132_2483)) {
          case TAG_MkBlock: {
            V v_t_2484 = heff_field(v_x132_2483, 0);
            heff_take_n(v_x132_2483, 1ULL, 1);
            v_t_2487 = ({ V a_0 = v_t_2484; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2484); r_; });
            break;
          }
          default: heff_nomatch(v_x132_2483);
          }
          break;
        }
        case TAG_DefVal: {
          V v_x131_2485 = heff_field(v_x13_2481, 0);
          heff_take_n(v_x13_2481, 1ULL, 1);
          switch (heff_tag_of(v_x131_2485)) {
          case TAG_MkBlock: {
            V v_t_2486 = heff_field(v_x131_2485, 0);
            heff_take_n(v_x131_2485, 1ULL, 1);
            v_t_2487 = ({ V a_0 = v_t_2486; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2486); r_; });
            break;
          }
          default: heff_nomatch(v_x131_2485);
          }
          break;
        }
        default: heff_nomatch(v_x13_2481);
        }
        break;
      }
      default: heff_nomatch(v_d_2478);
      }
      V v_t_2488 = (g_list_2emap_24s1585362143x1323498048(v_t_2487));
      V v_t_2489 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2488));
      V v_t_2498;
      switch (heff_tag_of(v_d_2478)) {
      case TAG_MkDef: {
        V v_x13_2492 = heff_field(v_d_2478, 2);
        heff_take_n(v_d_2478, 4ULL, 3);
        switch (heff_tag_of(v_x13_2492)) {
        case TAG_DefFun: {
          V v_x132_2494 = heff_field(v_x13_2492, 1);
          heff_take_n(v_x13_2492, 2ULL, 2);
          switch (heff_tag_of(v_x132_2494)) {
          case TAG_MkBlock: {
            V v_t_2495 = heff_field(v_x132_2494, 0);
            heff_take_n(v_x132_2494, 1ULL, 1);
            v_t_2498 = ({ V a_0 = v_t_2495; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2495); r_; });
            break;
          }
          default: heff_nomatch(v_x132_2494);
          }
          break;
        }
        case TAG_DefVal: {
          V v_x131_2496 = heff_field(v_x13_2492, 0);
          heff_take_n(v_x13_2492, 1ULL, 1);
          switch (heff_tag_of(v_x131_2496)) {
          case TAG_MkBlock: {
            V v_t_2497 = heff_field(v_x131_2496, 0);
            heff_take_n(v_x131_2496, 1ULL, 1);
            v_t_2498 = ({ V a_0 = v_t_2497; V a_1 = NTAG(TAG_Nil); V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2497); r_; });
            break;
          }
          default: heff_nomatch(v_x131_2496);
          }
          break;
        }
        default: heff_nomatch(v_x13_2492);
        }
        break;
      }
      default: heff_nomatch(v_d_2478);
      }
      V v_m_2499 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2498; V r_ = (g_list_2efoldl_24s398854970x1533504811(a_0, a_1)); heff_drop(v_t_2498); r_; });
      V v_t_24100 = ({ V a_0 = v_m_2499; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2499); r_; });
      V v_t_24101 = (g_list_2emap_24s1937570095x2110149801(v_t_24100));
      return heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_v_2477, NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2489, v_t_24101});
    }
  }
}
V g_heff_2ecompile_2eemit_2ekeptOfDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ekeptOfDef(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ekeptOfDef_lam0(V self, V *args) {
  V v_g_2435 = args[0];
  V v_p_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_p_2413, 0, 1); V a_1 = v_g_2435; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_2435); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    if ((v_tag_2437 == ((int64_t)0ULL))) {
      V v_i_2439 = v_field_2438;
      return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_i_2439, 0, 4)});
    } else {
      heff_drop(v_field_2438);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str0, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str1, 5, "$c = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str3, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str7, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str9, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str10, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str12, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str13, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eassembled_str15, 1, "\012");
V g_heff_2ecompile_2eemit_2eassembled_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eassembled_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eassembled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eassembled_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eassembled(V v_p_240, V v_es_241, V v_curried_242) {
top: ;
  V v_info_243 = heff_dup(heff_rfield(v_p_240, 0));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_241)));
  V v_code_2437 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eassembled_lam0, 2, 2, (V[]){v_p_240, v_curried_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_241));
  V v_xs_2439 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2438; V r_ = (g_list_2efoldl_24s25420611x1990549631(a_0, a_1)); heff_drop(v_t_2438); r_; });
  V v_uses_2440 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2439; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2439); r_; });
  V v_xs_2441 = heff_dup(g_heff_2ecompile_2eprims_2ejsPrims_get());
  V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2441));
  V v_helpers_2465 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eassembled_lam1, 2, 1, (V[]){v_uses_2440}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2442; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2442); r_; });
  V v_x2_2466 = (g_prelude_2e_2b_2b(heff_dup(v_helpers_2465), heff_dup(v_code_2437)));
  V v_t_2469;
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_Nil: {
    v_t_2469 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str14);
    break;
  }
  case TAG_Cons: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_xs_2468 = heff_field(v_x2_2466, 1);
    heff_take_n(v_x2_2466, 3ULL, 2);
    v_t_2469 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str15); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2466);
  }
  V v_t_2470 = ({ V a_0 = v_t_2469; V r_ = (g_heff_2ecompile_2eemit_2eruntime(a_0)); heff_drop(v_t_2469); r_; });
  V v_t_2471 = (g_prelude_2e_2b_2b(v_helpers_2465, v_code_2437));
  V v_t_2472 = (g_prelude_2e_2b_2b(v_t_2470, v_t_2471));
  return heff_rec_n(2, shape_lines__globals, (V[]){v_t_2472, v_info_243});
}
V g_heff_2ecompile_2eemit_2eassembled_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eassembled(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2eassembled_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_p_240 = heff_env(self)[0];
  V v_curried_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436;
  switch (heff_tag_of(v_x_246)) {
  case TAG_MkPair: {
    V v_key_247 = heff_field(v_x_246, 0);
    V v_k_248 = heff_field(v_x_246, 1);
    V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
    V v_lines_249 = heff_take_field(v_k_248, 1);
    V v_params_2410 = heff_get_n(v_k_248, 2, 5);
    HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_p_240, 0, 1); V a_1 = v_key_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_i_2414 = v_field_2413;
        V v_curried_2415 = v_curried_242;
        V v_key_2416 = v_key_247;
        V v_i_2417 = v_i_2414;
        V v_arity_2418 = heff_take_field(v_i_2417, 1);
        V v_js_2419 = heff_get_n(v_i_2417, 0, 4);
        V v_js_2420 = v_params_2410;
        V v_t_2435;
        if (heff_intLe_c(MK_INT(2LL), v_arity_2418)) {
          HeffT2 v_t_2421 = ({ V a_0 = v_curried_2415; V a_1 = v_key_2416; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_curried_2415); heff_drop(v_key_2416); r_; });
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              V v_x_2424 = v_field_2423;
              heff_drop(v_x_2424);
              V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eassembled_str0), heff_dup(v_js_2419)), ((V)&g_heff_2ecompile_2eemit_2eassembled_str1));
              V v_x2_2426 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ecompile_2eemit_2eassembled_str2), ((V)&g_heff_2ecompile_2eemit_2eassembled_str3), heff_dup(v_js_2420)));
              V v_t_2429;
              switch (heff_tag_of(v_x2_2426)) {
              case TAG_Nil: {
                v_t_2429 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str4);
                break;
              }
              case TAG_Cons: {
                V v_x_2427 = heff_field(v_x2_2426, 0);
                V v_xs_2428 = heff_field(v_x2_2426, 1);
                heff_take_n(v_x2_2426, 3ULL, 2);
                v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str5); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
                break;
              }
              default: heff_nomatch(v_x2_2426);
              }
              V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2425, v_t_2429), v_js_2419);
              V v_t_2433;
              switch (heff_tag_of(v_js_2420)) {
              case TAG_Nil: {
                v_t_2433 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str6);
                break;
              }
              case TAG_Cons: {
                V v_x_2431 = heff_field(v_js_2420, 0);
                V v_xs_2432 = heff_field(v_js_2420, 1);
                heff_take_n(v_js_2420, 3ULL, 2);
                v_t_2433 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eassembled_str7); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
                break;
              }
              default: heff_nomatch(v_js_2420);
              }
              V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemit_2eassembled_str8)), v_t_2433);
              v_t_2435 = heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemit_2eassembled_str9)), NTAG(TAG_Nil)});
            } else {
              heff_drop_cell(v_ru_24x_246_24MkPair, 2);
              heff_drop(v_js_2419);
              heff_drop(v_js_2420);
              heff_drop(v_field_2423);
              v_t_2435 = NTAG(TAG_Nil);
            }
          }
        } else {
          heff_drop_cell(v_ru_24x_246_24MkPair, 2);
          heff_drop(v_curried_2415);
          heff_drop(v_key_2416);
          heff_drop(v_js_2419);
          heff_drop(v_js_2420);
          v_t_2435 = NTAG(TAG_Nil);
        }
        v_t_2436 = (g_prelude_2e_2b_2b(v_lines_249, v_t_2435));
      } else {
        heff_drop(v_curried_242);
        heff_drop(v_key_247);
        heff_drop_cell(v_ru_24x_246_24MkPair, 2);
        heff_drop(v_params_2410);
        heff_drop(v_field_2413);
        v_t_2436 = v_lines_249;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  return (g_prelude_2e_2b_2b(v_t_2436, v_acc_245));
}
V g_heff_2ecompile_2eemit_2eassembled_lam1(V self, V *args) {
  V v_acc_2443 = args[0];
  V v_x_2444 = args[1];
  V v_uses_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_uses_2445 = v_uses_2440;
  V v_p_2446 = v_x_2444;
  V v_p_2447 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_2446));
  V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eassembled_str10), heff_dup(v_p_2447)), ((V)&g_heff_2ecompile_2eemit_2eassembled_str11));
  HeffT2 v_t_2449 = ({ V a_0 = v_uses_2445; V a_1 = v_t_2448; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2448); r_; });
  V v_t_2464;
  {
    V v_field_2451 = v_t_2449.f[1];
    int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
    if ((v_tag_2450 == ((int64_t)0ULL))) {
      heff_drop(v_p_2447);
      V v_x_2452 = v_field_2451;
      heff_drop(v_x_2452);
      V v_t_2453 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_2446));
      V v_js_2454 = ({ V a_0 = v_p_2446; V r_ = (g_heff_2ecompile_2eprims_2eprimJs(a_0)); heff_drop(v_p_2446); r_; });
      V v_t_2455 = (g_heff_2ecompile_2eemit_2euncurryGo(NTAG(TAG_Nil), v_js_2454));
      v_t_2464 = ({ V a_0 = v_uses_2445; V a_1 = v_t_2453; V a_2 = v_t_2455; V r_ = (g_heff_2ecompile_2eemit_2eprimHelperU(a_0, a_1, a_2)); heff_drop(v_uses_2445); r_; });
    } else {
      heff_drop(v_field_2451);
      V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eassembled_str12), v_p_2447), ((V)&g_heff_2ecompile_2eemit_2eassembled_str13));
      HeffT2 v_t_2457 = ({ V a_0 = v_uses_2445; V a_1 = v_t_2456; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2456); r_; });
      {
        V v_field_2459 = v_t_2457.f[1];
        int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
        if ((v_tag_2458 == ((int64_t)0ULL))) {
          V v_x_2460 = v_field_2459;
          heff_drop(v_x_2460);
          V v_t_2461 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_2446));
          V v_js_2462 = ({ V a_0 = v_p_2446; V r_ = (g_heff_2ecompile_2eprims_2eprimJs(a_0)); heff_drop(v_p_2446); r_; });
          V v_t_2463 = (g_heff_2ecompile_2eemit_2euncurryGo(NTAG(TAG_Nil), v_js_2462));
          v_t_2464 = ({ V a_0 = v_uses_2445; V a_1 = v_t_2461; V a_2 = v_t_2463; V r_ = (g_heff_2ecompile_2eemit_2eprimHelperU(a_0, a_1, a_2)); heff_drop(v_uses_2445); r_; });
        } else {
          heff_drop(v_uses_2445);
          heff_drop(v_p_2446);
          heff_drop(v_field_2459);
          v_t_2464 = NTAG(TAG_Nil);
        }
      }
    }
  }
  return (g_prelude_2e_2b_2b(v_t_2464, v_acc_2443));
}
HEFF_LIT(g_heff_2ecompile_2eemit_2erunStr_str0, 361, "let $performer;\012const $run = (entry, perform) => {\012  const later = typeof setImmediate === \"function\" \? setImmediate : (f) => setTimeout(f, 0);\012  let depth = 0;\012  const now = (k) => (x) => { x = $tr(x); if (depth > 1000) { depth = 0; later(() => $tr(k(x))); return; } depth++; $tr(k(x)); };\012  $performer = (p, k) => perform(p, now(k));\012  return $tr(entry());\012};");

static V g_heff_2ecompile_2eemit_2erunStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2erunStr_st;
static V g_heff_2ecompile_2eemit_2erunStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2erunStr_str0);
}
V g_heff_2ecompile_2eemit_2erunStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2erunStr_st)) return g_heff_2ecompile_2eemit_2erunStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2erunStr_val, &g_heff_2ecompile_2eemit_2erunStr_st, g_heff_2ecompile_2eemit_2erunStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esumStr_str0, 77, "const $sum = (l, r) => (p, k) => p.$ === \"InL\" \? l(p.a[0], k) : r(p.a[0], k);");

static V g_heff_2ecompile_2eemit_2esumStr_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2esumStr_st;
static V g_heff_2ecompile_2eemit_2esumStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2esumStr_str0);
}
V g_heff_2ecompile_2eemit_2esumStr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2esumStr_st)) return g_heff_2ecompile_2eemit_2esumStr_val;
  return heff_global(&g_heff_2ecompile_2eemit_2esumStr_val, &g_heff_2ecompile_2eemit_2esumStr_st, g_heff_2ecompile_2eemit_2esumStr_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str0, 3, "// ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str1, 12, ".provider.js");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str2, 8, "const $p");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str3, 11, " = (() => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str4, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str5, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str6, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str7, 13, "export const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str8, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str9, 7, "import ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str10, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str11, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str12, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str14, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str15, 9, "return { ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str16, 3, " };");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str17, 5, "})();");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebundleProvider_str18, 1, "\012");
Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleProvider_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleProvider(V v_i_240, V v_p_241) {
top: ;
  V v_module_242 = heff_take_field(v_p_241, 0);
  V v_text_243 = heff_get_n(v_p_241, 1, 2);
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str0), v_module_242), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str1));
  V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str2), heff_intShow(v_i_240));
  V v_t_246 = heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str3));
  V v_t_247 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str4)), v_t_246);
  V v_s_248 = heff_dup(v_text_243);
  V v_t_249 = ({ V a_0 = v_s_248; V b_1 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str5); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str6), v_s_248, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_248); heff_drop(b_1); r_; });
  V v_t_2410 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(13LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str7); V a_3 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str8); V b_4 = MK_INT(13LL); V b_5 = MK_INT(0LL); V b_6 = MK_INT(7LL); V b_7 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str9); V a_8 = v_t_249; V r_ = (g_list_2emap_24f1952774010x636070089(b_0, b_1, b_2, a_3, b_4, b_5, b_6, b_7, a_8)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_6); heff_drop(b_7); r_; });
  V v_text_2411 = v_text_243;
  V v_t_2412 = ({ V a_0 = v_text_2411; V b_1 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str10); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str11), v_text_2411, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_text_2411); heff_drop(b_1); r_; });
  V v_t_2413 = (g_list_2emap_24s732475005x1616712052(v_t_2412));
  V v_x2_2414 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str12); V a_3 = v_t_2413; V r_ = (g_list_2ekeepIf_24f428638463x2144521938(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str13);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str14); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str15), v_t_2417), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str16));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str17), NTAG(TAG_Nil)});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str18); V a_1 = v_t_247; V a_2 = v_t_2410; V b_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2419}); V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, b_3)); heff_drop(v_t_2410); heff_drop(b_3); r_; });
}
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleProvider(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_cell_246;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleAll_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2eemit_2efindProv_24cpr(V v_md_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(v_md_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_p_242)}});
    } else {
      V t_0 = v_md_240;
      V t_1 = v_rest_243;
      v_md_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovsForGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprovsForGo(V v_available_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_md_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = ({ V a_0 = v_md_242; V a_1 = v_available_240; HeffT2 r_ = (g_heff_2ecompile_2eemit_2efindProv_24cpr(a_0, a_1)); heff_drop(v_md_242); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_p_247 = v_field_246;
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_p_247, heff_hole()});
        V v_u_249 = (g_heff_2ecompile_2eemit_2eprovsForGo_24dps(v_available_240, v_rest_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_246);
        V t_0 = v_available_240;
        V t_1 = v_rest_243;
        v_available_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprovsForGo(a0, a[1]); heff_drop(a0); return r;
}