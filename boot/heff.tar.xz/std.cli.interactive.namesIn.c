// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_MkPath 49630
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_Regular 40886
#define TAG_Right 62770
#define LBL_kind 9787483
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(V, V, V);
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str4, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str5, 1, "/");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str8, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str9, 0, "");
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam0(V self, V *args); static Clo g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam0, 1, 0};
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam2(V self, V *args);
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam3(V self, V *args);
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam4(V self, V *args);
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam5(V self, V *args);
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam6(V self, V *args);
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam1(V self, V *args);
Clo g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_entry, 3, 0};

V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_z_241);
    return heff_tail(v_z_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_q_243 = heff_field(v_x1_240, 0);
    V v_qs_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_q_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_247 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_245, NTAG(TAG_True), ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam0_clo)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    HEFF_LAST return g_co_2eop_24s535099379x685970669(v_t_2412, heff_dup(v_z_241), heff_clo_n(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam1, 1, 4, (V[]){v_qs_244, v_z_241, v_q_243, v_z_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(a[0], a[1], a[2]);
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_q_243 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_t_2419;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPath: {
    V v_xs_2418 = heff_field(v_q_243, 2);
    heff_take_n(v_q_243, 4ULL, 3);
    v_t_2419 = v_xs_2418;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2419));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x1_2420, 0);
    heff_take_n(v_x1_2420, 1ULL, 2);
    v_t_2423 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2420);
  }
  V v_x_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2423, ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str1)), v_x_2415});
  V f_ = v_z_242;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_q_243 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_t_2431;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPath: {
    V v_xs_2430 = heff_field(v_q_243, 2);
    heff_take_n(v_q_243, 4ULL, 3);
    v_t_2431 = v_xs_2430;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_x1_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2431));
  V v_t_2435;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nil: {
    v_t_2435 = ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 2);
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V v_x_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2435, ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str3)), v_x_2427});
  V f_ = v_z_242;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_q_243 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_t_2441;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPath: {
    V v_xs_2440 = heff_field(v_q_243, 2);
    heff_take_n(v_q_243, 4ULL, 3);
    v_t_2441 = v_xs_2440;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_x1_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2441));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nil: {
    v_t_2445 = ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 2);
    v_t_2445 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_x_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str5)), v_x_2437});
  V f_ = v_z_242;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam5(V self, V *args) {
  V v_x_2447 = args[0];
  V v_q_243 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_t_2451;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPath: {
    V v_xs_2450 = heff_field(v_q_243, 2);
    heff_take_n(v_q_243, 4ULL, 3);
    v_t_2451 = v_xs_2450;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_x1_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2451));
  V v_t_2455;
  switch (heff_tag_of(v_x1_2452)) {
  case TAG_Nil: {
    v_t_2455 = ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x1_2452, 0);
    heff_take_n(v_x1_2452, 1ULL, 2);
    v_t_2455 = v_x_2453;
    break;
  }
  default: heff_nomatch(v_x1_2452);
  }
  V v_x_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2455, ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str7)), v_x_2447});
  V f_ = v_z_242;
  args[0] = v_x_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam6(V self, V *args) {
  V v_x_2457 = args[0];
  V v_q_243 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_t_2461;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_q_243)) {
  case TAG_MkPath: {
    V v_xs_2460 = heff_field(v_q_243, 2);
    heff_take_n(v_q_243, 4ULL, 3);
    v_t_2461 = v_xs_2460;
    break;
  }
  default: heff_nomatch(v_q_243);
  }
  V v_x1_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2461));
  V v_t_2465;
  switch (heff_tag_of(v_x1_2462)) {
  case TAG_Nil: {
    v_t_2465 = ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2463 = heff_field(v_x1_2462, 0);
    heff_take_n(v_x1_2462, 1ULL, 2);
    v_t_2465 = v_x_2463;
    break;
  }
  default: heff_nomatch(v_x1_2462);
  }
  V v_x_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2465, ((V)&g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_str9)), v_x_2457});
  V f_ = v_z_242;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_qs_244 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_q_243 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    heff_clo_take(self, 4);
    return (g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(v_qs_244, v_z_241, heff_clo_n(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam2, 1, 2, (V[]){v_q_243, v_z_242})));
  }
  case TAG_Right: {
    V v_s_2425 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    V v_t_2426 = heff_get_n(v_s_2425, 0, 4);
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Regular: {
      heff_clo_take(self, 4);
      return (g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(v_qs_244, v_z_241, heff_clo_n(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam3, 1, 2, (V[]){v_q_243, v_z_242})));
    }
    case TAG_Directory: {
      heff_clo_take(self, 4);
      return (g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(v_qs_244, v_z_241, heff_clo_n(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam4, 1, 2, (V[]){v_q_243, v_z_242})));
    }
    case TAG_Link: {
      heff_clo_take(self, 4);
      return (g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(v_qs_244, v_z_241, heff_clo_n(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam5, 1, 2, (V[]){v_q_243, v_z_242})));
    }
    case TAG_Other: {
      heff_clo_take(self, 4);
      return (g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(v_qs_244, v_z_241, heff_clo_n(g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_lam6, 1, 2, (V[]){v_q_243, v_z_242})));
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}