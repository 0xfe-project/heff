// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eprims_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eprims_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str3 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 45, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eprims_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str5 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 42, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eprims_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[133]; } g_heff_2eprims_2eprims_str7 = {{0x80000000u, K_STR, 0}, 133, 133, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 48, 110, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 113, 32, 61, 32, 97, 32, 47, 32, 98, 44, 32, 114, 32, 61, 32, 97, 32, 37, 32, 98, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 32, 33, 61, 61, 32, 48, 110, 32, 38, 38, 32, 40, 114, 32, 60, 32, 48, 110, 41, 32, 33, 61, 61, 32, 40, 98, 32, 60, 32, 48, 110, 41, 32, 63, 32, 113, 32, 45, 32, 49, 110, 32, 58, 32, 113, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eprims_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[121]; } g_heff_2eprims_2eprims_str9 = {{0x80000000u, K_STR, 0}, 121, 121, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 48, 110, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 114, 32, 61, 32, 97, 32, 37, 32, 98, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 32, 33, 61, 61, 32, 48, 110, 32, 38, 38, 32, 40, 114, 32, 60, 32, 48, 110, 41, 32, 33, 61, 61, 32, 40, 98, 32, 60, 32, 48, 110, 41, 32, 63, 32, 114, 32, 43, 32, 98, 32, 58, 32, 114, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eprims_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2eprims_str11 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eprims_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2eprims_str13 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eprims_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2eprims_str15 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2eprims_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str17 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 97, 46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str18 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str19 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str20 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str21 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 45, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str22 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str23 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 42, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str24 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str25 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 47, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2eprims_str26 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2eprims_str27 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2eprims_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2eprims_str29 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2eprims_str30 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2eprims_str31 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2eprims_str32 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[70]; } g_heff_2eprims_2eprims_str33 = {{0x80000000u, K_STR, 0}, 70, 70, {40, 97, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 115, 32, 61, 32, 83, 116, 114, 105, 110, 103, 40, 97, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 105, 115, 78, 97, 78, 40, 115, 32, 43, 32, 34, 46, 48, 34, 41, 32, 63, 32, 115, 32, 58, 32, 115, 32, 43, 32, 34, 46, 48, 34, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprims_2eprims_str34 = {{0x80000000u, K_STR, 0}, 12, 12, {102, 108, 111, 97, 116, 70, 114, 111, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eprims_2eprims_str35 = {{0x80000000u, K_STR, 0}, 16, 16, {40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2eprims_str36 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 113, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str37 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 115, 113, 114, 116, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprims_2eprims_str38 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 70, 108, 111, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2eprims_2eprims_str39 = {{0x80000000u, K_STR, 0}, 62, 62, {40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 46, 105, 115, 70, 105, 110, 105, 116, 101, 40, 97, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 77, 97, 116, 104, 46, 102, 108, 111, 111, 114, 40, 97, 41, 41, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str40 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2eprims_str41 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 115, 105, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str42 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 67, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2eprims_str43 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 99, 111, 115, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str44 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 84, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2eprims_str45 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 116, 97, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2eprims_str46 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 115, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str47 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 115, 105, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2eprims_str48 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 99, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str49 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 99, 111, 115, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2eprims_str50 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 116, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str51 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 116, 97, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprims_2eprims_str52 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 65, 116, 97, 110, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2eprims_str53 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 116, 97, 110, 50, 40, 97, 44, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str54 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 69, 120, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2eprims_str55 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 101, 120, 112, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str56 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 76, 111, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2eprims_str57 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 108, 111, 103, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str58 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 80, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[84]; } g_heff_2eprims_2eprims_str59 = {{0x80000000u, K_STR, 0}, 84, 84, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 49, 32, 124, 124, 32, 40, 97, 32, 61, 61, 61, 32, 45, 49, 32, 38, 38, 32, 77, 97, 116, 104, 46, 97, 98, 115, 40, 98, 41, 32, 61, 61, 61, 32, 73, 110, 102, 105, 110, 105, 116, 121, 41, 32, 63, 32, 49, 32, 58, 32, 77, 97, 116, 104, 46, 112, 111, 119, 40, 97, 44, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprims_2eprims_str60 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eprims_2eprims_str61 = {{0x80000000u, K_STR, 0}, 23, 23, {40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprims_2eprims_str62 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 114, 114, 97, 121, 73, 110, 100, 101, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[73]; } g_heff_2eprims_2eprims_str63 = {{0x80000000u, K_STR, 0}, 73, 73, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 32, 63, 32, 97, 91, 78, 117, 109, 98, 101, 114, 40, 105, 41, 93, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str64 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 114, 97, 121, 83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[132]; } g_heff_2eprims_2eprims_str65 = {{0x80000000u, K_STR, 0}, 132, 132, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 40, 120, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 33, 40, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 41, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 98, 32, 61, 32, 97, 46, 115, 108, 105, 99, 101, 40, 41, 59, 32, 98, 91, 78, 117, 109, 98, 101, 114, 40, 105, 41, 93, 32, 61, 32, 120, 59, 32, 114, 101, 116, 117, 114, 110, 32, 98, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprims_2eprims_str66 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[89]; } g_heff_2eprims_2eprims_str67 = {{0x80000000u, K_STR, 0}, 89, 89, {40, 110, 41, 32, 61, 62, 32, 40, 102, 41, 32, 61, 62, 32, 65, 114, 114, 97, 121, 46, 102, 114, 111, 109, 40, 123, 32, 108, 101, 110, 103, 116, 104, 58, 32, 110, 32, 62, 32, 48, 110, 32, 63, 32, 78, 117, 109, 98, 101, 114, 40, 110, 41, 32, 58, 32, 48, 32, 125, 44, 32, 40, 95, 44, 32, 107, 41, 32, 61, 62, 32, 36, 116, 114, 40, 102, 40, 66, 105, 103, 73, 110, 116, 40, 107, 41, 41, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprims_2eprims_str68 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 70, 114, 111, 109, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[89]; } g_heff_2eprims_2eprims_str69 = {{0x80000000u, K_STR, 0}, 89, 89, {40, 108, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 114, 32, 61, 32, 91, 93, 59, 32, 119, 104, 105, 108, 101, 32, 40, 108, 46, 36, 32, 61, 61, 61, 32, 34, 67, 111, 110, 115, 34, 41, 32, 123, 32, 114, 46, 112, 117, 115, 104, 40, 108, 46, 97, 91, 48, 93, 41, 59, 32, 108, 32, 61, 32, 108, 46, 97, 91, 49, 93, 59, 32, 125, 32, 114, 101, 116, 117, 114, 110, 32, 114, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprims_2eprims_str70 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 84, 111, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[85]; } g_heff_2eprims_2eprims_str71 = {{0x80000000u, K_STR, 0}, 85, 85, {40, 97, 41, 32, 61, 62, 32, 97, 46, 114, 101, 100, 117, 99, 101, 82, 105, 103, 104, 116, 40, 40, 114, 101, 115, 116, 44, 32, 120, 41, 32, 61, 62, 32, 40, 123, 32, 36, 58, 32, 34, 67, 111, 110, 115, 34, 44, 32, 97, 58, 32, 91, 120, 44, 32, 114, 101, 115, 116, 93, 32, 125, 41, 44, 32, 123, 32, 36, 58, 32, 34, 78, 105, 108, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2eprims_str72 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eprims_str73 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2eprims_str74 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eprims_2eprims_str75 = {{0x80000000u, K_STR, 0}, 23, 23, {40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eprims_str76 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 116, 114, 83, 108, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2eprims_2eprims_str77 = {{0x80000000u, K_STR, 0}, 50, 50, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 40, 106, 41, 32, 61, 62, 32, 97, 46, 115, 108, 105, 99, 101, 40, 78, 117, 109, 98, 101, 114, 40, 105, 41, 44, 32, 78, 117, 109, 98, 101, 114, 40, 106, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eprims_str78 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2eprims_str79 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eprims_str80 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2eprims_str81 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprims_2eprims_str82 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 114, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[85]; } g_heff_2eprims_2eprims_str83 = {{0x80000000u, K_STR, 0}, 85, 85, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 99, 104, 97, 114, 67, 111, 100, 101, 65, 116, 40, 78, 117, 109, 98, 101, 114, 40, 105, 41, 41, 41, 32, 58, 32, 45, 49, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eprims_2eprims_str84 = {{0x80000000u, K_STR, 0}, 15, 15, {115, 116, 114, 70, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[67]; } g_heff_2eprims_2eprims_str85 = {{0x80000000u, K_STR, 0}, 67, 67, {40, 99, 41, 32, 61, 62, 32, 99, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 99, 32, 60, 61, 32, 54, 53, 53, 51, 53, 110, 32, 63, 32, 83, 116, 114, 105, 110, 103, 46, 102, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101, 40, 78, 117, 109, 98, 101, 114, 40, 99, 41, 41, 32, 58, 32, 34, 34}};

static V g_heff_2eprims_2eprims_val;
static int g_heff_2eprims_2eprims_st;
static V g_heff_2eprims_2eprims_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str0), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str1)})});
  V v_t_241 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str2), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str3)})});
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str4), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str5)})});
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str6), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str7)})});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str8), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str9)})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str10), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str11)})});
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str12), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str13)})});
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str14), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str15)})});
  V v_t_248 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str16), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str17)})});
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str18), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str19)})});
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str20), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str21)})});
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str22), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str23)})});
  V v_t_2412 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str24), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str25)})});
  V v_t_2413 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str26), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str27)})});
  V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str28), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str29)})});
  V v_t_2415 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str30), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str31)})});
  V v_t_2416 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str32), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str33)})});
  V v_t_2417 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str34), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str35)})});
  V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str36), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str37)})});
  V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str38), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str39)})});
  V v_t_2420 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str40), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str41)})});
  V v_t_2421 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str42), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str43)})});
  V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str44), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str45)})});
  V v_t_2423 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str46), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str47)})});
  V v_t_2424 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str48), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str49)})});
  V v_t_2425 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str50), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str51)})});
  V v_t_2426 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str52), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str53)})});
  V v_t_2427 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str54), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str55)})});
  V v_t_2428 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str56), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str57)})});
  V v_t_2429 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str58), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str59)})});
  V v_t_2430 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str60), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str61)})});
  V v_t_2431 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str62), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str63)})});
  V v_t_2432 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str64), heff_rec(2, shape_14_150, (V[]){MK_INT(3LL), ((V)&g_heff_2eprims_2eprims_str65)})});
  V v_t_2433 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str66), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str67)})});
  V v_t_2434 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str68), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str69)})});
  V v_t_2435 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str70), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str71)})});
  V v_t_2436 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str72), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str73)})});
  V v_t_2437 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str74), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str75)})});
  V v_t_2438 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str76), heff_rec(2, shape_14_150, (V[]){MK_INT(3LL), ((V)&g_heff_2eprims_2eprims_str77)})});
  V v_t_2439 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str78), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str79)})});
  V v_t_2440 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str80), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str81)})});
  V v_t_2441 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str82), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2eprims_str83)})});
  V v_t_2442 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2eprims_str84), heff_rec(2, shape_14_150, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2eprims_str85)})});
  V v_t_2443 = heff_tag(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
  V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){v_t_2440, heff_tag(TAG_Cons, 2, (V[]){v_t_2441, v_t_2443})});
  V v_t_2445 = heff_tag(TAG_Cons, 2, (V[]){v_t_2438, heff_tag(TAG_Cons, 2, (V[]){v_t_2439, v_t_2444})});
  V v_t_2446 = heff_tag(TAG_Cons, 2, (V[]){v_t_2436, heff_tag(TAG_Cons, 2, (V[]){v_t_2437, v_t_2445})});
  V v_t_2447 = heff_tag(TAG_Cons, 2, (V[]){v_t_2434, heff_tag(TAG_Cons, 2, (V[]){v_t_2435, v_t_2446})});
  V v_t_2448 = heff_tag(TAG_Cons, 2, (V[]){v_t_2432, heff_tag(TAG_Cons, 2, (V[]){v_t_2433, v_t_2447})});
  V v_t_2449 = heff_tag(TAG_Cons, 2, (V[]){v_t_2430, heff_tag(TAG_Cons, 2, (V[]){v_t_2431, v_t_2448})});
  V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){v_t_2428, heff_tag(TAG_Cons, 2, (V[]){v_t_2429, v_t_2449})});
  V v_t_2451 = heff_tag(TAG_Cons, 2, (V[]){v_t_2426, heff_tag(TAG_Cons, 2, (V[]){v_t_2427, v_t_2450})});
  V v_t_2452 = heff_tag(TAG_Cons, 2, (V[]){v_t_2424, heff_tag(TAG_Cons, 2, (V[]){v_t_2425, v_t_2451})});
  V v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, heff_tag(TAG_Cons, 2, (V[]){v_t_2423, v_t_2452})});
  V v_t_2454 = heff_tag(TAG_Cons, 2, (V[]){v_t_2420, heff_tag(TAG_Cons, 2, (V[]){v_t_2421, v_t_2453})});
  V v_t_2455 = heff_tag(TAG_Cons, 2, (V[]){v_t_2418, heff_tag(TAG_Cons, 2, (V[]){v_t_2419, v_t_2454})});
  V v_t_2456 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, heff_tag(TAG_Cons, 2, (V[]){v_t_2417, v_t_2455})});
  V v_t_2457 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, heff_tag(TAG_Cons, 2, (V[]){v_t_2415, v_t_2456})});
  V v_t_2458 = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, heff_tag(TAG_Cons, 2, (V[]){v_t_2413, v_t_2457})});
  V v_t_2459 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, heff_tag(TAG_Cons, 2, (V[]){v_t_2411, v_t_2458})});
  V v_t_2460 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, heff_tag(TAG_Cons, 2, (V[]){v_t_249, v_t_2459})});
  V v_t_2461 = heff_tag(TAG_Cons, 2, (V[]){v_t_246, heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_2460})});
  V v_t_2462 = heff_tag(TAG_Cons, 2, (V[]){v_t_244, heff_tag(TAG_Cons, 2, (V[]){v_t_245, v_t_2461})});
  V v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_2462})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_240, heff_tag(TAG_Cons, 2, (V[]){v_t_241, v_t_2463})});
}
V g_heff_2eprims_2eprims_get(void) {
  if (g_heff_2eprims_2eprims_st == 2) return g_heff_2eprims_2eprims_val;
  if (g_heff_2eprims_2eprims_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2eprims_st = 1;
  g_heff_2eprims_2eprims_val = heff_tr(g_heff_2eprims_2eprims_init());
  g_heff_2eprims_2eprims_st = 2;
  return g_heff_2eprims_2eprims_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2einternal_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 101, 114, 102, 111, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2einternal_str1 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 112, 41, 32, 61, 62, 32, 40, 107, 41, 32, 61, 62, 32, 36, 112, 101, 114, 102, 111, 114, 109, 101, 114, 40, 112, 44, 32, 107, 41}};

static V g_heff_2eprims_2einternal_val;
static int g_heff_2eprims_2einternal_st;
static V g_heff_2eprims_2einternal_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2einternal_str0), heff_rec(2, shape_14_150, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2einternal_str1)})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_240, NTAG(TAG_Nil)});
}
V g_heff_2eprims_2einternal_get(void) {
  if (g_heff_2eprims_2einternal_st == 2) return g_heff_2eprims_2einternal_val;
  if (g_heff_2eprims_2einternal_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2einternal_st = 1;
  g_heff_2eprims_2einternal_val = heff_tr(g_heff_2eprims_2einternal_init());
  g_heff_2eprims_2einternal_st = 2;
  return g_heff_2eprims_2einternal_val;
}

static V g_heff_2eprims_2eallPrims_val;
static int g_heff_2eprims_2eallPrims_st;
static V g_heff_2eprims_2eallPrims_init(void) {
  return (g_prelude_2econcatList(heff_dup(g_heff_2eprims_2eprims_get()), heff_dup(g_heff_2eprims_2einternal_get())));
}
V g_heff_2eprims_2eallPrims_get(void) {
  if (g_heff_2eprims_2eallPrims_st == 2) return g_heff_2eprims_2eallPrims_val;
  if (g_heff_2eprims_2eallPrims_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2eallPrims_st = 1;
  g_heff_2eprims_2eallPrims_val = heff_tr(g_heff_2eprims_2eallPrims_init());
  g_heff_2eprims_2eallPrims_st = 2;
  return g_heff_2eprims_2eallPrims_val;
}
Clo g_heff_2eprims_2eprimArityGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprims_2eprimArityGo_entry, 2, 0};

V g_heff_2eprims_2eprimArityGo(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_i_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_strEq(heff_dup(v_k_244), heff_dup(v_p_240));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_p_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_i_245), LBL_arity)});
      }
      case TAG_False: {
        V t_0 = v_p_240;
        V t_1 = v_rest_243;
        v_p_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprims_2eprimArityGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprims_2eprimArityGo(a[0], a[1]); heff_drop(a[1]); return r;
}