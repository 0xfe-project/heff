// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_fixed 298804110
#define LBL_js 10160
#define LBL_op 10312
static uint32_t shape_arity__js[] = {LBL_arity, LBL_js};
V g_heff_2efixed_2efixedPrimName(V);
V g_heff_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2efixed_2efixedPrimName_clo;
V g_heff_2efixed_2efixedPrims_get(void);
V g_heff_2eprims_2eallPrims_get(void);
V g_heff_2eprims_2ebasicPrims_get(void);
V g_heff_2eprims_2efixedImpl(V);
V g_heff_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2eprims_2efixedImpl_clo;
V g_heff_2eprims_2efixedJs(V);
V g_heff_2eprims_2efixedJs_entry(V self, V *a);
extern Clo g_heff_2eprims_2efixedJs_clo;
V g_heff_2eprims_2efloat32ShowJs_get(void);
V g_heff_2eprims_2eintOpJs(V, V);
V g_heff_2eprims_2eintOpJs_entry(V self, V *a);
extern Clo g_heff_2eprims_2eintOpJs_clo;
V g_heff_2eprims_2einternal_get(void);
V g_heff_2eprims_2enarrowJs(V, V);
V g_heff_2eprims_2enarrowJs_entry(V self, V *a);
extern Clo g_heff_2eprims_2enarrowJs_clo;
V g_heff_2eprims_2eprimArityGo(V, V);
V g_heff_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2eprims_2eprimArityGo_clo;
V g_heff_2eprims_2eprims_get(void);
V g_heff_2eprims_2eshiftMaskJs(V);
V g_heff_2eprims_2eshiftMaskJs_entry(V self, V *a);
extern Clo g_heff_2eprims_2eshiftMaskJs_clo;
V g_list_2emap_24s420379013x173468973(V);
V g_list_2emap_24s420379013x173468973_entry(V self, V *a);
extern Clo g_list_2emap_24s420379013x173468973_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str1 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str3 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 45, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str5 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 42, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[133]; } g_heff_2eprims_2ebasicPrims_str7 = {{0x80000000u, K_STR, 0}, 133, 133, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 48, 110, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 113, 32, 61, 32, 97, 32, 47, 32, 98, 44, 32, 114, 32, 61, 32, 97, 32, 37, 32, 98, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 32, 33, 61, 61, 32, 48, 110, 32, 38, 38, 32, 40, 114, 32, 60, 32, 48, 110, 41, 32, 33, 61, 61, 32, 40, 98, 32, 60, 32, 48, 110, 41, 32, 63, 32, 113, 32, 45, 32, 49, 110, 32, 58, 32, 113, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 111, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[121]; } g_heff_2eprims_2ebasicPrims_str9 = {{0x80000000u, K_STR, 0}, 121, 121, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 98, 32, 61, 61, 61, 32, 48, 110, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 114, 32, 61, 32, 97, 32, 37, 32, 98, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 32, 33, 61, 61, 32, 48, 110, 32, 38, 38, 32, 40, 114, 32, 60, 32, 48, 110, 41, 32, 33, 61, 61, 32, 40, 98, 32, 60, 32, 48, 110, 41, 32, 63, 32, 114, 32, 43, 32, 98, 32, 58, 32, 114, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2ebasicPrims_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2ebasicPrims_str11 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2ebasicPrims_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2ebasicPrims_str13 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2ebasicPrims_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2ebasicPrims_str15 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2ebasicPrims_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str17 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 97, 46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str19 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 38, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2ebasicPrims_str20 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 79, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str21 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 124, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str22 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 88, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str23 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 94, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str24 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 104, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eprims_2ebasicPrims_str25 = {{0x80000000u, K_STR, 0}, 42, 42, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 98, 32, 60, 32, 48, 110, 32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32, 97, 32, 60, 60, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2ebasicPrims_str26 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 104, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eprims_2ebasicPrims_str27 = {{0x80000000u, K_STR, 0}, 42, 42, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 98, 32, 60, 32, 48, 110, 32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32, 97, 32, 62, 62, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str28 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str29 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str30 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str31 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 45, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str33 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 42, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str34 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str35 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 47, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2ebasicPrims_str36 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2ebasicPrims_str37 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2ebasicPrims_str38 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2ebasicPrims_str39 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2ebasicPrims_str40 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2ebasicPrims_str41 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2ebasicPrims_str42 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[70]; } g_heff_2eprims_2ebasicPrims_str43 = {{0x80000000u, K_STR, 0}, 70, 70, {40, 97, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 115, 32, 61, 32, 83, 116, 114, 105, 110, 103, 40, 97, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 105, 115, 78, 97, 78, 40, 115, 32, 43, 32, 34, 46, 48, 34, 41, 32, 63, 32, 115, 32, 58, 32, 115, 32, 43, 32, 34, 46, 48, 34, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprims_2ebasicPrims_str44 = {{0x80000000u, K_STR, 0}, 12, 12, {102, 108, 111, 97, 116, 70, 114, 111, 109, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eprims_2ebasicPrims_str45 = {{0x80000000u, K_STR, 0}, 16, 16, {40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2ebasicPrims_str46 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 83, 113, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str47 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 115, 113, 114, 116, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprims_2ebasicPrims_str48 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 70, 108, 111, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2eprims_2ebasicPrims_str49 = {{0x80000000u, K_STR, 0}, 62, 62, {40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 46, 105, 115, 70, 105, 110, 105, 116, 101, 40, 97, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 77, 97, 116, 104, 46, 102, 108, 111, 111, 114, 40, 97, 41, 41, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str50 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2ebasicPrims_str51 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 115, 105, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str52 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 67, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2ebasicPrims_str53 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 99, 111, 115, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str54 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 84, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2ebasicPrims_str55 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 116, 97, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2ebasicPrims_str56 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 115, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str57 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 115, 105, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2ebasicPrims_str58 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 99, 111, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str59 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 99, 111, 115, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2ebasicPrims_str60 = {{0x80000000u, K_STR, 0}, 9, 9, {102, 108, 111, 97, 116, 65, 116, 97, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str61 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 116, 97, 110, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprims_2ebasicPrims_str62 = {{0x80000000u, K_STR, 0}, 10, 10, {102, 108, 111, 97, 116, 65, 116, 97, 110, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2ebasicPrims_str63 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 97, 116, 97, 110, 50, 40, 97, 44, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str64 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 69, 120, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2ebasicPrims_str65 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 101, 120, 112, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str66 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 76, 111, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2ebasicPrims_str67 = {{0x80000000u, K_STR, 0}, 18, 18, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 108, 111, 103, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str68 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 80, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[84]; } g_heff_2eprims_2ebasicPrims_str69 = {{0x80000000u, K_STR, 0}, 84, 84, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 49, 32, 124, 124, 32, 40, 97, 32, 61, 61, 61, 32, 45, 49, 32, 38, 38, 32, 77, 97, 116, 104, 46, 97, 98, 115, 40, 98, 41, 32, 61, 61, 61, 32, 73, 110, 102, 105, 110, 105, 116, 121, 41, 32, 63, 32, 49, 32, 58, 32, 77, 97, 116, 104, 46, 112, 111, 119, 40, 97, 44, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprims_2ebasicPrims_str70 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eprims_2ebasicPrims_str71 = {{0x80000000u, K_STR, 0}, 23, 23, {40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprims_2ebasicPrims_str72 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 114, 114, 97, 121, 73, 110, 100, 101, 120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[73]; } g_heff_2eprims_2ebasicPrims_str73 = {{0x80000000u, K_STR, 0}, 73, 73, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 32, 63, 32, 97, 91, 78, 117, 109, 98, 101, 114, 40, 105, 41, 93, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str74 = {{0x80000000u, K_STR, 0}, 8, 8, {97, 114, 114, 97, 121, 83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[132]; } g_heff_2eprims_2ebasicPrims_str75 = {{0x80000000u, K_STR, 0}, 132, 132, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 40, 120, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 33, 40, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 41, 41, 32, 114, 101, 116, 117, 114, 110, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 59, 32, 99, 111, 110, 115, 116, 32, 98, 32, 61, 32, 97, 46, 115, 108, 105, 99, 101, 40, 41, 59, 32, 98, 91, 78, 117, 109, 98, 101, 114, 40, 105, 41, 93, 32, 61, 32, 120, 59, 32, 114, 101, 116, 117, 114, 110, 32, 98, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprims_2ebasicPrims_str76 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 71, 101, 110, 101, 114, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[89]; } g_heff_2eprims_2ebasicPrims_str77 = {{0x80000000u, K_STR, 0}, 89, 89, {40, 110, 41, 32, 61, 62, 32, 40, 102, 41, 32, 61, 62, 32, 65, 114, 114, 97, 121, 46, 102, 114, 111, 109, 40, 123, 32, 108, 101, 110, 103, 116, 104, 58, 32, 110, 32, 62, 32, 48, 110, 32, 63, 32, 78, 117, 109, 98, 101, 114, 40, 110, 41, 32, 58, 32, 48, 32, 125, 44, 32, 40, 95, 44, 32, 107, 41, 32, 61, 62, 32, 36, 116, 114, 40, 102, 40, 66, 105, 103, 73, 110, 116, 40, 107, 41, 41, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprims_2ebasicPrims_str78 = {{0x80000000u, K_STR, 0}, 13, 13, {97, 114, 114, 97, 121, 70, 114, 111, 109, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[89]; } g_heff_2eprims_2ebasicPrims_str79 = {{0x80000000u, K_STR, 0}, 89, 89, {40, 108, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 114, 32, 61, 32, 91, 93, 59, 32, 119, 104, 105, 108, 101, 32, 40, 108, 46, 36, 32, 61, 61, 61, 32, 34, 67, 111, 110, 115, 34, 41, 32, 123, 32, 114, 46, 112, 117, 115, 104, 40, 108, 46, 97, 91, 48, 93, 41, 59, 32, 108, 32, 61, 32, 108, 46, 97, 91, 49, 93, 59, 32, 125, 32, 114, 101, 116, 117, 114, 110, 32, 114, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprims_2ebasicPrims_str80 = {{0x80000000u, K_STR, 0}, 11, 11, {97, 114, 114, 97, 121, 84, 111, 76, 105, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[85]; } g_heff_2eprims_2ebasicPrims_str81 = {{0x80000000u, K_STR, 0}, 85, 85, {40, 97, 41, 32, 61, 62, 32, 97, 46, 114, 101, 100, 117, 99, 101, 82, 105, 103, 104, 116, 40, 40, 114, 101, 115, 116, 44, 32, 120, 41, 32, 61, 62, 32, 40, 123, 32, 36, 58, 32, 34, 67, 111, 110, 115, 34, 44, 32, 97, 58, 32, 91, 120, 44, 32, 114, 101, 115, 116, 93, 32, 125, 41, 44, 32, 123, 32, 36, 58, 32, 34, 78, 105, 108, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2ebasicPrims_str82 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2ebasicPrims_str83 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 43, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2ebasicPrims_str84 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eprims_2ebasicPrims_str85 = {{0x80000000u, K_STR, 0}, 23, 23, {40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2ebasicPrims_str86 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 116, 114, 83, 108, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[50]; } g_heff_2eprims_2ebasicPrims_str87 = {{0x80000000u, K_STR, 0}, 50, 50, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 40, 106, 41, 32, 61, 62, 32, 97, 46, 115, 108, 105, 99, 101, 40, 78, 117, 109, 98, 101, 114, 40, 105, 41, 44, 32, 78, 117, 109, 98, 101, 114, 40, 106, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2ebasicPrims_str88 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2ebasicPrims_str89 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2ebasicPrims_str90 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2ebasicPrims_str91 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eprims_2ebasicPrims_str92 = {{0x80000000u, K_STR, 0}, 11, 11, {115, 116, 114, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[85]; } g_heff_2eprims_2ebasicPrims_str93 = {{0x80000000u, K_STR, 0}, 85, 85, {40, 97, 41, 32, 61, 62, 32, 40, 105, 41, 32, 61, 62, 32, 105, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 105, 32, 60, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 108, 101, 110, 103, 116, 104, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 97, 46, 99, 104, 97, 114, 67, 111, 100, 101, 65, 116, 40, 78, 117, 109, 98, 101, 114, 40, 105, 41, 41, 41, 32, 58, 32, 45, 49, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eprims_2ebasicPrims_str94 = {{0x80000000u, K_STR, 0}, 15, 15, {115, 116, 114, 70, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[67]; } g_heff_2eprims_2ebasicPrims_str95 = {{0x80000000u, K_STR, 0}, 67, 67, {40, 99, 41, 32, 61, 62, 32, 99, 32, 62, 61, 32, 48, 110, 32, 38, 38, 32, 99, 32, 60, 61, 32, 54, 53, 53, 51, 53, 110, 32, 63, 32, 83, 116, 114, 105, 110, 103, 46, 102, 114, 111, 109, 67, 104, 97, 114, 67, 111, 100, 101, 40, 78, 117, 109, 98, 101, 114, 40, 99, 41, 41, 32, 58, 32, 34, 34}};

static V g_heff_2eprims_2ebasicPrims_val;
static int g_heff_2eprims_2ebasicPrims_st;
static V g_heff_2eprims_2ebasicPrims_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str0), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str1)})});
  V v_t_241 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str2), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str3)})});
  V v_t_242 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str4), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str5)})});
  V v_t_243 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str6), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str7)})});
  V v_t_244 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str8), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str9)})});
  V v_t_245 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str10), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str11)})});
  V v_t_246 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str12), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str13)})});
  V v_t_247 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str14), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str15)})});
  V v_t_248 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str16), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str17)})});
  V v_t_249 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str18), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str19)})});
  V v_t_2410 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str20), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str21)})});
  V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str22), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str23)})});
  V v_t_2412 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str24), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str25)})});
  V v_t_2413 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str26), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str27)})});
  V v_t_2414 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str28), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str29)})});
  V v_t_2415 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str30), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str31)})});
  V v_t_2416 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str32), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str33)})});
  V v_t_2417 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str34), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str35)})});
  V v_t_2418 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str36), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str37)})});
  V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str38), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str39)})});
  V v_t_2420 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str40), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str41)})});
  V v_t_2421 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str42), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str43)})});
  V v_t_2422 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str44), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str45)})});
  V v_t_2423 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str46), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str47)})});
  V v_t_2424 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str48), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str49)})});
  V v_t_2425 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str50), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str51)})});
  V v_t_2426 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str52), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str53)})});
  V v_t_2427 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str54), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str55)})});
  V v_t_2428 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str56), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str57)})});
  V v_t_2429 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str58), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str59)})});
  V v_t_2430 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str60), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str61)})});
  V v_t_2431 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str62), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str63)})});
  V v_t_2432 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str64), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str65)})});
  V v_t_2433 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str66), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str67)})});
  V v_t_2434 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str68), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str69)})});
  V v_t_2435 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str70), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str71)})});
  V v_t_2436 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str72), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str73)})});
  V v_t_2437 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str74), heff_rec(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2eprims_2ebasicPrims_str75)})});
  V v_t_2438 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str76), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str77)})});
  V v_t_2439 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str78), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str79)})});
  V v_t_2440 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str80), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str81)})});
  V v_t_2441 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str82), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str83)})});
  V v_t_2442 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str84), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str85)})});
  V v_t_2443 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str86), heff_rec(2, shape_arity__js, (V[]){MK_INT(3LL), ((V)&g_heff_2eprims_2ebasicPrims_str87)})});
  V v_t_2444 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str88), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str89)})});
  V v_t_2445 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str90), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str91)})});
  V v_t_2446 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str92), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2ebasicPrims_str93)})});
  V v_t_2447 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2ebasicPrims_str94), heff_rec(2, shape_arity__js, (V[]){MK_INT(1LL), ((V)&g_heff_2eprims_2ebasicPrims_str95)})});
  V v_t_2448 = heff_tag(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
  V v_t_2449 = heff_tag(TAG_Cons, 2, (V[]){v_t_2445, heff_tag(TAG_Cons, 2, (V[]){v_t_2446, v_t_2448})});
  V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){v_t_2443, heff_tag(TAG_Cons, 2, (V[]){v_t_2444, v_t_2449})});
  V v_t_2451 = heff_tag(TAG_Cons, 2, (V[]){v_t_2441, heff_tag(TAG_Cons, 2, (V[]){v_t_2442, v_t_2450})});
  V v_t_2452 = heff_tag(TAG_Cons, 2, (V[]){v_t_2439, heff_tag(TAG_Cons, 2, (V[]){v_t_2440, v_t_2451})});
  V v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2437, heff_tag(TAG_Cons, 2, (V[]){v_t_2438, v_t_2452})});
  V v_t_2454 = heff_tag(TAG_Cons, 2, (V[]){v_t_2435, heff_tag(TAG_Cons, 2, (V[]){v_t_2436, v_t_2453})});
  V v_t_2455 = heff_tag(TAG_Cons, 2, (V[]){v_t_2433, heff_tag(TAG_Cons, 2, (V[]){v_t_2434, v_t_2454})});
  V v_t_2456 = heff_tag(TAG_Cons, 2, (V[]){v_t_2431, heff_tag(TAG_Cons, 2, (V[]){v_t_2432, v_t_2455})});
  V v_t_2457 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, heff_tag(TAG_Cons, 2, (V[]){v_t_2430, v_t_2456})});
  V v_t_2458 = heff_tag(TAG_Cons, 2, (V[]){v_t_2427, heff_tag(TAG_Cons, 2, (V[]){v_t_2428, v_t_2457})});
  V v_t_2459 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, heff_tag(TAG_Cons, 2, (V[]){v_t_2426, v_t_2458})});
  V v_t_2460 = heff_tag(TAG_Cons, 2, (V[]){v_t_2423, heff_tag(TAG_Cons, 2, (V[]){v_t_2424, v_t_2459})});
  V v_t_2461 = heff_tag(TAG_Cons, 2, (V[]){v_t_2421, heff_tag(TAG_Cons, 2, (V[]){v_t_2422, v_t_2460})});
  V v_t_2462 = heff_tag(TAG_Cons, 2, (V[]){v_t_2419, heff_tag(TAG_Cons, 2, (V[]){v_t_2420, v_t_2461})});
  V v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, heff_tag(TAG_Cons, 2, (V[]){v_t_2418, v_t_2462})});
  V v_t_2464 = heff_tag(TAG_Cons, 2, (V[]){v_t_2415, heff_tag(TAG_Cons, 2, (V[]){v_t_2416, v_t_2463})});
  V v_t_2465 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, heff_tag(TAG_Cons, 2, (V[]){v_t_2414, v_t_2464})});
  V v_t_2466 = heff_tag(TAG_Cons, 2, (V[]){v_t_2411, heff_tag(TAG_Cons, 2, (V[]){v_t_2412, v_t_2465})});
  V v_t_2467 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_tag(TAG_Cons, 2, (V[]){v_t_2410, v_t_2466})});
  V v_t_2468 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, heff_tag(TAG_Cons, 2, (V[]){v_t_248, v_t_2467})});
  V v_t_2469 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_t_2468})});
  V v_t_2470 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_2469})});
  V v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){v_t_241, heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2470})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_240, v_t_2471});
}
V g_heff_2eprims_2ebasicPrims_get(void) {
  if (g_heff_2eprims_2ebasicPrims_st == 2) return g_heff_2eprims_2ebasicPrims_val;
  if (g_heff_2eprims_2ebasicPrims_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2ebasicPrims_st = 1;
  g_heff_2eprims_2ebasicPrims_val = heff_tr(g_heff_2eprims_2ebasicPrims_init());
  g_heff_2eprims_2ebasicPrims_st = 2;
  return g_heff_2eprims_2ebasicPrims_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprims_2enarrowJs_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {41, 32, 60, 60, 32, 50, 52, 32, 62, 62, 32, 50, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eprims_2enarrowJs_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {41, 32, 60, 60, 32, 49, 54, 32, 62, 62, 32, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2enarrowJs_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 124, 32, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_heff_2eprims_2enarrowJs_str6 = {{0x80000000u, K_STR, 0}, 18, 18, {66, 105, 103, 73, 110, 116, 46, 97, 115, 73, 110, 116, 78, 40, 54, 52, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2enarrowJs_str9 = {{0x80000000u, K_STR, 0}, 7, 7, {41, 32, 38, 32, 50, 53, 53}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eprims_2enarrowJs_str11 = {{0x80000000u, K_STR, 0}, 9, 9, {41, 32, 38, 32, 54, 53, 53, 51, 53}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2enarrowJs_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {41, 32, 62, 62, 62, 32, 48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2enarrowJs_str14 = {{0x80000000u, K_STR, 0}, 19, 19, {66, 105, 103, 73, 110, 116, 46, 97, 115, 85, 105, 110, 116, 78, 40, 54, 52, 44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eprims_2enarrowJs_str16 = {{0x80000000u, K_STR, 0}, 12, 12, {77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2enarrowJs_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eprims_2enarrowJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprims_2enarrowJs_entry, 2, 0};

V g_heff_2eprims_2enarrowJs(V v_x1_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_I8: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str0), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str1)));
  }
  case TAG_I16: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str2), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str3)));
  }
  case TAG_I32: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str4), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str5)));
  }
  case TAG_I64: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str6), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str7)));
  }
  case TAG_U8: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str8), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str9)));
  }
  case TAG_U16: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str10), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str11)));
  }
  case TAG_U32: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str12), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str13)));
  }
  case TAG_U64: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str14), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str15)));
  }
  case TAG_F32: {
    return heff_strAppend(((V)&g_heff_2eprims_2enarrowJs_str16), heff_strAppend(v_e_241, ((V)&g_heff_2eprims_2enarrowJs_str17)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eprims_2enarrowJs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprims_2enarrowJs(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2eshiftMaskJs_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2eshiftMaskJs_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eprims_2eshiftMaskJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprims_2eshiftMaskJs_entry, 1, 0};

V g_heff_2eprims_2eshiftMaskJs(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_241 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_241 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_241 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_241 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_241 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_241 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_241 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_241 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_242 = heff_intShow(heff_intSub(v_t_241, MK_INT(1LL)));
  V v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_245;
  if (heff_intEq_c(v_t_243, MK_INT(64LL))) {
    v_t_245 = ((V)&g_heff_2eprims_2eshiftMaskJs_str0);
  } else {
    v_t_245 = ((V)&g_heff_2eprims_2eshiftMaskJs_str1);
  }
  return heff_strAppend(v_t_242, v_t_245);
}
V g_heff_2eprims_2eshiftMaskJs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprims_2eshiftMaskJs(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 43, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 45, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 42, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eprims_2eintOpJs_str5 = {{0x80000000u, K_STR, 0}, 15, 15, {77, 97, 116, 104, 46, 105, 109, 117, 108, 40, 97, 44, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str6 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 47, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2eintOpJs_str8 = {{0x80000000u, K_STR, 0}, 17, 17, {77, 97, 116, 104, 46, 116, 114, 117, 110, 99, 40, 97, 32, 47, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprims_2eintOpJs_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {48, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2eintOpJs_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eintOpJs_str11 = {{0x80000000u, K_STR, 0}, 6, 6, {98, 32, 61, 61, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eprims_2eintOpJs_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str13 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 37, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprims_2eintOpJs_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {48, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2eintOpJs_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {48}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eintOpJs_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {98, 32, 61, 61, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eprims_2eintOpJs_str18 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 63, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41, 32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str19 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2eintOpJs_str20 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2eintOpJs_str21 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2eintOpJs_str22 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 38, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str24 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str25 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 124, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str26 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str27 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 32, 94, 32, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str28 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eprims_2eintOpJs_str29 = {{0x80000000u, K_STR, 0}, 10, 10, {97, 32, 60, 60, 32, 40, 98, 32, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2eintOpJs_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str31 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprims_2eintOpJs_str32 = {{0x80000000u, K_STR, 0}, 2, 2, {62, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprims_2eintOpJs_str33 = {{0x80000000u, K_STR, 0}, 2, 2, {62, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eprims_2eintOpJs_str34 = {{0x80000000u, K_STR, 0}, 3, 3, {62, 62, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eprims_2eintOpJs_str35 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eintOpJs_str36 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 40, 98, 32, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2eintOpJs_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eprims_2eintOpJs_str38 = {{0x80000000u, K_STR, 0}, 14, 14, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eprims_2eintOpJs_str39 = {{0x80000000u, K_STR, 0}, 19, 19, {40, 97, 41, 32, 61, 62, 32, 97, 46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2eintOpJs_str40 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 97, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2eintOpJs_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str42 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str43 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str44 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str45 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eintOpJs_str46 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 105, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eintOpJs_str47 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 105, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eintOpJs_str48 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 105, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eprims_2eintOpJs_str49 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 105, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str50 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 78, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eprims_2eintOpJs_str51 = {{0x80000000u, K_STR, 0}, 23, 23, {40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 40, 66, 105, 103, 73, 110, 116, 46, 97, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eprims_2eintOpJs_str52 = {{0x80000000u, K_STR, 0}, 5, 5, {44, 32, 97, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2eintOpJs_str53 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 97, 41, 32, 61, 62, 32, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eprims_2eintOpJs_str54 = {{0x80000000u, K_STR, 0}, 16, 16, {40, 97, 41, 32, 61, 62, 32, 66, 105, 103, 73, 110, 116, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2eintOpJs_str55 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2eintOpJs_str56 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2eintOpJs_str57 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2eintOpJs_str58 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
Clo g_heff_2eprims_2eintOpJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprims_2eintOpJs_entry, 2, 0};

V g_heff_2eprims_2eintOpJs(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_body_242 = (g_heff_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2eprims_2eintOpJs_str0)));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str1), v_body_242);
  }
  case TAG_OpSub: {
    V v_body_243 = (g_heff_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2eprims_2eintOpJs_str2)));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str3), v_body_243);
  }
  case TAG_OpMul: {
    V v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_244 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_244 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_244 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_244 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_246;
    if (heff_intEq_c(v_t_244, MK_INT(64LL))) {
      v_t_246 = ((V)&g_heff_2eprims_2eintOpJs_str4);
    } else {
      v_t_246 = ((V)&g_heff_2eprims_2eintOpJs_str5);
    }
    V v_body_247 = (g_heff_2eprims_2enarrowJs(v_w_240, v_t_246));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str6), v_body_247);
  }
  case TAG_OpDiv: {
    V v_t_248;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_248 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_248 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_248 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_248 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_248 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_248 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_248 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_248 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_248 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2410;
    if (heff_intEq_c(v_t_248, MK_INT(64LL))) {
      v_t_2410 = ((V)&g_heff_2eprims_2eintOpJs_str7);
    } else {
      v_t_2410 = ((V)&g_heff_2eprims_2eintOpJs_str8);
    }
    V v_e_2411 = (g_heff_2eprims_2enarrowJs(v_w_240, v_t_2410));
    V v_t_2412;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2412 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2412 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2412 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2412 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2412 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2412 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2412 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2412 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2412 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2414;
    if (heff_intEq_c(v_t_2412, MK_INT(64LL))) {
      v_t_2414 = ((V)&g_heff_2eprims_2eintOpJs_str9);
    } else {
      v_t_2414 = ((V)&g_heff_2eprims_2eintOpJs_str10);
    }
    V v_body_2415 = heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str11), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str12), v_e_2411)));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str13), v_body_2415);
  }
  case TAG_OpRem: {
    V v_e_2416 = (g_heff_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2eprims_2eintOpJs_str14)));
    V v_t_2417;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2417 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2417 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2417 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2417 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2417 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2417 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2417 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2417 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2417 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2419;
    if (heff_intEq_c(v_t_2417, MK_INT(64LL))) {
      v_t_2419 = ((V)&g_heff_2eprims_2eintOpJs_str15);
    } else {
      v_t_2419 = ((V)&g_heff_2eprims_2eintOpJs_str16);
    }
    V v_body_2420 = heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str17), heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str18), v_e_2416)));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str19), v_body_2420);
  }
  case TAG_OpEq: {
    return ((V)&g_heff_2eprims_2eintOpJs_str20);
  }
  case TAG_OpLt: {
    return ((V)&g_heff_2eprims_2eintOpJs_str21);
  }
  case TAG_OpLe: {
    return ((V)&g_heff_2eprims_2eintOpJs_str22);
  }
  case TAG_OpAnd: {
    V v_body_2421 = (g_heff_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2eprims_2eintOpJs_str23)));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str24), v_body_2421);
  }
  case TAG_OpOr: {
    V v_body_2422 = (g_heff_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2eprims_2eintOpJs_str25)));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str26), v_body_2422);
  }
  case TAG_OpXor: {
    V v_body_2423 = (g_heff_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2eprims_2eintOpJs_str27)));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str28), v_body_2423);
  }
  case TAG_OpShl: {
    V v_t_2424 = (g_heff_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str29), heff_strAppend(v_t_2424, ((V)&g_heff_2eprims_2eintOpJs_str30)));
    V v_body_2426 = (g_heff_2eprims_2enarrowJs(v_w_240, v_t_2425));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str31), v_body_2426);
  }
  case TAG_OpShr: {
    V v_t_2427;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_I16: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_I32: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_I64: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_U8: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_U16: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_U32: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_U64: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_F32: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2430;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_True: {
      v_t_2430 = ((V)&g_heff_2eprims_2eintOpJs_str32);
      break;
    }
    case TAG_False: {
      V v_t_2428;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2428 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2428 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2428 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2428 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2428 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2428 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2428 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2428 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2428 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      if (heff_intEq_c(v_t_2428, MK_INT(64LL))) {
        v_t_2430 = ((V)&g_heff_2eprims_2eintOpJs_str33);
      } else {
        v_t_2430 = ((V)&g_heff_2eprims_2eintOpJs_str34);
      }
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    V v_t_2431 = (g_heff_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2432 = heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str35), heff_strAppend(v_t_2430, heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str36), heff_strAppend(v_t_2431, ((V)&g_heff_2eprims_2eintOpJs_str37)))));
    V v_body_2433 = (g_heff_2eprims_2enarrowJs(v_w_240, v_t_2432));
    return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str38), v_body_2433);
  }
  case TAG_OpShow: {
    return ((V)&g_heff_2eprims_2eintOpJs_str39);
  }
  case TAG_OpFromInt: {
    V v_t_2434;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2434 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2434 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2434 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2434 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2434 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2434 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2434 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2434 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2434 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if (heff_intEq_c(v_t_2434, MK_INT(64LL))) {
      return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str40), (g_heff_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2eprims_2eintOpJs_str41))));
    } else {
      V v_t_2436;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str42);
        break;
      }
      case TAG_I16: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str43);
        break;
      }
      case TAG_I32: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str44);
        break;
      }
      case TAG_I64: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str45);
        break;
      }
      case TAG_U8: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str46);
        break;
      }
      case TAG_U16: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str47);
        break;
      }
      case TAG_U32: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str48);
        break;
      }
      case TAG_U64: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str49);
        break;
      }
      case TAG_F32: {
        v_t_2436 = ((V)&g_heff_2eprims_2eintOpJs_str50);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2437;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2437 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2437 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2437 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2437 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2437 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2437 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_strAppend(((V)&g_heff_2eprims_2eintOpJs_str51), heff_strAppend(v_t_2436, heff_strAppend(heff_intShow(v_t_2437), ((V)&g_heff_2eprims_2eintOpJs_str52))));
    }
  }
  case TAG_OpToInt: {
    V v_t_2438;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2438 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2438 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2438 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2438 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2438 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2438 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2438 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2438 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2438 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if (heff_intEq_c(v_t_2438, MK_INT(64LL))) {
      return ((V)&g_heff_2eprims_2eintOpJs_str53);
    } else {
      return ((V)&g_heff_2eprims_2eintOpJs_str54);
    }
  }
  case TAG_OpSqrt: {
    return ((V)&g_heff_2eprims_2eintOpJs_str55);
  }
  case TAG_OpFromFloat: {
    return ((V)&g_heff_2eprims_2eintOpJs_str56);
  }
  case TAG_OpToFloat: {
    return ((V)&g_heff_2eprims_2eintOpJs_str57);
  }
  case TAG_OpFloor: {
    return ((V)&g_heff_2eprims_2eintOpJs_str58);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprims_2eintOpJs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprims_2eintOpJs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[61]; } g_heff_2eprims_2efloat32ShowJs_str0 = {{0x80000000u, K_STR, 0}, 61, 61, {99, 111, 110, 115, 116, 32, 115, 32, 61, 32, 83, 116, 114, 105, 110, 103, 40, 116, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 105, 115, 78, 97, 78, 40, 115, 32, 43, 32, 34, 46, 48, 34, 41, 32, 63, 32, 115, 32, 58, 32, 115, 32, 43, 32, 34, 46, 48, 34, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[45]; } g_heff_2eprims_2efloat32ShowJs_str1 = {{0x80000000u, K_STR, 0}, 45, 45, {99, 111, 110, 115, 116, 32, 99, 32, 61, 32, 78, 117, 109, 98, 101, 114, 40, 113, 32, 43, 32, 34, 101, 34, 32, 43, 32, 115, 41, 32, 42, 32, 77, 97, 116, 104, 46, 115, 105, 103, 110, 40, 97, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eprims_2efloat32ShowJs_str2 = {{0x80000000u, K_STR, 0}, 47, 47, {105, 102, 32, 40, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 99, 41, 32, 61, 61, 61, 32, 97, 41, 32, 123, 32, 116, 32, 61, 32, 99, 59, 32, 98, 114, 101, 97, 107, 59, 32, 125, 32, 125, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[47]; } g_heff_2eprims_2efloat32ShowJs_str3 = {{0x80000000u, K_STR, 0}, 47, 47, {108, 101, 116, 32, 113, 32, 61, 32, 110, 117, 109, 32, 47, 32, 100, 101, 110, 59, 32, 99, 111, 110, 115, 116, 32, 114, 50, 32, 61, 32, 50, 110, 32, 42, 32, 40, 110, 117, 109, 32, 37, 32, 100, 101, 110, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[46]; } g_heff_2eprims_2efloat32ShowJs_str4 = {{0x80000000u, K_STR, 0}, 46, 46, {105, 102, 32, 40, 114, 50, 32, 62, 32, 100, 101, 110, 32, 124, 124, 32, 40, 114, 50, 32, 61, 61, 61, 32, 100, 101, 110, 32, 38, 38, 32, 40, 113, 32, 38, 32, 49, 110, 41, 41, 41, 32, 113, 43, 43, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[51]; } g_heff_2eprims_2efloat32ShowJs_str5 = {{0x80000000u, K_STR, 0}, 51, 51, {102, 111, 114, 32, 40, 108, 101, 116, 32, 112, 32, 61, 32, 49, 59, 32, 112, 32, 60, 61, 32, 57, 59, 32, 112, 43, 43, 41, 32, 123, 32, 99, 111, 110, 115, 116, 32, 115, 32, 61, 32, 107, 32, 45, 32, 112, 32, 43, 32, 49, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[88]; } g_heff_2eprims_2efloat32ShowJs_str6 = {{0x80000000u, K_STR, 0}, 88, 88, {99, 111, 110, 115, 116, 32, 110, 117, 109, 32, 61, 32, 115, 32, 62, 61, 32, 48, 32, 63, 32, 110, 32, 58, 32, 110, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 45, 115, 41, 44, 32, 100, 101, 110, 32, 61, 32, 115, 32, 62, 61, 32, 48, 32, 63, 32, 100, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 115, 41, 32, 58, 32, 100, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2eprims_2efloat32ShowJs_str7 = {{0x80000000u, K_STR, 0}, 82, 82, {99, 111, 110, 115, 116, 32, 103, 101, 32, 61, 32, 40, 107, 41, 32, 61, 62, 32, 107, 32, 62, 61, 32, 48, 32, 63, 32, 110, 32, 62, 61, 32, 100, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 107, 41, 32, 58, 32, 110, 32, 42, 32, 49, 48, 110, 32, 42, 42, 32, 66, 105, 103, 73, 110, 116, 40, 45, 107, 41, 32, 62, 61, 32, 100, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[87]; } g_heff_2eprims_2efloat32ShowJs_str8 = {{0x80000000u, K_STR, 0}, 87, 87, {108, 101, 116, 32, 107, 32, 61, 32, 77, 97, 116, 104, 46, 102, 108, 111, 111, 114, 40, 77, 97, 116, 104, 46, 108, 111, 103, 49, 48, 40, 77, 97, 116, 104, 46, 97, 98, 115, 40, 97, 41, 41, 41, 59, 32, 119, 104, 105, 108, 101, 32, 40, 33, 103, 101, 40, 107, 41, 41, 32, 107, 45, 45, 59, 32, 119, 104, 105, 108, 101, 32, 40, 103, 101, 40, 107, 32, 43, 32, 49, 41, 41, 32, 107, 43, 43, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2eprims_2efloat32ShowJs_str9 = {{0x80000000u, K_STR, 0}, 82, 82, {99, 111, 110, 115, 116, 32, 109, 32, 61, 32, 66, 105, 103, 73, 110, 116, 40, 98, 101, 32, 63, 32, 40, 98, 32, 38, 32, 56, 51, 56, 56, 54, 48, 55, 41, 32, 124, 32, 56, 51, 56, 56, 54, 48, 56, 32, 58, 32, 98, 32, 38, 32, 56, 51, 56, 56, 54, 48, 55, 41, 44, 32, 101, 32, 61, 32, 40, 98, 101, 32, 124, 124, 32, 49, 41, 32, 45, 32, 49, 53, 48, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[74]; } g_heff_2eprims_2efloat32ShowJs_str10 = {{0x80000000u, K_STR, 0}, 74, 74, {99, 111, 110, 115, 116, 32, 110, 32, 61, 32, 101, 32, 62, 61, 32, 48, 32, 63, 32, 109, 32, 60, 60, 32, 66, 105, 103, 73, 110, 116, 40, 101, 41, 32, 58, 32, 109, 44, 32, 100, 32, 61, 32, 101, 32, 62, 61, 32, 48, 32, 63, 32, 49, 110, 32, 58, 32, 49, 110, 32, 60, 60, 32, 66, 105, 103, 73, 110, 116, 40, 45, 101, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[73]; } g_heff_2eprims_2efloat32ShowJs_str11 = {{0x80000000u, K_STR, 0}, 73, 73, {99, 111, 110, 115, 116, 32, 118, 32, 61, 32, 110, 101, 119, 32, 68, 97, 116, 97, 86, 105, 101, 119, 40, 110, 101, 119, 32, 65, 114, 114, 97, 121, 66, 117, 102, 102, 101, 114, 40, 52, 41, 41, 59, 32, 118, 46, 115, 101, 116, 70, 108, 111, 97, 116, 51, 50, 40, 48, 44, 32, 77, 97, 116, 104, 46, 97, 98, 115, 40, 97, 41, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[40]; } g_heff_2eprims_2efloat32ShowJs_str12 = {{0x80000000u, K_STR, 0}, 40, 40, {99, 111, 110, 115, 116, 32, 98, 32, 61, 32, 118, 46, 103, 101, 116, 85, 105, 110, 116, 51, 50, 40, 48, 41, 44, 32, 98, 101, 32, 61, 32, 98, 32, 62, 62, 62, 32, 50, 51, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eprims_2efloat32ShowJs_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[56]; } g_heff_2eprims_2efloat32ShowJs_str14 = {{0x80000000u, K_STR, 0}, 56, 56, {40, 97, 41, 32, 61, 62, 32, 123, 32, 108, 101, 116, 32, 116, 32, 61, 32, 97, 59, 32, 105, 102, 32, 40, 78, 117, 109, 98, 101, 114, 46, 105, 115, 70, 105, 110, 105, 116, 101, 40, 97, 41, 32, 38, 38, 32, 97, 32, 33, 61, 61, 32, 48, 41, 32, 123}};

static V g_heff_2eprims_2efloat32ShowJs_val;
static int g_heff_2eprims_2efloat32ShowJs_st;
static V g_heff_2eprims_2efloat32ShowJs_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str8), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str10), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str11), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eprims_2efloat32ShowJs_str12), v_t_245})});
  return ({ V a_0 = ((V)&g_heff_2eprims_2efloat32ShowJs_str13); V a_1 = ((V)&g_heff_2eprims_2efloat32ShowJs_str14); V a_2 = v_t_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_246, 2); r_; });
}
V g_heff_2eprims_2efloat32ShowJs_get(void) {
  if (g_heff_2eprims_2efloat32ShowJs_st == 2) return g_heff_2eprims_2efloat32ShowJs_val;
  if (g_heff_2eprims_2efloat32ShowJs_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2efloat32ShowJs_st = 1;
  g_heff_2eprims_2efloat32ShowJs_val = heff_tr(g_heff_2eprims_2efloat32ShowJs_init());
  g_heff_2eprims_2efloat32ShowJs_st = 2;
  return g_heff_2eprims_2efloat32ShowJs_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2eprims_2efixedJs_str0 = {{0x80000000u, K_STR, 0}, 32, 32, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 43, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2eprims_2efixedJs_str1 = {{0x80000000u, K_STR, 0}, 32, 32, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 45, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2eprims_2efixedJs_str2 = {{0x80000000u, K_STR, 0}, 32, 32, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 42, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2eprims_2efixedJs_str3 = {{0x80000000u, K_STR, 0}, 32, 32, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 32, 47, 32, 98, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2efixedJs_str4 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eprims_2efixedJs_str5 = {{0x80000000u, K_STR, 0}, 31, 31, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 61, 61, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2efixedJs_str6 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2efixedJs_str7 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 97, 41, 32, 61, 62, 32, 40, 98, 41, 32, 61, 62, 32, 97, 32, 60, 61, 32, 98, 32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2efixedJs_str8 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2efixedJs_str9 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2efixedJs_str10 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2efixedJs_str11 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2efixedJs_str12 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_heff_2eprims_2efixedJs_str13 = {{0x80000000u, K_STR, 0}, 29, 29, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 78, 117, 109, 98, 101, 114, 40, 97, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eprims_2efixedJs_str14 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 97, 41, 32, 61, 62, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_heff_2eprims_2efixedJs_str15 = {{0x80000000u, K_STR, 0}, 32, 32, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 77, 97, 116, 104, 46, 115, 113, 114, 116, 40, 97, 41, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_heff_2eprims_2efixedJs_str16 = {{0x80000000u, K_STR, 0}, 21, 21, {40, 97, 41, 32, 61, 62, 32, 77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40, 97, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eprims_2efixedJs_str17 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 97, 41, 32, 61, 62, 32, 97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[62]; } g_heff_2eprims_2efixedJs_str18 = {{0x80000000u, K_STR, 0}, 62, 62, {40, 97, 41, 32, 61, 62, 32, 78, 117, 109, 98, 101, 114, 46, 105, 115, 70, 105, 110, 105, 116, 101, 40, 97, 41, 32, 63, 32, 66, 105, 103, 73, 110, 116, 40, 77, 97, 116, 104, 46, 102, 108, 111, 111, 114, 40, 97, 41, 41, 32, 58, 32, 36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
Clo g_heff_2eprims_2efixedJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprims_2efixedJs_entry, 1, 0};

V g_heff_2eprims_2efixedJs(V v_p_240) {
top: ;
  V v_t_241 = heff_get(heff_dup(v_p_240), LBL_fixed);
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_I8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_242 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_get(v_p_240, LBL_op);
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      return ((V)&g_heff_2eprims_2efixedJs_str0);
    }
    case TAG_OpSub: {
      return ((V)&g_heff_2eprims_2efixedJs_str1);
    }
    case TAG_OpMul: {
      return ((V)&g_heff_2eprims_2efixedJs_str2);
    }
    case TAG_OpDiv: {
      return ((V)&g_heff_2eprims_2efixedJs_str3);
    }
    case TAG_OpRem: {
      return ((V)&g_heff_2eprims_2efixedJs_str4);
    }
    case TAG_OpEq: {
      return ((V)&g_heff_2eprims_2efixedJs_str5);
    }
    case TAG_OpLt: {
      return ((V)&g_heff_2eprims_2efixedJs_str6);
    }
    case TAG_OpLe: {
      return ((V)&g_heff_2eprims_2efixedJs_str7);
    }
    case TAG_OpAnd: {
      return ((V)&g_heff_2eprims_2efixedJs_str8);
    }
    case TAG_OpOr: {
      return ((V)&g_heff_2eprims_2efixedJs_str9);
    }
    case TAG_OpXor: {
      return ((V)&g_heff_2eprims_2efixedJs_str10);
    }
    case TAG_OpShl: {
      return ((V)&g_heff_2eprims_2efixedJs_str11);
    }
    case TAG_OpShr: {
      return ((V)&g_heff_2eprims_2efixedJs_str12);
    }
    case TAG_OpShow: {
      return heff_dup(g_heff_2eprims_2efloat32ShowJs_get());
    }
    case TAG_OpFromInt: {
      return ((V)&g_heff_2eprims_2efixedJs_str13);
    }
    case TAG_OpToInt: {
      return ((V)&g_heff_2eprims_2efixedJs_str14);
    }
    case TAG_OpSqrt: {
      return ((V)&g_heff_2eprims_2efixedJs_str15);
    }
    case TAG_OpFromFloat: {
      return ((V)&g_heff_2eprims_2efixedJs_str16);
    }
    case TAG_OpToFloat: {
      return ((V)&g_heff_2eprims_2efixedJs_str17);
    }
    case TAG_OpFloor: {
      return ((V)&g_heff_2eprims_2efixedJs_str18);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    return ({ V b_0 = heff_get(heff_dup(v_p_240), LBL_fixed); V b_1 = heff_get(v_p_240, LBL_op); V r_ = (g_heff_2eprims_2eintOpJs(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eprims_2efixedJs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprims_2efixedJs(a[0]);
}
Clo g_heff_2eprims_2efixedImpl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprims_2efixedImpl_entry, 1, 0};

V g_heff_2eprims_2efixedImpl(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2efixed_2efixedPrimName(heff_dup(v_p_240)));
  V v_t_242 = heff_get(heff_dup(v_p_240), LBL_op);
  V v_arity_243;
  switch (heff_tag_of(v_t_242)) {
  case TAG_OpAdd: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpSub: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpMul: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpDiv: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpRem: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpEq: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpLt: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpLe: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpAnd: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpOr: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpXor: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpShl: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpShr: {
    v_arity_243 = MK_INT(2LL);
    break;
  }
  case TAG_OpShow: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpFromInt: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpToInt: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpSqrt: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpFromFloat: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpToFloat: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  case TAG_OpFloor: {
    v_arity_243 = MK_INT(1LL);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_js_244 = (g_heff_2eprims_2efixedJs(v_p_240));
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_241, heff_rec(2, shape_arity__js, (V[]){v_arity_243, v_js_244})});
}
V g_heff_2eprims_2efixedImpl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eprims_2efixedImpl(a[0]);
}

static V g_heff_2eprims_2eprims_val;
static int g_heff_2eprims_2eprims_st;
static V g_heff_2eprims_2eprims_init(void) {
  V v_t_240 = (g_list_2emap_24s420379013x173468973(heff_dup(g_heff_2efixed_2efixedPrims_get())));
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2eprims_2ebasicPrims_get()), v_t_240));
}
V g_heff_2eprims_2eprims_get(void) {
  if (g_heff_2eprims_2eprims_st == 2) return g_heff_2eprims_2eprims_val;
  if (g_heff_2eprims_2eprims_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2eprims_st = 1;
  g_heff_2eprims_2eprims_val = heff_tr(g_heff_2eprims_2eprims_init());
  g_heff_2eprims_2eprims_st = 2;
  return g_heff_2eprims_2eprims_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eprims_2einternal_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 101, 114, 102, 111, 114, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_heff_2eprims_2einternal_str1 = {{0x80000000u, K_STR, 0}, 30, 30, {40, 112, 41, 32, 61, 62, 32, 40, 107, 41, 32, 61, 62, 32, 36, 112, 101, 114, 102, 111, 114, 109, 101, 114, 40, 112, 44, 32, 107, 41}};

static V g_heff_2eprims_2einternal_val;
static int g_heff_2eprims_2einternal_st;
static V g_heff_2eprims_2einternal_init(void) {
  V v_t_240 = heff_tag(TAG_MkPair, 2, (V[]){((V)&g_heff_2eprims_2einternal_str0), heff_rec(2, shape_arity__js, (V[]){MK_INT(2LL), ((V)&g_heff_2eprims_2einternal_str1)})});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_240, NTAG(TAG_Nil)});
}
V g_heff_2eprims_2einternal_get(void) {
  if (g_heff_2eprims_2einternal_st == 2) return g_heff_2eprims_2einternal_val;
  if (g_heff_2eprims_2einternal_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2einternal_st = 1;
  g_heff_2eprims_2einternal_val = heff_tr(g_heff_2eprims_2einternal_init());
  g_heff_2eprims_2einternal_st = 2;
  return g_heff_2eprims_2einternal_val;
}

static V g_heff_2eprims_2eallPrims_val;
static int g_heff_2eprims_2eallPrims_st;
static V g_heff_2eprims_2eallPrims_init(void) {
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2eprims_2eprims_get()), heff_dup(g_heff_2eprims_2einternal_get())));
}
V g_heff_2eprims_2eallPrims_get(void) {
  if (g_heff_2eprims_2eallPrims_st == 2) return g_heff_2eprims_2eallPrims_val;
  if (g_heff_2eprims_2eallPrims_st == 1) heff_fail("defined by itself");
  g_heff_2eprims_2eallPrims_st = 1;
  g_heff_2eprims_2eallPrims_val = heff_tr(g_heff_2eprims_2eallPrims_init());
  g_heff_2eprims_2eallPrims_st = 2;
  return g_heff_2eprims_2eallPrims_val;
}
Clo g_heff_2eprims_2eprimArityGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eprims_2eprimArityGo_entry, 2, 0};

V g_heff_2eprims_2eprimArityGo(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_i_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_244), heff_dup(v_p_240))) {
        heff_drop(v_p_240);
        return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_i_245), LBL_arity)});
      } else {
        V t_0 = v_p_240;
        V t_1 = v_rest_243;
        v_p_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eprims_2eprimArityGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eprims_2eprimArityGo(a[0], a[1]); heff_drop(a[1]); return r;
}