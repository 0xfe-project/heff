// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_c 317
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_cwd 308458
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_loaded 849622832
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_note 9882809
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_zig 330130
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo;
V g_heff_2ebuild_2ecommands_2eintegrationText(V, V);
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576(V, V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V);
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400_clo;
V g_heff_2ebuild_2ecommands_2erefusedReaching(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197(V, V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2erootsAmong(V, V);
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erootsAmong_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2equery_2etypeAt_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2ecompile_2elower_2ecErased(V, V);
V g_heff_2ecompile_2elower_2ecErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecErased_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
HeffT2 g_list_2efind_24s1973550603x1701528639_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1942081783x251284947(V, V, V, V);
V g_list_2emap_24f1942081783x251284947_entry(V self, V *a);
extern Clo g_list_2emap_24f1942081783x251284947_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s1750766838x1556198350(V, V, V);
V g_list_2emap_24s1750766838x1556198350_entry(V self, V *a);
extern Clo g_list_2emap_24s1750766838x1556198350_clo;
V g_list_2emap_24s764064723x821001015(V);
V g_list_2emap_24s764064723x821001015_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str0, 23, "not known: there is no ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str1, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str2, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str3, 5, "heff ");

HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V v_path_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_f_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str0), v_path_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_Just: {
    V v_src_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_src_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_p_248 = v_field_246;
        V v_t_249 = (g_heff_2ebuild_2eload_2eproblemMsg(v_path_240, v_src_243, v_p_248));
        V v_f_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str1), v_t_249);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      } else {
        V v_x_2411 = v_field_246;
        HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_p_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2ebuild_2eload_2eproblemMsg(v_path_240, v_src_243, v_p_2416));
            V v_f_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str2), v_t_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
          } else {
            heff_drop(v_path_240);
            V v_p_2419 = v_field_2414;
            V v_f_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str3), heff_get_n(v_p_2419, 1, 4));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2420}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str0, 4, "std.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str1, 81, "` is an effect of the system (lib/std/), for C: it has no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str2, 1, "`");
Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erefusedReaching_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erefusedReaching(V v_host_240, V v_sources_241, V v_only_242, V v_s_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_s_243, 7));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_s_243, 0)), MK_INT(0LL), MK_INT(4LL));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str0))) {
      V v_t_247 = (g_list_2eany_24s2065989517x1307020881(heff_rfield(v_s_243, 0), v_only_242));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_sources_241);
        heff_drop(v_t_247);
        V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_243, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str1), v_host_240));
        V v_t_249 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_243, 0, 8), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str2), v_t_248), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      } else {
        heff_drop(v_t_247);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_s_243, 0)), NTAG(TAG_Nil)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
        HeffT2 v_t_2412 = (g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(v_sources_241, v_only_242, NTAG(TAG_Nil), v_t_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2ebuild_2ecommands_2ereachingRefused(v_host_240, v_s_243, v_x_2416));
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
          } else {
            heff_drop(v_host_240);
            heff_drop_rec(v_s_243, 8);
            heff_drop(v_field_2414);
            return NTAG(TAG_Nothing);
          }
        }
      }
    } else {
      heff_drop(v_host_240);
      heff_drop(v_sources_241);
      heff_drop_rec(v_s_243, 8);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_host_240);
    heff_drop(v_sources_241);
    heff_drop_rec(v_s_243, 8);
    heff_drop(v_t_244);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2erefusedReaching(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_str0, 45, "its file does not import check, which runs it");
V g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V v_p_240, V v_src_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_src_241, 6), heff_take_field(v_src_241, 4)));
  HeffT4 v_t_243 = ({ V b_0 = heff_get_n(v_src_241, 5, 8); V a_1 = v_t_242; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248;
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    heff_drop(v_t_243.f[3]);
    v_t_248 = v_field_244;
  }
  HeffT2 v_t_249 = (g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_q_2413 = v_field_2411;
      V v_l_2414 = heff_dup(heff_rfield(v_p_240, 5));
      V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_p_240, 6)), 0, 14);
      V v_c_2416 = heff_take_field(v_p_240, 6);
      V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_2416)}), heff_dup(heff_rfield(v_c_2416, 7))));
      V v_t_2419 = (g_heff_2ebuild_2edriver_2erootsAmong(v_c_2416, v_t_2418));
      V v_t_2420 = (g_heff_2ebuild_2ecommands_2eintegrationText(v_q_2413, v_t_2419));
      V v_t_2421 = heff_get_n(heff_get_n(v_p_240, 5, 7), 0, 5);
      V v_sources_2422 = ({ V a_0 = v_t_2415; V a_1 = v_t_2420; V a_2 = v_t_2421; V r_ = (g_list_2emap_24s1750766838x1556198350(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
      V v_f_2423 = ({ V rv_0 = v_sources_2422; V rr_ = heff_rec_reuse_nf(v_l_2414, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2423}});
    } else {
      heff_drop_rec(v_p_240, 7);
      heff_drop(v_field_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_str0)}});
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0(V self, V *args) {
  V v_o_2417 = args[0];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_2416, v_o_2417));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam2(V self, V *args) {
  V v_s_2413 = args[0];
  return v_s_2413;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_2412 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2412, v_x_2421));
  V v_x_2423 = ({ V a_0 = v_st_2412; V a_1 = v_t_2422; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_str1); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2412); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2412;
  if (heff_strEq_c(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_str0))) {
    v_st_2412 = NTAG(TAG_Windows);
  } else {
    v_st_2412 = NTAG(TAG_Posix);
  }
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam2_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s495635622x733177935(v_t_2420, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_lam3, 1, 2, (V[]){v_st_2412, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665(V v_ps_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    top_TAG_Nothing: ;
    V v_t_243 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567(v_ps_240, v_b_241, v_t_243);
  }
  case TAG_Just: {
    V v_kept_244 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_str0), v_kept_244, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_kept_244);
      heff_drop(v_j_245);
      V t_0 = v_ps_240;
      V t_1 = v_b_241;
      V t_2 = NTAG(TAG_Nothing);
      v_ps_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top_TAG_Nothing;
    } else {
      V v_t_247 = heff_intSub(heff_strLength_lent(v_kept_244, 0), heff_dup(v_j_245));
      if (heff_intEq_c(heff_intSub(v_t_247, MK_INT(1LL)), heff_strLength_lent(v_b_241, 0))) {
        V v_t_249 = heff_strSlice(heff_dup(v_kept_244), heff_intAdd(heff_dup(v_j_245), MK_INT(1LL)), heff_strLength_lent(v_kept_244, 0));
        if (heff_strEq_c_lent(v_t_249, v_b_241, 1)) {
          heff_drop(v_ps_240);
          heff_drop(v_b_241);
          return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_lam0, 2, 2, (V[]){v_kept_244, v_j_245});
        } else {
          heff_drop(v_kept_244);
          heff_drop(v_j_245);
          V t_0 = v_ps_240;
          V t_1 = v_b_241;
          V t_2 = NTAG(TAG_Nothing);
          v_ps_240 = t_0;
          v_b_241 = t_1;
          v_x3_242 = t_2;
          goto top_TAG_Nothing;
        }
      } else {
        heff_drop(v_kept_244);
        heff_drop(v_j_245);
        V t_0 = v_ps_240;
        V t_1 = v_b_241;
        V t_2 = NTAG(TAG_Nothing);
        v_ps_240 = t_0;
        v_b_241 = t_1;
        v_x3_242 = t_2;
        goto top_TAG_Nothing;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1411264318x1632503665_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_kept_244 = heff_env(self)[0];
  V v_j_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_strSlice(v_kept_244, MK_INT(0LL), v_j_245);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_str2, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(V v_ps_240, V v_olds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_olds_241, v_m_247));
      V v_t_2414;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          v_t_2414 = v_x_2413;
        } else {
          heff_drop(v_field_2411);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_str0);
        }
      }
      V v_c_2421;
      if (heff_strEq_c_lent(v_text_248, v_t_2414, 2)) {
        v_c_2421 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam1_clo);
      } else {
        V v_d_2418 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_str1)));
        V v_d_2419 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2418, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
        V v_t_2420 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2419, heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_str2))));
        v_c_2421 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_clo), 2, (V[]){v_t_2420, heff_dup(v_text_248)}));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam2, 2, 4, (V[]){v_c_2421, v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2422 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2424);
  V v_t_2425 = ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587(a_0, a_1, a_2)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_olds_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s127156401x1669669587_lam3, 1, 5, (V[]){v_ps_240, v_olds_241, v_rest_246, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str6, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str7, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str9, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str12, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str13, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam8(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_failed_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2414 = v_field_2412;
      V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam0, 1, 1, (V[]){heff_dup(v_c_2414)}), heff_dup(heff_rfield(v_c_2414, 7))));
      V v_t_2423 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2422));
      V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2423); r_; });
      V v_t_2425 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2424));
      V v_xs_2426 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str3); V a_6 = v_t_2425; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2427 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2426));
      V v_c_2428 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s695571491x1881815669(v_sources_241, v_t_2427));
      return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam1, 1, 9, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2414, v_z_249, v_file_242, v_failed_245, v_bi_240, v_done_246})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_2488 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str13), NTAG(TAG_MkUnit)});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam8, 1, 2, (V[]){v_z_248, v_z_249})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam0(V self, V *args) {
  V v_o_2415 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2414, heff_rfield(v_o_2415, 1)));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_eff_2420 = v_field_2418;
      V v_t_2421 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2415, 0), heff_get_n(v_o_2415, 1, 2), v_eff_2420});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
    } else {
      heff_drop_rec(v_o_2415, 2);
      heff_drop(v_field_2418);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam4(V self, V *args) {
  V v_ok_2437 = args[0];
  return v_ok_2437;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam5(V self, V *args) {
  V v_x_2445 = args[0];
  V v_c_2414 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2446 = heff_bool(!(heff_dup(v_x_2445) == NTAG(TAG_True)));
  heff_drop(v_x_2445);
  V v_exports_2447 = (g_list_2emap_24s764064723x821001015(heff_take_field(v_c_2414, 7)));
  V v_roots_2448 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2447)));
  V v_t_2449 = heff_get_n(heff_get_n(v_c_2414, 5, 14), 0, 9);
  V v_t_2450 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2449));
  V v_t_2451 = (g_heff_2ecompile_2elower_2ecErased(v_roots_2448, v_t_2450));
  V v_t_2452 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2430, v_exports_2447, v_t_2451));
  return ({ V a_0 = v_outPath_244; V a_1 = v_t_2446; V a_2 = v_t_2452; V a_3 = v_z_248; V a_4 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2446); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam6(V self, V *args) {
  V v_o_2454 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2455 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2414, heff_rfield(v_o_2454, 1)));
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    if ((v_tag_2456 == ((int64_t)0ULL))) {
      V v_eff_2459 = v_field_2457;
      V v_t_2460 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2454, 0), heff_get_n(v_o_2454, 1, 2), v_eff_2459});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2460});
    } else {
      heff_drop_rec(v_o_2454, 2);
      heff_drop(v_field_2457);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam7(V self, V *args) {
  V v_x_2482 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_why_2472 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2482);
  V v_t_2483 = heff_strAppend(v_file_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str11), v_why_2472));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str12), v_t_2483);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_outPath_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_c_2414 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_x_2429 = heff_env(self)[6];
  V v_file_242 = heff_env(self)[7];
  V v_failed_245 = heff_env(self)[8];
  V v_bi_240 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_x_2429);
    heff_drop(v_file_242);
    heff_drop(v_failed_245);
    heff_drop(v_bi_240);
    heff_drop(v_done_246);
    int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
    V v_t_2433 = heff_strSlice(heff_dup(v_outPath_244), heff_box_word(v_t_2432), heff_strLength_lent(v_outPath_244, 0));
    V v_t_2436;
    if (heff_strEq_c(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str6))) {
      int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
      v_t_2436 = heff_strSlice_lent(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2435), 6);
    } else {
      v_t_2436 = heff_dup(v_outPath_244);
    }
    V v_t_2438 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str7)), v_x_2431, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam4_clo)});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s495635622x733177935(v_t_2444, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam5, 1, 5, (V[]){v_c_2414, v_x_2430, v_outPath_244, v_z_248, v_z_249})));
  }
  case TAG_Just: {
    V v_t_2461 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam6, 1, 1, (V[]){heff_dup(v_c_2414)}), heff_dup(heff_rfield(v_c_2414, 7))));
    V v_t_2462 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2461));
    V v_t_2463 = ({ V a_0 = v_t_2462; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2462); r_; });
    V v_leaves_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
    V v_t_2465 = heff_get_n(heff_dup(heff_rfield(v_c_2414, 5)), 0, 9);
    V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2429)}));
    V v_t_2467 = (g_list_2emap_24s164225955x66209884(v_t_2465, v_t_2466, v_leaves_2464));
    HeffT2 v_t_2468 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2467));
    {
      V v_field_2470 = v_t_2468.f[1];
      int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
      if ((v_tag_2469 == ((int64_t)0ULL))) {
        heff_drop(v_x_2431);
        heff_drop_tag(v_name_243, 1);
        heff_drop(v_outPath_244);
        heff_drop_rec(v_c_2414, 14);
        heff_drop(v_x_2430);
        heff_drop(v_x_2429);
        heff_drop(v_bi_240);
        heff_drop(v_done_246);
        V v_why_2472 = v_field_2470;
        V v_t_2473 = heff_strAppend(heff_dup(v_file_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str8), heff_dup(v_why_2472)));
        V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str9), v_t_2473), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str10));
        V v_t_2475 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2474, NTAG(TAG_MkUnit)});
        V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
        V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam7, 1, 5, (V[]){v_file_242, v_why_2472, v_failed_245, v_z_248, v_z_249})));
      } else {
        V v_ms_2484 = v_field_2470;
        V v_glues_2485 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2484));
        V v_t_2486 = (g_list_2emap_24s1435185561x202019164(v_glues_2485));
        V v_t_2487 = (g_prelude_2e_2b_2b(v_x_2429, v_t_2486));
        return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = heff_rec_n(2, shape_c__zig, (V[]){v_x_2430, v_x_2431}); V a_5 = v_failed_245; V a_6 = v_done_246; V a_7 = v_c_2414; V a_8 = v_t_2487; V a_9 = v_z_248; V a_10 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop_tag(v_name_243, 1); r_; });
      }
    }
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2414 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_x_2429 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_failed_245 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str5), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam3, 1, 11, (V[]){v_name_243, v_outPath_244, v_z_248, v_c_2414, v_x_2430, v_z_249, v_x_2429, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2414 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_failed_245 = heff_env(self)[6];
  V v_bi_240 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s338515064x741563400(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_str4), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam2, 1, 10, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2414, v_z_249, v_x_2429, v_file_242, v_failed_245, v_bi_240, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154_lam8(V self, V *args) {
  V v_x_2495 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24102}), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(V v_lit_240, V v_rep_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam0, 1, 9, (V[]){v_l_242, v_hd_247, v_rep_241, v_lit_240, v_k_248, v_file_245, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_sources_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2415 = (g_list_2efind_24s1973550603x1701528639_24cpr(heff_dup(v_c_2414), v_sources_2412));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2417;
      V v_t_2420 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2413, v_s_2419));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2414, v_t_2420));
    } else {
      heff_drop(v_x_2413);
      heff_drop(v_field_2417);
      return v_c_2414;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam4(V self, V *args) {
  V v_a_2444 = args[0];
  V v_z_2445 = args[1];
  V v_z_2446 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2444);
  V v_t_2447 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s22628809x1035315751(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), v_z_2445, v_z_2446));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_l_242 = heff_env(self)[6];
  V v_file_245 = heff_env(self)[7];
  V v_name_243 = heff_env(self)[8];
  V v_outPath_244 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2423);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop_rec(v_x_2411, 2);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_file_245);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    V v_x2_2425 = (g_heff_2ebuild_2ecommands_2efirstErrorOf(v_x_2421));
    heff_drop(v_x2_2425);
    V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s22628809x1035315751(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_247, v_k_248));
  } else {
    V v_t_2433 = (g_list_2eany_24s469495312x865582084(v_x_2421));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2411, 2);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_file_245);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2433);
      V v_x2_2434 = (g_heff_2ebuild_2ecommands_2efirstErrorOf(v_x_2421));
      heff_drop(v_x2_2434);
      V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
      return (g_co_2eop_24s22628809x1035315751(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_247, v_k_248));
    } else {
      heff_drop(v_t_2433);
      V v_t_2442 = (g_list_2emap_24s1698496827x1884878103(heff_take_field(v_x_2411, 0)));
      V v_t_2443 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_242, 2), heff_get_n(v_x_2411, 1, 2), v_t_2442});
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s334010137x1021656154(v_t_2443, heff_get_n(v_l_242, 0, 5), v_file_245, v_name_243, v_outPath_244, heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam4, 3, 1, (V[]){v_lit_240}), v_done_246, v_x_2421, v_hd_247, v_k_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_rep_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_file_245 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_sources_2412 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2413 = (g_list_2emap_24f1942081783x251284947(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_str2), heff_dup(v_sources_2412)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam2, 1, 2, (V[]){v_sources_2412, v_x_2413}), heff_dup(heff_rfield(v_x_2411, 0))));
  V v_c_2422 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_241, heff_dup(v_x_2421)));
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam3, 1, 11, (V[]){v_x_249, v_x_2421, v_lit_240, v_hd_247, v_k_248, v_x_2411, v_l_242, v_file_245, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_rep_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_file_245 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_l_242)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_lam1, 1, 10, (V[]){v_l_242, v_rep_241, v_hd_247, v_x_249, v_lit_240, v_k_248, v_file_245, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_str1, 13, "nothing there");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_str2, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197(V v_rep_240, V v_file_241, V v_offs_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(v_file_241));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam0, 2, 3, (V[]){v_c_243, v_rep_240, v_offs_242});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam5(V self, V *args) {
  V v_off_2418 = args[0];
  V v_c_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = ({ V a_0 = v_off_2418; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_off_2418); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_o_2423 = v_field_2421;
      HeffT2 v_t_2424 = (g_heff_2ebuild_2equery_2etypeAt_24cpr(v_c_2417, v_o_2423));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_x_2428 = v_field_2426;
          return v_x_2428;
        } else {
          heff_drop(v_field_2426);
          return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_str1);
        }
      }
    } else {
      heff_drop(v_c_2417);
      heff_drop(v_field_2421);
      return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_str2);
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_cs_2410 = heff_env(self)[0];
  V v_offs_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2412);
  HeffT2 v_t_2413 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2410));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_c_2417 = v_field_2415;
      V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam5, 1, 1, (V[]){v_c_2417}), v_offs_242));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(v_t_2429, v_hd_244, v_k_245));
    } else {
      heff_drop(v_offs_242);
      heff_drop(v_field_2415);
      V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_244, v_k_245));
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_cs_2410 = heff_get_n(v_x_249, 0, 2);
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_cs_2410)));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam4, 1, 4, (V[]){v_cs_2410, v_offs_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_offs_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_247);
  V v_c_248 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_246));
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam3, 1, 4, (V[]){v_rep_240, v_hd_244, v_offs_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_str0), heff_dup(heff_rfield(v_x_246, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_rep_240, v_offs_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s2042680416x668195197_lam1, 1, 4, (V[]){v_hd_244, v_rep_240, v_offs_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam2(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2418, 0ULL, 1);
    v_t_2420 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_242;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_240, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam2_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s920401334x23760898_lam3, 1, 1, (V[]){v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2410, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str1, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str3, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str4, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str5, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str6, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str8, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam11(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576(V v_rep_240, V v_v_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      heff_drop(v_x_246);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam0, 2, 2, (V[]){v_rep_240, v_v_241});
    } else {
      heff_drop(v_rep_240);
      heff_drop(v_field_244);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam11, 2, 1, (V[]){v_v_241});
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam1(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2449);
  V v_t_2450 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam9(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2466);
  V v_t_2467 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam10(V self, V *args) {
  V v_x_2482 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2482);
  V v_t_2483 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2489}), v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_cs_2438 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_v_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_dup(heff_rfield(v_x_2434, 3));
  switch (heff_tag_of(v_t_2441)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2434, 5);
    heff_drop(v_x_2435);
    heff_drop(v_cs_2438);
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str4), NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam8, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
  case TAG_Just: {
    V v_pk_2457 = heff_field(v_t_2441, 0);
    V v_ru_24t_2441_24Just = heff_take_reuse_n(v_t_2441, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2435)) {
      heff_drop_rec(v_x_2434, 5);
      heff_drop(v_cs_2438);
      heff_drop(v_rep_240);
      heff_drop(v_v_241);
      heff_drop(v_pk_2457);
      V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str5), NTAG(TAG_MkUnit)});
      V v_t_2460 = heff_tag_at_n(v_ru_24t_2441_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
      V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam9, 1, 2, (V[]){v_hd_247, v_k_248})));
    } else {
      V v_t_2474 = ({ V a_0 = v_cs_2438; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_2438); r_; });
      if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2434, 5);
        heff_drop(v_rep_240);
        heff_drop(v_v_241);
        heff_drop(v_pk_2457);
        heff_drop(v_t_2474);
        V v_t_2475 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str6), NTAG(TAG_MkUnit)});
        V v_t_2476 = heff_tag_at_n(v_ru_24t_2441_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
        V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam10, 1, 2, (V[]){v_hd_247, v_k_248})));
      } else {
        heff_drop_cell(v_ru_24t_2441_24Just, 1);
        heff_drop(v_t_2474);
        return (g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406(v_rep_240, v_v_241, v_x_2434, v_pk_2457, v_hd_247, v_k_248));
      }
    }
  }
  default: return heff_nomatch(v_t_2441);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_cs_2438 = heff_get_n(v_x_2437, 0, 2);
  V v_c_2439 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(heff_dup(v_rep_240), heff_dup(v_cs_2438)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam7, 1, 7, (V[]){v_x_2434, v_hd_247, v_k_248, v_x_2435, v_cs_2438, v_rep_240, v_v_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2436 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_x_2434)));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam6, 1, 6, (V[]){v_rep_240, v_hd_247, v_x_2434, v_k_248, v_x_2435, v_v_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str3), heff_dup(heff_rfield(v_x_2434, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam5, 1, 5, (V[]){v_x_2434, v_hd_247, v_rep_240, v_k_248, v_v_241})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str1), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam3, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2416, 0ULL, 1);
    V v_c_2433 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str2)));
    V f_ = v_c_2433;
    heff_room[0] = heff_dup(v_hd_247);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam4, 1, 4, (V[]){v_hd_247, v_rep_240, v_k_248, v_v_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_rep_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str0), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam2, 1, 4, (V[]){v_hd_247, v_k_248, v_rep_240, v_v_241})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam12(V self, V *args) {
  V v_x_24101 = args[0];
  V v_hd_2490 = heff_env(self)[0];
  V v_k_2491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24101);
  V v_t_24102 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24108}), v_hd_2490, v_k_2491));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam11(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k_2491 = args[1];
  V v_v_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2492 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str7), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str8)));
  V v_t_2493 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str9), v_t_2492), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_str10));
  V v_t_2494 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2493, NTAG(TAG_MkUnit)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24100}), heff_dup(v_hd_2490), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1777396780x883820576_lam12, 1, 2, (V[]){v_hd_2490, v_k_2491})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112(V v_before_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam0_clo)})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam1, 1, 5, (V[]){v_path_244, v_p_242, v_p_243, v_before_240, v_rest_245})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam0(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam3, 1, 1, (V[]){v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam4(V self, V *args) {
  V v_s_2432 = args[0];
  return v_s_2432;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam8(V self, V *args) {
  V v_i_2456 = args[0];
  V v_before_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_i_2456}));
  return ({ V a_0 = v_t_2457; V a_1 = v_before_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_before_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_st_2442 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_x_2444 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_src_2431 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2448 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str12), v_st_2442}), heff_dup(v_path_244)));
  V v_ps_2449 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str14), heff_take_field(v_x_2444, 0), heff_take_field(v_x_2444, 1), heff_take_field(v_x_2444, 2), heff_get_n(v_x_2444, 3, 5)});
  HeffT2 v_t_2450 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_2449), heff_get_n(v_ps_2449, 2, 6), heff_dup(v_path_244)));
  V v_library_2455;
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    v_library_2455 = heff_bool(((v_tag_2451 == ((int64_t)0ULL)) && ({ V v_x_2454 = heff_dup(v_field_2452); int c_ = 1; heff_drop(v_x_2454); c_; })));
    heff_drop(v_field_2452);
  }
  V v_t_2458 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam8, 1, 1, (V[]){v_before_240}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
  V v_t_2459 = heff_rec_n(8, shape_module__named__path__shown__source__renames__implicit__library, (V[]){heff_dup(v_m_2448), v_m_2448, heff_dup(v_path_244), v_path_244, v_src_2431, NTAG(TAG_Nil), v_t_2458, v_library_2455});
  V v_x_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_x_2447});
  V f_ = v_p_243;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_st_2442 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_src_2431 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2445 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str7), heff_dup(v_st_2442)}), heff_dup(v_path_244)));
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, heff_dup(v_before_240)});
  return (g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112(v_t_2446, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam7, 1, 6, (V[]){v_st_2442, v_path_244, v_x_2444, v_before_240, v_src_2431, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_src_2431 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2442;
  if (heff_strEq_c(v_x_2440, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str2))) {
    v_st_2442 = NTAG(TAG_Windows);
  } else {
    v_st_2442 = NTAG(TAG_Posix);
  }
  V v_c_2443 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo);
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam6, 1, 7, (V[]){v_st_2442, v_path_244, v_before_240, v_rest_245, v_p_242, v_src_2431, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    heff_drop(v_before_240);
    heff_drop(v_rest_245);
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str0), v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_str1));
    V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam2, 1, 2, (V[]){v_p_242, v_p_243})));
  }
  case TAG_Just: {
    V v_src_2431 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Just = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2433 = heff_tag_at_n(v_ru_24x_2413_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam4_clo)})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s495635622x733177935(v_t_2439, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s332464098x807949112_lam5, 1, 6, (V[]){v_p_242, v_path_244, v_before_240, v_rest_245, v_src_2431, v_p_243})));
  }
  default: return heff_nomatch(v_x_2413);
  }
}