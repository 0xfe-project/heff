// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Start 63542
#define TAG_UseColor 15915
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_code 9554612
#define LBL_cwd 308458
#define LBL_done 9584713
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_out 319944
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_shipTo 1043811586
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_status 1054660381
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_clo;
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_clo;
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843(V, V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo;
V g_heff_2ebuild_2ecommands_2ereachOnly(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereachOnly_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachOnly_clo;
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_clo;
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517(V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_clo;
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118(V, V);
V g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118_clo;
V g_heff_2ebuild_2ecommands_2erefusedReaching(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2edriver_2eevaluate(V);
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevaluate_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2erelFrom(V, V, V);
V g_heff_2ebuild_2eload_2erelFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erelFrom_clo;
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
V g_heff_2ebuild_2eproject_2emajorMismatch(V, V);
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo;
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1490692278x809324339(V);
V g_list_2efilter_24s1490692278x809324339_entry(V self, V *a);
extern Clo g_list_2efilter_24s1490692278x809324339_clo;
V g_list_2efilter_24s313075719x1688564285(V);
V g_list_2efilter_24s313075719x1688564285_entry(V self, V *a);
extern Clo g_list_2efilter_24s313075719x1688564285_clo;
V g_list_2efind_24s1230956425x1562898054(V, V);
V g_list_2efind_24s1230956425x1562898054_entry(V self, V *a);
extern Clo g_list_2efind_24s1230956425x1562898054_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1048217315x1968986417(V, V, V);
V g_list_2efoldl_24f1048217315x1968986417_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1048217315x1968986417_clo;
V g_list_2efoldl_24f1117322828x1334654706(V, V, V);
V g_list_2efoldl_24f1117322828x1334654706_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1117322828x1334654706_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str0, 4, "std.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str1, 81, "` is an effect of the system (lib/std/), for C: it has no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str2, 1, "`");
Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erefusedReaching_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erefusedReaching(V v_host_240, V v_sources_241, V v_only_242, V v_s_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_s_243, 6));
  V v_t_247 = heff_bool(((heff_dup(v_t_244) == NTAG(TAG_True)) ? ({ V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_s_243, 0)), MK_INT(0LL), MK_INT(4LL)); int c_ = !heff_strEq_c(heff_dup(v_t_245), ((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str0)); heff_drop(v_t_245); c_; }) : 1));
  heff_drop(v_t_244);
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_host_240);
    heff_drop_rec(v_s_243, 7);
    heff_drop(v_t_247);
    return NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_247);
    V v_t_248 = (g_list_2eany_24s2065989517x1307020881(heff_dup(heff_rfield(v_s_243, 0)), v_only_242));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_243, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str1), v_host_240));
      V v_t_2410 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_243, 0, 7), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str2), v_t_249), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
    } else {
      heff_drop(v_t_248);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_s_243, 0)), NTAG(TAG_Nil)});
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_x3_2413 = (g_heff_2ebuild_2ecommands_2ereachOnly(v_sources_241, v_only_242, NTAG(TAG_Nil), v_t_2412));
      switch (heff_tag_of(v_x3_2413)) {
      case TAG_Nothing: {
        heff_drop(v_host_240);
        heff_drop_rec(v_s_243, 7);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_2414 = heff_field(v_x3_2413, 0);
        V v_ru_24x3_2413_24Just = heff_take_reuse_n(v_x3_2413, 1ULL, 1);
        V v_t_2415 = (g_heff_2ebuild_2ecommands_2ereachingRefused(v_host_240, v_s_243, v_x_2414));
        return heff_tag_at_n(v_ru_24x3_2413_24Just, TAG_Just, 1, (V[]){v_t_2415});
      }
      default: return heff_nomatch(v_x3_2413);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2erefusedReaching(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str2, 22, " with expected errors)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str3, 27, " files check as they should");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str5, 2, ", ");
Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efilesSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efilesSaid(V v_r_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_240, 4)));
  V v_t_242 = heff_intSub(heff_dup(heff_rfield(v_r_240, 0)), v_t_241);
  V v_t_243 = heff_intShow(heff_take_field(v_r_240, 0));
  V v_t_246;
  if (heff_intEq_c(heff_dup(heff_rfield(v_r_240, 1)), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 7);
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str0);
  } else {
    V v_t_245 = heff_intShow(heff_get_n(v_r_240, 1, 7));
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str2)));
  }
  V v_t_247 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str3), v_t_246));
  V v_t_248 = heff_strAppend(heff_intShow(v_t_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str4), v_t_247));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str5), v_t_248);
}
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efilesSaid(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2(V self, V *args) {
  V v_v_247 = args[0];
  return v_v_247;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2423;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str3))) {
    v_st_2423 = NTAG(TAG_Windows);
  } else {
    v_st_2423 = NTAG(TAG_Posix);
  }
  V v_x_2430;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_2426;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2416)) {
      case TAG_Nothing: {
        v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2424 = heff_field(v_x_2416, 0);
        heff_take_n(v_x_2416, 1ULL, 1);
        v_t_2426 = v_x_2424;
        break;
      }
      default: heff_nomatch(v_x_2416);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop(v_x_2416);
      v_t_2426 = v_x_2425;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_2427 = (g_std_2epath_2ejoin(v_st_2423, v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str5)));
    V v_t_2428 = (g_std_2epath_2ejoin(v_st_2423, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str6), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str7)));
    v_x_2430 = ({ V a_0 = v_st_2423; V a_1 = v_t_2427; V a_2 = v_t_2428; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2423); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2429 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_2416);
    heff_drop(v_st_2423);
    v_x_2430 = v_d_2429;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V f_ = v_k_241;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam7, 1, 4, (V[]){v_x_246, v_x_2411, v_x_2416, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam5, 1, 4, (V[]){v_hd_240, v_x_246, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam3, 1, 3, (V[]){v_hd_240, v_x_246, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(a[0]);
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_x1_2414 = (g_heff_2ebuild_2eproject_2epackageLit(v_src_2413));
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Left: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2412_24Just, 1);
      v_x_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      V v_t_2417 = ({ V a_0 = v_x_2416; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2416); r_; });
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Left: {
        heff_take_n(v_t_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x_2412_24Just, 1);
        v_x_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Right: {
        V v_p_2419 = heff_field(v_t_2417, 0);
        heff_take_n(v_t_2417, 1ULL, 1);
        v_x_2420 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2419, 1, 4)});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2421 = ({ V a_0 = v_x_2420; V a_1 = heff_dup(heff_rfield(v_x_246, 4)); V r_ = (g_heff_2ebuild_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2420); r_; });
  V v_x_2422 = (g_list_2efoldl_24s571074576x1179600767(v_x_246, v_t_2421));
  V f_ = v_k_243;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_247, ((V)&g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam5, 1, 2, (V[]){v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam3, 1, 3, (V[]){v_hd_242, v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(v_x_244, v_file_240));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(v_sources_240, v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(a_0, a_1)); heff_drop(v_sources_240); r_; });
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str0), v_e_243), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str1));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(v_rest_244, v_p_241, v_p_242));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str1, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str5, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(V v_f_240, V v_wrong_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_UseColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam1, 1, 6, (V[]){v_ts_242, v_f_240, v_hd_244, v_os_243, v_wrong_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_wrong_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2439 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_242; V r_ = (g_list_2efoldl_24f1117322828x1334654706(a_0, a_1, a_2)); heff_drop(v_ts_242); r_; });
  V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_243));
  V v_t_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_243; V r_ = (g_list_2efoldl_24f1048217315x1968986417(a_0, a_1, a_2)); heff_drop(v_os_243); r_; });
  V v_x_2442 = heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){MK_INT(1LL), MK_INT(0LL), v_t_2438, v_t_2439, v_wrong_241, v_t_2440, v_t_2441});
  V f_ = v_k_245;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_wrong_241 = heff_env(self)[2];
  V v_f_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  V v_x1_2415 = (g_list_2efilter_24s313075719x1688564285(heff_dup(v_ts_242)));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nil: {
    V v_x1_2416 = (g_list_2efilter_24s1490692278x809324339(heff_dup(v_os_243)));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_wrong_241)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str0);
        break;
      }
      case TAG_Cons: {
        v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str1);
        break;
      }
      default: heff_nomatch(v_wrong_241);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2416, 0ULL, 2);
      v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str2);
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2415, 0ULL, 2);
    v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str3);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2425 = (g_list_2efoldl_24f1117322828x1334654706(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2426 = heff_intShow(heff_intSub(v_t_2424, v_t_2425));
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2428 = (g_heff_2ebuild_2ecommands_2etestsSaid(v_os_243));
  V v_t_2429 = heff_strAppend(heff_intShow(v_t_2427), v_t_2428);
  V v_t_2430 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str4), v_t_2429));
  V v_t_2431 = heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str5), v_t_2430));
  V v_str_2432 = heff_strAppend(v_t_2423, v_t_2431);
  V v_t_2433 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2432, ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str6)), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s954557541x749476273(v_t_2436, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam4, 1, 4, (V[]){v_ts_242, v_os_243, v_wrong_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ts_242 = heff_env(self)[3];
  V v_wrong_241 = heff_env(self)[4];
  V v_f_240 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_c_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_os_243); V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam3, 1, 6, (V[]){v_ts_242, v_os_243, v_wrong_241, v_f_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_os_243 = heff_env(self)[3];
  V v_wrong_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2410 = (g_list_2efilter_24s313075719x1688564285(heff_dup(v_ts_242)));
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(heff_dup(v_f_240), v_x_249, v_t_2410));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam2, 1, 7, (V[]){v_x_249, v_os_243, v_hd_244, v_ts_242, v_wrong_241, v_f_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str1, 11, ".provider.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str2, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str3, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str4, 1, "\012");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272(V v_host_240, V v_s_241, V v_p_242, V v_p_243) {
top: ;
  V v_p_244 = heff_dup(heff_rfield(v_s_241, 1));
  V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_p_244)), MK_INT(3LL));
  V v_t_246 = heff_strSlice(heff_dup(v_p_244), v_t_245, heff_strLength(heff_dup(v_p_244)));
  V v_t_249;
  if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str0))) {
    V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_p_244)), MK_INT(3LL));
    v_t_249 = heff_strSlice(v_p_244, MK_INT(0LL), v_t_248);
  } else {
    v_t_249 = v_p_244;
  }
  V v_path_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str1));
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2410, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam1, 1, 4, (V[]){v_s_241, v_p_242, v_host_240, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam0(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam2(V self, V *args) {
  V v_t_2423 = args[0];
  return v_t_2423;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2436;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop(v_x_2427);
    heff_drop(v_host_240);
    v_x_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2415, 0ULL, 1);
    V v_x1_2435;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_Nothing: {
      heff_drop(v_host_240);
      v_x1_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_t_2429 = heff_field(v_x_2427, 0);
      heff_take_n(v_x_2427, 1ULL, 1);
      V v_t_2430 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str4), v_t_2429, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2431 = (g_list_2emap_24s649333309x1802289391(v_t_2430));
      V v_x1_2432 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2431));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_Nil: {
        heff_drop(v_host_240);
        v_x1_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        V v_x_2433 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 2);
        v_x1_2435 = heff_strEq(v_x_2433, v_host_240);
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    v_x_2436 = heff_bool(!(heff_dup(v_x1_2435) == NTAG(TAG_True)));
    heff_drop(v_x1_2435);
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_p_243;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_2416 = heff_get_n(v_s_241, 1, 7);
  V v_t_2417 = heff_intSub(heff_strLength(heff_dup(v_p_2416)), MK_INT(3LL));
  V v_t_2418 = heff_strSlice(heff_dup(v_p_2416), v_t_2417, heff_strLength(heff_dup(v_p_2416)));
  V v_t_2421;
  if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str2))) {
    V v_t_2420 = heff_intSub(heff_strLength(heff_dup(v_p_2416)), MK_INT(3LL));
    v_t_2421 = heff_strSlice(v_p_2416, MK_INT(0LL), v_t_2420);
  } else {
    v_t_2421 = v_p_2416;
  }
  V v_path_2422 = heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_str3));
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2422, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam2_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s954557541x749476273(v_t_2426, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1524477871x906080272_lam3, 1, 3, (V[]){v_x_2415, v_host_240, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517(V v_host_240, V v_sources_241, V v_cs_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2erefusedFor_24s1666913177x1861306118(v_host_240, heff_dup(v_sources_241)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam0, 2, 3, (V[]){v_c_243, v_sources_241, v_cs_242});
}
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam2(V self, V *args) {
  V v_c_247 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = ({ V a_0 = heff_dup(v_c_247); V a_1 = v_sources_241; V r_ = (g_list_2efind_24s1230956425x1562898054(a_0, a_1)); heff_drop(v_sources_241); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_246);
    return v_c_247;
  }
  case TAG_Just: {
    V v_s_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_t_2410 = ({ V a_0 = v_x_246; V a_1 = v_s_249; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_246); r_; });
    return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_247, v_t_2410));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_cs_242 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2411 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam2, 1, 2, (V[]){v_sources_241, v_x_246}), v_cs_242));
  V f_ = v_k_245;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_sources_241 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = v_hd_244;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erefusedChecked_24s912365115x2066206517_lam1, 1, 3, (V[]){v_sources_241, v_cs_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam0, 2, 1, (V[]){v_c_241});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513(a[0]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_cs_248 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V v_t_2410 = ({ V a_0 = v_cs_248; V r_ = (g_heff_2ebuild_2edriver_2elastChecked(a_0)); heff_drop(v_cs_248); r_; });
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_c_2415 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    V v_t_2416 = (g_heff_2ebuild_2equery_2eexplain(v_c_2415));
    return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_t_2416, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_cs_248 = heff_get_n(v_x_247, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_248), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam4, 1, 3, (V[]){v_cs_248, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_245);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam3, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam2, 1, 3, (V[]){v_x_244, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam1, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str4, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str5, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str8, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str10, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str12, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str14, 9, "that of /");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str15, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str16, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str17, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str18, 20, " (vA.B.C, its major ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str19, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str20, 17, " is a version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str21, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str22, 10, "no tag of ");
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str0), heff_dup(v_path_240)), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0_clo)});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_244}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam5(V self, V *args) {
  V v_best_2427 = args[0];
  V v_line_2428 = args[1];
  V v_path_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_it_2429 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str10), v_line_2428, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_2429)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_2427;
  }
  case TAG_Cons: {
    V v_it2_2431 = heff_field(v_it_2429, 1);
    heff_take_n(v_it_2429, 2ULL, 2);
    switch (heff_tag_of(v_it2_2431)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      return v_best_2427;
    }
    case TAG_Cons: {
      V v_v_2432 = heff_field(v_it2_2431, 0);
      V v_it22_2433 = heff_field(v_it2_2431, 1);
      heff_take_n(v_it2_2431, 3ULL, 2);
      switch (heff_tag_of(v_it22_2433)) {
      case TAG_Nil: {
        V v_t_2434 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2435 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
        V v_t_2436 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2435, MK_INT(-1LL)));
        V v_t_2437 = heff_strSlice(heff_dup(v_v_2432), v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
        V v_t_2438 = (g_heff_2ebuild_2eproject_2eversion(v_t_2437));
        switch (heff_tag_of(v_t_2438)) {
        case TAG_Nothing: {
          heff_drop(v_path_240);
          heff_drop(v_v_2432);
          return v_best_2427;
        }
        case TAG_Just: {
          V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 0ULL, 1);
          V v_t_2440 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
          V v_t_2441 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
          V v_t_2442 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2441, MK_INT(-1LL)));
          V v_t_2443 = heff_strSlice(heff_dup(v_v_2432), v_t_2440, heff_intAdd(v_t_2442, MK_INT(1LL)));
          V v_t_2444 = (g_heff_2ebuild_2eproject_2emajorMismatch(v_path_240, v_t_2443));
          switch (heff_tag_of(v_t_2444)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_best_2427)) {
            case TAG_Nothing: {
              V v_t_2445 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2446 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
              V v_t_2447 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2446, MK_INT(-1LL)));
              V v_t_2448 = heff_strSlice(v_v_2432, v_t_2445, heff_intAdd(v_t_2447, MK_INT(1LL)));
              return heff_tag_at_n(v_ru_24t_2438_24Just, TAG_Just, 1, (V[]){v_t_2448});
            }
            case TAG_Just: {
              V v_b_2449 = heff_dup(heff_field(v_best_2427, 0));
              V v_t_2450 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2451 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
              V v_t_2452 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2451, MK_INT(-1LL)));
              V v_a_2453 = heff_strSlice(heff_dup(v_v_2432), v_t_2450, heff_intAdd(v_t_2452, MK_INT(1LL)));
              V v_x2_2454 = (g_heff_2ebuild_2eproject_2eversion(v_a_2453));
              V v_t_2456;
              switch (heff_tag_of(v_x2_2454)) {
              case TAG_Nothing: {
                v_t_2456 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2455 = heff_field(v_x2_2454, 0);
                heff_take_n(v_x2_2454, 1ULL, 1);
                v_t_2456 = v_x_2455;
                break;
              }
              default: heff_nomatch(v_x2_2454);
              }
              V v_x2_2457 = (g_heff_2ebuild_2eproject_2eversion(v_b_2449));
              V v_t_2459;
              switch (heff_tag_of(v_x2_2457)) {
              case TAG_Nothing: {
                v_t_2459 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2458 = heff_field(v_x2_2457, 0);
                heff_take_n(v_x2_2457, 1ULL, 1);
                v_t_2459 = v_x_2458;
                break;
              }
              default: heff_nomatch(v_x2_2457);
              }
              V v_t_2460 = ({ V a_0 = v_t_2456; V a_1 = v_t_2459; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2456); heff_drop(v_t_2459); r_; });
              if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
                heff_drop_tag(v_best_2427, 1);
                heff_drop(v_t_2460);
                V v_t_2461 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
                V v_t_2462 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
                V v_t_2463 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2462, MK_INT(-1LL)));
                V v_t_2464 = heff_strSlice(v_v_2432, v_t_2461, heff_intAdd(v_t_2463, MK_INT(1LL)));
                return heff_tag_at_n(v_ru_24t_2438_24Just, TAG_Just, 1, (V[]){v_t_2464});
              } else {
                heff_drop(v_v_2432);
                heff_drop_cell(v_ru_24t_2438_24Just, 1);
                heff_drop(v_t_2460);
                return v_best_2427;
              }
            }
            default: return heff_nomatch(v_best_2427);
            }
          }
          case TAG_Just: {
            heff_take_n(v_t_2444, 0ULL, 1);
            heff_drop(v_v_2432);
            heff_drop_cell(v_ru_24t_2438_24Just, 1);
            return v_best_2427;
          }
          default: return heff_nomatch(v_t_2444);
          }
        }
        default: return heff_nomatch(v_t_2438);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2433, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop(v_v_2432);
        return v_best_2427;
      }
      default: return heff_nomatch(v_it22_2433);
      }
    }
    default: return heff_nomatch(v_it2_2431);
    }
  }
  default: return heff_nomatch(v_it_2429);
  }
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2416);
  V v_t_2418 = heff_bool(!heff_intEq_c(heff_dup(heff_rfield(v_x_2414, 0)), MK_INT(0LL)));
  V v_x_2489;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    V v_t_2419 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
    V v_s_2420 = heff_get_n(v_x_2414, 2, 3);
    V v_t_2421 = (g_prelude_2eskipSpaces(heff_dup(v_s_2420), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2422 = heff_intSub(heff_strLength(heff_dup(v_s_2420)), MK_INT(1LL));
    V v_t_2423 = (g_prelude_2eskipSpaces(heff_dup(v_s_2420), v_t_2422, MK_INT(-1LL)));
    V v_t_2424 = heff_strSlice(v_s_2420, v_t_2421, heff_intAdd(v_t_2423, MK_INT(1LL)));
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str6), v_t_2419), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str7), v_t_2424));
    v_x_2489 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str8), v_t_2425)});
  } else {
    heff_drop(v_t_2418);
    V v_t_2426 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str9), heff_get_n(v_x_2414, 1, 3), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2468 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam5, 2, 1, (V[]){heff_dup(v_path_240)}); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
    switch (heff_tag_of(v_t_2468)) {
    case TAG_Nothing: {
      V v_t_2469 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
      V v_xs_2470 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str11), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2470));
      V v_x_2474;
      switch (heff_tag_of(v_t_2471)) {
      case TAG_Nil: {
        v_x_2474 = heff_dup(v_path_240);
        break;
      }
      case TAG_Cons: {
        V v_x_2472 = heff_field(v_t_2471, 0);
        heff_take_n(v_t_2471, 1ULL, 2);
        v_x_2474 = v_x_2472;
        break;
      }
      default: heff_nomatch(v_t_2471);
      }
      V v_t_2484;
      if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_x_2474)))) {
        if (heff_strEq_c(heff_strSlice(heff_dup(v_x_2474), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str12))) {
          V v_t_2477 = heff_strSlice(heff_dup(v_x_2474), MK_INT(1LL), heff_strLength(v_x_2474));
          V v_t_2478 = (g_heff_2ebuild_2eproject_2eisNumber(v_t_2477));
          if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
            heff_drop(v_t_2478);
            V v_xs_2479 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str13), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
            V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2479));
            V v_t_2483;
            switch (heff_tag_of(v_t_2480)) {
            case TAG_Nil: {
              v_t_2483 = heff_dup(v_path_240);
              break;
            }
            case TAG_Cons: {
              V v_x_2481 = heff_field(v_t_2480, 0);
              heff_take_n(v_t_2480, 1ULL, 2);
              v_t_2483 = v_x_2481;
              break;
            }
            default: heff_nomatch(v_t_2480);
            }
            v_t_2484 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str14), v_t_2483);
          } else {
            heff_drop(v_t_2478);
            v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str15);
          }
        } else {
          heff_drop(v_x_2474);
          v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str16);
        }
      } else {
        heff_drop(v_x_2474);
        v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str17);
      }
      V v_t_2485 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str18), heff_strAppend(v_t_2484, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str19)));
      V v_t_2486 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str20), heff_strAppend(v_path_240, v_t_2485));
      V v_t_2487 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str21), v_t_2469), v_t_2486);
      v_x_2489 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str22), v_t_2487)});
      break;
    }
    case TAG_Just: {
      V v_v_2488 = heff_field(v_t_2468, 0);
      V v_ru_24t_2468_24Just = heff_take_reuse_n(v_t_2468, 1ULL, 1);
      heff_drop(v_path_240);
      v_x_2489 = heff_tag_at_n(v_ru_24t_2468_24Just, TAG_Right, 1, (V[]){v_v_2488});
      break;
    }
    default: heff_nomatch(v_t_2468);
    }
  }
  V f_ = v_k_242;
  args[0] = v_x_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_End, 2, (V[]){v_x_245, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2415}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam4, 1, 3, (V[]){v_x_2414, v_path_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str1), v_t_246), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str3), v_t_247})});
  V v_as_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str4), v_t_248});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str5), v_as_249, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam3, 1, 4, (V[]){v_x_245, v_hd_241, v_path_240, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(V v_st_240, V v_t_241, V v_progs_242, V v_z_243, V v_z_244) {
top: ;
  V v_p_245 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str1)));
  V v_path_246 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_245));
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_246, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam1, 1, 5, (V[]){v_progs_242, v_z_243, v_st_240, v_t_241, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_t_2416 = heff_env(self)[2];
  V v_progs_242 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_k_2418 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2420);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_t_2416; V a_3 = v_progs_242; V a_4 = v_hd_2417; V a_5 = v_k_2418; V r_ = (g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_242); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_t_2416 = heff_env(self)[3];
  V v_progs_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2419}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam5, 1, 6, (V[]){v_st_240, v_t_241, v_t_2416, v_progs_242, v_hd_2417, v_k_2418})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_progs_242), heff_dup(heff_rfield(v_t_241, 4))));
  V v_t_2421 = ({ V a_0 = heff_dup(v_st_240); V a_1 = heff_dup(v_t_241); V a_2 = heff_dup(v_x_2415); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam4, 2, 5, (V[]){v_x_2415, v_st_240, v_t_241, v_t_2416, heff_dup(v_progs_242)}); V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_242); r_; });
  V f_ = v_t_2421;
  heff_room[0] = v_z_243;
  heff_room[1] = v_z_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V v_total_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_242));
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str2), v_total_2412, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam3, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_z_243, v_z_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_z_244, V v_z_245) {
top: ;
  V v_p_246 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str1)));
  V v_path_247 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_246));
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam1, 1, 6, (V[]){v_progs_243, v_z_244, v_st_240, v_t_241, v_done_242, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_t_2417 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_2418 = heff_env(self)[4];
  V v_k_2419 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2421);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_t_2417; V a_3 = v_progs_243; V a_4 = v_hd_2418; V a_5 = v_k_2419; V r_ = (g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2416 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_t_2417 = heff_env(self)[3];
  V v_progs_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2420}), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam5, 1, 6, (V[]){v_st_240, v_t_241, v_t_2417, v_progs_243, v_hd_2418, v_k_2419})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(heff_dup(v_st_240), heff_dup(v_t_241), v_done_242, heff_dup(v_progs_243), heff_dup(heff_rfield(v_t_241, 4))));
  V v_t_2422 = ({ V a_0 = heff_dup(v_st_240); V a_1 = heff_dup(v_t_241); V a_2 = heff_dup(v_x_2416); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam4, 2, 5, (V[]){v_x_2416, v_st_240, v_t_241, v_t_2417, heff_dup(v_progs_243)}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2422;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2412);
  V v_total_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str2), v_total_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_z_244, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(V v_x1_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(MK_INT(2026LL), heff_dup(v_f_244), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam0, 1, 4, (V[]){v_acc_241, heff_dup(v_rest_245), v_p_242, v_p_243}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_241, v_x_246));
  return ({ V a_0 = v_rest_245; V a_1 = v_t_247; V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(V v_before_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0_clo)})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam1, 1, 5, (V[]){v_path_244, v_p_242, v_p_243, v_before_240, v_rest_245})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam3, 1, 1, (V[]){v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  return v_s_2423;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam8(V self, V *args) {
  V v_i_2440 = args[0];
  V v_before_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_i_2440}));
  return ({ V a_0 = v_t_2441; V a_1 = v_before_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_before_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_2429 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_src_2422 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2435 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str12), v_st_2429}), heff_dup(v_path_244)));
  V v_ps_2436 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str14), heff_take_field(v_x_2431, 0), heff_take_field(v_x_2431, 1), heff_take_field(v_x_2431, 2), heff_get_n(v_x_2431, 3, 5)});
  V v_t_2437 = (g_heff_2ebuild_2eload_2erelFrom(heff_dup(v_ps_2436), heff_get_n(v_ps_2436, 2, 6), heff_dup(v_path_244)));
  V v_library_2439;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nothing: {
    v_library_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_library_2439 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_t_2442 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam8, 1, 1, (V[]){v_before_240}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
  V v_t_2443 = heff_rec_n(7, shape_module__path__shown__source__renames__implicit__library, (V[]){v_m_2435, heff_dup(v_path_244), v_path_244, v_src_2422, NTAG(TAG_Nil), v_t_2442, v_library_2439});
  V v_x_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_x_2434});
  V f_ = v_p_243;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_2429 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_src_2422 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2432 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str7), heff_dup(v_st_2429)}), heff_dup(v_path_244)));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_dup(v_before_240)});
  return (g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(v_t_2433, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam7, 1, 6, (V[]){v_st_2429, v_path_244, v_x_2431, v_before_240, v_src_2422, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_src_2422 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2429;
  if (heff_strEq_c(v_x_2427, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str2))) {
    v_st_2429 = NTAG(TAG_Windows);
  } else {
    v_st_2429 = NTAG(TAG_Posix);
  }
  V v_c_2430 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam6, 1, 7, (V[]){v_st_2429, v_path_244, v_before_240, v_rest_245, v_p_242, v_src_2422, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_before_240);
    heff_drop(v_rest_245);
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str0), v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str1));
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam2, 1, 2, (V[]){v_p_242, v_p_243})));
  }
  case TAG_Just: {
    V v_src_2422 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4_clo)})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam5, 1, 6, (V[]){v_p_242, v_path_244, v_before_240, v_rest_245, v_src_2422, v_p_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(V v_badL_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badL_240)})));
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_badL_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_badL_240) == NTAG(TAG_True))) {
    heff_drop(v_x_2412);
    heff_drop(v_badL_240);
    heff_drop(v_cs_241);
    V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_242, v_k_243));
  } else {
    heff_drop(v_badL_240);
    V v_t_2417 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s1996724342x1838336560(a_0)); heff_drop(v_cs_241); r_; });
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_t_2417);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s954557541x749476273(v_t_2421, v_hd_242, v_k_243));
    } else {
      heff_drop(v_t_2417);
      if ((heff_dup(v_x_2412) == NTAG(TAG_True))) {
        heff_drop(v_x_2412);
        V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        return (g_co_2eop_24s954557541x749476273(v_t_2425, v_hd_242, v_k_243));
      } else {
        heff_drop(v_x_2412);
        heff_drop(v_hd_242);
        V f_ = v_k_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badL_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badL_240);
    V v_t_246 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s954557541x749476273(v_t_249, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_c_2410 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2411 = (g_heff_2ebuild_2edriver_2eevaluate(v_c_2410));
    return (g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam1, 1, 4, (V[]){v_badL_240, v_hd_242, v_k_243, v_cs_241})));
  }
  default: return heff_nomatch(v_t_245);
  }
}