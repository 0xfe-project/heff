// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_aliases 1464806715
#define LBL_apps 9496377
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_c 317
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_opt 319789
#define LBL_own 320000
#define LBL_packages 1496006433
#define LBL_pages 307784670
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_seen 10021698
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_syntax 1059664654
#define LBL_top 324559
#define LBL_tySyntax 1405311289
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406(V, V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(V, V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(V, V);
V g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24f1176765648x1638512070(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s328934344x1728860012(V, V);
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_2412 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2414 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2412), v_x_2413));
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_a_2414));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2412), ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_str1)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  V v_x_2418 = ({ V a_0 = v_st_2412; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop(v_t_2417); r_; });
  V f_ = v_k_242;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_2412;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_str0))) {
    v_st_2412 = NTAG(TAG_Windows);
  } else {
    v_st_2412 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(v_e_240, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_lam2, 1, 2, (V[]){v_st_2412, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam7, 3, 0};
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V v_e_240, V v_file_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ehostNow_24s1752554670x2084139895(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam0, 1, 4, (V[]){v_e_240, v_file_241, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    heff_take_n(v_x_2415, 0ULL, 1);
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    v_t_2418 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Just, 1, (V[]){v_y_2417});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2414;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam4, 1, 1, (V[]){v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam1(V self, V *args) {
  V v_p_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_245));
  V v_c_247 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_246; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_246); r_; });
  V v_t_248 = (g_exception_2eattempted(v_e_240));
  V v_c_2412 = heff_tr(heff_call(v_c_247, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam2_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam3, 2, 1, (V[]){v_c_2412});
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    V v_t_2431 = (g_heff_2ebuild_2ecommands_2eheffErrors(NTAG(TAG_Nothing), heff_dup(heff_rfield(v_x_2420, 4))));
    V v_x_2432 = (g_list_2efoldl_24s571074576x1179600767(v_x_2420, v_t_2431));
    V f_ = v_k_243;
    args[0] = v_x_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2433 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Right = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    HeffT2 v_t_2434 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2433));
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      V v_x_2444;
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2429_24Right, 1);
        V v_p_2437 = v_field_2436;
        heff_drop(v_p_2437);
        v_x_2444 = NTAG(TAG_Nothing);
      } else {
        V v_x_2438 = v_field_2436;
        HeffT2 v_t_2439 = ({ V a_0 = v_x_2438; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2438); r_; });
        {
          V v_field_2441 = v_t_2439.f[1];
          int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
          if ((v_tag_2440 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2429_24Right, 1);
            V v_x_2442 = v_field_2441;
            heff_drop(v_x_2442);
            v_x_2444 = NTAG(TAG_Nothing);
          } else {
            V v_p_2443 = v_field_2441;
            v_x_2444 = heff_tag_at_n(v_ru_24x_2429_24Right, TAG_Just, 1, (V[]){heff_get_n(v_p_2443, 1, 4)});
          }
        }
      }
      V v_t_2445 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2444, heff_dup(heff_rfield(v_x_2420, 4))));
      V v_x_2446 = (g_list_2efoldl_24s571074576x1179600767(v_x_2420, v_t_2445));
      V f_ = v_k_243;
      args[0] = v_x_2446;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2421));
  V v_c_2423 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2422; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2422); r_; });
  V v_t_2424 = (g_exception_2eattempted(v_e_240));
  V v_c_2428 = heff_tr(heff_call(v_c_2423, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam7_clo)}));
  V f_ = v_c_2428;
  heff_room[0] = v_hd_242;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam8, 1, 2, (V[]){v_x_2420, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam6, 1, 4, (V[]){v_e_240, v_hd_242, v_x_2420, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_file_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2419 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(heff_dup(v_e_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam1, 1, 1, (V[]){heff_dup(v_e_240)}), v_x_244, v_file_241));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_lam5, 1, 3, (V[]){v_e_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503(V v_e_240, V v_ps_241, V v_b_242, V v_id_243, V v_z_244, V v_z_245) {
top: ;
  V v_s_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_246));
  V v_c_248 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_247; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_247); r_; });
  V v_t_249 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2413 = heff_tr(heff_call(v_c_248, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam0_clo)}));
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam1, 1, 6, (V[]){v_ps_241, v_id_243, v_b_242, v_e_240, v_z_244, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V f_ = v_z_245;
  args[0] = v_id_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  V v_d_2415 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
  V v_st_2416 = heff_get_n(v_ps_241, 5, 6);
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_d_2415));
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2416), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_str0)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_t_2420 = ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2419); r_; });
  V v_t_2421 = heff_strAppend(heff_strAppend(heff_dup(v_id_243), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_str1)), v_b_242);
  V v_c_2422 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911(v_e_240, v_t_2420, v_t_2421));
  V f_ = v_c_2422;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s2107132273x280913503_lam2, 1, 2, (V[]){v_z_245, v_id_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam4, 3, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam8, 3, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162(V v_e_240, V v_dir_241, V v_x2_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_dir_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_name_247 = heff_field(v_x21_245, 0);
      V v_text_248 = heff_field(v_x21_245, 1);
      V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam0_clo)})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2416, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam1, 1, 7, (V[]){v_dir_241, heff_dup(v_name_247), v_e_240, v_p_243, heff_dup(v_text_248), heff_dup(v_rest_246), v_p_244})));
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam0(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448;
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Left: {
    heff_take_n(v_x_2445, 0ULL, 1);
    v_t_2448 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2445, 0ULL, 1);
    v_t_2448 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2445);
  }
  V f_ = v_k_2444;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam6, 1, 1, (V[]){v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam7(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam8(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2456 = args[1];
  V v_k_2457 = args[2];
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_k_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464;
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Left: {
    heff_take_n(v_x_2461, 0ULL, 1);
    v_t_2464 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2461, 0ULL, 1);
    v_t_2464 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2461);
  }
  V f_ = v_k_2460;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam9(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_c_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2458;
  args[0] = v_hd_2459;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam10, 1, 1, (V[]){v_k_2460});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam11(V self, V *args) {
  V v_x_2466 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2466) == NTAG(TAG_True))) {
    heff_drop(v_x_2466);
    return ({ V a_0 = v_e_240; V a_1 = v_dir_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
  } else {
    heff_drop(v_x_2466);
    heff_drop(v_e_240);
    heff_drop(v_dir_241);
    heff_drop(v_rest_246);
    heff_drop(v_p_243);
    V f_ = v_p_244;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_name_247 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_text_248 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_rest_246 = heff_env(self)[6];
  V v_p_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_241)));
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_name_247));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  V v_path_2434 = ({ V a_0 = v_st_2418; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2433); r_; });
  V v_c_2465;
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    V v_path_2436 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_2434));
    V v_c_2437 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2436; V a_2 = v_text_248; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2436); r_; });
    V v_t_2438 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2442 = heff_tr(heff_call(v_c_2437, 2, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam4_clo)}));
    v_c_2465 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam5, 2, 1, (V[]){v_c_2442});
    break;
  }
  case TAG_Right: {
    V v_y_2449 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_2449, v_text_248, 1)) {
      heff_drop(v_text_248);
      heff_drop(v_path_2434);
      v_c_2465 = ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam7_clo);
    } else {
      V v_path_2452 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_2434));
      V v_c_2453 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2452; V a_2 = v_text_248; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2452); r_; });
      V v_t_2454 = (g_exception_2eattempted(heff_dup(v_e_240)));
      V v_c_2458 = heff_tr(heff_call(v_c_2453, 2, (V[]){v_t_2454, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam8_clo)}));
      v_c_2465 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam9, 2, 1, (V[]){v_c_2458});
    }
    break;
  }
  default: heff_nomatch(v_x_2430);
  }
  V f_ = v_c_2465;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam11, 1, 5, (V[]){v_e_240, v_dir_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_241 = heff_env(self)[0];
  V v_name_247 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_text_248 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_241)));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_name_247)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_c_2424 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2423); r_; });
  V v_t_2425 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam2_clo)}));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s491979089x246637162_lam3, 1, 8, (V[]){v_st_2418, v_dir_241, v_name_247, v_e_240, v_text_248, v_p_243, v_rest_246, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(V v_e_240, V v_outPath_241, V v_done_242, V v_o_243, V v_hd_244, V v_k_245) {
top: ;
  V v_errors_246 = heff_take_field(v_o_243, 1);
  V v_source_247 = heff_get_n(v_o_243, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(heff_dup(v_e_240), heff_dup(v_errors_246), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam0, 1, 7, (V[]){v_errors_246, v_outPath_241, v_e_240, v_source_247, v_hd_244, v_k_245, v_done_242})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_outPath_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 0ULL, 1);
    heff_drop(v_done_242);
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_str0), v_outPath_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_str1));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam3, 1, 3, (V[]){v_e_240, v_hd_244, v_k_245})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2416, 0ULL, 1);
    heff_drop(v_outPath_241);
    heff_drop(v_e_240);
    V f_ = v_done_242;
    heff_room[0] = v_hd_244;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_source_247 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_outPath_241)));
    V v_c_2410 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_249; V a_2 = v_source_247; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_249); r_; });
    V v_t_2411 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam1_clo)}));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_lam2, 1, 5, (V[]){v_outPath_241, v_e_240, v_hd_244, v_k_245, v_done_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_outPath_241);
    heff_drop(v_source_247);
    heff_drop(v_done_242);
    V v_t_2437 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_hd_244, v_k_245));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406(V v_e_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    V v_diags_246 = heff_dup(heff_rfield(v_c_244, 6));
    V v_module_247 = heff_dup(heff_rfield(v_c_244, 0));
    V v_t_248 = (g_list_2emap_24s328934344x1728860012(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_str0), heff_dup(v_diags_246)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam1, 2, 5, (V[]){v_e_240, v_module_247, v_t_248, heff_dup(v_rest_245), v_diags_246});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_diags_246 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_diags_246; V r_ = (g_list_2efoldl_24f2094160282x1876485468(a_0, a_1, a_2)); heff_drop(v_diags_246); r_; });
  V v_x_2415 = heff_intAdd(v_t_2414, v_x_2413);
  V f_ = v_k_2410;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_diags_246 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V v_c_2412 = ({ V a_0 = v_e_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_c_2412;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam3, 1, 2, (V[]){v_diags_246, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_module_247 = heff_env(self)[1];
  V v_t_248 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_diags_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), v_module_247, v_t_248, MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s997892233x210557406_lam2, 1, 5, (V[]){v_e_240, v_rest_245, v_hd_249, v_diags_246, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985(V v_e_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_file_243), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam0, 1, 7, (V[]){v_e_240, v_hd_245, v_file_243, heff_dup(v_name_241), v_outPath_242, v_done_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_hd_245 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_hashes_2411 = heff_take_field(v_x_2410, 1);
  V v_done_2412 = heff_get_n(v_x_2410, 0, 2);
  V v_t_2413 = (g_list_2emap_24s1698496827x1884878103(heff_dup(v_done_2412)));
  V v_t_2414 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_x_247, 2), v_hashes_2411, v_t_2413});
  V v_t_2415 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_248, 1));
  heff_drop(v_x_248);
  return ({ V a_0 = v_e_240; V a_1 = v_t_2414; V a_2 = heff_get_n(v_x_247, 0, 5); V a_3 = v_file_243; V a_4 = v_name_241; V a_5 = v_outPath_242; V a_6 = v_done_244; V a_7 = v_t_2415; V a_8 = v_done_2412; V a_9 = v_hd_245; V a_10 = v_k_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_name_241); heff_drop(v_t_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), heff_dup(v_x_247)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam2, 1, 9, (V[]){v_x_247, v_x_248, v_e_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_str0), heff_dup(heff_rfield(v_x_247, 1)), MK_INT(0LL), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985_lam1, 1, 8, (V[]){v_e_240, v_x_247, v_hd_245, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str3, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str4, 10, "heff build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str5, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str6, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str7, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str8, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str9, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam15, 3, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam20(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132(V v_e_240, V v_st_241, V v_t_242, V v_bp_243, V v_x_244, V v_a_245, V v_next_246, V v_p_247, V v_p_248) {
top: ;
  V v_backend_249 = heff_take_field(v_a_245, 0);
  V v_run_2410 = heff_get_n(v_a_245, 1, 3);
  if (heff_strEq_c(v_backend_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str0))) {
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_243, heff_dup(v_x_244), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam0_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2413, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam1, 1, 8, (V[]){v_e_240, v_p_247, v_st_241, v_t_242, v_x_244, v_next_246, v_run_2410, v_p_248})));
  } else {
    V v_t_2466 = heff_dup(heff_rfield(v_t_242, 3));
    if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
      heff_drop(v_t_2466);
      V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_243, heff_dup(v_x_244), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam11_clo)})});
      V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2469, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam12, 1, 8, (V[]){v_e_240, v_p_247, v_st_241, v_t_242, v_x_244, v_run_2410, v_next_246, v_p_248})));
    } else {
      heff_drop(v_st_241);
      heff_drop_rec(v_t_242, 6);
      heff_drop(v_run_2410);
      heff_drop(v_t_2466);
      V v_t_2499 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str8), v_x_244), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str9));
      V v_t_24100 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2499, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str10)), NTAG(TAG_MkUnit)});
      V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
      V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
      V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
      V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
      V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
      V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24106}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam20, 1, 5, (V[]){v_bp_243, v_e_240, v_p_247, v_next_246, v_p_248})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam0(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam2(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_hd_2427 = heff_env(self)[1];
  V v_k_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2431);
  V f_ = v_next_246;
  heff_room[0] = v_hd_2427;
  heff_room[1] = v_k_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2414 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2429 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam5, 1, 3, (V[]){v_next_246, v_hd_2427, v_k_2428})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam6(V self, V *args) {
  V v_why_2439 = args[0];
  V v_z_2440 = args[1];
  V v_z_2441 = args[2];
  V v_e_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_why_2439);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s310169282x2049378029(v_e_2422, heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_z_2440, v_z_2441));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam8(V self, V *args) {
  V v_why_2451 = args[0];
  V v_z_2452 = args[1];
  V v_z_2453 = args[2];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_why_2451);
  V v_t_2454 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), v_z_2452, v_z_2453));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_next_2449 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_k_2462 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2465);
  V f_ = v_next_2449;
  heff_room[0] = v_hd_2461;
  heff_room[1] = v_k_2462;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam9(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_x_2418 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_2449 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2463 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(v_hd_2461), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam10, 1, 3, (V[]){v_next_2449, v_hd_2461, v_k_2462})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_run_2410 = heff_env(self)[1];
  V v_outPath_2420 = heff_env(self)[2];
  V v_file_2421 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  V v_next_2449 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s442820789x1758527474(heff_dup(v_e_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam8, 3, 1, (V[]){heff_dup(v_e_240)}), v_x_2450, heff_tag_n(TAG_Just, 1, (V[]){v_run_2410}), v_outPath_2420, v_file_2421, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam9, 2, 3, (V[]){v_x_2418, v_e_240, v_next_2449}), v_p_247, v_p_248));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_next_246 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_run_2410 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_outPath_2420 = heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str2));
  V v_file_2421 = (g_heff_2ebuild_2ecommands_2eappFile(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str3)));
  V v_e_2422 = heff_dup(v_e_240);
  V v_st_2423 = v_st_241;
  V v_t_2424 = v_t_242;
  V v_p_2425 = heff_dup(v_x_2414);
  V v_x_2426 = v_x_244;
  V v_next_2432 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam4, 2, 3, (V[]){v_x_2414, heff_dup(v_e_240), v_next_246});
  V v_dir_2433 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_2423), heff_dup(v_t_2424), heff_dup(v_x_2426)));
  V v_a_2434 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_2423), heff_dup(v_t_2424), heff_dup(v_x_2426)));
  V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_2423), v_a_2434));
  V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_2423), v_x_2426));
  V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
  V v_out_2438 = ({ V a_0 = v_st_2423; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2437); r_; });
  V v_next_2449 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1577281796x1523043263(heff_get_n(v_t_2424, 5, 6), heff_dup(v_e_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam6, 3, 1, (V[]){v_e_2422}), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str4), v_st_2423, v_p_2425, v_dir_2433, v_out_2438, v_next_2432));
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_file_2421), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam7, 1, 8, (V[]){v_e_240, v_run_2410, v_outPath_2420, v_file_2421, v_x_2418, v_next_2449, v_p_247, v_p_248})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_next_246 = heff_env(self)[5];
  V v_run_2410 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2417, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam3, 1, 9, (V[]){v_st_241, v_t_242, v_x_244, v_e_240, v_x_2414, v_next_246, v_p_247, v_run_2410, v_p_248})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam11(V self, V *args) {
  V v_t_2467 = args[0];
  return v_t_2467;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam13(V self, V *args) {
  V v_t_2471 = args[0];
  return v_t_2471;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam15(V self, V *args) {
  V v_x_2479 = args[0];
  V v_hd_2480 = args[1];
  V v_k_2481 = args[2];
  heff_drop(v_hd_2480);
  V f_ = v_k_2481;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2479});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam19(V self, V *args) {
  V v_x_2498 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_hd_2491 = heff_env(self)[1];
  V v_k_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2498);
  V f_ = v_next_246;
  heff_room[0] = v_hd_2491;
  heff_room[1] = v_k_2492;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam18(V self, V *args) {
  V v_x_2495 = args[0];
  V v_x_2470 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2491 = heff_env(self)[2];
  V v_next_246 = heff_env(self)[3];
  V v_k_2492 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_End, 2, (V[]){v_x_2470, NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2497}), heff_dup(v_hd_2491), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam19, 1, 3, (V[]){v_next_246, v_hd_2491, v_k_2492})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam17(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_x_2474 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2470 = heff_env(self)[2];
  V v_next_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2493 = heff_tag_n(TAG_End, 2, (V[]){v_x_2474, NTAG(TAG_MkUnit)});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), heff_dup(v_hd_2491), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam18, 1, 5, (V[]){v_x_2470, v_e_240, v_hd_2491, v_next_246, v_k_2492})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam16(V self, V *args) {
  V v_x_2483 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_run_2410 = heff_env(self)[4];
  V v_x_2474 = heff_env(self)[5];
  V v_x_2470 = heff_env(self)[6];
  V v_next_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  V v_p_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2483);
  V v_n_2484 = heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str6));
  V v_a_2485 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_t_2486 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_a_2485));
  V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_2484));
  V v_t_2488 = (g_std_2epath_2ejoin(v_t_2486, v_t_2487));
  V v_t_2489 = ({ V a_0 = v_st_241; V a_1 = v_t_2488; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2488); r_; });
  V v_t_2490 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_241, v_t_242, v_x_244, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str7)));
  return ({ V a_0 = heff_dup(v_e_240); V b_1 = heff_tag_n(TAG_Just, 1, (V[]){v_run_2410}); V a_2 = v_t_2489; V a_3 = v_t_2490; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam17, 2, 4, (V[]){v_x_2474, v_e_240, v_x_2470, v_next_246}); V a_5 = v_p_247; V a_6 = v_p_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1340594384x1858914985(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam14(V self, V *args) {
  V v_x_2474 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  V v_run_2410 = heff_env(self)[5];
  V v_x_2470 = heff_env(self)[6];
  V v_next_246 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_s_2475 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_path_2476 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2475));
  V v_c_2477 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2476; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2476); r_; });
  V v_t_2478 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2482 = heff_tr(heff_call(v_c_2477, 2, (V[]){v_t_2478, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam15_clo)}));
  V f_ = v_c_2482;
  heff_room[0] = heff_dup(v_p_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam16, 1, 10, (V[]){v_x_244, v_st_241, v_t_242, v_e_240, v_run_2410, v_x_2474, v_x_2470, v_next_246, v_p_247, v_p_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam12(V self, V *args) {
  V v_x_2470 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_run_2410 = heff_env(self)[5];
  V v_next_246 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2470), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_str5), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam13_clo)})});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2473, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam14, 1, 9, (V[]){v_st_241, v_t_242, v_x_244, v_e_240, v_p_247, v_run_2410, v_x_2470, v_next_246, v_p_248})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam21(V self, V *args) {
  V v_x_24110 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  V v_p_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24110);
  V f_ = v_next_246;
  heff_room[0] = v_p_247;
  heff_room[1] = v_p_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam20(V self, V *args) {
  V v_x_24107 = args[0];
  V v_bp_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  V v_next_246 = heff_env(self)[3];
  V v_p_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24107);
  V v_t_24108 = heff_tag_n(TAG_Complete, 2, (V[]){v_bp_243, NTAG(TAG_MkUnit)});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24109}), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1550384102x1238655132_lam21, 1, 3, (V[]){v_next_246, v_p_247, v_p_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str9, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str11, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str12, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str20, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str21, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str22, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077(V v_e_240, V v_st_241, V v_cmd_242, V v_t_243, V v_none_244, V v_done_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_243, 0))));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str0)));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_t_2411 = ({ V a_0 = v_st_241; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_c_2413 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(heff_dup(v_e_240), v_t_2412, NTAG(TAG_Nil)));
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam0, 1, 8, (V[]){v_e_240, v_z_246, v_cmd_242, v_z_247, v_st_241, v_t_243, v_none_244, v_done_245})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam1(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam8(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2468);
  V f_ = v_k_2469;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam7(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_2467 = (g_list_2emap_24s219049803x1458391381(v_x_2466));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam8, 2, 1, (V[]){v_x_2467});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam10(V self, V *args) {
  V v_t_2478 = args[0];
  return v_t_2478;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam14(V self, V *args) {
  V v_x_24104 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24104);
  V v_t_24105 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24111}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam13(V self, V *args) {
  V v_x_2491 = args[0];
  V v_bad_2487 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_apps_2488 = heff_env(self)[5];
  V v_none_244 = heff_env(self)[6];
  V v_st_241 = heff_env(self)[7];
  V v_t_243 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2491);
  if (heff_intLt_c_lent(MK_INT(0LL), v_bad_2487, 1)) {
    heff_drop(v_apps_2488);
    heff_drop(v_none_244);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    heff_drop(v_done_245);
    V v_n_2492 = v_bad_2487;
    V v_t_2493;
    if (heff_intEq_c_lent(v_n_2492, MK_INT(1LL), 2)) {
      heff_drop(v_n_2492);
      v_t_2493 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str17);
    } else {
      v_t_2493 = heff_strAppend(heff_intShow(v_n_2492), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str18));
    }
    V v_what_2494 = heff_strAppend(v_t_2493, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str19));
    V v_t_2495 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str20), v_cmd_242), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str21));
    V v_t_2496 = heff_strAppend(heff_strAppend(v_t_2495, v_what_2494), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str22));
    V v_t_2497 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2496, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str23)), NTAG(TAG_MkUnit)});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24103}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam14, 1, 3, (V[]){v_e_240, v_z_246, v_z_247})));
  } else {
    heff_drop(v_bad_2487);
    heff_drop(v_cmd_242);
    switch (heff_tag_of(v_apps_2488)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_st_241);
      heff_drop_rec(v_t_243, 6);
      heff_drop(v_done_245);
      V f_ = v_none_244;
      heff_room[0] = v_z_246;
      heff_room[1] = v_z_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_drop(v_none_244);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s80227614x1689946914(v_e_240, v_st_241, v_t_243, v_done_245, v_apps_2488, v_z_246, v_z_247));
    }
    default: return heff_nomatch(v_apps_2488);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam12(V self, V *args) {
  V v_x_2486 = args[0];
  V v_x_2481 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_none_244 = heff_env(self)[5];
  V v_st_241 = heff_env(self)[6];
  V v_t_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_bad_2487 = heff_take_field(v_x_2486, 1);
  V v_apps_2488 = heff_get_n(v_x_2486, 0, 2);
  V v_t_2489 = heff_tag_n(TAG_End, 2, (V[]){v_x_2481, NTAG(TAG_MkUnit)});
  V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2490}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam13, 1, 10, (V[]){v_bad_2487, v_cmd_242, v_e_240, v_z_246, v_z_247, v_apps_2488, v_none_244, v_st_241, v_t_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam11(V self, V *args) {
  V v_x_2481 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_cmd_242 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_none_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2482 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2484;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_Nothing: {
    v_t_2484 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2483 = heff_field(v_x_2474, 0);
    heff_take_n(v_x_2474, 1ULL, 1);
    v_t_2484 = v_x_2483;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_c_2485 = (g_heff_2ebuild_2ecommands_2eappsIn_24s2021398137x657731979(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_243), heff_dup(v_x_2481), v_t_2482, v_t_2484));
  V f_ = v_c_2485;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam12, 1, 9, (V[]){v_x_2481, v_e_240, v_z_246, v_cmd_242, v_z_247, v_none_244, v_st_241, v_t_243, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam9(V self, V *args) {
  V v_x_2471 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_none_244 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2474;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_Left: {
    heff_take_n(v_x_2471, 0ULL, 1);
    v_x_2474 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2473 = heff_field(v_x_2471, 0);
    V v_ru_24x_2471_24Right = heff_take_reuse_n(v_x_2471, 1ULL, 1);
    v_x_2474 = heff_tag_at_n(v_ru_24x_2471_24Right, TAG_Just, 1, (V[]){v_y_2473});
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V v_t_2476;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_Nothing: {
    v_t_2476 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2475 = heff_dup(heff_field(v_x_2474, 0));
    v_t_2476 = v_x_2475;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_total_2477 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2476; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2476); r_; });
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str16), v_total_2477, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam10_clo)})});
  V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2480, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam11, 1, 9, (V[]){v_x_2474, v_e_240, v_st_241, v_t_243, v_z_246, v_cmd_242, v_z_247, v_none_244, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_none_244 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_243, 0))));
  V v_t_2460 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str15)));
  V v_t_2461 = (g_std_2epath_2ejoin(v_t_2459, v_t_2460));
  V v_s_2462 = ({ V a_0 = v_st_241; V a_1 = v_t_2461; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2461); r_; });
  V v_path_2463 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2462));
  V v_c_2464 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2463));
  V v_t_2465 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2470 = heff_tr(heff_call(v_c_2464, 2, (V[]){v_t_2465, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam7_clo)}));
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam9, 1, 8, (V[]){v_e_240, v_z_246, v_st_241, v_t_243, v_cmd_242, v_z_247, v_none_244, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_errors_2422 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_seen_2423 = heff_env(self)[5];
  V v_st_241 = heff_env(self)[6];
  V v_t_243 = heff_env(self)[7];
  V v_none_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2426);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2422, 1)) {
    heff_drop(v_seen_2423);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    heff_drop(v_none_244);
    heff_drop(v_done_245);
    V v_n_2427 = v_errors_2422;
    V v_t_2428;
    if (heff_intEq_c_lent(v_n_2427, MK_INT(1LL), 2)) {
      heff_drop(v_n_2427);
      v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str2);
    } else {
      v_t_2428 = heff_strAppend(heff_intShow(v_n_2427), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str3));
    }
    V v_what_2429 = heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str4));
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str5), v_cmd_242), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str6));
    V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, v_what_2429), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str7));
    V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str8)), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam5, 1, 3, (V[]){v_e_240, v_z_246, v_z_247})));
  } else {
    heff_drop(v_errors_2422);
    V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str9), heff_dup(v_cmd_242)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str10));
    V v_n_2448 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2423; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2423); r_; });
    V v_t_2449;
    if (heff_intEq_c_lent(v_n_2448, MK_INT(1LL), 2)) {
      heff_drop(v_n_2448);
      v_t_2449 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str11);
    } else {
      v_t_2449 = heff_strAppend(heff_intShow(v_n_2448), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str12));
    }
    V v_str_2450 = heff_strAppend(heff_strAppend(v_t_2447, v_t_2449), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str13));
    V v_t_2451 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str14)), NTAG(TAG_MkUnit)});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam6, 1, 8, (V[]){v_st_241, v_t_243, v_e_240, v_z_246, v_cmd_242, v_z_247, v_none_244, v_done_245})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  V v_none_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_errors_2422 = heff_take_field(v_x_2421, 1);
  V v_seen_2423 = heff_get_n(v_x_2421, 0, 2);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam4, 1, 10, (V[]){v_errors_2422, v_cmd_242, v_e_240, v_z_246, v_z_247, v_seen_2423, v_st_241, v_t_243, v_none_244, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  V v_none_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2420 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_x_2419); V a_2 = v_t_2420; V a_3 = v_x_2414; V a_4 = heff_dup(v_z_246); V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam3, 1, 9, (V[]){v_x_2419, v_e_240, v_z_246, v_cmd_242, v_z_247, v_st_241, v_t_243, v_none_244, v_done_245}); V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_cmd_242 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_none_244 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_total_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2414));
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_str1), v_total_2415, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam1_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2418, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1057060480x1863863077_lam2, 1, 9, (V[]){v_e_240, v_x_2414, v_z_246, v_cmd_242, v_z_247, v_st_241, v_t_243, v_none_244, v_done_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str0, 5, "=def ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str2, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str3, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str4, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str5, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str6, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str7, 6, "=body ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129(V v_e_240, V v_c_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_c_241, 14);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str0), heff_dup(v_k_245)), ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str1));
    V v_t_248 = (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_241), v_k_245));
    V v_t_249 = heff_strAppend(v_t_247, v_t_248);
    V v_t_2410 = heff_dup(heff_rfield(v_c_241, 5));
    V v_k_2411 = heff_dup(v_k_245);
    V v_g_2412 = heff_get_n(v_t_2410, 0, 10);
    V v_entries_2413 = heff_take_field(v_g_2412, 1);
    V v_aliases_2414 = heff_get_n(v_g_2412, 2, 8);
    HeffT2 v_t_2415 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2413, v_k_2411));
    V v_t_2427;
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_k_2411);
        heff_drop(v_entries_2413);
        heff_drop(v_aliases_2414);
        V v_e_2418 = v_field_2417;
        v_t_2427 = ({ V b_0 = heff_get_n(v_e_2418, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_field_2417);
        HeffT2 v_t_2419 = ({ V a_0 = v_aliases_2414; V a_1 = v_k_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2414); heff_drop(v_k_2411); r_; });
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_k2_2422 = v_field_2421;
            HeffT2 v_t_2423 = ({ V a_0 = v_entries_2413; V a_1 = v_k2_2422; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2413); heff_drop(v_k2_2422); r_; });
            {
              V v_field_2425 = v_t_2423.f[1];
              int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
              if ((v_tag_2424 == ((int64_t)0ULL))) {
                V v_e_2426 = v_field_2425;
                v_t_2427 = ({ V b_0 = heff_get_n(v_e_2426, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
              } else {
                heff_drop(v_field_2425);
                v_t_2427 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str2);
              }
            }
          } else {
            heff_drop(v_entries_2413);
            heff_drop(v_field_2421);
            v_t_2427 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str3);
          }
        }
      }
    }
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str4), v_t_2427);
    V v_t_2429 = heff_dup(heff_rfield(v_c_241, 5));
    V v_k_2430 = v_k_245;
    V v_g_2431 = heff_get_n(v_t_2429, 0, 10);
    V v_entries_2432 = heff_take_field(v_g_2431, 1);
    V v_aliases_2433 = heff_get_n(v_g_2431, 2, 8);
    HeffT2 v_t_2434 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2432, v_k_2430));
    V v_t_2446;
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        heff_drop(v_k_2430);
        heff_drop(v_entries_2432);
        heff_drop(v_aliases_2433);
        V v_e_2437 = v_field_2436;
        v_t_2446 = ({ V b_0 = heff_get_n(v_e_2437, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_field_2436);
        HeffT2 v_t_2438 = ({ V a_0 = v_aliases_2433; V a_1 = v_k_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2433); heff_drop(v_k_2430); r_; });
        {
          V v_field_2440 = v_t_2438.f[1];
          int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
          if ((v_tag_2439 == ((int64_t)0ULL))) {
            V v_k2_2441 = v_field_2440;
            HeffT2 v_t_2442 = ({ V a_0 = v_entries_2432; V a_1 = v_k2_2441; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2432); heff_drop(v_k2_2441); r_; });
            {
              V v_field_2444 = v_t_2442.f[1];
              int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
              if ((v_tag_2443 == ((int64_t)0ULL))) {
                V v_e_2445 = v_field_2444;
                v_t_2446 = ({ V b_0 = heff_get_n(v_e_2445, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
              } else {
                heff_drop(v_field_2444);
                v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str5);
              }
            }
          } else {
            heff_drop(v_entries_2432);
            heff_drop(v_field_2440);
            v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str6);
          }
        }
      }
    }
    V v_t_2447 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str7), v_t_2446);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam1, 2, 6, (V[]){v_t_249, v_e_240, v_t_2447, v_t_2428, v_c_241, v_rest_246});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2448 = heff_env(self)[3];
  V v_k_2449 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2459);
  V v_t_2460 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129(v_e_240, v_c_241, v_rest_246));
  V f_ = v_t_2460;
  heff_room[0] = v_hd_2448;
  heff_room[1] = v_k_2449;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam2(V self, V *args) {
  V v_x_2457 = args[0];
  V v_t_2447 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_t_2428 = heff_env(self)[2];
  V v_hd_2448 = heff_env(self)[3];
  V v_c_241 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  V v_k_2449 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(heff_dup(v_e_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2458}), heff_dup(v_hd_2448), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam3, 1, 5, (V[]){v_e_240, v_c_241, v_rest_246, v_hd_2448, v_k_2449})));
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam1(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_t_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_t_2447 = heff_env(self)[2];
  V v_t_2428 = heff_env(self)[3];
  V v_c_241 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2450 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_str8)), NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), heff_dup(v_hd_2448), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_lam2, 1, 7, (V[]){v_t_2447, v_e_240, v_t_2428, v_hd_2448, v_c_241, v_rest_246, v_k_2449})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823(V v_e_240, V v_bi_241, V v_file_242, V v_name_243, V v_outPath_244, V v_rt_245, V v_failed_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_247)));
  V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2411); r_; });
  V v_t_2413 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2412));
  V v_t_2415 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_lam0, 1, 1, (V[]){heff_dup(v_available_248)}), v_t_2413));
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2415, heff_dup(v_c_247), v_name_243));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      heff_drop(v_bi_241);
      heff_drop(v_outPath_244);
      heff_drop_rec(v_rt_245, 2);
      heff_drop_rec(v_c_247, 14);
      heff_drop(v_available_248);
      V v_why_2419 = v_field_2418;
      V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str0), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str1));
      V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, heff_dup(v_why_2419)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str2));
      V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2421, NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_lam1, 1, 5, (V[]){v_file_242, v_failed_246, v_why_2419, v_z_249, v_z_2410})));
    } else {
      heff_drop(v_file_242);
      heff_drop(v_failed_246);
      V v_r_2431 = v_field_2418;
      int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
      V v_t_2433 = heff_strSlice(heff_dup(v_outPath_244), heff_box_word(v_t_2432), heff_strLength_lent(v_outPath_244, 0));
      if (heff_strEq_c(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str5))) {
        int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688(v_e_240, v_bi_241, heff_strSlice(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2434)), v_rt_245, v_c_247, v_available_248, v_r_2431, v_z_249, v_z_2410));
      } else {
        heff_drop(v_bi_241);
        V v_t_2435 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 10);
        V v_t_2436 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_take_field(v_rt_245, 0), v_available_248, v_t_2435, heff_take_field(v_r_2431, 0), heff_get_n(v_r_2431, 1, 2)));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s2084192393x1420742402(v_e_240, v_outPath_244, heff_get_n(v_rt_245, 1, 2), v_t_2436, v_z_249, v_z_2410));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_lam0(V self, V *args) {
  V v_k_2414 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2419 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str3), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823_str4));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2430, v_why_2419);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str6, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str7, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str8, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str9, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str10, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str12, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str13, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str14, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str17, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str18, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str19, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam7(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153(V v_e_240, V v_bi_241, V v_sources_242, V v_file_243, V v_name_244, V v_outPath_245, V v_failed_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_t_2414 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
      V v_xs_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str3); V a_6 = v_t_2416; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
      V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(heff_dup(v_e_240), v_sources_242, v_t_2418));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam0, 1, 9, (V[]){v_e_240, v_z_248, v_name_244, v_outPath_245, v_c_2413, v_z_249, v_file_243, v_failed_246, v_bi_241})});
    } else {
      heff_drop(v_bi_241);
      heff_drop(v_sources_242);
      heff_drop(v_file_243);
      heff_drop(v_name_244);
      heff_drop(v_outPath_245);
      heff_drop(v_failed_246);
      heff_drop(v_field_2412);
      V v_t_2488 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str19), NTAG(TAG_MkUnit)});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam7, 1, 3, (V[]){v_e_240, v_z_248, v_z_249})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_outPath_245 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2448);
  V v_exports_2449 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str12); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2413, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
  V v_roots_2450 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2449)));
  V v_t_2451 = heff_get_n(heff_get_n(v_c_2413, 5, 14), 0, 10);
  V v_t_2452 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2451));
  V v_t_2453 = (g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(v_roots_2450, v_t_2452));
  V v_t_2454 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2421, v_exports_2449, v_t_2453));
  return ({ V a_0 = v_e_240; V a_1 = v_outPath_245; V b_2 = NTAG(TAG_True); V a_3 = v_t_2454; V a_4 = v_z_248; V a_5 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_outPath_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    V v_ru_24x_2434_24Left = heff_take_reuse_n(v_x_2434, 0ULL, 1);
    int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
    V v_t_2437 = heff_strSlice(heff_dup(v_outPath_245), heff_box_word(v_t_2436), heff_strLength_lent(v_outPath_245, 0));
    V v_t_2439;
    if (heff_strEq_c(v_t_2437, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str8))) {
      int64_t v_t_2438 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
      v_t_2439 = heff_strSlice_lent(v_outPath_245, MK_INT(0LL), heff_box_word(v_t_2438), 6);
    } else {
      v_t_2439 = heff_dup(v_outPath_245);
    }
    V v_t_2440 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str9), heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str10)));
    V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str11)), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_at_n(v_ru_24x_2434_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam5, 1, 6, (V[]){v_c_2413, v_x_2421, v_e_240, v_outPath_245, v_z_248, v_z_249})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2434, 0ULL, 1);
    V v_exports_2456 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str13); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_take_field(v_c_2413, 7); V r_ = (g_list_2emap_24f1176765648x1638512070(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_roots_2457 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2456)));
    V v_t_2458 = heff_get_n(heff_get_n(v_c_2413, 5, 14), 0, 10);
    V v_t_2459 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2458));
    V v_t_2460 = (g_heff_2ecompile_2elower_2eerasedWith_24s1851647938x992362929(v_roots_2457, v_t_2459));
    V v_t_2461 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2421, v_exports_2456, v_t_2460));
    return ({ V a_0 = v_e_240; V a_1 = v_outPath_245; V b_2 = NTAG(TAG_False); V a_3 = v_t_2461; V a_4 = v_z_248; V a_5 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(b_2); r_; });
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam6(V self, V *args) {
  V v_x_2482 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2472 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2482);
  V v_t_2483 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str17), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str18));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2483, v_why_2472);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_name_244 = heff_env(self)[0];
  V v_outPath_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_c_2413 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  V v_z_249 = heff_env(self)[6];
  V v_x_2420 = heff_env(self)[7];
  V v_file_243 = heff_env(self)[8];
  V v_failed_246 = heff_env(self)[9];
  V v_bi_241 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_name_244)) {
  case TAG_Nothing: {
    heff_drop(v_x_2420);
    heff_drop(v_file_243);
    heff_drop(v_failed_246);
    heff_drop(v_bi_241);
    int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
    V v_t_2424 = heff_strSlice(heff_dup(v_outPath_245), heff_box_word(v_t_2423), heff_strLength_lent(v_outPath_245, 0));
    V v_t_2426;
    if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str6))) {
      int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_outPath_245, 0)) - ((int64_t)2ULL));
      v_t_2426 = heff_strSlice_lent(v_outPath_245, MK_INT(0LL), heff_box_word(v_t_2425), 6);
    } else {
      v_t_2426 = heff_dup(v_outPath_245);
    }
    V v_path_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str7))));
    V v_c_2428 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2427; V a_2 = v_x_2422; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2427); r_; });
    V v_t_2429 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2433 = heff_tr(heff_call(v_c_2428, 2, (V[]){v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam3_clo)}));
    V f_ = v_c_2433;
    heff_room[0] = heff_dup(v_z_248);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam4, 1, 6, (V[]){v_outPath_245, v_e_240, v_z_248, v_c_2413, v_x_2421, v_z_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_2463 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
    V v_t_2464 = ({ V a_0 = v_t_2463; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2463); r_; });
    V v_leaves_2465 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2464));
    V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 10);
    V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2420)}));
    V v_t_2468 = (g_list_2emap_24s164225955x66209884(v_t_2466, v_t_2467, v_leaves_2465));
    HeffT2 v_t_2469 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2468));
    {
      V v_field_2471 = v_t_2469.f[1];
      int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
      if ((v_tag_2470 == ((int64_t)0ULL))) {
        heff_drop(v_x_2422);
        heff_drop_tag(v_name_244, 1);
        heff_drop(v_outPath_245);
        heff_drop_rec(v_c_2413, 14);
        heff_drop(v_x_2421);
        heff_drop(v_x_2420);
        heff_drop(v_bi_241);
        V v_why_2472 = v_field_2471;
        V v_t_2473 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str14), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str15));
        V v_t_2474 = heff_strAppend(heff_strAppend(v_t_2473, heff_dup(v_why_2472)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str16));
        V v_t_2475 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2474, NTAG(TAG_MkUnit)});
        V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
        V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam6, 1, 5, (V[]){v_file_243, v_failed_246, v_why_2472, v_z_248, v_z_249})));
      } else {
        V v_ms_2484 = v_field_2471;
        V v_glues_2485 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2484));
        V v_t_2486 = (g_list_2emap_24s1435185561x202019164(v_glues_2485));
        V v_t_2487 = (g_prelude_2e_2b_2b(v_x_2420, v_t_2486));
        return ({ V a_0 = v_e_240; V a_1 = v_bi_241; V a_2 = v_file_243; V a_3 = v_name_244; V a_4 = v_outPath_245; V a_5 = heff_rec_n(2, shape_c__zig, (V[]){v_x_2421, v_x_2422}); V a_6 = v_failed_246; V a_7 = v_c_2413; V a_8 = v_t_2487; V a_9 = v_z_248; V a_10 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1615088519x613763823(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop_tag(v_name_244, 1); r_; });
      }
    }
  }
  default: return heff_nomatch(v_name_244);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_name_244 = heff_env(self)[2];
  V v_outPath_245 = heff_env(self)[3];
  V v_c_2413 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_x_2420 = heff_env(self)[6];
  V v_file_243 = heff_env(self)[7];
  V v_failed_246 = heff_env(self)[8];
  V v_bi_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str5), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam2, 1, 11, (V[]){v_name_244, v_outPath_245, v_e_240, v_z_248, v_c_2413, v_x_2421, v_z_249, v_x_2420, v_file_243, v_failed_246, v_bi_241})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_name_244 = heff_env(self)[2];
  V v_outPath_245 = heff_env(self)[3];
  V v_c_2413 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_file_243 = heff_env(self)[6];
  V v_failed_246 = heff_env(self)[7];
  V v_bi_241 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_str4), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam1, 1, 10, (V[]){v_e_240, v_z_248, v_name_244, v_outPath_245, v_c_2413, v_z_249, v_x_2420, v_file_243, v_failed_246, v_bi_241})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s672741368x117077153_lam7(V self, V *args) {
  V v_x_2495 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24102}), v_z_248, v_z_249));
}