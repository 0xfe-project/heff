// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_Holds 53574
#define TAG_MakeDirectory 16793
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_RunUnder 28888
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_UseColor 15915
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_cwd 308458
#define LBL_diags 296935042
#define LBL_emits 297985818
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_groups 709681407
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_integrations 139286697
#define LBL_jss 315076
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_loaded 849622832
#define LBL_mod 317820
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_olds 9909235
#define LBL_out 319944
#define LBL_outcomes 803130769
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_renames 1324191545
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_shown 310772011
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_watches 1357821955
#define LBL_wrong 314763719
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_file__wrong__reports__outcomes__integrations__loaded__checked[] = {LBL_file, LBL_wrong, LBL_reports, LBL_outcomes, LBL_integrations, LBL_loaded, LBL_checked};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo;
V g_heff_2ebuild_2ecommands_2eintegrationText(V, V);
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eranLine(V);
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranLine_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_clo;
V g_heff_2ebuild_2ecommands_2erefusedReaching(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2eisTestOwn(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2erootsAmong(V, V);
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erootsAmong_clo;
HeffT2 g_heff_2ebuild_2edriver_2erunTests_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2eany_24s529567056x880977707(V, V, V);
V g_list_2eany_24s529567056x880977707_entry(V self, V *a);
extern Clo g_list_2eany_24s529567056x880977707_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s313075719x1688564285(V);
V g_list_2efilter_24s313075719x1688564285_entry(V self, V *a);
extern Clo g_list_2efilter_24s313075719x1688564285_clo;
V g_list_2efilter_24s770154907x42702486(V);
V g_list_2efilter_24s770154907x42702486_entry(V self, V *a);
extern Clo g_list_2efilter_24s770154907x42702486_clo;
V g_list_2efilter_24s794048906x2073543501(V, V);
V g_list_2efilter_24s794048906x2073543501_entry(V self, V *a);
extern Clo g_list_2efilter_24s794048906x2073543501_clo;
HeffT2 g_list_2efind_24s1983706162x228765702_24cpr(V, V);
V g_list_2efoldl_24f1046331721x1909432377(V, V, V);
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1046331721x1909432377_clo;
V g_list_2efoldl_24f1117322828x1334654706(V, V, V);
V g_list_2efoldl_24f1117322828x1334654706_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1117322828x1334654706_clo;
V g_list_2efoldl_24f1189266312x1583313228(V, V, V);
V g_list_2efoldl_24f1189266312x1583313228_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1189266312x1583313228_clo;
V g_list_2efoldl_24f1824632076x1202317442(V, V, V);
V g_list_2efoldl_24f1824632076x1202317442_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1824632076x1202317442_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s86307863x1047527532(V, V);
V g_list_2efoldl_24s86307863x1047527532_entry(V self, V *a);
extern Clo g_list_2efoldl_24s86307863x1047527532_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s1951926392x340347826(V, V, V);
V g_list_2emap_24s1951926392x340347826_entry(V self, V *a);
extern Clo g_list_2emap_24s1951926392x340347826_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str0, 23, "not known: there is no ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str1, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str2, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str3, 5, "heff ");

HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V v_path_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_f_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str0), v_path_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_Just: {
    V v_src_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_src_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_p_248 = v_field_246;
        V v_t_249 = (g_heff_2ebuild_2eload_2eproblemMsg(v_path_240, v_src_243, v_p_248));
        V v_f_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str1), v_t_249);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      } else {
        V v_x_2411 = v_field_246;
        HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_p_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2ebuild_2eload_2eproblemMsg(v_path_240, v_src_243, v_p_2416));
            V v_f_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str2), v_t_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
          } else {
            heff_drop(v_path_240);
            V v_p_2419 = v_field_2414;
            V v_f_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str3), heff_get_n(v_p_2419, 1, 4));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2420}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str0, 4, "std.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str1, 81, "` is an effect of the system (lib/std/), for C: it has no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str2, 1, "`");
Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erefusedReaching_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erefusedReaching(V v_host_240, V v_sources_241, V v_only_242, V v_s_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_s_243, 6));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_s_243, 0)), MK_INT(0LL), MK_INT(4LL));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str0))) {
      V v_t_247 = (g_list_2eany_24s2065989517x1307020881(heff_rfield(v_s_243, 0), v_only_242));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_sources_241);
        heff_drop(v_t_247);
        V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_243, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str1), v_host_240));
        V v_t_249 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_243, 0, 7), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str2), v_t_248), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      } else {
        heff_drop(v_t_247);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_s_243, 0)), NTAG(TAG_Nil)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
        HeffT2 v_t_2412 = (g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(v_sources_241, v_only_242, NTAG(TAG_Nil), v_t_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2ebuild_2ecommands_2ereachingRefused(v_host_240, v_s_243, v_x_2416));
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
          } else {
            heff_drop(v_host_240);
            heff_drop_rec(v_s_243, 7);
            heff_drop(v_field_2414);
            return NTAG(TAG_Nothing);
          }
        }
      }
    } else {
      heff_drop(v_host_240);
      heff_drop(v_sources_241);
      heff_drop_rec(v_s_243, 7);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_host_240);
    heff_drop(v_sources_241);
    heff_drop_rec(v_s_243, 7);
    heff_drop(v_t_244);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2erefusedReaching(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_str0, 45, "its file does not import check, which runs it");
V g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V v_p_240, V v_src_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_src_241, 5), heff_take_field(v_src_241, 3)));
  HeffT4 v_t_243 = ({ V b_0 = heff_get_n(v_src_241, 4, 7); V a_1 = v_t_242; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248;
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    heff_drop(v_t_243.f[3]);
    v_t_248 = v_field_244;
  }
  HeffT2 v_t_249 = (g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_q_2413 = v_field_2411;
      V v_l_2414 = heff_dup(heff_rfield(v_p_240, 5));
      V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_p_240, 6)), 0, 14);
      V v_c_2416 = heff_take_field(v_p_240, 6);
      V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_2416)}), heff_dup(heff_rfield(v_c_2416, 7))));
      V v_t_2419 = (g_heff_2ebuild_2edriver_2erootsAmong(v_c_2416, v_t_2418));
      V v_t_2420 = (g_heff_2ebuild_2ecommands_2eintegrationText(v_q_2413, v_t_2419));
      V v_t_2421 = heff_get_n(heff_get_n(v_p_240, 5, 7), 0, 5);
      V v_sources_2422 = ({ V a_0 = v_t_2415; V a_1 = v_t_2420; V a_2 = v_t_2421; V r_ = (g_list_2emap_24s1951926392x340347826(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
      V v_f_2423 = ({ V rv_0 = v_sources_2422; V rr_ = heff_rec_reuse_nf(v_l_2414, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2423}});
    } else {
      heff_drop_rec(v_p_240, 7);
      heff_drop(v_field_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_str0)}});
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0(V self, V *args) {
  V v_o_2417 = args[0];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_2416, v_o_2417));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_str2, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870(V v_ps_240, V v_olds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_olds_241, v_m_247));
      V v_t_2414;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          v_t_2414 = v_x_2413;
        } else {
          heff_drop(v_field_2411);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_str0);
        }
      }
      V v_c_2421;
      if (heff_strEq_c_lent(v_text_248, v_t_2414, 2)) {
        v_c_2421 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam1_clo);
      } else {
        V v_d_2418 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_str1)));
        V v_d_2419 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2418, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
        V v_t_2420 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2419, heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_str2))));
        v_c_2421 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_clo), 2, (V[]){v_t_2420, heff_dup(v_text_248)}));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam2, 2, 4, (V[]){v_c_2421, v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2422 = heff_env(self)[3];
  V v_k_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2424);
  V v_t_2425 = ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870(a_0, a_1, a_2)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_olds_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_lam3, 1, 5, (V[]){v_ps_240, v_olds_241, v_rest_246, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str3, 8, "heff.zig");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277(V v_bi_240, V v_dir_241, V v_zig_242, V v_id_243, V v_texts_244, V v_backs_245, V v_done_246, V v_out_247, V v_z_248, V v_z_249) {
top: ;
  V v_t_2430;
  if (heff_strEq_c_lent(v_id_243, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str0), 2)) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_243);
    heff_drop(v_backs_245);
    v_t_2430 = v_done_246;
  } else {
    V v_ps_2411 = heff_dup(heff_rfield(v_bi_240, 0));
    V v_d_2412 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2411, 5), heff_take_field(v_ps_2411, 0), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str1)));
    V v_path_2413 = ({ V b_0 = heff_get_n(v_ps_2411, 5, 6); V a_1 = v_d_2412; V a_2 = heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get()); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_t_2430 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam0, 2, 7, (V[]){v_path_2413, heff_dup(v_texts_244), v_bi_240, heff_dup(v_out_247), v_id_243, v_backs_245, v_done_246});
  }
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str3), v_zig_242}), heff_take_field(v_out_247, 0)});
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, heff_get_n(v_out_247, 1, 5)});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s1211585058x941388669(v_dir_241, v_t_2430, v_t_2432, v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam1(V self, V *args) {
  V v_ok_2416 = args[0];
  return v_ok_2416;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_texts_244 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_247 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_backs_245 = heff_env(self)[4];
  V v_hd_2414 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  V v_k_2415 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2422);
  V v_t_2423 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s86307863x1047527532(a_0, a_1)); heff_drop(v_texts_244); r_; });
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_str2), heff_take_field(v_bi_240, 2)});
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop_tag(v_t_2424, 2); r_; });
  V v_t_2426 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){heff_take_field(v_out_247, 2), heff_take_field(v_out_247, 3), heff_get_n(v_out_247, 4, 5), NTAG(TAG_Nil)});
  V v_t_2427 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2425, v_backs_245}), v_t_2426));
  V v_c_2428 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2423; V a_2 = v_t_2427; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870(a_0, a_1, a_2)); heff_drop(v_t_2423); heff_drop(v_t_2427); r_; });
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_hd_2414);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam3, 1, 3, (V[]){v_done_246, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_path_2413 = heff_env(self)[0];
  V v_texts_244 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_247 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_backs_245 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2413, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam1_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s160788861x2088654277_lam2, 1, 8, (V[]){v_texts_244, v_bi_240, v_out_247, v_id_243, v_backs_245, v_hd_2414, v_done_246, v_k_2415})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str0, 2, ".o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str1, 11, "-femit-bin=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str2, 2, "-O");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str3, 9, "build-obj");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920(V v_prog_240, V v_z_241, V v_mode_242, V v_x3_243, V v_made_244) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_made_244));
    V v_x_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_f_249 = heff_field(v_x3_243, 0);
    V v_rest_2410 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam1, 2, 6, (V[]){v_f_249, v_mode_242, v_prog_240, v_z_241, v_rest_2410, v_made_244});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam2(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2432);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_mode_242 = heff_env(self)[2];
  V v_rest_2410 = heff_env(self)[3];
  V v_o_2414 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = heff_take_field(v_x_2420, 0);
  V v_t_2424;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Exited: {
    V v_n_2422 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    v_t_2424 = heff_intEq(v_n_2422, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2420, 3);
    heff_drop(v_t_2424);
    V v_t_2425 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920(v_prog_240, v_z_241, v_mode_242, v_rest_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_o_2414, v_made_244})));
    V f_ = v_t_2425;
    heff_room[0] = v_hd_2411;
    heff_room[1] = v_k_2412;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_prog_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    heff_drop(v_rest_2410);
    heff_drop(v_o_2414);
    heff_drop(v_made_244);
    heff_drop(v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2420, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2411, heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam4, 1, 1, (V[]){v_k_2412})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_f_249 = heff_env(self)[0];
  V v_mode_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_z_241 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_f_249, 0)) - ((int64_t)4ULL));
  V v_o_2414 = heff_strAppend(heff_strSlice_lent(v_f_249, MK_INT(0LL), heff_box_word(v_t_2413), 6), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str0));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str1), heff_dup(v_o_2414)), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str2), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_mode_242), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_f_249, v_t_2416})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_z_241), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_str4), v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2419, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920_lam3, 1, 8, (V[]){v_prog_240, v_z_241, v_mode_242, v_rest_2410, v_o_2414, v_made_244, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str3, 44, "not kept yet: `heff test --update` writes it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str4, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str5, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str10, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str11, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str16, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str17, 1, "\"");
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003(V v_update_240, V v_dir_241, V v_path_242, V v_text_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
      V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam0_clo)})});
      V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam1, 1, 4, (V[]){v_path_242, v_text_243, v_z_245, v_z_246})));
    } else {
      heff_drop(v_dir_241);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      V v_t_2422 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str2), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str3)})});
      return heff_tail(v_z_246, 1, (V[]){v_t_2422});
    }
  }
  case TAG_Just: {
    V v_kept_2423 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Just = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_dir_241);
    if (heff_strEq_c_lent(v_kept_2423, v_text_243, 0)) {
      heff_drop(v_path_242);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      heff_drop(v_kept_2423);
      heff_drop_cell(v_ru_24x5_244_24Just, 1);
      return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Holds)});
    } else {
      if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
        heff_drop(v_kept_2423);
        V v_t_2426 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_path_242), v_text_243, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam4_clo)})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam5, 1, 2, (V[]){v_path_242, v_z_246})));
      } else {
        heff_drop(v_z_245);
        heff_drop_cell(v_ru_24x5_244_24Just, 1);
        V v_t_2433 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str6); V a_1 = v_kept_2423; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str7), v_kept_2423, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_kept_2423); r_; });
        V v_t_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str8); V a_1 = v_text_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str9), v_text_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_text_243); r_; });
        HeffT2 v_t_2435 = (g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(MK_INT(1LL), v_t_2433, v_t_2434));
        {
          V v_field_2436 = v_t_2435.f[0];
          V v_field_2437 = v_t_2435.f[1];
          V v_n_2438 = v_field_2436;
          V v_x22_2439 = v_field_2437;
          V v_x_2448;
          switch (heff_tag_of(v_x22_2439)) {
          case TAG_MkPair: {
            V v_kept_2440 = heff_field(v_x22_2439, 0);
            V v_text_2441 = heff_field(v_x22_2439, 1);
            V v_ru_24x22_2439_24MkPair = heff_take_reuse_n(v_x22_2439, 3ULL, 2);
            V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str10), heff_intShow(v_n_2438));
            V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str11), heff_strAppend(v_path_242, v_t_2442));
            V v_t_2444 = ({ V a_0 = v_kept_2440; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str12); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2440); r_; });
            V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str13), heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str14)));
            V v_t_2446 = ({ V a_0 = v_text_2441; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str15); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2441); r_; });
            V v_t_2447 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str16), heff_strAppend(v_t_2446, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str17)));
            v_x_2448 = heff_tag_at_n(v_ru_24x22_2439_24MkPair, TAG_Wrong, 2, (V[]){v_t_2443, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2445, v_t_2447})});
            break;
          }
          default: heff_nomatch(v_x22_2439);
          }
          return heff_tail(v_z_246, 1, (V[]){v_x_2448});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam0(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam2(V self, V *args) {
  V v_ok_2414 = args[0];
  return v_ok_2414;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421;
  if ((heff_dup(v_x_2420) == NTAG(TAG_True))) {
    heff_drop(v_x_2420);
    v_t_2421 = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
  } else {
    heff_drop(v_x_2420);
    v_t_2421 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str0), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str1)})});
  }
  V f_ = v_z_246;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2413);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_path_242), v_text_243, ((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam3, 1, 2, (V[]){v_path_242, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam4(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432;
  if ((heff_dup(v_x_2431) == NTAG(TAG_True))) {
    heff_drop(v_x_2431);
    v_t_2432 = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
  } else {
    heff_drop(v_x_2431);
    v_t_2432 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str4), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenAgainst_24s914639966x1432028003_str5)})});
  }
  V f_ = v_z_246;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str0, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str1, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str2, 8, "  skip  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str4, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_o_244, 2));
    V v_str_2410;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_str_2410 = (g_heff_2ebuild_2ecommands_2eranLine(heff_dup(v_o_244)));
      break;
    }
    case TAG_Just: {
      V v_why_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str0), heff_strAppend(v_why_247, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str1)));
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_o_244, 0)), v_t_248);
      v_str_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str2), v_t_249);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam1, 2, 4, (V[]){v_str_2410, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2438);
  V v_t_2439 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651(a_0, a_1)); heff_drop(v_color_240); r_; });
  V f_ = v_t_2439;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2419);
  V v_t_2420 = heff_take_field(v_o_244, 1);
  V v_c_2437;
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop_rec(v_o_244, 12);
    heff_drop(v_t_2420);
    v_c_2437 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam3_clo);
  } else {
    heff_drop(v_t_2420);
    V v_t_2423 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str4), heff_take_field(v_o_244, 8)));
    V v_t_2424 = heff_get_n(v_o_244, 9, 12);
    V v_t_2426;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nothing: {
      v_t_2426 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2425 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      v_t_2426 = (g_heff_2ebuild_2ecommands_2efailLines(v_color_240, v_f_2425));
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    V v_x2_2427 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2426));
    V v_str_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_str_2430 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_str_2430 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str6); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    V v_t_2431 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2430, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str7)), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    v_c_2437 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  }
  V f_ = v_c_2437;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam4, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_str_2410 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2410, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_str3)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651_lam2, 1, 5, (V[]){v_o_244, v_color_240, v_hd_2411, v_rest_245, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str1, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str5, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(V v_f_240, V v_wrong_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_UseColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(v_t_2411, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam1, 1, 6, (V[]){v_ts_242, v_f_240, v_hd_244, v_os_243, v_wrong_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam0(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam4(V self, V *args) {
  V v_x_2442 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_wrong_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2442);
  V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2444 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_242; V r_ = (g_list_2efoldl_24f1117322828x1334654706(a_0, a_1, a_2)); heff_drop(v_ts_242); r_; });
  V v_t_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_243));
  V v_t_2446 = (g_list_2efoldl_24f1189266312x1583313228(MK_INT(1LL), MK_INT(0LL), v_os_243));
  V v_t_2447 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_243; V r_ = (g_list_2efoldl_24f1824632076x1202317442(a_0, a_1, a_2)); heff_drop(v_os_243); r_; });
  V v_x_2448 = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), v_t_2443, v_t_2444, v_wrong_241, v_t_2445, v_t_2446, v_t_2447});
  V f_ = v_k_245;
  args[0] = v_x_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_wrong_241 = heff_env(self)[2];
  V v_f_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  V v_x1_2418 = (g_list_2efilter_24s313075719x1688564285(heff_dup(v_ts_242)));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nil: {
    V v_x1_2419 = (g_list_2efilter_24s770154907x42702486(heff_dup(v_os_243)));
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_wrong_241)) {
      case TAG_Nil: {
        v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str0);
        break;
      }
      case TAG_Cons: {
        v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str1);
        break;
      }
      default: heff_nomatch(v_wrong_241);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2419, 0ULL, 2);
      v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str2);
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2418, 0ULL, 2);
    v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str3);
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2428 = (g_list_2efoldl_24f1117322828x1334654706(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2429 = heff_intShow(heff_intSub(v_t_2427, v_t_2428));
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_t_2431 = (g_heff_2ebuild_2ecommands_2etestsSaid(v_os_243));
  V v_t_2432 = heff_strAppend(heff_intShow(v_t_2430), v_t_2431);
  V v_t_2433 = heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str4), v_t_2432));
  V v_t_2434 = heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str5), v_t_2433));
  V v_str_2435 = heff_strAppend(v_t_2426, v_t_2434);
  V v_t_2436 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2435, ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_str6)), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam4, 1, 4, (V[]){v_ts_242, v_os_243, v_wrong_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ts_242 = heff_env(self)[3];
  V v_wrong_241 = heff_env(self)[4];
  V v_f_240 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2415);
  V v_c_2416 = ({ V a_0 = v_x_2412; V a_1 = heff_dup(v_os_243); V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s113061853x665913651(a_0, a_1)); heff_drop(v_x_2412); r_; });
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam3, 1, 6, (V[]){v_ts_242, v_os_243, v_wrong_241, v_f_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_os_243 = heff_env(self)[3];
  V v_wrong_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = (g_list_2efilter_24s313075719x1688564285(heff_dup(v_ts_242)));
  V v_c_2414 = (g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826(heff_dup(v_f_240), v_x_2412, v_t_2413));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_lam2, 1, 7, (V[]){v_x_2412, v_os_243, v_hd_244, v_ts_242, v_wrong_241, v_f_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_str0), heff_dup(heff_rfield(v_c_243, 6))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam1, 2, 3, (V[]){heff_dup(v_c_243), v_t_245, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_c_243, 6, 14); V r_ = (g_list_2efoldl_24f1046331721x1909432377(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_x_2412 = heff_intAdd(v_t_2411, v_x_2410);
  V f_ = v_k_247;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_c_249 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam3, 1, 2, (V[]){v_c_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(heff_dup(heff_rfield(v_c_243, 0)), v_t_245, MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133_lam2, 1, 4, (V[]){v_rest_244, v_hd_246, v_c_243, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str1, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str2, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str4, 5, "  0/0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str6, 13, ": not checked");
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260(V v_opts_240, V v_f_241, V v_l_242, V v_cs_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = (g_heff_2ebuild_2ecommands_2ediagCount_24s1309637845x193755133(v_cs_243));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam0, 1, 6, (V[]){v_cs_243, v_l_242, v_opts_240, v_f_241, v_z_245, v_z_244})});
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam1(V self, V *args) {
  V v_w_2420 = args[0];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2412, v_w_2420));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam2(V self, V *args) {
  V v_w_2443 = args[0];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2412, v_w_2443));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam3(V self, V *args) {
  V v_w_2461 = args[0];
  V v_c_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2412, v_w_2461));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam4(V self, V *args) {
  V v_x_2473 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2473);
  V v_t_2474 = heff_get_n(v_l_242, 1, 5);
  V v_why_2482;
  switch (heff_tag_of(v_t_2474)) {
  case TAG_Nil: {
    HeffT2 v_t_2475 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_243));
    {
      V v_field_2477 = v_t_2475.f[1];
      int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
      if ((v_tag_2476 == ((int64_t)0ULL))) {
        heff_drop(v_f_241);
        V v_x_2479 = v_field_2477;
        v_why_2482 = v_x_2479;
      } else {
        heff_drop(v_field_2477);
        v_why_2482 = heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str6));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2480 = heff_field(v_t_2474, 0);
    heff_take_n(v_t_2474, 1ULL, 2);
    heff_drop(v_cs_243);
    heff_drop(v_f_241);
    v_why_2482 = v_why_2480;
    break;
  }
  default: heff_nomatch(v_t_2474);
  }
  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2482, NTAG(TAG_Nil)});
  V v_x_2484 = heff_tag_n(TAG_Settled, 1, (V[]){heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2483, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)})});
  V f_ = v_z_245;
  args[0] = v_x_2484;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_l_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_248 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_243)));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_z_244);
      V v_c_2412 = v_field_2410;
      V v_t_2413 = heff_dup(heff_rfield(v_l_242, 1));
      V v_x_2465;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nil: {
        if (heff_intEq_c(v_x_247, MK_INT(0LL))) {
          heff_drop(v_cs_243);
          HeffT2 v_t_2415 = (g_heff_2ebuild_2edriver_2erunTests_24cpr(heff_dup(heff_rfield(v_opts_240, 1)), heff_take_field(v_opts_240, 0), heff_dup(v_c_2412)));
          {
            V v_field_2416 = v_t_2415.f[0];
            V v_field_2417 = v_t_2415.f[1];
            V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 4, 9);
            V v_t_2419 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2412), v_t_2418));
            V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam1, 1, 1, (V[]){heff_dup(v_c_2412)}), v_t_2419));
            V v_t_2422 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2421));
            V v_p_2423 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_241, NTAG(TAG_Nil), v_t_2422, v_field_2416, v_field_2417, v_l_242, v_c_2412});
            if (heff_strEq_c(heff_get_n(v_opts_240, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str0))) {
              v_x_2465 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2423});
            } else {
              V v_t_2425 = heff_dup(heff_rfield(v_p_2423, 3));
              switch (heff_tag_of(v_t_2425)) {
              case TAG_Nil: {
                V v_t_2426 = heff_dup(heff_rfield(v_p_2423, 4));
                switch (heff_tag_of(v_t_2426)) {
                case TAG_Nil: {
                  heff_drop_rec(v_p_2423, 7);
                  v_x_2465 = heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_t_2426, 0ULL, 2);
                  v_x_2465 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2423});
                  break;
                }
                default: heff_nomatch(v_t_2426);
                }
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2425, 0ULL, 2);
                v_x_2465 = heff_tag_n(TAG_Pend, 1, (V[]){v_p_2423});
                break;
              }
              default: heff_nomatch(v_t_2425);
              }
            }
          }
        } else {
          heff_drop_rec(v_opts_240, 4);
          V v_t_2431 = heff_dup(heff_rfield(v_l_242, 1));
          V v_t_2439;
          switch (heff_tag_of(v_t_2431)) {
          case TAG_Nil: {
            HeffT2 v_t_2432 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_243));
            {
              V v_field_2434 = v_t_2432.f[1];
              int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
              if ((v_tag_2433 == ((int64_t)0ULL))) {
                V v_x_2436 = v_field_2434;
                v_t_2439 = v_x_2436;
              } else {
                heff_drop(v_field_2434);
                v_t_2439 = heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str1));
              }
            }
            break;
          }
          case TAG_Cons: {
            V v_why_2437 = heff_field(v_t_2431, 0);
            heff_take_n(v_t_2431, 1ULL, 2);
            heff_drop(v_cs_243);
            v_t_2439 = v_why_2437;
            break;
          }
          default: heff_nomatch(v_t_2431);
          }
          V v_wrong_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
          V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 4, 9);
          V v_t_2442 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2412), v_t_2441));
          V v_t_2444 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam2, 1, 1, (V[]){heff_dup(v_c_2412)}), v_t_2442));
          V v_t_2445 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2444));
          V v_t_2446 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_241, v_wrong_2440, v_t_2445, NTAG(TAG_Nil), NTAG(TAG_Nil), v_l_242, v_c_2412});
          v_x_2465 = heff_tag_n(TAG_Pend, 1, (V[]){v_t_2446});
        }
        break;
      }
      case TAG_Cons: {
        V v_ru_24t_2413_24Cons = heff_take_reuse_n(v_t_2413, 0ULL, 2);
        heff_drop(v_x_247);
        heff_drop_rec(v_opts_240, 4);
        V v_t_2449 = heff_dup(heff_rfield(v_l_242, 1));
        V v_t_2457;
        switch (heff_tag_of(v_t_2449)) {
        case TAG_Nil: {
          HeffT2 v_t_2450 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_243));
          {
            V v_field_2452 = v_t_2450.f[1];
            int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
            if ((v_tag_2451 == ((int64_t)0ULL))) {
              V v_x_2454 = v_field_2452;
              v_t_2457 = v_x_2454;
            } else {
              heff_drop(v_field_2452);
              v_t_2457 = heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str2));
            }
          }
          break;
        }
        case TAG_Cons: {
          V v_why_2455 = heff_field(v_t_2449, 0);
          heff_take_n(v_t_2449, 1ULL, 2);
          heff_drop(v_cs_243);
          v_t_2457 = v_why_2455;
          break;
        }
        default: heff_nomatch(v_t_2449);
        }
        V v_wrong_2458 = heff_tag_at_n(v_ru_24t_2413_24Cons, TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
        V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 4, 9);
        V v_t_2460 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2412), v_t_2459));
        V v_t_2462 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam3, 1, 1, (V[]){heff_dup(v_c_2412)}), v_t_2460));
        V v_t_2463 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2462));
        V v_t_2464 = heff_rec_n(7, shape_file__wrong__reports__outcomes__integrations__loaded__checked, (V[]){v_f_241, v_wrong_2458, v_t_2463, NTAG(TAG_Nil), NTAG(TAG_Nil), v_l_242, v_c_2412});
        v_x_2465 = heff_tag_n(TAG_Pend, 1, (V[]){v_t_2464});
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      V f_ = v_z_245;
      args[0] = v_x_2465;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_x_247);
      heff_drop_rec(v_opts_240, 4);
      heff_drop(v_field_2410);
      V v_t_2466 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str3), heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str4)));
      V v_t_2467 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2466, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_str5)), NTAG(TAG_MkUnit)});
      V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
      V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
      V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2472}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s2071935309x1155842260_lam4, 1, 4, (V[]){v_l_242, v_cs_243, v_f_241, v_z_245})));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str22, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665(V v_prog_240, V v_failed_241, V v_who_242, V v_st_243, V v_flags_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248, V v_hd_249, V v_k_2410) {
top: ;
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_dir_246), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam1, 1, 11, (V[]){heff_dup(v_st_243), v_dir_246, v_prog_240, v_p_245, v_hd_249, v_flags_244, v_out_247, v_next_248, v_k_2410, v_who_242, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam0(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2421; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam3(V self, V *args) {
  V v_n_2426 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_st_243; V a_1 = v_dir_246; V a_2 = v_n_2426; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam4(V self, V *args) {
  V v_t_2431 = args[0];
  return v_t_2431;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V v_t_2443 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str14)});
  V f_ = v_k_2442;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam8(V self, V *args) {
  V v_r_2451 = args[0];
  return v_r_2451;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam12(V self, V *args) {
  V v_x_2476 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_failed_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2476);
  V v_t_2477 = heff_strAppend(v_who_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str22), v_out_247));
  V f_ = v_failed_241;
  heff_room[0] = v_t_2477;
  heff_room[1] = v_hd_249;
  heff_room[2] = v_k_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2468);
  V v_t_2469 = heff_strAppend(heff_dup(v_who_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str20), heff_dup(v_out_247)));
  V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str21)), NTAG(TAG_MkUnit)});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam12, 1, 5, (V[]){v_who_242, v_out_247, v_failed_241, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2454 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_who_242 = heff_env(self)[4];
  V v_out_247 = heff_env(self)[5];
  V v_failed_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_take_field(v_x_2454, 0);
  V v_t_2461;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_Exited: {
    V v_n_2459 = heff_field(v_t_2458, 0);
    heff_take_n(v_t_2458, 1ULL, 1);
    v_t_2461 = heff_intEq(v_n_2459, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2458, 0ULL, 1);
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2461 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2454, 3);
    heff_drop(v_who_242);
    heff_drop(v_out_247);
    heff_drop(v_failed_241);
    heff_drop(v_t_2461);
    V f_ = v_next_248;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2461);
    V v_t_2462 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2454, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam11, 1, 5, (V[]){v_who_242, v_out_247, v_hd_249, v_failed_241, v_k_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_failed_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2455 = heff_tag_n(TAG_End, 2, (V[]){v_x_2433, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2455}));
  return (g_co_2eop_24s94900133x232571340(v_t_2456, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam10, 1, 7, (V[]){v_x_2454, v_next_248, v_hd_249, v_k_2410, v_who_242, v_out_247, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  V v_flags_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2433 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2453;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Nothing: {
    heff_drop(v_x_2422);
    heff_drop(v_flags_244);
    v_c_2453 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam7_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2444 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str15), NTAG(TAG_Nil)});
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2445})});
    V v_t_2447 = (g_prelude_2e_2b_2b(v_os_2444, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_x_2422, v_t_2447));
    V v_t_2449 = (g_prelude_2e_2b_2b(v_flags_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str17), v_t_2448})));
    V v_as_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str18), v_t_2449});
    V v_t_2452 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2433), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str19), v_as_2450, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam8_clo)})}));
    v_c_2453 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){v_t_2452}));
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam9, 1, 8, (V[]){v_x_2433, v_prog_240, v_hd_249, v_next_248, v_k_2410, v_who_242, v_out_247, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_flags_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str3); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2438;
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_drop(v_t_2434);
    v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str4);
  } else {
    heff_drop(v_t_2434);
    V v_t_2435 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str5); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_t_2435);
      v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str6);
    } else {
      heff_drop(v_t_2435);
      V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str7); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop(v_t_2436);
        v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str8);
      } else {
        heff_drop(v_t_2436);
        V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str9); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str10); V a_2 = v_flags_244; V r_ = (g_list_2eany_24s529567056x880977707(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
          heff_drop(v_t_2437);
          v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str11);
        } else {
          heff_drop(v_t_2437);
          v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str12);
        }
      }
    }
  }
  V v_c_2439 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1298720733x988973920(heff_dup(v_prog_240), heff_dup(v_x_2433), v_t_2438, v_x_2427, NTAG(TAG_Nil)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam6, 1, 10, (V[]){v_out_247, v_x_2422, v_flags_244, v_prog_240, v_x_2433, v_hd_249, v_next_248, v_k_2410, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2410 = heff_env(self)[8];
  V v_who_242 = heff_env(self)[9];
  V v_failed_241 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2419;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2418 = heff_dup(heff_field(v_x_2417, 0));
    v_t_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V v_t_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str0); V a_1 = v_t_2419; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam2, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_246)}), v_t_2420));
  V v_t_2424;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    v_t_2424 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2423 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    v_t_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V v_t_2425 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str1); V a_1 = v_t_2424; V r_ = (g_list_2efilter_24s794048906x2073543501(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam3, 1, 2, (V[]){v_st_243, v_dir_246}), v_t_2425));
  V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2422));
  V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2427));
  V v_total_2430 = heff_intAdd(heff_intAdd(v_t_2428, v_t_2429), MK_INT(1LL));
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_str2), v_total_2430, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam4_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2432, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_lam5, 1, 10, (V[]){v_flags_244, v_prog_240, v_x_2427, v_hd_249, v_out_247, v_x_2422, v_next_248, v_k_2410, v_who_242, v_failed_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_str1, 4, "page");
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_checked_247, V v_z_248, V v_z_249) {
top: ;
  V v_c_2410 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_str0); V a_1 = heff_dup(v_sources_241); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366(b_0, a_1)); heff_drop(b_0); r_; });
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam0, 1, 10, (V[]){v_sources_241, v_checked_247, v_z_248, heff_dup(v_badL_246), v_z_249, v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245})});
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446(a[0], a[1], a[2], a3, a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a3); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam1(V self, V *args) {
  V v_c_2414 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2415 = (g_list_2efind_24s1983706162x228765702_24cpr(heff_dup(v_c_2414), v_sources_241));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2417;
      V v_t_2420 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2413, v_s_2419));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2414, v_t_2420));
    } else {
      heff_drop(v_x_2413);
      heff_drop(v_field_2417);
      return v_c_2414;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_badL_246 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_bi_240 = heff_env(self)[4];
  V v_sources_241 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2422);
  if ((heff_dup(v_badL_246) == NTAG(TAG_True))) {
    heff_drop(v_badL_246);
    heff_drop(v_x_2421);
    heff_drop(v_bi_240);
    heff_drop(v_sources_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_z_248, v_z_249));
  } else {
    heff_drop(v_badL_246);
    V v_t_2429 = (g_list_2eany_24s469495312x865582084(v_x_2421));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_x_2421);
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_t_2429);
      V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_z_248, v_z_249));
    } else {
      heff_drop(v_t_2429);
      return ({ V a_0 = v_bi_240; V a_1 = v_sources_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_x_2421; V a_7 = v_z_248; V a_8 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s1347222791x1121808400(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sources_241 = heff_env(self)[0];
  V v_checked_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_badL_246 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_str1); V a_1 = heff_dup(v_sources_241); V a_2 = v_x_2411; V a_3 = heff_dup(v_sources_241); V r_ = (g_list_2emap_24s159228909x554161698(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
  V v_x_2413 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2412));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam1, 1, 2, (V[]){heff_dup(v_sources_241), v_x_2413}), v_checked_247));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_x_2421), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_lam2, 1, 10, (V[]){v_badL_246, v_z_248, v_z_249, v_x_2421, v_bi_240, v_sources_241, v_file_242, v_name_243, v_outPath_244, v_done_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam2(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2425, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2426});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam4, 1, 3, (V[]){v_x_2425, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_str0))) {
    v_t_2417 = NTAG(TAG_Windows);
  } else {
    v_t_2417 = NTAG(TAG_Posix);
  }
  V v_path_2418 = ({ V a_0 = v_t_2417; V a_1 = heff_dup(v_dir_240); V a_2 = heff_dup(v_f_246); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2418, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam2_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194(V v_prog_240, V v_st_241, V v_cmd_242, V v_t_243, V v_none_244, V v_done_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str0)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s539143178x1536032116(v_t_249, NTAG(TAG_Nil)));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam0, 1, 8, (V[]){v_prog_240, v_z_246, v_cmd_242, v_z_247, v_st_241, v_t_243, v_none_244, v_done_245})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam1(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam7(V self, V *args) {
  V v_ns_2455 = args[0];
  return v_ns_2455;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam9(V self, V *args) {
  V v_t_2465 = args[0];
  return v_t_2465;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam13(V self, V *args) {
  V v_x_2489 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2489);
  V v_t_2490 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam12(V self, V *args) {
  V v_x_2475 = args[0];
  V v_x_2472 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_none_244 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_st_241 = heff_env(self)[6];
  V v_t_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2475);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2472, 1)))) {
    heff_drop(v_none_244);
    heff_drop(v_prog_240);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    heff_drop(v_done_245);
    V v_n_2477 = heff_get_n(v_x_2472, 1, 2);
    V v_t_2479;
    if (heff_intEq_c_lent(v_n_2477, MK_INT(1LL), 2)) {
      heff_drop(v_n_2477);
      v_t_2479 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str17);
    } else {
      v_t_2479 = heff_strAppend(heff_intShow(v_n_2477), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str18));
    }
    V v_what_2480 = heff_strAppend(v_t_2479, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str19));
    V v_t_2481 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str20), heff_strAppend(v_what_2480, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str21)));
    V v_t_2482 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str22), heff_strAppend(v_cmd_242, v_t_2481));
    V v_t_2483 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2482, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str23)), NTAG(TAG_MkUnit)});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2488}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam13, 1, 2, (V[]){v_z_246, v_z_247})));
  } else {
    heff_drop(v_cmd_242);
    V v_t_2496 = heff_dup(heff_rfield(v_x_2472, 0));
    switch (heff_tag_of(v_t_2496)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2472, 2);
      heff_drop(v_prog_240);
      heff_drop(v_st_241);
      heff_drop_rec(v_t_243, 6);
      heff_drop(v_done_245);
      V f_ = v_none_244;
      heff_room[0] = v_z_246;
      heff_room[1] = v_z_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2496, 0ULL, 2);
      heff_drop(v_none_244);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665(v_prog_240, v_st_241, v_t_243, v_done_245, heff_get_n(v_x_2472, 0, 2), v_z_246, v_z_247));
    }
    default: return heff_nomatch(v_t_2496);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam11(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_2467 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_none_244 = heff_env(self)[5];
  V v_st_241 = heff_env(self)[6];
  V v_t_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2473 = heff_tag_n(TAG_End, 2, (V[]){v_x_2467, NTAG(TAG_MkUnit)});
  V v_t_2474 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2473}));
  return (g_co_2eop_24s94900133x232571340(v_t_2474, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam12, 1, 9, (V[]){v_x_2472, v_cmd_242, v_z_246, v_z_247, v_none_244, v_prog_240, v_st_241, v_t_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam10(V self, V *args) {
  V v_x_2467 = args[0];
  V v_x_2461 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_cmd_242 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_none_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2468 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2470;
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Nothing: {
    v_t_2470 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2469 = heff_field(v_x_2461, 0);
    heff_take_n(v_x_2461, 1ULL, 1);
    v_t_2470 = v_x_2469;
    break;
  }
  default: heff_nomatch(v_x_2461);
  }
  V v_c_2471 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_243), heff_dup(v_x_2467), v_t_2468, v_t_2470));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam11, 1, 9, (V[]){v_x_2467, v_prog_240, v_z_246, v_cmd_242, v_z_247, v_none_244, v_st_241, v_t_243, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam8(V self, V *args) {
  V v_x_2461 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_none_244 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2463;
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Nothing: {
    v_t_2463 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2462 = heff_dup(heff_field(v_x_2461, 0));
    v_t_2463 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_x_2461);
  }
  V v_total_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2463; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
  V v_t_2466 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str16), v_total_2464, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam9_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2466, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam10, 1, 9, (V[]){v_x_2461, v_prog_240, v_st_241, v_t_243, v_z_246, v_cmd_242, v_z_247, v_none_244, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam6(V self, V *args) {
  V v_x_2453 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_cmd_242 = heff_env(self)[4];
  V v_z_247 = heff_env(self)[5];
  V v_none_244 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2453);
  V v_path_2454 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str15)));
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_path_2454, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam7_clo)})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam8, 1, 8, (V[]){v_prog_240, v_z_246, v_st_241, v_t_243, v_cmd_242, v_z_247, v_none_244, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_cmd_242 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_none_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2421);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2418, 1)))) {
    heff_drop(v_st_241);
    heff_drop_rec(v_t_243, 6);
    heff_drop(v_prog_240);
    heff_drop(v_none_244);
    heff_drop(v_done_245);
    V v_n_2423 = heff_get_n(v_x_2418, 1, 2);
    V v_t_2425;
    if (heff_intEq_c_lent(v_n_2423, MK_INT(1LL), 2)) {
      heff_drop(v_n_2423);
      v_t_2425 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str2);
    } else {
      v_t_2425 = heff_strAppend(heff_intShow(v_n_2423), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str3));
    }
    V v_what_2426 = heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str4));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str5), heff_strAppend(v_what_2426, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str6)));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str7), heff_strAppend(v_cmd_242, v_t_2427));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str8)), NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam5, 1, 2, (V[]){v_z_246, v_z_247})));
  } else {
    V v_n_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2418, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2444;
    if (heff_intEq_c_lent(v_n_2442, MK_INT(1LL), 2)) {
      heff_drop(v_n_2442);
      v_t_2444 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str9);
    } else {
      v_t_2444 = heff_strAppend(heff_intShow(v_n_2442), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str10));
    }
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str11), heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str12)));
    V v_str_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str13), heff_strAppend(heff_dup(v_cmd_242), v_t_2445));
    V v_t_2447 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2446, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str14)), NTAG(TAG_MkUnit)});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam6, 1, 8, (V[]){v_st_241, v_t_243, v_z_246, v_prog_240, v_cmd_242, v_z_247, v_none_244, v_done_245})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  V v_none_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2419 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2419}));
  return (g_co_2eop_24s94900133x232571340(v_t_2420, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam4, 1, 9, (V[]){v_x_2418, v_cmd_242, v_z_246, v_z_247, v_st_241, v_t_243, v_prog_240, v_none_244, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_cmd_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  V v_none_244 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2417 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_x_2415); V a_2 = v_t_2416; V a_3 = v_x_2411; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s2061480346x491872923(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam3, 1, 9, (V[]){v_x_2415, v_prog_240, v_z_246, v_cmd_242, v_z_247, v_st_241, v_t_243, v_none_244, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_cmd_242 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_none_244 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_total_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2411));
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_str1), v_total_2412, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam1_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_lam2, 1, 9, (V[]){v_prog_240, v_x_2411, v_z_246, v_cmd_242, v_z_247, v_st_241, v_t_243, v_none_244, v_done_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460(V v_before_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam0_clo)})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam1, 1, 5, (V[]){v_path_244, v_p_242, v_p_243, v_before_240, v_rest_245})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam0(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam3, 1, 1, (V[]){v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  return v_s_2429;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam8(V self, V *args) {
  V v_i_2452 = args[0];
  V v_before_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_i_2452}));
  return ({ V a_0 = v_t_2453; V a_1 = v_before_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_before_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_st_2438 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_src_2428 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2444 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str12), v_st_2438}), heff_dup(v_path_244)));
  V v_ps_2445 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str14), heff_take_field(v_x_2440, 0), heff_take_field(v_x_2440, 1), heff_take_field(v_x_2440, 2), heff_get_n(v_x_2440, 3, 5)});
  HeffT2 v_t_2446 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_2445), heff_get_n(v_ps_2445, 2, 6), heff_dup(v_path_244)));
  V v_library_2451;
  {
    V v_field_2448 = v_t_2446.f[1];
    int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
    v_library_2451 = heff_bool(((v_tag_2447 == ((int64_t)0ULL)) && ({ V v_x_2450 = heff_dup(v_field_2448); int c_ = 1; heff_drop(v_x_2450); c_; })));
    heff_drop(v_field_2448);
  }
  V v_t_2454 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam8, 1, 1, (V[]){v_before_240}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
  V v_t_2455 = heff_rec_n(7, shape_module__path__shown__source__renames__implicit__library, (V[]){v_m_2444, heff_dup(v_path_244), v_path_244, v_src_2428, NTAG(TAG_Nil), v_t_2454, v_library_2451});
  V v_x_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_x_2443});
  V f_ = v_p_243;
  args[0] = v_x_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_2438 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_src_2428 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2441 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str7), heff_dup(v_st_2438)}), heff_dup(v_path_244)));
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, heff_dup(v_before_240)});
  return (g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460(v_t_2442, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam7, 1, 6, (V[]){v_st_2438, v_path_244, v_x_2440, v_before_240, v_src_2428, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_src_2428 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2438;
  if (heff_strEq_c(v_x_2436, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str2))) {
    v_st_2438 = NTAG(TAG_Windows);
  } else {
    v_st_2438 = NTAG(TAG_Posix);
  }
  V v_c_2439 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo);
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam6, 1, 7, (V[]){v_st_2438, v_path_244, v_before_240, v_rest_245, v_p_242, v_src_2428, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    heff_drop(v_before_240);
    heff_drop(v_rest_245);
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str0), v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_str1));
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam2, 1, 2, (V[]){v_p_242, v_p_243})));
  }
  case TAG_Just: {
    V v_src_2428 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2430 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam4_clo)})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s94900133x232571340(v_t_2435, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1702309521x974965460_lam5, 1, 6, (V[]){v_p_242, v_path_244, v_before_240, v_rest_245, v_src_2428, v_p_243})));
  }
  default: return heff_nomatch(v_x_2412);
  }
}