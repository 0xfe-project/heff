// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_Move 53768
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_arity 294440695
#define LBL_backend 2032133329
#define LBL_bind 9519364
#define LBL_copies 592412158
#define LBL_defs 9574869
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_emitted 749050271
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_file 9638467
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_js 10160
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_malg 9839318
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_order 307364712
#define LBL_outPath 1272254166
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_pages 307784670
#define LBL_paths 307797256
#define LBL_run 322821
#define LBL_said 10017968
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_top 324559
#define LBL_units 312791945
static uint32_t shape_output__groups__copies__jss[] = {LBL_output, LBL_groups, LBL_copies, LBL_jss};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1734868233x1940051977(V, V, V);
V g_co_2eop_24s1734868233x1940051977_entry(V self, V *a);
extern Clo g_co_2eop_24s1734868233x1940051977_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087(V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemit_2eemitKept(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKept_clo;
HeffT2 g_heff_2ecompile_2eemit_2eemitKept_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2epropName(V);
V g_heff_2ecompile_2eemit_2epropName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2epropName_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587(V, V, V);
V g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_clo;
HeffT3 g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr(V, V, V);
HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V, V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s331724893x1262243254(V);
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a);
extern Clo g_list_2eany_24s331724893x1262243254_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1246062630x1975509602(V, V);
V g_list_2efoldl_24s1246062630x1975509602_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1246062630x1975509602_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1707192740x1747748619(V, V);
V g_list_2efoldl_24s1707192740x1747748619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1707192740x1747748619_clo;
V g_list_2efoldl_24s552376067x1255995125(V, V);
V g_list_2efoldl_24s552376067x1255995125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s552376067x1255995125_clo;
V g_list_2efoldl_24s650566757x317183241(V, V, V);
V g_list_2efoldl_24s650566757x317183241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s650566757x317183241_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f2124896334x71745266(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0(V self, V *args) {
  V v_v_244 = args[0];
  return v_v_244;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4(V self, V *args) {
  V v_v_2424 = args[0];
  return v_v_2424;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6(V self, V *args) {
  V v_s_2434 = args[0];
  return v_s_2434;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2444;
  if (heff_strEq_c(v_x_2443, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str3))) {
    v_st_2444 = NTAG(TAG_Windows);
  } else {
    v_st_2444 = NTAG(TAG_Posix);
  }
  V v_x_2460;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    V v_t_2447;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2433)) {
      case TAG_Nothing: {
        v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2445 = heff_field(v_x_2433, 0);
        heff_take_n(v_x_2433, 1ULL, 1);
        v_t_2447 = v_x_2445;
        break;
      }
      default: heff_nomatch(v_x_2433);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2446 = heff_field(v_x_2423, 0);
      heff_take_n(v_x_2423, 1ULL, 1);
      heff_drop(v_x_2433);
      v_t_2447 = v_x_2446;
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    V v_t_2448 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_t_2447));
    V v_t_2449 = (g_std_2epath_2eparse(heff_dup(v_st_2444), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str5)));
    V v_t_2450 = (g_std_2epath_2ejoin(v_t_2448, v_t_2449));
    V v_a_2451 = ({ V a_0 = v_st_2444; V a_1 = v_t_2450; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2450); r_; });
    V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2444), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str6)));
    V v_t_2453 = (g_std_2epath_2eparse(heff_dup(v_st_2444), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str7)));
    V v_t_2454 = (g_std_2epath_2ejoin(v_t_2452, v_t_2453));
    V v_b_2455 = ({ V a_0 = v_st_2444; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2454); r_; });
    V v_t_2456 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_a_2451));
    V v_t_2457 = (g_std_2epath_2eparse(heff_dup(v_st_2444), v_b_2455));
    V v_t_2458 = (g_std_2epath_2ejoin(v_t_2456, v_t_2457));
    v_x_2460 = ({ V a_0 = v_st_2444; V a_1 = v_t_2458; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2458); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2459 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    heff_drop(v_x_2423);
    heff_drop(v_x_2433);
    heff_drop(v_st_2444);
    v_x_2460 = v_d_2459;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_241;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6_clo)})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2441}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam7, 1, 4, (V[]){v_x_2413, v_x_2423, v_x_2433, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2431}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam5, 1, 5, (V[]){v_malg_243, v_bind_242, v_x_2413, v_x_2423, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam3, 1, 4, (V[]){v_malg_243, v_bind_242, v_x_2413, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2423));
  V v_t_2425;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_str0))) {
    v_t_2425 = NTAG(TAG_Windows);
  } else {
    v_t_2425 = NTAG(TAG_Posix);
  }
  V v_x_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2425); heff_drop(v_x_2424); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2421}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam3, 1, 2, (V[]){v_x_2413, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str5, 1, ".");
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(V v_bi_240, V v_outPath_241, V v_done_242, V v_c_243, V v_available_244, V v_r_245, V v_hd_246, V v_k_247) {
top: ;
  V v_key_248 = heff_take_field(v_r_245, 0);
  V v_effect_249 = heff_get_n(v_r_245, 1, 2);
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam0, 1, 9, (V[]){v_bi_240, v_hd_246, v_available_244, v_c_243, v_key_248, v_effect_249, v_outPath_241, v_done_242, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_available_244 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_key_248 = heff_env(self)[3];
  V v_effect_249 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_242 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_available_2417 = v_available_244;
  V v_g_2418 = heff_get_n(heff_get_n(v_c_243, 5, 14), 0, 10);
  V v_key_2419 = v_key_248;
  V v_eff_2420 = v_effect_249;
  V v_vers_2421 = heff_dup(heff_rfield(v_bi_240, 1));
  V v_m_2422 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
  V v_bs_2424 = (g_list_2emap_24s1173914895x100384474(v_t_2423));
  V v_t_2425 = (g_list_2efoldl_24s1707192740x1747748619(heff_dup(g_std_2eordmap_2eempty_get()), v_bs_2424));
  V v_t_2426 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2424; V r_ = (g_list_2efoldl_24s552376067x1255995125(a_0, a_1)); heff_drop(v_bs_2424); r_; });
  V v_ks_2427 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2425, v_t_2426});
  V v_m_2428 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_t_2429 = ({ V a_0 = v_m_2428; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2428); r_; });
  V v_bs_2430 = (g_list_2emap_24s1173914895x100384474(v_t_2429));
  V v_kept_2431 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2430; V r_ = (g_list_2efoldl_24s1246062630x1975509602(a_0, a_1)); heff_drop(v_bs_2430); r_; });
  V v_t_2432 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_2420));
  V v_xs_2433 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str2); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str3); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str4); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str5); V a_6 = v_t_2432; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
  V v_t_2434 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_2433));
  V v_provs_2435 = ({ V a_0 = v_available_2417; V a_1 = v_t_2434; V r_ = (g_heff_2ecompile_2eemit_2eprovsForGo(a_0, a_1)); heff_drop(v_available_2417); r_; });
  V v_eff_2436 = v_eff_2420;
  V v_key_2437 = heff_dup(v_key_2419);
  V v_kept_2438 = v_kept_2431;
  HeffT4 v_t_2439 = (g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(v_g_2418, v_key_2419, v_vers_2421, v_ks_2427));
  V v_t_2456;
  {
    V v_field_2440 = v_t_2439.f[0];
    V v_field_2441 = v_t_2439.f[1];
    V v_field_2442 = v_t_2439.f[2];
    V v_field_2443 = v_t_2439.f[3];
    V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_t_2446 = (g_heff_2ecompile_2elower_2efusedOf(v_t_2445, v_field_2440));
    HeffT3 v_t_2447 = (g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr(v_t_2444, v_field_2441, v_t_2446));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_field_2450 = v_t_2447.f[2];
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
      HeffT2 v_t_2452 = (g_heff_2ecompile_2eemit_2eemitKept_24cpr(v_field_2449, v_field_2448, v_t_2451, v_kept_2438));
      {
        V v_field_2453 = v_t_2452.f[0];
        V v_field_2454 = v_t_2452.f[1];
        V v_t_2455 = ({ V a_0 = v_provs_2435; V a_1 = v_eff_2436; V a_2 = v_key_2437; V a_3 = v_field_2453; V r_ = (g_heff_2ecompile_2eemit_2erunSource(a_0, a_1, a_2, a_3)); heff_drop(v_key_2437); r_; });
        v_t_2456 = heff_rec_n(4, shape_output__groups__copies__jss, (V[]){heff_rec_n(2, shape_source__errors, (V[]){v_t_2455, v_field_2450}), v_field_2442, v_field_2443, v_field_2454});
      }
    }
  }
  return ({ V a_0 = v_bi_240; V a_1 = v_outPath_241; V a_2 = v_x_2410; V a_3 = v_x_2415; V a_4 = v_t_2416; V a_5 = v_done_242; V a_6 = v_t_2456; V a_7 = v_hd_246; V a_8 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_available_244 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_key_248 = heff_env(self)[4];
  V v_effect_249 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_242 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam2, 1, 10, (V[]){v_x_2410, v_available_244, v_c_243, v_key_248, v_effect_249, v_bi_240, v_outPath_241, v_done_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam0, 2, 5, (V[]){v_c_244, v_file_242, heff_dup(v_name_240), v_outPath_241, v_done_243});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_hashes_2411 = heff_take_field(v_x_2410, 1);
  V v_done_2412 = heff_get_n(v_x_2410, 0, 2);
  V v_t_2413 = (g_list_2emap_24s1698496827x1884878103(heff_dup(v_done_2412)));
  V v_t_2414 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_x_247, 2), v_hashes_2411, v_t_2413});
  V v_t_2415 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_248, 1));
  heff_drop(v_x_248);
  return ({ V a_0 = v_t_2414; V a_1 = heff_get_n(v_x_247, 0, 5); V a_2 = v_file_242; V a_3 = v_name_240; V a_4 = v_outPath_241; V a_5 = v_done_243; V a_6 = v_t_2415; V a_7 = v_done_2412; V a_8 = v_hd_245; V a_9 = v_k_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s875339231x1663367778(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_name_240); heff_drop(v_t_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_247)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam3, 1, 8, (V[]){v_x_247, v_x_248, v_file_242, v_name_240, v_outPath_241, v_done_243, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_str0), heff_dup(heff_rfield(v_x_247, 1)), MK_INT(0LL), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam2, 1, 7, (V[]){v_x_247, v_hd_245, v_file_242, v_name_240, v_outPath_241, v_done_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981_lam1, 1, 6, (V[]){v_hd_245, v_file_242, v_name_240, v_outPath_241, v_done_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str1, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str2, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str4, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str5, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str6, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str7, 16, "export default {");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str11, 2, "};");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str12, 6, "  get ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str13, 17, "() { return $ext(");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str14, 2, "$c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str15, 2, "()");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str16, 9, "undefined");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str17, 5, "); },");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str19, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str20, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str21, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str22, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str23, 46, ": build it with `zig build-obj -O ReleaseFast ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str24, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str25, 8, "heff.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str26, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str27, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str28, 39, " -femit-bin=runtime.o` and `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str29, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str30, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str31, 26, " runtime.o -o PROGRAM -lm`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str32, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str33, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str34, 16, ": esm, page or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str35, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam10, 2, 0};
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam14(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087(V v_o_240) {
top: ;
  V v_backend_241 = heff_take_field(v_o_240, 3);
  V v_outPath_242 = heff_take_field(v_o_240, 1);
  V v_file_243 = heff_take_field(v_o_240, 0);
  V v_name_244 = heff_get_n(v_o_240, 2, 4);
  if (heff_strEq_c_lent(v_backend_241, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str0), 2)) {
    heff_drop(v_backend_241);
    V v_outPath_245 = v_outPath_242;
    V v_file_246 = v_file_243;
    return ({ V a_0 = v_name_244; V a_1 = heff_dup(v_outPath_245); V a_2 = v_file_246; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam0, 2, 1, (V[]){v_outPath_245}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981(a_0, a_1, a_2, a_3)); heff_drop(v_name_244); r_; });
  } else {
    if (heff_strEq_c_lent(v_backend_241, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str4), 2)) {
      heff_drop(v_backend_241);
      switch (heff_tag_of(v_name_244)) {
      case TAG_Nothing: {
        V v_file_2420 = v_file_243;
        V v_outPath_2421 = v_outPath_242;
        V v_c_2422 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_2420)));
        return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam1, 2, 3, (V[]){v_c_2422, v_file_2420, v_outPath_2421});
      }
      case TAG_Just: {
        heff_take_n(v_name_244, 0ULL, 1);
        heff_drop(v_outPath_242);
        heff_drop(v_file_243);
        return ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam10_clo);
      }
      default: return heff_nomatch(v_name_244);
      }
    } else {
      if (heff_strEq_c_lent(v_backend_241, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str21), 2)) {
        heff_drop(v_backend_241);
        V v_name_24126 = v_name_244;
        V v_outPath_24127 = v_outPath_242;
        V v_file_24128 = v_file_243;
        V v_t_24129 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str22), heff_dup(v_outPath_24127)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str23));
        V v_outPath_24130 = heff_dup(v_outPath_24127);
        int64_t v_t_24131 = (heff_unbox_word(heff_strLength_lent(v_outPath_24130, 0)) - ((int64_t)1ULL));
        V v_t_24132 = heff_strSlice(heff_dup(v_outPath_24130), heff_box_word(v_t_24131), heff_strLength_lent(v_outPath_24130, 0));
        V v_t_24137;
        if (heff_strEq_c(v_t_24132, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str24))) {
          v_t_24137 = heff_strAppend(v_outPath_24130, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str25));
        } else {
          int64_t v_t_24133 = (heff_unbox_word(heff_strLength_lent(v_outPath_24130, 0)) - ((int64_t)2ULL));
          V v_t_24134 = heff_strSlice(heff_dup(v_outPath_24130), heff_box_word(v_t_24133), heff_strLength_lent(v_outPath_24130, 0));
          V v_t_24136;
          if (heff_strEq_c(v_t_24134, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str26))) {
            int64_t v_t_24135 = (heff_unbox_word(heff_strLength_lent(v_outPath_24130, 0)) - ((int64_t)2ULL));
            v_t_24136 = heff_strSlice(v_outPath_24130, MK_INT(0LL), heff_box_word(v_t_24135));
          } else {
            v_t_24136 = v_outPath_24130;
          }
          v_t_24137 = heff_strAppend(v_t_24136, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str27));
        }
        V v_t_24138 = heff_strAppend(heff_strAppend(v_t_24129, v_t_24137), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str28));
        int64_t v_t_24139 = (heff_unbox_word(heff_strLength_lent(v_outPath_24127, 0)) - ((int64_t)1ULL));
        V v_t_24140 = heff_strSlice(heff_dup(v_outPath_24127), heff_box_word(v_t_24139), heff_strLength_lent(v_outPath_24127, 0));
        V v_t_24141;
        if (heff_strEq_c(v_t_24140, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str29))) {
          v_t_24141 = heff_strAppend(heff_dup(v_outPath_24127), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str30));
        } else {
          v_t_24141 = heff_dup(v_outPath_24127);
        }
        V v_str_24142 = heff_strAppend(heff_strAppend(v_t_24138, v_t_24141), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str31));
        V v_c_24143 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_24128)));
        return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam12, 2, 5, (V[]){v_c_24143, v_str_24142, v_name_24126, v_outPath_24127, v_file_24128});
      } else {
        heff_drop(v_outPath_242);
        heff_drop(v_file_243);
        heff_drop(v_name_244);
        return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam14, 2, 1, (V[]){v_backend_241});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087(a[0]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_outPath_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_249 = heff_take_field(v_hd_247, 1);
  V v_malg_2410 = heff_get_n(v_hd_247, 2, 3);
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str1), v_outPath_245), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str2));
  V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str3)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(v_malg_2410, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
  V f_ = v_bind_249;
  args[0] = v_t_2419;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam6(V self, V *args) {
  V v_acc_2446 = args[0];
  V v_k_2447 = args[1];
  V v_g_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2448 = ({ V b_0 = heff_get_n(v_g_2443, 1, 8); V a_1 = v_k_2447; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2450 = v_t_2448.f[1];
    int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
    if ((v_tag_2449 == ((int64_t)0ULL))) {
      V v_e_2451 = v_field_2450;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2447, v_e_2451}), v_acc_2446});
    } else {
      heff_drop(v_k_2447);
      heff_drop(v_field_2450);
      return v_acc_2446;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam7(V self, V *args) {
  V v_d_2466 = args[0];
  V v_reached_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2467 = ({ V a_0 = v_reached_2465; V b_1 = heff_get_n(v_d_2466, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_2465); heff_drop(b_1); r_; });
  {
    V v_field_2469 = v_t_2467.f[1];
    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2468 == ((int64_t)0ULL)) && ({ V v_x_2470 = heff_dup(v_field_2469); int c_ = 1; heff_drop(v_x_2470); c_; })));
    heff_drop(v_field_2469);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam8(V self, V *args) {
  V v_o_2490 = args[0];
  V v_globals_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2491 = ({ V a_0 = v_globals_2483; V b_1 = heff_get_n(v_o_2490, 1, 2); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_globals_2483); heff_drop(b_1); r_; });
  {
    V v_field_2493 = v_t_2491.f[1];
    int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2492 == ((int64_t)0ULL)) && ({ V v_x_2494 = heff_dup(v_field_2493); int c_ = 1; heff_drop(v_x_2494); c_; })));
    heff_drop(v_field_2493);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam9(V self, V *args) {
  V v_o_2496 = args[0];
  V v_globals_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_gs_2497 = v_globals_2483;
  V v_o_2498 = v_o_2496;
  V v_name_2499 = heff_take_field(v_o_2498, 0);
  V v_key_24100 = heff_get_n(v_o_2498, 1, 2);
  V v_t_24101 = (g_heff_2ecompile_2eemit_2epropName(v_name_2499));
  V v_t_24102 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str12), v_t_24101), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str13));
  HeffT2 v_t_24103 = ({ V a_0 = v_gs_2497; V a_1 = v_key_24100; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_gs_2497); heff_drop(v_key_24100); r_; });
  V v_t_24110;
  {
    V v_field_24105 = v_t_24103.f[1];
    int64_t v_tag_24104 = ((int64_t)v_t_24103.f[0]);
    if ((v_tag_24104 == ((int64_t)0ULL))) {
      V v_i_24106 = v_field_24105;
      V v_arity_24107 = heff_take_field(v_i_24106, 1);
      V v_js_24108 = heff_take_field(v_i_24106, 0);
      V v_lazy_24109 = heff_get_n(v_i_24106, 2, 4);
      if (heff_intLe_c(MK_INT(2LL), v_arity_24107)) {
        heff_drop(v_lazy_24109);
        v_t_24110 = heff_strAppend(v_js_24108, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str14));
      } else {
        if ((heff_dup(v_lazy_24109) == NTAG(TAG_True))) {
          heff_drop(v_lazy_24109);
          v_t_24110 = heff_strAppend(v_js_24108, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str15));
        } else {
          heff_drop(v_lazy_24109);
          v_t_24110 = v_js_24108;
        }
      }
    } else {
      heff_drop(v_field_24105);
      v_t_24110 = ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str16);
    }
  }
  return heff_strAppend(heff_strAppend(v_t_24102, v_t_24110), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str17));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_cs_2432 = heff_env(self)[0];
  V v_badL_2431 = heff_env(self)[1];
  V v_outPath_2430 = heff_env(self)[2];
  V v_hd_2433 = heff_env(self)[3];
  V v_k_2434 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2435);
  HeffT2 v_t_2436 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2432));
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    if ((v_tag_2437 == ((int64_t)0ULL))) {
      V v_c_2439 = v_field_2438;
      V v_top_2440 = heff_take_field(v_c_2439, 5);
      V v_own_2441 = heff_get_n(v_c_2439, 7, 14);
      V v_t_2442;
      if ((heff_dup(v_badL_2431) == NTAG(TAG_True))) {
        heff_drop(v_cs_2432);
        heff_drop(v_badL_2431);
        v_t_2442 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_2431);
        v_t_2442 = ({ V a_0 = v_cs_2432; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2432); r_; });
      }
      V v_g_2443 = heff_get_n(v_top_2440, 0, 10);
      V v_exports0_2444 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str6); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_2441; V r_ = (g_list_2emap_24f2124896334x71745266(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
      V v_g_2445 = heff_dup(v_g_2443);
      V v_exports_2455;
      switch (heff_tag_of(v_exports0_2444)) {
      case TAG_Nil: {
        V v_t_2452 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam6, 2, 1, (V[]){heff_dup(v_g_2443)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_g_2443, 0, 8); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        v_exports_2455 = (g_list_2emap_24s129316455x2072694707(v_t_2452));
        break;
      }
      case TAG_Cons: {
        heff_drop_rec(v_g_2443, 8);
        v_exports_2455 = v_exports0_2444;
        break;
      }
      default: heff_nomatch(v_exports0_2444);
      }
      V v_roots_2456 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_2455)));
      V v_roots_2457 = v_roots_2456;
      HeffT3 v_t_2458 = (g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(v_g_2445));
      V v_l_2474;
      {
        V v_field_2459 = v_t_2458.f[0];
        V v_field_2460 = v_t_2458.f[1];
        V v_field_2461 = v_t_2458.f[2];
        V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2459));
        V v_defs_2463 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2462; V r_ = (g_list_2efoldl_24s650566757x317183241(a_0, a_1, a_2)); heff_drop(v_t_2462); r_; });
        V v_t_2464 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2463));
        V v_reached_2465 = ({ V a_0 = v_t_2464; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_2457); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_2464); r_; });
        V v_t_2471 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam7, 1, 1, (V[]){v_reached_2465}), v_defs_2463));
        V v_si_2472 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(v_field_2461, v_t_2471));
        V v_t_2473 = (g_heff_2ecompile_2elower_2efusedOf(heff_dup(v_roots_2457), v_si_2472));
        v_l_2474 = (g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587(v_roots_2457, v_field_2460, v_t_2473));
      }
      V v_facts_2475 = heff_take_field(v_l_2474, 1);
      V v_defs_2476 = heff_take_field(v_l_2474, 0);
      V v_errors_2477 = heff_get_n(v_l_2474, 2, 3);
      V v_exports_2478 = heff_dup(v_exports_2455);
      V v_roots_2479 = (g_list_2emap_24s152505078x225062837(v_exports_2455));
      V v_t_2480 = (g_heff_2ecompile_2eemit_2eemitKept(v_facts_2475, v_defs_2476, v_roots_2479, heff_dup(g_std_2eordmap_2eempty_get())));
      V v_m_2481 = heff_get_n(v_t_2480, 0, 2);
      V v_lines_2482 = heff_take_field(v_m_2481, 0);
      V v_globals_2483 = heff_get_n(v_m_2481, 1, 2);
      V v_t_2484 = (g_list_2eany_24s331724893x1262243254(v_lines_2482));
      V v_t_2485;
      if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
        heff_drop(v_t_2484);
        v_t_2485 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2484);
        v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
      }
      V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str7), NTAG(TAG_Nil)});
      V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eextStr_get()), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str8), v_t_2486})});
      V v_t_2488 = (g_prelude_2e_2b_2b(v_t_2485, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str9), v_t_2487})));
      V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str10), NTAG(TAG_Nil)});
      V v_t_2495 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam8, 1, 1, (V[]){heff_dup(v_globals_2483)}), v_exports_2478));
      V v_t_24111 = (g_prelude_2e_2b_2b_24f58476578x2140998212(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str11), v_t_2489}), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam9, 1, 1, (V[]){v_globals_2483}), v_t_2495));
      V v_t_24112 = (g_prelude_2e_2b_2b(v_t_2488, v_t_24111));
      V v_t_24113 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str18); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str19); V a_2 = v_lines_2482; V a_3 = v_t_24112; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_lines_2482); heff_drop(v_t_24112); r_; });
      return ({ V a_0 = v_outPath_2430; V a_1 = v_t_2442; V a_2 = heff_rec_n(2, shape_source__errors, (V[]){v_t_24113, v_errors_2477}); V a_3 = v_hd_2433; V a_4 = v_k_2434; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2442); r_; });
    } else {
      heff_drop(v_cs_2432);
      heff_drop(v_badL_2431);
      heff_drop(v_outPath_2430);
      heff_drop(v_field_2438);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2433, v_k_2434));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_file_2420 = heff_env(self)[0];
  V v_outPath_2421 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_hd_2423 = heff_env(self)[3];
  V v_k_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_file_2429 = v_file_2420;
  heff_drop(v_file_2429);
  V v_outPath_2430 = v_outPath_2421;
  V v_badL_2431 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2426, 1));
  heff_drop(v_x_2426);
  V v_cs_2432 = heff_get_n(v_x_2428, 0, 2);
  V v_hd_2433 = v_hd_2423;
  V v_k_2434 = v_k_2424;
  return ({ V a_0 = v_cs_2432; V a_1 = heff_dup(v_hd_2433); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam5, 1, 5, (V[]){heff_dup(v_cs_2432), v_badL_2431, v_outPath_2430, v_hd_2433, v_k_2434}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_cs_2432); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_file_2420 = heff_env(self)[2];
  V v_outPath_2421 = heff_env(self)[3];
  V v_k_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2427 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_2425));
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_2423);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam4, 1, 5, (V[]){v_file_2420, v_outPath_2421, v_x_2426, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2423 = heff_env(self)[0];
  V v_file_2420 = heff_env(self)[1];
  V v_outPath_2421 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str5), heff_dup(heff_rfield(v_x_2425, 1)), MK_INT(0LL), heff_dup(v_hd_2423), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam3, 1, 5, (V[]){v_x_2425, v_hd_2423, v_file_2420, v_outPath_2421, v_k_2424})));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_file_2420 = heff_env(self)[1];
  V v_outPath_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam2, 1, 4, (V[]){v_hd_2423, v_file_2420, v_outPath_2421, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam11(V self, V *args) {
  V v_x_24125 = args[0];
  V v_hd_24115 = heff_env(self)[0];
  V v_k_24116 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24125);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_24115, v_k_24116));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam10(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_t_24117 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str20), NTAG(TAG_MkUnit)});
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24115, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24123})}));
  V f_ = heff_dup(heff_rfield(v_hd_24115, 1));
  args[0] = v_t_24124;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam11, 1, 2, (V[]){v_hd_24115, v_k_24116});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam13(V self, V *args) {
  V v_x_24146 = args[0];
  V v_str_24142 = heff_env(self)[0];
  V v_name_24126 = heff_env(self)[1];
  V v_outPath_24127 = heff_env(self)[2];
  V v_file_24128 = heff_env(self)[3];
  V v_hd_24144 = heff_env(self)[4];
  V v_k_24145 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24147 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24142, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str32)), NTAG(TAG_MkUnit)});
  V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
  V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
  V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
  V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
  V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
  V v_t_24153 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24152})});
  V v_t_24154 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24153})}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290(MK_INT(1LL), v_x_24146, v_name_24126, v_outPath_24127, v_file_24128, v_t_24154, v_hd_24144, v_k_24145));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam12(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_c_24143 = heff_env(self)[0];
  V v_str_24142 = heff_env(self)[1];
  V v_name_24126 = heff_env(self)[2];
  V v_outPath_24127 = heff_env(self)[3];
  V v_file_24128 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24143;
  args[0] = heff_dup(v_hd_24144);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam13, 1, 6, (V[]){v_str_24142, v_name_24126, v_outPath_24127, v_file_24128, v_hd_24144, v_k_24145});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam15(V self, V *args) {
  V v_x_24166 = args[0];
  V v_hd_24155 = heff_env(self)[0];
  V v_k_24156 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24166);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_24155, v_k_24156));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam14(V self, V *args) {
  V v_hd_24155 = args[0];
  V v_k_24156 = args[1];
  V v_backend_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24157 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str33), v_backend_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str34));
  V v_t_24158 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24157, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_str35)), NTAG(TAG_MkUnit)});
  V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
  V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
  V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
  V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
  V v_t_24163 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24162})});
  V v_t_24164 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})});
  V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24155, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24164})}));
  V f_ = heff_dup(heff_rfield(v_hd_24155, 1));
  args[0] = v_t_24165;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1204746891x2099828087_lam15, 1, 2, (V[]){v_hd_24155, v_k_24156});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam6(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1_clo)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    V v_c_2434 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam2, 3, 1, (V[]){v_path_247})));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam6, 2, 4, (V[]){v_c_2434, v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2425));
  return (g_std_2epath_2ejoin(v_path_247, v_t_2426));
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_z_2423 = args[1];
  V v_z_2424 = args[2];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2423);
  V v_x_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam4, 1, 1, (V[]){v_path_247}), v_x_2422));
  V v_x_2428 = (g_list_2emap_24s219049803x1458391381(v_x_2427));
  V f_ = v_z_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam5(V self, V *args) {
  V v_n_2430 = args[0];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2430));
  return (g_std_2epath_2ejoin(v_path_247, v_t_2431));
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_2418 = args[1];
  V v_z_2419 = args[2];
  V v_path_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2420})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2421, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3, 3, 1, (V[]){v_path_247}), v_z_2418, v_z_2419));
  }
  case TAG_Right: {
    V v_x_2429 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    heff_drop(v_z_2418);
    V v_x_2432 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam5, 1, 1, (V[]){v_path_247}), v_x_2429));
    V v_x_2433 = (g_list_2emap_24s219049803x1458391381(v_x_2432));
    V f_ = v_z_2419;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2433});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam8(V self, V *args) {
  V v_s_2444 = args[0];
  return v_s_2444;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam10(V self, V *args) {
  V v_n_2456 = args[0];
  V v_st_2454 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = (g_std_2epath_2eparse(heff_dup(v_st_2454), v_p_245));
  V v_t_2458 = (g_std_2epath_2eparse(heff_dup(v_st_2454), v_n_2456));
  V v_t_2459 = (g_std_2epath_2ejoin(v_t_2457, v_t_2458));
  return ({ V a_0 = v_st_2454; V a_1 = v_t_2459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2454); heff_drop(v_t_2459); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam9(V self, V *args) {
  V v_x_2453 = args[0];
  V v_y_2443 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_2435 = heff_env(self)[4];
  V v_k_2436 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2454;
  if (heff_strEq_c(v_x_2453, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str1))) {
    v_st_2454 = NTAG(TAG_Windows);
  } else {
    v_st_2454 = NTAG(TAG_Posix);
  }
  V v_t_2455 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str2); V a_3 = v_y_2443; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2460 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam10, 1, 2, (V[]){v_st_2454, v_p_245}), v_t_2455));
  V v_t_2461 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2460, v_acc_241));
  V f_ = v_t_2461;
  heff_room[0] = v_hd_2435;
  heff_room[1] = v_k_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_2435 = heff_env(self)[3];
  V v_k_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    heff_take_n(v_x_2437, 0ULL, 1);
    int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_p_245, 0)) - ((int64_t)3ULL));
    V v_t_2440 = heff_strSlice(heff_dup(v_p_245), heff_box_word(v_t_2439), heff_strLength_lent(v_p_245, 0));
    if (heff_strEq_c(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str0))) {
      V v_t_2441 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      V f_ = v_t_2441;
      heff_room[0] = v_hd_2435;
      heff_room[1] = v_k_2436;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_245);
      V v_t_2442 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_rest_246, v_acc_241));
      V f_ = v_t_2442;
      heff_room[0] = v_hd_2435;
      heff_room[1] = v_k_2436;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_y_2443 = heff_field(v_x_2437, 0);
    V v_ru_24x_2437_24Right = heff_take_reuse_n(v_x_2437, 1ULL, 1);
    V v_t_2445 = heff_tag_at_n(v_ru_24x_2437_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam8_clo)})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2435, 2)), 1, (V[]){v_t_2451}));
    V f_ = heff_dup(heff_rfield(v_hd_2435, 1));
    heff_room[0] = v_t_2452;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam9, 1, 6, (V[]){v_y_2443, v_rest_246, v_p_245, v_acc_241, v_hd_2435, v_k_2436});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2437);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam6(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2434;
  args[0] = heff_dup(v_hd_2435);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam7, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_2435, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str3, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str4, 10, "heff build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str5, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str6, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str7, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str8, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str9, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam20(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622(V v_st_240, V v_t_241, V v_bp_242, V v_x_243, V v_a_244, V v_next_245, V v_p_246, V v_p_247) {
top: ;
  V v_backend_248 = heff_take_field(v_a_244, 0);
  V v_run_249 = heff_get_n(v_a_244, 1, 3);
  if (heff_strEq_c(v_backend_248, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str0))) {
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam0_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){v_t_2412}));
    return heff_tail(heff_dup(heff_rfield(v_p_246, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam1, 1, 7, (V[]){v_p_246, v_st_240, v_t_241, v_x_243, v_next_245, v_run_249, v_p_247})});
  } else {
    V v_t_2443 = heff_dup(heff_rfield(v_t_241, 3));
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam9_clo)})});
      V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){v_t_2446}));
      return heff_tail(heff_dup(heff_rfield(v_p_246, 1)), 2, (V[]){v_t_2447, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam10, 1, 7, (V[]){v_p_246, v_st_240, v_t_241, v_x_243, v_run_249, v_next_245, v_p_247})});
    } else {
      heff_drop(v_st_240);
      heff_drop_rec(v_t_241, 6);
      heff_drop(v_run_249);
      heff_drop(v_t_2443);
      V v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str8), v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str9));
      V v_t_2486 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2485, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str10)), NTAG(TAG_MkUnit)});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})}));
      return heff_tail(heff_dup(heff_rfield(v_p_246, 1)), 2, (V[]){v_t_2493, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam20, 1, 4, (V[]){v_bp_242, v_p_246, v_next_245, v_p_247})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam2(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2427 = heff_env(self)[1];
  V v_k_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2429);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2427;
  heff_room[1] = v_k_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2414 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2414, heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam5, 1, 3, (V[]){v_next_245, v_hd_2427, v_k_2428})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_next_2437 = heff_env(self)[0];
  V v_hd_2440 = heff_env(self)[1];
  V v_k_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2442);
  V f_ = v_next_2437;
  heff_room[0] = v_hd_2440;
  heff_room[1] = v_k_2441;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam7(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_x_2419 = heff_env(self)[0];
  V v_next_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2419, heff_dup(v_hd_2440), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam8, 1, 3, (V[]){v_next_2437, v_hd_2440, v_k_2441})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_run_249 = heff_env(self)[0];
  V v_outPath_2421 = heff_env(self)[1];
  V v_file_2422 = heff_env(self)[2];
  V v_x_2419 = heff_env(self)[3];
  V v_next_2437 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290(MK_INT(1LL), v_x_2439, heff_tag_n(TAG_Just, 1, (V[]){v_run_249}), v_outPath_2421, v_file_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam7, 2, 2, (V[]){v_x_2419, v_next_2437}), v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_next_245 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_run_249 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2420 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_outPath_2421 = heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str2));
  V v_file_2422 = (g_heff_2ebuild_2ecommands_2eappFile(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str3)));
  V v_st_2423 = v_st_240;
  V v_t_2424 = v_t_241;
  V v_p_2425 = heff_dup(v_x_2414);
  V v_x_2426 = v_x_243;
  V v_next_2430 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam4, 2, 2, (V[]){v_x_2414, v_next_245});
  V v_dir_2431 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_2423), heff_dup(v_t_2424), heff_dup(v_x_2426)));
  V v_a_2432 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_2423), heff_dup(v_t_2424), heff_dup(v_x_2426)));
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_2423), v_a_2432));
  V v_t_2434 = (g_std_2epath_2eparse(heff_dup(v_st_2423), v_x_2426));
  V v_t_2435 = (g_std_2epath_2ejoin(v_t_2433, v_t_2434));
  V v_out_2436 = ({ V a_0 = v_st_2423; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2435); r_; });
  V v_next_2437 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s146330414x1966858918(MK_INT(1LL), heff_get_n(v_t_2424, 5, 6), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str4), v_st_2423, v_p_2425, v_dir_2431, v_out_2436, v_next_2430));
  V v_c_2438 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_2422)));
  V f_ = v_c_2438;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam6, 1, 7, (V[]){v_run_249, v_outPath_2421, v_file_2422, v_x_2419, v_next_2437, v_p_246, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_next_245 = heff_env(self)[4];
  V v_run_249 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){v_t_2417}));
  V f_ = heff_dup(heff_rfield(v_p_246, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam3, 1, 8, (V[]){v_st_240, v_t_241, v_x_243, v_x_2414, v_next_245, v_p_246, v_run_249, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam9(V self, V *args) {
  V v_t_2444 = args[0];
  return v_t_2444;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam11(V self, V *args) {
  V v_t_2449 = args[0];
  return v_t_2449;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam13(V self, V *args) {
  V v_r_2457 = args[0];
  return v_r_2457;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam15(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_x_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2469);
  V f_ = v_k_2470;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2468});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam14(V self, V *args) {
  V v_x_2465 = args[0];
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    V v_err_2466 = heff_field(v_x_2465, 0);
    V v_ru_24x_2465_24Left = heff_take_reuse_n(v_x_2465, 1ULL, 1);
    V v_t_2467 = heff_tag_at_n(v_ru_24x_2465_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2466})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2467));
  }
  case TAG_Right: {
    V v_x_2468 = heff_field(v_x_2465, 0);
    heff_take_n(v_x_2465, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam15, 2, 1, (V[]){v_x_2468});
  }
  default: return heff_nomatch(v_x_2465);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam19(V self, V *args) {
  V v_x_2483 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2480 = heff_env(self)[1];
  V v_k_2481 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2483);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2480;
  heff_room[1] = v_k_2481;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam18(V self, V *args) {
  V v_x_2482 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_hd_2480 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_k_2481 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2482);
  return (g_co_2eop_24s1531911654x724325922(v_x_2448, heff_dup(v_hd_2480), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam19, 1, 3, (V[]){v_next_245, v_hd_2480, v_k_2481})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam17(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k_2481 = args[1];
  V v_x_2453 = heff_env(self)[0];
  V v_x_2448 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s1531911654x724325922(v_x_2453, heff_dup(v_hd_2480), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam18, 1, 4, (V[]){v_x_2448, v_hd_2480, v_next_245, v_k_2481})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam16(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_run_249 = heff_env(self)[3];
  V v_x_2453 = heff_env(self)[4];
  V v_x_2448 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2472);
  V v_n_2473 = heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str6));
  V v_a_2474 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_t_2475 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_2474));
  V v_t_2476 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_2473));
  V v_t_2477 = (g_std_2epath_2ejoin(v_t_2475, v_t_2476));
  V v_t_2478 = ({ V a_0 = v_st_240; V a_1 = v_t_2477; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2477); r_; });
  V v_t_2479 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str7)));
  V v_t_2484 = ({ V b_0 = heff_tag_n(TAG_Just, 1, (V[]){v_run_249}); V a_1 = v_t_2478; V a_2 = v_t_2479; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam17, 2, 3, (V[]){v_x_2453, v_x_2448, v_next_245}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s417034440x782274981(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  V f_ = v_t_2484;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam12(V self, V *args) {
  V v_x_2453 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_run_249 = heff_env(self)[4];
  V v_x_2448 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_s_2454 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_path_2455 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2454));
  V v_t_2456 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2455; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2455); r_; });
  V v_a_2458 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2456, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam13_clo)});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
  V v_c_2471 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam14_clo)));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam16, 1, 9, (V[]){v_x_243, v_st_240, v_t_241, v_run_249, v_x_2453, v_x_2448, v_next_245, v_p_246, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam10(V self, V *args) {
  V v_x_2448 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_run_249 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2448), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_str5), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam11_clo)})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){v_t_2451}));
  V f_ = heff_dup(heff_rfield(v_p_246, 1));
  heff_room[0] = v_t_2452;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam12, 1, 8, (V[]){v_st_240, v_t_241, v_x_243, v_p_246, v_run_249, v_x_2448, v_next_245, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam21(V self, V *args) {
  V v_x_2495 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2495);
  V f_ = v_next_245;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam20(V self, V *args) {
  V v_x_2494 = args[0];
  V v_bp_242 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2494);
  return (g_co_2eop_24s1734868233x1940051977(v_bp_242, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s417826162x1425306622_lam21, 1, 3, (V[]){v_next_245, v_p_246, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str2, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str3, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam8(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    heff_drop(v_fresh_241);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_old_242));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1_clo)));
    return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3, 1, 5, (V[]){v_t_240, v_to_243, v_z_246, v_next_244, v_z_247})});
  } else {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_old_242));
    V v_to_2438 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_to_243)));
    V v_t_2439 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2437; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2437); r_; });
    V v_t_2440 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2438; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2438); r_; });
    V v_a_2442 = heff_tag_n(TAG_Move, 3, (V[]){v_t_2439, v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5_clo)});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    V v_c_2455 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6_clo)));
    return heff_tail(v_c_2455, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam8, 1, 4, (V[]){v_fresh_241, v_z_246, v_to_243, v_z_247})});
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam2, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2436);
  V f_ = v_next_244;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_strAppend(heff_get_n(v_t_240, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str0));
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str1));
  V v_t_2428 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2427, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
  V f_ = heff_dup(heff_rfield(v_z_246, 1));
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam4, 1, 3, (V[]){v_next_244, v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5(V self, V *args) {
  V v_r_2441 = args[0];
  return v_r_2441;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam7(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2453);
  V f_ = v_k_2454;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6(V self, V *args) {
  V v_x_2449 = args[0];
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Left: {
    V v_err_2450 = heff_field(v_x_2449, 0);
    V v_ru_24x_2449_24Left = heff_take_reuse_n(v_x_2449, 1ULL, 1);
    V v_t_2451 = heff_tag_at_n(v_ru_24x_2449_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2450})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2451));
  }
  case TAG_Right: {
    V v_x_2452 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam7, 2, 1, (V[]){v_x_2452});
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam9(V self, V *args) {
  V v_r_2459 = args[0];
  return v_r_2459;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam11(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_x_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2471);
  V f_ = v_k_2472;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2470});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam10(V self, V *args) {
  V v_x_2467 = args[0];
  switch (heff_tag_of(v_x_2467)) {
  case TAG_Left: {
    V v_err_2468 = heff_field(v_x_2467, 0);
    V v_ru_24x_2467_24Left = heff_take_reuse_n(v_x_2467, 1ULL, 1);
    V v_t_2469 = heff_tag_at_n(v_ru_24x_2467_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2468})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2469));
  }
  case TAG_Right: {
    V v_x_2470 = heff_field(v_x_2467, 0);
    heff_take_n(v_x_2467, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam11, 2, 1, (V[]){v_x_2470});
  }
  default: return heff_nomatch(v_x_2467);
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam13(V self, V *args) {
  V v_x_2485 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2485);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam12(V self, V *args) {
  V v_x_2474 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2474);
  V v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str2), v_fresh_241), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str3));
  V v_t_2476 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str4), heff_strAppend(v_t_2475, v_to_243));
  V v_t_2477 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2476, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str5)), NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_dup(heff_rfield(v_z_246, 1));
  heff_room[0] = v_t_2484;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam13, 1, 2, (V[]){v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2456);
  V v_path_2457 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_fresh_241)));
  V v_t_2458 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2457; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2457); r_; });
  V v_a_2460 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2458, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam9_clo)});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
  V v_c_2473 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam10_clo)));
  V f_ = v_c_2473;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam12, 1, 4, (V[]){v_fresh_241, v_to_243, v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}