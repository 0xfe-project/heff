// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_file 9638467
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_keep 9783372
#define LBL_launch 837298910
#define LBL_library 398066429
#define LBL_loaded 849622832
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_out 319944
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_paths 307797256
#define LBL_pending 1696753626
#define LBL_program 2069953735
#define LBL_renames 1324191545
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_update 1108295668
#define LBL_wrong 314763719
static uint32_t shape_at__pending__launch[] = {LBL_at, LBL_pending, LBL_launch};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_program__env[] = {LBL_program, LBL_env};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_clo;
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2eintegrationText(V, V);
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886(V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(V);
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused(V, V, V);
V g_heff_2ebuild_2ecommands_2ereachingRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereachingRefused_clo;
V g_heff_2ebuild_2ecommands_2erefusedReaching(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo;
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408_clo;
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_clo;
V g_heff_2ebuild_2ecommands_2etestDir(V, V);
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestDir_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914(V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656_clo;
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_clo;
V g_heff_2ebuild_2edriver_2eisTestOwn(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo;
V g_heff_2ebuild_2edriver_2erootsAmong(V, V);
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erootsAmong_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_clo;
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003(V);
V g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
HeffT2 g_list_2efind_24s814399109x689165205_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s417343796x227886918(V, V, V);
V g_list_2efoldl_24s417343796x227886918_entry(V self, V *a);
extern Clo g_list_2efoldl_24s417343796x227886918_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s654566231x1096033(V, V, V, V);
V g_list_2ekeepIf_24s654566231x1096033_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s654566231x1096033_clo;
V g_list_2emap_24s1750766838x1556198350(V, V, V);
V g_list_2emap_24s1750766838x1556198350_entry(V self, V *a);
extern Clo g_list_2emap_24s1750766838x1556198350_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str0, 23, "not known: there is no ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str1, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str2, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str3, 5, "heff ");

HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V v_path_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_f_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str0), v_path_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_Just: {
    V v_src_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_src_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_p_248 = v_field_246;
        V v_t_249 = (g_heff_2ebuild_2eload_2eproblemMsg(v_path_240, v_src_243, v_p_248));
        V v_f_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str1), v_t_249);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      } else {
        V v_x_2411 = v_field_246;
        HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_p_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2ebuild_2eload_2eproblemMsg(v_path_240, v_src_243, v_p_2416));
            V v_f_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str2), v_t_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
          } else {
            heff_drop(v_path_240);
            V v_p_2419 = v_field_2414;
            V v_f_2420 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_24cpr_str3), heff_get_n(v_p_2419, 1, 4));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2420}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str0, 4, "std.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str1, 81, "` is an effect of the system (lib/std/), for C: it has no provider for --backend=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erefusedReaching_str2, 1, "`");
Clo g_heff_2ebuild_2ecommands_2erefusedReaching_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erefusedReaching_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erefusedReaching(V v_host_240, V v_sources_241, V v_only_242, V v_s_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_s_243, 7));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_s_243, 0)), MK_INT(0LL), MK_INT(4LL));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str0))) {
      V v_t_247 = (g_list_2eany_24s2065989517x1307020881(heff_rfield(v_s_243, 0), v_only_242));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_sources_241);
        heff_drop(v_t_247);
        V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_243, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str1), v_host_240));
        V v_t_249 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_243, 0, 8), MK_INT(352LL), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2erefusedReaching_str2), v_t_248), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      } else {
        heff_drop(v_t_247);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_s_243, 0)), NTAG(TAG_Nil)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
        HeffT2 v_t_2412 = (g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(v_sources_241, v_only_242, NTAG(TAG_Nil), v_t_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2ebuild_2ecommands_2ereachingRefused(v_host_240, v_s_243, v_x_2416));
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
          } else {
            heff_drop(v_host_240);
            heff_drop_rec(v_s_243, 8);
            heff_drop(v_field_2414);
            return NTAG(TAG_Nothing);
          }
        }
      }
    } else {
      heff_drop(v_host_240);
      heff_drop(v_sources_241);
      heff_drop_rec(v_s_243, 8);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_host_240);
    heff_drop(v_sources_241);
    heff_drop_rec(v_s_243, 8);
    heff_drop(v_t_244);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ecommands_2erefusedReaching_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2erefusedReaching(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_str0, 45, "its file does not import check, which runs it");
V g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V v_p_240, V v_src_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_src_241, 6), heff_take_field(v_src_241, 4)));
  HeffT4 v_t_243 = ({ V b_0 = heff_get_n(v_src_241, 5, 8); V a_1 = v_t_242; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248;
  {
    V v_field_244 = v_t_243.f[0];
    heff_drop(v_t_243.f[1]);
    heff_drop(v_t_243.f[2]);
    heff_drop(v_t_243.f[3]);
    v_t_248 = v_field_244;
  }
  HeffT2 v_t_249 = (g_heff_2ebuild_2ecommands_2equalifierOf_24cpr(v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_q_2413 = v_field_2411;
      V v_l_2414 = heff_dup(heff_rfield(v_p_240, 5));
      V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_p_240, 6)), 0, 14);
      V v_c_2416 = heff_take_field(v_p_240, 6);
      V v_t_2418 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_2416)}), heff_dup(heff_rfield(v_c_2416, 7))));
      V v_t_2419 = (g_heff_2ebuild_2edriver_2erootsAmong(v_c_2416, v_t_2418));
      V v_t_2420 = (g_heff_2ebuild_2ecommands_2eintegrationText(v_q_2413, v_t_2419));
      V v_t_2421 = heff_get_n(heff_get_n(v_p_240, 5, 7), 0, 5);
      V v_sources_2422 = ({ V a_0 = v_t_2415; V a_1 = v_t_2420; V a_2 = v_t_2421; V r_ = (g_list_2emap_24s1750766838x1556198350(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
      V v_f_2423 = ({ V rv_0 = v_sources_2422; V rr_ = heff_rec_reuse_nf(v_l_2414, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2423}});
    } else {
      heff_drop_rec(v_p_240, 7);
      heff_drop(v_field_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_str0)}});
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr_lam0(V self, V *args) {
  V v_o_2417 = args[0];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_2416, v_o_2417));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str0, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str1, 19, ": integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str2, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str3, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str4, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str5, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str6, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str7, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str8, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str9, 9, "heff test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str11, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str12, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str13, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str14, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str15, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str16, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str17, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str18, 34, "its file is not among those loaded");
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam20(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam24(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam23(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502(V v_rep_240, V v_prog_241, V v_opts_242, V v_at_243, V v_p_244, V v_k_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_p_244, 5)), 0, 5);
  HeffT2 v_t_249 = (g_list_2efind_24s814399109x689165205_24cpr(heff_dup(v_p_244), v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_src_2413 = v_field_2411;
      HeffT2 v_t_2414 = (g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(heff_dup(v_p_244), v_src_2413));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop(v_prog_241);
          heff_drop(v_at_243);
          V v_why_2418 = v_field_2416;
          V v_more_2419 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str0), v_why_2418, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
          V v_t_2420 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_2419));
          V v_c_2421 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_2420));
          return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam0, 1, 6, (V[]){v_opts_242, v_k_245, v_z_246, v_z_247, v_rep_240, v_p_244})});
        } else {
          V v_l_2425 = v_field_2416;
          V v_t_2426 = heff_strAppend(heff_dup(heff_rfield(v_p_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str1));
          V v_t_2428 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2426, MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam2_clo)})}));
          return (g_co_2eop_24s615738393x1686646143(v_t_2428, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam3, 1, 9, (V[]){v_prog_241, v_z_246, v_l_2425, v_p_244, v_opts_242, v_k_245, v_rep_240, v_at_243, v_z_247})));
        }
      }
    } else {
      heff_drop(v_prog_241);
      heff_drop(v_at_243);
      heff_drop(v_field_2411);
      V v_more_24118 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str17), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str18), MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
      V v_t_24119 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_24118));
      V v_c_24120 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_24119));
      return heff_tail(v_c_24120, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam23, 1, 6, (V[]){v_opts_242, v_k_245, v_z_246, v_z_247, v_rep_240, v_p_244})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2424});
  heff_room[1] = v_z_246;
  heff_room[2] = v_z_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_2422)));
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_x_2422);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_2423);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_246;
    heff_room[2] = v_z_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2423);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_2422, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam1, 1, 3, (V[]){v_k_245, v_z_246, v_z_247})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam2(V self, V *args) {
  V v_t_2427 = args[0];
  return v_t_2427;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam4(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam9(V self, V *args) {
  V v_x_2466 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_2456 = heff_env(self)[1];
  V v_z_2457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2466});
  heff_room[1] = v_z_2456;
  heff_room[2] = v_z_2457;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_2456 = heff_env(self)[2];
  V v_z_2457 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2465 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_2464)));
  if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
    heff_drop(v_x_2464);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_2465);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_2456;
    heff_room[2] = v_z_2457;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2465);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_2464, heff_dup(v_z_2456), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam9, 1, 3, (V[]){v_k_245, v_z_2456, v_z_2457})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam7(V self, V *args) {
  V v_x_2460 = args[0];
  V v_why_2455 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_z_2456 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_z_2457 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2460);
  V v_more_2461 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str8), v_why_2455, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
  V v_t_2462 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_2461));
  V v_c_2463 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_2462));
  V f_ = v_c_2463;
  heff_room[0] = heff_dup(v_z_2456);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam8, 1, 6, (V[]){v_opts_242, v_k_245, v_z_2456, v_z_2457, v_rep_240, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam6(V self, V *args) {
  V v_why_2455 = args[0];
  V v_z_2456 = args[1];
  V v_z_2457 = args[2];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2458 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2458}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2459, heff_dup(v_z_2456), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam7, 1, 7, (V[]){v_why_2455, v_p_244, v_opts_242, v_z_2456, v_k_245, v_z_2457, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam15(V self, V *args) {
  V v_x_2480 = args[0];
  V v_x_2469 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2473 = heff_env(self)[2];
  V v_x_2470 = heff_env(self)[3];
  V v_x_2477 = heff_env(self)[4];
  V v_at_243 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_hd_2467 = heff_env(self)[8];
  V v_k_2468 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2480);
  V v_t_2484;
  switch (heff_tag_of(v_x_2469)) {
  case TAG_Left: {
    heff_take_n(v_x_2469, 0ULL, 1);
    v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str10);
    break;
  }
  case TAG_Right: {
    V v_real_2482 = heff_field(v_x_2469, 0);
    heff_take_n(v_x_2469, 1ULL, 1);
    V v_t_2483 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
    v_t_2484 = ({ V a_0 = v_t_2483; V a_1 = v_real_2482; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2483); heff_drop(v_real_2482); r_; });
    break;
  }
  default: heff_nomatch(v_x_2469);
  }
  V v_t_2488;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_Left: {
    heff_take_n(v_x_2473, 0ULL, 1);
    v_t_2488 = v_x_2470;
    break;
  }
  case TAG_Right: {
    V v_real_2486 = heff_field(v_x_2473, 0);
    heff_take_n(v_x_2473, 1ULL, 1);
    heff_drop(v_x_2470);
    V v_t_2487 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
    v_t_2488 = ({ V a_0 = v_t_2487; V a_1 = v_real_2486; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2487); heff_drop(v_real_2486); r_; });
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_t_2492;
  switch (heff_tag_of(v_x_2477)) {
  case TAG_Left: {
    heff_take_n(v_x_2477, 0ULL, 1);
    v_t_2492 = heff_get_n(heff_get_n(v_l_2425, 2, 5), 0, 6);
    break;
  }
  case TAG_Right: {
    V v_real_2490 = heff_field(v_x_2477, 0);
    heff_take_n(v_x_2477, 1ULL, 1);
    V v_t_2491 = heff_get_n(heff_get_n(v_l_2425, 2, 5), 5, 6);
    v_t_2492 = ({ V a_0 = v_t_2491; V a_1 = v_real_2490; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2491); heff_drop(v_real_2490); r_; });
    break;
  }
  default: heff_nomatch(v_x_2477);
  }
  V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str11), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str12)}), NTAG(TAG_Nil)});
  V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str13), v_t_2492}), v_t_2493});
  V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str14), v_t_2488}), v_t_2494});
  V v_t_2496 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_243, v_p_244, heff_rec_n(2, shape_program__env, (V[]){v_t_2484, v_t_2495})});
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_2496});
  heff_room[1] = v_hd_2467;
  heff_room[2] = v_k_2468;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam14(V self, V *args) {
  V v_x_2477 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2467 = heff_env(self)[2];
  V v_x_2469 = heff_env(self)[3];
  V v_l_2425 = heff_env(self)[4];
  V v_x_2473 = heff_env(self)[5];
  V v_x_2470 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_p_244 = heff_env(self)[8];
  V v_k_245 = heff_env(self)[9];
  V v_k_2468 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2478 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2478}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2479, heff_dup(v_hd_2467), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam15, 1, 10, (V[]){v_x_2469, v_l_2425, v_x_2473, v_x_2470, v_x_2477, v_at_243, v_p_244, v_k_245, v_hd_2467, v_k_2468})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam13(V self, V *args) {
  V v_x_2473 = args[0];
  V v_l_2425 = heff_env(self)[0];
  V v_hd_2467 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2469 = heff_env(self)[4];
  V v_x_2470 = heff_env(self)[5];
  V v_at_243 = heff_env(self)[6];
  V v_p_244 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  V v_k_2468 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2474 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 0, 6);
  V v_t_2475 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_t_2474; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2476 = ({ V a_0 = v_t_2475; V r_ = heff_tr(g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003(a_0)); heff_drop(v_t_2475); r_; });
  V f_ = v_c_2476;
  heff_room[0] = heff_dup(v_hd_2467);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam14, 1, 11, (V[]){v_x_2429, v_prog_241, v_hd_2467, v_x_2469, v_l_2425, v_x_2473, v_x_2470, v_at_243, v_p_244, v_k_245, v_k_2468});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam12(V self, V *args) {
  V v_x_2470 = args[0];
  V v_hd_2467 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_x_2469 = heff_env(self)[4];
  V v_at_243 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  V v_k_2468 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2471 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2470); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2472 = ({ V a_0 = v_t_2471; V r_ = heff_tr(g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003(a_0)); heff_drop(v_t_2471); r_; });
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_2467);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam13, 1, 10, (V[]){v_l_2425, v_hd_2467, v_x_2429, v_prog_241, v_x_2469, v_x_2470, v_at_243, v_p_244, v_k_245, v_k_2468});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam11(V self, V *args) {
  V v_x_2469 = args[0];
  V v_hd_2467 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_at_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_k_2468 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_2467), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam12, 1, 9, (V[]){v_hd_2467, v_l_2425, v_x_2429, v_prog_241, v_x_2469, v_at_243, v_p_244, v_k_245, v_k_2468})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam10(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_c_2452 = heff_env(self)[0];
  V v_l_2425 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_at_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2452;
  args[0] = heff_dup(v_hd_2467);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam11, 1, 8, (V[]){v_hd_2467, v_l_2425, v_x_2429, v_prog_241, v_at_243, v_p_244, v_k_245, v_k_2468});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam20(V self, V *args) {
  V v_x_24114 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_24101 = heff_env(self)[1];
  V v_z_24102 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24114});
  heff_room[1] = v_z_24101;
  heff_room[2] = v_z_24102;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam19(V self, V *args) {
  V v_x_24112 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_24101 = heff_env(self)[2];
  V v_z_24102 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24113 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_24112)));
  if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
    heff_drop(v_x_24112);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_24113);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_24101;
    heff_room[2] = v_z_24102;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24113);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_24112, heff_dup(v_z_24101), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam20, 1, 3, (V[]){v_k_245, v_z_24101, v_z_24102})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam18(V self, V *args) {
  V v_x_24108 = args[0];
  V v_why_24100 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_z_24101 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_z_24102 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24108);
  V v_more_24109 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str15), v_why_24100, MK_INT(0LL), heff_dup(heff_rfield(v_p_244, 4))));
  V v_t_24110 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_244, 3)), v_more_24109));
  V v_c_24111 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(heff_rfield(v_opts_242, 3), heff_dup(heff_rfield(v_p_244, 0)), v_t_24110));
  V f_ = v_c_24111;
  heff_room[0] = heff_dup(v_z_24101);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam19, 1, 6, (V[]){v_opts_242, v_k_245, v_z_24101, v_z_24102, v_rep_240, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam17(V self, V *args) {
  V v_x_24105 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_24101 = heff_env(self)[2];
  V v_why_24100 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_z_24102 = heff_env(self)[7];
  V v_rep_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_24105);
  V v_t_24106 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_24107 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_24106}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24107, heff_dup(v_z_24101), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam18, 1, 7, (V[]){v_why_24100, v_p_244, v_opts_242, v_z_24101, v_k_245, v_z_24102, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam16(V self, V *args) {
  V v_why_24100 = args[0];
  V v_z_24101 = args[1];
  V v_z_24102 = args[2];
  V v_x_2432 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_24103 = heff_tag_n(TAG_End, 2, (V[]){v_x_2432, NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_24103}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24104, heff_dup(v_z_24101), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam17, 1, 9, (V[]){v_x_2429, v_prog_241, v_z_24101, v_why_24100, v_p_244, v_opts_242, v_k_245, v_z_24102, v_rep_240})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam22(V self, V *args) {
  V v_x_24117 = args[0];
  V v_next_2497 = heff_env(self)[0];
  V v_hd_24115 = heff_env(self)[1];
  V v_k_24116 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24117);
  V f_ = v_next_2497;
  heff_room[0] = v_hd_24115;
  heff_room[1] = v_k_24116;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam21(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_t_2499 = heff_env(self)[0];
  V v_next_2497 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2499, heff_dup(v_hd_24115), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam22, 1, 3, (V[]){v_next_2497, v_hd_24115, v_k_24116})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_l_2425 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_z_246 = heff_env(self)[8];
  V v_z_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2433 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_dir_2434 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_d_2435 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_st_2436 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, v_d_2435));
  V v_t_2438 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2439;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_Posix: {
    v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str3);
    break;
  }
  case TAG_Windows: {
    v_t_2439 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str4);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2440 = (g_std_2epath_2eparse(v_st_2436, v_t_2439));
  V v_t_2441 = (g_std_2epath_2ejoin(v_t_2437, v_t_2440));
  V v_out_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); heff_drop(v_t_2441); r_; });
  V v_d_2443 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2425, 2)), heff_dup(heff_rfield(v_p_244, 0))));
  V v_st_2444 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2445 = (g_std_2epath_2eparse(v_st_2444, v_d_2443));
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2447;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_Posix: {
    v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str5);
    break;
  }
  case TAG_Windows: {
    v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str6);
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_t_2448 = (g_std_2epath_2eparse(v_st_2444, v_t_2447));
  V v_t_2449 = (g_std_2epath_2ejoin(v_t_2445, v_t_2448));
  V v_s_2450 = ({ V a_0 = v_st_2444; V a_1 = v_t_2449; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2449); r_; });
  V v_t_2451 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2450; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2452 = ({ V a_0 = v_t_2451; V r_ = heff_tr(g_heff_2eutil_2efiles_2erealPath_24s890079819x1866690003(a_0)); heff_drop(v_t_2451); r_; });
  V v_t_2453 = heff_get_n(heff_dup(heff_rfield(v_l_2425, 2)), 5, 6);
  V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str7), NTAG(TAG_Nil)});
  V v_next_2497 = ({ V a_0 = heff_dup(v_prog_241); V a_1 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam6, 3, 6, (V[]){heff_dup(v_x_2429), heff_dup(v_prog_241), heff_dup(v_p_244), heff_dup(v_opts_242), heff_dup(v_k_245), heff_dup(v_rep_240)}); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str9); V a_3 = v_t_2453; V a_4 = v_t_2454; V a_5 = heff_dup(v_x_2429); V a_6 = v_dir_2434; V a_7 = v_out_2442; V a_8 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam10, 2, 7, (V[]){v_c_2452, heff_dup(v_l_2425), heff_dup(v_x_2429), heff_dup(v_prog_241), v_at_243, heff_dup(v_p_244), heff_dup(v_k_245)}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2453); r_; });
  V v_t_2498 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2432), NTAG(TAG_MkUnit)});
  V v_t_2499 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2498}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558(heff_dup(v_rep_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam16, 3, 7, (V[]){v_x_2432, v_prog_241, v_x_2429, heff_dup(v_p_244), v_opts_242, v_k_245, v_rep_240}), v_l_2425, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get())}), heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str16)), heff_get_n(v_p_244, 0, 7), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam21, 2, 2, (V[]){v_t_2499, v_next_2497}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_l_2425 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_at_243 = heff_env(self)[7];
  V v_z_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2429), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_str2), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam4_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2431, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam5, 1, 10, (V[]){v_l_2425, v_p_244, v_prog_241, v_x_2429, v_opts_242, v_k_245, v_rep_240, v_at_243, v_z_246, v_z_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam24(V self, V *args) {
  V v_x_24123 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24123});
  heff_room[1] = v_z_246;
  heff_room[2] = v_z_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam23(V self, V *args) {
  V v_x_24121 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24122 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_242, heff_dup(v_x_24121)));
  if ((heff_dup(v_t_24122) == NTAG(TAG_True))) {
    heff_drop(v_x_24121);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_244, 7);
    heff_drop(v_t_24122);
    V f_ = v_k_245;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_246;
    heff_room[2] = v_z_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24122);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(v_rep_240, heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_get_n(v_p_244, 2, 7), v_x_24121, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502_lam24, 1, 3, (V[]){v_k_245, v_z_246, v_z_247})));
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623(V v_rep_240, V v_prog_241, V v_rx_242, V v_ex_243, V v_tk_244, V v_opts_245, V v_x3_246, V v_acc_247, V v_ready_248, V v_z_249, V v_z_2410) {
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    V v_t_2411 = heff_tag_n(TAG_End, 2, (V[]){v_tk_244, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2411}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2412, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam0, 1, 9, (V[]){v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_opts_245, v_ready_248, v_acc_247, v_z_249, v_z_2410})));
  }
  case TAG_Cons: {
    V v_f_2416 = heff_field(v_x3_246, 0);
    V v_rest_2417 = heff_field(v_x3_246, 1);
    heff_take_n(v_x3_246, 3ULL, 2);
    V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_tk_244), heff_dup(v_f_2416), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam2_clo)})}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2419, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam3, 1, 12, (V[]){v_rep_240, v_opts_245, v_f_2416, v_z_249, v_ready_248, v_prog_241, v_acc_247, v_rx_242, v_ex_243, v_tk_244, v_rest_2417, v_z_2410})));
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_opts_245 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2etestSummary_24s765472471x1941831733(v_opts_245, v_x_2415, v_z_249, v_z_2410));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_rx_242 = heff_env(self)[2];
  V v_ex_243 = heff_env(self)[3];
  V v_opts_245 = heff_env(self)[4];
  V v_ready_248 = heff_env(self)[5];
  V v_acc_247 = heff_env(self)[6];
  V v_z_249 = heff_env(self)[7];
  V v_z_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2413);
  V v_c_2414 = (g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770(v_rep_240, v_prog_241, v_rx_242, v_ex_243, heff_dup(v_opts_245), v_ready_248, v_acc_247));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam1, 1, 3, (V[]){v_opts_245, v_z_249, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam2(V self, V *args) {
  V v_t_2418 = args[0];
  return v_t_2418;
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_pr_2424 = heff_env(self)[0];
  V v_acc_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_rx_242 = heff_env(self)[4];
  V v_ex_243 = heff_env(self)[5];
  V v_tk_244 = heff_env(self)[6];
  V v_opts_245 = heff_env(self)[7];
  V v_rest_2417 = heff_env(self)[8];
  V v_ready_248 = heff_env(self)[9];
  V v_hd_2427 = heff_env(self)[10];
  V v_k_2428 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2429);
  switch (heff_tag_of(v_pr_2424)) {
  case TAG_Done: {
    V v_r_2430 = heff_field(v_pr_2424, 0);
    heff_take_n(v_pr_2424, 1ULL, 1);
    V v_t_2431 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_247, v_r_2430));
    return (g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623(v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_t_2431, v_ready_248, v_hd_2427, v_k_2428));
  }
  case TAG_Later: {
    V v_r_2432 = heff_field(v_pr_2424, 0);
    heff_take_n(v_pr_2424, 1ULL, 1);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2432, NTAG(TAG_Nil)});
    V v_t_2434 = (g_prelude_2e_2b_2b(v_ready_248, v_t_2433));
    return (g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623(v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_acc_247, v_t_2434, v_hd_2427, v_k_2428));
  }
  default: return heff_nomatch(v_pr_2424);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam6(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_t_2426 = heff_env(self)[0];
  V v_pr_2424 = heff_env(self)[1];
  V v_acc_247 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_rx_242 = heff_env(self)[5];
  V v_ex_243 = heff_env(self)[6];
  V v_tk_244 = heff_env(self)[7];
  V v_opts_245 = heff_env(self)[8];
  V v_rest_2417 = heff_env(self)[9];
  V v_ready_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  return (g_co_2eop_24s615738393x1686646143(v_t_2426, heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam7, 1, 12, (V[]){v_pr_2424, v_acc_247, v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_ready_248, v_hd_2427, v_k_2428})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam5(V self, V *args) {
  V v_pr_2424 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_acc_247 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_rx_242 = heff_env(self)[4];
  V v_ex_243 = heff_env(self)[5];
  V v_tk_244 = heff_env(self)[6];
  V v_opts_245 = heff_env(self)[7];
  V v_rest_2417 = heff_env(self)[8];
  V v_ready_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2425}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam6, 2, 11, (V[]){v_t_2426, v_pr_2424, v_acc_247, v_rep_240, v_prog_241, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_ready_248});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam9(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_2435 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2435;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2443});
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_opts_245 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_z_2410 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_p_2437 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2442 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_245, heff_dup(v_x_2441)));
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_x_2441);
    heff_drop(v_rep_240);
    heff_drop_rec(v_p_2437, 7);
    heff_drop(v_t_2442);
    V f_ = v_k_2435;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_249;
    heff_room[2] = v_z_2410;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2442);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s615201233x1268985656(v_rep_240, heff_dup(heff_rfield(v_p_2437, 0)), heff_dup(heff_rfield(v_p_2437, 1)), heff_get_n(v_p_2437, 2, 7), v_x_2441, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam9, 1, 3, (V[]){v_k_2435, v_z_249, v_z_2410})));
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_ready_248 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_acc_247 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_rx_242 = heff_env(self)[5];
  V v_ex_243 = heff_env(self)[6];
  V v_tk_244 = heff_env(self)[7];
  V v_opts_245 = heff_env(self)[8];
  V v_rest_2417 = heff_env(self)[9];
  V v_z_249 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_at_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ready_248));
  V v_k_2435 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam5, 1, 10, (V[]){v_x_2420, heff_dup(v_prog_241), v_acc_247, heff_dup(v_rep_240), v_rx_242, v_ex_243, v_tk_244, heff_dup(v_opts_245), v_rest_2417, v_ready_248});
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Settled: {
    V v_r_2436 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    heff_drop(v_prog_241);
    heff_drop(v_rep_240);
    heff_drop_rec(v_opts_245, 4);
    heff_drop(v_at_2423);
    V f_ = v_k_2435;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_r_2436});
    heff_room[1] = v_z_249;
    heff_room[2] = v_z_2410;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Pend: {
    V v_p_2437 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    V v_t_2438 = heff_dup(heff_rfield(v_p_2437, 4));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nil: {
      heff_drop(v_prog_241);
      heff_drop(v_at_2423);
      V v_t_2439 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_2437, 3)), NTAG(TAG_Nil)));
      V v_c_2440 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(heff_rfield(v_opts_245, 3), heff_dup(heff_rfield(v_p_2437, 0)), v_t_2439));
      V f_ = v_c_2440;
      heff_room[0] = heff_dup(v_z_249);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam8, 1, 6, (V[]){v_opts_245, v_k_2435, v_z_249, v_z_2410, v_rep_240, v_p_2437});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2438, 0ULL, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1383197926x1593234502(v_rep_240, v_prog_241, v_opts_245, v_at_2423, v_p_2437, v_k_2435, v_z_249, v_z_2410));
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_245 = heff_env(self)[1];
  V v_f_2416 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_ready_248 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_acc_247 = heff_env(self)[6];
  V v_rx_242 = heff_env(self)[7];
  V v_ex_243 = heff_env(self)[8];
  V v_tk_244 = heff_env(self)[9];
  V v_rest_2417 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_c_2421 = (g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914(v_rep_240, heff_dup(v_opts_245), v_f_2416));
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_lam4, 1, 12, (V[]){v_ready_248, v_x_2420, v_prog_241, v_acc_247, v_rep_240, v_rx_242, v_ex_243, v_tk_244, v_opts_245, v_rest_2417, v_z_249, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str4, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str7, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str9, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str11, 1, "\012");
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886(V v_prog_240, V v_path_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str0), heff_dup(v_path_241)), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam0_clo)});
  V v_t_244 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_243}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam1, 2, 3, (V[]){v_t_244, v_path_241, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam3(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_take_field(v_x_2423, 0);
  V v_t_2431;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Exited: {
    V v_n_2428 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2431 = heff_bool(!heff_intEq_c_lent(v_n_2428, MK_INT(0LL), 2));
    heff_drop(v_n_2428);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2427, 0ULL, 1);
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V v_x_2442;
  if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
    heff_drop(v_t_2431);
    V v_t_2432 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
    V v_s_2433 = heff_get_n(v_x_2423, 2, 3);
    V v_t_2434 = (g_prelude_2eskipSpaces(v_s_2433, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_s_2433, 0)) - ((int64_t)1ULL));
    V v_t_2436 = (g_prelude_2eskipSpaces(v_s_2433, heff_box_word(v_t_2435), MK_INT(-1LL)));
    V v_t_2437 = heff_strSlice(v_s_2433, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str7), v_t_2432), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str8), v_t_2437));
    v_x_2442 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str9), v_t_2438)});
  } else {
    heff_drop(v_t_2431);
    V v_s_2439 = heff_get_n(v_x_2423, 1, 3);
    V v_t_2440 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str10); V a_1 = v_s_2439; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str11), v_s_2439, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2439); r_; });
    V v_t_2441 = ({ V a_0 = v_path_241; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2440; V r_ = (g_list_2efoldl_24s417343796x227886918(a_0, a_1, a_2)); heff_drop(v_t_2440); r_; });
    v_x_2442 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2441});
  }
  V f_ = v_k_246;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2424}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2425, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam5, 1, 3, (V[]){v_x_2423, v_path_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str1), v_t_248), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str3), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str4), v_t_2410});
  V v_t_2412 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str5);
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2414 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_str6), v_t_2411, v_t_2413, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2416 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam3_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam4, 1, 5, (V[]){v_x_247, v_prog_240, v_hd_245, v_path_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_t_244 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s615738393x1686646143(v_t_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s84426448x1507457886_lam2, 1, 4, (V[]){v_path_241, v_hd_245, v_prog_240, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_p_245); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_248 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_247));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1, 2, 4, (V[]){v_c_248, v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  return v_s_2418;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam5(V self, V *args) {
  V v_n_2430 = args[0];
  V v_st_2428 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = (g_std_2epath_2eparse(v_st_2428, v_p_245));
  V v_t_2432 = (g_std_2epath_2eparse(v_st_2428, v_n_2430));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  return ({ V a_0 = v_st_2428; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2428); heff_drop(v_t_2433); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_ns_2417 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2428;
  if (heff_strEq_c(v_x_2426, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str1))) {
    v_st_2428 = NTAG(TAG_Windows);
  } else {
    v_st_2428 = NTAG(TAG_Posix);
  }
  V v_t_2429 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str2); V a_3 = v_ns_2417; V r_ = (g_list_2ekeepIf_24s654566231x1096033(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
  V v_t_2434 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam5, 1, 2, (V[]){v_st_2428, v_p_245}), v_t_2429));
  V v_t_2435 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2434, v_acc_241));
  V f_ = v_t_2435;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_p_245, 0)) - ((int64_t)3ULL));
    V v_t_2413 = heff_strSlice(heff_dup(v_p_245), heff_box_word(v_t_2412), heff_strLength_lent(v_p_245, 0));
    if (heff_strEq_c(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_str0))) {
      V v_t_2415 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      V f_ = v_t_2415;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_245);
      V v_t_2416 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_rest_246, v_acc_241));
      V f_ = v_t_2416;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2417 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Just = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2419 = heff_tag_at_n(v_ru_24x_2411_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam3_clo)})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s615738393x1686646143(v_t_2425, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam4, 1, 6, (V[]){v_ns_2417, v_rest_246, v_p_245, v_acc_241, v_hd_249, v_k_2410})));
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_lam2, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(V v_rep_240, V v_prog_241, V v_chk_242, V v_acc_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_chk_242);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam0, 2, 1, (V[]){v_acc_243});
  }
  case TAG_Cons: {
    V v_f_247 = heff_field(v_x3_244, 0);
    V v_rest_248 = heff_field(v_x3_244, 1);
    V v_c_249 = (g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092(heff_dup(v_rep_240), heff_dup(v_prog_241), heff_dup(v_chk_242), v_acc_243, heff_dup(v_f_247)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam1, 2, 5, (V[]){v_c_249, v_rep_240, v_prog_241, v_chk_242, heff_dup(v_rest_248)});
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_chk_242 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_chk_242; V a_3 = v_x_2412; V a_4 = v_rest_248; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_248); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_chk_242 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s632929488x1890279333_lam2, 1, 6, (V[]){v_rep_240, v_prog_241, v_chk_242, v_rest_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_progs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_str0)));
  V v_t_248 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_str1)));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_p_2410 = ({ V a_0 = v_st_242; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_std_2epath_2eparse(v_st_242, heff_dup(heff_rfield(v_t_243, 0))));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_242, v_p_2410));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_s_2414 = ({ V a_0 = v_st_242; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2414; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_2415); r_; });
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam0, 1, 7, (V[]){v_progs_244, v_prog_241, v_z_245, heff_dup(v_st_242), v_t_243, v_rep_240, v_z_246})});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam1(V self, V *args) {
  V v_t_2419 = args[0];
  return v_t_2419;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_next_2423 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V f_ = v_next_2423;
  heff_room[0] = v_hd_2426;
  heff_room[1] = v_k_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_t_2425 = heff_env(self)[0];
  V v_next_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2425, heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam4, 1, 3, (V[]){v_next_2423, v_hd_2426, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_t_243 = heff_env(self)[2];
  V v_progs_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2422 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1618665758x903008408(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), heff_dup(v_progs_244), heff_rfield(v_t_243, 4)));
  V v_next_2423 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s1743980705x1259201650(heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), v_t_2422, v_progs_244));
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2421), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2424}));
  V v_t_2429 = ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_242; V a_3 = v_t_243; V a_4 = v_x_2421; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam3, 2, 2, (V[]){v_t_2425, v_next_2423}); V a_6 = v_progs_244; V r_ = (g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_242); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2429;
  heff_room[0] = v_z_245;
  heff_room[1] = v_z_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2417);
  V v_total_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_str2), v_total_2418, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam1_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2420, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s805612547x936891240_lam2, 1, 7, (V[]){v_prog_241, v_st_242, v_t_243, v_progs_244, v_rep_240, v_z_245, v_z_246})));
}