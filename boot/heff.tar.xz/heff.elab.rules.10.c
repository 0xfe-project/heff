// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CUndelay 45232
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IntNum 31256
#define TAG_Left 13886
#define TAG_MentionsError 719
#define TAG_MkChk 56962
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SLitFloat 3938
#define TAG_SLitInt 21439
#define TAG_Trace 9637
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_chk 308000
#define LBL_ctx 308385
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_instantiated 552850723
#define LBL_insts 301719303
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_names 305943394
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_span 10032145
#define LBL_state 311115947
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_val 326043
#define LBL_witness 1587180415
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2ecommitted(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecommitted_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2eescapeAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eescapeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eescapeAt_clo;
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2egivenTwice(V, V);
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenTwice_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2emisfit(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_clo;
V g_heff_2eelab_2erules_2enameAtGo(V, V);
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enameAtGo_clo;
V g_heff_2eelab_2erules_2enestedField(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enestedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enestedField_clo;
V g_heff_2eelab_2erules_2enotFunctionMsg(V);
V g_heff_2eelab_2erules_2enotFunctionMsg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotFunctionMsg_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2enumLitDefault(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitDefault_clo;
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2eplainMismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eplainMismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplainMismatch_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordFormation(V);
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordFormation_clo;
V g_heff_2eelab_2erules_2erecordNameOf(V, V, V, V);
V g_heff_2eelab_2erules_2erecordNameOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordNameOf_clo;
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordUpdate(V, V, V, V);
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordUpdate_clo;
V g_heff_2eelab_2erules_2eresourceEscapes(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresourceEscapes_clo;
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V);
V g_heff_2eelab_2erules_2eupdateOf(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateOf_clo;
V g_heff_2eelab_2erules_2eupdateSetting(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateSetting_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2efilter_24s1966236437x1225976932(V, V);
V g_list_2efilter_24s1966236437x1225976932_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966236437x1225976932_clo;
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str1, 3, " : ");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str2, 6, "found ");
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ecommitted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_lam0, 1, 0};
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecommitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_entry, 8, 0};

V g_heff_2eelab_2erules_2ecommitted(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_fit_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2ecommitted_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam1, 1, 8, (V[]){v_fit_245, v_hd_246, v_e_240, v_hm_242, v_holeVal_243, v_sp_241, v_k_247, v_goal_244})});
}
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecommitted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args) {
  V v_u_2429 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2429);
  V v_t_2430 = heff_get_n(heff_get_n(v_fit_245, 0, 3), 0, 6);
  V v_t_2431 = heff_tr(heff_call(v_t_2430, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2432 = ({ V a_0 = v_e_240; V a_1 = v_x_2412; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  V v_t_2433 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2eelab_2erules_2ecommitted_str1), v_t_2432));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2ecommitted_str2), v_t_2433);
}
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_fit_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V f_ = v_k_247;
  args[0] = heff_get_n(v_fit_245, 1, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_fit_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_goal_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_err_2427 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_goal_244);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = heff_get_n(v_fit_245, 0, 3); V a_3 = v_err_2427; V a_4 = v_hd_246; V a_5 = v_k_247; V r_ = (g_heff_2eelab_2erules_2emisfit(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_err_2427); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2426, 0ULL, 1);
    V v_t_2434 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2ecommitted_str0), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam4, 1, 4, (V[]){heff_dup(v_fit_245), v_e_240, v_x_2412, v_goal_244})}), NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2435;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam5, 1, 2, (V[]){v_k_247, v_fit_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hm_242 = heff_env(self)[2];
  V v_holeVal_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_goal_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_fit_245, 1)), 0, 3);
  V v_x1_2418 = heff_tr(heff_call(heff_get_n(v_t_2417, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_t_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_c_2423 = heff_dup(heff_rfield(v_e_240, 0));
  V v_t_2424 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2423, 0), heff_get_n(v_c_2423, 1, 4)});
  V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_fit_245, 1)), 0, 3);
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), v_t_2424, v_hm_242, v_holeVal_243, heff_get_n(v_t_2425, 0, 2), v_t_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam3, 1, 7, (V[]){v_e_240, v_sp_241, v_fit_245, v_hd_246, v_k_247, v_x_2412, v_goal_244})));
}
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_fit_245 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hm_242 = heff_env(self)[3];
  V v_holeVal_243 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_goal_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_Put, 2, (V[]){heff_dup(heff_rfield(v_fit_245, 2)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam2, 1, 9, (V[]){v_fit_245, v_e_240, v_hm_242, v_holeVal_243, v_hd_246, v_sp_241, v_k_247, v_x_2412, v_goal_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2enotFunctionMsg_str0, 4, "#arg");
HEFF_LIT(g_heff_2eelab_2erules_2enotFunctionMsg_str1, 70, "` takes no argument: a definition of a `mutual` block is a function, `");
HEFF_LIT(g_heff_2eelab_2erules_2enotFunctionMsg_str2, 10, " : A -> B`");
HEFF_LIT(g_heff_2eelab_2erules_2enotFunctionMsg_str3, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2enotFunctionMsg_str4, 57, "tried to check a lambda expression at a non-function type");
Clo g_heff_2eelab_2erules_2enotFunctionMsg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotFunctionMsg_entry, 1, 0};

V g_heff_2eelab_2erules_2enotFunctionMsg(V v_x_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)4ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_x_240), heff_box_word(v_t_241), heff_strLength_lent(v_x_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2eelab_2erules_2enotFunctionMsg_str0))) {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)4ULL));
    V v_f_245 = heff_strSlice_lent(v_x_240, MK_INT(0LL), heff_box_word(v_t_244), 6);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotFunctionMsg_str1), heff_strAppend(heff_dup(v_f_245), ((V)&g_heff_2eelab_2erules_2enotFunctionMsg_str2)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2enotFunctionMsg_str3), heff_strAppend(v_f_245, v_t_246));
  } else {
    return ((V)&g_heff_2eelab_2erules_2enotFunctionMsg_str4);
  }
}
V g_heff_2eelab_2erules_2enotFunctionMsg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2enotFunctionMsg(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroAnn_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionIntroAnn(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(v_sp_240, v_x_241, v_dom_242, v_body_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_245});
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2efunctionIntroAnn(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eescapeAt_str0, 16, "the type names `");
HEFF_LIT(g_heff_2eelab_2erules_2eescapeAt_str1, 27, "` outside where it is bound");
Clo g_heff_2eelab_2erules_2eescapeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eescapeAt_entry, 7, 0};

V g_heff_2eelab_2erules_2eescapeAt(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_err_244, V v_l_245, V v_x7_246) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_err_244)) {
    case TAG_UnequalTys: {
      heff_drop(v_l_245);
      V v_t_2410 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2410});
    }
    case TAG_UnequalEls: {
      heff_drop(v_l_245);
      V v_t_2414 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2414});
    }
    case TAG_UnequalNeus: {
      heff_drop(v_l_245);
      V v_t_2420 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2420});
    }
    case TAG_MentionsError: {
      heff_drop(v_l_245);
      V v_t_2421 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2421});
    }
    case TAG_Escapes: {
      V v_sc_2423 = heff_dup(heff_rfield(v_e_240, 0));
      V v_t_2424 = heff_intSub(heff_take_field(v_sc_2423, 0), MK_INT(1LL));
      V v_t_2425 = ({ V b_0 = heff_get_n(v_sc_2423, 1, 4); V a_1 = heff_intSub(v_t_2424, v_l_245); V r_ = (g_heff_2eelab_2erules_2enameAtGo(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2426 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eescapeAt_str0), heff_strAppend(v_t_2425, ((V)&g_heff_2eelab_2erules_2eescapeAt_str1)));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2426});
    }
    default: return heff_nomatch(v_err_244);
    }
  }
  case TAG_Just: {
    V v_x71_2427 = heff_field(v_x7_246, 0);
    heff_drop(v_a_242);
    heff_drop(v_a_27_243);
    switch (heff_tag_of(v_x71_2427)) {
    case TAG_MkPair: {
      V v_x_2428 = heff_field(v_x71_2427, 0);
      V v_t_2429 = heff_field(v_x71_2427, 1);
      V v_sc_2430 = heff_dup(heff_rfield(v_e_240, 0));
      V v_t_2431 = heff_intSub(heff_take_field(v_sc_2430, 0), MK_INT(1LL));
      V v_t_2432 = ({ V b_0 = heff_get_n(v_sc_2430, 1, 4); V a_1 = heff_intSub(v_t_2431, v_l_245); V r_ = (g_heff_2eelab_2erules_2enameAtGo(b_0, a_1)); heff_drop(b_0); r_; });
      return heff_tail(((V)&g_heff_2eelab_2erules_2eresourceEscapes_clo), 5, (V[]){v_e_240, v_sp_241, v_t_2432, heff_dup(v_x_2428), heff_dup(v_t_2429)});
    }
    default: return heff_nomatch(v_x71_2427);
    }
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2erules_2eescapeAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2eelab_2erules_2eescapeAt(a[0], a[1], a[2], a[3], a4, a[5], a6); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam3, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitDefault(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    HeffT1 v_t_2413 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam0, 3, 1, (V[]){v_i_246})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_f_2415 = v_field_2414;
      return heff_tail(v_f_2415, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
  }
  case TAG_FracNum: {
    V v_x_2416 = heff_tget_v(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    HeffT1 v_t_2423 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24FracNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam2, 3, 1, (V[]){v_x_2416})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_f_2425 = v_field_2424;
      return heff_tail(v_f_2425, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitDefault(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  V v_i_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_247);
  heff_drop(v_hd_248);
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam1_clo)});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, NTAG(TAG_VPrimInt)});
  V f_ = v_k_249;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam2(V self, V *args) {
  V v_e_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2417);
  heff_drop(v_hd_2418);
  V v_t_2421 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2416))}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam3_clo)});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, NTAG(TAG_VPrimFloat)});
  V f_ = v_k_2419;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitWait_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitWait_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_entry, 3, 0};

V g_heff_2eelab_2erules_2enumLitWait(V v_n_240, V v_sp_241, V v_lit_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam0, 4, 3, (V[]){v_sp_241, v_lit_242, v_n_240})});
}
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitWait(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_n_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2433;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2413 = heff_dup(heff_field(v_x_2411, 0));
    switch (heff_tag_of(v_t1_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t1_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_n_240);
    heff_drop(v_t_2433);
    return (g_heff_2eelab_2erules_2enumLitAt(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
  } else {
    heff_drop(v_t_2433);
    if ((((int64_t)0ULL) < heff_peek_word(v_n_240))) {
      switch (heff_tag_of(v_lit_242)) {
      case TAG_IntNum: {
        V v_c_2436 = (g_heff_2eelab_2erules_2enumLitWait(heff_box_word((heff_unbox_word(v_n_240) - ((int64_t)1ULL))), heff_dup(v_sp_241), v_lit_242));
        return ({ V a_0 = v_e_243; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2enumLitWait_str0); V a_3 = v_c_2436; V a_4 = heff_dup(v_x_2411); V a_5 = v_x_2411; V a_6 = v_hd_245; V a_7 = v_k_246; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2436); r_; });
      }
      case TAG_FracNum: {
        heff_drop(v_n_240);
        return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
      }
      default: return heff_nomatch(v_lit_242);
      }
    } else {
      heff_drop(v_n_240);
      return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
    }
  }
}
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_241 = heff_env(self)[0];
  V v_lit_242 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam2, 1, 6, (V[]){v_sp_241, v_e_243, v_lit_242, v_hd_245, v_k_246, v_n_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordFormation_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordFormation_entry, 1, 0};

V g_heff_2eelab_2erules_2erecordFormation(V v_fieldTyps_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam0, 1, 1, (V[]){v_fieldTyps_240})});
}
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordFormation(a[0]);
}
V g_heff_2eelab_2erules_2erecordFormation_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = (g_heff_2eelab_2erules_2erecordOf(v_e_241, v_x_249));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam2, 1, 2, (V[]){v_e_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordFormation_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_fieldTyps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sd_242 = heff_dup(heff_rfield(v_e_241, 0));
  V v_t_243 = heff_tag_n(TAG_CUndelay, 1, (V[]){heff_take_field(v_sd_242, 3)});
  V v_t_244 = ({ V rv_3 = v_t_243; V rr_ = heff_rec_reuse_nf(v_sd_242, 7ULL, 4, shape_len__names__locals__ctx, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_245 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_t_244, heff_dup(heff_rfield(v_e_241, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), heff_dup(heff_rfield(v_e_241, 5))});
  V v_c_246 = (g_heff_2eelab_2erules_2eformGo(v_t_245, MK_INT(0LL), v_fieldTyps_240));
  return heff_clo_n(g_heff_2eelab_2erules_2erecordFormation_lam1, 2, 2, (V[]){v_c_246, v_e_241});
}
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdateSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_entry, 8, 0};

V g_heff_2eelab_2erules_2eupdateSetting(V v_upd_240, V v_e_241, V v_sp_242, V v_r_243, V v_g_244, V v_a_245, V v_fs_246, V v_x_247) {
top: ;
  V v_it_248 = (g_list_2efilter_24s1966236437x1225976932(v_x_247, heff_dup(v_fs_246)));
  switch (heff_tag_of(v_it_248)) {
  case TAG_Nil: {
    heff_drop(v_upd_240);
    heff_drop(v_e_241);
    heff_drop(v_fs_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam0, 2, 5, (V[]){v_x_247, v_sp_242, v_r_243, v_g_244, v_a_245});
  }
  case TAG_Cons: {
    V v_it1_2420 = heff_field(v_it_248, 0);
    V v_it2_2421 = heff_field(v_it_248, 1);
    heff_take_n(v_it_248, 3ULL, 2);
    heff_drop(v_sp_242);
    switch (heff_tag_of(v_it1_2420)) {
    case TAG_UpdateTo: {
      V v_xsp_2423 = heff_field(v_it1_2420, 1);
      V v_fsp_2424 = heff_field(v_it1_2420, 2);
      V v_c_2425 = heff_field(v_it1_2420, 3);
      heff_take_n(v_it1_2420, 14ULL, 4);
      heff_drop(v_upd_240);
      heff_drop(v_e_241);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_a_245);
      switch (heff_tag_of(v_it2_2421)) {
      case TAG_Nil: {
        heff_drop(v_fs_246);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam4, 2, 4, (V[]){v_x_247, v_c_2425, v_fsp_2424, v_xsp_2423});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_2421, 0ULL, 2);
        heff_drop(v_xsp_2423);
        heff_drop(v_fsp_2424);
        heff_drop(v_c_2425);
        return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
      }
      default: return heff_nomatch(v_it2_2421);
      }
    }
    case TAG_UpdateIn: {
      V v_xsp_2431 = heff_field(v_it1_2420, 1);
      V v_fsp_2432 = heff_field(v_it1_2420, 2);
      V v_inner_2433 = heff_field(v_it1_2420, 3);
      heff_take_n(v_it1_2420, 14ULL, 4);
      HeffT2 v_t_2434 = (g_heff_2eelab_2erules_2eupdateInner_24cpr(v_it2_2421));
      {
        V v_field_2436 = v_t_2434.f[1];
        int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
        if ((v_tag_2435 == ((int64_t)0ULL))) {
          heff_drop(v_fs_246);
          V v_rest_2438 = v_field_2436;
          V v_c_2439 = heff_tr(g_heff_2eelab_2erules_2erecordNameOf(v_e_241, heff_dup(v_a_245), heff_dup(v_x_247), v_xsp_2431));
          return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam5, 2, 9, (V[]){v_c_2439, v_inner_2433, v_rest_2438, v_upd_240, v_fsp_2432, v_r_243, v_g_244, v_a_245, v_x_247});
        } else {
          heff_drop(v_upd_240);
          heff_drop(v_e_241);
          heff_drop(v_r_243);
          heff_drop(v_g_244);
          heff_drop(v_a_245);
          heff_drop(v_xsp_2431);
          heff_drop(v_fsp_2432);
          heff_drop(v_inner_2433);
          heff_drop(v_field_2436);
          return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
        }
      }
    }
    default: return heff_nomatch(v_it1_2420);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdateSetting(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_e_2411 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_fty_2412 = heff_env(self)[3];
  V v_hd_2414 = heff_env(self)[4];
  V v_k_2415 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_m_2417 = heff_field(v_x_2416, 0);
    V v_t_2418 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    return (g_heff_2eelab_2erules_2esameField(v_sp_242, v_e_2411, v_x_247, v_fty_2412, v_m_2417, v_t_2418, v_hd_2414, v_k_2415));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_e_2411 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_fty_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam3, 1, 6, (V[]){v_sp_242, v_e_2411, v_x_247, v_fty_2412, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args) {
  V v_e_2411 = args[0];
  V v_fty_2412 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  V v_g_244 = heff_env(self)[2];
  V v_a_245 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2413 = ({ V a_0 = heff_dup(v_sp_242); V a_1 = heff_dup(v_e_2411); V a_2 = v_r_243; V a_3 = v_g_244; V a_4 = v_a_245; V a_5 = heff_dup(v_x_247); V r_ = (g_heff_2eelab_2erules_2eupdatedField(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_r_243); r_; });
  return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam2, 2, 5, (V[]){v_c_2413, v_sp_242, v_e_2411, v_x_247, v_fty_2412});
}
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_r_243 = heff_env(self)[2];
  V v_g_244 = heff_env(self)[3];
  V v_a_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_hd_249);
  V v_t_2419 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){heff_dup(v_x_247), heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam1, 2, 5, (V[]){heff_dup(v_sp_242), v_r_243, v_g_244, v_a_245, v_x_247})}), v_sp_242, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2410;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_c_2425 = heff_env(self)[1];
  V v_fsp_2424 = heff_env(self)[2];
  V v_xsp_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, v_c_2425, v_fsp_2424, v_xsp_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_inner_2433 = heff_env(self)[0];
  V v_rest_2438 = heff_env(self)[1];
  V v_upd_240 = heff_env(self)[2];
  V v_fsp_2432 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_a_245 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_k_2441 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2442);
  V v_t_2443 = (g_heff_2eelab_2erules_2eappendP(v_inner_2433, v_rest_2438));
  V v_t_2444 = (g_heff_2eelab_2erules_2enestedField(v_upd_240, heff_dup(v_fsp_2432), v_r_243, v_g_244, v_a_245, heff_dup(v_x_247), v_t_2443));
  V v_x_2445 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, v_t_2444, v_fsp_2432, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2441;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  V v_inner_2433 = heff_env(self)[1];
  V v_rest_2438 = heff_env(self)[2];
  V v_upd_240 = heff_env(self)[3];
  V v_fsp_2432 = heff_env(self)[4];
  V v_r_243 = heff_env(self)[5];
  V v_g_244 = heff_env(self)[6];
  V v_a_245 = heff_env(self)[7];
  V v_x_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2439;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam6, 1, 9, (V[]){v_inner_2433, v_rest_2438, v_upd_240, v_fsp_2432, v_r_243, v_g_244, v_a_245, v_x_247, v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordUpdate_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordUpdate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordUpdate_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordUpdate(V v_sp_240, V v_s_241, V v_r_242, V v_fs_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_r_242, v_fs_243})});
}
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordUpdate(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordUpdate_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_a_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_a_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_r_242 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_fs_243 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_g_2417 = heff_field(v_x_2416, 0);
    V v_a_2418 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    return (g_heff_2eelab_2erules_2eupdateOf(v_sp_240, v_r_242, v_e_244, v_g_2417, heff_dup(v_a_2418), v_fs_243, v_hd_247, heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam4, 1, 2, (V[]){v_k_248, v_a_2418})));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2erecordUpdate_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_fs_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_dup(heff_field(v_x_249, 0));
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_y_2414 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 2ULL, 2);
    v_t_2415 = v_y_2414;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_240), v_t_2412, v_t_2415, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam3, 1, 6, (V[]){v_sp_240, v_r_242, v_e_244, v_fs_243, v_hd_247, v_k_248})));
}
V g_heff_2eelab_2erules_2erecordUpdate_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_fs_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam2, 1, 6, (V[]){v_e_244, v_sp_240, v_hd_247, v_r_242, v_fs_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordUpdate_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  V v_fs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordUpdate_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_240, v_r_242, v_fs_243});
}