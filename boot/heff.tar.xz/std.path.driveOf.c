// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2epath_2edriveOf_2eunc_240_24cpr(V, V);
HEFF_LIT(g_std_2epath_2edriveOf_2eunc_240_24cpr_str0, 0, "");
HEFF_LIT(g_std_2epath_2edriveOf_2eunc_240_24cpr_str1, 0, "");
HEFF_LIT(g_std_2epath_2edriveOf_2eunc_240_24cpr_str2, 1, "/");
HEFF_LIT(g_std_2epath_2edriveOf_2eunc_240_24cpr_str3, 2, "//");
HEFF_LIT(g_std_2epath_2edriveOf_2eunc_240_24cpr_str4, 0, "");
HEFF_LIT(g_std_2epath_2edriveOf_2eunc_240_24cpr_str5, 1, "/");
HEFF_LIT(g_std_2epath_2edriveOf_2eunc_240_24cpr_str6, 1, "/");

HeffT2 g_std_2epath_2edriveOf_2eunc_240_24cpr(V v_s_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return ((HeffT2){{((V)&g_std_2epath_2edriveOf_2eunc_240_24cpr_str0), v_s_240}});
  }
  case TAG_Cons: {
    V v_server_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_server_242);
      return ((HeffT2){{((V)&g_std_2epath_2edriveOf_2eunc_240_24cpr_str1), v_s_240}});
    }
    case TAG_Cons: {
      V v_share_244 = heff_field(v_x12_243, 0);
      V v_rest_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      heff_drop(v_s_240);
      V v_t_246 = heff_strAppend(v_server_242, heff_strAppend(((V)&g_std_2epath_2edriveOf_2eunc_240_24cpr_str2), v_share_244));
      V v_f_247 = heff_strAppend(((V)&g_std_2epath_2edriveOf_2eunc_240_24cpr_str3), v_t_246);
      V v_t_2410;
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_std_2epath_2edriveOf_2eunc_240_24cpr_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_rest_245, 0);
        V v_xs_249 = heff_field(v_rest_245, 1);
        heff_take_n(v_rest_245, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_std_2epath_2edriveOf_2eunc_240_24cpr_str5); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_rest_245);
      }
      V v_f_2411 = heff_strAppend(((V)&g_std_2epath_2edriveOf_2eunc_240_24cpr_str6), v_t_2410);
      return ((HeffT2){{v_f_247, v_f_2411}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_241)}});
  }
}