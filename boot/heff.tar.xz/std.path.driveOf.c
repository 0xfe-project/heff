// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_std_2epath_2edriveOf_2eunc_240(V, V);
V g_std_2epath_2edriveOf_2eunc_240_entry(V self, V *a);
extern Clo g_std_2epath_2edriveOf_2eunc_240_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_2eunc_240_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_2eunc_240_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2edriveOf_2eunc_240_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_2eunc_240_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_2eunc_240_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_2eunc_240_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_2eunc_240_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_std_2epath_2edriveOf_2eunc_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2edriveOf_2eunc_240_entry, 2, 0};

V g_std_2epath_2edriveOf_2eunc_240(V v_s_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_2eunc_240_str0), v_s_240});
  }
  case TAG_Cons: {
    V v_server_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_server_242);
      return heff_tag_at(v_ru_24x1_241_24Cons, TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_2eunc_240_str1), v_s_240});
    }
    case TAG_Cons: {
      V v_share_244 = heff_field(v_x12_243, 0);
      V v_rest_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      heff_drop(v_s_240);
      V v_t_246 = heff_strAppend(((V)&g_std_2epath_2edriveOf_2eunc_240_str2), heff_strAppend(v_server_242, heff_strAppend(((V)&g_std_2epath_2edriveOf_2eunc_240_str3), v_share_244)));
      V v_t_249;
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_std_2epath_2edriveOf_2eunc_240_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_rest_245, 0);
        V v_xs_248 = heff_field(v_rest_245, 1);
        heff_take_n(v_rest_245, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_std_2epath_2edriveOf_2eunc_240_str5); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_rest_245);
      }
      return heff_tag_at(v_ru_24x1_241_24Cons, TAG_MkPair, 2, (V[]){v_t_246, heff_strAppend(((V)&g_std_2epath_2edriveOf_2eunc_240_str6), v_t_249)});
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_std_2epath_2edriveOf_2eunc_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2edriveOf_2eunc_240(a[0], a[1]);
}