// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCArm 24694
#define TAG_MkCode 2932
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define LBL_body 9524841
#define LBL_entry 298026124
#define LBL_key 315609
#define LBL_lent 9813446
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_wrapper 1827365593
static uint32_t shape_key__params__lent__entry__body__reprs__ret__wrapper[] = {LBL_key, LBL_params, LBL_lent, LBL_entry, LBL_body, LBL_reprs, LBL_ret, LBL_wrapper};
V g_heff_2ecompile_2eborrow_2elendingPrims_get(void);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2eowned_2echain(V, V);
V g_heff_2ecompile_2eowned_2echain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2echain_clo;
V g_heff_2ecompile_2eowned_2econdKids(V);
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_clo;
V g_heff_2ecompile_2eowned_2econdKids_24dps(V, V);
V g_heff_2ecompile_2eowned_2econdKids_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_24dps_clo;
V g_heff_2ecompile_2eowned_2eelemS(V, V);
V g_heff_2ecompile_2eowned_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eelemS_clo;
V g_heff_2ecompile_2eowned_2egivesUp(V, V);
V g_heff_2ecompile_2eowned_2egivesUp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2egivesUp_clo;
HeffT2 g_heff_2ecompile_2eowned_2eheldOf_24cpr(V);
V g_heff_2ecompile_2eowned_2ekids(V);
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ekids_clo;
V g_heff_2ecompile_2eowned_2elendingPrims_get(void);
V g_heff_2ecompile_2eowned_2elentOperand(V, V);
V g_heff_2ecompile_2eowned_2elentOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elentOperand_clo;
HeffT2 g_heff_2ecompile_2eowned_2elocalOf_24cpr(V);
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_heff_2ecompile_2eowned_2emapCond_24dps(V, V, V, V);
V g_heff_2ecompile_2eowned_2emapCond_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24dps_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(V);
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps(V, V, V);
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(V);
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps(V, V, V);
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps_clo;
V g_heff_2ecompile_2eowned_2eokCond(V, V);
V g_heff_2ecompile_2eowned_2eokCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokCond_clo;
V g_heff_2ecompile_2eowned_2eokExp(V, V, V);
V g_heff_2ecompile_2eowned_2eokExp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokExp_clo;
V g_heff_2ecompile_2eowned_2eokOperands(V, V, V);
V g_heff_2ecompile_2eowned_2eokOperands_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokOperands_clo;
V g_heff_2ecompile_2eowned_2eokStmts(V, V, V);
V g_heff_2ecompile_2eowned_2eokStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokStmts_clo;
V g_heff_2ecompile_2eowned_2eownCheck(V, V);
V g_heff_2ecompile_2eowned_2eownCheck_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownCheck_clo;
V g_heff_2ecompile_2eowned_2eownExp(V, V);
V g_heff_2ecompile_2eowned_2eownExp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownExp_clo;
V g_heff_2ecompile_2eowned_2eownExp_24dps(V, V, V, V);
V g_heff_2ecompile_2eowned_2eownExp_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownExp_24dps_clo;
V g_heff_2ecompile_2eowned_2eownSt(V, V, V);
V g_heff_2ecompile_2eowned_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownSt_clo;
V g_heff_2ecompile_2eowned_2eownStmts(V, V);
V g_heff_2ecompile_2eowned_2eownStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownStmts_clo;
V g_heff_2ecompile_2eowned_2eownedChain(V, V, V, V);
V g_heff_2ecompile_2eowned_2eownedChain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownedChain_clo;
V g_heff_2ecompile_2eowned_2esetRepr(V, V);
V g_heff_2ecompile_2eowned_2esetRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2esetRepr_clo;
V g_heff_2ecompile_2eowned_2esetsIn(V, V);
V g_heff_2ecompile_2eowned_2esetsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2esetsIn_clo;
V g_heff_2ecompile_2eowned_2esetsOf(V, V);
V g_heff_2ecompile_2eowned_2esetsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2esetsOf_clo;
V g_heff_2ecompile_2eowned_2esetsSt(V, V, V);
V g_heff_2ecompile_2eowned_2esetsSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2esetsSt_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1465078656x604124530(V);
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a);
extern Clo g_list_2eall_24s1465078656x604124530_clo;
V g_list_2eall_24s335630579x1560445122(V, V);
V g_list_2eall_24s335630579x1560445122_entry(V self, V *a);
extern Clo g_list_2eall_24s335630579x1560445122_clo;
V g_list_2eall_24s751274328x395946890(V, V, V);
V g_list_2eall_24s751274328x395946890_entry(V self, V *a);
extern Clo g_list_2eall_24s751274328x395946890_clo;
V g_list_2eany_24s63755471x810534073(V, V);
V g_list_2eany_24s63755471x810534073_entry(V self, V *a);
extern Clo g_list_2eany_24s63755471x810534073_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1365277776x1804683130(V, V);
V g_list_2efoldl_24f1365277776x1804683130_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1365277776x1804683130_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s708019417x1279437633(V, V);
V g_list_2ekeepIf_24s708019417x1279437633_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s708019417x1279437633_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1354671438x1264137843(V);
V g_list_2emap_24s1354671438x1264137843_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_clo;
V g_list_2emap_24s1688354384x1781591142(V, V, V);
V g_list_2emap_24s1688354384x1781591142_entry(V self, V *a);
extern Clo g_list_2emap_24s1688354384x1781591142_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s391650521x1406868658(V);
V g_list_2emap_24s391650521x1406868658_entry(V self, V *a);
extern Clo g_list_2emap_24s391650521x1406868658_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_LIT(g_heff_2ecompile_2eowned_2elendingPrims_str0, 10, "arrayKeeps");
HEFF_LIT(g_heff_2ecompile_2eowned_2elendingPrims_str1, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eowned_2elendingPrims_str2, 12, "arrayIndexIn");
HEFF_LIT(g_heff_2ecompile_2eowned_2elendingPrims_str3, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eowned_2elendingPrims_str4, 5, "intLt");

static V g_heff_2ecompile_2eowned_2elendingPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eowned_2elendingPrims_st;
static V g_heff_2ecompile_2eowned_2elendingPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eowned_2elendingPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eowned_2elendingPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eowned_2elendingPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eowned_2elendingPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eowned_2elendingPrims_str4), v_t_241})});
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eborrow_2elendingPrims_get()), v_t_242));
}
V g_heff_2ecompile_2eowned_2elendingPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eowned_2elendingPrims_st)) return g_heff_2ecompile_2eowned_2elendingPrims_val;
  return heff_global(&g_heff_2ecompile_2eowned_2elendingPrims_val, &g_heff_2ecompile_2eowned_2elendingPrims_st, g_heff_2ecompile_2eowned_2elendingPrims_init);
}
Clo g_heff_2ecompile_2eowned_2egivesUp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2egivesUp_entry, 2, 0};

V g_heff_2ecompile_2eowned_2egivesUp(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242, 0));
    return v_ret_24bool;
  }
  case TAG_RDup: {
    return NTAG(TAG_False);
  }
  case TAG_RClo: {
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2egivesUp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eowned_2egivesUp(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eowned_2econdKids_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2econdKids_24dps_entry, 2, 0};

V g_heff_2ecompile_2eowned_2econdKids_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CondTrue: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_CondFalse: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_CondRel: {
    V v_es_243 = heff_field(v_x1_240, 1);
    return heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_es_243));
  }
  case TAG_CondRelU: {
    V v_es_245 = heff_field(v_x1_240, 1);
    return heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_es_245));
  }
  case TAG_CondBool: {
    V v_e_246 = heff_field(v_x1_240, 0);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_246), NTAG(TAG_Nil)});
    return heff_setField(v_d_241, MK_INT(1LL), v_t_247);
  }
  case TAG_CondNot: {
    V v_c_248 = heff_field(v_x1_240, 0);
    V t_0 = v_c_248;
    V t_1 = v_d_241;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_249 = heff_field(v_x1_240, 0);
    V v_b_2410 = heff_field(v_x1_240, 1);
    V v_c_2411 = heff_field(v_x1_240, 2);
    V v_t_2412 = (g_heff_2ecompile_2eowned_2econdKids(v_a_249));
    V v_t_2413 = (g_heff_2ecompile_2eowned_2econdKids(v_b_2410));
    V v_t_2414 = (g_heff_2ecompile_2eowned_2econdKids(v_c_2411));
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2414));
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2415));
    return heff_setField(v_d_241, MK_INT(1LL), v_t_2416);
  }
  case TAG_CondLet: {
    V v_e_2418 = heff_field(v_x1_240, 1);
    V v_c_2419 = heff_field(v_x1_240, 2);
    V v_cell_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2418), heff_hole()});
    V v_u_2422 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_c_2419;
    V t_1 = v_cell_2421;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eowned_2econdKids_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eowned_2econdKids_24dps(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eowned_2elocalOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    V v_a_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_241}});
  }
  case TAG_RDup: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    heff_take_n(v_x1_240, 0ULL, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RLam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2eowned_2echain_lam1(V self, V *args);
V g_heff_2ecompile_2eowned_2echain_lam0(V self, V *args);
Clo g_heff_2ecompile_2eowned_2echain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2echain_entry, 2, 0};

V g_heff_2ecompile_2eowned_2echain(V v_ds_240, V v_us_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_ds_240)));
  V v_more_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eowned_2echain_lam0, 1, 2, (V[]){heff_dup(v_us_241), heff_dup(v_ds_240)}), v_t_242));
  switch (heff_tag_of(v_more_2414)) {
  case TAG_Nil: {
    heff_drop(v_ds_240);
    return v_us_241;
  }
  case TAG_Cons: {
    V v_t_2417 = (g_prelude_2e_2b_2b(v_more_2414, v_us_241));
    V t_0 = v_ds_240;
    V t_1 = v_t_2417;
    v_ds_240 = t_0;
    v_us_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_more_2414);
  }
}
V g_heff_2ecompile_2eowned_2echain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2echain(a[0], a[1]);
}
V g_heff_2ecompile_2eowned_2echain_lam1(V self, V *args) {
  V v_v_249 = args[0];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(v_v_249));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      return ({ V a_0 = v_x_2413; V a_1 = v_us_241; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2413); heff_drop(v_us_241); r_; });
    } else {
      heff_drop(v_us_241);
      heff_drop(v_field_2412);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eowned_2echain_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_us_241 = heff_env(self)[0];
  V v_ds_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244 = (g_heff_2ecompile_2eowned_2eelemS(v_x_243, v_us_241));
  if (!(heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    V v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_ds_240; V r_ = (g_list_2ekeepIf_24s708019417x1279437633(a_0, a_1)); heff_drop(v_x_243); r_; });
    V v_vs_246 = (g_list_2emap_24s1173914895x100384474(v_t_245));
    switch (heff_tag_of(v_vs_246)) {
    case TAG_Nil: {
      heff_drop(v_us_241);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2echain_lam1, 1, 1, (V[]){v_us_241}); V a_1 = v_vs_246; V r_ = (g_list_2eall(a_0, a_1)); heff_drop_tag(v_vs_246, 2); r_; });
    }
    default: return heff_nomatch(v_vs_246);
    }
  } else {
    heff_drop(v_x_243);
    heff_drop(v_us_241);
    heff_drop(v_ds_240);
    heff_drop(v_x1_244);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2eowned_2eokOperands_lam0(V self, V *args);
Clo g_heff_2ecompile_2eowned_2eokOperands_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eokOperands_entry, 3, 0};

V g_heff_2ecompile_2eowned_2eokOperands(V v_ok_240, V v_p_241, V v_es_242) {
top: ;
  V v_t_243 = ({ V a_0 = v_p_241; V b_1 = heff_dup(g_heff_2ecompile_2eowned_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_list_2eall_24s1465078656x604124530(v_es_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2eany_24s63755471x810534073(v_es_242, v_es_242));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        return (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eowned_2eokOperands_lam0, 1, 2, (V[]){heff_dup(v_es_242), v_ok_240}), v_es_242));
      } else {
        heff_drop(v_t_245);
        return (g_list_2eall(v_ok_240, v_es_242));
      }
    } else {
      heff_drop(v_t_244);
      return (g_list_2eall(v_ok_240, v_es_242));
    }
  } else {
    heff_drop(v_t_243);
    return (g_list_2eall(v_ok_240, v_es_242));
  }
}
V g_heff_2ecompile_2eowned_2eokOperands_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eowned_2eokOperands(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eowned_2eokOperands_lam0(V self, V *args) {
  V v_e_246 = args[0];
  V v_es_242 = heff_env(self)[0];
  V v_ok_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = ({ V a_0 = v_es_242; V a_1 = v_e_246; V r_ = (g_heff_2ecompile_2eowned_2elentOperand(a_0, a_1)); heff_drop(v_es_242); r_; });
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_e_246);
    heff_drop(v_ok_240);
    heff_drop(v_t_247);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_247);
    V f_ = v_ok_240;
    args[0] = v_e_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
Clo g_heff_2ecompile_2eowned_2eokCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eokCond_entry, 2, 0};

V g_heff_2ecompile_2eowned_2eokCond(V v_ok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    V v_t_242 = (g_heff_2ecompile_2eowned_2econdKids(v_x2_241));
    return ({ V a_0 = v_ok_240; V a_1 = v_t_242; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_242); r_; });
  }
  case TAG_CondFalse: {
    V v_t_243 = (g_heff_2ecompile_2eowned_2econdKids(v_x2_241));
    return ({ V a_0 = v_ok_240; V a_1 = v_t_243; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_243); r_; });
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    return (g_heff_2ecompile_2eowned_2eokOperands(v_ok_240, v_p_244, v_es_245));
  }
  case TAG_CondRelU: {
    V v_t_248 = (g_heff_2ecompile_2eowned_2econdKids(v_x2_241));
    return ({ V a_0 = v_ok_240; V a_1 = v_t_248; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  case TAG_CondBool: {
    V v_t_2410 = (g_heff_2ecompile_2eowned_2econdKids(v_x2_241));
    return ({ V a_0 = v_ok_240; V a_1 = v_t_2410; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_CondNot: {
    V v_c_2411 = heff_field(v_x2_241, 0);
    V t_0 = v_ok_240;
    V t_1 = v_c_2411;
    v_ok_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_2412 = heff_field(v_x2_241, 0);
    V v_b_2413 = heff_field(v_x2_241, 1);
    V v_c_2414 = heff_field(v_x2_241, 2);
    V v_t_2415 = (g_heff_2ecompile_2eowned_2eokCond(heff_dup(v_ok_240), v_a_2412));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      V v_t_2416 = (g_heff_2ecompile_2eowned_2eokCond(heff_dup(v_ok_240), v_b_2413));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V t_0 = v_ok_240;
        V t_1 = v_c_2414;
        v_ok_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_ok_240);
        heff_drop(v_t_2416);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_ok_240);
      heff_drop(v_t_2415);
      return NTAG(TAG_False);
    }
  }
  case TAG_CondLet: {
    V v_e_2418 = heff_field(v_x2_241, 1);
    V v_c_2419 = heff_field(v_x2_241, 2);
    V v_t_2421 = heff_tr(heff_call(heff_dup(v_ok_240), 1, (V[]){heff_dup(v_e_2418)}));
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      V t_0 = v_ok_240;
      V t_1 = v_c_2419;
      v_ok_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_ok_240);
      heff_drop(v_t_2421);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2eokCond_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eowned_2eokCond(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eowned_2eokExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eokExp_entry, 3, 0};

V g_heff_2ecompile_2eowned_2eokExp(V v_go_240, V v_us_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_RLocal: {
    V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_245 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_244; V a_1 = v_t_245; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_245); r_; });
  }
  case TAG_RDup: {
    V v_x_246 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_go_240);
    V v_x1_247 = ({ V a_0 = v_x_246; V a_1 = v_us_241; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_246); heff_drop(v_us_241); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
    heff_drop(v_x1_247);
    return v_ret_24bool;
  }
  case TAG_RClo: {
    V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2410 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_249; V a_1 = v_t_2410; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_RGet: {
    V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2413 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2412; V a_1 = v_t_2413; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2413); r_; });
  }
  case TAG_RGetRaw: {
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2416 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2415; V a_1 = v_t_2416; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2416); r_; });
  }
  case TAG_RInt: {
    V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2419 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2418; V a_1 = v_t_2419; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2419); r_; });
  }
  case TAG_RFloat: {
    V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2422 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2421; V a_1 = v_t_2422; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2422); r_; });
  }
  case TAG_RStr: {
    V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2425 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2424; V a_1 = v_t_2425; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2425); r_; });
  }
  case TAG_RBytes: {
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2428 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2427; V a_1 = v_t_2428; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2428); r_; });
  }
  case TAG_RFixed: {
    V v_t_2431 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2432 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2431; V a_1 = v_t_2432; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2432); r_; });
  }
  case TAG_RF32: {
    V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2435 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2434; V a_1 = v_t_2435; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2435); r_; });
  }
  case TAG_RNTag: {
    V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2438 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2437; V a_1 = v_t_2438; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2438); r_; });
  }
  case TAG_RTag: {
    V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2443 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2442; V a_1 = v_t_2443; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2443); r_; });
  }
  case TAG_RTagIn: {
    V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2449 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2448; V a_1 = v_t_2449; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2449); r_; });
  }
  case TAG_RRec: {
    V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2454 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2453; V a_1 = v_t_2454; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2454); r_; });
  }
  case TAG_RRecIn: {
    V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2464 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2463; V a_1 = v_t_2464; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2464); r_; });
  }
  case TAG_RField: {
    V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2468 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2467; V a_1 = v_t_2468; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2468); r_; });
  }
  case TAG_RDupE: {
    V v_e_2469 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    HeffT2 v_t_2470 = (g_heff_2ecompile_2eowned_2elocalOf_24cpr(heff_dup(v_e_2469)));
    {
      V v_field_2472 = v_t_2470.f[1];
      int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
      if ((v_tag_2471 == ((int64_t)0ULL))) {
        V v_x_2473 = v_field_2472;
        V v_x1_2474 = ({ V a_0 = v_x_2473; V a_1 = v_us_241; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2473); r_; });
        if (!(heff_dup(v_x1_2474) == NTAG(TAG_True))) {
          heff_drop(v_x1_2474);
          V t_0 = v_go_240;
          V t_1 = v_us_241;
          V t_2 = v_e_2469;
          v_go_240 = t_0;
          v_us_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop(v_go_240);
          heff_drop(v_us_241);
          heff_drop(v_e_2469);
          heff_drop(v_x1_2474);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_2472);
        V t_0 = v_go_240;
        V t_1 = v_us_241;
        V t_2 = v_e_2469;
        v_go_240 = t_0;
        v_us_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  case TAG_RFieldV: {
    V v_t_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2478 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2477; V a_1 = v_t_2478; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2478); r_; });
  }
  case TAG_RGetN: {
    V v_t_2482 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2483 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2482; V a_1 = v_t_2483; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2483); r_; });
  }
  case TAG_RFieldU: {
    V v_t_2488 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2489 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2488; V a_1 = v_t_2489; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2489); r_; });
  }
  case TAG_RGetNU: {
    V v_t_2495 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_2496 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2495; V a_1 = v_t_2496; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2496); r_; });
  }
  case TAG_RWord: {
    V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24100 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_2499; V a_1 = v_t_24100; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24100); r_; });
  }
  case TAG_RTakeField: {
    V v_t_24103 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24104 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24103; V a_1 = v_t_24104; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24104); r_; });
  }
  case TAG_RGetLabel: {
    V v_t_24107 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24108 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24107; V a_1 = v_t_24108; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24108); r_; });
  }
  case TAG_RPrimFn: {
    V v_t_24110 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24111 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24110; V a_1 = v_t_24111; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24111); r_; });
  }
  case TAG_RPrim: {
    V v_p_24112 = heff_field(v_x3_242, 0);
    V v_es_24113 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_24114 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    return ({ V a_0 = v_t_24114; V a_1 = v_p_24112; V a_2 = v_es_24113; V r_ = (g_heff_2ecompile_2eowned_2eokOperands(a_0, a_1, a_2)); heff_drop(v_p_24112); heff_drop(v_es_24113); r_; });
  }
  case TAG_RLam: {
    V v_held_24117 = heff_field(v_x3_242, 2);
    V v_x34_24118 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 12ULL, 4);
    switch (heff_tag_of(v_x34_24118)) {
    case TAG_MkCode: {
      V v_body_24119 = heff_field(v_x34_24118, 0);
      heff_take_n(v_x34_24118, 1ULL, 1);
      V v_t_24120 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){heff_dup(v_go_240), v_us_241}));
      V v_t_24121 = ({ V a_0 = v_t_24120; V a_1 = v_held_24117; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_held_24117); r_; });
      if ((heff_dup(v_t_24121) == NTAG(TAG_True))) {
        heff_drop(v_t_24121);
        return heff_tail(v_go_240, 1, (V[]){v_body_24119});
      } else {
        heff_drop(v_go_240);
        heff_drop(v_body_24119);
        heff_drop(v_t_24121);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x34_24118);
    }
  }
  case TAG_RCall: {
    V v_args_24125 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 8ULL, 4);
    V v_t_24126 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, heff_dup(v_us_241)}));
    return ({ V a_0 = v_t_24126; V a_1 = v_us_241; V a_2 = v_args_24125; V r_ = (g_list_2eall_24s751274328x395946890(a_0, a_1, a_2)); heff_drop(v_us_241); heff_drop(v_args_24125); r_; });
  }
  case TAG_RApply: {
    V v_t_24129 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24130 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24129; V a_1 = v_t_24130; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24130); r_; });
  }
  case TAG_RBool: {
    V v_c_24131 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24132 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    return ({ V a_0 = v_t_24132; V a_1 = v_c_24131; V r_ = (g_heff_2ecompile_2eowned_2eokCond(a_0, a_1)); heff_drop(v_c_24131); r_; });
  }
  case TAG_RAbandon: {
    V v_t_24133 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24134 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24133; V a_1 = v_t_24134; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24134); r_; });
  }
  case TAG_RBox: {
    V v_t_24137 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24138 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24137; V a_1 = v_t_24138; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24138); r_; });
  }
  case TAG_RUnbox: {
    V v_t_24141 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24142 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24141; V a_1 = v_t_24142; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24142); r_; });
  }
  case TAG_RPeek: {
    V v_t_24145 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24146 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24145; V a_1 = v_t_24146; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24146); r_; });
  }
  case TAG_RPrimU: {
    V v_t_24149 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24150 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24149; V a_1 = v_t_24150; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24150); r_; });
  }
  case TAG_RPrimAt: {
    V v_p_24151 = heff_field(v_x3_242, 0);
    V v_es_24153 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 5ULL, 3);
    V v_t_24154 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    return ({ V a_0 = v_t_24154; V a_1 = v_p_24151; V a_2 = v_es_24153; V r_ = (g_heff_2ecompile_2eowned_2eokOperands(a_0, a_1, a_2)); heff_drop(v_p_24151); heff_drop(v_es_24153); r_; });
  }
  case TAG_RFixU: {
    V v_t_24157 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24158 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24157; V a_1 = v_t_24158; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24158); r_; });
  }
  case TAG_RF32U: {
    V v_t_24160 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24161 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24160; V a_1 = v_t_24161; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24161); r_; });
  }
  case TAG_RF64U: {
    V v_t_24163 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eokExp_clo), 2, (V[]){v_go_240, v_us_241}));
    V v_t_24164 = (g_heff_2ecompile_2eowned_2ekids(v_x3_242));
    return ({ V a_0 = v_t_24163; V a_1 = v_t_24164; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24164); r_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eowned_2eokExp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eokExp(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eowned_2esetsIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eowned_2esetsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2esetsIn_entry, 2, 0};

V g_heff_2ecompile_2eowned_2esetsIn(V v_us_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eowned_2esetRepr(v_us_240, heff_dup(v_e_241)));
  V v_f_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2esetsIn_clo), 1, (V[]){v_us_240}));
  V v_xs_244 = (g_heff_2ecompile_2eowned_2ekids(v_e_241));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_t_249 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsIn_lam0, 2, 1, (V[]){v_f_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_242, v_t_249);
}
V g_heff_2ecompile_2eowned_2esetsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2esetsIn(a[0], a[1]);
}
V g_heff_2ecompile_2eowned_2esetsIn_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_f_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(heff_call(v_f_243, 1, (V[]){v_x_247}));
  return (g_prelude_2e_2b_2b(v_t_248, v_acc_246));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam0(V self, V *args);
V g_heff_2ecompile_2eowned_2esetsSt_lam1(V self, V *args);
V g_heff_2ecompile_2eowned_2esetsSt_lam2(V self, V *args);
V g_heff_2ecompile_2eowned_2esetsSt_lam3(V self, V *args);
V g_heff_2ecompile_2eowned_2esetsSt_lam4(V self, V *args);
V g_heff_2ecompile_2eowned_2esetsSt_lam5(V self, V *args);
V g_heff_2ecompile_2eowned_2esetsSt_lam6(V self, V *args);
V g_heff_2ecompile_2eowned_2esetsSt_lam7(V self, V *args);
Clo g_heff_2ecompile_2eowned_2esetsSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2esetsSt_entry, 3, 0};

V g_heff_2ecompile_2eowned_2esetsSt(V v_go_240, V v_us_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_CDrop: {
    heff_take_n(v_s_242, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return NTAG(TAG_Nil);
  }
  case TAG_CLet: {
    V v_e_245 = heff_field(v_s_242, 1);
    heff_take_n(v_s_242, 2ULL, 2);
    heff_drop(v_go_240);
    return (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_e_245));
  }
  case TAG_CDecl: {
    heff_take_n(v_s_242, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return NTAG(TAG_Nil);
  }
  case TAG_CSet: {
    V v_e_248 = heff_field(v_s_242, 1);
    heff_take_n(v_s_242, 2ULL, 2);
    heff_drop(v_go_240);
    return (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_e_248));
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return NTAG(TAG_Nil);
  }
  case TAG_CIf: {
    V v_c_249 = heff_field(v_s_242, 0);
    V v_a_2410 = heff_field(v_s_242, 1);
    V v_b_2411 = heff_field(v_s_242, 2);
    heff_take_n(v_s_242, 7ULL, 3);
    V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_c_249; V r_ = (g_list_2efoldl_24f1365277776x1804683130(a_0, a_1)); heff_drop(v_c_249); r_; });
    V v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam0, 2, 1, (V[]){v_us_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2412; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
    V v_t_2417 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_2410}));
    V v_t_2418 = heff_tr(heff_call(v_go_240, 1, (V[]){v_b_2411}));
    V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
    return (g_prelude_2e_2b_2b(v_t_2416, v_t_2419));
  }
  case TAG_CSwitch: {
    V v_e_2420 = heff_field(v_s_242, 0);
    V v_arms_2421 = heff_field(v_s_242, 1);
    heff_take_n(v_s_242, 3ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_e_2420));
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2421));
    V v_t_2437 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam1, 2, 1, (V[]){v_go_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    return (g_prelude_2e_2b_2b(v_t_2423, v_t_2437));
  }
  case TAG_CReturn: {
    V v_e_2438 = heff_field(v_s_242, 0);
    heff_take_n(v_s_242, 1ULL, 1);
    heff_drop(v_go_240);
    return (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_e_2438));
  }
  case TAG_CInPlace: {
    V v_f_2439 = heff_field(v_s_242, 0);
    V v_es_2440 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CInPlace = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24s_242_24CInPlace, TAG_Cons, 2, (V[]){v_f_2439, v_es_2440})));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam2, 2, 1, (V[]){v_us_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2441; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2441); r_; });
  }
  case TAG_CRoomed: {
    V v_f_2445 = heff_field(v_s_242, 0);
    V v_es_2446 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CRoomed = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24s_242_24CRoomed, TAG_Cons, 2, (V[]){v_f_2445, v_es_2446})));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam3, 2, 1, (V[]){v_us_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2447; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2447); r_; });
  }
  case TAG_CTail: {
    V v_f_2451 = heff_field(v_s_242, 0);
    V v_es_2452 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CTail = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24s_242_24CTail, TAG_Cons, 2, (V[]){v_f_2451, v_es_2452})));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam4, 2, 1, (V[]){v_us_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2453; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2453); r_; });
  }
  case TAG_CLoop: {
    V v_es_2458 = heff_field(v_s_242, 1);
    heff_take_n(v_s_242, 2ULL, 2);
    heff_drop(v_go_240);
    V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2458));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam5, 2, 1, (V[]){v_us_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2459; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2459); r_; });
  }
  case TAG_CLoopTo: {
    V v_es_2465 = heff_field(v_s_242, 2);
    heff_take_n(v_s_242, 4ULL, 3);
    heff_drop(v_go_240);
    V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2465));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam6, 2, 1, (V[]){v_us_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2466; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2466); r_; });
  }
  case TAG_CLabel: {
    heff_take_n(v_s_242, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return NTAG(TAG_Nil);
  }
  case TAG_CJump: {
    V v_es_2473 = heff_field(v_s_242, 2);
    heff_take_n(v_s_242, 4ULL, 3);
    heff_drop(v_go_240);
    V v_t_2474 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2473));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsSt_lam7, 2, 1, (V[]){v_us_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2474; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2474); r_; });
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2eowned_2esetsSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2esetsSt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eowned_2esetsSt_lam0(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_x_2414 = args[1];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_x_2414));
  return (g_prelude_2e_2b_2b(v_t_2415, v_acc_2413));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam1(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_MkCArm: {
    V v_body_2433 = heff_field(v_x_2426, 6);
    heff_take_n(v_x_2426, 64ULL, 8);
    v_t_2435 = v_body_2433;
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V v_t_2436 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2435}));
  return (g_prelude_2e_2b_2b(v_t_2436, v_acc_2425));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam2(V self, V *args) {
  V v_acc_2442 = args[0];
  V v_x_2443 = args[1];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_x_2443));
  return (g_prelude_2e_2b_2b(v_t_2444, v_acc_2442));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam3(V self, V *args) {
  V v_acc_2448 = args[0];
  V v_x_2449 = args[1];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_x_2449));
  return (g_prelude_2e_2b_2b(v_t_2450, v_acc_2448));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam4(V self, V *args) {
  V v_acc_2454 = args[0];
  V v_x_2455 = args[1];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_x_2455));
  return (g_prelude_2e_2b_2b(v_t_2456, v_acc_2454));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam5(V self, V *args) {
  V v_acc_2460 = args[0];
  V v_x_2461 = args[1];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_x_2461));
  return (g_prelude_2e_2b_2b(v_t_2462, v_acc_2460));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam6(V self, V *args) {
  V v_acc_2467 = args[0];
  V v_x_2468 = args[1];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_x_2468));
  return (g_prelude_2e_2b_2b(v_t_2469, v_acc_2467));
}
V g_heff_2ecompile_2eowned_2esetsSt_lam7(V self, V *args) {
  V v_acc_2475 = args[0];
  V v_x_2476 = args[1];
  V v_us_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2477 = (g_heff_2ecompile_2eowned_2esetsIn(v_us_241, v_x_2476));
  return (g_prelude_2e_2b_2b(v_t_2477, v_acc_2475));
}
V g_heff_2ecompile_2eowned_2esetsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eowned_2esetsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2esetsOf_entry, 2, 0};

V g_heff_2ecompile_2eowned_2esetsOf(V v_us_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2esetsOf_clo), 1, (V[]){heff_dup(v_us_240)}));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_241));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eowned_2esetsOf_lam0, 2, 2, (V[]){v_t_242, v_us_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_heff_2ecompile_2eowned_2esetsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2esetsOf(a[0], a[1]);
}
V g_heff_2ecompile_2eowned_2esetsOf_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_t_242 = heff_env(self)[0];
  V v_us_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = (g_heff_2ecompile_2eowned_2esetsSt(v_t_242, v_us_240, v_x_245));
  return (g_prelude_2e_2b_2b(v_t_246, v_acc_244));
}
Clo g_heff_2ecompile_2eowned_2emapCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2emapCond_entry, 2, 0};

V g_heff_2ecompile_2eowned_2emapCond(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_CondFalse: {
    heff_drop(v_f_240);
    return v_x2_241;
  }
  case TAG_CondRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CondRel = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2emap(v_f_240, v_es_243));
    return heff_tag_at_n(v_ru_24x2_241_24CondRel, TAG_CondRel, 2, (V[]){v_p_242, v_t_244});
  }
  case TAG_CondRelU: {
    V v_p_245 = heff_field(v_x2_241, 0);
    V v_es_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CondRelU = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = (g_list_2emap(v_f_240, v_es_246));
    return heff_tag_at_n(v_ru_24x2_241_24CondRelU, TAG_CondRelU, 2, (V[]){v_p_245, v_t_247});
  }
  case TAG_CondBool: {
    V v_e_248 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CondBool = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_249 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_248}));
    return heff_tag_at_n(v_ru_24x2_241_24CondBool, TAG_CondBool, 1, (V[]){v_t_249});
  }
  case TAG_CondNot: {
    V v_c_2410 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CondNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24CondNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2412 = (g_heff_2ecompile_2eowned_2emapCond_24dps(v_f_240, v_c_2410, heff_dup(v_cell_2411), MK_INT(0LL)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  case TAG_CondIf: {
    V v_a_2413 = heff_field(v_x2_241, 0);
    V v_b_2414 = heff_field(v_x2_241, 1);
    V v_c_2415 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CondIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2eowned_2emapCond(heff_dup(v_f_240), v_a_2413));
    V v_t_2417 = (g_heff_2ecompile_2eowned_2emapCond(heff_dup(v_f_240), v_b_2414));
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_241_24CondIf, TAG_CondIf, 3, (V[]){v_t_2416, v_t_2417, heff_hole()});
    V v_u_2419 = (g_heff_2ecompile_2eowned_2emapCond_24dps(v_f_240, v_c_2415, heff_dup(v_cell_2418), MK_INT(2LL)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  case TAG_CondLet: {
    V v_x_2420 = heff_field(v_x2_241, 0);
    V v_e_2421 = heff_field(v_x2_241, 1);
    V v_c_2422 = heff_field(v_x2_241, 2);
    V v_ds_2423 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24CondLet = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2424 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_e_2421}));
    V v_t_2425 = (g_heff_2ecompile_2eowned_2emapCond(v_f_240, v_c_2422));
    return heff_tag_at_n(v_ru_24x2_241_24CondLet, TAG_CondLet, 4, (V[]){v_x_2420, v_t_2424, v_t_2425, v_ds_2423});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2emapCond(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_24dps_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_24dps_str1, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_24dps_str2, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2eowned_2eownExp_24dps_str3, 13, "arraySetOwned");
V g_heff_2ecompile_2eowned_2eownExp_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eowned_2eownExp_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2eowned_2eownExp_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownExp_24dps_entry, 4, 0};

V g_heff_2ecompile_2eowned_2eownExp_24dps(V v_us_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RDup: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RClo: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RGet: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RGetRaw: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RInt: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RFloat: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RStr: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RBytes: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RFixed: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RF32: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RNTag: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RTag: {
    V v_t_2417 = heff_field(v_x2_241, 0);
    V v_b_2418 = heff_field(v_x2_241, 1);
    V v_es_2419 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2421 = (g_list_2emap(v_t_2420, v_es_2419));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RTag, 3, (V[]){v_t_2417, v_b_2418, v_t_2421}));
  }
  case TAG_RTagIn: {
    V v_e_2422 = heff_field(v_x2_241, 0);
    V v_t_2423 = heff_field(v_x2_241, 1);
    V v_b_2424 = heff_field(v_x2_241, 2);
    V v_es_2425 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2426 = (g_heff_2ecompile_2eowned_2eownExp(heff_dup(v_us_240), v_e_2422));
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2428 = (g_list_2emap(v_t_2427, v_es_2425));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RTagIn, 4, (V[]){v_t_2426, v_t_2423, v_b_2424, v_t_2428}));
  }
  case TAG_RRec: {
    V v_ls_2429 = heff_field(v_x2_241, 0);
    V v_b_2430 = heff_field(v_x2_241, 1);
    V v_es_2431 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2433 = (g_list_2emap(v_t_2432, v_es_2431));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RRec, 3, (V[]){v_ls_2429, v_b_2430, v_t_2433}));
  }
  case TAG_RRecIn: {
    V v_x_2434 = heff_field(v_x2_241, 0);
    V v_n_2435 = heff_field(v_x2_241, 1);
    V v_k_2436 = heff_field(v_x2_241, 2);
    V v_f_2437 = heff_field(v_x2_241, 3);
    V v_s_2438 = heff_field(v_x2_241, 4);
    V v_ls_2439 = heff_field(v_x2_241, 5);
    V v_fs_2440 = heff_field(v_x2_241, 6);
    V v_sure_2441 = heff_field(v_x2_241, 7);
    heff_take_n(v_x2_241, 255ULL, 8);
    V v_t_2450 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eowned_2eownExp_24dps_lam0, 1, 1, (V[]){v_us_240}), v_fs_2440));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RRecIn, 8, (V[]){v_x_2434, v_n_2435, v_k_2436, v_f_2437, v_s_2438, v_ls_2439, v_t_2450, v_sure_2441}));
  }
  case TAG_RField: {
    V v_e_2451 = heff_field(v_x2_241, 0);
    V v_i_2452 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2453 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2451));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RField, 2, (V[]){v_t_2453, v_i_2452}));
  }
  case TAG_RDupE: {
    V v_e_2454 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24RDupE = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2455 = heff_tag_at_n(v_ru_24x2_241_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2456 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2455));
    heff_drop(v_u_2456);
    V t_0 = v_us_240;
    V t_1 = v_e_2454;
    V t_2 = v_cell_2455;
    V t_3 = MK_INT(0LL);
    v_us_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_RFieldV: {
    V v_e_2457 = heff_field(v_x2_241, 0);
    V v_i_2458 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2459 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2457));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RFieldV, 2, (V[]){v_t_2459, v_i_2458}));
  }
  case TAG_RGetN: {
    V v_e_2460 = heff_field(v_x2_241, 0);
    V v_i_2461 = heff_field(v_x2_241, 1);
    V v_n_2462 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2463 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2460));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RGetN, 3, (V[]){v_t_2463, v_i_2461, v_n_2462}));
  }
  case TAG_RFieldU: {
    V v_r_2464 = heff_field(v_x2_241, 0);
    V v_s_2465 = heff_field(v_x2_241, 1);
    V v_e_2466 = heff_field(v_x2_241, 2);
    V v_i_2467 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2468 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2466));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RFieldU, 4, (V[]){v_r_2464, v_s_2465, v_t_2468, v_i_2467}));
  }
  case TAG_RGetNU: {
    V v_r_2469 = heff_field(v_x2_241, 0);
    V v_s_2470 = heff_field(v_x2_241, 1);
    V v_e_2471 = heff_field(v_x2_241, 2);
    V v_i_2472 = heff_field(v_x2_241, 3);
    V v_n_2473 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 31ULL, 5);
    V v_t_2474 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2471));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RGetNU, 5, (V[]){v_r_2469, v_s_2470, v_t_2474, v_i_2472, v_n_2473}));
  }
  case TAG_RWord: {
    V v_r_2475 = heff_field(v_x2_241, 0);
    V v_e_2476 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RWord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2477 = heff_tag_at_n(v_ru_24x2_241_24RWord, TAG_RWord, 2, (V[]){v_r_2475, heff_hole()});
    V v_u_2478 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2477));
    heff_drop(v_u_2478);
    V t_0 = v_us_240;
    V t_1 = v_e_2476;
    V t_2 = v_cell_2477;
    V t_3 = MK_INT(1LL);
    v_us_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_RTakeField: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RGetLabel: {
    V v_e_2481 = heff_field(v_x2_241, 0);
    V v_l_2482 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2483 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_e_2481));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_2483, v_l_2482}));
  }
  case TAG_RPrimFn: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RPrim: {
    V v_p_2485 = heff_field(v_x2_241, 0);
    V v_es_2486 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RPrim = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2492;
    if (heff_strEq_c_lent(v_p_2485, ((V)&g_heff_2ecompile_2eowned_2eownExp_24dps_str0), 2)) {
      HeffT2 v_t_2487 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(heff_tag_at_n(v_ru_24x2_241_24RPrim, TAG_RPrim, 2, (V[]){heff_dup(v_p_2485), heff_dup(v_es_2486)})));
      {
        V v_field_2489 = v_t_2487.f[1];
        int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
        if ((v_tag_2488 == ((int64_t)0ULL))) {
          V v_x_2490 = v_field_2489;
          V v_t_2491 = ({ V a_0 = v_x_2490; V a_1 = v_us_240; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2490); r_; });
          if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
            heff_drop(v_p_2485);
            heff_drop(v_t_2491);
            v_t_2492 = ((V)&g_heff_2ecompile_2eowned_2eownExp_24dps_str1);
          } else {
            heff_drop(v_t_2491);
            v_t_2492 = v_p_2485;
          }
        } else {
          heff_drop(v_field_2489);
          v_t_2492 = v_p_2485;
        }
      }
    } else {
      heff_drop_cell(v_ru_24x2_241_24RPrim, 2);
      v_t_2492 = v_p_2485;
    }
    V v_t_2493 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_2494 = (g_list_2emap(v_t_2493, v_es_2486));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RPrim, 2, (V[]){v_t_2492, v_t_2494}));
  }
  case TAG_RLam: {
    V v_xs_2495 = heff_field(v_x2_241, 0);
    V v_fv_2496 = heff_field(v_x2_241, 1);
    V v_held_2497 = heff_field(v_x2_241, 2);
    V v_body_2498 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24100 = (g_list_2emap(v_t_2499, v_held_2497));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RLam, 4, (V[]){v_xs_2495, v_fv_2496, v_t_24100, v_body_2498}));
  }
  case TAG_RCall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_tr_24102 = heff_field(v_x2_241, 1);
    V v_w_24103 = heff_field(v_x2_241, 2);
    V v_args_24104 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_f_24105 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24116 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eowned_2eownExp_24dps_lam1, 1, 1, (V[]){v_f_24105}), v_args_24104));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RCall, 4, (V[]){v_g_24101, v_tr_24102, v_w_24103, v_t_24116}));
  }
  case TAG_RApply: {
    V v_f_24117 = heff_field(v_x2_241, 0);
    V v_es_24118 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RApply = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24119 = (g_heff_2ecompile_2eowned_2eownExp(heff_dup(v_us_240), v_f_24117));
    V v_t_24120 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24121 = (g_list_2emap_24tok2(v_ru_24x2_241_24RApply, v_t_24120, v_es_24118));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RApply, 2, (V[]){v_t_24119, v_t_24121}));
  }
  case TAG_RBool: {
    V v_c_24122 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24123 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24124 = (g_heff_2ecompile_2eowned_2emapCond(v_t_24123, v_c_24122));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RBool, 1, (V[]){v_t_24124}));
  }
  case TAG_RAbandon: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RBox: {
    V v_r_24125 = heff_field(v_x2_241, 0);
    V v_e_24126 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RBox = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_24127 = heff_tag_at_n(v_ru_24x2_241_24RBox, TAG_RBox, 2, (V[]){v_r_24125, heff_hole()});
    V v_u_24128 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_24127));
    heff_drop(v_u_24128);
    V t_0 = v_us_240;
    V t_1 = v_e_24126;
    V t_2 = v_cell_24127;
    V t_3 = MK_INT(1LL);
    v_us_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_RUnbox: {
    V v_r_24129 = heff_field(v_x2_241, 0);
    V v_e_24130 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RUnbox = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_24131 = heff_tag_at_n(v_ru_24x2_241_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_24129, heff_hole()});
    V v_u_24132 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_24131));
    heff_drop(v_u_24132);
    V t_0 = v_us_240;
    V t_1 = v_e_24130;
    V t_2 = v_cell_24131;
    V t_3 = MK_INT(1LL);
    v_us_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_RPeek: {
    V v_r_24133 = heff_field(v_x2_241, 0);
    V v_e_24134 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RPeek = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_24135 = heff_tag_at_n(v_ru_24x2_241_24RPeek, TAG_RPeek, 2, (V[]){v_r_24133, heff_hole()});
    V v_u_24136 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_24135));
    heff_drop(v_u_24136);
    V t_0 = v_us_240;
    V t_1 = v_e_24134;
    V t_2 = v_cell_24135;
    V t_3 = MK_INT(1LL);
    v_us_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_RPrimU: {
    V v_p_24137 = heff_field(v_x2_241, 0);
    V v_es_24138 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RPrimU = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24139 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24140 = (g_list_2emap_24tok2(v_ru_24x2_241_24RPrimU, v_t_24139, v_es_24138));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RPrimU, 2, (V[]){v_p_24137, v_t_24140}));
  }
  case TAG_RPrimAt: {
    V v_p_24141 = heff_field(v_x2_241, 0);
    V v_r_24142 = heff_field(v_x2_241, 1);
    V v_es_24143 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_24149;
    if (heff_strEq_c_lent(v_p_24141, ((V)&g_heff_2ecompile_2eowned_2eownExp_24dps_str2), 2)) {
      HeffT2 v_t_24144 = (g_heff_2ecompile_2eowned_2eheldOf_24cpr(heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(v_p_24141), heff_dup(v_es_24143)})));
      {
        V v_field_24146 = v_t_24144.f[1];
        int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
        if ((v_tag_24145 == ((int64_t)0ULL))) {
          V v_x_24147 = v_field_24146;
          V v_t_24148 = ({ V a_0 = v_x_24147; V a_1 = v_us_240; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_24147); r_; });
          if ((heff_dup(v_t_24148) == NTAG(TAG_True))) {
            heff_drop(v_p_24141);
            heff_drop(v_t_24148);
            v_t_24149 = ((V)&g_heff_2ecompile_2eowned_2eownExp_24dps_str3);
          } else {
            heff_drop(v_t_24148);
            v_t_24149 = v_p_24141;
          }
        } else {
          heff_drop(v_field_24146);
          v_t_24149 = v_p_24141;
        }
      }
    } else {
      v_t_24149 = v_p_24141;
    }
    V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_240}));
    V v_t_24151 = (g_list_2emap(v_t_24150, v_es_24143));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_RPrimAt, 3, (V[]){v_t_24149, v_r_24142, v_t_24151}));
  }
  case TAG_RFixU: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RF32U: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_RF64U: {
    heff_drop(v_us_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eowned_2eownExp_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownExp_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eowned_2eownExp_24dps_lam0(V self, V *args) {
  V v_p_2442 = args[0];
  V v_us_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445;
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_dup(heff_field(v_p_2442, 0));
    v_t_2445 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_p_2442);
  }
  V v_t_2448;
  switch (heff_tag_of(v_p_2442)) {
  case TAG_MkPair: {
    V v_y_2447 = heff_field(v_p_2442, 1);
    heff_take_n(v_p_2442, 2ULL, 2);
    v_t_2448 = v_y_2447;
    break;
  }
  default: heff_nomatch(v_p_2442);
  }
  V v_t_2449 = (g_heff_2ecompile_2eowned_2eownExp(v_us_240, v_t_2448));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_t_2449});
}
V g_heff_2ecompile_2eowned_2eownExp_24dps_lam1(V self, V *args) {
  V v_a_24106 = args[0];
  V v_f_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24106)) {
  case TAG_Given: {
    V v_e_24107 = heff_field(v_a_24106, 0);
    V v_ru_24a_24106_24Given = heff_take_reuse_n(v_a_24106, 1ULL, 1);
    V v_t_24108 = heff_tr(heff_call(v_f_24105, 1, (V[]){v_e_24107}));
    return heff_tag_at_n(v_ru_24a_24106_24Given, TAG_Given, 1, (V[]){v_t_24108});
  }
  case TAG_GivenU: {
    V v_r_24109 = heff_field(v_a_24106, 0);
    V v_e_24110 = heff_field(v_a_24106, 1);
    V v_ru_24a_24106_24GivenU = heff_take_reuse_n(v_a_24106, 3ULL, 2);
    V v_t_24111 = heff_tr(heff_call(v_f_24105, 1, (V[]){v_e_24110}));
    return heff_tag_at_n(v_ru_24a_24106_24GivenU, TAG_GivenU, 2, (V[]){v_r_24109, v_t_24111});
  }
  case TAG_LentVar: {
    heff_drop(v_f_24105);
    return v_a_24106;
  }
  case TAG_LentValue: {
    V v_e_24114 = heff_field(v_a_24106, 0);
    V v_ru_24a_24106_24LentValue = heff_take_reuse_n(v_a_24106, 1ULL, 1);
    V v_t_24115 = heff_tr(heff_call(v_f_24105, 1, (V[]){v_e_24114}));
    return heff_tag_at_n(v_ru_24a_24106_24LentValue, TAG_LentValue, 1, (V[]){v_t_24115});
  }
  default: return heff_nomatch(v_a_24106);
  }
}
V g_heff_2ecompile_2eowned_2eownSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2eowned_2eownSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownSt_entry, 3, 0};

V g_heff_2ecompile_2eowned_2eownSt(V v_go_240, V v_us_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_CDrop: {
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return v_s_242;
  }
  case TAG_CLet: {
    V v_x_244 = heff_field(v_s_242, 0);
    V v_e_245 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CLet = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_246 = (g_heff_2ecompile_2eowned_2eownExp(v_us_241, v_e_245));
    return heff_tag_at_n(v_ru_24s_242_24CLet, TAG_CLet, 2, (V[]){v_x_244, v_t_246});
  }
  case TAG_CDecl: {
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return v_s_242;
  }
  case TAG_CSet: {
    V v_x_248 = heff_field(v_s_242, 0);
    V v_e_249 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CSet = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2410 = (g_heff_2ecompile_2eowned_2eownExp(v_us_241, v_e_249));
    return heff_tag_at_n(v_ru_24s_242_24CSet, TAG_CSet, 2, (V[]){v_x_248, v_t_2410});
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return v_s_242;
  }
  case TAG_CIf: {
    V v_c_2411 = heff_field(v_s_242, 0);
    V v_a_2412 = heff_field(v_s_242, 1);
    V v_b_2413 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CIf = heff_take_reuse_n(v_s_242, 7ULL, 3);
    V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_241}));
    V v_t_2415 = (g_heff_2ecompile_2eowned_2emapCond(v_t_2414, v_c_2411));
    V v_t_2416 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_2412}));
    V v_t_2417 = heff_tr(heff_call(v_go_240, 1, (V[]){v_b_2413}));
    return heff_tag_at_n(v_ru_24s_242_24CIf, TAG_CIf, 3, (V[]){v_t_2415, v_t_2416, v_t_2417});
  }
  case TAG_CSwitch: {
    V v_e_2418 = heff_field(v_s_242, 0);
    V v_arms_2419 = heff_field(v_s_242, 1);
    V v_r_2420 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CSwitch = heff_take_reuse_n(v_s_242, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2eowned_2eownExp(v_us_241, v_e_2418));
    V v_t_2432 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eowned_2eownSt_lam0, 1, 1, (V[]){v_go_240}), v_arms_2419));
    return heff_tag_at_n(v_ru_24s_242_24CSwitch, TAG_CSwitch, 3, (V[]){v_t_2421, v_t_2432, v_r_2420});
  }
  case TAG_CReturn: {
    V v_e_2433 = heff_field(v_s_242, 0);
    V v_ru_24s_242_24CReturn = heff_take_reuse_n(v_s_242, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_2434 = (g_heff_2ecompile_2eowned_2eownExp(v_us_241, v_e_2433));
    return heff_tag_at_n(v_ru_24s_242_24CReturn, TAG_CReturn, 1, (V[]){v_t_2434});
  }
  case TAG_CInPlace: {
    V v_f_2435 = heff_field(v_s_242, 0);
    V v_es_2436 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CInPlace = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2437 = (g_heff_2ecompile_2eowned_2eownExp(heff_dup(v_us_241), v_f_2435));
    V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_241}));
    V v_t_2439 = (g_list_2emap(v_t_2438, v_es_2436));
    return heff_tag_at_n(v_ru_24s_242_24CInPlace, TAG_CInPlace, 2, (V[]){v_t_2437, v_t_2439});
  }
  case TAG_CRoomed: {
    V v_f_2440 = heff_field(v_s_242, 0);
    V v_es_2441 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CRoomed = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2442 = (g_heff_2ecompile_2eowned_2eownExp(heff_dup(v_us_241), v_f_2440));
    V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_241}));
    V v_t_2444 = (g_list_2emap(v_t_2443, v_es_2441));
    return heff_tag_at_n(v_ru_24s_242_24CRoomed, TAG_CRoomed, 2, (V[]){v_t_2442, v_t_2444});
  }
  case TAG_CTail: {
    V v_f_2445 = heff_field(v_s_242, 0);
    V v_es_2446 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CTail = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2447 = (g_heff_2ecompile_2eowned_2eownExp(heff_dup(v_us_241), v_f_2445));
    V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_241}));
    V v_t_2449 = (g_list_2emap(v_t_2448, v_es_2446));
    return heff_tag_at_n(v_ru_24s_242_24CTail, TAG_CTail, 2, (V[]){v_t_2447, v_t_2449});
  }
  case TAG_CLoop: {
    V v_ps_2450 = heff_field(v_s_242, 0);
    V v_es_2451 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CLoop = heff_take_reuse_n(v_s_242, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2452 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_241}));
    V v_t_2453 = (g_list_2emap(v_t_2452, v_es_2451));
    return heff_tag_at_n(v_ru_24s_242_24CLoop, TAG_CLoop, 2, (V[]){v_ps_2450, v_t_2453});
  }
  case TAG_CLoopTo: {
    V v_t_2454 = heff_field(v_s_242, 0);
    V v_ps_2455 = heff_field(v_s_242, 1);
    V v_es_2456 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CLoopTo = heff_take_reuse_n(v_s_242, 7ULL, 3);
    heff_drop(v_go_240);
    V v_t_2457 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_241}));
    V v_t_2458 = (g_list_2emap(v_t_2457, v_es_2456));
    return heff_tag_at_n(v_ru_24s_242_24CLoopTo, TAG_CLoopTo, 3, (V[]){v_t_2454, v_ps_2455, v_t_2458});
  }
  case TAG_CLabel: {
    heff_drop(v_go_240);
    heff_drop(v_us_241);
    return v_s_242;
  }
  case TAG_CJump: {
    V v_g_2460 = heff_field(v_s_242, 0);
    V v_w_2461 = heff_field(v_s_242, 1);
    V v_es_2462 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CJump = heff_take_reuse_n(v_s_242, 7ULL, 3);
    heff_drop(v_go_240);
    V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownExp_clo), 1, (V[]){v_us_241}));
    V v_t_2464 = (g_list_2emap(v_t_2463, v_es_2462));
    return heff_tag_at_n(v_ru_24s_242_24CJump, TAG_CJump, 3, (V[]){v_g_2460, v_w_2461, v_t_2464});
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2eowned_2eownSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownSt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eowned_2eownSt_lam0(V self, V *args) {
  V v_x2_2422 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkCArm: {
    V v_t_2423 = heff_field(v_x2_2422, 0);
    V v_fs_2424 = heff_field(v_x2_2422, 1);
    V v_fl_2425 = heff_field(v_x2_2422, 2);
    V v_su_2426 = heff_field(v_x2_2422, 3);
    V v_pl_2427 = heff_field(v_x2_2422, 4);
    V v_tk_2428 = heff_field(v_x2_2422, 5);
    V v_body_2429 = heff_field(v_x2_2422, 6);
    V v_lv_2430 = heff_field(v_x2_2422, 7);
    V v_ru_24x2_2422_24MkCArm = heff_take_reuse_n(v_x2_2422, 255ULL, 8);
    V v_t_2431 = heff_tr(heff_call(v_go_240, 1, (V[]){v_body_2429}));
    return heff_tag_at_n(v_ru_24x2_2422_24MkCArm, TAG_MkCArm, 8, (V[]){v_t_2423, v_fs_2424, v_fl_2425, v_su_2426, v_pl_2427, v_tk_2428, v_t_2431, v_lv_2430});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
Clo g_heff_2ecompile_2eowned_2eownStmts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownStmts_entry, 2, 0};

V g_heff_2ecompile_2eowned_2eownStmts(V v_us_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eowned_2eownStmts_clo), 1, (V[]){heff_dup(v_us_240)}));
  return (g_list_2emap_24s1688354384x1781591142(v_t_242, v_us_240, v_ss_241));
}
V g_heff_2ecompile_2eowned_2eownStmts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownStmts(a[0], a[1]);
}
Clo g_heff_2ecompile_2eowned_2eownedChain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2eownedChain_entry, 4, 0};

V g_heff_2ecompile_2eowned_2eownedChain(V v_f_240, V v_j_241, V v_x_242, V v_us_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eowned_2eokStmts(heff_dup(v_us_243), v_j_241, heff_rfield(v_f_240, 4)));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_x1_245 = (g_heff_2ecompile_2eowned_2esetsOf(heff_dup(v_us_243), heff_dup(heff_rfield(v_f_240, 4))));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_us_243);
      return v_f_240;
    }
    case TAG_Cons: {
      V v_r_246 = heff_field(v_x1_245, 0);
      V v_rs_247 = heff_field(v_x1_245, 1);
      V v_ru_24x1_245_24Cons = heff_take_reuse_n(v_x1_245, 3ULL, 2);
      V v_t_248 = ({ V a_0 = v_r_246; V a_1 = v_rs_247; V r_ = (g_list_2eall_24s335630579x1560445122(a_0, a_1)); heff_drop(v_rs_247); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = (g_heff_2ecompile_2eowned_2eownCheck(v_x_242, v_r_246));
        V v_t_2410 = heff_tag_at_n(v_ru_24x1_245_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
        V v_t_2411 = (g_prelude_2e_2b_2b(heff_take_field(v_f_240, 3), v_t_2410));
        V v_t_2412 = (g_heff_2ecompile_2eowned_2eownStmts(v_us_243, heff_take_field(v_f_240, 4)));
        return ({ V rv_3 = v_t_2411; V rv_4 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_f_240, 231ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      } else {
        heff_drop(v_x_242);
        heff_drop(v_us_243);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x1_245_24Cons, 2);
        heff_drop(v_t_248);
        return v_f_240;
      }
    }
    default: return heff_nomatch(v_x1_245);
    }
  } else {
    heff_drop(v_x_242);
    heff_drop(v_us_243);
    heff_drop(v_t_244);
    return v_f_240;
  }
}
V g_heff_2ecompile_2eowned_2eownedChain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2eownedChain(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps_entry, 3, 0};

V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps(V v_x2_240, V v_d_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_CondTrue: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_CondFalse: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_CondRel: {
    V v_p_243 = heff_field(v_x2_240, 0);
    V v_es_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_list_2emap_24s1354671438x1264137843(v_es_244));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondRel, 2, (V[]){v_p_243, v_t_245}));
  }
  case TAG_CondRelU: {
    V v_p_246 = heff_field(v_x2_240, 0);
    V v_es_247 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_248 = (g_list_2emap_24s1354671438x1264137843(v_es_247));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_246, v_t_248}));
  }
  case TAG_CondBool: {
    V v_e_249 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2410 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_249));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondBool, 1, (V[]){v_t_2410}));
  }
  case TAG_CondNot: {
    V v_c_2411 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24CondNot = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24CondNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2413 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_c_2411;
    V t_1 = v_cell_2412;
    V t_2 = MK_INT(0LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_c_2416 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24CondIf = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2417 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_a_2414));
    V v_t_2418 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_b_2415));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24CondIf, TAG_CondIf, 3, (V[]){v_t_2417, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_c_2416;
    V t_1 = v_cell_2419;
    V t_2 = MK_INT(2LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_CondLet: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_e_2422 = heff_field(v_x2_240, 1);
    V v_c_2423 = heff_field(v_x2_240, 2);
    V v_ds_2424 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2425 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2422));
    V v_t_2426 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_c_2423));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2421, v_t_2425, v_t_2426, v_ds_2424}));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_entry, 1, 0};

V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_CondTrue: {
    return v_x2_240;
  }
  case TAG_CondFalse: {
    return v_x2_240;
  }
  case TAG_CondRel: {
    V v_p_241 = heff_field(v_x2_240, 0);
    V v_es_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24CondRel = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_list_2emap_24s391650521x1406868658(v_es_242));
    return heff_tag_at_n(v_ru_24x2_240_24CondRel, TAG_CondRel, 2, (V[]){v_p_241, v_t_243});
  }
  case TAG_CondRelU: {
    V v_p_244 = heff_field(v_x2_240, 0);
    V v_es_245 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24CondRelU = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246 = (g_list_2emap_24s391650521x1406868658(v_es_245));
    return heff_tag_at_n(v_ru_24x2_240_24CondRelU, TAG_CondRelU, 2, (V[]){v_p_244, v_t_246});
  }
  case TAG_CondBool: {
    V v_e_247 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24CondBool = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_248 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_247));
    return heff_tag_at_n(v_ru_24x2_240_24CondBool, TAG_CondBool, 1, (V[]){v_t_248});
  }
  case TAG_CondNot: {
    V v_c_249 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24CondNot = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24CondNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2411 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps(v_c_249, heff_dup(v_cell_2410), MK_INT(0LL)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_CondIf: {
    V v_a_2412 = heff_field(v_x2_240, 0);
    V v_b_2413 = heff_field(v_x2_240, 1);
    V v_c_2414 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24CondIf = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2415 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_a_2412));
    V v_t_2416 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_b_2413));
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24CondIf, TAG_CondIf, 3, (V[]){v_t_2415, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_24dps(v_c_2414, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  case TAG_CondLet: {
    V v_x_2419 = heff_field(v_x2_240, 0);
    V v_e_2420 = heff_field(v_x2_240, 1);
    V v_c_2421 = heff_field(v_x2_240, 2);
    V v_ds_2422 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24CondLet = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2423 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2420));
    V v_t_2424 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_c_2421));
    return heff_tag_at_n(v_ru_24x2_240_24CondLet, TAG_CondLet, 4, (V[]){v_x_2419, v_t_2423, v_t_2424, v_ds_2422});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(a[0]);
}