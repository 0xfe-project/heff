// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ATail 47533
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DVal 23084
#define TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187 7242
#define TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565 57410
#define TAG_FlatAll 51900
#define TAG_FlatNone 33150
#define TAG_FlatSome 51022
#define TAG_Given 9359
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_MkCArm 24694
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RCall 39004
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RLocal 34280
#define TAG_RPrim 49376
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_key 315609
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2erefcount_2eapplyLast(V, V, V);
V g_heff_2ecompile_2erefcount_2eapplyLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eapplyLast_clo;
V g_heff_2ecompile_2erefcount_2eapplyLast_24tok1(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eapplyLast_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eapplyLast_24tok1_clo;
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2eboolName_get(void);
V g_heff_2ecompile_2erefcount_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallAs_clo;
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(V, V, V);
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3_clo;
HeffT2 g_heff_2ecompile_2erefcount_2edeclRun_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_clo;
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_24tok2_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2eelementRepr(V, V);
V g_heff_2ecompile_2erefcount_2eelementRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelementRepr_clo;
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461_clo;
V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_clo;
V g_heff_2ecompile_2erefcount_2eflatOnes(V, V, V);
V g_heff_2ecompile_2erefcount_2eflatOnes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatOnes_clo;
V g_heff_2ecompile_2erefcount_2eflatnessOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvRest(V, V);
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvRest_clo;
V g_heff_2ecompile_2erefcount_2efvSts(V);
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_clo;
V g_heff_2ecompile_2erefcount_2efvSts_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvSts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvSts_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvTl(V);
V g_heff_2ecompile_2erefcount_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_clo;
V g_heff_2ecompile_2erefcount_2efvTl_24tok1(V, V);
V g_heff_2ecompile_2erefcount_2efvTl_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvTl_24tok1_clo;
V g_heff_2ecompile_2erefcount_2efvVal(V);
V g_heff_2ecompile_2erefcount_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvVal_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2egoneOne(V, V, V);
V g_heff_2ecompile_2erefcount_2egoneOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2egoneOne_clo;
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentField(V, V, V);
V g_heff_2ecompile_2erefcount_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentField_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo;
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epeekOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekOf_clo;
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void);
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo;
V g_heff_2ecompile_2erefcount_2ereusePrim_get(void);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo;
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo;
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalRc(V, V, V);
V g_heff_2ecompile_2erefcount_2evalRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalRc_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s826961155x1314392429(V, V);
V g_list_2efoldl_24s826961155x1314392429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s826961155x1314392429_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f408128283x2136699628(V, V);
V g_list_2emap_24f408128283x2136699628_entry(V self, V *a);
extern Clo g_list_2emap_24f408128283x2136699628_clo;
V g_list_2emap_24s1341404685x1564972929(V);
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s698037429x265256386(V);
V g_list_2emap_24s698037429x265256386_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1572068627x1632985590(V, V);
V g_prelude_2e_2b_2b_24f1572068627x1632985590_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1572068627x1632985590_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2efvSts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvSts_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvSts(V v_ss_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_240}), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_bs_245 = v_field_243;
    V v_ms_246 = v_field_244;
    V v_bs_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_245));
    V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_246));
    V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_247; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_bs_247); r_; });
    return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  }
}
V g_heff_2ecompile_2erefcount_2efvSts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvSts(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, v_j_242, 0)) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eelemI(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2elentField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2elentField_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2elentField(V v_ce_240, V v_after_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SVar: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SInt: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFloat: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SStr: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SBytes: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFixed: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFloat32: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrimFn: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    V v_e_2420 = heff_field(v_x3_242, 0);
    V v_l_2421 = heff_field(v_x3_242, 1);
    V v_sh_2422 = heff_field(v_x3_242, 2);
    V v_t_2423 = heff_field(v_x3_242, 3);
    V v_t_2424 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_2423));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_t_2424);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2424);
      HeffT2 v_t_2425 = (g_heff_2ecompile_2erefcount_2eindexIn_24cpr(v_l_2421, MK_INT(0LL), heff_dup(v_sh_2422)));
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        switch (heff_tag_of(v_e_2420)) {
        case TAG_SVar: {
          V v_x_2428 = heff_field(v_e_2420, 0);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_i_2429 = v_field_2427;
            V v_t_2430 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2428, v_after_241));
            if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
              heff_drop_rec(v_ce_240, 17);
              heff_drop(v_t_2430);
              V v_t_2431 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){heff_dup(v_x_2428)}), v_i_2429});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
            } else {
              heff_drop(v_t_2430);
              V v_t_2432 = ({ V a_0 = v_x_2428; V b_1 = heff_get_n(v_ce_240, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
              if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
                heff_drop(v_t_2432);
                V v_t_2433 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){heff_dup(v_x_2428)}), v_i_2429});
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2433});
              } else {
                heff_drop(v_i_2429);
                heff_drop(v_t_2432);
                return NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop_rec(v_ce_240, 17);
            heff_drop(v_field_2427);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_SGlobal: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SInt: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFloat: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SStr: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SBytes: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFixed: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFloat32: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrimFn: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_drop_rec(v_ce_240, 17);
          heff_drop(v_field_2427);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_e_2420);
        }
      }
    }
  }
  case TAG_SPrim: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2elentField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2elentField(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ejustsOf_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epow2_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2epow2(V v_n_240) {
top: ;
  if (heff_intEq_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2ecompile_2erefcount_2epow2(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2epow2(a[0]);
}
V g_heff_2ecompile_2erefcount_2eflatOnes_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2eflatOnes_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eflatOnes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eflatOnes_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eflatOnes(V v_ce_240, V v_ps_241, V v_ws_242) {
top: ;
  V v_t_247 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2eflatOnes_lam0, 1, 1, (V[]){heff_dup(v_ps_241)}), v_ws_242));
  return (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2eflatOnes_lam1, 1, 1, (V[]){v_ce_240}), v_t_247));
}
V g_heff_2ecompile_2erefcount_2eflatOnes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eflatOnes(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eflatOnes_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_ps_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_245 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_t_246 = v_y_245;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  return ({ V a_0 = v_t_246; V a_1 = v_ps_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemI(a_0, a_1)); heff_drop(v_ps_241); r_; });
}
V g_heff_2ecompile_2erefcount_2eflatOnes_lam1(V self, V *args) {
  V v_p_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_dup(heff_field(v_p_248, 0));
    v_t_2411 = v_x_249;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_dup(heff_field(v_p_248, 1));
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2417;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 2);
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  HeffT2 v_t_2418 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_t_2417; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2417); r_; });
  V v_t_2422;
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2420;
      v_t_2422 = v_x_2421;
    } else {
      heff_drop(v_field_2420);
      v_t_2422 = NTAG(TAG_RepV);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2422})});
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eflatnessOf_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eflatnessOf(V v_x1_240, V v_su_241, V v_mask_242, V v_n_243) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_243, MK_INT(1LL))));
    V v_t_248 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2eflatnessOf_lam0, 1, 2, (V[]){v_mask_242, heff_dup(v_su_241)}); V a_1 = v_t_244; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_244); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_FlatAll);
    } else {
      heff_drop(v_t_248);
      return NTAG(TAG_FlatSome);
    }
  } else {
    heff_drop(v_mask_242);
    heff_drop(v_n_243);
    return NTAG(TAG_FlatNone);
  }
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eflatnessOf(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_mask_242 = heff_env(self)[0];
  V v_su_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_245)));
  V v_t_247 = heff_intMod(heff_intDiv(v_mask_242, v_t_246), MK_INT(2LL));
  if ((heff_unbox_word(v_t_247) == ((int64_t)1ULL))) {
    heff_drop(v_i_245);
    heff_drop(v_su_241);
    return NTAG(TAG_True);
  } else {
    return ({ V a_0 = v_i_245; V a_1 = v_su_241; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_su_241); r_; });
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2epeekPrim_str0, 9, "arrayPeek");

static V g_heff_2ecompile_2erefcount_2epeekPrim_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2epeekPrim_st;
static V g_heff_2ecompile_2erefcount_2epeekPrim_init(void) {
  return ((V)&g_heff_2ecompile_2erefcount_2epeekPrim_str0);
}
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2epeekPrim_st)) return g_heff_2ecompile_2erefcount_2epeekPrim_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2epeekPrim_val, &g_heff_2ecompile_2erefcount_2epeekPrim_st, g_heff_2ecompile_2erefcount_2epeekPrim_init);
}
V g_heff_2ecompile_2erefcount_2egoneOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2egoneOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2egoneOne_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2egoneOne(V v_go_240, V v_acc_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_CDrop: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CLet: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CDecl: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CSet: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CIf: {
    V v_a_2410 = heff_field(v_s_242, 1);
    V v_b_2411 = heff_field(v_s_242, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_acc_241, heff_dup(v_a_2410)}));
    return heff_tail(v_go_240, 2, (V[]){v_t_2412, heff_dup(v_b_2411)});
  }
  case TAG_CSwitch: {
    V v_arms_2414 = heff_field(v_s_242, 1);
    HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erefcount_2egoneOne_lam0, 2, 1, (V[]){v_go_240}), v_acc_241, v_arms_2414);
  }
  case TAG_CReturn: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CInPlace: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CRoomed: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CTail: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CLoop: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CLoopTo: {
    V v_t_2436 = heff_field(v_s_242, 0);
    heff_drop(v_go_240);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_t_2436), v_acc_241});
  }
  case TAG_CLabel: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CJump: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2erefcount_2egoneOne_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2egoneOne(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2egoneOne_lam0(V self, V *args) {
  V v_a_2416 = args[0];
  V v_arm_2417 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_arm_2417)) {
  case TAG_MkCArm: {
    V v_body_2424 = heff_field(v_arm_2417, 6);
    heff_take_n(v_arm_2417, 64ULL, 8);
    v_t_2426 = v_body_2424;
    break;
  }
  default: heff_nomatch(v_arm_2417);
  }
  V f_ = v_go_240;
  args[0] = v_a_2416;
  args[1] = v_t_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_x5_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_245 = heff_field(v_x4_242, 0);
    V v_rps_246 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x5_243)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_rp_245);
      heff_drop(v_rps_246);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_247 = heff_field(v_x5_243, 0);
      V v_es_248 = heff_field(v_x5_243, 1);
      V v_ru_24x5_243_24Cons = heff_take_reuse_n(v_x5_243, 3ULL, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_248)));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_249); r_; });
      V v_live_2411 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x5_243_24Cons, v_t_2410, heff_dup(v_live_241)));
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2411, v_rp_245, v_e_247));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_rps_246;
      V t_3 = v_es_248;
      V t_4 = v_cell_2413;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_x4_242 = t_2;
      v_x5_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x5_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V v_ce_240, V v_live_241, V v_p_242, V v_argv_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nothing: {
    if (heff_strEq_c(heff_dup(v_p_242), heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()))) {
      heff_drop(v_p_242);
      return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_argv_243; V r_ = (g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(a_0, a_1, a_2)); heff_drop(v_argv_243); r_; });
    } else {
      V v_t_245 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_243));
      return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_242, v_t_245});
    }
  }
  case TAG_Just: {
    V v_e_246 = heff_field(v_x6_244, 0);
    V v_ru_24x6_244_24Just = heff_take_reuse_n(v_x6_244, 1ULL, 1);
    HeffT3 v_t_247 = (g_list_2edrop_24cpr(heff_dup(v_e_246), v_argv_243));
    V v_t_2413;
    {
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x6_244_24Just, 1);
        V v_x_2411 = v_field_249;
        V v_x12_2412 = v_field_2410;
        heff_drop(v_x12_2412);
        v_t_2413 = v_x_2411;
      } else {
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        v_t_2413 = heff_tag_at_n(v_ru_24x6_244_24Just, TAG_SInt, 1, (V[]){MK_INT(0LL)});
      }
    }
    V v_t_2414 = (g_heff_2ecompile_2erefcount_2eelementRepr(heff_dup(v_ce_240), v_t_2413));
    return (g_heff_2ecompile_2erefcount_2eelementVal_24s459561160x272892461(v_ce_240, v_live_241, v_p_242, v_argv_243, v_e_246, v_t_2414));
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775(V v_ce_240, V v_live_241, V v_e_242, V v_rp_243, V v_su_244, V v_i_245, V v_n_246, V v_x9_247, V v_x10_248) {
top: ;
  switch (heff_tag_of(v_x9_247)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_x10_248)) {
    case TAG_Nothing: {
      V v_t_249 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
      return heff_tag_n(TAG_RGetNU, 5, (V[]){v_rp_243, v_su_244, v_t_249, v_i_245, v_n_246});
    }
    case TAG_Just: {
      V v_g_2410 = heff_field(v_x10_248, 0);
      V v_ru_24x10_248_24Just = heff_take_reuse_n(v_x10_248, 1ULL, 1);
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_246);
      return heff_tag_n(TAG_RFieldU, 4, (V[]){v_rp_243, v_su_244, heff_tag_at_n(v_ru_24x10_248_24Just, TAG_RGetRaw, 1, (V[]){v_g_2410}), v_i_245});
    }
    default: return heff_nomatch(v_x10_248);
    }
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x9_247, 0);
    V v_ru_24x9_247_24Just = heff_take_reuse_n(v_x9_247, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_x10_248);
    V v_t_2412 = ({ V a_0 = v_x_2411; V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_n_246);
      heff_drop(v_t_2412);
      return heff_tag_n(TAG_RFieldU, 4, (V[]){v_rp_243, v_su_244, heff_tag_at_n(v_ru_24x9_247_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_245});
    } else {
      heff_drop(v_t_2412);
      V v_t_2413 = ({ V a_0 = v_x_2411; V b_1 = heff_get_n(v_ce_240, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_n_246);
        heff_drop(v_t_2413);
        return heff_tag_n(TAG_RFieldU, 4, (V[]){v_rp_243, v_su_244, heff_tag_at_n(v_ru_24x9_247_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_245});
      } else {
        heff_drop(v_t_2413);
        return heff_tag_n(TAG_RGetNU, 5, (V[]){v_rp_243, v_su_244, heff_tag_at_n(v_ru_24x9_247_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_245, v_n_246});
      }
    }
  }
  default: return heff_nomatch(v_x9_247);
  }
}
V g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efieldNum_24s1371969882x2095179775(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V v_ce_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_CondTrue);
  }
  case TAG_PFalse: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_CondFalse);
  }
  case TAG_PRel: {
    V v_p_242 = heff_field(v_x3_241, 0);
    V v_a_243 = heff_field(v_x3_241, 1);
    V v_b_244 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_245 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_sh_248 = v_field_247;
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, NTAG(TAG_Nil)});
        V v_t_2410 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, NTAG(TAG_Nil), heff_get_n(v_sh_248, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_t_249})));
        return heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_242, v_t_2410});
      } else {
        heff_drop(v_field_247);
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, NTAG(TAG_Nil)});
        V v_t_2412 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_t_2411})));
        return heff_tag_n(TAG_CondRel, 2, (V[]){v_p_242, v_t_2412});
      }
    }
  }
  case TAG_PBool: {
    V v_v_2413 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PBool = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_2414 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_2413));
    return heff_tag_at_n(v_ru_24x3_241_24PBool, TAG_CondBool, 1, (V[]){v_t_2414});
  }
  case TAG_PNot: {
    V v_c_2415 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PNot = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_2416 = heff_tag_at_n(v_ru_24x3_241_24PNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2417 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(v_ce_240, v_c_2415, heff_dup(v_cell_2416), MK_INT(0LL)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  case TAG_PIf: {
    V v_a_2418 = heff_field(v_x3_241, 0);
    V v_b_2419 = heff_field(v_x3_241, 1);
    V v_c_2420 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24PIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_a_2418));
    V v_t_2422 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_b_2419));
    V v_cell_2423 = heff_tag_at_n(v_ru_24x3_241_24PIf, TAG_CondIf, 3, (V[]){v_t_2421, v_t_2422, heff_hole()});
    V v_u_2424 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(v_ce_240, v_c_2420, heff_dup(v_cell_2423), MK_INT(2LL)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  case TAG_PLet: {
    V v_x_2425 = heff_field(v_x3_241, 0);
    V v_o_2426 = heff_field(v_x3_241, 1);
    V v_c_2427 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_2428 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 10), v_x_2425));
    V v_t_2433;
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      V v_t_2432;
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_x_2431 = v_field_2430;
        v_t_2432 = v_x_2431;
      } else {
        heff_drop(v_field_2430);
        v_t_2432 = NTAG(TAG_RepV);
      }
      v_t_2433 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2432, v_o_2426));
    }
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), heff_dup(heff_rfield(v_ce_240, 6))});
    V v_t_2435 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2434, heff_dup(v_ce_240)));
    V v_t_2436 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2435, v_c_2427));
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
    V v_t_2443 = (g_list_2emap_24f408128283x2136699628(heff_clo_n(g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_lam0, 1, 1, (V[]){v_ce_240}), v_t_2437));
    return heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2425, v_t_2433, v_t_2436, v_t_2443});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_lam0(V self, V *args) {
  V v_x_2438 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2439 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2438; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2438); r_; });
  {
    V v_field_2441 = v_t_2439.f[1];
    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2440 == ((int64_t)0ULL)) ? ({ V v_x_2442 = heff_dup(v_field_2441); int c_ = 0; heff_drop(v_x_2442); c_; }) : 1));
    heff_drop(v_field_2441);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_v_243));
  }
  case TAG_OCall: {
    V v_g_244 = heff_field(v_x4_242, 0);
    V v_argv_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_ce_240, 1), v_g_244));
    V v_t_2410;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      v_t_2410 = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_249); c_; })));
      heff_drop(v_field_248);
    }
    HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_244));
    V v_t_2415;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2413;
        v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2414, 1, 2)});
      } else {
        heff_drop(v_field_2413);
        v_t_2415 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2416 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 7), v_g_244));
    V v_t_2420;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_x_2419 = v_field_2418;
        v_t_2420 = v_x_2419;
      } else {
        heff_drop(v_field_2418);
        v_t_2420 = NTAG(TAG_Nil);
      }
    }
    HeffT2 v_t_2421 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_244));
    V v_t_2425;
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_s_2424 = v_field_2423;
        v_t_2425 = heff_get_n(v_s_2424, 0, 2);
      } else {
        heff_drop(v_field_2423);
        v_t_2425 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_argv_245)));
      }
    }
    V v_t_2426 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2420; V a_4 = MK_INT(0LL); V a_5 = v_t_2425; V a_6 = v_argv_245; V r_ = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2420); r_; });
    return heff_tag_n(TAG_RCall, 4, (V[]){v_g_244, v_t_2410, v_t_2415, v_t_2426});
  }
  case TAG_OApply: {
    V v_f_2427 = heff_field(v_x4_242, 0);
    V v_argv_2428 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OApply = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2429 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24x4_242_24OApply, TAG_Cons, 2, (V[]){v_f_2427, v_argv_2428})));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nil: {
      return NTAG(TAG_RAbandon);
    }
    case TAG_Cons: {
      V v_fv_2430 = heff_field(v_t_2429, 0);
      V v_vs_2431 = heff_field(v_t_2429, 1);
      V v_ru_24t_2429_24Cons = heff_take_reuse_n(v_t_2429, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2429_24Cons, TAG_RApply, 2, (V[]){v_fv_2430, v_vs_2431});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_OPrim: {
    V v_p_2432 = heff_field(v_x4_242, 0);
    V v_argv_2433 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OPrim = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2434 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2433));
    return heff_tag_at_n(v_ru_24x4_242_24OPrim, TAG_RPrim, 2, (V[]){v_p_2432, v_t_2434});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return NTAG(TAG_RAbandon);
  }
  case TAG_OBool: {
    V v_c_2435 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24OBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_t_2436 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 6))));
    V v_t_2437 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2436, v_ce_240));
    V v_t_2438 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2437));
    V v_t_2439 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2438, v_c_2435));
    return heff_tag_at_n(v_ru_24x4_242_24OBool, TAG_RBool, 1, (V[]){v_t_2439});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V v_ce_240, V v_returns_241, V v_v_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(heff_dup(v_ce_240), heff_dup(v_v_242)));
  V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0, 1, 2, (V[]){v_v_242, v_ce_240}), v_arms_243));
  return heff_tag_n(TAG_CSwitch, 3, (V[]){v_t_244, v_t_2459, v_returns_241});
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_v_242 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_it1_246 = heff_field(v_p_245, 0);
    V v_b_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_t_248 = heff_field(v_it1_246, 0);
      V v_vs_249 = heff_field(v_it1_246, 1);
      heff_take_n(v_it1_246, 3ULL, 2);
      V v_t_2434;
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2410 = heff_dup(heff_field(v_v_242, 0));
        V v_t_2411 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2410, heff_rfield(v_ce_240, 4)));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
        } else {
          heff_drop(v_x_2410);
          heff_drop(v_t_2411);
          v_t_2434 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_SGlobal: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2434 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      V v_t_2458;
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2435 = heff_field(v_v_242, 0);
        heff_take_n(v_v_242, 1ULL, 1);
        v_t_2458 = ({ V a_0 = v_x_2435; V a_1 = heff_rfield(v_ce_240, 6); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2435); r_; });
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_v_242, 0ULL, 3);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_v_242, 0ULL, 4);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      return ({ V a_0 = v_ce_240; V a_1 = v_t_2434; V a_2 = v_t_2458; V a_3 = v_t_248; V a_4 = v_vs_249; V a_5 = v_b_247; V r_ = (g_heff_2ecompile_2erefcount_2earmOf_24s187383402x1262053818(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2458); r_; });
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam5(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(V v_ce_240, V v_xs_241, V v_st_242, V v_rest_243, V v_after_244, V v_wb_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_st_242), NTAG(TAG_Nil)});
  V v_t_247 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_246));
  V v_wanted_248 = (g_prelude_2e_2b_2b(v_t_247, heff_dup(v_wb_245)));
  V v_xs_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam0, 1, 1, (V[]){v_wanted_248}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2412 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2411));
  V v_t_2413 = (g_list_2emap_24s1796125103x644876049(v_t_2412));
  V v_t_2414 = (g_list_2emap_24s698037429x265256386(heff_dup(v_xs_241)));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_st_242), NTAG(TAG_Nil)});
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_2415));
  V v_wanted_2417 = (g_prelude_2e_2b_2b(v_t_2416, heff_dup(v_wb_245)));
  V v_t_2419 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam1, 1, 1, (V[]){v_wanted_2417}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2419, heff_dup(v_wb_245), heff_dup(v_ce_240)));
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2420));
  V v_t_2422 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_t_2421, v_st_242));
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2422));
  V v_xs_2426 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam2, 1, 1, (V[]){heff_dup(v_wb_245)}), heff_dup(v_xs_241)));
  V v_t_2427 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2426));
  V v_t_2428 = (g_list_2emap_24s1796125103x644876049(v_t_2427));
  V v_t_2430 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam3, 1, 1, (V[]){heff_dup(v_wb_245)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_xs_2432 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam4, 1, 1, (V[]){v_wb_245}), v_xs_241));
  V v_t_2438 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam5, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2432));
  V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2438));
  V v_t_2440 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), heff_dup(v_ce_240)));
  V v_ce_2441 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2439, heff_get_n(v_ce_240, 5, 17), v_t_2440));
  V v_t_2442 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2441, v_rest_243, v_after_244));
  V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2442));
  V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2443));
  return (g_prelude_2e_2b_2b(v_t_2413, v_t_2444));
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_249); heff_drop(v_wanted_248); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam1(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wanted_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2418; V a_1 = v_wanted_2417; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2418); heff_drop(v_wanted_2417); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_wb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425 = ({ V a_0 = v_x_2424; V a_1 = v_wb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2424); heff_drop(v_wb_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2425) == NTAG(TAG_True)));
  heff_drop(v_x1_2425);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam3(V self, V *args) {
  V v_v_2429 = args[0];
  V v_wb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2429; V a_1 = v_wb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2429); heff_drop(v_wb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_wb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2431; V a_1 = v_wb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2431); heff_drop(v_wb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2434 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2433; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2433); r_; });
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2435 == ((int64_t)0ULL)) ? ({ V v_x_2437 = heff_dup(v_field_2436); int c_ = 0; heff_drop(v_x_2437); c_; }) : 1));
    heff_drop(v_field_2436);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str7, 0, "");
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam4(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(V v_tag_240, V v_ce_241, V v_x3_242, V v_after_243, V v_ce_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187: {
    top_TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187: ;
    heff_drop_rec(v_ce_244, 17);
    heff_drop(v_x3_245);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        heff_drop_rec(v_ce_241, 17);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_t_246 = heff_field(v_after_243, 0);
        heff_take_n(v_after_243, 1ULL, 1);
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565);
        V t_1 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str0);
        V t_2 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str1);
        V t_3 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str2);
        V t_4 = v_ce_241;
        V t_5 = v_t_246;
        v_tag_240 = t_0;
        v_ce_241 = t_1;
        v_x3_242 = t_2;
        v_after_243 = t_3;
        v_ce_244 = t_4;
        v_x3_245 = t_5;
        goto top_TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565;
      }
      default: return heff_nomatch(v_after_243);
      }
    }
    case TAG_Cons: {
      V v_x31_247 = heff_field(v_x3_242, 0);
      V v_x32_248 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_SLet: {
        V v_x_249 = heff_field(v_x31_247, 0);
        V v_o_2410 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24SLet = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_t_2413;
        switch (heff_tag_of(v_after_243)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x31_247_24SLet, 2);
          v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_x32_248)}), NTAG(TAG_Nil)});
          break;
        }
        case TAG_Just: {
          V v_t_2411 = heff_dup(heff_field(v_after_243, 0));
          V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2411}), NTAG(TAG_Nil)});
          v_t_2413 = heff_tag_at_n(v_ru_24x31_247_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_x32_248)}), v_t_2412});
          break;
        }
        default: heff_nomatch(v_after_243);
        }
        V v_t_2414 = (g_heff_2ecompile_2erefcount_2epeekOf(heff_dup(v_ce_241), v_x_249, v_o_2410, v_t_2413));
        return ({ V a_0 = v_ce_241; V a_1 = v_x_249; V a_2 = v_o_2410; V a_3 = v_x32_248; V a_4 = v_after_243; V a_5 = v_t_2414; V r_ = (g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2414); r_; });
      }
      case TAG_SDecl: {
        V v_x_2415 = heff_dup(heff_field(v_x31_247, 0));
        switch (heff_tag_of(v_x32_248)) {
        case TAG_Nil: {
          heff_drop(v_x_2415);
          V v_t_2416 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_241), v_x31_247));
          V v_t_2417 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
          return (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2416, v_t_2417));
        }
        case TAG_Cons: {
          V v_x321_2418 = heff_field(v_x32_248, 0);
          V v_more_2419 = heff_field(v_x32_248, 1);
          V v_ru_24x32_248_24Cons = heff_take_reuse_n(v_x32_248, 3ULL, 2);
          heff_drop_tag(v_x31_247, 1);
          switch (heff_tag_of(v_x321_2418)) {
          case TAG_SLet: {
            V v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x321_2418), NTAG(TAG_Nil)});
            V v_fa_2423 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_2422));
            V v_t_2424 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_more_2419), heff_dup(v_after_243)));
            V v_t_2425 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x32_248_24Cons, v_t_2424, heff_dup(heff_rfield(v_ce_241, 5))));
            return ({ V a_0 = v_ce_241; V a_1 = heff_dup(v_x_2415); V a_2 = v_fa_2423; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam0, 1, 2, (V[]){v_x321_2418, v_x_2415}); V b_4 = NTAG(TAG_Nothing); V a_5 = NTAG(TAG_Nil); V a_6 = v_more_2419; V a_7 = v_after_243; V a_8 = v_t_2425; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7, a_8)); heff_drop(b_4); r_; });
          }
          case TAG_SDecl: {
            V v_y_2428 = heff_field(v_x321_2418, 0);
            heff_take_n(v_x321_2418, 1ULL, 1);
            V v_t_2429 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_2428, NTAG(TAG_Nil)});
            HeffT2 v_t_2430 = (g_heff_2ecompile_2erefcount_2edeclRun_24cpr(heff_tag_at_n(v_ru_24x32_248_24Cons, TAG_Cons, 2, (V[]){v_x_2415, v_t_2429}), v_more_2419));
            {
              V v_field_2431 = v_t_2430.f[0];
              V v_field_2432 = v_t_2430.f[1];
              V v_xs_2433 = v_field_2431;
              V v_x32_2434 = v_field_2432;
              switch (heff_tag_of(v_x32_2434)) {
              case TAG_Nil: {
                heff_drop(v_xs_2433);
                switch (heff_tag_of(v_after_243)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_ce_241, 17);
                  return NTAG(TAG_Nil);
                }
                case TAG_Just: {
                  V v_t_2435 = heff_field(v_after_243, 0);
                  heff_take_n(v_after_243, 1ULL, 1);
                  V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565);
                  V t_1 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str3);
                  V t_2 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str4);
                  V t_3 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str5);
                  V t_4 = v_ce_241;
                  V t_5 = v_t_2435;
                  v_tag_240 = t_0;
                  v_ce_241 = t_1;
                  v_x3_242 = t_2;
                  v_after_243 = t_3;
                  v_ce_244 = t_4;
                  v_x3_245 = t_5;
                  goto top_TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565;
                }
                default: return heff_nomatch(v_after_243);
                }
              }
              case TAG_Cons: {
                V v_st_2436 = heff_field(v_x32_2434, 0);
                V v_rest_2437 = heff_field(v_x32_2434, 1);
                V v_ru_24x32_2434_24Cons = heff_take_reuse_n(v_x32_2434, 3ULL, 2);
                V v_t_2438 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_2437), heff_dup(v_after_243)));
                V v_t_2439 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x32_2434_24Cons, v_t_2438, heff_dup(heff_rfield(v_ce_241, 5))));
                HEFF_LAST return g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(v_ce_241, v_xs_2433, v_st_2436, v_rest_2437, v_after_243, v_t_2439);
              }
              default: return heff_nomatch(v_x32_2434);
              }
            }
          }
          case TAG_SSet: {
            V v_t_2442 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x321_2418), NTAG(TAG_Nil)});
            V v_fa_2443 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_2442));
            V v_t_2444 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_more_2419), heff_dup(v_after_243)));
            V v_t_2445 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x32_248_24Cons, v_t_2444, heff_dup(heff_rfield(v_ce_241, 5))));
            return ({ V a_0 = v_ce_241; V a_1 = heff_dup(v_x_2415); V a_2 = v_fa_2443; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam1, 1, 2, (V[]){v_x321_2418, v_x_2415}); V b_4 = NTAG(TAG_Nothing); V a_5 = NTAG(TAG_Nil); V a_6 = v_more_2419; V a_7 = v_after_243; V a_8 = v_t_2445; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7, a_8)); heff_drop(b_4); r_; });
          }
          case TAG_SIf: {
            V v_t_2451 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x321_2418), NTAG(TAG_Nil)});
            V v_fa_2452 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_2451));
            V v_t_2453 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_more_2419), heff_dup(v_after_243)));
            V v_t_2454 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x32_248_24Cons, v_t_2453, heff_dup(heff_rfield(v_ce_241, 5))));
            return ({ V a_0 = v_ce_241; V a_1 = heff_dup(v_x_2415); V a_2 = v_fa_2452; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam2, 1, 2, (V[]){v_x321_2418, v_x_2415}); V b_4 = NTAG(TAG_Nothing); V a_5 = NTAG(TAG_Nil); V a_6 = v_more_2419; V a_7 = v_after_243; V a_8 = v_t_2454; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7, a_8)); heff_drop(b_4); r_; });
          }
          case TAG_SCase: {
            V v_t_2459 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x321_2418), NTAG(TAG_Nil)});
            V v_fa_2460 = (g_heff_2ecompile_2erefcount_2efvSts(v_t_2459));
            V v_t_2461 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_more_2419), heff_dup(v_after_243)));
            V v_t_2462 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x32_248_24Cons, v_t_2461, heff_dup(heff_rfield(v_ce_241, 5))));
            return ({ V a_0 = v_ce_241; V a_1 = heff_dup(v_x_2415); V a_2 = v_fa_2460; V a_3 = heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam3, 1, 2, (V[]){v_x321_2418, v_x_2415}); V b_4 = NTAG(TAG_Nothing); V a_5 = NTAG(TAG_Nil); V a_6 = v_more_2419; V a_7 = v_after_243; V a_8 = v_t_2462; V r_ = (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7, a_8)); heff_drop(b_4); r_; });
          }
          default: return heff_nomatch(v_x321_2418);
          }
        }
        default: return heff_nomatch(v_x32_248);
        }
      }
      case TAG_SSet: {
        V v_x_2465 = heff_field(v_x31_247, 0);
        V v_o_2466 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24SSet = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_t_2467 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_x32_248), heff_dup(v_after_243)));
        V v_live_2468 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x31_247_24SSet, v_t_2467, heff_dup(heff_rfield(v_ce_241, 5))));
        HeffT2 v_t_2469 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_241, 10), v_x_2465));
        V v_t_2474;
        {
          V v_field_2471 = v_t_2469.f[1];
          int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
          V v_t_2473;
          if ((v_tag_2470 == ((int64_t)0ULL))) {
            V v_x_2472 = v_field_2471;
            v_t_2473 = v_x_2472;
          } else {
            heff_drop(v_field_2471);
            v_t_2473 = NTAG(TAG_RepV);
          }
          v_t_2474 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_241), v_live_2468, v_t_2473, heff_dup(v_o_2466)));
        }
        V v_t_2487;
        switch (heff_tag_of(v_o_2466)) {
        case TAG_OSimple: {
          heff_take_n(v_o_2466, 0ULL, 1);
          v_t_2487 = NTAG(TAG_Nil);
          break;
        }
        case TAG_OCall: {
          heff_take_n(v_o_2466, 0ULL, 2);
          v_t_2487 = NTAG(TAG_Nil);
          break;
        }
        case TAG_OApply: {
          heff_take_n(v_o_2466, 0ULL, 2);
          v_t_2487 = NTAG(TAG_Nil);
          break;
        }
        case TAG_OPrim: {
          heff_take_n(v_o_2466, 0ULL, 2);
          v_t_2487 = NTAG(TAG_Nil);
          break;
        }
        case TAG_OAbandon: {
          v_t_2487 = NTAG(TAG_Nil);
          break;
        }
        case TAG_OBool: {
          V v_ru_24o_2466_24OBool = heff_take_reuse_n(v_o_2466, 0ULL, 1);
          V v_xs_2485 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam4, 1, 1, (V[]){heff_dup(v_ce_241)}), heff_dup(heff_rfield(v_ce_241, 4))));
          V v_t_2486 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2485));
          v_t_2487 = (g_list_2emap_24s1796125103x644876049_24tok1(v_ru_24o_2466_24OBool, v_t_2486));
          break;
        }
        default: heff_nomatch(v_o_2466);
        }
        V v_t_2488 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
        V v_t_2489 = (g_prelude_2e_2b_2b(v_t_2487, v_t_2488));
        return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CSet, 2, (V[]){v_x_2465, v_t_2474}), v_t_2489});
      }
      case TAG_SIf: {
        V v_t_2493 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_241), v_x31_247));
        V v_t_2494 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
        return (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2493, v_t_2494));
      }
      case TAG_SCase: {
        V v_t_2497 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_241), v_x31_247));
        V v_t_2498 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
        return (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2497, v_t_2498));
      }
      default: return heff_nomatch(v_x31_247);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565: {
    top_TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565: ;
    heff_drop_rec(v_ce_241, 17);
    heff_drop(v_x3_242);
    heff_drop(v_after_243);
    switch (heff_tag_of(v_x3_245)) {
    case TAG_TSeq: {
      V v_ss_2499 = heff_field(v_x3_245, 0);
      V v_t_24100 = heff_field(v_x3_245, 1);
      heff_take_n(v_x3_245, 3ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187);
      V t_1 = v_ce_244;
      V t_2 = v_ss_2499;
      V t_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24100});
      V t_4 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str6);
      V t_5 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str7);
      v_tag_240 = t_0;
      v_ce_241 = t_1;
      v_x3_242 = t_2;
      v_after_243 = t_3;
      v_ce_244 = t_4;
      v_x3_245 = t_5;
      goto top_TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187;
    }
    case TAG_TReturn: {
      V v_x31_24101 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24TReturn = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_24101)) {
      case TAG_OSimple: {
        V v_t_24103 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_244), NTAG(TAG_Nil), heff_get_n(v_ce_244, 16, 17), v_x31_24101));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24103}), NTAG(TAG_Nil)});
      }
      case TAG_OCall: {
        V v_g_24104 = heff_field(v_x31_24101, 0);
        V v_argv_24105 = heff_field(v_x31_24101, 1);
        heff_take_n(v_x31_24101, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_245_24TReturn, 1);
        return (g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(v_ce_244, v_g_24104, v_argv_24105));
      }
      case TAG_OApply: {
        V v_f_24106 = heff_field(v_x31_24101, 0);
        V v_argv_24107 = heff_field(v_x31_24101, 1);
        V v_ru_24x31_24101_24OApply = heff_take_reuse_n(v_x31_24101, 3ULL, 2);
        V v_t_24108 = heff_dup(heff_rfield(v_ce_244, 16));
        switch (heff_tag_of(v_t_24108)) {
        case TAG_RepV: {
          V v_t_24109 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_24107));
          V v_t_24110 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(heff_dup(v_ce_244), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x31_24101_24OApply, TAG_Cons, 2, (V[]){v_f_24106, v_argv_24107})));
          return (g_heff_2ecompile_2erefcount_2eapplyLast_24tok1(v_ru_24x3_245_24TReturn, v_ce_244, v_t_24109, v_t_24110));
        }
        case TAG_RepFix: {
          heff_take_n(v_t_24108, 0ULL, 1);
          V v_t_24112 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(heff_dup(v_ce_244), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x31_24101_24OApply, TAG_Cons, 2, (V[]){v_f_24106, v_argv_24107})));
          V v_t_24115;
          switch (heff_tag_of(v_t_24112)) {
          case TAG_Nil: {
            v_t_24115 = NTAG(TAG_RAbandon);
            break;
          }
          case TAG_Cons: {
            V v_fv_24113 = heff_field(v_t_24112, 0);
            V v_vs_24114 = heff_field(v_t_24112, 1);
            V v_ru_24t_24112_24Cons = heff_take_reuse_n(v_t_24112, 3ULL, 2);
            v_t_24115 = heff_tag_at_n(v_ru_24t_24112_24Cons, TAG_RApply, 2, (V[]){v_fv_24113, v_vs_24114});
            break;
          }
          default: heff_nomatch(v_t_24112);
          }
          V v_t_24116 = (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), heff_get_n(v_ce_244, 16, 17), v_t_24115));
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24116}), NTAG(TAG_Nil)});
        }
        case TAG_RepF64: {
          V v_t_24117 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(heff_dup(v_ce_244), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x31_24101_24OApply, TAG_Cons, 2, (V[]){v_f_24106, v_argv_24107})));
          V v_t_24120;
          switch (heff_tag_of(v_t_24117)) {
          case TAG_Nil: {
            v_t_24120 = NTAG(TAG_RAbandon);
            break;
          }
          case TAG_Cons: {
            V v_fv_24118 = heff_field(v_t_24117, 0);
            V v_vs_24119 = heff_field(v_t_24117, 1);
            V v_ru_24t_24117_24Cons = heff_take_reuse_n(v_t_24117, 3ULL, 2);
            v_t_24120 = heff_tag_at_n(v_ru_24t_24117_24Cons, TAG_RApply, 2, (V[]){v_fv_24118, v_vs_24119});
            break;
          }
          default: heff_nomatch(v_t_24117);
          }
          V v_t_24121 = (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), heff_get_n(v_ce_244, 16, 17), v_t_24120));
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24121}), NTAG(TAG_Nil)});
        }
        case TAG_RepInt: {
          V v_t_24122 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(heff_dup(v_ce_244), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x31_24101_24OApply, TAG_Cons, 2, (V[]){v_f_24106, v_argv_24107})));
          V v_t_24125;
          switch (heff_tag_of(v_t_24122)) {
          case TAG_Nil: {
            v_t_24125 = NTAG(TAG_RAbandon);
            break;
          }
          case TAG_Cons: {
            V v_fv_24123 = heff_field(v_t_24122, 0);
            V v_vs_24124 = heff_field(v_t_24122, 1);
            V v_ru_24t_24122_24Cons = heff_take_reuse_n(v_t_24122, 3ULL, 2);
            v_t_24125 = heff_tag_at_n(v_ru_24t_24122_24Cons, TAG_RApply, 2, (V[]){v_fv_24123, v_vs_24124});
            break;
          }
          default: heff_nomatch(v_t_24122);
          }
          V v_t_24126 = (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), heff_get_n(v_ce_244, 16, 17), v_t_24125));
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24126}), NTAG(TAG_Nil)});
        }
        default: return heff_nomatch(v_t_24108);
        }
      }
      case TAG_OPrim: {
        V v_t_24129 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_244), NTAG(TAG_Nil), heff_get_n(v_ce_244, 16, 17), v_x31_24101));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24129}), NTAG(TAG_Nil)});
      }
      case TAG_OAbandon: {
        V v_t_24130 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_244), NTAG(TAG_Nil), heff_get_n(v_ce_244, 16, 17), v_x31_24101));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24130}), NTAG(TAG_Nil)});
      }
      case TAG_OBool: {
        V v_c_24131 = heff_field(v_x31_24101, 0);
        V v_ru_24x31_24101_24OBool = heff_take_reuse_n(v_x31_24101, 1ULL, 1);
        V v_t_24132 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_244, 4)), heff_dup(heff_rfield(v_ce_244, 6))));
        V v_t_24133 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_24132, heff_dup(v_ce_244)));
        V v_t_24134 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_24133));
        V v_t_24135 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_24134, v_c_24131));
        V v_v_24136 = heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_RBool, 1, (V[]){v_t_24135});
        V v_t_24137 = (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), heff_dup(heff_rfield(v_ce_244, 16)), heff_tag_at_n(v_ru_24x31_24101_24OBool, TAG_RLocal, 1, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2eboolName_get())})));
        V v_t_24138 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_24137}), NTAG(TAG_Nil)});
        V v_t_24139 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_244), heff_get_n(v_ce_244, 4, 17)));
        V v_t_24140 = (g_prelude_2e_2b_2b_24f1572068627x1632985590(v_t_24138, v_t_24139));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2eboolName_get()), v_v_24136}), v_t_24140});
      }
      default: return heff_nomatch(v_x31_24101);
      }
    }
    case TAG_TLoop: {
      V v_argv_24141 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24TLoop = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      V v_t_24142 = heff_dup(heff_rfield(v_ce_244, 2));
      switch (heff_tag_of(v_t_24142)) {
      case TAG_Nothing: {
        heff_drop_rec(v_ce_244, 17);
        heff_drop(v_argv_24141);
        V v_t_24143 = heff_tag_at_n(v_ru_24x3_245_24TLoop, TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24143, NTAG(TAG_Nil)});
      }
      case TAG_Just: {
        V v_s_24144 = heff_field(v_t_24142, 0);
        heff_take_n(v_t_24142, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_245_24TLoop, 1);
        return (g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(v_ce_244, heff_get_n(v_s_24144, 0, 2), v_argv_24141));
      }
      default: return heff_nomatch(v_t_24142);
      }
    }
    case TAG_TIf: {
      V v_x31_24145 = heff_field(v_x3_245, 0);
      V v_t_24146 = heff_field(v_x3_245, 1);
      V v_e_24147 = heff_field(v_x3_245, 2);
      V v_ru_24x3_245_24TIf = heff_take_reuse_n(v_x3_245, 7ULL, 3);
      switch (heff_tag_of(v_x31_24145)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return ({ V a_0 = v_ce_244; V a_1 = v_x31_24145; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_24146}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_24147}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return ({ V a_0 = v_ce_244; V a_1 = v_x31_24145; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_24146}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_24147}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
      }
      case TAG_PRel: {
        V v_p_24148 = heff_field(v_x31_24145, 0);
        V v_a_24149 = heff_field(v_x31_24145, 1);
        V v_b_24150 = heff_field(v_x31_24145, 2);
        heff_take_n(v_x31_24145, 7ULL, 3);
        V v_t_24151 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_24150), NTAG(TAG_Nil)});
        V v_t_24152 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24150, NTAG(TAG_Nil)});
        V v_t_24153 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_24149), v_t_24152})));
        V v_t_24154 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24153; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_24153); r_; });
        V v_t_24155 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_t_24146)));
        V v_t_24156 = (g_heff_2ecompile_2erefcount_2efvTl(heff_dup(v_e_24147)));
        V v_t_24157 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_244, 5)), v_t_24155, v_t_24156));
        return ({ V a_0 = v_ru_24x3_245_24TIf; V a_1 = v_ce_244; V a_2 = v_p_24148; V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_24149, v_t_24151}); V b_4 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_24146}); V b_5 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_24147}); V a_6 = v_t_24154; V a_7 = v_t_24157; V r_ = (g_heff_2ecompile_2erefcount_2econdWith_24s183934579x184430633_24tok3(a_0, a_1, a_2, a_3, b_4, b_5, a_6, a_7)); heff_drop(b_4); heff_drop(b_5); r_; });
      }
      case TAG_PBool: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return ({ V a_0 = v_ce_244; V a_1 = v_x31_24145; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_24146}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_24147}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
      }
      case TAG_PNot: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return ({ V a_0 = v_ce_244; V a_1 = v_x31_24145; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_24146}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_24147}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
      }
      case TAG_PIf: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return ({ V a_0 = v_ce_244; V a_1 = v_x31_24145; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_24146}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_24147}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
      }
      case TAG_PLet: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return ({ V a_0 = v_ce_244; V a_1 = v_x31_24145; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_24146}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_24147}); V r_ = (g_heff_2ecompile_2erefcount_2econdTest_24s454968547x499742947(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
      }
      default: return heff_nomatch(v_x31_24145);
      }
    }
    case TAG_TCase: {
      V v_v_24166 = heff_field(v_x3_245, 0);
      V v_arms_24167 = heff_field(v_x3_245, 1);
      V v_ru_24x3_245_24TCase = heff_take_reuse_n(v_x3_245, 3ULL, 2);
      V v_t_24168 = (g_list_2emap_24s1341404685x1564972929(v_arms_24167));
      V v_t_24169 = (g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(v_ce_244, NTAG(TAG_True), v_v_24166, v_t_24168));
      return heff_tag_at_n(v_ru_24x3_245_24TCase, TAG_Cons, 2, (V[]){v_t_24169, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam0(V self, V *args) {
  V v_ce2_2426 = args[0];
  V v_x321_2418 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_ce2_2426, v_x321_2418));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_2415}), v_t_2427});
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam1(V self, V *args) {
  V v_ce2_2446 = args[0];
  V v_x321_2418 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_ce2_2446, v_x321_2418));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_2415}), v_t_2447});
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam2(V self, V *args) {
  V v_ce2_2455 = args[0];
  V v_x321_2418 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_ce2_2455, v_x321_2418));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_2415}), v_t_2456});
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam3(V self, V *args) {
  V v_ce2_2463 = args[0];
  V v_x321_2418 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_ce2_2463, v_x321_2418));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_2415}), v_t_2464});
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam4(V self, V *args) {
  V v_v_2483 = args[0];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2484 = ({ V a_0 = v_v_2483; V b_1 = heff_get_n(v_ce_241, 5, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_v_2483); heff_drop(b_1); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2484) == NTAG(TAG_True)));
  heff_drop(v_x1_2484);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str1, 0, "");
Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V v_ce_240, V v_x3_241, V v_after_242) {
top: ;
  return (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187), v_ce_240, v_x3_241, v_after_242, ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str0), ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str1)));
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_247 = heff_field(v_x7_245, 0);
    V v_ps_248 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_i_244);
      heff_drop(v_p_247);
      heff_drop(v_ps_248);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x8_246, 0);
      V v_es_2410 = heff_field(v_x8_246, 1);
      V v_ru_24x8_246_24Cons = heff_take_reuse_n(v_x8_246, 3ULL, 2);
      HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(heff_rfield(v_ce_240, 10), v_p_247));
      V v_t_2425;
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2413;
          heff_drop(v_x_2414);
          V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2410)));
          V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s826961155x1314392429(a_0, a_1)); heff_drop(v_t_2415); r_; });
          V v_t_2417 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x8_246_24Cons, v_t_2416, heff_dup(v_live_241)));
          V v_live_2418 = (g_prelude_2e_2b_2b(heff_dup(v_before_242), v_t_2417));
          HeffT2 v_t_2419 = ({ V a_0 = heff_rfield(v_ce_240, 10); V a_1 = v_p_247; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_p_247); r_; });
          V v_t_2424;
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            V v_t_2423;
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_x_2422 = v_field_2421;
              v_t_2423 = v_x_2422;
            } else {
              heff_drop(v_field_2421);
              v_t_2423 = NTAG(TAG_RepV);
            }
            v_t_2424 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2418, v_t_2423, heff_dup(v_e_249)));
          }
          v_t_2425 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2424});
        } else {
          heff_drop(v_p_247);
          heff_drop_cell(v_ru_24x8_246_24Cons, 2);
          heff_drop(v_field_2413);
          v_t_2425 = (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), v_bi_243, heff_dup(v_i_244), heff_dup(v_e_249), heff_dup(v_es_2410)));
        }
      }
      V v_cell_2426 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
      V v_t_2427 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = heff_dup(v_i_244); V a_3 = v_e_249; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_249); r_; });
      V v_u_2428 = (g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(v_ce_240, v_live_241, v_t_2427, v_bi_243, heff_box_word((heff_unbox_word(v_i_244) + ((int64_t)1ULL))), v_ps_248, v_es_2410, heff_dup(v_cell_2426)));
      heff_drop(v_u_2428);
      return v_cell_2426;
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(V v_ce_240, V v_g_241, V v_argv_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 7), v_g_241));
  V v_t_247;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      v_t_247 = v_x_246;
    } else {
      heff_drop(v_field_245);
      v_t_247 = NTAG(TAG_Nil);
    }
  }
  V v_t_248 = heff_dup(heff_rfield(v_ce_240, 2));
  V v_t_2410;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_s_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    v_t_2410 = heff_get_n(v_s_249, 1, 2);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2411 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_247; V a_4 = MK_INT(0LL); V a_5 = v_t_2410; V a_6 = heff_dup(v_argv_242); V r_ = (g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_247); r_; });
  HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 7), v_g_241));
  V v_t_2416;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2414;
      v_t_2416 = v_x_2415;
    } else {
      heff_drop(v_field_2414);
      v_t_2416 = NTAG(TAG_Nil);
    }
  }
  HeffT2 v_t_2417 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
  V v_t_2421;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      v_t_2421 = heff_get_n(v_s_2420, 0, 2);
    } else {
      heff_drop(v_field_2419);
      v_t_2421 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_argv_242)));
    }
  }
  V v_t_2422 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = NTAG(TAG_Nil); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2416; V a_4 = MK_INT(0LL); V a_5 = v_t_2421; V a_6 = heff_dup(v_argv_242); V r_ = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2416); r_; });
  return ({ V a_0 = v_ce_240; V a_1 = v_g_241; V a_2 = v_argv_242; V a_3 = v_t_2411; V a_4 = v_t_2422; V r_ = (g_heff_2ecompile_2erefcount_2ecallAs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_argv_242); r_; });
}
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erefcount_2evalRc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2evalRc_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2evalRc(V v_ce_240, V v_key_241, V v_t_242) {
top: ;
  V v_t_243 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_242, NTAG(TAG_Nil)));
  V v_t_244 = (g_list_2efoldl_24s976906006x1321876394(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
  V v_t_245 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1548442597x958354846(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_heff_2ecompile_2erefcount_2ewithFrame(NTAG(TAG_Nothing), MK_INT(0LL), v_t_245));
  V v_ce_247 = (g_heff_2ecompile_2erefcount_2ewithPath(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_246));
  V v_t_248 = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(v_ce_247, v_t_242));
  return heff_tag_n(TAG_DVal, 3, (V[]){v_key_241, v_t_248, heff_get_n(v_ce_240, 10, 17)});
}
V g_heff_2ecompile_2erefcount_2evalRc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2evalRc(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam2(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(V v_tok_240, V v_ce_241, V v_x_242, V v_a_243, V v_i_244, V v_rest_245, V v_after_246, V v_wb_247) {
top: ;
  V v_t_248 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_i_244)));
  V v_wanted_249 = (g_prelude_2e_2b_2b(v_t_248, heff_dup(v_wb_247)));
  V v_xs_2412 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam0, 1, 1, (V[]){v_wanted_249}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2412));
  V v_t_2414 = (g_list_2emap_24s1796125103x644876049(v_t_2413));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2efvVal(heff_dup(v_i_244)));
  V v_wanted_2416 = (g_prelude_2e_2b_2b(v_t_2415, heff_dup(v_wb_247)));
  V v_t_2418 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam1, 1, 1, (V[]){v_wanted_2416}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_ce_2419 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2418, heff_dup(v_wb_247), heff_dup(v_ce_241)));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2419, heff_dup(v_wb_247), NTAG(TAG_RepV), v_i_244));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_RLocal, 1, (V[]){v_a_243}), v_t_2421});
  V v_t_2423 = heff_tag_n(TAG_CLet, 2, (V[]){heff_dup(v_x_242), heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2epeekPrim_get()), v_t_2422})});
  V v_t_2425 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam2, 1, 1, (V[]){v_wb_247}), heff_dup(heff_rfield(v_ce_241, 4))));
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, heff_dup(heff_rfield(v_ce_241, 6))});
  V v_t_2427 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2426, heff_dup(v_ce_241)));
  V v_ce_2428 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2425, heff_get_n(v_ce_241, 5, 17), v_t_2427));
  V v_t_2429 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_2428, v_rest_245, v_after_246));
  return (g_prelude_2e_2b_2b(v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2429})));
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam1(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2417; V a_1 = v_wanted_2416; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2417); heff_drop(v_wanted_2416); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam2(V self, V *args) {
  V v_v_2424 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2424; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2424); heff_drop(v_wb_247); r_; });
}