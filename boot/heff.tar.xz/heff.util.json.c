// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define LBL_rune 10007553
#define LBL_width 314485216
static uint32_t shape_rune__width[] = {LBL_rune, LBL_width};
V g_heff_2eutil_2ejson_2eat(V, V);
V g_heff_2eutil_2ejson_2eat_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eat_clo;
V g_heff_2eutil_2ejson_2eescapeAt(V, V);
V g_heff_2eutil_2ejson_2eescapeAt_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eescapeAt_clo;
V g_heff_2eutil_2ejson_2eescapeGo(V, V, V);
V g_heff_2eutil_2ejson_2eescapeGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2eescapeGo_clo;
V g_heff_2eutil_2ejson_2estringify(V);
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a);
extern Clo g_heff_2eutil_2ejson_2estringify_clo;
V g_list_2efind_24s465947678x1101118081(V, V);
V g_list_2efind_24s465947678x1101118081_entry(V self, V *a);
extern Clo g_list_2efind_24s465947678x1101118081_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2005951263x462916503(V, V, V, V, V, V);
V g_list_2emap_24s2005951263x462916503_entry(V self, V *a);
extern Clo g_list_2emap_24s2005951263x462916503_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str0, 2, "\\\"");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str1, 2, "\\\\");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str2, 2, "\\n");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str3, 2, "\\r");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str4, 2, "\\t");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str5, 2, "\\b");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str6, 2, "\\f");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str7, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str8, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2ejson_2eescapeAt_str9, 4, "\\u00");
Clo g_heff_2eutil_2ejson_2eescapeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ejson_2eescapeAt_entry, 2, 0};

V g_heff_2eutil_2ejson_2eescapeAt(V v_s_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eutil_2ejson_2eescapeAt_str0);
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return ((V)&g_heff_2eutil_2ejson_2eescapeAt_str1);
    } else {
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL))) {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return ((V)&g_heff_2eutil_2ejson_2eescapeAt_str2);
      } else {
        if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL))) {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          return ((V)&g_heff_2eutil_2ejson_2eescapeAt_str3);
        } else {
          if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL))) {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            return ((V)&g_heff_2eutil_2ejson_2eescapeAt_str4);
          } else {
            if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(8LL))) {
              heff_drop(v_s_240);
              heff_drop(v_i_241);
              return ((V)&g_heff_2eutil_2ejson_2eescapeAt_str5);
            } else {
              if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(12LL))) {
                heff_drop(v_s_240);
                heff_drop(v_i_241);
                return ((V)&g_heff_2eutil_2ejson_2eescapeAt_str6);
              } else {
                if (heff_intLt_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(32LL))) {
                  V v_c_2410 = heff_strByteAt(v_s_240, v_i_241);
                  V v_d_2411 = heff_intDiv(heff_dup(v_c_2410), MK_INT(16LL));
                  V v_t_2412 = heff_strSlice(((V)&g_heff_2eutil_2ejson_2eescapeAt_str7), heff_dup(v_d_2411), heff_intAdd(v_d_2411, MK_INT(1LL)));
                  V v_d_2413 = heff_intMod(v_c_2410, MK_INT(16LL));
                  V v_t_2414 = heff_strSlice(((V)&g_heff_2eutil_2ejson_2eescapeAt_str8), heff_dup(v_d_2413), heff_intAdd(v_d_2413, MK_INT(1LL)));
                  return heff_strAppend(((V)&g_heff_2eutil_2ejson_2eescapeAt_str9), heff_strAppend(v_t_2412, v_t_2414));
                } else {
                  return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eutil_2ejson_2eescapeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ejson_2eescapeAt(a[0], a[1]);
}
Clo g_heff_2eutil_2ejson_2eescapeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ejson_2eescapeGo_entry, 3, 0};

V g_heff_2eutil_2ejson_2eescapeGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    if (heff_intLt_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(128LL))) {
      V v_t_245 = (g_heff_2eutil_2ejson_2eescapeAt(heff_dup(v_s_240), heff_dup(v_i_241)));
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_strAppend(v_acc_242, v_t_245);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      V v_r_246 = heff_rec_n(2, shape_rune__width, (V[]){heff_strRuneAt(heff_dup(v_s_240), heff_dup(v_i_241)), heff_strRuneWidth(heff_dup(v_s_240), heff_dup(v_i_241))});
      V v_t_247 = heff_intAdd(heff_dup(v_i_241), heff_dup(heff_rfield(v_r_246, 1)));
      V v_t_248 = heff_runeToInt(heff_take_field(v_r_246, 0));
      V v_t_2412;
      if (heff_intEq_c(v_t_248, MK_INT(65533LL))) {
        heff_drop(v_i_241);
        heff_drop_rec(v_r_246, 2);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(MK_INT(65533LL)), NTAG(TAG_Nil)});
        v_t_2412 = heff_strOfRunes(v_t_2410);
      } else {
        V v_t_2411 = heff_intAdd(heff_dup(v_i_241), heff_get_n(v_r_246, 1, 2));
        v_t_2412 = heff_strSlice(heff_dup(v_s_240), v_i_241, v_t_2411);
      }
      V t_0 = v_s_240;
      V t_1 = v_t_247;
      V t_2 = heff_strAppend(v_acc_242, v_t_2412);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2eutil_2ejson_2eescapeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ejson_2eescapeGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str0, 4, "null");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str1, 4, "true");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str2, 5, "false");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str3, 0, "");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str4, 1, "\"");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str5, 1, "\"");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str6, 0, "");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str7, 1, ",");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str8, 1, "[");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str9, 1, "]");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str10, 1, "\"");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str11, 0, "");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str12, 1, "\"");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str13, 1, ":");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str14, 0, "");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str15, 1, ",");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str16, 1, "{");
HEFF_LIT(g_heff_2eutil_2ejson_2estringify_str17, 1, "}");
Clo g_heff_2eutil_2ejson_2estringify_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ejson_2estringify_entry, 1, 0};

V g_heff_2eutil_2ejson_2estringify(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_JNull: {
    return ((V)&g_heff_2eutil_2ejson_2estringify_str0);
  }
  case TAG_JBool: {
    V v_b_241 = heff_field(v_x1_240, 0);
    if ((heff_dup(v_b_241) == NTAG(TAG_True))) {
      return ((V)&g_heff_2eutil_2ejson_2estringify_str1);
    } else {
      return ((V)&g_heff_2eutil_2ejson_2estringify_str2);
    }
  }
  case TAG_JInt: {
    V v_i_242 = heff_field(v_x1_240, 0);
    return heff_intShow(heff_dup(v_i_242));
  }
  case TAG_JFloat: {
    V v_x_243 = heff_field(v_x1_240, 0);
    return heff_floatShow(heff_dup(v_x_243));
  }
  case TAG_JString: {
    V v_s_244 = heff_field(v_x1_240, 0);
    V v_t_245 = (g_heff_2eutil_2ejson_2eescapeGo(heff_dup(v_s_244), MK_INT(0LL), ((V)&g_heff_2eutil_2ejson_2estringify_str3)));
    return heff_strAppend(((V)&g_heff_2eutil_2ejson_2estringify_str4), heff_strAppend(v_t_245, ((V)&g_heff_2eutil_2ejson_2estringify_str5)));
  }
  case TAG_JArray: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_x2_247 = (g_list_2emap(((V)&g_heff_2eutil_2ejson_2estringify_clo), heff_dup(v_xs_246)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2eutil_2ejson_2estringify_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2eutil_2ejson_2estringify_str7); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strAppend(((V)&g_heff_2eutil_2ejson_2estringify_str8), heff_strAppend(v_t_2410, ((V)&g_heff_2eutil_2ejson_2estringify_str9)));
  }
  case TAG_JObject: {
    V v_fs_2411 = heff_field(v_x1_240, 0);
    V v_x2_2412 = (g_list_2emap_24s2005951263x462916503(((V)&g_heff_2eutil_2ejson_2estringify_str10), MK_INT(0LL), ((V)&g_heff_2eutil_2ejson_2estringify_str11), ((V)&g_heff_2eutil_2ejson_2estringify_str12), ((V)&g_heff_2eutil_2ejson_2estringify_str13), heff_dup(v_fs_2411)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2eutil_2ejson_2estringify_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2eutil_2ejson_2estringify_str15); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    return heff_strAppend(((V)&g_heff_2eutil_2ejson_2estringify_str16), heff_strAppend(v_t_2415, ((V)&g_heff_2eutil_2ejson_2estringify_str17)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eutil_2ejson_2estringify_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2ejson_2estringify(a0); heff_drop(a0); return r;
}
Clo g_heff_2eutil_2ejson_2eat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ejson_2eat_entry, 2, 0};

V g_heff_2eutil_2ejson_2eat(V v_x1_240, V v_j_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_j_241});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ks_243 = heff_field(v_x1_240, 1);
    V v_t_2415;
    switch (heff_tag_of(v_j_241)) {
    case TAG_JNull: {
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_j_241, 0ULL, 1);
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_j_241, 0ULL, 1);
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_take_n(v_j_241, 0ULL, 1);
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_take_n(v_j_241, 0ULL, 1);
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_j_241, 0ULL, 1);
      v_t_2415 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_249 = heff_field(v_j_241, 0);
      V v_ru_24j_241_24JObject = heff_take_reuse_n(v_j_241, 1ULL, 1);
      V v_t_2410 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_fs_249; V r_ = (g_list_2efind_24s465947678x1101118081(a_0, a_1)); heff_drop(v_fs_249); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24j_241_24JObject, 1);
        v_t_2415 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2411 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_p_2411)) {
        case TAG_MkPair: {
          V v_y_2413 = heff_field(v_p_2411, 1);
          heff_take_n(v_p_2411, 2ULL, 2);
          v_t_2414 = v_y_2413;
          break;
        }
        default: heff_nomatch(v_p_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24j_241_24JObject, TAG_Just, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      break;
    }
    default: heff_nomatch(v_j_241);
    }
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      V t_0 = v_ks_243;
      V t_1 = v_v_2416;
      v_x1_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eutil_2ejson_2eat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2ejson_2eat(a0, a[1]); heff_drop(a0); return r;
}