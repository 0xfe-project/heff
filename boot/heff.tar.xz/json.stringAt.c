// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expected 48537
#define TAG_Left 13886
#define TAG_Right 62770
HeffT3 g_json_2eescapeText_24cpr(V, V);
V g_json_2estringAt_2estringFrom_240(V, V, V, V);
V g_json_2estringAt_2estringFrom_240_entry(V self, V *a);
extern Clo g_json_2estringAt_2estringFrom_240_clo;
HeffT3 g_json_2estringAt_2estringFrom_240_24cpr(V, V, V, V);
HEFF_LIT(g_json_2estringAt_2estringFrom_240_24cpr_str0, 3, "'\"'");
HEFF_LIT(g_json_2estringAt_2estringFrom_240_24cpr_str1, 31, "a character, or an escape of it");

HeffT3 g_json_2estringAt_2estringFrom_240_24cpr(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  V v_c_244 = heff_strByteAt_lent(v_s_240, v_i_242, 0);
  if ((heff_peek_word(v_c_244) == ((int64_t)34ULL))) {
    heff_drop(v_c_244);
    V v_f_245 = heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 2));
    V v_f_246 = heff_intAdd(v_i_242, MK_INT(1LL));
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_245, v_f_246}});
  } else {
    if ((heff_peek_word(v_c_244) == ((int64_t)92ULL))) {
      heff_drop(v_c_244);
      HeffT3 v_t_247 = (g_json_2eescapeText_24cpr(v_s_240, heff_intAdd(heff_dup(v_i_242), MK_INT(1LL))));
      {
        V v_field_249 = v_t_247.f[1];
        V v_field_2410 = v_t_247.f[2];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_start_241);
          heff_drop(v_i_242);
          heff_drop(v_acc_243);
          V v_e_2411 = heff_tag_n(TAG_Expected, 2, (V[]){v_field_249, v_field_2410});
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_e_2411, MK_INT(0LL)}});
        } else {
          V v_t_2412 = v_field_249;
          V v_j_2413 = v_field_2410;
          V v_t_2414 = heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_start_241, v_i_242, 6));
          V t_0 = v_s_240;
          V t_1 = heff_dup(v_j_2413);
          V t_2 = v_j_2413;
          V t_3 = heff_strAppend(v_t_2414, v_t_2412);
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_i_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    } else {
      if ((heff_peek_word(v_c_244) < ((int64_t)0ULL))) {
        heff_drop(v_start_241);
        heff_drop(v_acc_243);
        heff_drop(v_c_244);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2estringAt_2estringFrom_240_24cpr_str0)}), MK_INT(0LL)}});
      } else {
        if ((heff_unbox_word(v_c_244) < ((int64_t)32ULL))) {
          heff_drop(v_start_241);
          heff_drop(v_acc_243);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2estringAt_2estringFrom_240_24cpr_str1)}), MK_INT(0LL)}});
        } else {
          V t_0 = v_s_240;
          V t_1 = v_start_241;
          V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
          V t_3 = v_acc_243;
          v_s_240 = t_0;
          v_start_241 = t_1;
          v_i_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
  }
}
Clo g_json_2estringAt_2estringFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_json_2estringAt_2estringFrom_240_entry, 4, 0};

V g_json_2estringAt_2estringFrom_240(V v_s_240, V v_start_241, V v_i_242, V v_acc_243) {
top: ;
  HeffT3 v_t_244 = (g_json_2estringAt_2estringFrom_240_24cpr(v_s_240, v_start_241, v_i_242, v_acc_243));
  {
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_field_247);
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_246});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_246, v_field_247})});
    }
  }
}
V g_json_2estringAt_2estringFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2estringAt_2estringFrom_240(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}