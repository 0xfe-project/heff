// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ReadOnly 17623
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_cmt 308164
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_group 299987609
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_tok 324554
#define LBL_version 583465758
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s942716005x1337691863(V, V, V, V);
V g_co_2eop_24s942716005x1337691863_entry(V self, V *a);
extern Clo g_co_2eop_24s942716005x1337691863_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383(V, V, V);
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_clo;
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039_clo;
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012(V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_clo;
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_clo;
V g_heff_2ebuild_2efetch_2enewerTagged(V, V, V);
V g_heff_2ebuild_2efetch_2enewerTagged_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewerTagged_clo;
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368(V, V, V, V);
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_clo;
V g_heff_2ebuild_2efetch_2erevSaid(V);
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2erevSaid_clo;
HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V);
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906(V, V, V, V);
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_clo;
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069(V, V, V, V);
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(V, V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
HeffT3 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT3 g_heff_2ebuild_2eproject_2espanGo_24cpr(V, V);
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eany_24s1435008228x557204311(V, V);
V g_list_2eany_24s1435008228x557204311_entry(V self, V *a);
extern Clo g_list_2eany_24s1435008228x557204311_clo;
V g_list_2eany_24s944501138x775098345(V, V);
V g_list_2eany_24s944501138x775098345_entry(V self, V *a);
extern Clo g_list_2eany_24s944501138x775098345_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1788498486x1573409871(V, V, V);
V g_list_2efoldl_24s1788498486x1573409871_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1788498486x1573409871_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24s1193924222x1531824795(V, V, V);
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2ewords_2ewordsFrom_240(V, V, V, V);
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2efetch_2enewerTagged_str0, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewerTagged_str1, 11, "refs/tags/v");
Clo g_heff_2ebuild_2efetch_2enewerTagged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewerTagged_entry, 3, 0};

V g_heff_2ebuild_2efetch_2enewerTagged(V v_path_240, V v_best_241, V v_line_242) {
top: ;
  V v_it_243 = ({ V a_0 = v_line_242; V b_1 = ((V)&g_heff_2ebuild_2efetch_2enewerTagged_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2enewerTagged_str1), v_line_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_241;
  }
  case TAG_Cons: {
    V v_it2_245 = heff_field(v_it_243, 1);
    V v_ru_24it_243_24Cons = heff_take_reuse_n(v_it_243, 2ULL, 2);
    switch (heff_tag_of(v_it2_245)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      heff_drop_cell(v_ru_24it_243_24Cons, 2);
      return v_best_241;
    }
    case TAG_Cons: {
      V v_v_246 = heff_field(v_it2_245, 0);
      V v_it22_247 = heff_field(v_it2_245, 1);
      V v_ru_24it2_245_24Cons = heff_take_reuse_n(v_it2_245, 3ULL, 2);
      switch (heff_tag_of(v_it22_247)) {
      case TAG_Nil: {
        V v_t_248 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
        V v_t_2410 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_249), MK_INT(-1LL)));
        V v_t_2411 = heff_strSlice(heff_dup(v_v_246), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
        HeffT5 v_t_2412 = ({ V a_0 = v_t_2411; HeffT5 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2411); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          V v_field_2415 = v_t_2412.f[2];
          V v_field_2416 = v_t_2412.f[3];
          V v_field_2417 = v_t_2412.f[4];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_t_2418 = heff_tag_at_n(v_ru_24it_243_24Cons, TAG_Cons, 2, (V[]){v_field_2415, heff_tag_at_n(v_ru_24it2_245_24Cons, TAG_Cons, 2, (V[]){v_field_2416, v_field_2417})});
            V v_x_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2414, v_t_2418});
            heff_drop_tag(v_x_2419, 2);
            V v_t_2420 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
            int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
            V v_t_2422 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2421), MK_INT(-1LL)));
            V v_t_2423 = heff_strSlice(heff_dup(v_v_246), v_t_2420, heff_intAdd(v_t_2422, MK_INT(1LL)));
            HeffT2 v_t_2424 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(v_path_240, v_t_2423));
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              if ((v_tag_2425 == ((int64_t)0ULL))) {
                heff_drop(v_v_246);
                V v_x_2427 = v_field_2426;
                heff_drop(v_x_2427);
                return v_best_241;
              } else {
                heff_drop(v_field_2426);
                switch (heff_tag_of(v_best_241)) {
                case TAG_Nothing: {
                  V v_t_2428 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2429 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2430 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2429), MK_INT(-1LL)));
                  V v_t_2431 = heff_strSlice(v_v_246, v_t_2428, heff_intAdd(v_t_2430, MK_INT(1LL)));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
                }
                case TAG_Just: {
                  V v_b_2432 = heff_dup(heff_field(v_best_241, 0));
                  V v_t_2433 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2435 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2434), MK_INT(-1LL)));
                  V v_t_2436 = heff_strSlice(heff_dup(v_v_246), v_t_2433, heff_intAdd(v_t_2435, MK_INT(1LL)));
                  V v_t_2437 = ({ V a_0 = v_t_2436; V a_1 = v_b_2432; V r_ = (g_heff_2ebuild_2eproject_2enewer(a_0, a_1)); heff_drop(v_t_2436); heff_drop(v_b_2432); r_; });
                  if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
                    heff_drop_tag(v_best_241, 1);
                    heff_drop(v_t_2437);
                    V v_t_2438 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                    int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                    V v_t_2440 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2439), MK_INT(-1LL)));
                    V v_t_2441 = heff_strSlice(v_v_246, v_t_2438, heff_intAdd(v_t_2440, MK_INT(1LL)));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
                  } else {
                    heff_drop(v_v_246);
                    heff_drop(v_t_2437);
                    return v_best_241;
                  }
                }
                default: return heff_nomatch(v_best_241);
                }
              }
            }
          } else {
            heff_drop(v_path_240);
            heff_drop_cell(v_ru_24it_243_24Cons, 2);
            heff_drop(v_v_246);
            heff_drop_cell(v_ru_24it2_245_24Cons, 2);
            heff_drop(v_field_2414);
            heff_drop(v_field_2415);
            heff_drop(v_field_2416);
            heff_drop(v_field_2417);
            return v_best_241;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_247, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop_cell(v_ru_24it_243_24Cons, 2);
        heff_drop(v_v_246);
        heff_drop_cell(v_ru_24it2_245_24Cons, 2);
        return v_best_241;
      }
      default: return heff_nomatch(v_it22_247);
      }
    }
    default: return heff_nomatch(v_it2_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ebuild_2efetch_2enewerTagged_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2efetch_2enewerTagged(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str0, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str1, 28, "commit on the default branch");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str2, 7, "commit ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str3, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str4, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str5, 7, "branch ");
Clo g_heff_2ebuild_2efetch_2erevSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2erevSaid_entry, 1, 0};

V g_heff_2ebuild_2efetch_2erevSaid(V v_rev_240) {
top: ;
  if (heff_strEq_c_lent(v_rev_240, ((V)&g_heff_2ebuild_2efetch_2erevSaid_str0), 2)) {
    heff_drop(v_rev_240);
    return ((V)&g_heff_2ebuild_2efetch_2erevSaid_str1);
  } else {
    if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_240, 0)))) {
      if ((heff_unbox_word(heff_strLength_lent(v_rev_240, 0)) <= ((int64_t)40ULL))) {
        V v_t_241 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_240, 0)));
        V v_t_242 = ({ V a_0 = v_rev_240; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_241; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_241); r_; });
        if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str2), v_rev_240);
        } else {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str3), v_rev_240);
        }
      } else {
        return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str4), v_rev_240);
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str5), v_rev_240);
    }
  }
}
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2erevSaid(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2especOf_24cpr_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2efetch_2especOf_24cpr_str1, 1, "@");

HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V v_spec_240) {
top: ;
  V v_it_241 = ({ V a_0 = v_spec_240; V b_1 = ((V)&g_heff_2ebuild_2efetch_2especOf_24cpr_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2especOf_24cpr_str1), v_spec_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_path_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_path_242);
      return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_spec_240);
        return ((HeffT2){{v_path_242, heff_tag_n(TAG_Just, 1, (V[]){v_v_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it22_245, 0ULL, 2);
        heff_drop(v_path_242);
        heff_drop(v_v_244);
        return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str2, 1, "1");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str3, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str4, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str5, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str6, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str7, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str8, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str9, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str11, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str13, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str14, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str15, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str19, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str22, 3, "): ");
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_entry, 4, 0};

V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069(V v_e_240, V v_path_241, V v_v_242, V v_dir_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_dir_243, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str0), v_t_244), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str1), heff_dup(v_v_242)), v_t_246});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str3), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str5), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str7), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str8), v_t_2410});
  return heff_clo_n(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam0, 2, 4, (V[]){v_t_2411, v_e_240, v_path_241, v_v_242});
}
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam1(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_ended_2424 = heff_take_field(v_x_2423, 0);
  V v_err_2425 = heff_get_n(v_x_2423, 2, 3);
  V v_t_2429;
  switch (heff_tag_of(v_ended_2424)) {
  case TAG_Exited: {
    V v_n_2426 = heff_dup(heff_field(v_ended_2424, 0));
    v_t_2429 = heff_bool(heff_intEq_c_lent(v_n_2426, MK_INT(0LL), 2));
    heff_drop(v_n_2426);
    break;
  }
  case TAG_Signalled: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2424);
  }
  V v_x_2450;
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    heff_drop(v_ended_2424);
    heff_drop(v_err_2425);
    heff_drop(v_t_2429);
    v_x_2450 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2429);
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str11), heff_dup(v_path_241)), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str12));
    V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, heff_dup(v_v_242)), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str13));
    V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, v_v_242), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str14));
    V v_t_2433 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
    V v_t_2434 = heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str15), v_t_2433));
    V v_t_2443;
    switch (heff_tag_of(v_ended_2424)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2424, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str16);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2424, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str17);
      break;
    }
    case TAG_TimedOut: {
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str18);
      break;
    }
    case TAG_NotRun: {
      V v_err_2437 = heff_field(v_ended_2424, 0);
      heff_take_n(v_ended_2424, 1ULL, 1);
      V v_path_2438 = heff_take_field(v_err_2437, 3);
      V v_name_2439 = heff_take_field(v_err_2437, 1);
      V v_message_2440 = heff_get_n(v_err_2437, 2, 4);
      V v_t_2441 = heff_strAppend(heff_strAppend(v_path_2438, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str19)), v_name_2439);
      V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str20)), v_message_2440);
      v_t_2443 = heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str21));
      break;
    }
    default: heff_nomatch(v_ended_2424);
    }
    V v_s_2444 = heff_strAppend(v_t_2443, v_err_2425);
    V v_t_2445 = (g_prelude_2eskipSpaces(v_s_2444, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2446 = (heff_unbox_word(heff_strLength_lent(v_s_2444, 0)) - ((int64_t)1ULL));
    V v_t_2447 = (g_prelude_2eskipSpaces(v_s_2444, heff_box_word(v_t_2446), MK_INT(-1LL)));
    V v_t_2448 = heff_strSlice(v_s_2444, v_t_2445, heff_intAdd(v_t_2447, MK_INT(1LL)));
    V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str22)), v_t_2448);
    v_x_2450 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2449});
  }
  V f_ = v_k_2413;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str9), v_t_2411, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_str10), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam1_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2422, v_hd_2412, heff_clo_n(g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069_lam2, 1, 3, (V[]){v_path_241, v_v_242, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str1, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str2, 32, "--date=format-local:%Y%m%d%H%M%S");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str3, 15, "--format=%cd %H");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str4, 3, "log");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str5, 2, "-1");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str6, 2, "TZ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str7, 4, "UTC0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str8, 3, "git");
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_entry, 3, 0};

V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383(V v_e_240, V v_dir_241, V v_rev_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_241));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str0), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_rev_242, ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str1)), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str3), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str5), v_t_246})});
  V v_t_248 = ({ V a_0 = v_t_243; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_243); r_; });
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str6), ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str7)}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_str8), v_t_247, v_t_248, v_t_249, NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2412 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam1, 2, 2, (V[]){v_a_2412, v_e_240});
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ended_2422 = heff_take_field(v_x_2421, 0);
  V v_out_2423 = heff_get_n(v_x_2421, 1, 3);
  V v_x_2434;
  switch (heff_tag_of(v_ended_2422)) {
  case TAG_Exited: {
    V v_n_2424 = heff_field(v_ended_2422, 0);
    V v_ru_24ended_2422_24Exited = heff_take_reuse_n(v_ended_2422, 1ULL, 1);
    if (heff_intEq_c(v_n_2424, MK_INT(0LL))) {
      V v_x1_2425 = ({ V a_0 = v_out_2423; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_out_2423); r_; });
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24ended_2422_24Exited, 1);
        v_x_2434 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_time_2426 = heff_field(v_x1_2425, 0);
        V v_x12_2427 = heff_field(v_x1_2425, 1);
        V v_ru_24x1_2425_24Cons = heff_take_reuse_n(v_x1_2425, 3ULL, 2);
        switch (heff_tag_of(v_x12_2427)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24ended_2422_24Exited, 1);
          heff_drop(v_time_2426);
          heff_drop_cell(v_ru_24x1_2425_24Cons, 2);
          v_x_2434 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_hash_2428 = heff_field(v_x12_2427, 0);
          V v_x122_2429 = heff_field(v_x12_2427, 1);
          heff_take_n(v_x12_2427, 3ULL, 2);
          switch (heff_tag_of(v_x122_2429)) {
          case TAG_Nil: {
            v_x_2434 = heff_tag_at_n(v_ru_24ended_2422_24Exited, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_2425_24Cons, TAG_MkPair, 2, (V[]){v_time_2426, v_hash_2428})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x122_2429, 0ULL, 2);
            heff_drop_cell(v_ru_24ended_2422_24Exited, 1);
            heff_drop(v_time_2426);
            heff_drop_cell(v_ru_24x1_2425_24Cons, 2);
            heff_drop(v_hash_2428);
            v_x_2434 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x122_2429);
          }
          break;
        }
        default: heff_nomatch(v_x12_2427);
        }
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
    } else {
      heff_drop(v_out_2423);
      heff_drop_cell(v_ru_24ended_2422_24Exited, 1);
      v_x_2434 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2422, 0ULL, 1);
    heff_drop(v_out_2423);
    v_x_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_TimedOut: {
    heff_drop(v_out_2423);
    v_x_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_ended_2422, 0ULL, 1);
    heff_drop(v_out_2423);
    v_x_2434 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_ended_2422);
  }
  V f_ = v_k_2414;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_a_2412 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_2413, heff_clo_n(g_heff_2ebuild_2efetch_2ecommitAt_24s1414866995x638961383_lam2, 1, 1, (V[]){v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str1, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str4, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str5, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str8, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str9, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str10, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str12, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str13, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str15, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str17, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str18, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str19, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str20, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str21, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str22, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str23, 4, " in ");
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam1, 3, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam3, 3, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam5(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam5, 3, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam7(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam7, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam11(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam11, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam13(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam13, 3, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam15(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam15, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam17(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam16(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam18(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam18, 3, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam20(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam20, 3, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam22(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam23(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam21(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam19(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam24(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam24, 3, 0};
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam25(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_entry, 4, 0};

V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012(V v_e_240, V v_ps_241, V v_path_242, V v_v_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), heff_dup(v_v_243)));
  return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam0, 2, 5, (V[]){v_x_244, v_e_240, v_ps_241, v_path_242, v_v_243});
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2441 = args[1];
  V v_k_2442 = args[2];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam7(V self, V *args) {
  V v_t_2446 = args[0];
  return v_t_2446;
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam11(V self, V *args) {
  V v_r_2466 = args[0];
  return v_r_2466;
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam13(V self, V *args) {
  V v_x_2485 = args[0];
  V v_hd_2486 = args[1];
  V v_k_2487 = args[2];
  heff_drop(v_hd_2486);
  V f_ = v_k_2487;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2485});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam15(V self, V *args) {
  V v_r_2494 = args[0];
  return v_r_2494;
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam17(V self, V *args) {
  V v_x_2498 = args[0];
  V v_hd_2496 = heff_env(self)[0];
  V v_k_2497 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2498)) {
  case TAG_Left: {
    V v_err_2499 = heff_field(v_x_2498, 0);
    V v_ru_24x_2498_24Left = heff_take_reuse_n(v_x_2498, 1ULL, 1);
    V v_t_24100 = heff_tag_at_n(v_ru_24x_2498_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2499})});
    V v_t_24101 = heff_tr(heff_call(heff_take_field(v_hd_2496, 2), 1, (V[]){v_t_24100}));
    V f_ = heff_get_n(v_hd_2496, 1, 3);
    heff_room[0] = v_t_24101;
    heff_room[1] = v_k_2497;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_x_24102 = heff_field(v_x_2498, 0);
    heff_take_n(v_x_2498, 1ULL, 1);
    heff_drop_rec(v_hd_2496, 3);
    V f_ = v_k_2497;
    args[0] = v_x_24102;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2498);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam16(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k_2497 = args[1];
  V v_a_2495 = heff_env(self)[0];
  V v_lit_2491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s942716005x1337691863(v_a_2495, v_lit_2491, heff_dup(v_hd_2496), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam17, 1, 2, (V[]){v_hd_2496, v_k_2497})));
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam18(V self, V *args) {
  V v_x_24105 = args[0];
  V v_hd_24106 = args[1];
  V v_k_24107 = args[2];
  heff_drop(v_hd_24106);
  V f_ = v_k_24107;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24105});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam20(V self, V *args) {
  V v_x_24122 = args[0];
  V v_hd_24123 = args[1];
  V v_k_24124 = args[2];
  heff_drop(v_hd_24123);
  V f_ = v_k_24124;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24122});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam22(V self, V *args) {
  V v_x_24141 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_24118 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24141);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24118});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam23(V self, V *args) {
  V v_x_24159 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_24118 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24159);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24118});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam21(V self, V *args) {
  V v_x_24126 = args[0];
  V v_ended_2476 = heff_env(self)[0];
  V v_x_24112 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_x_24118 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_24126)) {
  case TAG_Left: {
    V v_ru_24x_24126_24Left = heff_take_reuse_n(v_x_24126, 0ULL, 1);
    V v_t_24131;
    switch (heff_tag_of(v_ended_2476)) {
    case TAG_Exited: {
      V v_n_24128 = heff_field(v_ended_2476, 0);
      heff_take_n(v_ended_2476, 1ULL, 1);
      v_t_24131 = heff_bool(heff_intEq_c_lent(v_n_24128, MK_INT(0LL), 2));
      heff_drop(v_n_24128);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2476, 0ULL, 1);
      v_t_24131 = NTAG(TAG_False);
      break;
    }
    case TAG_TimedOut: {
      v_t_24131 = NTAG(TAG_False);
      break;
    }
    case TAG_NotRun: {
      heff_take_n(v_ended_2476, 0ULL, 1);
      v_t_24131 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_ended_2476);
    }
    if (((heff_dup(v_t_24131) == NTAG(TAG_True)) && ((heff_dup(v_x_24112) == NTAG(TAG_True)) && 0))) {
      heff_drop(v_x_24112);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x_24126_24Left, 1);
      heff_drop(v_t_24131);
      V v_t_24132 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str12), v_path_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str13));
      V v_t_24133 = heff_strAppend(heff_strAppend(v_t_24132, v_v_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str14));
      V v_t_24134 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24133, NTAG(TAG_MkUnit)});
      V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
      V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
      V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
      V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
      V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24140}), v_hd_245, heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam22, 1, 2, (V[]){v_k_246, v_x_24118})));
    } else {
      heff_drop(v_x_24112);
      heff_drop(v_e_240);
      heff_drop(v_hd_245);
      heff_drop(v_x_24118);
      heff_drop(v_t_24131);
      V v_t_24142 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str15), v_path_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str16));
      V v_t_24143 = heff_strAppend(heff_strAppend(v_t_24142, v_v_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str17));
      V v_t_24144 = heff_tag_at_n(v_ru_24x_24126_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_24143, v_x_244)});
      V f_ = v_k_246;
      args[0] = v_t_24144;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  case TAG_Right: {
    V v_ru_24x_24126_24Right = heff_take_reuse_n(v_x_24126, 0ULL, 1);
    V v_t_24149;
    switch (heff_tag_of(v_ended_2476)) {
    case TAG_Exited: {
      V v_n_24146 = heff_field(v_ended_2476, 0);
      heff_take_n(v_ended_2476, 1ULL, 1);
      v_t_24149 = heff_bool(heff_intEq_c_lent(v_n_24146, MK_INT(0LL), 2));
      heff_drop(v_n_24146);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2476, 0ULL, 1);
      v_t_24149 = NTAG(TAG_False);
      break;
    }
    case TAG_TimedOut: {
      v_t_24149 = NTAG(TAG_False);
      break;
    }
    case TAG_NotRun: {
      heff_take_n(v_ended_2476, 0ULL, 1);
      v_t_24149 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_ended_2476);
    }
    if (((heff_dup(v_t_24149) == NTAG(TAG_True)) && (heff_dup(v_x_24112) == NTAG(TAG_True)))) {
      heff_drop(v_x_24112);
      heff_drop(v_x_244);
      heff_drop(v_t_24149);
      V v_t_24150 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str18), v_path_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str19));
      V v_t_24151 = heff_strAppend(heff_strAppend(v_t_24150, v_v_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str20));
      V v_t_24152 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24151, NTAG(TAG_MkUnit)});
      V v_t_24153 = heff_tag_at_n(v_ru_24x_24126_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
      V v_t_24154 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
      V v_t_24155 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24154})});
      V v_t_24156 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24155})});
      V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
      V v_t_24158 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24157})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24158}), v_hd_245, heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam23, 1, 2, (V[]){v_k_246, v_x_24118})));
    } else {
      heff_drop(v_x_24112);
      heff_drop(v_e_240);
      heff_drop(v_hd_245);
      heff_drop(v_x_24118);
      heff_drop(v_t_24149);
      V v_t_24160 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str21), v_path_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str22));
      V v_t_24161 = heff_strAppend(heff_strAppend(v_t_24160, v_v_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str23));
      V v_t_24162 = heff_tag_at_n(v_ru_24x_24126_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_24161, v_x_244)});
      V f_ = v_k_246;
      args[0] = v_t_24162;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_24126);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam19(V self, V *args) {
  V v_x_24109 = args[0];
  V v_out_2475 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_ended_2476 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_v_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_24112;
  switch (heff_tag_of(v_x_24109)) {
  case TAG_Left: {
    heff_take_n(v_x_24109, 0ULL, 1);
    v_x_24112 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_24109, 0ULL, 1);
    v_x_24112 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_24109);
  }
  V v_s_24113 = v_out_2475;
  V v_t_24114 = (g_prelude_2eskipSpaces(v_s_24113, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_24115 = (heff_unbox_word(heff_strLength_lent(v_s_24113, 0)) - ((int64_t)1ULL));
  V v_t_24116 = (g_prelude_2eskipSpaces(v_s_24113, heff_box_word(v_t_24115), MK_INT(-1LL)));
  V v_t_24117 = heff_strSlice(v_s_24113, v_t_24114, heff_intAdd(v_t_24116, MK_INT(1LL)));
  V v_x_24118 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str9), v_t_24117);
  V v_path_24119 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str10))));
  V v_c_24120 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_24119; V a_2 = heff_strAppend(heff_dup(v_x_24118), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str11)); V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_24119); r_; });
  V v_t_24121 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_24125 = heff_tr(heff_call(v_c_24120, 2, (V[]){v_t_24121, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam20_clo)}));
  V f_ = v_c_24125;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam21, 1, 9, (V[]){v_ended_2476, v_x_24112, v_path_242, v_v_243, v_e_240, v_hd_245, v_k_246, v_x_24118, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam14(V self, V *args) {
  V v_x_2489 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_out_2475 = heff_env(self)[3];
  V v_ended_2476 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_v_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2489);
  V v_path_2490 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_244)));
  V v_lit_2491 = heff_dup(v_e_240);
  V v_path_2492 = v_path_2490;
  V v_t_2493 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2492; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2492); r_; });
  V v_a_2495 = heff_tag_n(TAG_ReadOnly, 2, (V[]){v_t_2493, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam15_clo)});
  V v_c_24103 = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam16, 2, 2, (V[]){v_a_2495, v_lit_2491});
  V v_t_24104 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_24108 = heff_tr(heff_call(v_c_24103, 2, (V[]){v_t_24104, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam18_clo)}));
  V f_ = v_c_24108;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam19, 1, 8, (V[]){v_out_2475, v_x_244, v_e_240, v_hd_245, v_ended_2476, v_path_242, v_v_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam12(V self, V *args) {
  V v_x_2474 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_out_2475 = heff_take_field(v_x_2474, 1);
  V v_ended_2476 = heff_get_n(v_x_2474, 0, 3);
  V v_st_2477 = heff_get_n(v_ps_241, 5, 6);
  V v_t_2478 = (g_std_2epath_2eparse(heff_dup(v_st_2477), heff_dup(v_x_244)));
  V v_t_2479 = (g_std_2epath_2eparse(heff_dup(v_st_2477), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str8)));
  V v_t_2480 = (g_std_2epath_2ejoin(v_t_2478, v_t_2479));
  V v_s_2481 = ({ V a_0 = v_st_2477; V a_1 = v_t_2480; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2477); heff_drop(v_t_2480); r_; });
  V v_path_2482 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2481));
  V v_c_2483 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2482; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2482); r_; });
  V v_t_2484 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2488 = heff_tr(heff_call(v_c_2483, 2, (V[]){v_t_2484, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam13_clo)}));
  V f_ = v_c_2488;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam14, 1, 8, (V[]){v_x_244, v_e_240, v_hd_245, v_out_2475, v_ended_2476, v_path_242, v_v_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam24(V self, V *args) {
  V v_x_24167 = args[0];
  V v_hd_24168 = args[1];
  V v_k_24169 = args[2];
  heff_drop(v_hd_24168);
  V f_ = v_k_24169;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24167});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam25(V self, V *args) {
  V v_x_24171 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_why_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24171);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_24163});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2458 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_v_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2461);
  switch (heff_tag_of(v_x_2458)) {
  case TAG_Nothing: {
    V v_t_2462 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_244)));
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str5), NTAG(TAG_Nil)});
    V v_t_2464 = ({ V a_0 = v_t_2462; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2462); r_; });
    V v_t_2465 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str7), v_t_2463}), v_t_2464, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2467 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2465, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam11_clo)});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam12, 1, 7, (V[]){v_ps_241, v_x_244, v_e_240, v_hd_245, v_path_242, v_v_243, v_k_246})));
  }
  case TAG_Just: {
    V v_why_24163 = heff_field(v_x_2458, 0);
    heff_take_n(v_x_2458, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    V v_path_24164 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_244));
    V v_c_24165 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_24164; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_24164); r_; });
    V v_t_24166 = (g_exception_2eattempted(v_e_240));
    V v_c_24170 = heff_tr(heff_call(v_c_24165, 2, (V[]){v_t_24166, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam24_clo)}));
    V f_ = v_c_24170;
    heff_room[0] = v_hd_245;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam25, 1, 2, (V[]){v_k_246, v_why_24163});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2458);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam9(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2449 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_v_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2459 = heff_tag_n(TAG_End, 2, (V[]){v_x_2449, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam10, 1, 8, (V[]){v_x_2458, v_x_244, v_e_240, v_hd_245, v_ps_241, v_path_242, v_v_243, v_k_246})));
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_v_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450 = ({ V a_0 = v_v_243; V b_1 = ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str3); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str4), v_v_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  HeffT3 v_t_2451 = ({ V a_0 = v_t_2450; HeffT3 r_ = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(a_0)); heff_drop(v_t_2450); r_; });
  {
    V v_field_2453 = v_t_2451.f[1];
    V v_field_2454 = v_t_2451.f[2];
    int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
    V v_c_2457;
    if ((v_tag_2452 == ((int64_t)0ULL))) {
      V v_time_2455 = v_field_2453;
      V v_hash_2456 = v_field_2454;
      v_c_2457 = (g_heff_2ebuild_2efetch_2ecommitCloned_24s362174243x393534039(heff_dup(v_e_240), heff_dup(v_path_242), heff_dup(v_v_243), v_time_2455, v_hash_2456, heff_dup(v_x_244)));
    } else {
      heff_drop(v_field_2453);
      heff_drop(v_field_2454);
      v_c_2457 = (g_heff_2ebuild_2efetch_2etagCloned_24s352930315x1048405069(heff_dup(v_e_240), heff_dup(v_path_242), heff_dup(v_v_243), heff_dup(v_x_244)));
    }
    V f_ = v_c_2457;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam9, 1, 8, (V[]){v_x_2449, v_e_240, v_hd_245, v_x_244, v_ps_241, v_path_242, v_v_243, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str1), heff_dup(v_path_242)), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str2));
  V v_t_2447 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(v_t_2445, heff_dup(v_v_243)), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam7_clo)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam8, 1, 7, (V[]){v_v_243, v_e_240, v_path_242, v_x_244, v_hd_245, v_ps_241, v_k_246})));
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2423);
  V v_st_2424 = heff_dup(heff_rfield(v_ps_241, 5));
  HeffT3 v_t_2425 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2424), heff_dup(v_x_244)));
  V v_t_2435;
  {
    V v_field_2426 = v_t_2425.f[0];
    V v_field_2427 = v_t_2425.f[1];
    V v_field_2428 = v_t_2425.f[2];
    V v_d_2429 = v_field_2426;
    V v_a_2430 = v_field_2427;
    V v_xs_2431 = v_field_2428;
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    V v_xs_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2432; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2432); r_; });
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2433));
    v_t_2435 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2429, v_a_2430, v_t_2434});
  }
  V v_s_2436 = ({ V a_0 = v_st_2424; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); heff_drop(v_t_2435); r_; });
  V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2436));
  V v_c_2438 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2437; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2437); r_; });
  V v_t_2439 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2443 = heff_tr(heff_call(v_c_2438, 2, (V[]){v_t_2439, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam5_clo)}));
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam6, 1, 7, (V[]){v_path_242, v_v_243, v_e_240, v_hd_245, v_x_244, v_ps_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_244)));
    V v_c_2417 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2416; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2416); r_; });
    V v_t_2418 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2422 = heff_tr(heff_call(v_c_2417, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam3_clo)}));
    V f_ = v_c_2422;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam4, 1, 7, (V[]){v_ps_241, v_x_244, v_e_240, v_hd_245, v_path_242, v_v_243, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_24172 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_drop(v_x_244);
    heff_drop(v_e_240);
    heff_drop(v_hd_245);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    V v_t_24173 = (g_prelude_2eskipSpaces(v_y_24172, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24174 = (heff_unbox_word(heff_strLength_lent(v_y_24172, 0)) - ((int64_t)1ULL));
    V v_t_24175 = (g_prelude_2eskipSpaces(v_y_24172, heff_box_word(v_t_24174), MK_INT(-1LL)));
    V v_t_24176 = heff_strSlice(v_y_24172, v_t_24173, heff_intAdd(v_t_24175, MK_INT(1LL)));
    V v_x_24177 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_Right, 1, (V[]){v_t_24176});
    V f_ = v_k_246;
    args[0] = v_x_24177;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_str0))));
  V v_c_248 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_247; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_247); r_; });
  V v_t_249 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2413 = heff_tr(heff_call(v_c_248, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam1_clo)}));
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012_lam2, 1, 7, (V[]){v_x_244, v_e_240, v_hd_245, v_ps_241, v_path_242, v_v_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_str0, 5, ".hash");
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam0, 2, 0};
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam3, 3, 0};
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_entry, 4, 0};

V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906(V v_e_240, V v_ps_241, V v_root_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_ps_241);
    heff_drop_rec(v_root_242, 4);
    return ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_path_248 = heff_take_field(v_x_246, 0);
    V v_version_249 = heff_get_n(v_x_246, 1, 3);
    V v_c_2410 = (g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_root_242), v_rest_247));
    return heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam1, 2, 6, (V[]){v_c_2410, v_ps_241, v_path_248, v_version_249, v_e_240, v_root_242});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_version_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    heff_drop(v_version_249);
    V v_t_2425 = ({ V a_0 = v_path_248; V a_1 = heff_take_field(v_root_242, 2); V r_ = (g_list_2ekeepIf_24s1943838498x1969994910(a_0, a_1)); heff_drop(v_path_248); r_; });
    V v_x_2431;
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nil: {
      heff_drop_rec(v_root_242, 4);
      v_x_2431 = v_x_2413;
      break;
    }
    case TAG_Cons: {
      V v_r_2426 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 2);
      V v_t_2428 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2426, heff_get_n(v_root_242, 3, 4)));
      switch (heff_tag_of(v_t_2428)) {
      case TAG_Nil: {
        v_x_2431 = v_x_2413;
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2428, 0ULL, 2);
        v_x_2431 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_t_2428);
      }
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
    V f_ = v_k_2412;
    args[0] = v_x_2431;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    V v_t_2433 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_248, heff_take_field(v_root_242, 2)));
    V v_x_2447;
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      heff_drop_rec(v_root_242, 4);
      V v_t_2434 = (g_prelude_2eskipSpaces(v_y_2432, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_y_2432, 0)) - ((int64_t)1ULL));
      V v_t_2436 = (g_prelude_2eskipSpaces(v_y_2432, heff_box_word(v_t_2435), MK_INT(-1LL)));
      V v_t_2437 = heff_strSlice(v_y_2432, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
      v_x_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_248, v_version_249, v_t_2437}), v_x_2413});
      break;
    }
    case TAG_Cons: {
      V v_r_2438 = heff_field(v_t_2433, 0);
      V v_ru_24t_2433_24Cons = heff_take_reuse_n(v_t_2433, 1ULL, 2);
      V v_t_2440 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2438, heff_get_n(v_root_242, 3, 4)));
      switch (heff_tag_of(v_t_2440)) {
      case TAG_Nil: {
        V v_t_2441 = (g_prelude_2eskipSpaces(v_y_2432, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_y_2432, 0)) - ((int64_t)1ULL));
        V v_t_2443 = (g_prelude_2eskipSpaces(v_y_2432, heff_box_word(v_t_2442), MK_INT(-1LL)));
        V v_t_2444 = heff_strSlice(v_y_2432, v_t_2441, heff_intAdd(v_t_2443, MK_INT(1LL)));
        v_x_2447 = heff_tag_at_n(v_ru_24t_2433_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_248, v_version_249, v_t_2444}), v_x_2413});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2440, 0ULL, 2);
        heff_drop(v_path_248);
        heff_drop(v_version_249);
        heff_drop(v_y_2432);
        heff_drop_cell(v_ru_24t_2433_24Cons, 2);
        v_x_2447 = v_x_2413;
        break;
      }
      default: heff_nomatch(v_t_2440);
      }
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    V f_ = v_k_2412;
    args[0] = v_x_2447;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_path_248 = heff_env(self)[1];
  V v_version_249 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_root_242 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_241, heff_dup(v_path_248), heff_dup(v_version_249)));
  V v_s_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_str0));
  V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2415));
  V v_c_2417 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2416; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2416); r_; });
  V v_t_2418 = (g_exception_2eattempted(v_e_240));
  V v_c_2422 = heff_tr(heff_call(v_c_2417, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam3_clo)}));
  V f_ = v_c_2422;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam4, 1, 5, (V[]){v_path_248, v_root_242, v_x_2413, v_k_2412, v_version_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_248 = heff_env(self)[2];
  V v_version_249 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_root_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s1548875636x1391885906_lam2, 1, 7, (V[]){v_ps_241, v_path_248, v_version_249, v_e_240, v_hd_2411, v_root_242, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str4, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str5, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str7, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str8, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str13, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str17, 1, "\012");
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam2(V self, V *args); static Clo g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam2, 1, 0};
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_entry, 4, 0};

V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368(V v_e_240, V v_path_241, V v_p_242, V v_p_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str0), heff_dup(v_path_241)), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam0_clo)});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam1, 1, 4, (V[]){v_path_241, v_e_240, v_p_242, v_p_243}));
}
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam2(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_ended_2422 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_err_2423 = heff_env(self)[2];
  V v_out_2424 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  V v_t_2431;
  switch (heff_tag_of(v_ended_2422)) {
  case TAG_Exited: {
    V v_n_2428 = heff_dup(heff_field(v_ended_2422, 0));
    v_t_2431 = heff_bool(!heff_intEq_c_lent(v_n_2428, MK_INT(0LL), 2));
    heff_drop(v_n_2428);
    break;
  }
  case TAG_Signalled: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2422);
  }
  V v_x_2452;
  if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
    heff_drop(v_out_2424);
    heff_drop(v_t_2431);
    V v_t_2432 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str7), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str8), v_t_2432));
    V v_t_2442;
    switch (heff_tag_of(v_ended_2422)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2422, 0ULL, 1);
      v_t_2442 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str9);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2422, 0ULL, 1);
      v_t_2442 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str10);
      break;
    }
    case TAG_TimedOut: {
      v_t_2442 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str11);
      break;
    }
    case TAG_NotRun: {
      V v_err_2436 = heff_field(v_ended_2422, 0);
      heff_take_n(v_ended_2422, 1ULL, 1);
      V v_path_2437 = heff_take_field(v_err_2436, 3);
      V v_name_2438 = heff_take_field(v_err_2436, 1);
      V v_message_2439 = heff_get_n(v_err_2436, 2, 4);
      V v_t_2440 = heff_strAppend(heff_strAppend(v_path_2437, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str12)), v_name_2438);
      V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str13)), v_message_2439);
      v_t_2442 = heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str14));
      break;
    }
    default: heff_nomatch(v_ended_2422);
    }
    V v_s_2443 = heff_strAppend(v_t_2442, v_err_2423);
    V v_t_2444 = (g_prelude_2eskipSpaces(v_s_2443, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2445 = (heff_unbox_word(heff_strLength_lent(v_s_2443, 0)) - ((int64_t)1ULL));
    V v_t_2446 = (g_prelude_2eskipSpaces(v_s_2443, heff_box_word(v_t_2445), MK_INT(-1LL)));
    V v_t_2447 = heff_strSlice(v_s_2443, v_t_2444, heff_intAdd(v_t_2446, MK_INT(1LL)));
    V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str15)), v_t_2447);
    v_x_2452 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2448});
  } else {
    heff_drop(v_ended_2422);
    heff_drop(v_err_2423);
    heff_drop(v_t_2431);
    V v_s_2449 = v_out_2424;
    V v_t_2450 = ({ V a_0 = v_s_2449; V b_1 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str16); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str17), v_s_2449, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_2449); heff_drop(b_1); r_; });
    V v_t_2451 = ({ V a_0 = v_path_241; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2450; V r_ = (g_list_2efoldl_24s1788498486x1573409871(a_0, a_1, a_2)); heff_drop(v_t_2450); r_; });
    v_x_2452 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2451});
  }
  V f_ = v_p_243;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_ended_2422 = heff_take_field(v_x_2421, 0);
  V v_err_2423 = heff_take_field(v_x_2421, 2);
  V v_out_2424 = heff_get_n(v_x_2421, 1, 3);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_p_242, heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam4, 1, 5, (V[]){v_ended_2422, v_path_241, v_err_2423, v_out_2424, v_p_243})));
}
V g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str1), v_t_248), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str3), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str4), v_t_2410});
  V v_t_2412 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str5), v_t_2411, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_str6), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam2_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2420, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s1932055707x394565368_lam3, 1, 5, (V[]){v_x_247, v_e_240, v_p_242, v_path_241, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str1, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str5, 3, "src");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str6, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str8, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str10, 1, "`");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str11, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str12, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str13, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str15, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str16, 11, "{ module = ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str17, 9, ", heff = ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str20, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str21, 13, ", require = [");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str22, 1, "]");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str25, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str26, 13, ", replace = [");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str27, 1, "]");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str28, 2, " }");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str29, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str30, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str31, 34, "heff get: cannot write package.hf\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str32, 30, "heff get: package.hf requires ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str33, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str34, 1, "\012");
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam0(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam15(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam15, 3, 0};
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam18(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam17(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam19(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam16(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam3(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_entry, 6, 0};

V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479(V v_e_240, V v_ps_241, V v_text_242, V v_pk_243, V v_path_244, V v_v_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_244), heff_dup(v_v_245)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_text_242);
      heff_drop_rec(v_pk_243, 4);
      heff_drop(v_v_245);
      V v_why_249 = v_field_248;
      return heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam0, 2, 3, (V[]){v_path_244, v_why_249, v_e_240});
    } else {
      heff_drop(v_field_248);
      V v_c_2430 = (g_heff_2ebuild_2efetch_2efetched_24s1193904264x873443012(heff_dup(v_e_240), heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
      return heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam3, 2, 7, (V[]){v_c_2430, v_e_240, v_ps_241, v_path_244, v_v_245, v_pk_243, v_text_242});
    }
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_2410, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam2, 1, 1, (V[]){v_k_2411})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_path_244 = heff_env(self)[0];
  V v_why_249 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_strAppend(heff_strAppend(v_path_244, ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str0)), v_why_249);
  V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str1), v_t_2412), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str2));
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam1, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam6(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2451);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_hd_2431, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam6, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam10(V self, V *args) {
  V v_x_2481 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2481);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam9(V self, V *args) {
  V v_x_2473 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2473);
  V v_t_2474 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2480}), v_hd_2431, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam10, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam12(V self, V *args) {
  V v_x_24100 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24100);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam11(V self, V *args) {
  V v_x_2492 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2492);
  V v_t_2493 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2499}), v_hd_2431, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam12, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam14(V self, V *args) {
  V v_x_24122 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24122);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam13(V self, V *args) {
  V v_x_24114 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24114);
  V v_t_24115 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24120})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24121}), v_hd_2431, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam14, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam15(V self, V *args) {
  V v_x_24176 = args[0];
  V v_hd_24177 = args[1];
  V v_k_24178 = args[2];
  heff_drop(v_hd_24177);
  V f_ = v_k_24178;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24176});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam18(V self, V *args) {
  V v_x_24197 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24197);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam17(V self, V *args) {
  V v_x_24189 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24189);
  V v_t_24190 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24191 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24190})});
  V v_t_24192 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24191})});
  V v_t_24193 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24192})});
  V v_t_24194 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24193})});
  V v_t_24195 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24194})});
  V v_t_24196 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24195})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24196}), v_hd_2431, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam18, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam19(V self, V *args) {
  V v_x_24208 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24208);
  V f_ = v_k_2432;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam16(V self, V *args) {
  V v_x_24180 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  V v_v_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_24180)) {
  case TAG_Left: {
    V v_ru_24x_24180_24Left = heff_take_reuse_n(v_x_24180, 0ULL, 1);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    V v_t_24182 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str31), NTAG(TAG_MkUnit)});
    V v_t_24183 = heff_tag_at_n(v_ru_24x_24180_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24182})});
    V v_t_24184 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24183})});
    V v_t_24185 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24184})});
    V v_t_24186 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24185})});
    V v_t_24187 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24186})});
    V v_t_24188 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24187})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24188}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam17, 1, 3, (V[]){v_e_240, v_hd_2431, v_k_2432})));
  }
  case TAG_Right: {
    V v_ru_24x_24180_24Right = heff_take_reuse_n(v_x_24180, 0ULL, 1);
    V v_t_24199 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str32), v_path_244), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str33));
    V v_t_24200 = heff_strAppend(heff_strAppend(v_t_24199, v_v_245), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str34));
    V v_t_24201 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24200, NTAG(TAG_MkUnit)});
    V v_t_24202 = heff_tag_at_n(v_ru_24x_24180_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24201})});
    V v_t_24203 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24202})});
    V v_t_24204 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24203})});
    V v_t_24205 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24204})});
    V v_t_24206 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24205})});
    V v_t_24207 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24206})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24207}), v_hd_2431, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam19, 1, 1, (V[]){v_k_2432})));
  }
  default: return heff_nomatch(v_x_24180);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam8(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2431 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  V v_path_244 = heff_env(self)[4];
  V v_pk_243 = heff_env(self)[5];
  V v_text_242 = heff_env(self)[6];
  V v_v_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Left: {
    V v_why_2464 = heff_field(v_x_2455, 0);
    V v_ru_24x_2455_24Left = heff_take_reuse_n(v_x_2455, 1ULL, 1);
    heff_drop(v_x_2463);
    heff_drop(v_path_244);
    heff_drop_rec(v_pk_243, 4);
    heff_drop(v_text_242);
    heff_drop(v_v_245);
    V v_t_2465 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str6), v_why_2464), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str7));
    V v_t_2466 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2465, NTAG(TAG_MkUnit)});
    V v_t_2467 = heff_tag_at_n(v_ru_24x_2455_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2472}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam9, 1, 3, (V[]){v_e_240, v_hd_2431, v_k_2432})));
  }
  case TAG_Right: {
    V v_ru_24x_2455_24Right = heff_take_reuse_n(v_x_2455, 0ULL, 1);
    switch (heff_tag_of(v_x_2463)) {
    case TAG_Left: {
      V v_why_2483 = heff_field(v_x_2463, 0);
      V v_ru_24x_2463_24Left = heff_take_reuse_n(v_x_2463, 1ULL, 1);
      heff_drop(v_path_244);
      heff_drop_rec(v_pk_243, 4);
      heff_drop(v_text_242);
      heff_drop(v_v_245);
      V v_t_2484 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str8), v_why_2483), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str9));
      V v_t_2485 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2484, NTAG(TAG_MkUnit)});
      V v_t_2486 = heff_tag_at_n(v_ru_24x_2455_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2463_24Left, TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2491}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam11, 1, 3, (V[]){v_e_240, v_hd_2431, v_k_2432})));
    }
    case TAG_Right: {
      V v_name_24101 = heff_field(v_x_2463, 0);
      V v_ru_24x_2463_24Right = heff_take_reuse_n(v_x_2463, 1ULL, 1);
      V v_x1_24102 = (g_list_2eany_24s1435008228x557204311(v_path_244, heff_rfield(v_pk_243, 2)));
      V v_t_24103;
      if (!(heff_dup(v_x1_24102) == NTAG(TAG_True))) {
        heff_drop(v_x1_24102);
        v_t_24103 = (g_list_2eany_24s944501138x775098345(v_name_24101, heff_rfield(v_pk_243, 2)));
      } else {
        heff_drop(v_x1_24102);
        v_t_24103 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24103) == NTAG(TAG_True))) {
        heff_drop_rec(v_pk_243, 4);
        heff_drop(v_text_242);
        heff_drop(v_v_245);
        heff_drop(v_t_24103);
        V v_t_24104 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str10), v_name_24101), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str11));
        V v_t_24105 = heff_strAppend(heff_strAppend(v_t_24104, v_path_244), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str12));
        V v_t_24106 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str13), v_t_24105), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str14));
        V v_t_24107 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24106, NTAG(TAG_MkUnit)});
        V v_t_24108 = heff_tag_at_n(v_ru_24x_2455_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2463_24Right, TAG_InL, 1, (V[]){v_t_24107})});
        V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
        V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
        V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
        V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
        V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})});
        return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24113}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam13, 1, 3, (V[]){v_e_240, v_hd_2431, v_k_2432})));
      } else {
        heff_drop_cell(v_ru_24x_2455_24Right, 1);
        heff_drop_cell(v_ru_24x_2463_24Right, 1);
        heff_drop(v_t_24103);
        V v_path_24123 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str15)));
        V v_src_24124 = v_text_242;
        V v_t_24125 = (g_list_2eany_24s1435008228x557204311(v_path_244, heff_rfield(v_pk_243, 2)));
        V v_t_24127;
        if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
          heff_drop(v_name_24101);
          heff_drop(v_t_24125);
          v_t_24127 = (g_list_2emap_24s1193924222x1531824795(heff_dup(v_path_244), heff_dup(v_v_245), heff_dup(heff_rfield(v_pk_243, 2))));
        } else {
          heff_drop(v_t_24125);
          V v_t_24126 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_24101, heff_dup(v_path_244), heff_dup(v_v_245)}), NTAG(TAG_Nil)});
          v_t_24127 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_243, 2)), v_t_24126));
        }
        V v_pk_24128 = ({ V rv_2 = v_t_24127; V rr_ = heff_rec_reuse_nf(v_pk_243, 11ULL, 4, shape_module__heff__require__replace, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_24129 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        HeffT3 v_t_24130 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_24124), v_t_24129, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
        V v_t_24134;
        {
          V v_field_24131 = v_t_24130.f[0];
          heff_drop(v_t_24130.f[1]);
          heff_drop(v_t_24130.f[2]);
          v_t_24134 = v_field_24131;
        }
        HeffT3 v_t_24135 = ({ V b_0 = heff_arrayFromList(v_t_24134); V a_1 = MK_INT(0LL); HeffT3 r_ = (g_heff_2ebuild_2eproject_2espanGo_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_text_24167;
        {
          V v_field_24137 = v_t_24135.f[1];
          V v_field_24138 = v_t_24135.f[2];
          int64_t v_tag_24136 = ((int64_t)v_t_24135.f[0]);
          if ((v_tag_24136 == ((int64_t)0ULL))) {
            V v_from_24139 = v_field_24137;
            V v_to_24140 = v_field_24138;
            V v_pk_24141 = v_pk_24128;
            V v_module_24142 = heff_take_field(v_pk_24141, 0);
            V v_heff_24143 = heff_take_field(v_pk_24141, 1);
            V v_require_24144 = heff_take_field(v_pk_24141, 2);
            V v_replace_24145 = heff_get_n(v_pk_24141, 3, 4);
            V v_t_24146 = ({ V a_0 = v_module_24142; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_module_24142); r_; });
            V v_t_24147 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str16), v_t_24146), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str17));
            V v_t_24148 = ({ V a_0 = v_heff_24143; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_heff_24143); r_; });
            V v_items_24149 = (g_list_2emap_24s1381986540x1952410492(v_require_24144));
            V v_t_24155;
            switch (heff_tag_of(v_items_24149)) {
            case TAG_Nil: {
              v_t_24155 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str18);
              break;
            }
            case TAG_Cons: {
              V v_t_24154;
              switch (heff_tag_of(v_items_24149)) {
              case TAG_Nil: {
                v_t_24154 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str19);
                break;
              }
              case TAG_Cons: {
                V v_x_24152 = heff_field(v_items_24149, 0);
                V v_xs_24153 = heff_field(v_items_24149, 1);
                heff_take_n(v_items_24149, 3ULL, 2);
                v_t_24154 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str20); V a_1 = v_x_24152; V a_2 = v_xs_24153; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24153); r_; });
                break;
              }
              default: heff_nomatch(v_items_24149);
              }
              v_t_24155 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str21), v_t_24154), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str22));
              break;
            }
            default: heff_nomatch(v_items_24149);
            }
            V v_t_24156 = heff_strAppend(heff_strAppend(v_t_24147, v_t_24148), v_t_24155);
            V v_items_24157 = (g_list_2emap_24s404123879x745642248(v_replace_24145));
            V v_t_24163;
            switch (heff_tag_of(v_items_24157)) {
            case TAG_Nil: {
              v_t_24163 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str23);
              break;
            }
            case TAG_Cons: {
              V v_t_24162;
              switch (heff_tag_of(v_items_24157)) {
              case TAG_Nil: {
                v_t_24162 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str24);
                break;
              }
              case TAG_Cons: {
                V v_x_24160 = heff_field(v_items_24157, 0);
                V v_xs_24161 = heff_field(v_items_24157, 1);
                heff_take_n(v_items_24157, 3ULL, 2);
                v_t_24162 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str25); V a_1 = v_x_24160; V a_2 = v_xs_24161; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24161); r_; });
                break;
              }
              default: heff_nomatch(v_items_24157);
              }
              v_t_24163 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str26), v_t_24162), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str27));
              break;
            }
            default: heff_nomatch(v_items_24157);
            }
            V v_t_24164 = heff_strAppend(heff_strAppend(v_t_24156, v_t_24163), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str28));
            V v_t_24165 = heff_strAppend(heff_strSlice_lent(v_src_24124, MK_INT(0LL), v_from_24139, 6), v_t_24164);
            V v_t_24166 = heff_strSlice(heff_dup(v_src_24124), v_to_24140, heff_strLength(v_src_24124));
            v_text_24167 = heff_strAppend(v_t_24165, v_t_24166);
          } else {
            heff_drop_rec(v_pk_24128, 4);
            heff_drop(v_field_24137);
            heff_drop(v_field_24138);
            v_text_24167 = v_src_24124;
          }
        }
        V v_text_24173;
        if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str29), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str30))) {
          HeffT2 v_t_24168 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_24167)));
          {
            V v_field_24170 = v_t_24168.f[1];
            int64_t v_tag_24169 = ((int64_t)v_t_24168.f[0]);
            if ((v_tag_24169 == ((int64_t)0ULL))) {
              V v_x_24171 = v_field_24170;
              heff_drop(v_x_24171);
              v_text_24173 = v_text_24167;
            } else {
              heff_drop(v_text_24167);
              V v_out_24172 = v_field_24170;
              v_text_24173 = v_out_24172;
            }
          }
        } else {
          v_text_24173 = v_text_24167;
        }
        V v_c_24174 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_24123; V a_2 = v_text_24173; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_24123); r_; });
        V v_t_24175 = (g_exception_2eattempted(heff_dup(v_e_240)));
        V v_c_24179 = heff_tr(heff_call(v_c_24174, 2, (V[]){v_t_24175, ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam15_clo)}));
        V f_ = v_c_24179;
        heff_room[0] = heff_dup(v_hd_2431);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam16, 1, 5, (V[]){v_e_240, v_hd_2431, v_k_2432, v_path_244, v_v_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_x_2463);
    }
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_2431 = heff_env(self)[4];
  V v_k_2432 = heff_env(self)[5];
  V v_pk_243 = heff_env(self)[6];
  V v_text_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_st_2456 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_a_2457 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
  V v_t_2458 = (g_std_2epath_2eparse(heff_dup(v_st_2456), v_a_2457));
  V v_t_2459 = (g_std_2epath_2eparse(heff_dup(v_st_2456), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str5)));
  V v_t_2460 = (g_std_2epath_2ejoin(v_t_2458, v_t_2459));
  V v_t_2461 = ({ V a_0 = v_st_2456; V a_1 = v_t_2460; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2456); heff_drop(v_t_2460); r_; });
  V v_c_2462 = (g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(heff_dup(v_e_240), v_ps_241, v_t_2461));
  V f_ = v_c_2462;
  heff_room[0] = heff_dup(v_hd_2431);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam8, 1, 8, (V[]){v_x_2455, v_e_240, v_hd_2431, v_k_2432, v_path_244, v_pk_243, v_text_242, v_v_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_path_244 = heff_env(self)[4];
  V v_v_245 = heff_env(self)[5];
  V v_pk_243 = heff_env(self)[6];
  V v_text_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_why_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    heff_drop_rec(v_pk_243, 4);
    heff_drop(v_text_242);
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str3), v_why_2434), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_str4));
    V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2435, NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam5, 1, 3, (V[]){v_e_240, v_hd_2431, v_k_2432})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2433, 0ULL, 1);
    V v_t_2453 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_c_2454 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1492887254x997927530(heff_dup(v_e_240), heff_dup(v_ps_241), v_t_2453, heff_dup(v_path_244)));
    V f_ = v_c_2454;
    heff_room[0] = heff_dup(v_hd_2431);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam7, 1, 8, (V[]){v_ps_241, v_path_244, v_v_245, v_e_240, v_hd_2431, v_k_2432, v_pk_243, v_text_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam3(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  V v_v_245 = heff_env(self)[4];
  V v_pk_243 = heff_env(self)[5];
  V v_text_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1235069934x1162967479_lam4, 1, 8, (V[]){v_e_240, v_hd_2431, v_k_2432, v_ps_241, v_path_244, v_v_245, v_pk_243, v_text_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}