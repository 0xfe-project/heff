// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_cmt 308164
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_group 299987609
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_tok 324554
#define LBL_version 583465758
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868(V, V);
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_clo;
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064(V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_clo;
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698(V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_clo;
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493_clo;
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_get(void);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_clo;
V g_heff_2ebuild_2efetch_2enewerTagged(V, V, V);
V g_heff_2ebuild_2efetch_2enewerTagged_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewerTagged_clo;
V g_heff_2ebuild_2efetch_2erevSaid(V);
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2erevSaid_clo;
HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V);
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982(V, V, V);
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_clo;
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422(V, V, V);
V g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152_clo;
V g_heff_2ebuild_2eproject_2eisMajorPart(V);
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2espanGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eany_24s1435008228x557204311(V, V);
V g_list_2eany_24s1435008228x557204311_entry(V self, V *a);
extern Clo g_list_2eany_24s1435008228x557204311_clo;
V g_list_2eany_24s944501138x775098345(V, V);
V g_list_2eany_24s944501138x775098345_entry(V self, V *a);
extern Clo g_list_2eany_24s944501138x775098345_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24s1193924222x1531824795(V, V, V);
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s2098427539x1767581560(V, V, V, V);
V g_list_2emap_24s2098427539x1767581560_entry(V self, V *a);
extern Clo g_list_2emap_24s2098427539x1767581560_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emergeRuns_24s816413140x1019303067(V, V);
V g_list_2emergeRuns_24s816413140x1019303067_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s816413140x1019303067_clo;
V g_list_2erunFrom_24s424587874x298262355(V, V);
V g_list_2erunFrom_24s424587874x298262355_entry(V self, V *a);
extern Clo g_list_2erunFrom_24s424587874x298262355_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2efetch_2enewerTagged_str0, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewerTagged_str1, 11, "refs/tags/v");
Clo g_heff_2ebuild_2efetch_2enewerTagged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewerTagged_entry, 3, 0};

V g_heff_2ebuild_2efetch_2enewerTagged(V v_path_240, V v_best_241, V v_line_242) {
top: ;
  V v_it_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2enewerTagged_str0); V a_1 = v_line_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2enewerTagged_str1), v_line_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_241;
  }
  case TAG_Cons: {
    V v_it2_245 = heff_field(v_it_243, 1);
    heff_take_n(v_it_243, 2ULL, 2);
    switch (heff_tag_of(v_it2_245)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      return v_best_241;
    }
    case TAG_Cons: {
      V v_v_246 = heff_field(v_it2_245, 0);
      V v_it22_247 = heff_field(v_it2_245, 1);
      heff_take_n(v_it2_245, 3ULL, 2);
      switch (heff_tag_of(v_it22_247)) {
      case TAG_Nil: {
        V v_t_248 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
        V v_t_2410 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_249), MK_INT(-1LL)));
        V v_t_2411 = heff_strSlice(heff_dup(v_v_246), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
        HeffT2 v_t_2412 = ({ V a_0 = v_t_2411; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2411); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2414;
            heff_drop(v_x_2415);
            V v_t_2416 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
            int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
            V v_t_2418 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2417), MK_INT(-1LL)));
            V v_t_2419 = heff_strSlice(heff_dup(v_v_246), v_t_2416, heff_intAdd(v_t_2418, MK_INT(1LL)));
            HeffT2 v_t_2420 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(v_path_240, v_t_2419));
            {
              V v_field_2422 = v_t_2420.f[1];
              int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
              if ((v_tag_2421 == ((int64_t)0ULL))) {
                heff_drop(v_v_246);
                V v_x_2423 = v_field_2422;
                heff_drop(v_x_2423);
                return v_best_241;
              } else {
                heff_drop(v_field_2422);
                switch (heff_tag_of(v_best_241)) {
                case TAG_Nothing: {
                  V v_t_2424 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2426 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2425), MK_INT(-1LL)));
                  V v_t_2427 = heff_strSlice(v_v_246, v_t_2424, heff_intAdd(v_t_2426, MK_INT(1LL)));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2427});
                }
                case TAG_Just: {
                  V v_b_2428 = heff_dup(heff_field(v_best_241, 0));
                  V v_t_2429 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2430 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2431 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2430), MK_INT(-1LL)));
                  V v_t_2432 = heff_strSlice(heff_dup(v_v_246), v_t_2429, heff_intAdd(v_t_2431, MK_INT(1LL)));
                  V v_t_2433 = ({ V a_0 = v_t_2432; V a_1 = v_b_2428; V r_ = (g_heff_2ebuild_2eproject_2enewer(a_0, a_1)); heff_drop(v_t_2432); heff_drop(v_b_2428); r_; });
                  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
                    heff_drop_tag(v_best_241, 1);
                    heff_drop(v_t_2433);
                    V v_t_2434 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                    V v_t_2436 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2435), MK_INT(-1LL)));
                    V v_t_2437 = heff_strSlice(v_v_246, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2437});
                  } else {
                    heff_drop(v_v_246);
                    heff_drop(v_t_2433);
                    return v_best_241;
                  }
                }
                default: return heff_nomatch(v_best_241);
                }
              }
            }
          } else {
            heff_drop(v_path_240);
            heff_drop(v_v_246);
            heff_drop(v_field_2414);
            return v_best_241;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_247, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop(v_v_246);
        return v_best_241;
      }
      default: return heff_nomatch(v_it22_247);
      }
    }
    default: return heff_nomatch(v_it2_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ebuild_2efetch_2enewerTagged_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2efetch_2enewerTagged(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str0, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str1, 28, "commit on the default branch");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str2, 7, "commit ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str3, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str4, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str5, 7, "branch ");
Clo g_heff_2ebuild_2efetch_2erevSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2erevSaid_entry, 1, 0};

V g_heff_2ebuild_2efetch_2erevSaid(V v_rev_240) {
top: ;
  if (heff_strEq_c_lent(v_rev_240, ((V)&g_heff_2ebuild_2efetch_2erevSaid_str0), 2)) {
    heff_drop(v_rev_240);
    return ((V)&g_heff_2ebuild_2efetch_2erevSaid_str1);
  } else {
    if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_240, 0)))) {
      if ((heff_unbox_word(heff_strLength_lent(v_rev_240, 0)) <= ((int64_t)40ULL))) {
        V v_t_241 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_240, 0)));
        V v_t_242 = ({ V a_0 = v_rev_240; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_241; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_241); r_; });
        if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str2), v_rev_240);
        } else {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str3), v_rev_240);
        }
      } else {
        return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str4), v_rev_240);
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str5), v_rev_240);
    }
  }
}
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2erevSaid(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2especOf_24cpr_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2efetch_2especOf_24cpr_str1, 1, "@");

HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V v_spec_240) {
top: ;
  V v_it_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2especOf_24cpr_str0); V a_1 = v_spec_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2especOf_24cpr_str1), v_spec_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_path_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_path_242);
      return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_spec_240);
        return ((HeffT2){{v_path_242, heff_tag_n(TAG_Just, 1, (V[]){v_v_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it22_245, 0ULL, 2);
        heff_drop(v_path_242);
        heff_drop(v_v_244);
        return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str1, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str2, 32, "--date=format-local:%Y%m%d%H%M%S");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str3, 15, "--format=%cd %H");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str4, 3, "log");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str5, 2, "-1");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str6, 2, "TZ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str7, 4, "UTC0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str8, 3, "git");
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_entry, 2, 0};

V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868(V v_dir_240, V v_rev_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_240));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_rev_241, ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str1)), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str3), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str5), v_t_245})});
  V v_t_247 = ({ V a_0 = v_t_242; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_242); r_; });
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str6), ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str7)}), NTAG(TAG_Nil)});
  V v_t_249 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_str8), v_t_246, v_t_247, v_t_248, NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2411 = heff_tag_n(TAG_Run, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam1, 2, 1, (V[]){v_a_2411});
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868(a[0], a[1]);
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ended_2424 = heff_take_field(v_x_2423, 0);
  V v_out_2425 = heff_get_n(v_x_2423, 1, 3);
  V v_x_2435;
  switch (heff_tag_of(v_ended_2424)) {
  case TAG_Exited: {
    V v_n_2426 = heff_field(v_ended_2424, 0);
    V v_ru_24ended_2424_24Exited = heff_take_reuse_n(v_ended_2424, 1ULL, 1);
    if (heff_intEq_c(v_n_2426, MK_INT(0LL))) {
      V v_x1_2427 = ({ V a_0 = v_out_2425; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewordsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_out_2425); r_; });
      switch (heff_tag_of(v_x1_2427)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
        v_x_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_time_2428 = heff_field(v_x1_2427, 0);
        V v_x12_2429 = heff_field(v_x1_2427, 1);
        V v_ru_24x1_2427_24Cons = heff_take_reuse_n(v_x1_2427, 3ULL, 2);
        switch (heff_tag_of(v_x12_2429)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
          heff_drop(v_time_2428);
          heff_drop_cell(v_ru_24x1_2427_24Cons, 2);
          v_x_2435 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_hash_2430 = heff_field(v_x12_2429, 0);
          V v_x122_2431 = heff_field(v_x12_2429, 1);
          heff_take_n(v_x12_2429, 3ULL, 2);
          switch (heff_tag_of(v_x122_2431)) {
          case TAG_Nil: {
            v_x_2435 = heff_tag_at_n(v_ru_24ended_2424_24Exited, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_2427_24Cons, TAG_MkPair, 2, (V[]){v_time_2428, v_hash_2430})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x122_2431, 0ULL, 2);
            heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
            heff_drop(v_time_2428);
            heff_drop_cell(v_ru_24x1_2427_24Cons, 2);
            heff_drop(v_hash_2430);
            v_x_2435 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x122_2431);
          }
          break;
        }
        default: heff_nomatch(v_x12_2429);
        }
        break;
      }
      default: heff_nomatch(v_x1_2427);
      }
    } else {
      heff_drop(v_out_2425);
      heff_drop_cell(v_ru_24ended_2424_24Exited, 1);
      v_x_2435 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2424, 0ULL, 1);
    heff_drop(v_out_2425);
    v_x_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_TimedOut: {
    heff_drop(v_out_2425);
    v_x_2435 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_NotRun: {
    heff_drop(v_out_2425);
    v_x_2435 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_ended_2424);
  }
  V f_ = v_k_2413;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2414 = heff_take_field(v_hd_2412, 1);
  V v_malg_2415 = heff_get_n(v_hd_2412, 2, 3);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(v_malg_2415, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
  V f_ = v_bind_2414;
  args[0] = v_t_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868_lam2, 1, 1, (V[]){v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str0, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str2, 9, " (commit ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str4, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str5, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str7, 13, "--no-checkout");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str8, 18, "--filter=blob:none");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str9, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str10, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str11, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str13, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str14, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str15, 8, "--detach");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str16, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str17, 8, "checkout");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str18, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str19, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str20, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str21, 14, "no such commit");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str22, 17, "the commit is of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str23, 6, ", not ");
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam3, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_entry, 5, 0};

V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837(V v_path_240, V v_v_241, V v_time_242, V v_hash_243, V v_dir_244) {
top: ;
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str0), heff_dup(v_path_240)), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str1));
  V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, v_v_241), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str2));
  V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_hash_243)), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str3));
  V v_t_248 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_249 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str4), v_t_248));
  V v_x_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str5));
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam0, 2, 5, (V[]){v_path_240, v_dir_244, v_x_2410, v_hash_243, v_time_242});
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam1(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam3(V self, V *args) {
  V v_r_2446 = args[0];
  return v_r_2446;
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam5(V self, V *args) {
  V v_x_2459 = args[0];
  V v_ended_2456 = heff_env(self)[0];
  V v_err_2457 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2462;
  switch (heff_tag_of(v_ended_2456)) {
  case TAG_Exited: {
    V v_n_2460 = heff_field(v_ended_2456, 0);
    heff_take_n(v_ended_2456, 1ULL, 1);
    v_t_2462 = heff_bool(!heff_intEq_c_lent(v_n_2460, MK_INT(0LL), 2));
    heff_drop(v_n_2460);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2456, 0ULL, 1);
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2462 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2456);
  }
  V v_x_2473;
  if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
    heff_drop(v_x_2459);
    heff_drop(v_time_242);
    heff_drop(v_t_2462);
    V v_s_2463 = v_err_2457;
    V v_t_2464 = (g_prelude_2eskipSpaces(v_s_2463, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2465 = (heff_unbox_word(heff_strLength_lent(v_s_2463, 0)) - ((int64_t)1ULL));
    V v_t_2466 = (g_prelude_2eskipSpaces(v_s_2463, heff_box_word(v_t_2465), MK_INT(-1LL)));
    V v_t_2467 = heff_strSlice(v_s_2463, v_t_2464, heff_intAdd(v_t_2466, MK_INT(1LL)));
    v_x_2473 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2467)});
  } else {
    heff_drop(v_err_2457);
    heff_drop(v_t_2462);
    switch (heff_tag_of(v_x_2459)) {
    case TAG_Nothing: {
      heff_drop(v_time_242);
      v_x_2473 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str21))});
      break;
    }
    case TAG_Just: {
      V v_it1_2468 = heff_field(v_x_2459, 0);
      V v_ru_24x_2459_24Just = heff_take_reuse_n(v_x_2459, 1ULL, 1);
      switch (heff_tag_of(v_it1_2468)) {
      case TAG_MkPair: {
        V v_t_2469 = heff_field(v_it1_2468, 0);
        heff_take_n(v_it1_2468, 1ULL, 2);
        if (heff_strEq_c_lent(v_t_2469, v_time_242, 0)) {
          heff_drop(v_x_2410);
          heff_drop(v_time_242);
          heff_drop_cell(v_ru_24x_2459_24Just, 1);
          heff_drop(v_t_2469);
          v_x_2473 = NTAG(TAG_Nothing);
        } else {
          V v_t_2471 = heff_strAppend(heff_strAppend(v_x_2410, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str22)), v_t_2469);
          V v_t_2472 = heff_strAppend(heff_strAppend(v_t_2471, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str23)), v_time_242);
          v_x_2473 = heff_tag_at_n(v_ru_24x_2459_24Just, TAG_Just, 1, (V[]){v_t_2472});
        }
        break;
      }
      default: heff_nomatch(v_it1_2468);
      }
      break;
    }
    default: heff_nomatch(v_x_2459);
    }
  }
  V f_ = v_k_2412;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam4(V self, V *args) {
  V v_x_2455 = args[0];
  V v_dir_244 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_ended_2456 = heff_take_field(v_x_2455, 0);
  V v_err_2457 = heff_get_n(v_x_2455, 2, 3);
  V v_c_2458 = (g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868(v_dir_244, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str20)));
  V f_ = v_c_2458;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam5, 1, 5, (V[]){v_ended_2456, v_err_2457, v_x_2410, v_time_242, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  V v_dir_244 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_time_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_ended_2429 = heff_take_field(v_x_2428, 0);
  V v_err_2430 = heff_get_n(v_x_2428, 2, 3);
  V v_t_2433;
  switch (heff_tag_of(v_ended_2429)) {
  case TAG_Exited: {
    V v_n_2431 = heff_field(v_ended_2429, 0);
    heff_take_n(v_ended_2429, 1ULL, 1);
    v_t_2433 = heff_bool(!heff_intEq_c_lent(v_n_2431, MK_INT(0LL), 2));
    heff_drop(v_n_2431);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2429, 0ULL, 1);
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2429);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_dir_244);
    heff_drop(v_hash_243);
    heff_drop_rec(v_hd_2411, 3);
    heff_drop(v_time_242);
    heff_drop(v_t_2433);
    V v_s_2434 = v_err_2430;
    V v_t_2435 = (g_prelude_2eskipSpaces(v_s_2434, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_s_2434, 0)) - ((int64_t)1ULL));
    V v_t_2437 = (g_prelude_2eskipSpaces(v_s_2434, heff_box_word(v_t_2436), MK_INT(-1LL)));
    V v_t_2438 = heff_strSlice(v_s_2434, v_t_2435, heff_intAdd(v_t_2437, MK_INT(1LL)));
    V v_x_2439 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2438)});
    V f_ = v_k_2412;
    args[0] = v_x_2439;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_err_2430);
    heff_drop(v_t_2433);
    V v_t_2440 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_244)));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_hash_243, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str13)), NTAG(TAG_Nil)});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str15), v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str17), v_t_2442})});
    V v_t_2444 = ({ V a_0 = v_t_2440; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2440); r_; });
    V v_t_2445 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str19), v_t_2443}), v_t_2444, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2447 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2445, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam3_clo)});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})}));
    V f_ = heff_dup(heff_rfield(v_hd_2411, 1));
    heff_room[0] = v_t_2454;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam4, 1, 5, (V[]){v_dir_244, v_hd_2411, v_x_2410, v_time_242, v_k_2412});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_240 = heff_env(self)[0];
  V v_dir_244 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_time_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_dir_244), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str6), v_t_2413), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str8), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str10), v_t_2416})});
  V v_t_2418 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str11), v_t_2417, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_str12), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam1_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2411, 2)), 1, (V[]){v_t_2426}));
  V f_ = heff_dup(heff_rfield(v_hd_2411, 1));
  args[0] = v_t_2427;
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837_lam2, 1, 6, (V[]){v_x_2410, v_k_2412, v_dir_244, v_hash_243, v_hd_2411, v_time_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str1, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str4, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str5, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str8, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str9, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str10, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str12, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str13, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str15, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str17, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str18, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str19, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str20, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str21, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str22, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str23, 4, " in ");
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam2(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam2, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam5(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam5, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam6(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam6, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam9(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam9, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam10(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam10, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam13(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam13, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam17(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam17, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam19(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam19, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam21(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam20(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam20, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam23(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam23, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam25(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam24(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam24, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam27(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam27, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam29(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam28(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam28, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam31(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam32(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam30(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam26(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam22(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam18(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam33(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam33, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam35(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam34(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam34, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam36(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam16(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam15(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_entry, 3, 0};

V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_x_243 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), heff_dup(v_v_242)));
  return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam0, 2, 4, (V[]){v_x_243, v_ps_240, v_path_241, v_v_242});
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam1(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2417})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2418));
  }
  case TAG_Right: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam3, 2, 1, (V[]){v_x_2419});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam5(V self, V *args) {
  V v_r_2427 = args[0];
  return v_r_2427;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam7(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_err_2436 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2436})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2437));
  }
  case TAG_Right: {
    V v_x_2438 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam7, 2, 1, (V[]){v_x_2438});
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam9(V self, V *args) {
  V v_r_2458 = args[0];
  return v_r_2458;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam11(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_x_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2470);
  V f_ = v_k_2471;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2469});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam10(V self, V *args) {
  V v_x_2466 = args[0];
  switch (heff_tag_of(v_x_2466)) {
  case TAG_Left: {
    V v_err_2467 = heff_field(v_x_2466, 0);
    V v_ru_24x_2466_24Left = heff_take_reuse_n(v_x_2466, 1ULL, 1);
    V v_t_2468 = heff_tag_at_n(v_ru_24x_2466_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2467})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2468));
  }
  case TAG_Right: {
    V v_x_2469 = heff_field(v_x_2466, 0);
    heff_take_n(v_x_2466, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam11, 2, 1, (V[]){v_x_2469});
  }
  default: return heff_nomatch(v_x_2466);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam13(V self, V *args) {
  V v_t_2475 = args[0];
  return v_t_2475;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam17(V self, V *args) {
  V v_r_2494 = args[0];
  return v_r_2494;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam19(V self, V *args) {
  V v_r_24110 = args[0];
  return v_r_24110;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam21(V self, V *args) {
  V v_hd_24122 = args[0];
  V v_k_24123 = args[1];
  V v_x_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24122);
  V f_ = v_k_24123;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24121});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam20(V self, V *args) {
  V v_x_24118 = args[0];
  switch (heff_tag_of(v_x_24118)) {
  case TAG_Left: {
    V v_err_24119 = heff_field(v_x_24118, 0);
    V v_ru_24x_24118_24Left = heff_take_reuse_n(v_x_24118, 1ULL, 1);
    V v_t_24120 = heff_tag_at_n(v_ru_24x_24118_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24119})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24120));
  }
  case TAG_Right: {
    V v_x_24121 = heff_field(v_x_24118, 0);
    heff_take_n(v_x_24118, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam21, 2, 1, (V[]){v_x_24121});
  }
  default: return heff_nomatch(v_x_24118);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam23(V self, V *args) {
  V v_r_24128 = args[0];
  return v_r_24128;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam25(V self, V *args) {
  V v_hd_24140 = args[0];
  V v_k_24141 = args[1];
  V v_x_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24140);
  V f_ = v_k_24141;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24139});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam24(V self, V *args) {
  V v_x_24136 = args[0];
  switch (heff_tag_of(v_x_24136)) {
  case TAG_Left: {
    V v_err_24137 = heff_field(v_x_24136, 0);
    V v_ru_24x_24136_24Left = heff_take_reuse_n(v_x_24136, 1ULL, 1);
    V v_t_24138 = heff_tag_at_n(v_ru_24x_24136_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24137})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24138));
  }
  case TAG_Right: {
    V v_x_24139 = heff_field(v_x_24136, 0);
    heff_take_n(v_x_24136, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam25, 2, 1, (V[]){v_x_24139});
  }
  default: return heff_nomatch(v_x_24136);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam27(V self, V *args) {
  V v_r_24155 = args[0];
  return v_r_24155;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam29(V self, V *args) {
  V v_hd_24167 = args[0];
  V v_k_24168 = args[1];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24167);
  V f_ = v_k_24168;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24166});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam28(V self, V *args) {
  V v_x_24163 = args[0];
  switch (heff_tag_of(v_x_24163)) {
  case TAG_Left: {
    V v_err_24164 = heff_field(v_x_24163, 0);
    V v_ru_24x_24163_24Left = heff_take_reuse_n(v_x_24163, 1ULL, 1);
    V v_t_24165 = heff_tag_at_n(v_ru_24x_24163_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24164})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24165));
  }
  case TAG_Right: {
    V v_x_24166 = heff_field(v_x_24163, 0);
    heff_take_n(v_x_24163, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam29, 2, 1, (V[]){v_x_24166});
  }
  default: return heff_nomatch(v_x_24163);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam31(V self, V *args) {
  V v_x_24185 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_24152 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24185);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24152});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam32(V self, V *args) {
  V v_x_24203 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_24152 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24203);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24152});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam30(V self, V *args) {
  V v_x_24170 = args[0];
  V v_ended_24102 = heff_env(self)[0];
  V v_x_24146 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_x_24152 = heff_env(self)[6];
  V v_x_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_24170)) {
  case TAG_Left: {
    V v_ru_24x_24170_24Left = heff_take_reuse_n(v_x_24170, 0ULL, 1);
    V v_t_24174;
    switch (heff_tag_of(v_ended_24102)) {
    case TAG_Exited: {
      V v_n_24172 = heff_field(v_ended_24102, 0);
      heff_take_n(v_ended_24102, 1ULL, 1);
      v_t_24174 = heff_bool(heff_intEq_c_lent(v_n_24172, MK_INT(0LL), 2));
      heff_drop(v_n_24172);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_24102, 0ULL, 1);
      v_t_24174 = NTAG(TAG_False);
      break;
    }
    case TAG_TimedOut: {
      v_t_24174 = NTAG(TAG_False);
      break;
    }
    case TAG_NotRun: {
      v_t_24174 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_ended_24102);
    }
    if (((heff_dup(v_t_24174) == NTAG(TAG_True)) && ((heff_dup(v_x_24146) == NTAG(TAG_True)) && 0))) {
      heff_drop(v_x_24146);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x_24170_24Left, 1);
      heff_drop(v_t_24174);
      V v_t_24175 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str12), v_path_241), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str13));
      V v_t_24176 = heff_strAppend(heff_strAppend(v_t_24175, v_v_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str14));
      V v_t_24177 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24176, NTAG(TAG_MkUnit)});
      V v_t_24178 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24177})});
      V v_t_24179 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24178})});
      V v_t_24180 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24179})});
      V v_t_24181 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24180})});
      V v_t_24182 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24181})});
      V v_t_24183 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24182})});
      V v_t_24184 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24183})}));
      V f_ = heff_get_n(v_hd_244, 1, 3);
      heff_room[0] = v_t_24184;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam31, 1, 2, (V[]){v_k_245, v_x_24152});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_24146);
      heff_drop_rec(v_hd_244, 3);
      heff_drop(v_x_24152);
      heff_drop(v_t_24174);
      V v_t_24186 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str15), v_path_241), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str16));
      V v_t_24187 = heff_strAppend(heff_strAppend(v_t_24186, v_v_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str17));
      V v_t_24188 = heff_tag_at_n(v_ru_24x_24170_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_24187, v_x_243)});
      V f_ = v_k_245;
      args[0] = v_t_24188;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  case TAG_Right: {
    V v_ru_24x_24170_24Right = heff_take_reuse_n(v_x_24170, 0ULL, 1);
    V v_t_24192;
    switch (heff_tag_of(v_ended_24102)) {
    case TAG_Exited: {
      V v_n_24190 = heff_field(v_ended_24102, 0);
      heff_take_n(v_ended_24102, 1ULL, 1);
      v_t_24192 = heff_bool(heff_intEq_c_lent(v_n_24190, MK_INT(0LL), 2));
      heff_drop(v_n_24190);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_24102, 0ULL, 1);
      v_t_24192 = NTAG(TAG_False);
      break;
    }
    case TAG_TimedOut: {
      v_t_24192 = NTAG(TAG_False);
      break;
    }
    case TAG_NotRun: {
      v_t_24192 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_ended_24102);
    }
    if (((heff_dup(v_t_24192) == NTAG(TAG_True)) && (heff_dup(v_x_24146) == NTAG(TAG_True)))) {
      heff_drop(v_x_24146);
      heff_drop(v_x_243);
      heff_drop(v_t_24192);
      V v_t_24193 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str18), v_path_241), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str19));
      V v_t_24194 = heff_strAppend(heff_strAppend(v_t_24193, v_v_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str20));
      V v_t_24195 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24194, NTAG(TAG_MkUnit)});
      V v_t_24196 = heff_tag_at_n(v_ru_24x_24170_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24195})});
      V v_t_24197 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24196})});
      V v_t_24198 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24197})});
      V v_t_24199 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24198})});
      V v_t_24200 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24199})});
      V v_t_24201 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24200})});
      V v_t_24202 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24201})}));
      V f_ = heff_get_n(v_hd_244, 1, 3);
      heff_room[0] = v_t_24202;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam32, 1, 2, (V[]){v_k_245, v_x_24152});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_24146);
      heff_drop_rec(v_hd_244, 3);
      heff_drop(v_x_24152);
      heff_drop(v_t_24192);
      V v_t_24204 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str21), v_path_241), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str22));
      V v_t_24205 = heff_strAppend(heff_strAppend(v_t_24204, v_v_242), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str23));
      V v_t_24206 = heff_tag_at_n(v_ru_24x_24170_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_24205, v_x_243)});
      V f_ = v_k_245;
      args[0] = v_t_24206;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_24170);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam26(V self, V *args) {
  V v_x_24143 = args[0];
  V v_out_24101 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ended_24102 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_v_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_24146;
  switch (heff_tag_of(v_x_24143)) {
  case TAG_Left: {
    heff_take_n(v_x_24143, 0ULL, 1);
    v_x_24146 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_24143, 0ULL, 1);
    v_x_24146 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_24143);
  }
  V v_s_24147 = v_out_24101;
  V v_t_24148 = (g_prelude_2eskipSpaces(v_s_24147, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_24149 = (heff_unbox_word(heff_strLength_lent(v_s_24147, 0)) - ((int64_t)1ULL));
  V v_t_24150 = (g_prelude_2eskipSpaces(v_s_24147, heff_box_word(v_t_24149), MK_INT(-1LL)));
  V v_t_24151 = heff_strSlice(v_s_24147, v_t_24148, heff_intAdd(v_t_24150, MK_INT(1LL)));
  V v_x_24152 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str9), v_t_24151);
  V v_path_24153 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str10))));
  V v_t_24154 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24153; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24153); r_; });
  V v_a_24156 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_24154, heff_strAppend(heff_dup(v_x_24152), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str11)), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam27_clo)});
  V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24156})});
  V v_t_24158 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24157})});
  V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
  V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
  V v_t_24161 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
  V v_t_24162 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24161})});
  V v_c_24169 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24162}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam28_clo)));
  V f_ = v_c_24169;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam30, 1, 8, (V[]){v_ended_24102, v_x_24146, v_path_241, v_v_242, v_hd_244, v_k_245, v_x_24152, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam22(V self, V *args) {
  V v_x_24125 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_out_24101 = heff_env(self)[2];
  V v_ended_24102 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_v_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24125);
  V v_path_24126 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
  V v_t_24127 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24126; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24126); r_; });
  V v_a_24129 = heff_tag_n(TAG_ReadOnly, 2, (V[]){v_t_24127, ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam23_clo)});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24129})});
  V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
  V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
  V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
  V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
  V v_t_24135 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24134})});
  V v_c_24142 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24135}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam24_clo)));
  V f_ = v_c_24142;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam26, 1, 7, (V[]){v_out_24101, v_x_243, v_hd_244, v_ended_24102, v_path_241, v_v_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam18(V self, V *args) {
  V v_x_24100 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_out_24101 = heff_take_field(v_x_24100, 1);
  V v_ended_24102 = heff_get_n(v_x_24100, 0, 3);
  V v_st_24103 = heff_get_n(v_ps_240, 5, 6);
  V v_t_24104 = (g_std_2epath_2eparse(heff_dup(v_st_24103), heff_dup(v_x_243)));
  V v_t_24105 = (g_std_2epath_2eparse(heff_dup(v_st_24103), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str8)));
  V v_t_24106 = (g_std_2epath_2ejoin(v_t_24104, v_t_24105));
  V v_s_24107 = ({ V a_0 = v_st_24103; V a_1 = v_t_24106; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_24103); heff_drop(v_t_24106); r_; });
  V v_path_24108 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24107));
  V v_t_24109 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24108; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24108); r_; });
  V v_a_24111 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_24109, ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam19_clo)});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
  V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
  V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24116})});
  V v_c_24124 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24117}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam20_clo)));
  V f_ = v_c_24124;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam22, 1, 7, (V[]){v_x_243, v_hd_244, v_out_24101, v_ended_24102, v_path_241, v_v_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam33(V self, V *args) {
  V v_r_24218 = args[0];
  return v_r_24218;
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam35(V self, V *args) {
  V v_hd_24230 = args[0];
  V v_k_24231 = args[1];
  V v_x_24229 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24230);
  V f_ = v_k_24231;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24229});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam34(V self, V *args) {
  V v_x_24226 = args[0];
  switch (heff_tag_of(v_x_24226)) {
  case TAG_Left: {
    V v_err_24227 = heff_field(v_x_24226, 0);
    V v_ru_24x_24226_24Left = heff_take_reuse_n(v_x_24226, 1ULL, 1);
    V v_t_24228 = heff_tag_at_n(v_ru_24x_24226_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24227})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24228));
  }
  case TAG_Right: {
    V v_x_24229 = heff_field(v_x_24226, 0);
    heff_take_n(v_x_24226, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam35, 2, 1, (V[]){v_x_24229});
  }
  default: return heff_nomatch(v_x_24226);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam36(V self, V *args) {
  V v_x_24233 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_why_24215 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24233);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_24215});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam16(V self, V *args) {
  V v_x_2489 = args[0];
  V v_x_2488 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_v_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2489);
  switch (heff_tag_of(v_x_2488)) {
  case TAG_Nothing: {
    V v_t_2490 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
    V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str5), NTAG(TAG_Nil)});
    V v_t_2492 = ({ V a_0 = v_t_2490; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2490); r_; });
    V v_t_2493 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str7), v_t_2491}), v_t_2492, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2495 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2493, ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam17_clo)});
    V v_lit_2496 = v_a_2495;
    V v_hd_2497 = heff_dup(v_hd_244);
    V v_bind_2498 = heff_take_field(v_hd_2497, 1);
    V v_malg_2499 = heff_get_n(v_hd_2497, 2, 3);
    V v_k2_24207 = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam18, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245});
    V v_t_24208 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_lit_2496})});
    V v_t_24209 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24208})});
    V v_t_24210 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24209})});
    V v_t_24211 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24210})});
    V v_t_24212 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24211})});
    V v_t_24213 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24212})});
    V v_t_24214 = heff_tr(heff_call(v_malg_2499, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24213})}));
    V f_ = v_bind_2498;
    heff_room[0] = v_t_24214;
    heff_room[1] = v_k2_24207;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_24215 = heff_field(v_x_2488, 0);
    V v_ru_24x_2488_24Just = heff_take_reuse_n(v_x_2488, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    V v_path_24216 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_243));
    V v_t_24217 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24216; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24216); r_; });
    V v_a_24219 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_24217, ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam33_clo)});
    V v_t_24220 = heff_tag_at_n(v_ru_24x_2488_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24219})});
    V v_t_24221 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24220})});
    V v_t_24222 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24221})});
    V v_t_24223 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24222})});
    V v_t_24224 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24223})});
    V v_t_24225 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24224})});
    V v_c_24232 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24225}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam34_clo)));
    V f_ = v_c_24232;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam36, 1, 2, (V[]){v_k_245, v_why_24215});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2488);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam15(V self, V *args) {
  V v_x_2488 = args[0];
  V v_x_2479 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_v_242 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s1531911654x724325922(v_x_2479, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam16, 1, 7, (V[]){v_x_2488, v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245})));
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam14(V self, V *args) {
  V v_x_2479 = args[0];
  V v_v_242 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_ps_240 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2480 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str3); V a_1 = v_v_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str4), v_v_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  HeffT2 v_t_2481 = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(v_t_2480));
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    V v_c_2487;
    if ((v_tag_2482 == ((int64_t)0ULL))) {
      V v_it1_2484 = v_field_2483;
      switch (heff_tag_of(v_it1_2484)) {
      case TAG_MkPair: {
        V v_time_2485 = heff_field(v_it1_2484, 0);
        V v_hash_2486 = heff_field(v_it1_2484, 1);
        heff_take_n(v_it1_2484, 3ULL, 2);
        v_c_2487 = (g_heff_2ebuild_2efetch_2ecommitCloned_24s1703869007x1826892837(heff_dup(v_path_241), heff_dup(v_v_242), v_time_2485, v_hash_2486, heff_dup(v_x_243)));
        break;
      }
      default: heff_nomatch(v_it1_2484);
      }
    } else {
      heff_drop(v_field_2483);
      v_c_2487 = (g_heff_2ebuild_2efetch_2etagCloned_24s542869094x1884605422(heff_dup(v_path_241), heff_dup(v_v_242), heff_dup(v_x_243)));
    }
    V f_ = v_c_2487;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam15, 1, 7, (V[]){v_x_2479, v_hd_244, v_x_243, v_ps_240, v_path_241, v_v_242, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam12(V self, V *args) {
  V v_x_2473 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_ps_240 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2473);
  V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str1), heff_dup(v_path_241)), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str2));
  V v_t_2476 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(v_t_2474, heff_dup(v_v_242)), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam13_clo)});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2478;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam14, 1, 6, (V[]){v_v_242, v_path_241, v_x_243, v_hd_244, v_ps_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2442);
  V v_st_2443 = heff_dup(heff_rfield(v_ps_240, 5));
  HeffT3 v_t_2444 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2443), heff_dup(v_x_243)));
  V v_t_2454;
  {
    V v_field_2445 = v_t_2444.f[0];
    V v_field_2446 = v_t_2444.f[1];
    V v_field_2447 = v_t_2444.f[2];
    V v_d_2448 = v_field_2445;
    V v_a_2449 = v_field_2446;
    V v_xs_2450 = v_field_2447;
    V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2450));
    V v_xs_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2451; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2451); r_; });
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
    v_t_2454 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2448, v_a_2449, v_t_2453});
  }
  V v_s_2455 = ({ V a_0 = v_st_2443; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2443); heff_drop(v_t_2454); r_; });
  V v_path_2456 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2455));
  V v_t_2457 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2456; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2456); r_; });
  V v_a_2459 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2457, ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam9_clo)});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
  V v_c_2472 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam10_clo)));
  V f_ = v_c_2472;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam12, 1, 6, (V[]){v_path_241, v_v_242, v_hd_244, v_x_243, v_ps_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
    V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2425; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2425); r_; });
    V v_a_2428 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2426, ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam5_clo)});
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_c_2441 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam6_clo)));
    V f_ = v_c_2441;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam8, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_24234 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    heff_drop(v_x_243);
    heff_drop_rec(v_hd_244, 3);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    V v_t_24235 = (g_prelude_2eskipSpaces(v_y_24234, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24236 = (heff_unbox_word(heff_strLength_lent(v_y_24234, 0)) - ((int64_t)1ULL));
    V v_t_24237 = (g_prelude_2eskipSpaces(v_y_24234, heff_box_word(v_t_24236), MK_INT(-1LL)));
    V v_t_24238 = heff_strSlice(v_y_24234, v_t_24235, heff_intAdd(v_t_24237, MK_INT(1LL)));
    V v_x_24239 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_Right, 1, (V[]){v_t_24238});
    V f_ = v_k_245;
    args[0] = v_x_24239;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_str0))));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam1_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_c_2422 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam2_clo)));
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698_lam4, 1, 6, (V[]){v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_str0, 5, ".hash");
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam0, 2, 0};
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam3, 1, 0};
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam4(V self, V *args); static Clo g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam4, 1, 0};
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_entry, 3, 0};

V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop_rec(v_root_241, 4);
    return ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_path_247 = heff_take_field(v_x_245, 0);
    V v_version_248 = heff_get_n(v_x_245, 1, 3);
    V v_c_249 = (g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam1, 2, 5, (V[]){v_c_249, v_ps_240, v_path_247, v_version_248, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam3(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_err_2426 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Left = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2426})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2427));
  }
  case TAG_Right: {
    V v_x_2428 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam5, 2, 1, (V[]){v_x_2428});
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_path_247 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  V v_version_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    heff_take_n(v_x_2432, 0ULL, 1);
    heff_drop(v_version_248);
    V v_t_2434 = ({ V a_0 = v_path_247; V a_1 = heff_take_field(v_root_241, 2); V r_ = (g_list_2ekeepIf_24s1943838498x1969994910(a_0, a_1)); heff_drop(v_path_247); r_; });
    V v_x_2440;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_Nil: {
      heff_drop_rec(v_root_241, 4);
      v_x_2440 = v_x_2412;
      break;
    }
    case TAG_Cons: {
      V v_r_2435 = heff_field(v_t_2434, 0);
      heff_take_n(v_t_2434, 1ULL, 2);
      V v_t_2437 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2435, heff_get_n(v_root_241, 3, 4)));
      switch (heff_tag_of(v_t_2437)) {
      case TAG_Nil: {
        v_x_2440 = v_x_2412;
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2437, 0ULL, 2);
        v_x_2440 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    V f_ = v_k_2411;
    args[0] = v_x_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2441 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    V v_t_2442 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_247, heff_take_field(v_root_241, 2)));
    V v_x_2456;
    switch (heff_tag_of(v_t_2442)) {
    case TAG_Nil: {
      heff_drop_rec(v_root_241, 4);
      V v_t_2443 = (g_prelude_2eskipSpaces(v_y_2441, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2444 = (heff_unbox_word(heff_strLength_lent(v_y_2441, 0)) - ((int64_t)1ULL));
      V v_t_2445 = (g_prelude_2eskipSpaces(v_y_2441, heff_box_word(v_t_2444), MK_INT(-1LL)));
      V v_t_2446 = heff_strSlice(v_y_2441, v_t_2443, heff_intAdd(v_t_2445, MK_INT(1LL)));
      v_x_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_247, v_version_248, v_t_2446}), v_x_2412});
      break;
    }
    case TAG_Cons: {
      V v_r_2447 = heff_field(v_t_2442, 0);
      V v_ru_24t_2442_24Cons = heff_take_reuse_n(v_t_2442, 1ULL, 2);
      V v_t_2449 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_2447, heff_get_n(v_root_241, 3, 4)));
      switch (heff_tag_of(v_t_2449)) {
      case TAG_Nil: {
        V v_t_2450 = (g_prelude_2eskipSpaces(v_y_2441, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2451 = (heff_unbox_word(heff_strLength_lent(v_y_2441, 0)) - ((int64_t)1ULL));
        V v_t_2452 = (g_prelude_2eskipSpaces(v_y_2441, heff_box_word(v_t_2451), MK_INT(-1LL)));
        V v_t_2453 = heff_strSlice(v_y_2441, v_t_2450, heff_intAdd(v_t_2452, MK_INT(1LL)));
        v_x_2456 = heff_tag_at_n(v_ru_24t_2442_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_path__version__hash, (V[]){v_path_247, v_version_248, v_t_2453}), v_x_2412});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2449, 0ULL, 2);
        heff_drop(v_path_247);
        heff_drop(v_version_248);
        heff_drop(v_y_2441);
        heff_drop_cell(v_ru_24t_2442_24Cons, 2);
        v_x_2456 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_t_2449);
      }
      break;
    }
    default: heff_nomatch(v_t_2442);
    }
    V f_ = v_k_2411;
    args[0] = v_x_2456;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_path_247 = heff_env(self)[1];
  V v_version_248 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(v_path_247), heff_dup(v_version_248)));
  V v_s_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_str0));
  V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2414));
  V v_t_2416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2415; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2415); r_; });
  V v_a_2418 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2416, ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam3_clo)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_c_2431 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam4_clo)));
  V f_ = v_c_2431;
  heff_room[0] = v_hd_2410;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam6, 1, 5, (V[]){v_path_247, v_root_241, v_x_2412, v_k_2411, v_version_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_247 = heff_env(self)[2];
  V v_version_248 = heff_env(self)[3];
  V v_root_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982_lam2, 1, 6, (V[]){v_ps_240, v_path_247, v_version_248, v_hd_2410, v_root_241, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str3, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str4, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str5, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str8, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str10, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str15, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str17, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str21, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str22, 32, "heff get: cannot write heff.sum\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str23, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str24, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str25, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str26, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str27, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str28, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str32, 36, " packages, none fetched: no heff.sum");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str33, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str34, 1, "\012");
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam3, 1, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam4(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam4, 1, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam14(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam14, 2, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam15(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam15, 1, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam17(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam16(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam16, 1, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam19(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam18(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam22(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam25(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam24(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam23(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam21(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam20(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam0(V self, V *args);

static V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_val;
static HEFF_ONCE g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_st;
static V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_init(void) {
  V v_c_240 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  return heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam0, 2, 1, (V[]){v_c_240});
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_st)) return g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_val;
  return heff_global(&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_val, &g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_st, g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_init);
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam3(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2417})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2418));
  }
  case TAG_Right: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam5, 2, 1, (V[]){v_x_2419});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam8(V self, V *args) {
  V v_x_2453 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam10(V self, V *args) {
  V v_x_2467 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2467);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam11(V self, V *args) {
  V v_by_2471 = args[0];
  V v_path_2472 = args[1];
  V v_v_2473 = args[2];
  V v_x_245 = heff_env(self)[0];
  V v_root_2454 = heff_env(self)[1];
  V v_sums_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2efetch_2efetchedPkg_24s1218144068x1637600493(v_x_245, v_root_2454, v_sums_2468, v_by_2471, v_path_2472, v_v_2473));
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam14(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  heff_drop(v_hd_2489);
  V f_ = v_k_2490;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam15(V self, V *args) {
  V v_r_24101 = args[0];
  return v_r_24101;
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam17(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k_24114 = args[1];
  V v_x_24112 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24113);
  V f_ = v_k_24114;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24112});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam16(V self, V *args) {
  V v_x_24109 = args[0];
  switch (heff_tag_of(v_x_24109)) {
  case TAG_Left: {
    V v_err_24110 = heff_field(v_x_24109, 0);
    V v_ru_24x_24109_24Left = heff_take_reuse_n(v_x_24109, 1ULL, 1);
    V v_t_24111 = heff_tag_at_n(v_ru_24x_24109_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24110})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24111));
  }
  case TAG_Right: {
    V v_x_24112 = heff_field(v_x_24109, 0);
    heff_take_n(v_x_24109, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam17, 2, 1, (V[]){v_x_24112});
  }
  default: return heff_nomatch(v_x_24109);
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam19(V self, V *args) {
  V v_x_24118 = args[0];
  V v_k_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24121;
  switch (heff_tag_of(v_x_24118)) {
  case TAG_Left: {
    heff_take_n(v_x_24118, 0ULL, 1);
    v_t_24121 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_24118, 0ULL, 1);
    v_t_24121 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_24118);
  }
  V f_ = v_k_24117;
  args[0] = v_t_24121;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam18(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k_24117 = args[1];
  V v_c_24115 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24115;
  args[0] = v_hd_24116;
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam19, 1, 1, (V[]){v_k_24117});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam22(V self, V *args) {
  V v_x_24136 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24136);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam25(V self, V *args) {
  V v_x_24144 = args[0];
  V v_seen_24142 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24144; V a_1 = v_seen_24142; V r_ = (g_list_2efoldl_24s1910320727x339655847(a_0, a_1)); heff_drop(v_seen_24142); r_; });
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam24(V self, V *args) {
  V v_x_24139 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2475 = heff_env(self)[2];
  V v_x_2480 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_intLt_c(MK_INT(0LL), v_x_24139)) {
    heff_drop(v_x_2475);
    heff_drop(v_x_2480);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
  } else {
    V v_seen_24142;
    switch (heff_tag_of(v_x_2475)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x_2475, 0);
      heff_take_n(v_x_2475, 1ULL, 2);
      v_seen_24142 = v_x_24140;
      break;
    }
    default: heff_nomatch(v_x_2475);
    }
    V v_t_24143 = (g_list_2efoldl_24s422700624x1171050237(NTAG(TAG_Nil), heff_dup(v_seen_24142)));
    V v_t_24145 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam25, 1, 1, (V[]){v_seen_24142}); V a_3 = v_t_24143; V r_ = (g_list_2efoldl_24f556306710x2087456230(a_0, a_1, a_2, a_3)); heff_drop(v_t_24143); r_; });
    V v_t_24146 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str25), heff_intShow(v_t_24145));
    V v_t_24150;
    switch (heff_tag_of(v_x_2480)) {
    case TAG_Nil: {
      v_t_24150 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x_24147 = heff_field(v_x_2480, 0);
      V v_xs_24148 = heff_field(v_x_2480, 1);
      heff_take_n(v_x_2480, 3ULL, 2);
      V v_t_24149 = (g_list_2erunFrom_24s424587874x298262355(v_x_24147, v_xs_24148));
      v_t_24150 = (g_list_2emergeRuns_24s816413140x1019303067(NTAG(TAG_Nil), v_t_24149));
      break;
    }
    default: heff_nomatch(v_x_2480);
    }
    V v_x2_24151 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str26), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str27), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str28), v_t_24150));
    V v_t_24154;
    switch (heff_tag_of(v_x2_24151)) {
    case TAG_Nil: {
      v_t_24154 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str29);
      break;
    }
    case TAG_Cons: {
      V v_x_24152 = heff_field(v_x2_24151, 0);
      V v_xs_24153 = heff_field(v_x2_24151, 1);
      heff_take_n(v_x2_24151, 3ULL, 2);
      v_t_24154 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str30); V a_1 = v_x_24152; V a_2 = v_xs_24153; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24153); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24151);
    }
    V v_t_24155;
    if (heff_strEq_c(v_t_24154, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str31))) {
      v_t_24155 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str32);
    } else {
      v_t_24155 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str33);
    }
    V v_str_24156 = heff_strAppend(v_t_24146, v_t_24155);
    V v_t_24157 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24156, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str34)), NTAG(TAG_MkUnit)});
    V v_t_24158 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24157})});
    V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
    V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
    V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
    V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
    V v_t_24163 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24162})});
    V v_t_24164 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_24164;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam23(V self, V *args) {
  V v_x_24138 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2475 = heff_env(self)[2];
  V v_x_2480 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str24), heff_get_n(v_x_24138, 1, 5), MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam24, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2475, v_x_2480})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam21(V self, V *args) {
  V v_x_24127 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_24123 = heff_env(self)[2];
  V v_x_2475 = heff_env(self)[3];
  V v_x_2480 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_intLt_c(MK_INT(0LL), v_x_24127)) {
    heff_drop(v_x_24123);
    heff_drop(v_x_2475);
    heff_drop(v_x_2480);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
  } else {
    if (!(heff_dup(v_x_24123) == NTAG(TAG_True))) {
      heff_drop(v_x_24123);
      heff_drop(v_x_2475);
      heff_drop(v_x_2480);
      V v_t_24128 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str22), NTAG(TAG_MkUnit)});
      V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
      V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
      V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
      V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
      V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
      V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24133})});
      V v_t_24135 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24134})}));
      V f_ = heff_dup(heff_rfield(v_hd_241, 1));
      heff_room[0] = v_t_24135;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam22, 1, 2, (V[]){v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_24123);
      V v_c_24137 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str23)));
      V f_ = v_c_24137;
      heff_room[0] = heff_dup(v_hd_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam23, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2475, v_x_2480});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam20(V self, V *args) {
  V v_x_24123 = args[0];
  V v_x_2475 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2480 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24126;
  switch (heff_tag_of(v_x_2475)) {
  case TAG_MkPair: {
    V v_y_24125 = heff_dup(heff_field(v_x_2475, 1));
    v_t_24126 = v_y_24125;
    break;
  }
  default: heff_nomatch(v_x_2475);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str21), v_t_24126, MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam21, 1, 5, (V[]){v_hd_241, v_k_242, v_x_24123, v_x_2475, v_x_2480})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam13(V self, V *args) {
  V v_x_2480 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_2475 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2484;
  switch (heff_tag_of(v_x_2480)) {
  case TAG_Nil: {
    v_t_2484 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2481 = heff_dup(heff_field(v_x_2480, 0));
    V v_xs_2482 = heff_dup(heff_field(v_x_2480, 1));
    V v_t_2483 = (g_list_2erunFrom_24s424587874x298262355(v_x_2481, v_xs_2482));
    v_t_2484 = (g_list_2emergeRuns_24s816413140x1019303067(NTAG(TAG_Nil), v_t_2483));
    break;
  }
  default: heff_nomatch(v_x_2480);
  }
  V v_x2_2485 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str9), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str10), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str11), v_t_2484));
  V v_t_2488;
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_Nil: {
    v_t_2488 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_xs_2487 = heff_field(v_x2_2485, 1);
    heff_take_n(v_x2_2485, 3ULL, 2);
    v_t_2488 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str13); V a_1 = v_x_2486; V a_2 = v_xs_2487; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2487); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2485);
  }
  V v_c_24122;
  if (heff_strEq_c(v_t_2488, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str14))) {
    v_c_24122 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam14_clo);
  } else {
    V v_path_2491 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str15)));
    V v_t_2495;
    switch (heff_tag_of(v_x_2480)) {
    case TAG_Nil: {
      v_t_2495 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x_2492 = heff_dup(heff_field(v_x_2480, 0));
      V v_xs_2493 = heff_dup(heff_field(v_x_2480, 1));
      V v_t_2494 = (g_list_2erunFrom_24s424587874x298262355(v_x_2492, v_xs_2493));
      v_t_2495 = (g_list_2emergeRuns_24s816413140x1019303067(NTAG(TAG_Nil), v_t_2494));
      break;
    }
    default: heff_nomatch(v_x_2480);
    }
    V v_x2_2496 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str16), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str17), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str18), v_t_2495));
    V v_text_2499;
    switch (heff_tag_of(v_x2_2496)) {
    case TAG_Nil: {
      v_text_2499 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2497 = heff_field(v_x2_2496, 0);
      V v_xs_2498 = heff_field(v_x2_2496, 1);
      heff_take_n(v_x2_2496, 3ULL, 2);
      v_text_2499 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str20); V a_1 = v_x_2497; V a_2 = v_xs_2498; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2498); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2496);
    }
    V v_t_24100 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2491; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2491); r_; });
    V v_a_24102 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_24100, v_text_2499, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam15_clo)});
    V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24102})});
    V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
    V v_t_24107 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
    V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
    V v_c_24115 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24108}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam16_clo)));
    v_c_24122 = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam18, 2, 1, (V[]){v_c_24115});
  }
  V f_ = v_c_24122;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam20, 1, 4, (V[]){v_x_2475, v_hd_241, v_k_242, v_x_2480});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam12(V self, V *args) {
  V v_x_2475 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_2454 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2478;
  switch (heff_tag_of(v_x_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_dup(heff_field(v_x_2475, 0));
    v_t_2478 = v_x_2476;
    break;
  }
  default: heff_nomatch(v_x_2475);
  }
  V v_c_2479 = (g_heff_2ebuild_2efetch_2esumsOf_24s274621979x1481160982(v_x_245, v_root_2454, v_t_2478));
  V f_ = v_c_2479;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam13, 1, 3, (V[]){v_hd_241, v_x_2475, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_root_2454 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2456)) {
  case TAG_Left: {
    V v_why_2457 = heff_field(v_x_2456, 0);
    V v_ru_24x_2456_24Left = heff_take_reuse_n(v_x_2456, 1ULL, 1);
    heff_drop_rec(v_root_2454, 4);
    heff_drop(v_x_245);
    V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str5), v_why_2457), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str6));
    V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2458, NTAG(TAG_MkUnit)});
    V v_t_2460 = heff_tag_at_n(v_ru_24x_2456_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2466;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam10, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_sums_2468 = heff_field(v_x_2456, 0);
    heff_take_n(v_x_2456, 1ULL, 1);
    V v_t_2469;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2454, 0)), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str7))) {
      v_t_2469 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str8);
    } else {
      v_t_2469 = heff_dup(heff_rfield(v_root_2454, 0));
    }
    V v_t_2470 = (g_list_2emap_24s675147852x248982264(v_t_2469, heff_dup(heff_rfield(v_root_2454, 2))));
    V v_c_2474 = (g_heff_2ebuild_2eload_2eversionsGo_24s625013562x932185152(heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam11, 3, 3, (V[]){heff_dup(v_x_245), heff_dup(v_root_2454), v_sums_2468}), heff_rfield(v_root_2454, 0), v_t_2470, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V f_ = v_c_2474;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam12, 1, 4, (V[]){v_x_245, v_root_2454, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2456);
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426;
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    v_t_2426 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str2);
    break;
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  HeffT2 v_t_2427 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_t_2426));
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      heff_drop(v_x_245);
      V v_p_2430 = v_field_2429;
      heff_drop(v_p_2430);
      V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str3), NTAG(TAG_MkUnit)});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
      V f_ = heff_dup(heff_rfield(v_hd_241, 1));
      heff_room[0] = v_t_2438;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam7, 1, 2, (V[]){v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_x_2440 = v_field_2429;
      HeffT2 v_t_2441 = ({ V a_0 = v_x_2440; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2440); r_; });
      {
        V v_field_2443 = v_t_2441.f[1];
        int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
        if ((v_tag_2442 == ((int64_t)0ULL))) {
          heff_drop(v_x_245);
          V v_x_2444 = v_field_2443;
          heff_drop(v_x_2444);
          V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str4), NTAG(TAG_MkUnit)});
          V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
          V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
          V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
          V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
          V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
          V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
          V v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})}));
          V f_ = heff_dup(heff_rfield(v_hd_241, 1));
          heff_room[0] = v_t_2452;
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam8, 1, 2, (V[]){v_hd_241, v_k_242});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          V v_root_2454 = v_field_2443;
          V v_c_2455 = (g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(heff_dup(v_x_245)));
          V f_ = v_c_2455;
          heff_room[0] = heff_dup(v_hd_241);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam9, 1, 4, (V[]){v_hd_241, v_k_242, v_root_2454, v_x_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    }
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str1)));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam3_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_c_2422 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam4_clo)));
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam6, 1, 3, (V[]){v_hd_241, v_k_242, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_x_243, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_str0)));
  V f_ = v_c_244;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_240;
  args[0] = heff_dup(v_hd_241);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s787302179x1216885158_lam1, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str0, 7, "commits");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str1, 12, "finding the ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str4, 6, "--bare");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str5, 15, "--filter=tree:0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str6, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str8, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str10, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str11, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str12, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str13, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str14, 27, "cannot list the commits of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str15, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str16, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str17, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str18, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str19, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str20, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str21, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str22, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str23, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str24, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str25, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str26, 1, "0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str27, 5, ".0.0-");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str28, 1, "-");
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam2(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam2, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam5(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam5, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam6(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam6, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam9(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam9, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam11(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam11, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam13(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam13, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam14(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam14, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam15(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam15, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam16(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam16, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam18(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam18, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam20(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam19(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam19, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam22(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam21(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam17(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_entry, 3, 0};

V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064(V v_ps_240, V v_path_241, V v_rev_242) {
top: ;
  V v_x_243 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str0)));
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam0, 2, 4, (V[]){v_x_243, v_ps_240, v_rev_242, v_path_241});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam1(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2417})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2418));
  }
  case TAG_Right: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam3, 2, 1, (V[]){v_x_2419});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam5(V self, V *args) {
  V v_r_2439 = args[0];
  return v_r_2439;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam7(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_x_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    V v_err_2448 = heff_field(v_x_2447, 0);
    V v_ru_24x_2447_24Left = heff_take_reuse_n(v_x_2447, 1ULL, 1);
    V v_t_2449 = heff_tag_at_n(v_ru_24x_2447_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2448})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2449));
  }
  case TAG_Right: {
    V v_x_2450 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam7, 2, 1, (V[]){v_x_2450});
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam9(V self, V *args) {
  V v_t_2458 = args[0];
  return v_t_2458;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam11(V self, V *args) {
  V v_r_2469 = args[0];
  return v_r_2469;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam13(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  heff_drop(v_hd_2486);
  V f_ = v_k_2487;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam14(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  heff_drop(v_hd_2489);
  V f_ = v_k_2490;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam15(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  heff_drop(v_hd_2491);
  V f_ = v_k_2492;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam16(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k_2494 = args[1];
  heff_drop(v_hd_2493);
  V f_ = v_k_2494;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam18(V self, V *args) {
  V v_r_2499 = args[0];
  return v_r_2499;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam20(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_x_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24111);
  V f_ = v_k_24112;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24110});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam19(V self, V *args) {
  V v_x_24107 = args[0];
  switch (heff_tag_of(v_x_24107)) {
  case TAG_Left: {
    V v_err_24108 = heff_field(v_x_24107, 0);
    V v_ru_24x_24107_24Left = heff_take_reuse_n(v_x_24107, 1ULL, 1);
    V v_t_24109 = heff_tag_at_n(v_ru_24x_24107_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24108})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24109));
  }
  case TAG_Right: {
    V v_x_24110 = heff_field(v_x_24107, 0);
    heff_take_n(v_x_24107, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam20, 2, 1, (V[]){v_x_24110});
  }
  default: return heff_nomatch(v_x_24107);
  }
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam22(V self, V *args) {
  V v_x_24118 = args[0];
  V v_ended_2479 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_err_2480 = heff_env(self)[2];
  V v_x_2496 = heff_env(self)[3];
  V v_rev_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24118);
  V v_t_24121;
  switch (heff_tag_of(v_ended_2479)) {
  case TAG_Exited: {
    V v_n_24119 = heff_field(v_ended_2479, 0);
    heff_take_n(v_ended_2479, 1ULL, 1);
    v_t_24121 = heff_bool(!heff_intEq_c_lent(v_n_24119, MK_INT(0LL), 2));
    heff_drop(v_n_24119);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2479, 0ULL, 1);
    v_t_24121 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_24121 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_24121 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2479);
  }
  V v_x_24159;
  if ((heff_dup(v_t_24121) == NTAG(TAG_True))) {
    heff_drop(v_x_2496);
    heff_drop(v_rev_242);
    heff_drop(v_t_24121);
    V v_t_24122 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
    V v_t_24123 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str14), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str15), v_t_24122));
    V v_s_24124 = v_err_2480;
    V v_t_24125 = (g_prelude_2eskipSpaces(v_s_24124, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24126 = (heff_unbox_word(heff_strLength_lent(v_s_24124, 0)) - ((int64_t)1ULL));
    V v_t_24127 = (g_prelude_2eskipSpaces(v_s_24124, heff_box_word(v_t_24126), MK_INT(-1LL)));
    V v_t_24128 = heff_strSlice(v_s_24124, v_t_24125, heff_intAdd(v_t_24127, MK_INT(1LL)));
    V v_t_24129 = heff_strAppend(heff_strAppend(v_t_24123, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str16)), v_t_24128);
    v_x_24159 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24129});
  } else {
    heff_drop(v_err_2480);
    heff_drop(v_t_24121);
    switch (heff_tag_of(v_x_2496)) {
    case TAG_Nothing: {
      V v_t_24130 = (g_heff_2ebuild_2efetch_2erevSaid(v_rev_242));
      V v_t_24131 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str17), v_t_24130), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str18));
      V v_t_24132 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
      V v_t_24133 = heff_strAppend(v_t_24131, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str19), v_t_24132));
      v_x_24159 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24133});
      break;
    }
    case TAG_Just: {
      V v_it1_24134 = heff_field(v_x_2496, 0);
      V v_ru_24x_2496_24Just = heff_take_reuse_n(v_x_2496, 1ULL, 1);
      heff_drop(v_rev_242);
      switch (heff_tag_of(v_it1_24134)) {
      case TAG_MkPair: {
        V v_time_24135 = heff_field(v_it1_24134, 0);
        V v_hash_24136 = heff_field(v_it1_24134, 1);
        heff_take_n(v_it1_24134, 3ULL, 2);
        V v_path_24137 = v_path_241;
        V v_time_24138 = v_time_24135;
        V v_hash_24139 = v_hash_24136;
        V v_xs_24140 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str20); V a_1 = v_path_24137; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str21), v_path_24137, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_24141 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24140));
        V v_t_24144;
        switch (heff_tag_of(v_t_24141)) {
        case TAG_Nil: {
          v_t_24144 = heff_dup(v_path_24137);
          break;
        }
        case TAG_Cons: {
          V v_x_24142 = heff_field(v_t_24141, 0);
          heff_take_n(v_t_24141, 1ULL, 2);
          v_t_24144 = v_x_24142;
          break;
        }
        default: heff_nomatch(v_t_24141);
        }
        V v_t_24145 = ({ V a_0 = v_t_24144; V r_ = (g_heff_2ebuild_2eproject_2eisMajorPart(a_0)); heff_drop(v_t_24144); r_; });
        V v_t_24156;
        if ((heff_dup(v_t_24145) == NTAG(TAG_True))) {
          heff_drop(v_t_24145);
          V v_xs_24146 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str22); V a_1 = v_path_24137; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str23), v_path_24137, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_24147 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24146));
          V v_t_24150;
          switch (heff_tag_of(v_t_24147)) {
          case TAG_Nil: {
            v_t_24150 = heff_dup(v_path_24137);
            break;
          }
          case TAG_Cons: {
            V v_x_24148 = heff_field(v_t_24147, 0);
            heff_take_n(v_t_24147, 1ULL, 2);
            v_t_24150 = v_x_24148;
            break;
          }
          default: heff_nomatch(v_t_24147);
          }
          V v_xs_24151 = ({ V b_0 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str24); V a_1 = v_path_24137; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str25), v_path_24137, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_24152 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24151));
          V v_t_24155;
          switch (heff_tag_of(v_t_24152)) {
          case TAG_Nil: {
            v_t_24155 = v_path_24137;
            break;
          }
          case TAG_Cons: {
            V v_x_24153 = heff_field(v_t_24152, 0);
            heff_take_n(v_t_24152, 1ULL, 2);
            heff_drop(v_path_24137);
            v_t_24155 = v_x_24153;
            break;
          }
          default: heff_nomatch(v_t_24152);
          }
          v_t_24156 = heff_strSlice(v_t_24150, MK_INT(1LL), heff_strLength(v_t_24155));
        } else {
          heff_drop(v_path_24137);
          heff_drop(v_t_24145);
          v_t_24156 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str26);
        }
        V v_t_24157 = heff_strAppend(heff_strAppend(v_t_24156, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str27)), v_time_24138);
        V v_t_24158 = heff_strAppend(heff_strAppend(v_t_24157, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str28)), heff_strSlice(v_hash_24139, MK_INT(0LL), MK_INT(12LL)));
        v_x_24159 = heff_tag_at_n(v_ru_24x_2496_24Just, TAG_Right, 1, (V[]){v_t_24158});
        break;
      }
      default: heff_nomatch(v_it1_24134);
      }
      break;
    }
    default: heff_nomatch(v_x_2496);
    }
  }
  V f_ = v_k_245;
  args[0] = v_x_24159;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam21(V self, V *args) {
  V v_x_24114 = args[0];
  V v_x_2462 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_ended_2479 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_err_2480 = heff_env(self)[4];
  V v_x_2496 = heff_env(self)[5];
  V v_rev_242 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_24114);
  V v_t_24115 = heff_tag_n(TAG_End, 2, (V[]){v_x_2462, NTAG(TAG_MkUnit)});
  V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24116})}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_24117;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam22, 1, 6, (V[]){v_ended_2479, v_path_241, v_err_2480, v_x_2496, v_rev_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam17(V self, V *args) {
  V v_x_2496 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_2462 = heff_env(self)[2];
  V v_ended_2479 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_err_2480 = heff_env(self)[5];
  V v_rev_242 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_path_2497 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_243));
  V v_t_2498 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2497; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2497); r_; });
  V v_a_24100 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2498, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam18_clo)});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
  V v_c_24113 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24106}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam19_clo)));
  V f_ = v_c_24113;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam21, 1, 8, (V[]){v_x_2462, v_hd_244, v_ended_2479, v_path_241, v_err_2480, v_x_2496, v_rev_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam12(V self, V *args) {
  V v_x_2478 = args[0];
  V v_rev_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2462 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_ended_2479 = heff_take_field(v_x_2478, 0);
  V v_err_2480 = heff_get_n(v_x_2478, 2, 3);
  V v_c_2495;
  switch (heff_tag_of(v_ended_2479)) {
  case TAG_Exited: {
    V v_n_2481 = heff_dup(heff_field(v_ended_2479, 0));
    if (heff_intEq_c(v_n_2481, MK_INT(0LL))) {
      V v_rev_2482 = heff_dup(v_rev_242);
      V v_t_2485;
      if (heff_strEq_c_lent(v_rev_2482, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str10), 2)) {
        v_t_2485 = v_rev_2482;
      } else {
        if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_2482, 0)))) {
          if ((heff_unbox_word(heff_strLength_lent(v_rev_2482, 0)) <= ((int64_t)40ULL))) {
            V v_t_2483 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_2482, 0)));
            V v_t_2484 = ({ V a_0 = v_rev_2482; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_2483; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2483); r_; });
            if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
              heff_drop(v_t_2484);
              v_t_2485 = v_rev_2482;
            } else {
              heff_drop(v_t_2484);
              v_t_2485 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str11), v_rev_2482);
            }
          } else {
            v_t_2485 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str12), v_rev_2482);
          }
        } else {
          v_t_2485 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str13), v_rev_2482);
        }
      }
      v_c_2495 = (g_heff_2ebuild_2efetch_2ecommitAt_24s610684802x1542059868(heff_dup(v_x_243), v_t_2485));
    } else {
      v_c_2495 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam13_clo);
    }
    break;
  }
  case TAG_Signalled: {
    v_c_2495 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam14_clo);
    break;
  }
  case TAG_TimedOut: {
    v_c_2495 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam15_clo);
    break;
  }
  case TAG_NotRun: {
    v_c_2495 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam16_clo);
    break;
  }
  default: heff_nomatch(v_ended_2479);
  }
  V f_ = v_c_2495;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam17, 1, 8, (V[]){v_x_243, v_hd_244, v_x_2462, v_ended_2479, v_path_241, v_err_2480, v_rev_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_rev_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2463 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str3), v_t_2463), v_t_2464});
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str5), v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str7), v_t_2466})});
  V v_t_2468 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str8), v_t_2467, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str9), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2468, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam11_clo)})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2476}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2477;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam12, 1, 6, (V[]){v_rev_242, v_x_243, v_hd_244, v_x_2462, v_path_241, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_rev_242 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2454);
  V v_t_2455 = (g_heff_2ebuild_2efetch_2erevSaid(heff_dup(v_rev_242)));
  V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str1), v_t_2455), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_str2));
  V v_name_2457 = heff_strAppend(v_t_2456, heff_dup(v_path_241));
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_name_2457, MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam9_clo)})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2460}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2461;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam10, 1, 5, (V[]){v_path_241, v_x_243, v_hd_244, v_rev_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_rev_242 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2423);
  V v_st_2424 = heff_get_n(v_ps_240, 5, 6);
  HeffT3 v_t_2425 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2424), heff_dup(v_x_243)));
  V v_t_2435;
  {
    V v_field_2426 = v_t_2425.f[0];
    V v_field_2427 = v_t_2425.f[1];
    V v_field_2428 = v_t_2425.f[2];
    V v_d_2429 = v_field_2426;
    V v_a_2430 = v_field_2427;
    V v_xs_2431 = v_field_2428;
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    V v_xs_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2432; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2432); r_; });
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2433));
    v_t_2435 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2429, v_a_2430, v_t_2434});
  }
  V v_s_2436 = ({ V a_0 = v_st_2424; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); heff_drop(v_t_2435); r_; });
  V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2436));
  V v_t_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2437; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2437); r_; });
  V v_a_2440 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam5_clo)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_c_2453 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam6_clo)));
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam8, 1, 5, (V[]){v_rev_242, v_path_241, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rev_242 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam1_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_c_2422 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam2_clo)));
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s1209809942x1298887064_lam4, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_rev_242, v_path_241, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str1, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str5, 3, "src");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str6, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str8, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str10, 1, "`");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str11, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str12, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str13, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str15, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str16, 11, "{ module = ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str17, 9, ", heff = ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str20, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str21, 13, ", require = [");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str22, 1, "]");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str25, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str26, 13, ", replace = [");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str27, 1, "]");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str28, 2, " }");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str29, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str30, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str31, 34, "heff get: cannot write package.hf\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str32, 30, "heff get: package.hf requires ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str33, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str34, 1, "\012");
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam0(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam15(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam15, 1, 0};
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam17(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam16(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam16, 1, 0};
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam20(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam19(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam21(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam18(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam3(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_entry, 5, 0};

V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_243), heff_dup(v_v_244)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_text_241);
      heff_drop_rec(v_pk_242, 4);
      heff_drop(v_v_244);
      V v_why_248 = v_field_247;
      return heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam0, 2, 2, (V[]){v_path_243, v_why_248});
    } else {
      heff_drop(v_field_247);
      V v_c_2433 = (g_heff_2ebuild_2efetch_2efetched_24s857505634x1155359698(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
      return heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam3, 2, 6, (V[]){v_c_2433, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
    }
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2432);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_malg_2412 = heff_env(self)[0];
  V v_bind_2411 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(v_malg_2412, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})}));
  V f_ = v_bind_2411;
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam2, 1, 1, (V[]){v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_why_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2411 = heff_take_field(v_hd_249, 1);
  V v_malg_2412 = heff_get_n(v_hd_249, 2, 3);
  V v_t_2413 = heff_strAppend(heff_strAppend(v_path_243, ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str0)), v_why_248);
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str1), v_t_2413), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str2));
  V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_2412), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
  V f_ = heff_dup(v_bind_2411);
  args[0] = v_t_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam1, 1, 3, (V[]){v_malg_2412, v_bind_2411, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2456);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam5(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})}));
  V f_ = heff_get_n(v_hd_2434, 1, 3);
  heff_room[0] = v_t_2455;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam6, 1, 1, (V[]){v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam10(V self, V *args) {
  V v_x_2488 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2488);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam9(V self, V *args) {
  V v_x_2479 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2479);
  V v_t_2480 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})}));
  V f_ = heff_get_n(v_hd_2434, 1, 3);
  heff_room[0] = v_t_2487;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam10, 1, 1, (V[]){v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam12(V self, V *args) {
  V v_x_24109 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24109);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam11(V self, V *args) {
  V v_x_24100 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24100);
  V v_t_24101 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})}));
  V f_ = heff_get_n(v_hd_2434, 1, 3);
  heff_room[0] = v_t_24108;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam12, 1, 1, (V[]){v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam14(V self, V *args) {
  V v_x_24133 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24133);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam13(V self, V *args) {
  V v_x_24124 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24124);
  V v_t_24125 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24125})});
  V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
  V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
  V v_t_24131 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24130})});
  V v_t_24132 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24131})}));
  V f_ = heff_get_n(v_hd_2434, 1, 3);
  heff_room[0] = v_t_24132;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam14, 1, 1, (V[]){v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam15(V self, V *args) {
  V v_r_24186 = args[0];
  return v_r_24186;
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam17(V self, V *args) {
  V v_hd_24198 = args[0];
  V v_k_24199 = args[1];
  V v_x_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24198);
  V f_ = v_k_24199;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24197});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam16(V self, V *args) {
  V v_x_24194 = args[0];
  switch (heff_tag_of(v_x_24194)) {
  case TAG_Left: {
    V v_err_24195 = heff_field(v_x_24194, 0);
    V v_ru_24x_24194_24Left = heff_take_reuse_n(v_x_24194, 1ULL, 1);
    V v_t_24196 = heff_tag_at_n(v_ru_24x_24194_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24195})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24196));
  }
  case TAG_Right: {
    V v_x_24197 = heff_field(v_x_24194, 0);
    heff_take_n(v_x_24194, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam17, 2, 1, (V[]){v_x_24197});
  }
  default: return heff_nomatch(v_x_24194);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam20(V self, V *args) {
  V v_x_24220 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24220);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam19(V self, V *args) {
  V v_x_24211 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24211);
  V v_t_24212 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24213 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24212})});
  V v_t_24214 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24213})});
  V v_t_24215 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24214})});
  V v_t_24216 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24215})});
  V v_t_24217 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24216})});
  V v_t_24218 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24217})});
  V v_t_24219 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24218})}));
  V f_ = heff_get_n(v_hd_2434, 1, 3);
  heff_room[0] = v_t_24219;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam20, 1, 1, (V[]){v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam21(V self, V *args) {
  V v_x_24232 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24232);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam18(V self, V *args) {
  V v_x_24201 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24201)) {
  case TAG_Left: {
    V v_ru_24x_24201_24Left = heff_take_reuse_n(v_x_24201, 0ULL, 1);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    V v_t_24203 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str31), NTAG(TAG_MkUnit)});
    V v_t_24204 = heff_tag_at_n(v_ru_24x_24201_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24203})});
    V v_t_24205 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24204})});
    V v_t_24206 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24205})});
    V v_t_24207 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24206})});
    V v_t_24208 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24207})});
    V v_t_24209 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24208})});
    V v_t_24210 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2434, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24209})}));
    V f_ = heff_dup(heff_rfield(v_hd_2434, 1));
    heff_room[0] = v_t_24210;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam19, 1, 2, (V[]){v_hd_2434, v_k_2435});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_24201_24Right = heff_take_reuse_n(v_x_24201, 0ULL, 1);
    V v_t_24222 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str32), v_path_243), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str33));
    V v_t_24223 = heff_strAppend(heff_strAppend(v_t_24222, v_v_244), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str34));
    V v_t_24224 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24223, NTAG(TAG_MkUnit)});
    V v_t_24225 = heff_tag_at_n(v_ru_24x_24201_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24224})});
    V v_t_24226 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24225})});
    V v_t_24227 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24226})});
    V v_t_24228 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24227})});
    V v_t_24229 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24228})});
    V v_t_24230 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24229})});
    V v_t_24231 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24230})}));
    V f_ = heff_get_n(v_hd_2434, 1, 3);
    heff_room[0] = v_t_24231;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam21, 1, 1, (V[]){v_k_2435});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24201);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_x_2460 = heff_env(self)[0];
  V v_hd_2434 = heff_env(self)[1];
  V v_k_2435 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  V v_v_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Left: {
    V v_why_2469 = heff_field(v_x_2460, 0);
    V v_ru_24x_2460_24Left = heff_take_reuse_n(v_x_2460, 1ULL, 1);
    heff_drop(v_x_2468);
    heff_drop(v_path_243);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_text_241);
    heff_drop(v_v_244);
    V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str6), v_why_2469), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str7));
    V v_t_2471 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2470, NTAG(TAG_MkUnit)});
    V v_t_2472 = heff_tag_at_n(v_ru_24x_2460_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2434, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
    V f_ = heff_dup(heff_rfield(v_hd_2434, 1));
    heff_room[0] = v_t_2478;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam9, 1, 2, (V[]){v_hd_2434, v_k_2435});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_2460_24Right = heff_take_reuse_n(v_x_2460, 0ULL, 1);
    switch (heff_tag_of(v_x_2468)) {
    case TAG_Left: {
      V v_why_2490 = heff_field(v_x_2468, 0);
      V v_ru_24x_2468_24Left = heff_take_reuse_n(v_x_2468, 1ULL, 1);
      heff_drop(v_path_243);
      heff_drop_rec(v_pk_242, 4);
      heff_drop(v_text_241);
      heff_drop(v_v_244);
      V v_t_2491 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str8), v_why_2490), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str9));
      V v_t_2492 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2491, NTAG(TAG_MkUnit)});
      V v_t_2493 = heff_tag_at_n(v_ru_24x_2460_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2468_24Left, TAG_InL, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
      V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
      V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
      V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2434, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})}));
      V f_ = heff_dup(heff_rfield(v_hd_2434, 1));
      heff_room[0] = v_t_2499;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam11, 1, 2, (V[]){v_hd_2434, v_k_2435});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Right: {
      V v_name_24110 = heff_field(v_x_2468, 0);
      V v_ru_24x_2468_24Right = heff_take_reuse_n(v_x_2468, 1ULL, 1);
      V v_x1_24111 = (g_list_2eany_24s1435008228x557204311(v_path_243, heff_rfield(v_pk_242, 2)));
      V v_t_24112;
      if (!(heff_dup(v_x1_24111) == NTAG(TAG_True))) {
        heff_drop(v_x1_24111);
        v_t_24112 = (g_list_2eany_24s944501138x775098345(v_name_24110, heff_rfield(v_pk_242, 2)));
      } else {
        heff_drop(v_x1_24111);
        v_t_24112 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
        heff_drop_rec(v_pk_242, 4);
        heff_drop(v_text_241);
        heff_drop(v_v_244);
        heff_drop(v_t_24112);
        V v_t_24113 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str10), v_name_24110), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str11));
        V v_t_24114 = heff_strAppend(heff_strAppend(v_t_24113, v_path_243), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str12));
        V v_t_24115 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str13), v_t_24114), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str14));
        V v_t_24116 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24115, NTAG(TAG_MkUnit)});
        V v_t_24117 = heff_tag_at_n(v_ru_24x_2460_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2468_24Right, TAG_InL, 1, (V[]){v_t_24116})});
        V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
        V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
        V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
        V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
        V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24121})});
        V v_t_24123 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2434, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})}));
        V f_ = heff_dup(heff_rfield(v_hd_2434, 1));
        heff_room[0] = v_t_24123;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam13, 1, 2, (V[]){v_hd_2434, v_k_2435});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_24112);
        V v_path_24134 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str15)));
        V v_src_24135 = v_text_241;
        V v_t_24136 = (g_list_2eany_24s1435008228x557204311(v_path_243, heff_rfield(v_pk_242, 2)));
        V v_t_24138;
        if ((heff_dup(v_t_24136) == NTAG(TAG_True))) {
          heff_drop(v_name_24110);
          heff_drop(v_t_24136);
          v_t_24138 = (g_list_2emap_24s1193924222x1531824795(heff_dup(v_path_243), heff_dup(v_v_244), heff_dup(heff_rfield(v_pk_242, 2))));
        } else {
          heff_drop(v_t_24136);
          V v_t_24137 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_24110, heff_dup(v_path_243), heff_dup(v_v_244)}), NTAG(TAG_Nil)});
          v_t_24138 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_242, 2)), v_t_24137));
        }
        V v_pk_24139 = ({ V rv_2 = v_t_24138; V rr_ = heff_rec_reuse_nf(v_pk_242, 11ULL, 4, shape_module__heff__require__replace, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_24140 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        HeffT3 v_t_24141 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_24135), v_t_24140, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
        V v_t_24145;
        {
          V v_field_24142 = v_t_24141.f[0];
          heff_drop(v_t_24141.f[1]);
          heff_drop(v_t_24141.f[2]);
          v_t_24145 = v_field_24142;
        }
        HeffT2 v_t_24146 = ({ V b_0 = heff_arrayFromList(v_t_24145); V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ebuild_2eproject_2espanGo_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_text_24178;
        {
          V v_field_24148 = v_t_24146.f[1];
          int64_t v_tag_24147 = ((int64_t)v_t_24146.f[0]);
          if ((v_tag_24147 == ((int64_t)0ULL))) {
            V v_it1_24149 = v_field_24148;
            switch (heff_tag_of(v_it1_24149)) {
            case TAG_MkPair: {
              V v_from_24150 = heff_field(v_it1_24149, 0);
              V v_to_24151 = heff_field(v_it1_24149, 1);
              heff_take_n(v_it1_24149, 3ULL, 2);
              V v_pk_24152 = v_pk_24139;
              V v_module_24153 = heff_take_field(v_pk_24152, 0);
              V v_heff_24154 = heff_take_field(v_pk_24152, 1);
              V v_require_24155 = heff_take_field(v_pk_24152, 2);
              V v_replace_24156 = heff_get_n(v_pk_24152, 3, 4);
              V v_t_24157 = ({ V a_0 = v_module_24153; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_module_24153); r_; });
              V v_t_24158 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str16), v_t_24157), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str17));
              V v_t_24159 = ({ V a_0 = v_heff_24154; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_heff_24154); r_; });
              V v_items_24160 = (g_list_2emap_24s1381986540x1952410492(v_require_24155));
              V v_t_24166;
              switch (heff_tag_of(v_items_24160)) {
              case TAG_Nil: {
                v_t_24166 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str18);
                break;
              }
              case TAG_Cons: {
                V v_t_24165;
                switch (heff_tag_of(v_items_24160)) {
                case TAG_Nil: {
                  v_t_24165 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str19);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24163 = heff_field(v_items_24160, 0);
                  V v_xs_24164 = heff_field(v_items_24160, 1);
                  heff_take_n(v_items_24160, 3ULL, 2);
                  v_t_24165 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str20); V a_1 = v_x_24163; V a_2 = v_xs_24164; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24164); r_; });
                  break;
                }
                default: heff_nomatch(v_items_24160);
                }
                v_t_24166 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str21), v_t_24165), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str22));
                break;
              }
              default: heff_nomatch(v_items_24160);
              }
              V v_t_24167 = heff_strAppend(heff_strAppend(v_t_24158, v_t_24159), v_t_24166);
              V v_items_24168 = (g_list_2emap_24s404123879x745642248(v_replace_24156));
              V v_t_24174;
              switch (heff_tag_of(v_items_24168)) {
              case TAG_Nil: {
                v_t_24174 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str23);
                break;
              }
              case TAG_Cons: {
                V v_t_24173;
                switch (heff_tag_of(v_items_24168)) {
                case TAG_Nil: {
                  v_t_24173 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str24);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24171 = heff_field(v_items_24168, 0);
                  V v_xs_24172 = heff_field(v_items_24168, 1);
                  heff_take_n(v_items_24168, 3ULL, 2);
                  v_t_24173 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str25); V a_1 = v_x_24171; V a_2 = v_xs_24172; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24172); r_; });
                  break;
                }
                default: heff_nomatch(v_items_24168);
                }
                v_t_24174 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str26), v_t_24173), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str27));
                break;
              }
              default: heff_nomatch(v_items_24168);
              }
              V v_t_24175 = heff_strAppend(heff_strAppend(v_t_24167, v_t_24174), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str28));
              V v_t_24176 = heff_strAppend(heff_strSlice_lent(v_src_24135, MK_INT(0LL), v_from_24150, 6), v_t_24175);
              V v_t_24177 = heff_strSlice(heff_dup(v_src_24135), v_to_24151, heff_strLength(v_src_24135));
              v_text_24178 = heff_strAppend(v_t_24176, v_t_24177);
              break;
            }
            default: heff_nomatch(v_it1_24149);
            }
          } else {
            heff_drop_rec(v_pk_24139, 4);
            heff_drop(v_field_24148);
            v_text_24178 = v_src_24135;
          }
        }
        V v_text_24184;
        if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str29), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str30))) {
          HeffT2 v_t_24179 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_24178)));
          {
            V v_field_24181 = v_t_24179.f[1];
            int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
            if ((v_tag_24180 == ((int64_t)0ULL))) {
              V v_x_24182 = v_field_24181;
              heff_drop(v_x_24182);
              v_text_24184 = v_text_24178;
            } else {
              heff_drop(v_text_24178);
              V v_out_24183 = v_field_24181;
              v_text_24184 = v_out_24183;
            }
          }
        } else {
          v_text_24184 = v_text_24178;
        }
        V v_t_24185 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24134; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24134); r_; });
        V v_a_24187 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_24185, v_text_24184, ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam15_clo)});
        V v_t_24188 = heff_tag_at_n(v_ru_24x_2460_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2468_24Right, TAG_InR, 1, (V[]){v_a_24187})});
        V v_t_24189 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24188})});
        V v_t_24190 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24189})});
        V v_t_24191 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24190})});
        V v_t_24192 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24191})});
        V v_t_24193 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24192})});
        V v_c_24200 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24193}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam16_clo)));
        V f_ = v_c_24200;
        heff_room[0] = heff_dup(v_hd_2434);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam18, 1, 4, (V[]){v_hd_2434, v_k_2435, v_path_243, v_v_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_x_2468);
    }
  }
  default: return heff_nomatch(v_x_2460);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam7(V self, V *args) {
  V v_x_2460 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_path_243 = heff_env(self)[1];
  V v_v_244 = heff_env(self)[2];
  V v_hd_2434 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2461 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_a_2462 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
  V v_t_2463 = (g_std_2epath_2eparse(heff_dup(v_st_2461), v_a_2462));
  V v_t_2464 = (g_std_2epath_2eparse(heff_dup(v_st_2461), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str5)));
  V v_t_2465 = (g_std_2epath_2ejoin(v_t_2463, v_t_2464));
  V v_t_2466 = ({ V a_0 = v_st_2461; V a_1 = v_t_2465; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2461); heff_drop(v_t_2465); r_; });
  V v_c_2467 = (g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(v_ps_240, v_t_2466));
  V f_ = v_c_2467;
  heff_room[0] = heff_dup(v_hd_2434);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam8, 1, 7, (V[]){v_x_2460, v_hd_2434, v_k_2435, v_path_243, v_pk_242, v_text_241, v_v_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    V v_why_2437 = heff_field(v_x_2436, 0);
    V v_ru_24x_2436_24Left = heff_take_reuse_n(v_x_2436, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_text_241);
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str3), v_why_2437), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_str4));
    V v_t_2439 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2438, NTAG(TAG_MkUnit)});
    V v_t_2440 = heff_tag_at_n(v_ru_24x_2436_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2434, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
    V f_ = heff_dup(heff_rfield(v_hd_2434, 1));
    heff_room[0] = v_t_2446;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam5, 1, 2, (V[]){v_hd_2434, v_k_2435});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2436, 0ULL, 1);
    V v_t_2458 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    V v_c_2459 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(heff_dup(v_ps_240), v_t_2458, heff_dup(v_path_243)));
    V f_ = v_c_2459;
    heff_room[0] = heff_dup(v_hd_2434);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam7, 1, 7, (V[]){v_ps_240, v_path_243, v_v_244, v_hd_2434, v_k_2435, v_pk_242, v_text_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1843556236x1742222532_lam4, 1, 7, (V[]){v_hd_2434, v_k_2435, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}