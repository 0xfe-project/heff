// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Posix 44191
#define TAG_Windows 49101
#define LBL_absolute 325777132
#define LBL_drive 297211300
#define LBL_segments 1801007612
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1725521117x1379101383(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1725521117x1379101383_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1725521117x1379101383_clo;
V g_list_2emap_24f2056124927x822823214(V, V, V);
V g_list_2emap_24f2056124927x822823214_entry(V self, V *a);
extern Clo g_list_2emap_24f2056124927x822823214_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2edriveOf(V, V);
V g_std_2epath_2edriveOf_entry(V self, V *a);
extern Clo g_std_2epath_2edriveOf_clo;
V g_std_2epath_2edriveOf_2eunc_240(V, V);
V g_std_2epath_2edriveOf_2eunc_240_entry(V self, V *a);
extern Clo g_std_2epath_2edriveOf_2eunc_240_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2enormalize(V, V);
V g_std_2epath_2enormalize_entry(V self, V *a);
extern Clo g_std_2epath_2enormalize_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2eparse_2ekeep_240(V);
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_2ekeep_240_clo;
V g_std_2epath_2erelative(V, V, V);
V g_std_2epath_2erelative_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_clo;
V g_std_2epath_2erelative_2ego_240(V, V, V);
V g_std_2epath_2erelative_2ego_240_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_2ego_240_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2erender_2eslashesTo_240(V, V);
V g_std_2epath_2erender_2eslashesTo_240_entry(V self, V *a);
extern Clo g_std_2epath_2erender_2eslashesTo_240_clo;
V g_std_2epath_2esameDrive(V, V, V);
V g_std_2epath_2esameDrive_entry(V self, V *a);
extern Clo g_std_2epath_2esameDrive_clo;
V g_std_2epath_2eunshared(V, V, V);
V g_std_2epath_2eunshared_entry(V self, V *a);
extern Clo g_std_2epath_2eunshared_clo;
HEFF_LIT(g_std_2epath_2edriveOf_str0, 0, "");
HEFF_LIT(g_std_2epath_2edriveOf_str1, 2, "//");
HEFF_LIT(g_std_2epath_2edriveOf_str2, 3, "///");
HEFF_LIT(g_std_2epath_2edriveOf_str3, 1, "/");
HEFF_LIT(g_std_2epath_2edriveOf_str4, 1, "/");
HEFF_LIT(g_std_2epath_2edriveOf_str5, 1, ":");
HEFF_LIT(g_std_2epath_2edriveOf_str6, 0, "");
HEFF_LIT(g_std_2epath_2edriveOf_str7, 0, "");
HEFF_LIT(g_std_2epath_2edriveOf_str8, 0, "");
Clo g_std_2epath_2edriveOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2edriveOf_entry, 2, 0};

V g_std_2epath_2edriveOf(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Posix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str0), v_s_241});
  }
  case TAG_Windows: {
    V v_t_244 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2epath_2edriveOf_str1)) && !heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_std_2epath_2edriveOf_str2))));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_s_245 = heff_strSlice(heff_dup(v_s_241), MK_INT(2LL), heff_strLength_lent(v_s_241, 0));
      V v_t_246 = (g_prelude_2esplitFrom(((V)&g_std_2epath_2edriveOf_str3), heff_dup(v_s_245), MK_INT(0LL), heff_strFind(((V)&g_std_2epath_2edriveOf_str4), v_s_245, MK_INT(0LL)), NTAG(TAG_Nil)));
      HEFF_LAST return g_std_2epath_2edriveOf_2eunc_240(v_s_241, v_t_246);
    } else {
      heff_drop(v_t_244);
      if (heff_intLe_c(MK_INT(2LL), heff_strLength_lent(v_s_241, 0))) {
        V v_c_248 = heff_strByteAt_lent(v_s_241, MK_INT(0LL), 2);
        V v_t_2413 = heff_bool((heff_intLe_c(MK_INT(65LL), heff_dup(v_c_248)) ? (heff_intLe_c(heff_dup(v_c_248), MK_INT(90LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_248)) && heff_intLe_c(heff_dup(v_c_248), MK_INT(122LL)))) : (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_248)) && heff_intLe_c(heff_dup(v_c_248), MK_INT(122LL)))));
        heff_drop(v_c_248);
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          if (heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(1LL), MK_INT(2LL), 6), ((V)&g_std_2epath_2edriveOf_str5))) {
            V v_t_2415 = heff_strSlice(heff_dup(v_s_241), MK_INT(2LL), heff_strLength_lent(v_s_241, 0));
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strSlice(v_s_241, MK_INT(0LL), MK_INT(2LL)), v_t_2415});
          } else {
            return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str6), v_s_241});
          }
        } else {
          heff_drop(v_t_2413);
          return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str7), v_s_241});
        }
      } else {
        return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str8), v_s_241});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2epath_2edriveOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2edriveOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2eparse_str0, 1, "\\");
HEFF_LIT(g_std_2epath_2eparse_str1, 1, "\\");
HEFF_LIT(g_std_2epath_2eparse_str2, 0, "");
HEFF_LIT(g_std_2epath_2eparse_str3, 1, "/");
HEFF_LIT(g_std_2epath_2eparse_str4, 1, "/");
HEFF_LIT(g_std_2epath_2eparse_str5, 2, "//");
HEFF_LIT(g_std_2epath_2eparse_str6, 1, "/");
HEFF_LIT(g_std_2epath_2eparse_str7, 1, "/");
Clo g_std_2epath_2eparse_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eparse_entry, 2, 0};

V g_std_2epath_2eparse(V v_st_240, V v_s_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_Posix: {
    v_t_245 = v_s_241;
    break;
  }
  case TAG_Windows: {
    V v_x2_242 = (g_prelude_2esplitFrom(((V)&g_std_2epath_2eparse_str0), heff_dup(v_s_241), MK_INT(0LL), heff_strFind(((V)&g_std_2epath_2eparse_str1), v_s_241, MK_INT(0LL)), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_std_2epath_2eparse_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_std_2epath_2eparse_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_t_246 = (g_std_2epath_2edriveOf(v_st_240, v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkPair: {
    V v_d_247 = heff_field(v_t_246, 0);
    V v_rest_248 = heff_field(v_t_246, 1);
    heff_take_n(v_t_246, 3ULL, 2);
    V v_t_2410 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_rest_248, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2epath_2eparse_str4)) || heff_strEq_c(heff_strSlice_lent(v_d_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2epath_2eparse_str5))));
    V v_t_2411 = (g_prelude_2esplitFrom(((V)&g_std_2epath_2eparse_str6), heff_dup(v_rest_248), MK_INT(0LL), heff_strFind(((V)&g_std_2epath_2eparse_str7), v_rest_248, MK_INT(0LL)), NTAG(TAG_Nil)));
    V v_t_2412 = (g_list_2efilter(((V)&g_std_2epath_2eparse_2ekeep_240_clo), v_t_2411));
    return heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_d_247, v_t_2410, v_t_2412});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_std_2epath_2eparse_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2eparse(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2erender_str0, 0, "");
HEFF_LIT(g_std_2epath_2erender_str1, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str2, 0, "");
HEFF_LIT(g_std_2epath_2erender_str3, 0, "");
HEFF_LIT(g_std_2epath_2erender_str4, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str5, 1, ".");
HEFF_LIT(g_std_2epath_2erender_str6, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str7, 0, "");
HEFF_LIT(g_std_2epath_2erender_str8, 0, "");
HEFF_LIT(g_std_2epath_2erender_str9, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str10, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str11, 0, "");
HEFF_LIT(g_std_2epath_2erender_str12, 0, "");
HEFF_LIT(g_std_2epath_2erender_str13, 1, "/");
Clo g_std_2epath_2erender_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erender_entry, 2, 0};

V g_std_2epath_2erender(V v_st_240, V v_p_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_p_241, 0)), ((V)&g_std_2epath_2erender_str0))) {
    V v_t_243 = heff_dup(heff_rfield(v_p_241, 1));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = heff_take_field(v_p_241, 1);
      V v_t_245;
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        v_t_245 = ((V)&g_std_2epath_2erender_str1);
      } else {
        heff_drop(v_t_244);
        v_t_245 = ((V)&g_std_2epath_2erender_str2);
      }
      V v_t_246 = heff_take_field(v_p_241, 2);
      V v_t_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_std_2epath_2erender_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_t_246, 0);
        V v_xs_248 = heff_field(v_t_246, 1);
        heff_take_n(v_t_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_std_2epath_2erender_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_2410 = heff_strAppend(heff_get_n(v_p_241, 0, 3), heff_strAppend(v_t_245, v_t_249));
      HEFF_LAST return g_std_2epath_2erender_2eslashesTo_240(v_st_240, v_t_2410);
    } else {
      heff_drop(v_t_243);
      V v_t_2411 = heff_dup(heff_rfield(v_p_241, 2));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nil: {
        heff_drop_rec(v_p_241, 3);
        return ((V)&g_std_2epath_2erender_str5);
      }
      case TAG_Cons: {
        heff_take_n(v_t_2411, 0ULL, 2);
        V v_t_2414 = heff_take_field(v_p_241, 1);
        V v_t_2415;
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = ((V)&g_std_2epath_2erender_str6);
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = ((V)&g_std_2epath_2erender_str7);
        }
        V v_t_2416 = heff_take_field(v_p_241, 2);
        V v_t_2419;
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Nil: {
          v_t_2419 = ((V)&g_std_2epath_2erender_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2417 = heff_field(v_t_2416, 0);
          V v_xs_2418 = heff_field(v_t_2416, 1);
          heff_take_n(v_t_2416, 3ULL, 2);
          v_t_2419 = ({ V a_0 = ((V)&g_std_2epath_2erender_str9); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
          break;
        }
        default: heff_nomatch(v_t_2416);
        }
        V v_t_2420 = heff_strAppend(heff_get_n(v_p_241, 0, 3), heff_strAppend(v_t_2415, v_t_2419));
        HEFF_LAST return g_std_2epath_2erender_2eslashesTo_240(v_st_240, v_t_2420);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
  } else {
    V v_t_2421 = heff_take_field(v_p_241, 1);
    V v_t_2422;
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      v_t_2422 = ((V)&g_std_2epath_2erender_str10);
    } else {
      heff_drop(v_t_2421);
      v_t_2422 = ((V)&g_std_2epath_2erender_str11);
    }
    V v_t_2423 = heff_take_field(v_p_241, 2);
    V v_t_2426;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_std_2epath_2erender_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2424 = heff_field(v_t_2423, 0);
      V v_xs_2425 = heff_field(v_t_2423, 1);
      heff_take_n(v_t_2423, 3ULL, 2);
      v_t_2426 = ({ V a_0 = ((V)&g_std_2epath_2erender_str13); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_t_2427 = heff_strAppend(heff_get_n(v_p_241, 0, 3), heff_strAppend(v_t_2422, v_t_2426));
    HEFF_LAST return g_std_2epath_2erender_2eslashesTo_240(v_st_240, v_t_2427);
  }
}
V g_std_2epath_2erender_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2erender(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2enormalize_str0, 2, "..");
HEFF_LIT(g_std_2epath_2enormalize_str1, 2, "..");
HEFF_LIT(g_std_2epath_2enormalize_str2, 2, "..");
HEFF_LIT(g_std_2epath_2enormalize_str3, 2, "..");
Clo g_std_2epath_2enormalize_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2enormalize_entry, 2, 0};

V g_std_2epath_2enormalize(V v_st_240, V v_s_241) {
top: ;
  V v_p_242 = (g_std_2epath_2eparse(v_st_240, v_s_241));
  V v_xs_243 = (g_list_2efoldl_24s1725521117x1379101383(((V)&g_std_2epath_2enormalize_str0), heff_dup(v_p_242), ((V)&g_std_2epath_2enormalize_str1), ((V)&g_std_2epath_2enormalize_str2), ((V)&g_std_2epath_2enormalize_str3), NTAG(TAG_Nil), heff_dup(heff_rfield(v_p_242, 2))));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
  V v_t_245 = ({ V rv_2 = v_t_244; V rr_ = heff_rec_reuse_nf(v_p_242, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_245);
}
V g_std_2epath_2enormalize_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2enormalize(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2ejoin_str0, 2, "..");
HEFF_LIT(g_std_2epath_2ejoin_str1, 2, "..");
HEFF_LIT(g_std_2epath_2ejoin_str2, 2, "..");
HEFF_LIT(g_std_2epath_2ejoin_str3, 2, "..");
Clo g_std_2epath_2ejoin_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ejoin_entry, 3, 0};

V g_std_2epath_2ejoin(V v_st_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, v_a_241));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_b_242));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s1725521117x1379101383(((V)&g_std_2epath_2ejoin_str0), heff_dup(v_p_245), ((V)&g_std_2epath_2ejoin_str1), ((V)&g_std_2epath_2ejoin_str2), ((V)&g_std_2epath_2ejoin_str3), NTAG(TAG_Nil), heff_dup(heff_rfield(v_p_245, 2))));
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_nf(v_p_245, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_std_2epath_2erender(v_st_240, v_t_248));
}
V g_std_2epath_2ejoin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2ejoin(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2esameDrive_str0, 0, "");
HEFF_LIT(g_std_2epath_2esameDrive_str1, 0, "");
HEFF_LIT(g_std_2epath_2esameDrive_str2, 0, "");
HEFF_LIT(g_std_2epath_2esameDrive_str3, 0, "");
Clo g_std_2epath_2esameDrive_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2esameDrive_entry, 3, 0};

V g_std_2epath_2esameDrive(V v_x1_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Posix: {
    return heff_strEq(v_a_241, v_b_242);
  }
  case TAG_Windows: {
    V v_x2_243 = (g_list_2emap_24f2056124927x822823214(heff_dup(v_a_241), MK_INT(0LL), heff_strLength(v_a_241)));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_std_2epath_2esameDrive_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = ((V)&g_std_2epath_2esameDrive_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_x2_247 = (g_list_2emap_24f2056124927x822823214(heff_dup(v_b_242), MK_INT(0LL), heff_strLength(v_b_242)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_std_2epath_2esameDrive_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_std_2epath_2esameDrive_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strEq(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2epath_2esameDrive_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2esameDrive(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_std_2epath_2eunshared_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eunshared_entry, 3, 0};

V g_std_2epath_2eunshared(V v_st_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_xs_241, v_ys_242});
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_xs_241, v_ys_242});
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = (g_std_2epath_2esameDrive(v_st_240, heff_dup(v_x_243), heff_dup(v_y_245)));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_x_243);
        heff_drop(v_y_245);
        heff_drop_cell(v_ru_24ys_242_24Cons, 2);
        heff_drop(v_t_247);
        V t_0 = v_st_240;
        V t_1 = v_xs2_244;
        V t_2 = v_ys2_246;
        v_st_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_247);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ys_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246})});
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_std_2epath_2eunshared_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2eunshared(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2erelative_str0, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_str1, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_str2, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_str3, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_str4, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_str5, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_str6, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_str7, 2, "..");
Clo g_std_2epath_2erelative_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erelative_entry, 3, 0};

V g_std_2epath_2erelative(V v_st_240, V v_from_241, V v_to_242) {
top: ;
  V v_p_243 = (g_std_2epath_2eparse(v_st_240, v_from_241));
  V v_xs_244 = (g_list_2efoldl_24s1725521117x1379101383(((V)&g_std_2epath_2erelative_str0), heff_dup(v_p_243), ((V)&g_std_2epath_2erelative_str1), ((V)&g_std_2epath_2erelative_str2), ((V)&g_std_2epath_2erelative_str3), NTAG(TAG_Nil), heff_dup(heff_rfield(v_p_243, 2))));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_p_243, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_p_247 = (g_std_2epath_2eparse(v_st_240, v_to_242));
  V v_xs_248 = (g_list_2efoldl_24s1725521117x1379101383(((V)&g_std_2epath_2erelative_str4), heff_dup(v_p_247), ((V)&g_std_2epath_2erelative_str5), ((V)&g_std_2epath_2erelative_str6), ((V)&g_std_2epath_2erelative_str7), NTAG(TAG_Nil), heff_dup(heff_rfield(v_p_247, 2))));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = ({ V rv_2 = v_t_249; V rr_ = heff_rec_reuse_nf(v_p_247, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  HEFF_LAST return g_std_2epath_2erelative_2ego_240(v_st_240, v_t_246, v_t_2410);
}
V g_std_2epath_2erelative_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2erelative(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2eisUnder_str0, 2, "..");
HEFF_LIT(g_std_2epath_2eisUnder_str1, 1, "/");
HEFF_LIT(g_std_2epath_2eisUnder_str2, 1, "\\");
HEFF_LIT(g_std_2epath_2eisUnder_str3, 2, "..");
Clo g_std_2epath_2eisUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eisUnder_entry, 3, 0};

V g_std_2epath_2eisUnder(V v_st_240, V v_dir_241, V v_s_242) {
top: ;
  V v_t_243 = (g_std_2epath_2erelative(v_st_240, v_dir_241, v_s_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_r_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    if (heff_strEq_c_lent(v_r_244, ((V)&g_std_2epath_2eisUnder_str0), 2)) {
      heff_drop(v_r_244);
      return NTAG(TAG_False);
    } else {
      V v_t_246;
      switch (heff_tag_of(v_st_240)) {
      case TAG_Posix: {
        v_t_246 = ((V)&g_std_2epath_2eisUnder_str1);
        break;
      }
      case TAG_Windows: {
        v_t_246 = ((V)&g_std_2epath_2eisUnder_str2);
        break;
      }
      default: heff_nomatch(v_st_240);
      }
      V v_prefix_247 = heff_strAppend(((V)&g_std_2epath_2eisUnder_str3), v_t_246);
      V v_t_248 = heff_strSlice(v_r_244, MK_INT(0LL), heff_strLength_lent(v_prefix_247, 0));
      V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_t_248, v_prefix_247, 0));
      heff_drop(v_prefix_247);
      heff_drop(v_t_248);
      return v_ret_24bool;
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2epath_2eisUnder_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2eisUnder(a0, a[1], a[2]); heff_drop(a0); return r;
}