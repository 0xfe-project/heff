// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_MkPath 49630
#define TAG_Posix 44191
#define TAG_Windows 49101
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2ekeepIf_24s85961498x283047001(V);
V g_list_2ekeepIf_24s85961498x283047001_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s85961498x283047001_clo;
V g_list_2emap_24f201346761x152404242(V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670(V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecurrent_get(void);
HeffT2 g_std_2epath_2edriveOf_24cpr(V, V);
HeffT2 g_std_2epath_2edriveOf_2eunc_240_24cpr(V, V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2enormal(V);
V g_std_2epath_2enormal_entry(V self, V *a);
extern Clo g_std_2epath_2enormal_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT2 g_std_2epath_2erelative_24cpr(V, V, V);
HeffT2 g_std_2epath_2erelativeNormal_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameDrive(V, V, V);
V g_std_2epath_2esameDrive_entry(V self, V *a);
extern Clo g_std_2epath_2esameDrive_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
HeffT2 g_std_2epath_2eunshared_24cpr(V, V, V);

static V g_std_2epath_2enative_val;
static HEFF_ONCE g_std_2epath_2enative_st;
static V g_std_2epath_2enative_init(void) {
  V v_t_240 = heff_onWindows(NTAG(TAG_MkUnit));
  if ((heff_dup(v_t_240) == NTAG(TAG_True))) {
    heff_drop(v_t_240);
    return NTAG(TAG_Windows);
  } else {
    heff_drop(v_t_240);
    return NTAG(TAG_Posix);
  }
}
V g_std_2epath_2enative_get(void) {
  if (HEFF_DONE(g_std_2epath_2enative_st)) return g_std_2epath_2enative_val;
  return heff_global(&g_std_2epath_2enative_val, &g_std_2epath_2enative_st, g_std_2epath_2enative_init);
}
HEFF_LIT(g_std_2epath_2edriveOf_24cpr_str0, 0, "");
HEFF_LIT(g_std_2epath_2edriveOf_24cpr_str1, 2, "//");
HEFF_LIT(g_std_2epath_2edriveOf_24cpr_str2, 3, "///");
HEFF_LIT(g_std_2epath_2edriveOf_24cpr_str3, 1, "/");
HEFF_LIT(g_std_2epath_2edriveOf_24cpr_str4, 1, "/");
HEFF_LIT(g_std_2epath_2edriveOf_24cpr_str5, 1, ":");
HEFF_LIT(g_std_2epath_2edriveOf_24cpr_str6, 0, "");

HeffT2 g_std_2epath_2edriveOf_24cpr(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Posix: {
    return ((HeffT2){{((V)&g_std_2epath_2edriveOf_24cpr_str0), v_s_241}});
  }
  case TAG_Windows: {
    if ((heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2epath_2edriveOf_24cpr_str1)) && !heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_std_2epath_2edriveOf_24cpr_str2)))) {
      V v_s_242 = heff_strSlice(heff_dup(v_s_241), MK_INT(2LL), heff_strLength_lent(v_s_241, 0));
      V v_t_243 = ({ V b_0 = ((V)&g_std_2epath_2edriveOf_24cpr_str3); V a_1 = v_s_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2epath_2edriveOf_24cpr_str4), v_s_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_242); r_; });
      HEFF_LAST return g_std_2epath_2edriveOf_2eunc_240_24cpr(v_s_241, v_t_243);
    } else {
      if (((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_s_241, 0))) && ({ V v_c_244 = heff_strByteAt_lent(v_s_241, MK_INT(0LL), 2); int c_ = ((((((int64_t)65ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)122ULL)))) && heff_strEq_c(heff_strSlice_lent(v_s_241, MK_INT(1LL), MK_INT(2LL), 6), ((V)&g_std_2epath_2edriveOf_24cpr_str5))); heff_drop(v_c_244); c_; }))) {
        V v_f_245 = heff_strSlice_lent(v_s_241, MK_INT(0LL), MK_INT(2LL), 6);
        V v_f_246 = heff_strSlice(heff_dup(v_s_241), MK_INT(2LL), heff_strLength(v_s_241));
        return ((HeffT2){{v_f_245, v_f_246}});
      } else {
        return ((HeffT2){{((V)&g_std_2epath_2edriveOf_24cpr_str6), v_s_241}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_std_2epath_2eparse_24cpr_str0, 1, "\\");
HEFF_LIT(g_std_2epath_2eparse_24cpr_str1, 1, "\\");
HEFF_LIT(g_std_2epath_2eparse_24cpr_str2, 0, "");
HEFF_LIT(g_std_2epath_2eparse_24cpr_str3, 1, "/");
HEFF_LIT(g_std_2epath_2eparse_24cpr_str4, 1, "/");
HEFF_LIT(g_std_2epath_2eparse_24cpr_str5, 2, "//");
HEFF_LIT(g_std_2epath_2eparse_24cpr_str6, 1, "/");
HEFF_LIT(g_std_2epath_2eparse_24cpr_str7, 1, "/");

HeffT3 g_std_2epath_2eparse_24cpr(V v_os_240, V v_s_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Posix: {
    v_t_245 = v_s_241;
    break;
  }
  case TAG_Windows: {
    V v_x2_242 = ({ V b_0 = ((V)&g_std_2epath_2eparse_24cpr_str0); V a_1 = v_s_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2epath_2eparse_24cpr_str1), v_s_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_241); r_; });
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_std_2epath_2eparse_24cpr_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_std_2epath_2eparse_24cpr_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    break;
  }
  default: heff_nomatch(v_os_240);
  }
  HeffT2 v_t_246 = (g_std_2epath_2edriveOf_24cpr(v_os_240, v_t_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_d_249 = v_field_247;
    V v_rest_2410 = v_field_248;
    V v_f_2411 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_rest_2410, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2epath_2eparse_24cpr_str4)) || heff_strEq_c(heff_strSlice_lent(v_d_249, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2epath_2eparse_24cpr_str5))));
    V v_t_2412 = ({ V b_0 = ((V)&g_std_2epath_2eparse_24cpr_str6); V a_1 = v_rest_2410; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2epath_2eparse_24cpr_str7), v_rest_2410, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_rest_2410); r_; });
    V v_f_2413 = (g_list_2ekeepIf_24s85961498x283047001(v_t_2412));
    return ((HeffT3){{v_d_249, v_f_2411, v_f_2413}});
  }
}
Clo g_std_2epath_2eparse_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eparse_entry, 2, 0};

V g_std_2epath_2eparse(V v_os_240, V v_s_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(v_os_240, v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    return heff_tag_n(TAG_MkPath, 3, (V[]){v_field_243, v_field_244, v_field_245});
  }
}
V g_std_2epath_2eparse_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2eparse(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2epath_2erender_str0, 0, "");
HEFF_LIT(g_std_2epath_2erender_str1, 1, ".");
HEFF_LIT(g_std_2epath_2erender_str2, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str3, 0, "");
HEFF_LIT(g_std_2epath_2erender_str4, 0, "");
HEFF_LIT(g_std_2epath_2erender_str5, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str6, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str7, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str8, 0, "");
HEFF_LIT(g_std_2epath_2erender_str9, 1, "/");
HEFF_LIT(g_std_2epath_2erender_str10, 1, "\\");
Clo g_std_2epath_2erender_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erender_entry, 2, 0};

V g_std_2epath_2erender(V v_os_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_MkPath: {
    V v_d_242 = heff_field(v_x1_241, 0);
    V v_a_243 = heff_field(v_x1_241, 1);
    V v_xs_244 = heff_field(v_x1_241, 2);
    V v_t_247;
    if (heff_strEq_c_lent(v_d_242, ((V)&g_std_2epath_2erender_str0), 2)) {
      if (!(heff_dup(v_a_243) == NTAG(TAG_True))) {
        switch (heff_tag_of(v_xs_244)) {
        case TAG_Nil: {
          v_t_247 = NTAG(TAG_True);
          break;
        }
        case TAG_Cons: {
          v_t_247 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_xs_244);
        }
      } else {
        v_t_247 = NTAG(TAG_False);
      }
    } else {
      v_t_247 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      return ((V)&g_std_2epath_2erender_str1);
    } else {
      heff_drop(v_t_247);
      V v_t_248;
      if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
        v_t_248 = ((V)&g_std_2epath_2erender_str2);
      } else {
        v_t_248 = ((V)&g_std_2epath_2erender_str3);
      }
      V v_t_2411;
      switch (heff_tag_of(v_xs_244)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_std_2epath_2erender_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_xs_244, 0);
        V v_xs_2410 = heff_field(v_xs_244, 1);
        v_t_2411 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_std_2epath_2erender_str5), heff_dup(v_x_249), v_xs_2410));
        break;
      }
      default: heff_nomatch(v_xs_244);
      }
      V v_s_2412 = heff_strAppend(heff_dup(v_d_242), heff_strAppend(v_t_248, v_t_2411));
      V v_x2_2413 = ({ V b_0 = ((V)&g_std_2epath_2erender_str6); V a_1 = v_s_2412; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2epath_2erender_str7), v_s_2412, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2412); r_; });
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nil: {
        return ((V)&g_std_2epath_2erender_str8);
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_xs_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        V v_t_2416;
        switch (heff_tag_of(v_os_240)) {
        case TAG_Posix: {
          v_t_2416 = ((V)&g_std_2epath_2erender_str9);
          break;
        }
        case TAG_Windows: {
          v_t_2416 = ((V)&g_std_2epath_2erender_str10);
          break;
        }
        default: heff_nomatch(v_os_240);
        }
        return ({ V a_0 = v_t_2416; V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_std_2epath_2erender_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2epath_2erender(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_std_2epath_2esameSegments_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2esameSegments_entry, 2, 0};

V g_std_2epath_2esameSegments(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2epath_2esameSegments_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2epath_2esameSegments(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2epath_2ecurrent_str0, 0, "");

static V g_std_2epath_2ecurrent_val;
static HEFF_ONCE g_std_2epath_2ecurrent_st;
static V g_std_2epath_2ecurrent_init(void) {
  return heff_tag_n(TAG_MkPath, 3, (V[]){((V)&g_std_2epath_2ecurrent_str0), NTAG(TAG_False), NTAG(TAG_Nil)});
}
V g_std_2epath_2ecurrent_get(void) {
  if (HEFF_DONE(g_std_2epath_2ecurrent_st)) return g_std_2epath_2ecurrent_val;
  return heff_global(&g_std_2epath_2ecurrent_val, &g_std_2epath_2ecurrent_st, g_std_2epath_2ecurrent_init);
}
HEFF_LIT(g_std_2epath_2enormal_str0, 2, "..");
HEFF_LIT(g_std_2epath_2enormal_str1, 2, "..");
HEFF_LIT(g_std_2epath_2enormal_str2, 2, "..");
HEFF_LIT(g_std_2epath_2enormal_str3, 2, "..");
Clo g_std_2epath_2enormal_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2enormal_entry, 1, 0};

V g_std_2epath_2enormal(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPath: {
    V v_d_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_xs_243 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24MkPath = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_xs_244 = ({ V b_0 = ((V)&g_std_2epath_2enormal_str0); V a_1 = v_a_242; V a_2 = ((V)&g_std_2epath_2enormal_str1); V b_3 = ((V)&g_std_2epath_2enormal_str2); V a_4 = ((V)&g_std_2epath_2enormal_str3); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_243; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
    return heff_tag_at_n(v_ru_24x1_240_24MkPath, TAG_MkPath, 3, (V[]){v_d_241, v_a_242, v_t_245});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2epath_2enormal_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2enormal(a[0]);
}
HEFF_LIT(g_std_2epath_2ejoin_str0, 0, "");
Clo g_std_2epath_2ejoin_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ejoin_entry, 2, 0};

V g_std_2epath_2ejoin(V v_a_240, V v_b_241) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_a_240)) {
  case TAG_MkPath: {
    V v_d_242 = heff_field(v_a_240, 0);
    V v_a_243 = heff_field(v_a_240, 1);
    V v_xs_244 = heff_field(v_a_240, 2);
    V v_ru_24a_240_24MkPath = heff_take_reuse_n(v_a_240, 7ULL, 3);
    switch (heff_tag_of(v_b_241)) {
    case TAG_MkPath: {
      V v_e_245 = heff_field(v_b_241, 0);
      V v_b_246 = heff_field(v_b_241, 1);
      V v_ys_247 = heff_field(v_b_241, 2);
      heff_take_n(v_b_241, 7ULL, 3);
      if (!heff_strEq_c_lent(v_e_245, ((V)&g_std_2epath_2ejoin_str0), 2)) {
        heff_drop(v_d_242);
        heff_drop(v_a_243);
        heff_drop(v_xs_244);
        v_t_249 = heff_tag_at_n(v_ru_24a_240_24MkPath, TAG_MkPath, 3, (V[]){v_e_245, v_b_246, v_ys_247});
      } else {
        heff_drop(v_e_245);
        if ((heff_dup(v_b_246) == NTAG(TAG_True))) {
          heff_drop(v_a_243);
          heff_drop(v_xs_244);
          heff_drop(v_b_246);
          v_t_249 = heff_tag_at_n(v_ru_24a_240_24MkPath, TAG_MkPath, 3, (V[]){v_d_242, NTAG(TAG_True), v_ys_247});
        } else {
          heff_drop(v_b_246);
          V v_t_248 = (g_prelude_2e_2b_2b(v_xs_244, v_ys_247));
          v_t_249 = heff_tag_at_n(v_ru_24a_240_24MkPath, TAG_MkPath, 3, (V[]){v_d_242, v_a_243, v_t_248});
        }
      }
      break;
    }
    default: heff_nomatch(v_b_241);
    }
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  return (g_std_2epath_2enormal(v_t_249));
}
V g_std_2epath_2ejoin_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2ejoin(a[0], a[1]);
}
HEFF_LIT(g_std_2epath_2esameDrive_str0, 0, "");
HEFF_LIT(g_std_2epath_2esameDrive_str1, 0, "");
HEFF_LIT(g_std_2epath_2esameDrive_str2, 0, "");
HEFF_LIT(g_std_2epath_2esameDrive_str3, 0, "");
Clo g_std_2epath_2esameDrive_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2esameDrive_entry, 3, 0};

V g_std_2epath_2esameDrive(V v_x1_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Posix: {
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_a_241, v_b_242, 0));
    return v_ret_24bool;
  }
  case TAG_Windows: {
    V v_x2_243 = (g_list_2emap_24f201346761x152404242(MK_INT(65LL), v_a_241, MK_INT(90LL), MK_INT(32LL), MK_INT(1LL), MK_INT(0LL), heff_strLength_lent(v_a_241, 0)));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_std_2epath_2esameDrive_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = ((V)&g_std_2epath_2esameDrive_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_x2_247 = (g_list_2emap_24f201346761x152404242(MK_INT(65LL), v_b_242, MK_INT(90LL), MK_INT(32LL), MK_INT(1LL), MK_INT(0LL), heff_strLength_lent(v_b_242, 0)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_std_2epath_2esameDrive_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_std_2epath_2esameDrive_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_246, v_t_2410, 0));
    heff_drop(v_t_246);
    heff_drop(v_t_2410);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2epath_2esameDrive_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_std_2epath_2esameDrive(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_std_2epath_2eunshared_24cpr(V v_st_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_x2_241, v_x3_242}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_241, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      return ((HeffT2){{v_x2_241, v_x3_242}});
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      V v_t_247 = (g_std_2epath_2esameDrive(v_st_240, v_x_243, v_y_245));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_x_243);
        heff_drop(v_y_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_247);
        V t_0 = v_st_240;
        V t_1 = v_xs_244;
        V t_2 = v_ys_246;
        v_st_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_247);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_std_2epath_2erelativeNormal_24cpr_str0, 2, "..");
HEFF_LIT(g_std_2epath_2erelativeNormal_24cpr_str1, 2, "..");
HEFF_LIT(g_std_2epath_2erelativeNormal_24cpr_str2, 0, "");

HeffT2 g_std_2epath_2erelativeNormal_24cpr(V v_st_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPath: {
    V v_d_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    V v_xs_245 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24MkPath = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_MkPath: {
      V v_e_246 = heff_field(v_x3_242, 0);
      V v_b_247 = heff_field(v_x3_242, 1);
      V v_ys_248 = heff_field(v_x3_242, 2);
      heff_take_n(v_x3_242, 7ULL, 3);
      V v_x1_249 = ({ V a_0 = v_st_240; V a_1 = v_d_243; V a_2 = v_e_246; V r_ = (g_std_2epath_2esameDrive(a_0, a_1, a_2)); heff_drop(v_d_243); heff_drop(v_e_246); r_; });
      V v_t_2410 = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
      heff_drop(v_x1_249);
      if (((heff_dup(v_t_2410) == NTAG(TAG_True)) || ((heff_dup(v_a_244) == NTAG(TAG_True)) ? !(heff_dup(v_b_247) == NTAG(TAG_True)) : (heff_dup(v_b_247) == NTAG(TAG_True))))) {
        heff_drop(v_a_244);
        heff_drop(v_xs_245);
        heff_drop_cell(v_ru_24x2_241_24MkPath, 3);
        heff_drop(v_b_247);
        heff_drop(v_ys_248);
        heff_drop(v_t_2410);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_a_244);
        heff_drop(v_b_247);
        heff_drop(v_t_2410);
        HeffT2 v_t_2411 = (g_std_2epath_2eunshared_24cpr(v_st_240, v_xs_245, v_ys_248));
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_up_2414 = v_field_2412;
          V v_down_2415 = v_field_2413;
          V v_t_2416 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){((V)&g_std_2epath_2erelativeNormal_24cpr_str0)}));
          V v_t_2417 = (g_list_2eany(v_t_2416, v_up_2414));
          if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x2_241_24MkPath, 3);
            heff_drop(v_up_2414);
            heff_drop(v_down_2415);
            heff_drop(v_t_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            heff_drop(v_t_2417);
            V v_t_2418 = (g_prelude_2e_2b_2b_24f227594336x1851497670(v_down_2415, ((V)&g_std_2epath_2erelativeNormal_24cpr_str1), v_up_2414));
            V v_f_2419 = heff_tag_at_n(v_ru_24x2_241_24MkPath, TAG_MkPath, 3, (V[]){((V)&g_std_2epath_2erelativeNormal_24cpr_str2), NTAG(TAG_False), v_t_2418});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_std_2epath_2erelative_24cpr_str0, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_24cpr_str1, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_24cpr_str2, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_24cpr_str3, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_24cpr_str4, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_24cpr_str5, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_24cpr_str6, 2, "..");
HEFF_LIT(g_std_2epath_2erelative_24cpr_str7, 2, "..");

HeffT2 g_std_2epath_2erelative_24cpr(V v_os_240, V v_from_241, V v_to_242) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_from_241)) {
  case TAG_MkPath: {
    V v_d_243 = heff_field(v_from_241, 0);
    V v_a_244 = heff_field(v_from_241, 1);
    V v_xs_245 = heff_field(v_from_241, 2);
    V v_ru_24from_241_24MkPath = heff_take_reuse_n(v_from_241, 7ULL, 3);
    V v_xs_246 = ({ V b_0 = ((V)&g_std_2epath_2erelative_24cpr_str0); V a_1 = v_a_244; V a_2 = ((V)&g_std_2epath_2erelative_24cpr_str1); V b_3 = ((V)&g_std_2epath_2erelative_24cpr_str2); V a_4 = ((V)&g_std_2epath_2erelative_24cpr_str3); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_245; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
    v_t_248 = heff_tag_at_n(v_ru_24from_241_24MkPath, TAG_MkPath, 3, (V[]){v_d_243, v_a_244, v_t_247});
    break;
  }
  default: heff_nomatch(v_from_241);
  }
  V v_t_2414;
  switch (heff_tag_of(v_to_242)) {
  case TAG_MkPath: {
    V v_d_249 = heff_field(v_to_242, 0);
    V v_a_2410 = heff_field(v_to_242, 1);
    V v_xs_2411 = heff_field(v_to_242, 2);
    V v_ru_24to_242_24MkPath = heff_take_reuse_n(v_to_242, 7ULL, 3);
    V v_xs_2412 = ({ V b_0 = ((V)&g_std_2epath_2erelative_24cpr_str4); V a_1 = v_a_2410; V a_2 = ((V)&g_std_2epath_2erelative_24cpr_str5); V b_3 = ((V)&g_std_2epath_2erelative_24cpr_str6); V a_4 = ((V)&g_std_2epath_2erelative_24cpr_str7); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2411; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
    v_t_2414 = heff_tag_at_n(v_ru_24to_242_24MkPath, TAG_MkPath, 3, (V[]){v_d_249, v_a_2410, v_t_2413});
    break;
  }
  default: heff_nomatch(v_to_242);
  }
  HEFF_LAST return g_std_2epath_2erelativeNormal_24cpr(v_os_240, v_t_248, v_t_2414);
}