// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Posix 44191
#define TAG_Windows 49101
#define LBL_absolute 325777132
#define LBL_drive 297211300
#define LBL_segments 1801007612
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
V g_prelude_2efilter(V, V);
V g_prelude_2efilter_entry(V self, V *a);
extern Clo g_prelude_2efilter_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2erange(V, V);
V g_prelude_2erange_entry(V self, V *a);
extern Clo g_prelude_2erange_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2ecollapse_2estep_240(V, V, V);
V g_std_2epath_2ecollapse_2estep_240_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_2estep_240_clo;
V g_std_2epath_2edriveOf(V, V);
V g_std_2epath_2edriveOf_entry(V self, V *a);
extern Clo g_std_2epath_2edriveOf_clo;
V g_std_2epath_2edriveOf_2eunc_240(V, V);
V g_std_2epath_2edriveOf_2eunc_240_entry(V self, V *a);
extern Clo g_std_2epath_2edriveOf_2eunc_240_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2elower_2elow_240(V, V);
V g_std_2epath_2elower_2elow_240_entry(V self, V *a);
extern Clo g_std_2epath_2elower_2elow_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2eparse_2ekeep_240(V);
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_2ekeep_240_clo;
V g_std_2epath_2erelative(V, V, V);
V g_std_2epath_2erelative_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_clo;
V g_std_2epath_2erelative_2ego_240(V, V, V);
V g_std_2epath_2erelative_2ego_240_entry(V self, V *a);
extern Clo g_std_2epath_2erelative_2ego_240_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2erender_2eslashesTo_240(V, V);
V g_std_2epath_2erender_2eslashesTo_240_entry(V self, V *a);
extern Clo g_std_2epath_2erender_2eslashesTo_240_clo;
V g_std_2epath_2esameDrive(V, V, V);
V g_std_2epath_2esameDrive_entry(V self, V *a);
extern Clo g_std_2epath_2esameDrive_clo;
V g_std_2epath_2eunshared(V, V, V);
V g_std_2epath_2eunshared_entry(V self, V *a);
extern Clo g_std_2epath_2eunshared_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2edriveOf_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2epath_2edriveOf_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {47, 47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2edriveOf_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2epath_2edriveOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2edriveOf_entry, 2, 0};

V g_std_2epath_2edriveOf(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Posix: {
    return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str0), v_s_241});
  }
  case TAG_Windows: {
    V v_t_242 = heff_strEq(heff_strSlice(heff_dup(v_s_241), MK_INT(0LL), MK_INT(2LL)), ((V)&g_std_2epath_2edriveOf_str1));
    V v_t_244;
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      V v_t_243 = heff_strEq(heff_strSlice(heff_dup(v_s_241), MK_INT(0LL), MK_INT(3LL)), ((V)&g_std_2epath_2edriveOf_str2));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        v_t_244 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_244 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      break;
    }
    case TAG_False: {
      v_t_244 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_t_245 = heff_strSlice(heff_dup(v_s_241), MK_INT(2LL), heff_strLength(heff_dup(v_s_241)));
      V v_t_246 = (g_prelude_2esplitFrom(((V)&g_std_2epath_2edriveOf_str3), v_t_245, MK_INT(0LL), NTAG(TAG_Nil)));
      HEFF_LAST return g_std_2epath_2edriveOf_2eunc_240(v_s_241, v_t_246);
    }
    case TAG_False: {
      V v_t_247 = heff_intLe(MK_INT(2LL), heff_strLength(heff_dup(v_s_241)));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_c_248 = heff_strCharCode(heff_dup(v_s_241), MK_INT(0LL));
        V v_t_249 = heff_intLe(MK_INT(65LL), heff_dup(v_c_248));
        V v_t_2413;
        switch (heff_tag_of(v_t_249)) {
        case TAG_True: {
          V v_t_2410 = heff_intLe(heff_dup(v_c_248), MK_INT(90LL));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_True: {
            heff_drop(v_c_248);
            v_t_2413 = NTAG(TAG_True);
            break;
          }
          case TAG_False: {
            V v_t_2411 = heff_intLe(MK_INT(97LL), heff_dup(v_c_248));
            switch (heff_tag_of(v_t_2411)) {
            case TAG_True: {
              v_t_2413 = heff_intLe(v_c_248, MK_INT(122LL));
              break;
            }
            case TAG_False: {
              heff_drop(v_c_248);
              v_t_2413 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_2411);
            }
            break;
          }
          default: heff_nomatch(v_t_2410);
          }
          break;
        }
        case TAG_False: {
          V v_t_2412 = heff_intLe(MK_INT(97LL), heff_dup(v_c_248));
          switch (heff_tag_of(v_t_2412)) {
          case TAG_True: {
            v_t_2413 = heff_intLe(v_c_248, MK_INT(122LL));
            break;
          }
          case TAG_False: {
            heff_drop(v_c_248);
            v_t_2413 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2412);
          }
          break;
        }
        default: heff_nomatch(v_t_249);
        }
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          V v_t_2414 = heff_strEq(heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), MK_INT(2LL)), ((V)&g_std_2epath_2edriveOf_str4));
          switch (heff_tag_of(v_t_2414)) {
          case TAG_True: {
            V v_t_2415 = heff_strSlice(heff_dup(v_s_241), MK_INT(2LL), heff_strLength(heff_dup(v_s_241)));
            return heff_tag(TAG_MkPair, 2, (V[]){heff_strSlice(v_s_241, MK_INT(0LL), MK_INT(2LL)), v_t_2415});
          }
          case TAG_False: {
            return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str5), v_s_241});
          }
          default: return heff_nomatch(v_t_2414);
          }
        }
        case TAG_False: {
          return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str6), v_s_241});
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      case TAG_False: {
        return heff_tag(TAG_MkPair, 2, (V[]){((V)&g_std_2epath_2edriveOf_str7), v_s_241});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2epath_2edriveOf_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2edriveOf(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2eparse_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {47, 47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_std_2epath_2eparse_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eparse_entry, 2, 0};

V g_std_2epath_2eparse(V v_st_240, V v_s_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_Posix: {
    v_t_245 = v_s_241;
    break;
  }
  case TAG_Windows: {
    V v_x2_242 = (g_prelude_2esplitFrom(((V)&g_std_2epath_2eparse_str0), v_s_241, MK_INT(0LL), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_std_2epath_2eparse_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_std_2epath_2eparse_str2); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_t_246 = (g_std_2epath_2edriveOf(v_st_240, v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkPair: {
    V v_d_247 = heff_field(v_t_246, 0);
    V v_rest_248 = heff_field(v_t_246, 1);
    heff_take_n(v_t_246, 3ULL, 2);
    V v_t_249 = heff_strEq(heff_strSlice(heff_dup(v_rest_248), MK_INT(0LL), MK_INT(1LL)), ((V)&g_std_2epath_2eparse_str3));
    V v_t_2410;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2410 = heff_strEq(heff_strSlice(heff_dup(v_d_247), MK_INT(0LL), MK_INT(2LL)), ((V)&g_std_2epath_2eparse_str4));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2411 = (g_prelude_2esplitFrom(((V)&g_std_2epath_2eparse_str5), v_rest_248, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2412 = (g_prelude_2efilter(((V)&g_std_2epath_2eparse_2ekeep_240_clo), v_t_2411));
    return heff_rec(3, shape_drive__absolute__segments, (V[]){v_d_247, v_t_2410, v_t_2412});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_std_2epath_2eparse_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2eparse(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2erender_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
Clo g_std_2epath_2erender_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erender_entry, 2, 0};

V g_std_2epath_2erender(V v_st_240, V v_p_241) {
top: ;
  V v_t_242 = heff_strEq(heff_get(heff_dup(v_p_241), LBL_drive), ((V)&g_std_2epath_2erender_str0));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_get(heff_dup(v_p_241), LBL_absolute);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_get(heff_dup(v_p_241), LBL_absolute);
      V v_t_245;
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        v_t_245 = ((V)&g_std_2epath_2erender_str1);
        break;
      }
      case TAG_False: {
        v_t_245 = ((V)&g_std_2epath_2erender_str2);
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      V v_t_246 = heff_get(heff_dup(v_p_241), LBL_segments);
      V v_t_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_std_2epath_2erender_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_t_246, 0);
        V v_xs_248 = heff_field(v_t_246, 1);
        heff_take_n(v_t_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_std_2epath_2erender_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_2410 = heff_strAppend(heff_get(v_p_241, LBL_drive), heff_strAppend(v_t_245, v_t_249));
      HEFF_LAST return g_std_2epath_2erender_2eslashesTo_240(v_st_240, v_t_2410);
    }
    case TAG_False: {
      V v_t_2411 = heff_get(heff_dup(v_p_241), LBL_segments);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nil: {
        heff_drop(v_p_241);
        return ((V)&g_std_2epath_2erender_str5);
      }
      case TAG_Cons: {
        heff_take_n(v_t_2411, 0ULL, 2);
        V v_t_2414 = heff_get(heff_dup(v_p_241), LBL_absolute);
        V v_t_2415;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_True: {
          v_t_2415 = ((V)&g_std_2epath_2erender_str6);
          break;
        }
        case TAG_False: {
          v_t_2415 = ((V)&g_std_2epath_2erender_str7);
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
        V v_t_2416 = heff_get(heff_dup(v_p_241), LBL_segments);
        V v_t_2419;
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Nil: {
          v_t_2419 = ((V)&g_std_2epath_2erender_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2417 = heff_field(v_t_2416, 0);
          V v_xs_2418 = heff_field(v_t_2416, 1);
          heff_take_n(v_t_2416, 3ULL, 2);
          v_t_2419 = ({ V a_0 = ((V)&g_std_2epath_2erender_str9); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
          break;
        }
        default: heff_nomatch(v_t_2416);
        }
        V v_t_2420 = heff_strAppend(heff_get(v_p_241, LBL_drive), heff_strAppend(v_t_2415, v_t_2419));
        HEFF_LAST return g_std_2epath_2erender_2eslashesTo_240(v_st_240, v_t_2420);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    V v_t_2421 = heff_get(heff_dup(v_p_241), LBL_absolute);
    V v_t_2422;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      v_t_2422 = ((V)&g_std_2epath_2erender_str10);
      break;
    }
    case TAG_False: {
      v_t_2422 = ((V)&g_std_2epath_2erender_str11);
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    V v_t_2423 = heff_get(heff_dup(v_p_241), LBL_segments);
    V v_t_2426;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_std_2epath_2erender_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2424 = heff_field(v_t_2423, 0);
      V v_xs_2425 = heff_field(v_t_2423, 1);
      heff_take_n(v_t_2423, 3ULL, 2);
      v_t_2426 = ({ V a_0 = ((V)&g_std_2epath_2erender_str13); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_t_2427 = heff_strAppend(heff_get(v_p_241, LBL_drive), heff_strAppend(v_t_2422, v_t_2426));
    HEFF_LAST return g_std_2epath_2erender_2eslashesTo_240(v_st_240, v_t_2427);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2epath_2erender_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2erender(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_std_2epath_2ecollapse_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ecollapse_entry, 2, 0};

V g_std_2epath_2ecollapse(V v_absolute_240, V v_xs_241) {
top: ;
  V v_t_242 = heff_tr(heff_apply(((V)&g_std_2epath_2ecollapse_2estep_240_clo), 1, (V[]){v_absolute_240}));
  V v_xs_243 = (g_prelude_2efoldl(v_t_242, NTAG(TAG_Nil), v_xs_241));
  HEFF_LAST return g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_243);
}
V g_std_2epath_2ecollapse_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2ecollapse(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2esameDrive_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2esameDrive_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2esameDrive_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2esameDrive_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2epath_2esameDrive_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2esameDrive_entry, 3, 0};

V g_std_2epath_2esameDrive(V v_x1_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Posix: {
    return heff_strEq(v_a_241, v_b_242);
  }
  case TAG_Windows: {
    V v_t_243 = heff_tr(heff_apply(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_a_241)}));
    V v_t_244 = (g_prelude_2erange(MK_INT(0LL), heff_strLength(v_a_241)));
    V v_x2_245 = (g_prelude_2emap(v_t_243, v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_std_2epath_2esameDrive_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_std_2epath_2esameDrive_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_tr(heff_apply(((V)&g_std_2epath_2elower_2elow_240_clo), 1, (V[]){heff_dup(v_b_242)}));
    V v_t_2410 = (g_prelude_2erange(MK_INT(0LL), heff_strLength(v_b_242)));
    V v_x2_2411 = (g_prelude_2emap(v_t_249, v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_std_2epath_2esameDrive_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_std_2epath_2esameDrive_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    return heff_strEq(v_t_248, v_t_2414);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2epath_2esameDrive_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2esameDrive(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_std_2epath_2eunshared_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eunshared_entry, 3, 0};

V g_std_2epath_2eunshared(V v_st_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_xs_241, v_ys_242});
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_241, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      return heff_tag(TAG_MkPair, 2, (V[]){v_xs_241, v_ys_242});
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      V v_ru_24ys_242_24Cons = heff_take_reuse_n(v_ys_242, 3ULL, 2);
      heff_drop_tag(v_xs_241, 2);
      V v_t_247 = (g_std_2epath_2esameDrive(v_st_240, heff_dup(v_x_243), heff_dup(v_y_245)));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_x_243);
        heff_drop(v_y_245);
        heff_drop_cell(v_ru_24ys_242_24Cons, 2);
        V t_0 = v_st_240;
        V t_1 = v_xs2_244;
        V t_2 = v_ys2_246;
        v_st_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24ys_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244}), heff_tag(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246})});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_std_2epath_2eunshared_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2eunshared(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_std_2epath_2erelative_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2erelative_entry, 3, 0};

V g_std_2epath_2erelative(V v_st_240, V v_from_241, V v_to_242) {
top: ;
  V v_p_243 = (g_std_2epath_2eparse(v_st_240, v_from_241));
  V v_t_244 = ({ V a_0 = heff_get(heff_dup(v_p_243), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_243), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_245 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_243), LBL_drive), heff_get(v_p_243, LBL_absolute), v_t_244});
  V v_p_246 = (g_std_2epath_2eparse(v_st_240, v_to_242));
  V v_t_247 = ({ V a_0 = heff_get(heff_dup(v_p_246), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_246), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248 = heff_rec(3, shape_drive__absolute__segments, (V[]){heff_get(heff_dup(v_p_246), LBL_drive), heff_get(v_p_246, LBL_absolute), v_t_247});
  HEFF_LAST return g_std_2epath_2erelative_2ego_240(v_st_240, v_t_245, v_t_248);
}
V g_std_2epath_2erelative_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2erelative(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2eisUnder_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eisUnder_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eisUnder_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2eisUnder_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
Clo g_std_2epath_2eisUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eisUnder_entry, 3, 0};

V g_std_2epath_2eisUnder(V v_st_240, V v_dir_241, V v_s_242) {
top: ;
  V v_t_243 = (g_std_2epath_2erelative(v_st_240, v_dir_241, v_s_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_r_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_strEq(heff_dup(v_r_244), ((V)&g_std_2epath_2eisUnder_str0));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_r_244);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_t_246;
      switch (heff_tag_of(v_st_240)) {
      case TAG_Posix: {
        v_t_246 = ((V)&g_std_2epath_2eisUnder_str1);
        break;
      }
      case TAG_Windows: {
        v_t_246 = ((V)&g_std_2epath_2eisUnder_str2);
        break;
      }
      default: heff_nomatch(v_st_240);
      }
      V v_prefix_247 = heff_strAppend(((V)&g_std_2epath_2eisUnder_str3), v_t_246);
      V v_t_248 = heff_strSlice(v_r_244, MK_INT(0LL), heff_strLength(heff_dup(v_prefix_247)));
      V v_x1_249 = heff_strEq(v_t_248, v_prefix_247);
      switch (heff_tag_of(v_x1_249)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_249);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2epath_2eisUnder_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2eisUnder(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}