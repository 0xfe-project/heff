// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_packages 1496006433
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
HeffT5 g_list_2efoldl_24s571074576x1179600767_24cpr(V, V);
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0(V v_f_240, V v_hd_241, V v_k_242, V v_checkOnly_243, V v_x_244) {
top: ;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    V v_ru_24x_244_24Left = heff_take_reuse_n(v_x_244, 0ULL, 1);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_str0), v_f_240), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_str1));
    V v_t_247 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_at_n(v_ru_24x_244_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam0, 1, 1, (V[]){v_k_242})));
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 1);
    V v_c_2415 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
    return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam1, 1, 5, (V[]){v_f_240, v_hd_241, heff_dup(v_checkOnly_243), v_y_2414, v_k_242})});
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_drop(v_x_2413);
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_checkOnly_243 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_y_2414 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2418, heff_dup(heff_rfield(v_x_2417, 4))));
  heff_clo_take(self, 6);
  HeffT5 v_t_2420 = (g_list_2efoldl_24s571074576x1179600767_24cpr(v_x_2417, v_t_2419));
  {
    V v_field_2421 = v_t_2420.f[0];
    heff_drop(v_t_2420.f[1]);
    heff_drop(v_t_2420.f[2]);
    heff_drop(v_t_2420.f[3]);
    heff_drop(v_t_2420.f[4]);
    V v_t_2426 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), v_field_2421));
    return ({ V a_0 = v_checkOnly_243; V a_1 = v_f_240; V a_2 = v_y_2414; V a_3 = v_t_2426; V a_4 = v_hd_241; V a_5 = v_k_242; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_243); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_checkOnly_243 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_y_2414 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam3, 1, 6, (V[]){v_x_2417, v_checkOnly_243, v_f_240, v_y_2414, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_checkOnly_243 = heff_env(self)[2];
  V v_y_2414 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2416, heff_dup(v_f_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_lam2, 1, 5, (V[]){v_hd_241, v_checkOnly_243, v_f_240, v_y_2414, v_k_242})));
}