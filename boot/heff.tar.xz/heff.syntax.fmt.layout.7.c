// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_exposing 966605106
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks(V);
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eexposingToks_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(V);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
HeffT2 g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(V, V, V);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2egroup_24tok2(V, V);
V g_std_2edoc_2egroup_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_24tok2_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str111, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str113, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str115, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str116, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str117, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str118, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str119, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str120, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str122, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str123, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str125, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str126, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str127, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str128, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str129, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str131, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str132, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str133, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str135, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str136, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str137, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str138, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str140, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str141, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str142, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str143, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str144, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str145, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str146, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str147, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str148, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str149, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str150, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str151, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str152, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str153, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str154, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str155, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str156, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str157, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str158, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str159, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str160, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str161, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str162, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str163, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str164, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam126, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam127, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam128, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam129, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam131(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam132(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam130, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam133(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam133, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam134(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam134, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam135(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam135, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam136(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam136, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam129_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam130_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam133_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam134_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam135_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam136_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2444 = args[0];
  V v_e_2445 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2446 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2444));
  V v_one_2447 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2448 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2445));
  V v_b_2452;
  if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
    heff_drop(v_t_2448);
    V v_d_2449 = heff_tr(heff_call(v_one_2447, 1, (V[]){v_e_2445}));
    v_b_2452 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2449});
  } else {
    heff_drop(v_t_2448);
    V v_t_2450 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_2445));
    if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
      heff_drop(v_t_2450);
      V v_d_2451 = heff_tr(heff_call(v_one_2447, 1, (V[]){v_e_2445}));
      v_b_2452 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2451});
    } else {
      heff_drop(v_t_2450);
      v_b_2452 = heff_tr(heff_call(v_one_2447, 1, (V[]){v_e_2445}));
    }
  }
  V v_t_2453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2452));
  V v_t_2454 = (g_std_2edoc_2e_3c_3e(v_a_2446, v_t_2453));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2454));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2465 = args[0];
  V v_k_2464 = heff_env(self)[0];
  V v_d_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2466 = heff_intSub(v_k_2464, v_i_2465);
  if (heff_intEq_c_lent(v_i_2466, MK_INT(0LL), 2)) {
    heff_drop(v_i_2466);
    return v_d_2463;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2466, v_d_2463});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2464 = args[0];
  V v_d_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2464, v_d_2463})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2472 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2472));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2487 = args[0];
  V v_f_2488 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2489 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2487));
  V v_d_2490 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2488}));
  V v_t_2491 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2490})));
  V v_t_2492 = (g_std_2edoc_2e_3c_3e(v_a_2489, v_t_2491));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2492));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24101 = args[0];
  V v_k_24100 = heff_env(self)[0];
  V v_d_2499 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24102 = heff_intSub(v_k_24100, v_i_24101);
  if (heff_intEq_c_lent(v_i_24102, MK_INT(0LL), 2)) {
    heff_drop(v_i_24102);
    return v_d_2499;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24102, v_d_2499});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24100 = args[0];
  V v_d_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24100, v_d_2499})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24128 = args[0];
  V v_f_24129 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24130 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24128));
  V v_d_24131 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24129}));
  V v_t_24132 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24131})));
  V v_t_24133 = (g_std_2edoc_2e_3c_3e(v_a_24130, v_t_24132));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24133));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24144 = args[0];
  V v_k_24143 = heff_env(self)[0];
  V v_d_24142 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24145 = heff_intSub(v_k_24143, v_i_24144);
  if (heff_intEq_c_lent(v_i_24145, MK_INT(0LL), 2)) {
    heff_drop(v_i_24145);
    return v_d_24142;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24145, v_d_24142});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24143 = args[0];
  V v_d_24142 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24143, v_d_24142})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24201 = args[0];
  V v_a_24202 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24184 = heff_env(self)[1];
  V v_c_24187 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24203 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24184, 4, 9), heff_get_n(v_c_24187, 3, 9)));
  V v_t_24204;
  if ((heff_dup(v_x1_24203) == NTAG(TAG_True))) {
    heff_drop(v_x1_24203);
    v_t_24204 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24203);
    v_t_24204 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24205 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24201));
  V v_b_24206 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24202}));
  V v_t_24207 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24206));
  V v_t_24208 = (g_std_2edoc_2e_3c_3e(v_a_24205, v_t_24207));
  return (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24208));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24215 = args[0];
  V v_k_24214 = heff_env(self)[0];
  V v_d_24213 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24216 = heff_intSub(v_k_24214, v_i_24215);
  if (heff_intEq_c_lent(v_i_24216, MK_INT(0LL), 2)) {
    heff_drop(v_i_24216);
    return v_d_24213;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24216, v_d_24213});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24214 = args[0];
  V v_d_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24214, v_d_24213})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24222 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24223 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24222}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24223));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24248 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24249 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24248));
  V v_t_24250;
  if ((heff_dup(v_x1_24249) == NTAG(TAG_True))) {
    heff_drop(v_x1_24249);
    v_t_24250 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24249);
    v_t_24250 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24251 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24246, v_r_24248}));
  return (g_std_2edoc_2e_3c_3e(v_t_24250, v_t_24251));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24365 = args[0];
  V v_k_24364 = heff_env(self)[0];
  V v_d_24363 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24366 = heff_intSub(v_k_24364, v_i_24365);
  if (heff_intEq_c_lent(v_i_24366, MK_INT(0LL), 2)) {
    heff_drop(v_i_24366);
    return v_d_24363;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24366, v_d_24363});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24364 = args[0];
  V v_d_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24364, v_d_24363})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24429 = args[0];
  V v_k_24428 = heff_env(self)[0];
  V v_d_24425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24430 = heff_intSub(v_k_24428, v_i_24429);
  if (heff_intEq_c_lent(v_i_24430, MK_INT(0LL), 2)) {
    heff_drop(v_i_24430);
    return v_d_24425;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24430, v_d_24425});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24428 = args[0];
  V v_d_24425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24428, v_d_24425})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24448 = args[0];
  V v_k_24447 = heff_env(self)[0];
  V v_d_24444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24449 = heff_intSub(v_k_24447, v_i_24448);
  if (heff_intEq_c_lent(v_i_24449, MK_INT(0LL), 2)) {
    heff_drop(v_i_24449);
    return v_d_24444;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24449, v_d_24444});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24447 = args[0];
  V v_d_24444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24447, v_d_24444})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24500 = args[0];
  V v_k_24499 = heff_env(self)[0];
  V v_d_24498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24501 = heff_intSub(v_k_24499, v_i_24500);
  if (heff_intEq_c_lent(v_i_24501, MK_INT(0LL), 2)) {
    heff_drop(v_i_24501);
    return v_d_24498;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24501, v_d_24498});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24499 = args[0];
  V v_d_24498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24499, v_d_24498})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_i_24531 = args[0];
  V v_k_24530 = heff_env(self)[0];
  V v_d_24521 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24532 = heff_intSub(v_k_24530, v_i_24531);
  if (heff_intEq_c_lent(v_i_24532, MK_INT(0LL), 2)) {
    heff_drop(v_i_24532);
    return v_d_24521;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24532, v_d_24521});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_k_24530 = args[0];
  V v_d_24521 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 2, (V[]){v_k_24530, v_d_24521})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24Atom, v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2412 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2412));
  }
  case TAG_Named: {
    V v_o_2413 = heff_field(v_e0_241, 0);
    V v_x_2414 = heff_field(v_e0_241, 1);
    V v_k_2415 = heff_field(v_e0_241, 2);
    V v_e_2416 = heff_field(v_e0_241, 3);
    V v_c_2417 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2413));
    V v_a_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2415));
    V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2416}));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2421));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_a_2419, v_t_2424));
    V v_t_2426 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2417));
    V v_t_2427 = (g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2426));
    return (g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2427));
  }
  case TAG_Tup: {
    V v_o_2428 = heff_field(v_e0_241, 0);
    V v_es_2429 = heff_field(v_e0_241, 1);
    V v_commas_2430 = heff_field(v_e0_241, 2);
    V v_c_2431 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2429)) {
    case TAG_Nil: {
      heff_drop(v_commas_2430);
      V v_t_2432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2428));
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2431));
      return (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2433));
    }
    case TAG_Cons: {
      V v_e1_2434 = heff_field(v_es_2429, 0);
      V v_more_2435 = heff_field(v_es_2429, 1);
      V v_ru_24es_2429_24Cons = heff_take_reuse_n(v_es_2429, 3ULL, 2);
      V v_t_2436 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2428)));
      V v_t_2437 = heff_tag_at_n(v_ru_24es_2429_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_one_2438 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2439 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2434));
      V v_t_2443;
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop(v_t_2439);
        V v_d_2440 = heff_tr(heff_call(v_one_2438, 1, (V[]){v_e1_2434}));
        v_t_2443 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2440});
      } else {
        heff_drop(v_t_2439);
        V v_t_2441 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e1_2434));
        if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
          heff_drop(v_t_2441);
          V v_d_2442 = heff_tr(heff_call(v_one_2438, 1, (V[]){v_e1_2434}));
          v_t_2443 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2442});
        } else {
          heff_drop(v_t_2441);
          v_t_2443 = heff_tr(heff_call(v_one_2438, 1, (V[]){v_e1_2434}));
        }
      }
      V v_t_2455 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2430; V a_3 = v_more_2435; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2430); heff_drop(v_more_2435); r_; });
      V v_x1_2456 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2428, 4, 9), heff_dup(heff_rfield(v_c_2431, 3))));
      V v_t_2457;
      if ((heff_dup(v_x1_2456) == NTAG(TAG_True))) {
        heff_drop(v_x1_2456);
        v_t_2457 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2456);
        v_t_2457 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2431));
      V v_t_2459 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2458));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2455, v_t_2459));
      V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2443, v_t_2460));
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2461));
      V v_d_2463 = (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2462));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2463})})));
    }
    default: return heff_nomatch(v_es_2429);
    }
  }
  case TAG_Seg: {
    V v_v_2467 = heff_field(v_e0_241, 0);
    V v_cc_2468 = heff_field(v_e0_241, 1);
    V v_spec_2469 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2467}));
    V v_t_2471 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2468));
    V v_t_2473 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2469; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2469); r_; });
    V v_t_2474 = (g_std_2edoc_2e_3c_3e(v_t_2471, v_t_2473));
    return (g_std_2edoc_2e_3c_3e(v_t_2470, v_t_2474));
  }
  case TAG_Braces: {
    V v_o_2475 = heff_field(v_e0_241, 0);
    V v_fs_2476 = heff_field(v_e0_241, 1);
    V v_commas_2477 = heff_field(v_e0_241, 2);
    V v_c_2478 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2476)) {
    case TAG_Nil: {
      heff_drop(v_commas_2477);
      V v_t_2479 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2475));
      V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2478));
      return (g_std_2edoc_2e_3c_3e(v_t_2479, v_t_2480));
    }
    case TAG_Cons: {
      V v_f1_2481 = heff_field(v_fs_2476, 0);
      V v_more_2482 = heff_field(v_fs_2476, 1);
      V v_ru_24fs_2476_24Cons = heff_take_reuse_n(v_fs_2476, 3ULL, 2);
      V v_a_2483 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2475)));
      V v_d_2484 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2481}));
      V v_t_2485 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2476_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2484})));
      V v_t_2486 = (g_std_2edoc_2e_3c_3e(v_a_2483, v_t_2485));
      V v_t_2493 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2477; V a_3 = v_more_2482; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2477); heff_drop(v_more_2482); r_; });
      V v_x1_2494 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2475, 4, 9), heff_dup(heff_rfield(v_c_2478, 3))));
      V v_t_2495;
      if ((heff_dup(v_x1_2494) == NTAG(TAG_True))) {
        heff_drop(v_x1_2494);
        v_t_2495 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2494);
        v_t_2495 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2496 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2478));
      V v_t_2497 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2496));
      V v_t_2498 = (g_std_2edoc_2e_3c_3e(v_t_2493, v_t_2497));
      V v_d_2499 = (g_std_2edoc_2e_3c_3e(v_t_2486, v_t_2498));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_2499})})));
    }
    default: return heff_nomatch(v_fs_2476);
    }
  }
  case TAG_Update: {
    V v_o_24103 = heff_field(v_e0_241, 0);
    V v_r_24104 = heff_field(v_e0_241, 1);
    V v_bar_24105 = heff_field(v_e0_241, 2);
    V v_fs_24106 = heff_field(v_e0_241, 3);
    V v_commas_24107 = heff_field(v_e0_241, 4);
    V v_c_24108 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24106)) {
    case TAG_Nil: {
      heff_drop(v_commas_24107);
      V v_a_24109 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24103));
      V v_a_24110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24104}));
      V v_a_24111 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24105));
      V v_b_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24108));
      V v_t_24113 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24112));
      V v_t_24114 = (g_std_2edoc_2e_3c_3e(v_a_24111, v_t_24113));
      V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24114));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(v_a_24110, v_t_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24116));
      return (g_std_2edoc_2e_3c_3e(v_a_24109, v_t_24117));
    }
    case TAG_Cons: {
      V v_f1_24118 = heff_field(v_fs_24106, 0);
      V v_more_24119 = heff_field(v_fs_24106, 1);
      V v_ru_24fs_24106_24Cons = heff_take_reuse_n(v_fs_24106, 3ULL, 2);
      V v_a_24120 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24103)));
      V v_d_24121 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24104}));
      V v_t_24122 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24106_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24121})));
      V v_t_24123 = (g_std_2edoc_2e_3c_3e(v_a_24120, v_t_24122));
      V v_a_24124 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24105));
      V v_d_24125 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24118}));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24125})));
      V v_t_24127 = (g_std_2edoc_2e_3c_3e(v_a_24124, v_t_24126));
      V v_t_24134 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24107; V a_3 = v_more_24119; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24107); heff_drop(v_more_24119); r_; });
      V v_x1_24135 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24103, 4, 9), heff_dup(heff_rfield(v_c_24108, 3))));
      V v_t_24136;
      if ((heff_dup(v_x1_24135) == NTAG(TAG_True))) {
        heff_drop(v_x1_24135);
        v_t_24136 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24135);
        v_t_24136 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24137 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24108));
      V v_t_24138 = (g_std_2edoc_2e_3c_3e(v_t_24136, v_t_24137));
      V v_t_24139 = (g_std_2edoc_2e_3c_3e(v_t_24134, v_t_24138));
      V v_t_24140 = (g_std_2edoc_2e_3c_3e(v_t_24127, v_t_24139));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24140));
      V v_d_24142 = (g_std_2edoc_2e_3c_3e(v_t_24123, v_t_24141));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24142})})));
    }
    default: return heff_nomatch(v_fs_24106);
    }
  }
  case TAG_EUSet: {
    V v_x_24146 = heff_field(v_e0_241, 0);
    V v_eq_24147 = heff_field(v_e0_241, 1);
    V v_e_24148 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24149 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24146}));
    V v_b_24150 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24147));
    V v_t_24151 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24150));
    V v_t_24152 = (g_std_2edoc_2e_3c_3e(v_a_24149, v_t_24151));
    V v_t_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24148}));
    return (g_std_2edoc_2e_3c_3e(v_t_24152, v_t_24153));
  }
  case TAG_InstB: {
    V v_o_24154 = heff_field(v_e0_241, 0);
    V v_o2_24155 = heff_field(v_e0_241, 1);
    V v_d_24156 = heff_field(v_e0_241, 2);
    V v_c1_24157 = heff_field(v_e0_241, 3);
    V v_c_24158 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24159 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24154));
    V v_t_24160 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24155));
    V v_t_24161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24156}));
    V v_t_24162 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24157));
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24158));
    V v_t_24164 = (g_std_2edoc_2e_3c_3e(v_t_24162, v_t_24163));
    V v_t_24165 = (g_std_2edoc_2e_3c_3e(v_t_24161, v_t_24164));
    V v_t_24166 = (g_std_2edoc_2e_3c_3e(v_t_24160, v_t_24165));
    return (g_std_2edoc_2e_3c_3e(v_t_24159, v_t_24166));
  }
  case TAG_EFSet: {
    V v_x_24167 = heff_field(v_e0_241, 0);
    V v_eq_24168 = heff_field(v_e0_241, 1);
    V v_e_24169 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24170 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24167));
    V v_b_24171 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24168));
    V v_t_24172 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24171));
    V v_t_24173 = (g_std_2edoc_2e_3c_3e(v_a_24170, v_t_24172));
    V v_t_24174 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24169}));
    return (g_std_2edoc_2e_3c_3e(v_t_24173, v_t_24174));
  }
  case TAG_EFDefault: {
    V v_d_24175 = heff_field(v_e0_241, 0);
    V v_eq_24176 = heff_field(v_e0_241, 1);
    V v_e_24177 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24175}));
    V v_b_24179 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24176));
    V v_t_24180 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24179));
    V v_t_24181 = (g_std_2edoc_2e_3c_3e(v_a_24178, v_t_24180));
    V v_t_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24177}));
    return (g_std_2edoc_2e_3c_3e(v_t_24181, v_t_24182));
  }
  case TAG_Sum: {
    V v_kw_24183 = heff_field(v_e0_241, 0);
    V v_o_24184 = heff_field(v_e0_241, 1);
    V v_alts_24185 = heff_field(v_e0_241, 2);
    V v_bars_24186 = heff_field(v_e0_241, 3);
    V v_c_24187 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24185)) {
    case TAG_Nil: {
      heff_drop(v_bars_24186);
      V v_a_24188 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24183));
      V v_a_24189 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24184));
      V v_b_24190 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24187));
      V v_t_24191 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24190));
      V v_t_24192 = (g_std_2edoc_2e_3c_3e(v_a_24189, v_t_24191));
      V v_t_24193 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24192));
      return (g_std_2edoc_2e_3c_3e(v_a_24188, v_t_24193));
    }
    case TAG_Cons: {
      V v_a1_24194 = heff_field(v_alts_24185, 0);
      V v_more_24195 = heff_field(v_alts_24185, 1);
      V v_ru_24alts_24185_24Cons = heff_take_reuse_n(v_alts_24185, 3ULL, 2);
      V v_a_24196 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24183));
      V v_a_24197 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24184)));
      V v_b_24198 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24194}));
      V v_t_24199 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24198));
      V v_t_24200 = (g_std_2edoc_2e_3c_3e(v_a_24197, v_t_24199));
      V v_a_24209 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24184, heff_dup(v_c_24187)}); V a_2 = v_bars_24186; V a_3 = v_more_24195; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24186); heff_drop(v_more_24195); r_; });
      V v_b_24210 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24187));
      V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24210));
      V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
      V v_d_24213 = (g_std_2edoc_2e_3c_3e(v_t_24200, v_t_24212));
      V v_b_24217 = (g_std_2edoc_2egroup_24tok2(v_ru_24alts_24185_24Cons, heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24213})})));
      V v_t_24218 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24217));
      return (g_std_2edoc_2e_3c_3e(v_a_24196, v_t_24218));
    }
    default: return heff_nomatch(v_alts_24185);
    }
  }
  case TAG_ECon: {
    V v_c_24219 = heff_field(v_e0_241, 0);
    V v_args_24220 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24221 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24219));
    V v_t_24224 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24220; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24220); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24221, v_t_24224));
  }
  case TAG_EField: {
    V v_e_24225 = heff_field(v_e0_241, 0);
    V v_f_24226 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24225}));
    V v_t_24228 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24226));
    return (g_std_2edoc_2e_3c_3e(v_t_24227, v_t_24228));
  }
  case TAG_ENeg: {
    V v_m_24229 = heff_field(v_e0_241, 0);
    V v_e_24230 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24231 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24229));
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24230}));
    return (g_std_2edoc_2e_3c_3e(v_t_24231, v_t_24232));
  }
  case TAG_ETilde: {
    V v_m_24233 = heff_field(v_e0_241, 0);
    V v_e_24234 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24235 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24233));
    V v_t_24236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24234}));
    return (g_std_2edoc_2e_3c_3e(v_t_24235, v_t_24236));
  }
  case TAG_App: {
    V v_h_24237 = heff_field(v_e0_241, 0);
    V v_args_24238 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24237;
    heff_room[2] = v_args_24238;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24239 = heff_field(v_e0_241, 0);
    V v_op_24240 = heff_field(v_e0_241, 1);
    V v_b_24241 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24242 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24239, v_op_24240, v_b_24241})));
    {
      V v_field_24243 = v_t_24242.f[0];
      V v_field_24244 = v_t_24242.f[1];
      V v_first_24245 = v_field_24243;
      V v_rest_24246 = v_field_24244;
      V v_t_24247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24246), v_first_24245}));
      V v_t_24252 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24246)}); V a_2 = v_rest_24246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24246); r_; });
      V v_t_24253 = (g_std_2edoc_2e_3c_3e(v_t_24247, v_t_24252));
      return (g_std_2edoc_2egroup(v_t_24253));
    }
  }
  case TAG_Ops: {
    V v_a_24254 = heff_field(v_e0_241, 0);
    V v_rest_24255 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24254;
    heff_room[2] = v_rest_24255;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24256 = heff_field(v_e0_241, 0);
    V v_e_24257 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24258 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24256));
    V v_b_24259 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24257}));
    V v_t_24260 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24259));
    return (g_std_2edoc_2e_3c_3e(v_a_24258, v_t_24260));
  }
  case TAG_Ann: {
    V v_e_24261 = heff_field(v_e0_241, 0);
    V v_cc_24262 = heff_field(v_e0_241, 1);
    V v_ty_24263 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24264 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24261}));
    V v_b_24265 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24262));
    V v_t_24266 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24265));
    V v_t_24267 = (g_std_2edoc_2e_3c_3e(v_a_24264, v_t_24266));
    V v_t_24268 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24263}));
    V v_d_24269 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24268));
    V v_t_24270 = (g_std_2edoc_2e_3c_3e(v_t_24267, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24269})));
    return (g_std_2edoc_2egroup(v_t_24270));
  }
  case TAG_BVar: {
    V v_t_24271 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24BVar = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24BVar, v_env_240, v_t_24271));
  }
  case TAG_BImp: {
    V v_o_24272 = heff_field(v_e0_241, 0);
    V v_x_24273 = heff_field(v_e0_241, 1);
    V v_c_24274 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24275 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24272));
    V v_t_24276 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24273));
    V v_t_24277 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24274));
    V v_t_24278 = (g_std_2edoc_2e_3c_3e(v_t_24276, v_t_24277));
    return (g_std_2edoc_2e_3c_3e(v_t_24275, v_t_24278));
  }
  case TAG_BAnn: {
    V v_o_24279 = heff_field(v_e0_241, 0);
    V v_x_24280 = heff_field(v_e0_241, 1);
    V v_cc_24281 = heff_field(v_e0_241, 2);
    V v_ty_24282 = heff_field(v_e0_241, 3);
    V v_c_24283 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24284 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24279));
    V v_a_24285 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24280));
    V v_a_24286 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24281));
    V v_b_24287 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24282}));
    V v_t_24288 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24287));
    V v_t_24289 = (g_std_2edoc_2e_3c_3e(v_a_24286, v_t_24288));
    V v_t_24290 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24289));
    V v_t_24291 = (g_std_2edoc_2e_3c_3e(v_a_24285, v_t_24290));
    V v_t_24292 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24283));
    V v_t_24293 = (g_std_2edoc_2e_3c_3e(v_t_24291, v_t_24292));
    return (g_std_2edoc_2e_3c_3e(v_t_24284, v_t_24293));
  }
  case TAG_BPat: {
    V v_p_24294 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return ({ V a_0 = v_env_240; V a_1 = v_p_24294; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24294); r_; });
  }
  case TAG_Lam: {
    V v_bs_24295 = heff_field(v_e0_241, 0);
    V v_binders_24296 = heff_field(v_e0_241, 1);
    V v_arrow_24297 = heff_field(v_e0_241, 2);
    V v_body_24298 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24299 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24295));
    V v_t_24300 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24301 = (g_list_2emap(v_t_24300, v_binders_24296));
    V v_a_24302 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24301; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24301); r_; });
    V v_b_24303 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24297));
    V v_t_24304 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24303));
    V v_t_24305 = (g_std_2edoc_2e_3c_3e(v_a_24302, v_t_24304));
    V v_t_24306 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24298));
    V v_t_24310;
    if ((heff_dup(v_t_24306) == NTAG(TAG_True))) {
      heff_drop(v_t_24306);
      V v_t_24307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      v_t_24310 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24307));
    } else {
      heff_drop(v_t_24306);
      V v_t_24308 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      V v_d_24309 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24308));
      v_t_24310 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24309})));
    }
    V v_t_24311 = (g_std_2edoc_2e_3c_3e(v_t_24305, v_t_24310));
    return (g_std_2edoc_2e_3c_3e(v_t_24299, v_t_24311));
  }
  case TAG_Case: {
    V v_kw_24312 = heff_field(v_e0_241, 0);
    V v_scrut_24313 = heff_field(v_e0_241, 1);
    V v_of2_24314 = heff_field(v_e0_241, 2);
    V v_alts_24315 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24316 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24312));
    V v_a_24317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24313}));
    V v_b_24318 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24314));
    V v_t_24319 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24318));
    V v_t_24320 = (g_std_2edoc_2e_3c_3e(v_a_24317, v_t_24319));
    V v_t_24321 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24320));
    V v_t_24322 = (g_std_2edoc_2e_3c_3e(v_a_24316, v_t_24321));
    V v_t_24323 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24315; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24315); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24322, v_t_24323));
  }
  case TAG_EAlt: {
    V v_p_24324 = heff_field(v_e0_241, 0);
    V v_arrow_24325 = heff_field(v_e0_241, 1);
    V v_body_24326 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24327 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24324; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24324); r_; });
    V v_b_24328 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24325));
    V v_t_24329 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24328));
    V v_t_24330 = (g_std_2edoc_2e_3c_3e(v_a_24327, v_t_24329));
    V v_t_24331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24326}));
    return (g_std_2edoc_2e_3c_3e(v_t_24330, v_t_24331));
  }
  case TAG_If: {
    V v_kw_24332 = heff_field(v_e0_241, 0);
    V v_c_24333 = heff_field(v_e0_241, 1);
    V v_th_24334 = heff_field(v_e0_241, 2);
    V v_a_24335 = heff_field(v_e0_241, 3);
    V v_el_24336 = heff_field(v_e0_241, 4);
    V v_b_24337 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24338 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24332, v_c_24333, v_th_24334, v_a_24335}));
    V v_t_24339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24336, v_b_24337}));
    V v_t_24340 = (g_std_2edoc_2e_3c_3e(v_t_24338, v_t_24339));
    return (g_std_2edoc_2egroup(v_t_24340));
  }
  case TAG_Do: {
    V v_kw_24341 = heff_field(v_e0_241, 0);
    V v_stmts_24342 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24343 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24341));
    V v_t_24344 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24342; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24342); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24343, v_t_24344));
  }
  case TAG_ESBind: {
    V v_x_24345 = heff_field(v_e0_241, 0);
    V v_arrow_24346 = heff_field(v_e0_241, 1);
    V v_e_24347 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24348 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24345; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24345); r_; });
    V v_b_24349 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24346));
    V v_t_24350 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24349));
    V v_t_24351 = (g_std_2edoc_2e_3c_3e(v_a_24348, v_t_24350));
    V v_t_24352 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24347}));
    return (g_std_2edoc_2e_3c_3e(v_t_24351, v_t_24352));
  }
  case TAG_ELet: {
    V v_kw_24353 = heff_field(v_e0_241, 0);
    V v_p_24354 = heff_field(v_e0_241, 1);
    V v_ann_24355 = heff_field(v_e0_241, 2);
    V v_eq_24356 = heff_field(v_e0_241, 3);
    V v_e_24357 = heff_field(v_e0_241, 4);
    V v_body_24358 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24358)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357});
    }
    case TAG_Just: {
      V v_it1_24359 = heff_field(v_body_24358, 0);
      V v_ru_24body_24358_24Just = heff_take_reuse_n(v_body_24358, 1ULL, 1);
      switch (heff_tag_of(v_it1_24359)) {
      case TAG_MkPair: {
        V v_i_24360 = heff_field(v_it1_24359, 0);
        V v_b_24361 = heff_field(v_it1_24359, 1);
        V v_ru_24it1_24359_24MkPair = heff_take_reuse_n(v_it1_24359, 3ULL, 2);
        V v_t_24362 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357, v_i_24360, v_b_24361}));
        V v_d_24363 = (g_std_2edoc_2egroup_24tok2(v_ru_24it1_24359_24MkPair, v_t_24362));
        return heff_tag_at_n(v_ru_24body_24358_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24363})});
      }
      default: return heff_nomatch(v_it1_24359);
      }
    }
    default: return heff_nomatch(v_body_24358);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24367 = heff_field(v_e0_241, 0);
    V v_p_24368 = heff_field(v_e0_241, 1);
    V v_ann_24369 = heff_field(v_e0_241, 2);
    V v_eq_24370 = heff_field(v_e0_241, 3);
    V v_e_24371 = heff_field(v_e0_241, 4);
    V v_el_24372 = heff_field(v_e0_241, 5);
    V v_ss_24373 = heff_field(v_e0_241, 6);
    heff_take_n(v_e0_241, 127ULL, 7);
    V v_a_24374 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_240), v_kw_24367, v_p_24368, v_ann_24369, v_eq_24370, v_e_24371}));
    V v_b_24375 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_el_24372));
    V v_t_24376 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24375));
    V v_t_24377 = (g_std_2edoc_2e_3c_3e(v_a_24374, v_t_24376));
    V v_t_24385;
    switch (heff_tag_of(v_ss_24373)) {
    case TAG_Nil: {
      v_t_24385 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(v_env_240, MK_INT(0LL), v_ss_24373));
      break;
    }
    case TAG_Cons: {
      V v_s1_24378 = heff_dup(heff_field(v_ss_24373, 0));
      V v_it2_24379 = heff_dup(heff_field(v_ss_24373, 1));
      switch (heff_tag_of(v_it2_24379)) {
      case TAG_Nil: {
        V v_t_24380 = (g_heff_2esyntax_2ecst_2efirstE(v_s1_24378));
        V v_t_24381 = heff_get_n(v_t_24380, 6, 9);
        if ((heff_dup(v_t_24381) == NTAG(TAG_True))) {
          heff_drop(v_s1_24378);
          heff_drop(v_t_24381);
          v_t_24385 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24373; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop_tag(v_ss_24373, 2); r_; });
        } else {
          heff_drop_tag(v_ss_24373, 2);
          heff_drop(v_t_24381);
          V v_t_24382 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14)), 2, (V[]){v_env_240, v_s1_24378}));
          v_t_24385 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24382));
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it2_24379, 0ULL, 2);
        heff_drop(v_s1_24378);
        v_t_24385 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24373; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop_tag(v_ss_24373, 2); r_; });
        break;
      }
      default: heff_nomatch(v_it2_24379);
      }
      break;
    }
    default: heff_nomatch(v_ss_24373);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_24377, v_t_24385));
  }
  case TAG_ELetMut: {
    V v_kw_24386 = heff_field(v_e0_241, 0);
    V v_m_24387 = heff_field(v_e0_241, 1);
    V v_x_24388 = heff_field(v_e0_241, 2);
    V v_ann_24389 = heff_field(v_e0_241, 3);
    V v_eq_24390 = heff_field(v_e0_241, 4);
    V v_e_24391 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24392 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24386));
    V v_a_24393 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24387));
    V v_b_24394 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24388));
    V v_t_24395 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24394));
    V v_t_24396 = (g_std_2edoc_2e_3c_3e(v_a_24393, v_t_24395));
    V v_t_24397 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24396));
    V v_t_24398 = (g_std_2edoc_2e_3c_3e(v_a_24392, v_t_24397));
    V v_a_24406;
    switch (heff_tag_of(v_ann_24389)) {
    case TAG_Nothing: {
      v_a_24406 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24399 = heff_field(v_ann_24389, 0);
      V v_ru_24ann_24389_24Just = heff_take_reuse_n(v_ann_24389, 1ULL, 1);
      switch (heff_tag_of(v_it1_24399)) {
      case TAG_MkPair: {
        V v_cc_24400 = heff_field(v_it1_24399, 0);
        V v_ty_24401 = heff_field(v_it1_24399, 1);
        heff_take_n(v_it1_24399, 3ULL, 2);
        V v_a_24402 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24400));
        V v_b_24403 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24401}));
        V v_t_24404 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24389_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24403));
        V v_t_24405 = (g_std_2edoc_2e_3c_3e(v_a_24402, v_t_24404));
        v_a_24406 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_t_24405));
        break;
      }
      default: heff_nomatch(v_it1_24399);
      }
      break;
    }
    default: heff_nomatch(v_ann_24389);
    }
    V v_b_24407 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24390));
    V v_t_24408 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24407));
    V v_t_24409 = (g_std_2edoc_2e_3c_3e(v_a_24406, v_t_24408));
    V v_t_24410 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24391}));
    V v_t_24411 = (g_std_2edoc_2e_3c_3e(v_t_24409, v_t_24410));
    return (g_std_2edoc_2e_3c_3e(v_t_24398, v_t_24411));
  }
  case TAG_EAssign: {
    V v_x_24412 = heff_field(v_e0_241, 0);
    V v_k_24413 = heff_field(v_e0_241, 1);
    V v_e_24414 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24415 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24412));
    V v_b_24416 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24413));
    V v_t_24417 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_b_24416));
    V v_t_24418 = (g_std_2edoc_2e_3c_3e(v_a_24415, v_t_24417));
    V v_t_24419 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24414}));
    return (g_std_2edoc_2e_3c_3e(v_t_24418, v_t_24419));
  }
  case TAG_EWhile: {
    V v_kw_24420 = heff_field(v_e0_241, 0);
    V v_c_24421 = heff_field(v_e0_241, 1);
    V v_d_24422 = heff_field(v_e0_241, 2);
    V v_body_24423 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24424 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24420));
    V v_d_24425 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24421}));
    V v_b_24426 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24422));
    V v_t_24427 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24426));
    V v_t_24431 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24425})}), v_t_24427));
    V v_t_24432 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24431));
    V v_t_24433 = (g_std_2edoc_2e_3c_3e(v_a_24424, v_t_24432));
    V v_t_24434 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24423; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24423); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24433, v_t_24434));
  }
  case TAG_EFor: {
    V v_kw_24435 = heff_field(v_e0_241, 0);
    V v_p_24436 = heff_field(v_e0_241, 1);
    V v_i_24437 = heff_field(v_e0_241, 2);
    V v_c_24438 = heff_field(v_e0_241, 3);
    V v_d_24439 = heff_field(v_e0_241, 4);
    V v_body_24440 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24441 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24435));
    V v_a_24442 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24436; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24436); r_; });
    V v_a_24443 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24437));
    V v_d_24444 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24438}));
    V v_b_24445 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24439));
    V v_t_24446 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_b_24445));
    V v_t_24450 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24444})}), v_t_24446));
    V v_t_24451 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24450));
    V v_t_24452 = (g_std_2edoc_2e_3c_3e(v_a_24443, v_t_24451));
    V v_t_24453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), v_t_24452));
    V v_t_24454 = (g_std_2edoc_2e_3c_3e(v_a_24442, v_t_24453));
    V v_t_24455 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_t_24454));
    V v_t_24456 = (g_std_2edoc_2e_3c_3e(v_a_24441, v_t_24455));
    V v_t_24457 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24440; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24440); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24456, v_t_24457));
  }
  case TAG_EJump: {
    V v_kw_24458 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24EJump, v_env_240, v_kw_24458));
  }
  case TAG_EReturn: {
    V v_kw_24459 = heff_field(v_e0_241, 0);
    V v_e_24460 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24461 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24459));
    V v_d_24462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24460}));
    V v_t_24463 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24462})));
    return (g_std_2edoc_2e_3c_3e(v_a_24461, v_t_24463));
  }
  case TAG_ENest: {
    V v_o_24464 = heff_field(v_e0_241, 0);
    V v_arrow_24465 = heff_field(v_e0_241, 1);
    V v_e_24466 = heff_field(v_e0_241, 2);
    V v_c_24467 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24468 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24464));
    V v_a_24469 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24465));
    V v_b_24470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24466}));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24470));
    V v_t_24472 = (g_std_2edoc_2e_3c_3e(v_a_24469, v_t_24471));
    V v_t_24473 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24467));
    V v_t_24474 = (g_std_2edoc_2e_3c_3e(v_t_24472, v_t_24473));
    return (g_std_2edoc_2e_3c_3e(v_t_24468, v_t_24474));
  }
  case TAG_EArrow: {
    V v_arrow_24475 = heff_field(v_e0_241, 0);
    V v_e_24476 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24477 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24475));
    V v_b_24478 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24476}));
    V v_t_24479 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_b_24478));
    return (g_std_2edoc_2e_3c_3e(v_a_24477, v_t_24479));
  }
  case TAG_IfThen: {
    V v_kw_24480 = heff_field(v_e0_241, 0);
    V v_c_24481 = heff_field(v_e0_241, 1);
    V v_th_24482 = heff_field(v_e0_241, 2);
    V v_a_24483 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24484 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24480, v_c_24481, v_th_24482, v_a_24483}));
    return (g_std_2edoc_2egroup(v_t_24484));
  }
  case TAG_ETry: {
    V v_kw_24485 = heff_field(v_e0_241, 0);
    V v_ty_24486 = heff_field(v_e0_241, 1);
    V v_body_24487 = heff_field(v_e0_241, 2);
    V v_c_24488 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24489 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24485));
    V v_t_24492;
    switch (heff_tag_of(v_ty_24486)) {
    case TAG_Nothing: {
      v_t_24492 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24490 = heff_field(v_ty_24486, 0);
      V v_ru_24ty_24486_24Just = heff_take_reuse_n(v_ty_24486, 1ULL, 1);
      V v_t_24491 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_t_24490}));
      v_t_24492 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24486_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_t_24491));
      break;
    }
    default: heff_nomatch(v_ty_24486);
    }
    V v_d_24493 = ({ V a_0 = heff_dup(v_env_240); V a_1 = MK_INT(0LL); V a_2 = v_body_24487; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24487); r_; });
    V v_t_24494 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_c_24488}));
    V v_t_24495 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24494));
    V v_t_24496 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24493}), v_t_24495));
    V v_t_24497 = (g_std_2edoc_2e_3c_3e(v_t_24492, v_t_24496));
    V v_d_24498 = (g_std_2edoc_2e_3c_3e(v_t_24489, v_t_24497));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24498})});
  }
  case TAG_ECatch: {
    V v_kw_24502 = heff_field(v_e0_241, 0);
    V v_b_24503 = heff_field(v_e0_241, 1);
    V v_arrow_24504 = heff_field(v_e0_241, 2);
    V v_body_24505 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24506 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24502));
    V v_a_24507 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 2, (V[]){heff_dup(v_env_240), v_b_24503}));
    V v_b_24508 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24504));
    V v_t_24509 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_b_24508));
    V v_t_24510 = (g_std_2edoc_2e_3c_3e(v_a_24507, v_t_24509));
    V v_t_24511 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_t_24510));
    V v_t_24512 = (g_std_2edoc_2e_3c_3e(v_a_24506, v_t_24511));
    V v_d_24513 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24505; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24505); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24512, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24513})));
  }
  case TAG_EWith: {
    V v_kw_24514 = heff_field(v_e0_241, 0);
    V v_e_24515 = heff_field(v_e0_241, 1);
    V v_a_24516 = heff_field(v_e0_241, 2);
    V v_x_24517 = heff_field(v_e0_241, 3);
    V v_d_24518 = heff_field(v_e0_241, 4);
    V v_body_24519 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24520 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24514));
    V v_d_24521 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24515}));
    V v_a_24522 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_a_24516));
    V v_a_24523 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24517; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24517); r_; });
    V v_b_24524 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24518));
    V v_t_24525 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_b_24524));
    V v_t_24526 = (g_std_2edoc_2e_3c_3e(v_a_24523, v_t_24525));
    V v_t_24527 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_t_24526));
    V v_t_24528 = (g_std_2edoc_2e_3c_3e(v_a_24522, v_t_24527));
    V v_t_24529 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24528));
    V v_t_24533 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_d_24521})}), v_t_24529));
    V v_t_24534 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_t_24533));
    V v_t_24535 = (g_std_2edoc_2e_3c_3e(v_a_24520, v_t_24534));
    V v_t_24536 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24519; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24519); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24535, v_t_24536));
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_env_24537 = args[0];
  V v_e_24538 = args[1];
  V v_t_24539 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24538));
  if ((heff_dup(v_t_24539) == NTAG(TAG_True))) {
    heff_drop(v_t_24539);
    V v_t_24540 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24537, v_e_24538}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), v_t_24540));
  } else {
    heff_drop(v_t_24539);
    V v_t_24541 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24537, v_e_24538}));
    V v_t_24542 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24541));
    return (g_std_2edoc_2egroup(v_t_24542));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_env_24543 = args[0];
  V v_kw_24544 = args[1];
  V v_p_24545 = args[2];
  V v_ann_24546 = args[3];
  V v_eq_24547 = args[4];
  V v_e_24548 = args[5];
  V v_a_24549 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24543), v_kw_24544));
  V v_b_24550 = ({ V a_0 = heff_dup(v_env_24543); V a_1 = v_p_24545; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24545); r_; });
  V v_t_24551 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), v_b_24550));
  V v_t_24552 = (g_std_2edoc_2e_3c_3e(v_a_24549, v_t_24551));
  V v_a_24560;
  switch (heff_tag_of(v_ann_24546)) {
  case TAG_Nothing: {
    v_a_24560 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24553 = heff_field(v_ann_24546, 0);
    V v_ru_24ann_24546_24Just = heff_take_reuse_n(v_ann_24546, 1ULL, 1);
    switch (heff_tag_of(v_it1_24553)) {
    case TAG_MkPair: {
      V v_cc_24554 = heff_field(v_it1_24553, 0);
      V v_ty_24555 = heff_field(v_it1_24553, 1);
      heff_take_n(v_it1_24553, 3ULL, 2);
      V v_a_24556 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24543), v_cc_24554));
      V v_b_24557 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24543), v_ty_24555}));
      V v_t_24558 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24546_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), v_b_24557));
      V v_t_24559 = (g_std_2edoc_2e_3c_3e(v_a_24556, v_t_24558));
      v_a_24560 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_t_24559));
      break;
    }
    default: heff_nomatch(v_it1_24553);
    }
    break;
  }
  default: heff_nomatch(v_ann_24546);
  }
  V v_b_24561 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24543), v_eq_24547));
  V v_t_24562 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24561));
  V v_t_24563 = (g_std_2edoc_2e_3c_3e(v_a_24560, v_t_24562));
  V v_t_24564 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24543, v_e_24548}));
  V v_t_24565 = (g_std_2edoc_2e_3c_3e(v_t_24563, v_t_24564));
  return (g_std_2edoc_2e_3c_3e(v_t_24552, v_t_24565));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_env_24566 = args[0];
  V v_kw_24567 = args[1];
  V v_p_24568 = args[2];
  V v_ann_24569 = args[3];
  V v_eq_24570 = args[4];
  V v_e_24571 = args[5];
  V v_i_24572 = args[6];
  V v_b_24573 = args[7];
  V v_d_24574 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24566), v_kw_24567, v_p_24568, v_ann_24569, v_eq_24570, v_e_24571}));
  V v_t_24575 = heff_dup(heff_rfield(v_i_24572, 6));
  V v_t_24578;
  if ((heff_dup(v_t_24575) == NTAG(TAG_True))) {
    heff_drop(v_t_24575);
    v_t_24578 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24575);
    V v_t_24576 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24573));
    V v_x1_24577 = heff_get_n(v_t_24576, 6, 9);
    if ((heff_dup(v_x1_24577) == NTAG(TAG_True))) {
      heff_drop(v_x1_24577);
      v_t_24578 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24577);
      v_t_24578 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24579 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24566), v_i_24572));
  V v_b_24745;
  switch (heff_tag_of(v_b_24573)) {
  case TAG_Atom: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EParen: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Named: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Tup: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Seg: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Braces: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Update: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EUSet: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_InstB: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EFSet: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Sum: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ECon: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EField: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ENeg: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ETilde: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_App: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Op: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Ops: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Ann: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_BVar: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_BImp: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_BAnn: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_BPat: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Lam: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Case: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EAlt: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_If: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_Do: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ESBind: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ELet: {
    V v_it6_24682 = heff_dup(heff_field(v_b_24573, 5));
    switch (heff_tag_of(v_it6_24682)) {
    case TAG_Nothing: {
      v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
      break;
    }
    case TAG_Just: {
      V v_it61_24683 = heff_field(v_it6_24682, 0);
      heff_take_n(v_it6_24682, 1ULL, 1);
      switch (heff_tag_of(v_b_24573)) {
      case TAG_ELet: {
        V v_kw2_24684 = heff_field(v_b_24573, 0);
        V v_p2_24685 = heff_field(v_b_24573, 1);
        V v_ann2_24686 = heff_field(v_b_24573, 2);
        V v_eq2_24687 = heff_field(v_b_24573, 3);
        V v_e2_24688 = heff_field(v_b_24573, 4);
        heff_take_n(v_b_24573, 31ULL, 6);
        switch (heff_tag_of(v_it61_24683)) {
        case TAG_MkPair: {
          V v_i2_24690 = heff_field(v_it61_24683, 0);
          V v_b2_24691 = heff_field(v_it61_24683, 1);
          heff_take_n(v_it61_24683, 3ULL, 2);
          v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24566, v_kw2_24684, v_p2_24685, v_ann2_24686, v_eq2_24687, v_e2_24688, v_i2_24690, v_b2_24691}));
          break;
        }
        default: heff_nomatch(v_it61_24683);
        }
        break;
      }
      default: heff_nomatch(v_b_24573);
      }
      break;
    }
    default: heff_nomatch(v_it6_24682);
    }
    break;
  }
  case TAG_ELetElse: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ELetMut: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EAssign: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EWhile: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EFor: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EJump: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EReturn: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ENest: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EArrow: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_IfThen: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ETry: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_ECatch: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  case TAG_EWith: {
    v_b_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24566, v_b_24573}));
    break;
  }
  default: heff_nomatch(v_b_24573);
  }
  V v_t_24746 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), v_b_24745));
  V v_t_24747 = (g_std_2edoc_2e_3c_3e(v_a_24579, v_t_24746));
  V v_t_24748 = (g_std_2edoc_2e_3c_3e(v_t_24578, v_t_24747));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24574}), v_t_24748));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_i_24757 = args[0];
  V v_k_24756 = heff_env(self)[0];
  V v_d_24755 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24758 = heff_intSub(v_k_24756, v_i_24757);
  if (heff_intEq_c_lent(v_i_24758, MK_INT(0LL), 2)) {
    heff_drop(v_i_24758);
    return v_d_24755;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24758, v_d_24755});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_k_24756 = args[0];
  V v_d_24755 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 2, (V[]){v_k_24756, v_d_24755})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_env_24749 = args[0];
  V v_kw_24750 = args[1];
  V v_c_24751 = args[2];
  V v_th_24752 = args[3];
  V v_a_24753 = args[4];
  V v_a_24754 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24749), v_kw_24750));
  V v_d_24755 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24749), v_c_24751}));
  V v_t_24759 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_d_24755})})));
  V v_t_24760 = (g_std_2edoc_2e_3c_3e(v_a_24754, v_t_24759));
  V v_t_24761 = heff_dup(heff_rfield(v_th_24752, 6));
  V v_t_24764;
  if ((heff_dup(v_t_24761) == NTAG(TAG_True))) {
    heff_drop(v_t_24761);
    v_t_24764 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24761);
    V v_t_24762 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24753));
    V v_x1_24763 = heff_get_n(v_t_24762, 6, 9);
    if ((heff_dup(v_x1_24763) == NTAG(TAG_True))) {
      heff_drop(v_x1_24763);
      v_t_24764 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24763);
      v_t_24764 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24765 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24749), v_th_24752));
  V v_d_24766 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24749, v_a_24753}));
  V v_t_24767 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24766})));
  V v_t_24768 = (g_std_2edoc_2e_3c_3e(v_a_24765, v_t_24767));
  V v_t_24769 = (g_std_2edoc_2e_3c_3e(v_t_24764, v_t_24768));
  V v_t_24770 = (g_std_2edoc_2e_3c_3e(v_t_24760, v_t_24769));
  return (g_std_2edoc_2egroup(v_t_24770));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_env_24771 = args[0];
  V v_el_24772 = args[1];
  V v_b_24773 = args[2];
  switch (heff_tag_of(v_b_24773)) {
  case TAG_Atom: {
    V v_t_24775 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24778;
    if ((heff_dup(v_t_24775) == NTAG(TAG_True))) {
      heff_drop(v_t_24775);
      v_t_24778 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24775);
      V v_t_24776 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24777 = heff_get_n(v_t_24776, 6, 9);
      if ((heff_dup(v_x1_24777) == NTAG(TAG_True))) {
        heff_drop(v_x1_24777);
        v_t_24778 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24777);
        v_t_24778 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24779 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24780 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24781 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24780})));
    V v_t_24782 = (g_std_2edoc_2e_3c_3e(v_a_24779, v_t_24781));
    return (g_std_2edoc_2e_3c_3e(v_t_24778, v_t_24782));
  }
  case TAG_EParen: {
    V v_t_24786 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24789;
    if ((heff_dup(v_t_24786) == NTAG(TAG_True))) {
      heff_drop(v_t_24786);
      v_t_24789 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24786);
      V v_t_24787 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24788 = heff_get_n(v_t_24787, 6, 9);
      if ((heff_dup(v_x1_24788) == NTAG(TAG_True))) {
        heff_drop(v_x1_24788);
        v_t_24789 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24788);
        v_t_24789 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24790 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24791 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24792 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24791})));
    V v_t_24793 = (g_std_2edoc_2e_3c_3e(v_a_24790, v_t_24792));
    return (g_std_2edoc_2e_3c_3e(v_t_24789, v_t_24793));
  }
  case TAG_Named: {
    V v_t_24799 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24802;
    if ((heff_dup(v_t_24799) == NTAG(TAG_True))) {
      heff_drop(v_t_24799);
      v_t_24802 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24799);
      V v_t_24800 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24801 = heff_get_n(v_t_24800, 6, 9);
      if ((heff_dup(v_x1_24801) == NTAG(TAG_True))) {
        heff_drop(v_x1_24801);
        v_t_24802 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24801);
        v_t_24802 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24803 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24804 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24805 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24804})));
    V v_t_24806 = (g_std_2edoc_2e_3c_3e(v_a_24803, v_t_24805));
    return (g_std_2edoc_2e_3c_3e(v_t_24802, v_t_24806));
  }
  case TAG_Tup: {
    V v_t_24811 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24814;
    if ((heff_dup(v_t_24811) == NTAG(TAG_True))) {
      heff_drop(v_t_24811);
      v_t_24814 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24811);
      V v_t_24812 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24813 = heff_get_n(v_t_24812, 6, 9);
      if ((heff_dup(v_x1_24813) == NTAG(TAG_True))) {
        heff_drop(v_x1_24813);
        v_t_24814 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24813);
        v_t_24814 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24815 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24816 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24817 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24816})));
    V v_t_24818 = (g_std_2edoc_2e_3c_3e(v_a_24815, v_t_24817));
    return (g_std_2edoc_2e_3c_3e(v_t_24814, v_t_24818));
  }
  case TAG_Seg: {
    V v_t_24822 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24825;
    if ((heff_dup(v_t_24822) == NTAG(TAG_True))) {
      heff_drop(v_t_24822);
      v_t_24825 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24822);
      V v_t_24823 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24824 = heff_get_n(v_t_24823, 6, 9);
      if ((heff_dup(v_x1_24824) == NTAG(TAG_True))) {
        heff_drop(v_x1_24824);
        v_t_24825 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24824);
        v_t_24825 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24826 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24827 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24828 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24827})));
    V v_t_24829 = (g_std_2edoc_2e_3c_3e(v_a_24826, v_t_24828));
    return (g_std_2edoc_2e_3c_3e(v_t_24825, v_t_24829));
  }
  case TAG_Braces: {
    V v_t_24834 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24837;
    if ((heff_dup(v_t_24834) == NTAG(TAG_True))) {
      heff_drop(v_t_24834);
      v_t_24837 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24834);
      V v_t_24835 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24836 = heff_get_n(v_t_24835, 6, 9);
      if ((heff_dup(v_x1_24836) == NTAG(TAG_True))) {
        heff_drop(v_x1_24836);
        v_t_24837 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24836);
        v_t_24837 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24838 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24839 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24840 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24839})));
    V v_t_24841 = (g_std_2edoc_2e_3c_3e(v_a_24838, v_t_24840));
    return (g_std_2edoc_2e_3c_3e(v_t_24837, v_t_24841));
  }
  case TAG_Update: {
    V v_t_24848 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24851;
    if ((heff_dup(v_t_24848) == NTAG(TAG_True))) {
      heff_drop(v_t_24848);
      v_t_24851 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24848);
      V v_t_24849 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24850 = heff_get_n(v_t_24849, 6, 9);
      if ((heff_dup(v_x1_24850) == NTAG(TAG_True))) {
        heff_drop(v_x1_24850);
        v_t_24851 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24850);
        v_t_24851 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24852 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24853 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24854 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24853})));
    V v_t_24855 = (g_std_2edoc_2e_3c_3e(v_a_24852, v_t_24854));
    return (g_std_2edoc_2e_3c_3e(v_t_24851, v_t_24855));
  }
  case TAG_EUSet: {
    V v_t_24859 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24862;
    if ((heff_dup(v_t_24859) == NTAG(TAG_True))) {
      heff_drop(v_t_24859);
      v_t_24862 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24859);
      V v_t_24860 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24861 = heff_get_n(v_t_24860, 6, 9);
      if ((heff_dup(v_x1_24861) == NTAG(TAG_True))) {
        heff_drop(v_x1_24861);
        v_t_24862 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24861);
        v_t_24862 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24863 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24864 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24865 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24864})));
    V v_t_24866 = (g_std_2edoc_2e_3c_3e(v_a_24863, v_t_24865));
    return (g_std_2edoc_2e_3c_3e(v_t_24862, v_t_24866));
  }
  case TAG_InstB: {
    V v_t_24872 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24875;
    if ((heff_dup(v_t_24872) == NTAG(TAG_True))) {
      heff_drop(v_t_24872);
      v_t_24875 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24872);
      V v_t_24873 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24874 = heff_get_n(v_t_24873, 6, 9);
      if ((heff_dup(v_x1_24874) == NTAG(TAG_True))) {
        heff_drop(v_x1_24874);
        v_t_24875 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24874);
        v_t_24875 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24876 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24877 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24878 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24877})));
    V v_t_24879 = (g_std_2edoc_2e_3c_3e(v_a_24876, v_t_24878));
    return (g_std_2edoc_2e_3c_3e(v_t_24875, v_t_24879));
  }
  case TAG_EFSet: {
    V v_t_24883 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24886;
    if ((heff_dup(v_t_24883) == NTAG(TAG_True))) {
      heff_drop(v_t_24883);
      v_t_24886 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24883);
      V v_t_24884 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24885 = heff_get_n(v_t_24884, 6, 9);
      if ((heff_dup(v_x1_24885) == NTAG(TAG_True))) {
        heff_drop(v_x1_24885);
        v_t_24886 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24885);
        v_t_24886 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24887 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24888 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24889 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24888})));
    V v_t_24890 = (g_std_2edoc_2e_3c_3e(v_a_24887, v_t_24889));
    return (g_std_2edoc_2e_3c_3e(v_t_24886, v_t_24890));
  }
  case TAG_EFDefault: {
    V v_t_24894 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24897;
    if ((heff_dup(v_t_24894) == NTAG(TAG_True))) {
      heff_drop(v_t_24894);
      v_t_24897 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24894);
      V v_t_24895 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24896 = heff_get_n(v_t_24895, 6, 9);
      if ((heff_dup(v_x1_24896) == NTAG(TAG_True))) {
        heff_drop(v_x1_24896);
        v_t_24897 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24896);
        v_t_24897 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24898 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24899 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24900 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24899})));
    V v_t_24901 = (g_std_2edoc_2e_3c_3e(v_a_24898, v_t_24900));
    return (g_std_2edoc_2e_3c_3e(v_t_24897, v_t_24901));
  }
  case TAG_Sum: {
    V v_t_24907 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24910;
    if ((heff_dup(v_t_24907) == NTAG(TAG_True))) {
      heff_drop(v_t_24907);
      v_t_24910 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24907);
      V v_t_24908 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24909 = heff_get_n(v_t_24908, 6, 9);
      if ((heff_dup(v_x1_24909) == NTAG(TAG_True))) {
        heff_drop(v_x1_24909);
        v_t_24910 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24909);
        v_t_24910 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24911 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24912 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24913 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24912})));
    V v_t_24914 = (g_std_2edoc_2e_3c_3e(v_a_24911, v_t_24913));
    return (g_std_2edoc_2e_3c_3e(v_t_24910, v_t_24914));
  }
  case TAG_ECon: {
    V v_t_24917 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24920;
    if ((heff_dup(v_t_24917) == NTAG(TAG_True))) {
      heff_drop(v_t_24917);
      v_t_24920 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24917);
      V v_t_24918 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24919 = heff_get_n(v_t_24918, 6, 9);
      if ((heff_dup(v_x1_24919) == NTAG(TAG_True))) {
        heff_drop(v_x1_24919);
        v_t_24920 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24919);
        v_t_24920 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24921 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24922 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24923 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24922})));
    V v_t_24924 = (g_std_2edoc_2e_3c_3e(v_a_24921, v_t_24923));
    return (g_std_2edoc_2e_3c_3e(v_t_24920, v_t_24924));
  }
  case TAG_EField: {
    V v_t_24927 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24930;
    if ((heff_dup(v_t_24927) == NTAG(TAG_True))) {
      heff_drop(v_t_24927);
      v_t_24930 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24927);
      V v_t_24928 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24929 = heff_get_n(v_t_24928, 6, 9);
      if ((heff_dup(v_x1_24929) == NTAG(TAG_True))) {
        heff_drop(v_x1_24929);
        v_t_24930 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24929);
        v_t_24930 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24931 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24932 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24933 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24932})));
    V v_t_24934 = (g_std_2edoc_2e_3c_3e(v_a_24931, v_t_24933));
    return (g_std_2edoc_2e_3c_3e(v_t_24930, v_t_24934));
  }
  case TAG_ENeg: {
    V v_t_24937 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24940;
    if ((heff_dup(v_t_24937) == NTAG(TAG_True))) {
      heff_drop(v_t_24937);
      v_t_24940 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24937);
      V v_t_24938 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24939 = heff_get_n(v_t_24938, 6, 9);
      if ((heff_dup(v_x1_24939) == NTAG(TAG_True))) {
        heff_drop(v_x1_24939);
        v_t_24940 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24939);
        v_t_24940 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24941 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24942 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24943 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24942})));
    V v_t_24944 = (g_std_2edoc_2e_3c_3e(v_a_24941, v_t_24943));
    return (g_std_2edoc_2e_3c_3e(v_t_24940, v_t_24944));
  }
  case TAG_ETilde: {
    V v_t_24947 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24950;
    if ((heff_dup(v_t_24947) == NTAG(TAG_True))) {
      heff_drop(v_t_24947);
      v_t_24950 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24947);
      V v_t_24948 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24949 = heff_get_n(v_t_24948, 6, 9);
      if ((heff_dup(v_x1_24949) == NTAG(TAG_True))) {
        heff_drop(v_x1_24949);
        v_t_24950 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24949);
        v_t_24950 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24951 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24952 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24953 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24952})));
    V v_t_24954 = (g_std_2edoc_2e_3c_3e(v_a_24951, v_t_24953));
    return (g_std_2edoc_2e_3c_3e(v_t_24950, v_t_24954));
  }
  case TAG_App: {
    V v_t_24957 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24960;
    if ((heff_dup(v_t_24957) == NTAG(TAG_True))) {
      heff_drop(v_t_24957);
      v_t_24960 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24957);
      V v_t_24958 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24959 = heff_get_n(v_t_24958, 6, 9);
      if ((heff_dup(v_x1_24959) == NTAG(TAG_True))) {
        heff_drop(v_x1_24959);
        v_t_24960 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24959);
        v_t_24960 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24961 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24962 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24963 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24962})));
    V v_t_24964 = (g_std_2edoc_2e_3c_3e(v_a_24961, v_t_24963));
    return (g_std_2edoc_2e_3c_3e(v_t_24960, v_t_24964));
  }
  case TAG_Op: {
    V v_t_24968 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24971;
    if ((heff_dup(v_t_24968) == NTAG(TAG_True))) {
      heff_drop(v_t_24968);
      v_t_24971 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24968);
      V v_t_24969 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24970 = heff_get_n(v_t_24969, 6, 9);
      if ((heff_dup(v_x1_24970) == NTAG(TAG_True))) {
        heff_drop(v_x1_24970);
        v_t_24971 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24970);
        v_t_24971 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24972 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24973 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24974 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24973})));
    V v_t_24975 = (g_std_2edoc_2e_3c_3e(v_a_24972, v_t_24974));
    return (g_std_2edoc_2e_3c_3e(v_t_24971, v_t_24975));
  }
  case TAG_Ops: {
    V v_t_24978 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24981;
    if ((heff_dup(v_t_24978) == NTAG(TAG_True))) {
      heff_drop(v_t_24978);
      v_t_24981 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24978);
      V v_t_24979 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24980 = heff_get_n(v_t_24979, 6, 9);
      if ((heff_dup(v_x1_24980) == NTAG(TAG_True))) {
        heff_drop(v_x1_24980);
        v_t_24981 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24980);
        v_t_24981 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24982 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24983 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24984 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24983})));
    V v_t_24985 = (g_std_2edoc_2e_3c_3e(v_a_24982, v_t_24984));
    return (g_std_2edoc_2e_3c_3e(v_t_24981, v_t_24985));
  }
  case TAG_OpRhs: {
    V v_t_24988 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_24991;
    if ((heff_dup(v_t_24988) == NTAG(TAG_True))) {
      heff_drop(v_t_24988);
      v_t_24991 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24988);
      V v_t_24989 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_24990 = heff_get_n(v_t_24989, 6, 9);
      if ((heff_dup(v_x1_24990) == NTAG(TAG_True))) {
        heff_drop(v_x1_24990);
        v_t_24991 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24990);
        v_t_24991 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24992 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_24993 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_24994 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24993})));
    V v_t_24995 = (g_std_2edoc_2e_3c_3e(v_a_24992, v_t_24994));
    return (g_std_2edoc_2e_3c_3e(v_t_24991, v_t_24995));
  }
  case TAG_Ann: {
    V v_t_24999 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241002;
    if ((heff_dup(v_t_24999) == NTAG(TAG_True))) {
      heff_drop(v_t_24999);
      v_t_241002 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24999);
      V v_t_241000 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241001 = heff_get_n(v_t_241000, 6, 9);
      if ((heff_dup(v_x1_241001) == NTAG(TAG_True))) {
        heff_drop(v_x1_241001);
        v_t_241002 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241001);
        v_t_241002 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241003 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241004 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241005 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241004})));
    V v_t_241006 = (g_std_2edoc_2e_3c_3e(v_a_241003, v_t_241005));
    return (g_std_2edoc_2e_3c_3e(v_t_241002, v_t_241006));
  }
  case TAG_BVar: {
    V v_t_241008 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241011;
    if ((heff_dup(v_t_241008) == NTAG(TAG_True))) {
      heff_drop(v_t_241008);
      v_t_241011 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241008);
      V v_t_241009 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241010 = heff_get_n(v_t_241009, 6, 9);
      if ((heff_dup(v_x1_241010) == NTAG(TAG_True))) {
        heff_drop(v_x1_241010);
        v_t_241011 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241010);
        v_t_241011 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241012 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241013 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241014 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241013})));
    V v_t_241015 = (g_std_2edoc_2e_3c_3e(v_a_241012, v_t_241014));
    return (g_std_2edoc_2e_3c_3e(v_t_241011, v_t_241015));
  }
  case TAG_BImp: {
    V v_t_241019 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241022;
    if ((heff_dup(v_t_241019) == NTAG(TAG_True))) {
      heff_drop(v_t_241019);
      v_t_241022 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241019);
      V v_t_241020 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241021 = heff_get_n(v_t_241020, 6, 9);
      if ((heff_dup(v_x1_241021) == NTAG(TAG_True))) {
        heff_drop(v_x1_241021);
        v_t_241022 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241021);
        v_t_241022 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241023 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241025 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241024})));
    V v_t_241026 = (g_std_2edoc_2e_3c_3e(v_a_241023, v_t_241025));
    return (g_std_2edoc_2e_3c_3e(v_t_241022, v_t_241026));
  }
  case TAG_BAnn: {
    V v_t_241032 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241035;
    if ((heff_dup(v_t_241032) == NTAG(TAG_True))) {
      heff_drop(v_t_241032);
      v_t_241035 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241032);
      V v_t_241033 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241034 = heff_get_n(v_t_241033, 6, 9);
      if ((heff_dup(v_x1_241034) == NTAG(TAG_True))) {
        heff_drop(v_x1_241034);
        v_t_241035 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241034);
        v_t_241035 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241036 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241037 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241038 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241037})));
    V v_t_241039 = (g_std_2edoc_2e_3c_3e(v_a_241036, v_t_241038));
    return (g_std_2edoc_2e_3c_3e(v_t_241035, v_t_241039));
  }
  case TAG_BPat: {
    V v_t_241041 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241044;
    if ((heff_dup(v_t_241041) == NTAG(TAG_True))) {
      heff_drop(v_t_241041);
      v_t_241044 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241041);
      V v_t_241042 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241043 = heff_get_n(v_t_241042, 6, 9);
      if ((heff_dup(v_x1_241043) == NTAG(TAG_True))) {
        heff_drop(v_x1_241043);
        v_t_241044 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241043);
        v_t_241044 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241045 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241046 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241047 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241046})));
    V v_t_241048 = (g_std_2edoc_2e_3c_3e(v_a_241045, v_t_241047));
    return (g_std_2edoc_2e_3c_3e(v_t_241044, v_t_241048));
  }
  case TAG_Lam: {
    V v_t_241053 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241056;
    if ((heff_dup(v_t_241053) == NTAG(TAG_True))) {
      heff_drop(v_t_241053);
      v_t_241056 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241053);
      V v_t_241054 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241055 = heff_get_n(v_t_241054, 6, 9);
      if ((heff_dup(v_x1_241055) == NTAG(TAG_True))) {
        heff_drop(v_x1_241055);
        v_t_241056 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241055);
        v_t_241056 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241057 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241058 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241059 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241058})));
    V v_t_241060 = (g_std_2edoc_2e_3c_3e(v_a_241057, v_t_241059));
    return (g_std_2edoc_2e_3c_3e(v_t_241056, v_t_241060));
  }
  case TAG_Case: {
    V v_t_241065 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241068;
    if ((heff_dup(v_t_241065) == NTAG(TAG_True))) {
      heff_drop(v_t_241065);
      v_t_241068 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241065);
      V v_t_241066 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241067 = heff_get_n(v_t_241066, 6, 9);
      if ((heff_dup(v_x1_241067) == NTAG(TAG_True))) {
        heff_drop(v_x1_241067);
        v_t_241068 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241067);
        v_t_241068 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241069 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241070 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241071 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241070})));
    V v_t_241072 = (g_std_2edoc_2e_3c_3e(v_a_241069, v_t_241071));
    return (g_std_2edoc_2e_3c_3e(v_t_241068, v_t_241072));
  }
  case TAG_EAlt: {
    V v_t_241076 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241079;
    if ((heff_dup(v_t_241076) == NTAG(TAG_True))) {
      heff_drop(v_t_241076);
      v_t_241079 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241076);
      V v_t_241077 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241078 = heff_get_n(v_t_241077, 6, 9);
      if ((heff_dup(v_x1_241078) == NTAG(TAG_True))) {
        heff_drop(v_x1_241078);
        v_t_241079 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241078);
        v_t_241079 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241080 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241081 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241082 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241081})));
    V v_t_241083 = (g_std_2edoc_2e_3c_3e(v_a_241080, v_t_241082));
    return (g_std_2edoc_2e_3c_3e(v_t_241079, v_t_241083));
  }
  case TAG_If: {
    V v_kw_241084 = heff_dup(heff_field(v_b_24773, 0));
    V v_c_241085 = heff_dup(heff_field(v_b_24773, 1));
    V v_th_241086 = heff_dup(heff_field(v_b_24773, 2));
    V v_a_241087 = heff_dup(heff_field(v_b_24773, 3));
    V v_el2_241088 = heff_dup(heff_field(v_b_24773, 4));
    V v_b2_241089 = heff_dup(heff_field(v_b_24773, 5));
    V v_t_241090 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241093;
    if ((heff_dup(v_t_241090) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24773, 6);
      heff_drop(v_t_241090);
      v_t_241093 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241090);
      V v_t_241091 = ({ V a_0 = v_b_24773; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24773, 6); r_; });
      V v_x1_241092 = heff_get_n(v_t_241091, 6, 9);
      if ((heff_dup(v_x1_241092) == NTAG(TAG_True))) {
        heff_drop(v_x1_241092);
        v_t_241093 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241092);
        v_t_241093 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241094 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_b_241095 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24771), v_kw_241084, v_c_241085, v_th_241086, v_a_241087}));
    V v_t_241096 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241095));
    V v_t_241097 = (g_std_2edoc_2e_3c_3e(v_a_241094, v_t_241096));
    V v_t_241098 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24771, v_el2_241088, v_b2_241089}));
    V v_t_241099 = (g_std_2edoc_2e_3c_3e(v_t_241097, v_t_241098));
    return (g_std_2edoc_2e_3c_3e(v_t_241093, v_t_241099));
  }
  case TAG_Do: {
    V v_t_241102 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241105;
    if ((heff_dup(v_t_241102) == NTAG(TAG_True))) {
      heff_drop(v_t_241102);
      v_t_241105 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241102);
      V v_t_241103 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241104 = heff_get_n(v_t_241103, 6, 9);
      if ((heff_dup(v_x1_241104) == NTAG(TAG_True))) {
        heff_drop(v_x1_241104);
        v_t_241105 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241104);
        v_t_241105 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241106 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241107 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241108 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241107})));
    V v_t_241109 = (g_std_2edoc_2e_3c_3e(v_a_241106, v_t_241108));
    return (g_std_2edoc_2e_3c_3e(v_t_241105, v_t_241109));
  }
  case TAG_ESBind: {
    V v_t_241113 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241116;
    if ((heff_dup(v_t_241113) == NTAG(TAG_True))) {
      heff_drop(v_t_241113);
      v_t_241116 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241113);
      V v_t_241114 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241115 = heff_get_n(v_t_241114, 6, 9);
      if ((heff_dup(v_x1_241115) == NTAG(TAG_True))) {
        heff_drop(v_x1_241115);
        v_t_241116 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241115);
        v_t_241116 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241117 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241119 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241118})));
    V v_t_241120 = (g_std_2edoc_2e_3c_3e(v_a_241117, v_t_241119));
    return (g_std_2edoc_2e_3c_3e(v_t_241116, v_t_241120));
  }
  case TAG_ELet: {
    V v_t_241127 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241130;
    if ((heff_dup(v_t_241127) == NTAG(TAG_True))) {
      heff_drop(v_t_241127);
      v_t_241130 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241127);
      V v_t_241128 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241129 = heff_get_n(v_t_241128, 6, 9);
      if ((heff_dup(v_x1_241129) == NTAG(TAG_True))) {
        heff_drop(v_x1_241129);
        v_t_241130 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241129);
        v_t_241130 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241131 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241132 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241133 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241132})));
    V v_t_241134 = (g_std_2edoc_2e_3c_3e(v_a_241131, v_t_241133));
    return (g_std_2edoc_2e_3c_3e(v_t_241130, v_t_241134));
  }
  case TAG_ELetElse: {
    V v_t_241142 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241145;
    if ((heff_dup(v_t_241142) == NTAG(TAG_True))) {
      heff_drop(v_t_241142);
      v_t_241145 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241142);
      V v_t_241143 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241144 = heff_get_n(v_t_241143, 6, 9);
      if ((heff_dup(v_x1_241144) == NTAG(TAG_True))) {
        heff_drop(v_x1_241144);
        v_t_241145 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241144);
        v_t_241145 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241146 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241147 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241148 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241147})));
    V v_t_241149 = (g_std_2edoc_2e_3c_3e(v_a_241146, v_t_241148));
    return (g_std_2edoc_2e_3c_3e(v_t_241145, v_t_241149));
  }
  case TAG_ELetMut: {
    V v_t_241156 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241159;
    if ((heff_dup(v_t_241156) == NTAG(TAG_True))) {
      heff_drop(v_t_241156);
      v_t_241159 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241156);
      V v_t_241157 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241158 = heff_get_n(v_t_241157, 6, 9);
      if ((heff_dup(v_x1_241158) == NTAG(TAG_True))) {
        heff_drop(v_x1_241158);
        v_t_241159 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241158);
        v_t_241159 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241160 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241162 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241161})));
    V v_t_241163 = (g_std_2edoc_2e_3c_3e(v_a_241160, v_t_241162));
    return (g_std_2edoc_2e_3c_3e(v_t_241159, v_t_241163));
  }
  case TAG_EAssign: {
    V v_t_241167 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241170;
    if ((heff_dup(v_t_241167) == NTAG(TAG_True))) {
      heff_drop(v_t_241167);
      v_t_241170 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241167);
      V v_t_241168 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241169 = heff_get_n(v_t_241168, 6, 9);
      if ((heff_dup(v_x1_241169) == NTAG(TAG_True))) {
        heff_drop(v_x1_241169);
        v_t_241170 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241169);
        v_t_241170 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241171 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241172 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241173 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241172})));
    V v_t_241174 = (g_std_2edoc_2e_3c_3e(v_a_241171, v_t_241173));
    return (g_std_2edoc_2e_3c_3e(v_t_241170, v_t_241174));
  }
  case TAG_EWhile: {
    V v_t_241179 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241182;
    if ((heff_dup(v_t_241179) == NTAG(TAG_True))) {
      heff_drop(v_t_241179);
      v_t_241182 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241179);
      V v_t_241180 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241181 = heff_get_n(v_t_241180, 6, 9);
      if ((heff_dup(v_x1_241181) == NTAG(TAG_True))) {
        heff_drop(v_x1_241181);
        v_t_241182 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241181);
        v_t_241182 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241184 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241185 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241184})));
    V v_t_241186 = (g_std_2edoc_2e_3c_3e(v_a_241183, v_t_241185));
    return (g_std_2edoc_2e_3c_3e(v_t_241182, v_t_241186));
  }
  case TAG_EFor: {
    V v_t_241193 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241196;
    if ((heff_dup(v_t_241193) == NTAG(TAG_True))) {
      heff_drop(v_t_241193);
      v_t_241196 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241193);
      V v_t_241194 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241195 = heff_get_n(v_t_241194, 6, 9);
      if ((heff_dup(v_x1_241195) == NTAG(TAG_True))) {
        heff_drop(v_x1_241195);
        v_t_241196 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241195);
        v_t_241196 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241197 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241198 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241199 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241198})));
    V v_t_241200 = (g_std_2edoc_2e_3c_3e(v_a_241197, v_t_241199));
    return (g_std_2edoc_2e_3c_3e(v_t_241196, v_t_241200));
  }
  case TAG_EJump: {
    V v_t_241202 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241205;
    if ((heff_dup(v_t_241202) == NTAG(TAG_True))) {
      heff_drop(v_t_241202);
      v_t_241205 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241202);
      V v_t_241203 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241204 = heff_get_n(v_t_241203, 6, 9);
      if ((heff_dup(v_x1_241204) == NTAG(TAG_True))) {
        heff_drop(v_x1_241204);
        v_t_241205 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241204);
        v_t_241205 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241206 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241207 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241208 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241207})));
    V v_t_241209 = (g_std_2edoc_2e_3c_3e(v_a_241206, v_t_241208));
    return (g_std_2edoc_2e_3c_3e(v_t_241205, v_t_241209));
  }
  case TAG_EReturn: {
    V v_t_241212 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241215;
    if ((heff_dup(v_t_241212) == NTAG(TAG_True))) {
      heff_drop(v_t_241212);
      v_t_241215 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241212);
      V v_t_241213 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241214 = heff_get_n(v_t_241213, 6, 9);
      if ((heff_dup(v_x1_241214) == NTAG(TAG_True))) {
        heff_drop(v_x1_241214);
        v_t_241215 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241214);
        v_t_241215 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241216 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241217 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241218 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241217})));
    V v_t_241219 = (g_std_2edoc_2e_3c_3e(v_a_241216, v_t_241218));
    return (g_std_2edoc_2e_3c_3e(v_t_241215, v_t_241219));
  }
  case TAG_ENest: {
    V v_t_241224 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241227;
    if ((heff_dup(v_t_241224) == NTAG(TAG_True))) {
      heff_drop(v_t_241224);
      v_t_241227 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241224);
      V v_t_241225 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241226 = heff_get_n(v_t_241225, 6, 9);
      if ((heff_dup(v_x1_241226) == NTAG(TAG_True))) {
        heff_drop(v_x1_241226);
        v_t_241227 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241226);
        v_t_241227 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241228 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241229 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241230 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241229})));
    V v_t_241231 = (g_std_2edoc_2e_3c_3e(v_a_241228, v_t_241230));
    return (g_std_2edoc_2e_3c_3e(v_t_241227, v_t_241231));
  }
  case TAG_EArrow: {
    V v_t_241234 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241237;
    if ((heff_dup(v_t_241234) == NTAG(TAG_True))) {
      heff_drop(v_t_241234);
      v_t_241237 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241234);
      V v_t_241235 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241236 = heff_get_n(v_t_241235, 6, 9);
      if ((heff_dup(v_x1_241236) == NTAG(TAG_True))) {
        heff_drop(v_x1_241236);
        v_t_241237 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241236);
        v_t_241237 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241238 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241239 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241240 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241239})));
    V v_t_241241 = (g_std_2edoc_2e_3c_3e(v_a_241238, v_t_241240));
    return (g_std_2edoc_2e_3c_3e(v_t_241237, v_t_241241));
  }
  case TAG_IfThen: {
    V v_t_241246 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241249;
    if ((heff_dup(v_t_241246) == NTAG(TAG_True))) {
      heff_drop(v_t_241246);
      v_t_241249 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241246);
      V v_t_241247 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241248 = heff_get_n(v_t_241247, 6, 9);
      if ((heff_dup(v_x1_241248) == NTAG(TAG_True))) {
        heff_drop(v_x1_241248);
        v_t_241249 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241248);
        v_t_241249 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241250 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241251 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241252 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241251})));
    V v_t_241253 = (g_std_2edoc_2e_3c_3e(v_a_241250, v_t_241252));
    return (g_std_2edoc_2e_3c_3e(v_t_241249, v_t_241253));
  }
  case TAG_ETry: {
    V v_t_241258 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241261;
    if ((heff_dup(v_t_241258) == NTAG(TAG_True))) {
      heff_drop(v_t_241258);
      v_t_241261 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241258);
      V v_t_241259 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241260 = heff_get_n(v_t_241259, 6, 9);
      if ((heff_dup(v_x1_241260) == NTAG(TAG_True))) {
        heff_drop(v_x1_241260);
        v_t_241261 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241260);
        v_t_241261 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241262 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241263 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241264 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241263})));
    V v_t_241265 = (g_std_2edoc_2e_3c_3e(v_a_241262, v_t_241264));
    return (g_std_2edoc_2e_3c_3e(v_t_241261, v_t_241265));
  }
  case TAG_ECatch: {
    V v_t_241270 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241273;
    if ((heff_dup(v_t_241270) == NTAG(TAG_True))) {
      heff_drop(v_t_241270);
      v_t_241273 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241270);
      V v_t_241271 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241272 = heff_get_n(v_t_241271, 6, 9);
      if ((heff_dup(v_x1_241272) == NTAG(TAG_True))) {
        heff_drop(v_x1_241272);
        v_t_241273 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241272);
        v_t_241273 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241274 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241275 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241276 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241275})));
    V v_t_241277 = (g_std_2edoc_2e_3c_3e(v_a_241274, v_t_241276));
    return (g_std_2edoc_2e_3c_3e(v_t_241273, v_t_241277));
  }
  case TAG_EWith: {
    V v_t_241284 = heff_dup(heff_rfield(v_el_24772, 6));
    V v_t_241287;
    if ((heff_dup(v_t_241284) == NTAG(TAG_True))) {
      heff_drop(v_t_241284);
      v_t_241287 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241284);
      V v_t_241285 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24773));
      V v_x1_241286 = heff_get_n(v_t_241285, 6, 9);
      if ((heff_dup(v_x1_241286) == NTAG(TAG_True))) {
        heff_drop(v_x1_241286);
        v_t_241287 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241286);
        v_t_241287 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241288 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24771), v_el_24772));
    V v_d_241289 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24771, v_b_24773}));
    V v_t_241290 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241289})));
    V v_t_241291 = (g_std_2edoc_2e_3c_3e(v_a_241288, v_t_241290));
    return (g_std_2edoc_2e_3c_3e(v_t_241287, v_t_241291));
  }
  default: return heff_nomatch(v_b_24773);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241303 = args[0];
  V v_one_241302 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241304 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241303));
  V v_x1_241305 = heff_get_n(v_t_241304, 6, 9);
  V v_t_241306;
  if ((heff_dup(v_x1_241305) == NTAG(TAG_True))) {
    heff_drop(v_x1_241305);
    v_t_241306 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241305);
    v_t_241306 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241307 = heff_tr(heff_call(v_one_241302, 1, (V[]){v_a_241303}));
  return (g_std_2edoc_2e_3c_3e(v_t_241306, v_t_241307));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241315 = args[0];
  V v_one_241314 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241316 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241315));
  V v_x1_241317 = heff_get_n(v_t_241316, 6, 9);
  V v_t_241318;
  if ((heff_dup(v_x1_241317) == NTAG(TAG_True))) {
    heff_drop(v_x1_241317);
    v_t_241318 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241317);
    v_t_241318 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241319 = heff_tr(heff_call(v_one_241314, 1, (V[]){v_a_241315}));
  return (g_std_2edoc_2e_3c_3e(v_t_241318, v_t_241319));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241328 = args[0];
  V v_one_241327 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241329 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241328));
  V v_x1_241330 = heff_get_n(v_t_241329, 6, 9);
  V v_t_241331;
  if ((heff_dup(v_x1_241330) == NTAG(TAG_True))) {
    heff_drop(v_x1_241330);
    v_t_241331 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241330);
    v_t_241331 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241332 = heff_tr(heff_call(v_one_241327, 1, (V[]){v_a_241328}));
  return (g_std_2edoc_2e_3c_3e(v_t_241331, v_t_241332));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241344 = args[0];
  V v_one_241343 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241345 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241344));
  V v_x1_241346 = heff_get_n(v_t_241345, 6, 9);
  V v_t_241347;
  if ((heff_dup(v_x1_241346) == NTAG(TAG_True))) {
    heff_drop(v_x1_241346);
    v_t_241347 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241346);
    v_t_241347 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241348 = heff_tr(heff_call(v_one_241343, 1, (V[]){v_a_241344}));
  return (g_std_2edoc_2e_3c_3e(v_t_241347, v_t_241348));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241359 = args[0];
  V v_one_241358 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241360 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241359));
  V v_x1_241361 = heff_get_n(v_t_241360, 6, 9);
  V v_t_241362;
  if ((heff_dup(v_x1_241361) == NTAG(TAG_True))) {
    heff_drop(v_x1_241361);
    v_t_241362 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241361);
    v_t_241362 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241363 = heff_tr(heff_call(v_one_241358, 1, (V[]){v_a_241359}));
  return (g_std_2edoc_2e_3c_3e(v_t_241362, v_t_241363));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241371 = args[0];
  V v_one_241370 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241372 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241371));
  V v_x1_241373 = heff_get_n(v_t_241372, 6, 9);
  V v_t_241374;
  if ((heff_dup(v_x1_241373) == NTAG(TAG_True))) {
    heff_drop(v_x1_241373);
    v_t_241374 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241373);
    v_t_241374 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241375 = heff_tr(heff_call(v_one_241370, 1, (V[]){v_a_241371}));
  return (g_std_2edoc_2e_3c_3e(v_t_241374, v_t_241375));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241385 = args[0];
  V v_one_241384 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241386 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241385));
  V v_x1_241387 = heff_get_n(v_t_241386, 6, 9);
  V v_t_241388;
  if ((heff_dup(v_x1_241387) == NTAG(TAG_True))) {
    heff_drop(v_x1_241387);
    v_t_241388 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241387);
    v_t_241388 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241389 = heff_tr(heff_call(v_one_241384, 1, (V[]){v_a_241385}));
  return (g_std_2edoc_2e_3c_3e(v_t_241388, v_t_241389));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241397 = args[0];
  V v_one_241396 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241398 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241397));
  V v_x1_241399 = heff_get_n(v_t_241398, 6, 9);
  V v_t_241400;
  if ((heff_dup(v_x1_241399) == NTAG(TAG_True))) {
    heff_drop(v_x1_241399);
    v_t_241400 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241399);
    v_t_241400 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241401 = heff_tr(heff_call(v_one_241396, 1, (V[]){v_a_241397}));
  return (g_std_2edoc_2e_3c_3e(v_t_241400, v_t_241401));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241410 = args[0];
  V v_one_241409 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241411 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241410));
  V v_x1_241412 = heff_get_n(v_t_241411, 6, 9);
  V v_t_241413;
  if ((heff_dup(v_x1_241412) == NTAG(TAG_True))) {
    heff_drop(v_x1_241412);
    v_t_241413 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241412);
    v_t_241413 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241414 = heff_tr(heff_call(v_one_241409, 1, (V[]){v_a_241410}));
  return (g_std_2edoc_2e_3c_3e(v_t_241413, v_t_241414));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241422 = args[0];
  V v_one_241421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241423 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241422));
  V v_x1_241424 = heff_get_n(v_t_241423, 6, 9);
  V v_t_241425;
  if ((heff_dup(v_x1_241424) == NTAG(TAG_True))) {
    heff_drop(v_x1_241424);
    v_t_241425 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241424);
    v_t_241425 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241426 = heff_tr(heff_call(v_one_241421, 1, (V[]){v_a_241422}));
  return (g_std_2edoc_2e_3c_3e(v_t_241425, v_t_241426));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241436 = args[0];
  V v_one_241435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241437 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241436));
  V v_x1_241438 = heff_get_n(v_t_241437, 6, 9);
  V v_t_241439;
  if ((heff_dup(v_x1_241438) == NTAG(TAG_True))) {
    heff_drop(v_x1_241438);
    v_t_241439 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241438);
    v_t_241439 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241440 = heff_tr(heff_call(v_one_241435, 1, (V[]){v_a_241436}));
  return (g_std_2edoc_2e_3c_3e(v_t_241439, v_t_241440));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241448 = args[0];
  V v_one_241447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241449 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241448));
  V v_x1_241450 = heff_get_n(v_t_241449, 6, 9);
  V v_t_241451;
  if ((heff_dup(v_x1_241450) == NTAG(TAG_True))) {
    heff_drop(v_x1_241450);
    v_t_241451 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241450);
    v_t_241451 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241452 = heff_tr(heff_call(v_one_241447, 1, (V[]){v_a_241448}));
  return (g_std_2edoc_2e_3c_3e(v_t_241451, v_t_241452));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241464 = args[0];
  V v_one_241463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241465 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241464));
  V v_x1_241466 = heff_get_n(v_t_241465, 6, 9);
  V v_t_241467;
  if ((heff_dup(v_x1_241466) == NTAG(TAG_True))) {
    heff_drop(v_x1_241466);
    v_t_241467 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241466);
    v_t_241467 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241468 = heff_tr(heff_call(v_one_241463, 1, (V[]){v_a_241464}));
  return (g_std_2edoc_2e_3c_3e(v_t_241467, v_t_241468));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241476 = args[0];
  V v_one_241475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241477 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241476));
  V v_x1_241478 = heff_get_n(v_t_241477, 6, 9);
  V v_t_241479;
  if ((heff_dup(v_x1_241478) == NTAG(TAG_True))) {
    heff_drop(v_x1_241478);
    v_t_241479 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241478);
    v_t_241479 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241480 = heff_tr(heff_call(v_one_241475, 1, (V[]){v_a_241476}));
  return (g_std_2edoc_2e_3c_3e(v_t_241479, v_t_241480));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241489 = args[0];
  V v_one_241488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241490 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241489));
  V v_x1_241491 = heff_get_n(v_t_241490, 6, 9);
  V v_t_241492;
  if ((heff_dup(v_x1_241491) == NTAG(TAG_True))) {
    heff_drop(v_x1_241491);
    v_t_241492 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241491);
    v_t_241492 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241493 = heff_tr(heff_call(v_one_241488, 1, (V[]){v_a_241489}));
  return (g_std_2edoc_2e_3c_3e(v_t_241492, v_t_241493));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241501 = args[0];
  V v_one_241500 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241502 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241501));
  V v_x1_241503 = heff_get_n(v_t_241502, 6, 9);
  V v_t_241504;
  if ((heff_dup(v_x1_241503) == NTAG(TAG_True))) {
    heff_drop(v_x1_241503);
    v_t_241504 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241503);
    v_t_241504 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241505 = heff_tr(heff_call(v_one_241500, 1, (V[]){v_a_241501}));
  return (g_std_2edoc_2e_3c_3e(v_t_241504, v_t_241505));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241516 = args[0];
  V v_one_241515 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241517 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241516));
  V v_x1_241518 = heff_get_n(v_t_241517, 6, 9);
  V v_t_241519;
  if ((heff_dup(v_x1_241518) == NTAG(TAG_True))) {
    heff_drop(v_x1_241518);
    v_t_241519 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241518);
    v_t_241519 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241520 = heff_tr(heff_call(v_one_241515, 1, (V[]){v_a_241516}));
  return (g_std_2edoc_2e_3c_3e(v_t_241519, v_t_241520));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241528 = args[0];
  V v_one_241527 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241529 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241528));
  V v_x1_241530 = heff_get_n(v_t_241529, 6, 9);
  V v_t_241531;
  if ((heff_dup(v_x1_241530) == NTAG(TAG_True))) {
    heff_drop(v_x1_241530);
    v_t_241531 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241530);
    v_t_241531 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241532 = heff_tr(heff_call(v_one_241527, 1, (V[]){v_a_241528}));
  return (g_std_2edoc_2e_3c_3e(v_t_241531, v_t_241532));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241541 = args[0];
  V v_one_241540 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241542 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241541));
  V v_x1_241543 = heff_get_n(v_t_241542, 6, 9);
  V v_t_241544;
  if ((heff_dup(v_x1_241543) == NTAG(TAG_True))) {
    heff_drop(v_x1_241543);
    v_t_241544 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241543);
    v_t_241544 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241545 = heff_tr(heff_call(v_one_241540, 1, (V[]){v_a_241541}));
  return (g_std_2edoc_2e_3c_3e(v_t_241544, v_t_241545));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241553 = args[0];
  V v_one_241552 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241554 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241553));
  V v_x1_241555 = heff_get_n(v_t_241554, 6, 9);
  V v_t_241556;
  if ((heff_dup(v_x1_241555) == NTAG(TAG_True))) {
    heff_drop(v_x1_241555);
    v_t_241556 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241555);
    v_t_241556 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241557 = heff_tr(heff_call(v_one_241552, 1, (V[]){v_a_241553}));
  return (g_std_2edoc_2e_3c_3e(v_t_241556, v_t_241557));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241566 = args[0];
  V v_one_241565 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241567 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241566));
  V v_x1_241568 = heff_get_n(v_t_241567, 6, 9);
  V v_t_241569;
  if ((heff_dup(v_x1_241568) == NTAG(TAG_True))) {
    heff_drop(v_x1_241568);
    v_t_241569 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241568);
    v_t_241569 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241570 = heff_tr(heff_call(v_one_241565, 1, (V[]){v_a_241566}));
  return (g_std_2edoc_2e_3c_3e(v_t_241569, v_t_241570));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241578 = args[0];
  V v_one_241577 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241579 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241578));
  V v_x1_241580 = heff_get_n(v_t_241579, 6, 9);
  V v_t_241581;
  if ((heff_dup(v_x1_241580) == NTAG(TAG_True))) {
    heff_drop(v_x1_241580);
    v_t_241581 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241580);
    v_t_241581 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241582 = heff_tr(heff_call(v_one_241577, 1, (V[]){v_a_241578}));
  return (g_std_2edoc_2e_3c_3e(v_t_241581, v_t_241582));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241593 = args[0];
  V v_one_241592 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241594 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241593));
  V v_x1_241595 = heff_get_n(v_t_241594, 6, 9);
  V v_t_241596;
  if ((heff_dup(v_x1_241595) == NTAG(TAG_True))) {
    heff_drop(v_x1_241595);
    v_t_241596 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241595);
    v_t_241596 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241597 = heff_tr(heff_call(v_one_241592, 1, (V[]){v_a_241593}));
  return (g_std_2edoc_2e_3c_3e(v_t_241596, v_t_241597));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241605 = args[0];
  V v_one_241604 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241606 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241605));
  V v_x1_241607 = heff_get_n(v_t_241606, 6, 9);
  V v_t_241608;
  if ((heff_dup(v_x1_241607) == NTAG(TAG_True))) {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241609 = heff_tr(heff_call(v_one_241604, 1, (V[]){v_a_241605}));
  return (g_std_2edoc_2e_3c_3e(v_t_241608, v_t_241609));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241617 = args[0];
  V v_one_241616 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241618 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241617));
  V v_x1_241619 = heff_get_n(v_t_241618, 6, 9);
  V v_t_241620;
  if ((heff_dup(v_x1_241619) == NTAG(TAG_True))) {
    heff_drop(v_x1_241619);
    v_t_241620 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241619);
    v_t_241620 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241621 = heff_tr(heff_call(v_one_241616, 1, (V[]){v_a_241617}));
  return (g_std_2edoc_2e_3c_3e(v_t_241620, v_t_241621));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241629 = args[0];
  V v_one_241628 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241630 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241629));
  V v_x1_241631 = heff_get_n(v_t_241630, 6, 9);
  V v_t_241632;
  if ((heff_dup(v_x1_241631) == NTAG(TAG_True))) {
    heff_drop(v_x1_241631);
    v_t_241632 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241631);
    v_t_241632 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241633 = heff_tr(heff_call(v_one_241628, 1, (V[]){v_a_241629}));
  return (g_std_2edoc_2e_3c_3e(v_t_241632, v_t_241633));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241641 = args[0];
  V v_one_241640 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241642 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241641));
  V v_x1_241643 = heff_get_n(v_t_241642, 6, 9);
  V v_t_241644;
  if ((heff_dup(v_x1_241643) == NTAG(TAG_True))) {
    heff_drop(v_x1_241643);
    v_t_241644 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241643);
    v_t_241644 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241645 = heff_tr(heff_call(v_one_241640, 1, (V[]){v_a_241641}));
  return (g_std_2edoc_2e_3c_3e(v_t_241644, v_t_241645));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241653 = args[0];
  V v_one_241652 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241654 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241653));
  V v_x1_241655 = heff_get_n(v_t_241654, 6, 9);
  V v_t_241656;
  if ((heff_dup(v_x1_241655) == NTAG(TAG_True))) {
    heff_drop(v_x1_241655);
    v_t_241656 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241655);
    v_t_241656 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241657 = heff_tr(heff_call(v_one_241652, 1, (V[]){v_a_241653}));
  return (g_std_2edoc_2e_3c_3e(v_t_241656, v_t_241657));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241665 = args[0];
  V v_one_241664 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241666 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241665));
  V v_x1_241667 = heff_get_n(v_t_241666, 6, 9);
  V v_t_241668;
  if ((heff_dup(v_x1_241667) == NTAG(TAG_True))) {
    heff_drop(v_x1_241667);
    v_t_241668 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241667);
    v_t_241668 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241669 = heff_tr(heff_call(v_one_241664, 1, (V[]){v_a_241665}));
  return (g_std_2edoc_2e_3c_3e(v_t_241668, v_t_241669));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241677 = args[0];
  V v_one_241676 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241678 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241677));
  V v_x1_241679 = heff_get_n(v_t_241678, 6, 9);
  V v_t_241680;
  if ((heff_dup(v_x1_241679) == NTAG(TAG_True))) {
    heff_drop(v_x1_241679);
    v_t_241680 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241679);
    v_t_241680 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241681 = heff_tr(heff_call(v_one_241676, 1, (V[]){v_a_241677}));
  return (g_std_2edoc_2e_3c_3e(v_t_241680, v_t_241681));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241689 = args[0];
  V v_one_241688 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241690 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241689));
  V v_x1_241691 = heff_get_n(v_t_241690, 6, 9);
  V v_t_241692;
  if ((heff_dup(v_x1_241691) == NTAG(TAG_True))) {
    heff_drop(v_x1_241691);
    v_t_241692 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241691);
    v_t_241692 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241693 = heff_tr(heff_call(v_one_241688, 1, (V[]){v_a_241689}));
  return (g_std_2edoc_2e_3c_3e(v_t_241692, v_t_241693));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241701 = args[0];
  V v_one_241700 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241702 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241701));
  V v_x1_241703 = heff_get_n(v_t_241702, 6, 9);
  V v_t_241704;
  if ((heff_dup(v_x1_241703) == NTAG(TAG_True))) {
    heff_drop(v_x1_241703);
    v_t_241704 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241703);
    v_t_241704 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241705 = heff_tr(heff_call(v_one_241700, 1, (V[]){v_a_241701}));
  return (g_std_2edoc_2e_3c_3e(v_t_241704, v_t_241705));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241713 = args[0];
  V v_one_241712 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241714 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241713));
  V v_x1_241715 = heff_get_n(v_t_241714, 6, 9);
  V v_t_241716;
  if ((heff_dup(v_x1_241715) == NTAG(TAG_True))) {
    heff_drop(v_x1_241715);
    v_t_241716 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241715);
    v_t_241716 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241717 = heff_tr(heff_call(v_one_241712, 1, (V[]){v_a_241713}));
  return (g_std_2edoc_2e_3c_3e(v_t_241716, v_t_241717));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241725 = args[0];
  V v_one_241724 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241726 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241725));
  V v_x1_241727 = heff_get_n(v_t_241726, 6, 9);
  V v_t_241728;
  if ((heff_dup(v_x1_241727) == NTAG(TAG_True))) {
    heff_drop(v_x1_241727);
    v_t_241728 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241727);
    v_t_241728 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241729 = heff_tr(heff_call(v_one_241724, 1, (V[]){v_a_241725}));
  return (g_std_2edoc_2e_3c_3e(v_t_241728, v_t_241729));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241738 = args[0];
  V v_one_241737 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241739 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241738));
  V v_x1_241740 = heff_get_n(v_t_241739, 6, 9);
  V v_t_241741;
  if ((heff_dup(v_x1_241740) == NTAG(TAG_True))) {
    heff_drop(v_x1_241740);
    v_t_241741 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241740);
    v_t_241741 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241742 = heff_tr(heff_call(v_one_241737, 1, (V[]){v_a_241738}));
  return (g_std_2edoc_2e_3c_3e(v_t_241741, v_t_241742));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241750 = args[0];
  V v_one_241749 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241751 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241750));
  V v_x1_241752 = heff_get_n(v_t_241751, 6, 9);
  V v_t_241753;
  if ((heff_dup(v_x1_241752) == NTAG(TAG_True))) {
    heff_drop(v_x1_241752);
    v_t_241753 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241752);
    v_t_241753 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241754 = heff_tr(heff_call(v_one_241749, 1, (V[]){v_a_241750}));
  return (g_std_2edoc_2e_3c_3e(v_t_241753, v_t_241754));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241762 = args[0];
  V v_one_241761 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241763 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241762));
  V v_x1_241764 = heff_get_n(v_t_241763, 6, 9);
  V v_t_241765;
  if ((heff_dup(v_x1_241764) == NTAG(TAG_True))) {
    heff_drop(v_x1_241764);
    v_t_241765 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241764);
    v_t_241765 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241766 = heff_tr(heff_call(v_one_241761, 1, (V[]){v_a_241762}));
  return (g_std_2edoc_2e_3c_3e(v_t_241765, v_t_241766));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241774 = args[0];
  V v_one_241773 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241775 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241774));
  V v_x1_241776 = heff_get_n(v_t_241775, 6, 9);
  V v_t_241777;
  if ((heff_dup(v_x1_241776) == NTAG(TAG_True))) {
    heff_drop(v_x1_241776);
    v_t_241777 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241776);
    v_t_241777 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241778 = heff_tr(heff_call(v_one_241773, 1, (V[]){v_a_241774}));
  return (g_std_2edoc_2e_3c_3e(v_t_241777, v_t_241778));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241786 = args[0];
  V v_one_241785 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241787 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241786));
  V v_x1_241788 = heff_get_n(v_t_241787, 6, 9);
  V v_t_241789;
  if ((heff_dup(v_x1_241788) == NTAG(TAG_True))) {
    heff_drop(v_x1_241788);
    v_t_241789 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241788);
    v_t_241789 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241790 = heff_tr(heff_call(v_one_241785, 1, (V[]){v_a_241786}));
  return (g_std_2edoc_2e_3c_3e(v_t_241789, v_t_241790));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241798 = args[0];
  V v_one_241797 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241799 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241798));
  V v_x1_241800 = heff_get_n(v_t_241799, 6, 9);
  V v_t_241801;
  if ((heff_dup(v_x1_241800) == NTAG(TAG_True))) {
    heff_drop(v_x1_241800);
    v_t_241801 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241800);
    v_t_241801 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241802 = heff_tr(heff_call(v_one_241797, 1, (V[]){v_a_241798}));
  return (g_std_2edoc_2e_3c_3e(v_t_241801, v_t_241802));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241811 = args[0];
  V v_one_241810 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241812 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241811));
  V v_x1_241813 = heff_get_n(v_t_241812, 6, 9);
  V v_t_241814;
  if ((heff_dup(v_x1_241813) == NTAG(TAG_True))) {
    heff_drop(v_x1_241813);
    v_t_241814 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241813);
    v_t_241814 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241815 = heff_tr(heff_call(v_one_241810, 1, (V[]){v_a_241811}));
  return (g_std_2edoc_2e_3c_3e(v_t_241814, v_t_241815));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241823 = args[0];
  V v_one_241822 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241824 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241823));
  V v_x1_241825 = heff_get_n(v_t_241824, 6, 9);
  V v_t_241826;
  if ((heff_dup(v_x1_241825) == NTAG(TAG_True))) {
    heff_drop(v_x1_241825);
    v_t_241826 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241825);
    v_t_241826 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241827 = heff_tr(heff_call(v_one_241822, 1, (V[]){v_a_241823}));
  return (g_std_2edoc_2e_3c_3e(v_t_241826, v_t_241827));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241834 = args[0];
  V v_one_241833 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241835 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241834));
  V v_x1_241836 = heff_get_n(v_t_241835, 6, 9);
  V v_t_241837;
  if ((heff_dup(v_x1_241836) == NTAG(TAG_True))) {
    heff_drop(v_x1_241836);
    v_t_241837 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241836);
    v_t_241837 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241838 = heff_tr(heff_call(v_one_241833, 1, (V[]){v_a_241834}));
  return (g_std_2edoc_2e_3c_3e(v_t_241837, v_t_241838));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241846 = args[0];
  V v_one_241845 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241847 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241846));
  V v_x1_241848 = heff_get_n(v_t_241847, 6, 9);
  V v_t_241849;
  if ((heff_dup(v_x1_241848) == NTAG(TAG_True))) {
    heff_drop(v_x1_241848);
    v_t_241849 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241848);
    v_t_241849 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241850 = heff_tr(heff_call(v_one_241845, 1, (V[]){v_a_241846}));
  return (g_std_2edoc_2e_3c_3e(v_t_241849, v_t_241850));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241859 = args[0];
  V v_one_241858 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241860 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241859));
  V v_x1_241861 = heff_get_n(v_t_241860, 6, 9);
  V v_t_241862;
  if ((heff_dup(v_x1_241861) == NTAG(TAG_True))) {
    heff_drop(v_x1_241861);
    v_t_241862 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241861);
    v_t_241862 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241863 = heff_tr(heff_call(v_one_241858, 1, (V[]){v_a_241859}));
  return (g_std_2edoc_2e_3c_3e(v_t_241862, v_t_241863));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241871 = args[0];
  V v_one_241870 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241872 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241871));
  V v_x1_241873 = heff_get_n(v_t_241872, 6, 9);
  V v_t_241874;
  if ((heff_dup(v_x1_241873) == NTAG(TAG_True))) {
    heff_drop(v_x1_241873);
    v_t_241874 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241873);
    v_t_241874 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241875 = heff_tr(heff_call(v_one_241870, 1, (V[]){v_a_241871}));
  return (g_std_2edoc_2e_3c_3e(v_t_241874, v_t_241875));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241886 = args[0];
  V v_one_241885 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241887 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241886));
  V v_x1_241888 = heff_get_n(v_t_241887, 6, 9);
  V v_t_241889;
  if ((heff_dup(v_x1_241888) == NTAG(TAG_True))) {
    heff_drop(v_x1_241888);
    v_t_241889 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241888);
    v_t_241889 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241890 = heff_tr(heff_call(v_one_241885, 1, (V[]){v_a_241886}));
  return (g_std_2edoc_2e_3c_3e(v_t_241889, v_t_241890));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241898 = args[0];
  V v_one_241897 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241899 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241898));
  V v_x1_241900 = heff_get_n(v_t_241899, 6, 9);
  V v_t_241901;
  if ((heff_dup(v_x1_241900) == NTAG(TAG_True))) {
    heff_drop(v_x1_241900);
    v_t_241901 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241900);
    v_t_241901 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241902 = heff_tr(heff_call(v_one_241897, 1, (V[]){v_a_241898}));
  return (g_std_2edoc_2e_3c_3e(v_t_241901, v_t_241902));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241909 = args[0];
  V v_one_241908 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241910 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241909));
  V v_x1_241911 = heff_get_n(v_t_241910, 6, 9);
  V v_t_241912;
  if ((heff_dup(v_x1_241911) == NTAG(TAG_True))) {
    heff_drop(v_x1_241911);
    v_t_241912 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241911);
    v_t_241912 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241913 = heff_tr(heff_call(v_one_241908, 1, (V[]){v_a_241909}));
  return (g_std_2edoc_2e_3c_3e(v_t_241912, v_t_241913));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241921 = args[0];
  V v_one_241920 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241922 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241921));
  V v_x1_241923 = heff_get_n(v_t_241922, 6, 9);
  V v_t_241924;
  if ((heff_dup(v_x1_241923) == NTAG(TAG_True))) {
    heff_drop(v_x1_241923);
    v_t_241924 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241923);
    v_t_241924 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241925 = heff_tr(heff_call(v_one_241920, 1, (V[]){v_a_241921}));
  return (g_std_2edoc_2e_3c_3e(v_t_241924, v_t_241925));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_a_241935 = args[0];
  V v_one_241934 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241936 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241935));
  V v_x1_241937 = heff_get_n(v_t_241936, 6, 9);
  V v_t_241938;
  if ((heff_dup(v_x1_241937) == NTAG(TAG_True))) {
    heff_drop(v_x1_241937);
    v_t_241938 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241937);
    v_t_241938 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241939 = heff_tr(heff_call(v_one_241934, 1, (V[]){v_a_241935}));
  return (g_std_2edoc_2e_3c_3e(v_t_241938, v_t_241939));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_a_241947 = args[0];
  V v_one_241946 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241948 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241947));
  V v_x1_241949 = heff_get_n(v_t_241948, 6, 9);
  V v_t_241950;
  if ((heff_dup(v_x1_241949) == NTAG(TAG_True))) {
    heff_drop(v_x1_241949);
    v_t_241950 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241949);
    v_t_241950 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241951 = heff_tr(heff_call(v_one_241946, 1, (V[]){v_a_241947}));
  return (g_std_2edoc_2e_3c_3e(v_t_241950, v_t_241951));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_a_241961 = args[0];
  V v_one_241960 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241962 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241961));
  V v_x1_241963 = heff_get_n(v_t_241962, 6, 9);
  V v_t_241964;
  if ((heff_dup(v_x1_241963) == NTAG(TAG_True))) {
    heff_drop(v_x1_241963);
    v_t_241964 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241963);
    v_t_241964 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241965 = heff_tr(heff_call(v_one_241960, 1, (V[]){v_a_241961}));
  return (g_std_2edoc_2e_3c_3e(v_t_241964, v_t_241965));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_a_241973 = args[0];
  V v_one_241972 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241974 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241973));
  V v_x1_241975 = heff_get_n(v_t_241974, 6, 9);
  V v_t_241976;
  if ((heff_dup(v_x1_241975) == NTAG(TAG_True))) {
    heff_drop(v_x1_241975);
    v_t_241976 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241975);
    v_t_241976 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241977 = heff_tr(heff_call(v_one_241972, 1, (V[]){v_a_241973}));
  return (g_std_2edoc_2e_3c_3e(v_t_241976, v_t_241977));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_a_241986 = args[0];
  V v_one_241985 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241987 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241986));
  V v_x1_241988 = heff_get_n(v_t_241987, 6, 9);
  V v_t_241989;
  if ((heff_dup(v_x1_241988) == NTAG(TAG_True))) {
    heff_drop(v_x1_241988);
    v_t_241989 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241988);
    v_t_241989 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241990 = heff_tr(heff_call(v_one_241985, 1, (V[]){v_a_241986}));
  return (g_std_2edoc_2e_3c_3e(v_t_241989, v_t_241990));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_a_241998 = args[0];
  V v_one_241997 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241999 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241998));
  V v_x1_242000 = heff_get_n(v_t_241999, 6, 9);
  V v_t_242001;
  if ((heff_dup(v_x1_242000) == NTAG(TAG_True))) {
    heff_drop(v_x1_242000);
    v_t_242001 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242000);
    v_t_242001 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242002 = heff_tr(heff_call(v_one_241997, 1, (V[]){v_a_241998}));
  return (g_std_2edoc_2e_3c_3e(v_t_242001, v_t_242002));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_a_242014 = args[0];
  V v_one_242013 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242015 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242014));
  V v_x1_242016 = heff_get_n(v_t_242015, 6, 9);
  V v_t_242017;
  if ((heff_dup(v_x1_242016) == NTAG(TAG_True))) {
    heff_drop(v_x1_242016);
    v_t_242017 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242016);
    v_t_242017 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242018 = heff_tr(heff_call(v_one_242013, 1, (V[]){v_a_242014}));
  return (g_std_2edoc_2e_3c_3e(v_t_242017, v_t_242018));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_a_242026 = args[0];
  V v_one_242025 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242027 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242026));
  V v_x1_242028 = heff_get_n(v_t_242027, 6, 9);
  V v_t_242029;
  if ((heff_dup(v_x1_242028) == NTAG(TAG_True))) {
    heff_drop(v_x1_242028);
    v_t_242029 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242028);
    v_t_242029 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242030 = heff_tr(heff_call(v_one_242025, 1, (V[]){v_a_242026}));
  return (g_std_2edoc_2e_3c_3e(v_t_242029, v_t_242030));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_a_242038 = args[0];
  V v_one_242037 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242039 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242038));
  V v_x1_242040 = heff_get_n(v_t_242039, 6, 9);
  V v_t_242041;
  if ((heff_dup(v_x1_242040) == NTAG(TAG_True))) {
    heff_drop(v_x1_242040);
    v_t_242041 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242040);
    v_t_242041 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242042 = heff_tr(heff_call(v_one_242037, 1, (V[]){v_a_242038}));
  return (g_std_2edoc_2e_3c_3e(v_t_242041, v_t_242042));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_a_242050 = args[0];
  V v_one_242049 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242051 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242050));
  V v_x1_242052 = heff_get_n(v_t_242051, 6, 9);
  V v_t_242053;
  if ((heff_dup(v_x1_242052) == NTAG(TAG_True))) {
    heff_drop(v_x1_242052);
    v_t_242053 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242052);
    v_t_242053 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242054 = heff_tr(heff_call(v_one_242049, 1, (V[]){v_a_242050}));
  return (g_std_2edoc_2e_3c_3e(v_t_242053, v_t_242054));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_a_242063 = args[0];
  V v_one_242062 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242064 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242063));
  V v_x1_242065 = heff_get_n(v_t_242064, 6, 9);
  V v_t_242066;
  if ((heff_dup(v_x1_242065) == NTAG(TAG_True))) {
    heff_drop(v_x1_242065);
    v_t_242066 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242065);
    v_t_242066 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242067 = heff_tr(heff_call(v_one_242062, 1, (V[]){v_a_242063}));
  return (g_std_2edoc_2e_3c_3e(v_t_242066, v_t_242067));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args) {
  V v_a_242075 = args[0];
  V v_one_242074 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242076 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242075));
  V v_x1_242077 = heff_get_n(v_t_242076, 6, 9);
  V v_t_242078;
  if ((heff_dup(v_x1_242077) == NTAG(TAG_True))) {
    heff_drop(v_x1_242077);
    v_t_242078 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242077);
    v_t_242078 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242079 = heff_tr(heff_call(v_one_242074, 1, (V[]){v_a_242075}));
  return (g_std_2edoc_2e_3c_3e(v_t_242078, v_t_242079));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args) {
  V v_a_242091 = args[0];
  V v_one_242090 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242092 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242091));
  V v_x1_242093 = heff_get_n(v_t_242092, 6, 9);
  V v_t_242094;
  if ((heff_dup(v_x1_242093) == NTAG(TAG_True))) {
    heff_drop(v_x1_242093);
    v_t_242094 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242093);
    v_t_242094 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242095 = heff_tr(heff_call(v_one_242090, 1, (V[]){v_a_242091}));
  return (g_std_2edoc_2e_3c_3e(v_t_242094, v_t_242095));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args) {
  V v_a_242103 = args[0];
  V v_one_242102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242104 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242103));
  V v_x1_242105 = heff_get_n(v_t_242104, 6, 9);
  V v_t_242106;
  if ((heff_dup(v_x1_242105) == NTAG(TAG_True))) {
    heff_drop(v_x1_242105);
    v_t_242106 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242105);
    v_t_242106 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242107 = heff_tr(heff_call(v_one_242102, 1, (V[]){v_a_242103}));
  return (g_std_2edoc_2e_3c_3e(v_t_242106, v_t_242107));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args) {
  V v_a_242120 = args[0];
  V v_one_242119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242121 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242120));
  V v_x1_242122 = heff_get_n(v_t_242121, 6, 9);
  V v_t_242123;
  if ((heff_dup(v_x1_242122) == NTAG(TAG_True))) {
    heff_drop(v_x1_242122);
    v_t_242123 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242122);
    v_t_242123 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242124 = heff_tr(heff_call(v_one_242119, 1, (V[]){v_a_242120}));
  return (g_std_2edoc_2e_3c_3e(v_t_242123, v_t_242124));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args) {
  V v_a_242132 = args[0];
  V v_one_242131 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242133 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242132));
  V v_x1_242134 = heff_get_n(v_t_242133, 6, 9);
  V v_t_242135;
  if ((heff_dup(v_x1_242134) == NTAG(TAG_True))) {
    heff_drop(v_x1_242134);
    v_t_242135 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242134);
    v_t_242135 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242136 = heff_tr(heff_call(v_one_242131, 1, (V[]){v_a_242132}));
  return (g_std_2edoc_2e_3c_3e(v_t_242135, v_t_242136));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args) {
  V v_a_242148 = args[0];
  V v_one_242147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242149 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242148));
  V v_x1_242150 = heff_get_n(v_t_242149, 6, 9);
  V v_t_242151;
  if ((heff_dup(v_x1_242150) == NTAG(TAG_True))) {
    heff_drop(v_x1_242150);
    v_t_242151 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242150);
    v_t_242151 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242152 = heff_tr(heff_call(v_one_242147, 1, (V[]){v_a_242148}));
  return (g_std_2edoc_2e_3c_3e(v_t_242151, v_t_242152));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args) {
  V v_a_242160 = args[0];
  V v_one_242159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242161 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242160));
  V v_x1_242162 = heff_get_n(v_t_242161, 6, 9);
  V v_t_242163;
  if ((heff_dup(v_x1_242162) == NTAG(TAG_True))) {
    heff_drop(v_x1_242162);
    v_t_242163 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242162);
    v_t_242163 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242164 = heff_tr(heff_call(v_one_242159, 1, (V[]){v_a_242160}));
  return (g_std_2edoc_2e_3c_3e(v_t_242163, v_t_242164));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args) {
  V v_a_242173 = args[0];
  V v_one_242172 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242174 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242173));
  V v_x1_242175 = heff_get_n(v_t_242174, 6, 9);
  V v_t_242176;
  if ((heff_dup(v_x1_242175) == NTAG(TAG_True))) {
    heff_drop(v_x1_242175);
    v_t_242176 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242175);
    v_t_242176 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242177 = heff_tr(heff_call(v_one_242172, 1, (V[]){v_a_242173}));
  return (g_std_2edoc_2e_3c_3e(v_t_242176, v_t_242177));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args) {
  V v_a_242185 = args[0];
  V v_one_242184 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242186 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242185));
  V v_x1_242187 = heff_get_n(v_t_242186, 6, 9);
  V v_t_242188;
  if ((heff_dup(v_x1_242187) == NTAG(TAG_True))) {
    heff_drop(v_x1_242187);
    v_t_242188 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242187);
    v_t_242188 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242189 = heff_tr(heff_call(v_one_242184, 1, (V[]){v_a_242185}));
  return (g_std_2edoc_2e_3c_3e(v_t_242188, v_t_242189));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args) {
  V v_a_242199 = args[0];
  V v_one_242198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242200 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242199));
  V v_x1_242201 = heff_get_n(v_t_242200, 6, 9);
  V v_t_242202;
  if ((heff_dup(v_x1_242201) == NTAG(TAG_True))) {
    heff_drop(v_x1_242201);
    v_t_242202 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242201);
    v_t_242202 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242203 = heff_tr(heff_call(v_one_242198, 1, (V[]){v_a_242199}));
  return (g_std_2edoc_2e_3c_3e(v_t_242202, v_t_242203));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args) {
  V v_a_242211 = args[0];
  V v_one_242210 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242212 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242211));
  V v_x1_242213 = heff_get_n(v_t_242212, 6, 9);
  V v_t_242214;
  if ((heff_dup(v_x1_242213) == NTAG(TAG_True))) {
    heff_drop(v_x1_242213);
    v_t_242214 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242213);
    v_t_242214 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242215 = heff_tr(heff_call(v_one_242210, 1, (V[]){v_a_242211}));
  return (g_std_2edoc_2e_3c_3e(v_t_242214, v_t_242215));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args) {
  V v_a_242227 = args[0];
  V v_one_242226 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242228 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242227));
  V v_x1_242229 = heff_get_n(v_t_242228, 6, 9);
  V v_t_242230;
  if ((heff_dup(v_x1_242229) == NTAG(TAG_True))) {
    heff_drop(v_x1_242229);
    v_t_242230 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242229);
    v_t_242230 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242231 = heff_tr(heff_call(v_one_242226, 1, (V[]){v_a_242227}));
  return (g_std_2edoc_2e_3c_3e(v_t_242230, v_t_242231));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args) {
  V v_a_242239 = args[0];
  V v_one_242238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242240 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242239));
  V v_x1_242241 = heff_get_n(v_t_242240, 6, 9);
  V v_t_242242;
  if ((heff_dup(v_x1_242241) == NTAG(TAG_True))) {
    heff_drop(v_x1_242241);
    v_t_242242 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242241);
    v_t_242242 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242243 = heff_tr(heff_call(v_one_242238, 1, (V[]){v_a_242239}));
  return (g_std_2edoc_2e_3c_3e(v_t_242242, v_t_242243));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args) {
  V v_a_242250 = args[0];
  V v_one_242249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242251 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242250));
  V v_x1_242252 = heff_get_n(v_t_242251, 6, 9);
  V v_t_242253;
  if ((heff_dup(v_x1_242252) == NTAG(TAG_True))) {
    heff_drop(v_x1_242252);
    v_t_242253 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242252);
    v_t_242253 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242254 = heff_tr(heff_call(v_one_242249, 1, (V[]){v_a_242250}));
  return (g_std_2edoc_2e_3c_3e(v_t_242253, v_t_242254));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args) {
  V v_a_242262 = args[0];
  V v_one_242261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242263 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242262));
  V v_x1_242264 = heff_get_n(v_t_242263, 6, 9);
  V v_t_242265;
  if ((heff_dup(v_x1_242264) == NTAG(TAG_True))) {
    heff_drop(v_x1_242264);
    v_t_242265 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242264);
    v_t_242265 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242266 = heff_tr(heff_call(v_one_242261, 1, (V[]){v_a_242262}));
  return (g_std_2edoc_2e_3c_3e(v_t_242265, v_t_242266));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args) {
  V v_a_242274 = args[0];
  V v_one_242273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242275 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242274));
  V v_x1_242276 = heff_get_n(v_t_242275, 6, 9);
  V v_t_242277;
  if ((heff_dup(v_x1_242276) == NTAG(TAG_True))) {
    heff_drop(v_x1_242276);
    v_t_242277 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242276);
    v_t_242277 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242278 = heff_tr(heff_call(v_one_242273, 1, (V[]){v_a_242274}));
  return (g_std_2edoc_2e_3c_3e(v_t_242277, v_t_242278));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args) {
  V v_a_242286 = args[0];
  V v_one_242285 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242287 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242286));
  V v_x1_242288 = heff_get_n(v_t_242287, 6, 9);
  V v_t_242289;
  if ((heff_dup(v_x1_242288) == NTAG(TAG_True))) {
    heff_drop(v_x1_242288);
    v_t_242289 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242288);
    v_t_242289 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242290 = heff_tr(heff_call(v_one_242285, 1, (V[]){v_a_242286}));
  return (g_std_2edoc_2e_3c_3e(v_t_242289, v_t_242290));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args) {
  V v_a_242300 = args[0];
  V v_one_242299 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242301 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242300));
  V v_x1_242302 = heff_get_n(v_t_242301, 6, 9);
  V v_t_242303;
  if ((heff_dup(v_x1_242302) == NTAG(TAG_True))) {
    heff_drop(v_x1_242302);
    v_t_242303 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242302);
    v_t_242303 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242304 = heff_tr(heff_call(v_one_242299, 1, (V[]){v_a_242300}));
  return (g_std_2edoc_2e_3c_3e(v_t_242303, v_t_242304));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args) {
  V v_a_242312 = args[0];
  V v_one_242311 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242313 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242312));
  V v_x1_242314 = heff_get_n(v_t_242313, 6, 9);
  V v_t_242315;
  if ((heff_dup(v_x1_242314) == NTAG(TAG_True))) {
    heff_drop(v_x1_242314);
    v_t_242315 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242314);
    v_t_242315 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242316 = heff_tr(heff_call(v_one_242311, 1, (V[]){v_a_242312}));
  return (g_std_2edoc_2e_3c_3e(v_t_242315, v_t_242316));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args) {
  V v_a_242324 = args[0];
  V v_one_242323 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242325 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242324));
  V v_x1_242326 = heff_get_n(v_t_242325, 6, 9);
  V v_t_242327;
  if ((heff_dup(v_x1_242326) == NTAG(TAG_True))) {
    heff_drop(v_x1_242326);
    v_t_242327 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242326);
    v_t_242327 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242328 = heff_tr(heff_call(v_one_242323, 1, (V[]){v_a_242324}));
  return (g_std_2edoc_2e_3c_3e(v_t_242327, v_t_242328));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args) {
  V v_a_242336 = args[0];
  V v_one_242335 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242337 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242336));
  V v_x1_242338 = heff_get_n(v_t_242337, 6, 9);
  V v_t_242339;
  if ((heff_dup(v_x1_242338) == NTAG(TAG_True))) {
    heff_drop(v_x1_242338);
    v_t_242339 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242338);
    v_t_242339 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242340 = heff_tr(heff_call(v_one_242335, 1, (V[]){v_a_242336}));
  return (g_std_2edoc_2e_3c_3e(v_t_242339, v_t_242340));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args) {
  V v_a_242350 = args[0];
  V v_one_242349 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242351 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242350));
  V v_x1_242352 = heff_get_n(v_t_242351, 6, 9);
  V v_t_242353;
  if ((heff_dup(v_x1_242352) == NTAG(TAG_True))) {
    heff_drop(v_x1_242352);
    v_t_242353 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242352);
    v_t_242353 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242354 = heff_tr(heff_call(v_one_242349, 1, (V[]){v_a_242350}));
  return (g_std_2edoc_2e_3c_3e(v_t_242353, v_t_242354));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args) {
  V v_a_242362 = args[0];
  V v_one_242361 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242363 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242362));
  V v_x1_242364 = heff_get_n(v_t_242363, 6, 9);
  V v_t_242365;
  if ((heff_dup(v_x1_242364) == NTAG(TAG_True))) {
    heff_drop(v_x1_242364);
    v_t_242365 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242364);
    v_t_242365 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242366 = heff_tr(heff_call(v_one_242361, 1, (V[]){v_a_242362}));
  return (g_std_2edoc_2e_3c_3e(v_t_242365, v_t_242366));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args) {
  V v_a_242376 = args[0];
  V v_one_242375 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242377 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242376));
  V v_x1_242378 = heff_get_n(v_t_242377, 6, 9);
  V v_t_242379;
  if ((heff_dup(v_x1_242378) == NTAG(TAG_True))) {
    heff_drop(v_x1_242378);
    v_t_242379 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242378);
    v_t_242379 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242380 = heff_tr(heff_call(v_one_242375, 1, (V[]){v_a_242376}));
  return (g_std_2edoc_2e_3c_3e(v_t_242379, v_t_242380));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args) {
  V v_a_242388 = args[0];
  V v_one_242387 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242389 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242388));
  V v_x1_242390 = heff_get_n(v_t_242389, 6, 9);
  V v_t_242391;
  if ((heff_dup(v_x1_242390) == NTAG(TAG_True))) {
    heff_drop(v_x1_242390);
    v_t_242391 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242390);
    v_t_242391 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242392 = heff_tr(heff_call(v_one_242387, 1, (V[]){v_a_242388}));
  return (g_std_2edoc_2e_3c_3e(v_t_242391, v_t_242392));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args) {
  V v_a_242402 = args[0];
  V v_one_242401 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242403 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242402));
  V v_x1_242404 = heff_get_n(v_t_242403, 6, 9);
  V v_t_242405;
  if ((heff_dup(v_x1_242404) == NTAG(TAG_True))) {
    heff_drop(v_x1_242404);
    v_t_242405 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242404);
    v_t_242405 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242406 = heff_tr(heff_call(v_one_242401, 1, (V[]){v_a_242402}));
  return (g_std_2edoc_2e_3c_3e(v_t_242405, v_t_242406));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args) {
  V v_a_242414 = args[0];
  V v_one_242413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242415 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242414));
  V v_x1_242416 = heff_get_n(v_t_242415, 6, 9);
  V v_t_242417;
  if ((heff_dup(v_x1_242416) == NTAG(TAG_True))) {
    heff_drop(v_x1_242416);
    v_t_242417 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242416);
    v_t_242417 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242418 = heff_tr(heff_call(v_one_242413, 1, (V[]){v_a_242414}));
  return (g_std_2edoc_2e_3c_3e(v_t_242417, v_t_242418));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args) {
  V v_a_242430 = args[0];
  V v_one_242429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242431 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242430));
  V v_x1_242432 = heff_get_n(v_t_242431, 6, 9);
  V v_t_242433;
  if ((heff_dup(v_x1_242432) == NTAG(TAG_True))) {
    heff_drop(v_x1_242432);
    v_t_242433 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242432);
    v_t_242433 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242434 = heff_tr(heff_call(v_one_242429, 1, (V[]){v_a_242430}));
  return (g_std_2edoc_2e_3c_3e(v_t_242433, v_t_242434));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args) {
  V v_a_242442 = args[0];
  V v_one_242441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242443 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242442));
  V v_x1_242444 = heff_get_n(v_t_242443, 6, 9);
  V v_t_242445;
  if ((heff_dup(v_x1_242444) == NTAG(TAG_True))) {
    heff_drop(v_x1_242444);
    v_t_242445 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242444);
    v_t_242445 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242446 = heff_tr(heff_call(v_one_242441, 1, (V[]){v_a_242442}));
  return (g_std_2edoc_2e_3c_3e(v_t_242445, v_t_242446));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_env_241292 = args[0];
  V v_h_241293 = args[1];
  V v_args_241294 = args[2];
  V v_x1_241295 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_241294)));
  switch (heff_tag_of(v_x1_241295)) {
  case TAG_Nil: {
    heff_drop(v_args_241294);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241292;
    args[1] = v_h_241293;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_241296 = heff_field(v_x1_241295, 0);
    V v_rev_241297 = heff_field(v_x1_241295, 1);
    V v_ru_24x1_241295_24Cons = heff_take_reuse_n(v_x1_241295, 3ULL, 2);
    V v_init2_241298 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_241297));
    switch (heff_tag_of(v_x_241296)) {
    case TAG_Atom: {
      V v_t_241300 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241300) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241300);
        V v_t_241301 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241302 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241308 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241302}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241309 = (g_std_2edoc_2e_3c_3e(v_t_241301, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241308})));
        V v_a_241310 = (g_std_2edoc_2egroup(v_t_241309));
        V v_b_241311 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241312 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_241311));
        return (g_std_2edoc_2e_3c_3e(v_a_241310, v_t_241312));
      } else {
        heff_drop_tag(v_x_241296, 1);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241300);
        V v_t_241313 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241314 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241320 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241314}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241321 = (g_std_2edoc_2e_3c_3e(v_t_241313, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241320})));
        return (g_std_2edoc_2egroup(v_t_241321));
      }
    }
    case TAG_EParen: {
      V v_o_241322 = heff_field(v_x_241296, 0);
      V v_e_241323 = heff_field(v_x_241296, 1);
      V v_c_241324 = heff_field(v_x_241296, 2);
      heff_take_n(v_x_241296, 7ULL, 3);
      V v_t_241325 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_241323));
      if ((heff_dup(v_t_241325) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241325);
        V v_t_241326 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241327 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241333 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241327}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241334 = (g_std_2edoc_2e_3c_3e(v_t_241326, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241333})));
        V v_a_241335 = (g_std_2edoc_2egroup(v_t_241334));
        V v_b_241336 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241292), v_o_241322));
        V v_t_241337 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str111)}), v_b_241336));
        V v_t_241338 = (g_std_2edoc_2e_3c_3e(v_a_241335, v_t_241337));
        V v_t_241339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_e_241323}));
        V v_t_241340 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241292, v_c_241324));
        V v_t_241341 = (g_std_2edoc_2e_3c_3e(v_t_241339, v_t_241340));
        return (g_std_2edoc_2e_3c_3e(v_t_241338, v_t_241341));
      } else {
        heff_drop(v_init2_241298);
        heff_drop(v_o_241322);
        heff_drop(v_e_241323);
        heff_drop(v_c_241324);
        heff_drop(v_t_241325);
        V v_t_241342 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241343 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241349 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241343}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241350 = (g_std_2edoc_2e_3c_3e(v_t_241342, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241349})));
        return (g_std_2edoc_2egroup(v_t_241350));
      }
    }
    case TAG_Named: {
      V v_t_241356 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241356) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241356);
        V v_t_241357 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241358 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241364 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241358}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241365 = (g_std_2edoc_2e_3c_3e(v_t_241357, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241364})));
        V v_a_241366 = (g_std_2edoc_2egroup(v_t_241365));
        V v_b_241367 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241368 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str112)}), v_b_241367));
        return (g_std_2edoc_2e_3c_3e(v_a_241366, v_t_241368));
      } else {
        heff_drop_tag(v_x_241296, 5);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241356);
        V v_t_241369 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241370 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241376 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241370}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241377 = (g_std_2edoc_2e_3c_3e(v_t_241369, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241376})));
        return (g_std_2edoc_2egroup(v_t_241377));
      }
    }
    case TAG_Tup: {
      V v_t_241382 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241382) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241382);
        V v_t_241383 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241384 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241390 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241384}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241391 = (g_std_2edoc_2e_3c_3e(v_t_241383, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241390})));
        V v_a_241392 = (g_std_2edoc_2egroup(v_t_241391));
        V v_b_241393 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241394 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str113)}), v_b_241393));
        return (g_std_2edoc_2e_3c_3e(v_a_241392, v_t_241394));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241382);
        V v_t_241395 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241396 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241402 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241396}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241403 = (g_std_2edoc_2e_3c_3e(v_t_241395, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241402})));
        return (g_std_2edoc_2egroup(v_t_241403));
      }
    }
    case TAG_Seg: {
      V v_t_241407 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241407) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241407);
        V v_t_241408 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241409 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241415 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241409}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241416 = (g_std_2edoc_2e_3c_3e(v_t_241408, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241415})));
        V v_a_241417 = (g_std_2edoc_2egroup(v_t_241416));
        V v_b_241418 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241419 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str114)}), v_b_241418));
        return (g_std_2edoc_2e_3c_3e(v_a_241417, v_t_241419));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241407);
        V v_t_241420 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241427 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241421}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241428 = (g_std_2edoc_2e_3c_3e(v_t_241420, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241427})));
        return (g_std_2edoc_2egroup(v_t_241428));
      }
    }
    case TAG_Braces: {
      V v_t_241433 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241433) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241433);
        V v_t_241434 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241435 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241441 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241435}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241442 = (g_std_2edoc_2e_3c_3e(v_t_241434, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241441})));
        V v_a_241443 = (g_std_2edoc_2egroup(v_t_241442));
        V v_b_241444 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241445 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str115)}), v_b_241444));
        return (g_std_2edoc_2e_3c_3e(v_a_241443, v_t_241445));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241433);
        V v_t_241446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241447 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241453 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241447}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241454 = (g_std_2edoc_2e_3c_3e(v_t_241446, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241453})));
        return (g_std_2edoc_2egroup(v_t_241454));
      }
    }
    case TAG_Update: {
      V v_t_241461 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241461) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241461);
        V v_t_241462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241463 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241469 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241463}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241470 = (g_std_2edoc_2e_3c_3e(v_t_241462, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241469})));
        V v_a_241471 = (g_std_2edoc_2egroup(v_t_241470));
        V v_b_241472 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241473 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str116)}), v_b_241472));
        return (g_std_2edoc_2e_3c_3e(v_a_241471, v_t_241473));
      } else {
        heff_drop_tag(v_x_241296, 6);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241461);
        V v_t_241474 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241475 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241481 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241475}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241482 = (g_std_2edoc_2e_3c_3e(v_t_241474, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241481})));
        return (g_std_2edoc_2egroup(v_t_241482));
      }
    }
    case TAG_EUSet: {
      V v_t_241486 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241486) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241486);
        V v_t_241487 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241488 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241494 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241488}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241495 = (g_std_2edoc_2e_3c_3e(v_t_241487, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241494})));
        V v_a_241496 = (g_std_2edoc_2egroup(v_t_241495));
        V v_b_241497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241498 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str117)}), v_b_241497));
        return (g_std_2edoc_2e_3c_3e(v_a_241496, v_t_241498));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241486);
        V v_t_241499 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241500 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241506 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241500}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241507 = (g_std_2edoc_2e_3c_3e(v_t_241499, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241506})));
        return (g_std_2edoc_2egroup(v_t_241507));
      }
    }
    case TAG_InstB: {
      V v_t_241513 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241513) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241513);
        V v_t_241514 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241515 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241521 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241515}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241522 = (g_std_2edoc_2e_3c_3e(v_t_241514, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241521})));
        V v_a_241523 = (g_std_2edoc_2egroup(v_t_241522));
        V v_b_241524 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241525 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str118)}), v_b_241524));
        return (g_std_2edoc_2e_3c_3e(v_a_241523, v_t_241525));
      } else {
        heff_drop_tag(v_x_241296, 5);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241513);
        V v_t_241526 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241527 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241533 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241527}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241534 = (g_std_2edoc_2e_3c_3e(v_t_241526, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241533})));
        return (g_std_2edoc_2egroup(v_t_241534));
      }
    }
    case TAG_EFSet: {
      V v_t_241538 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241538) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241538);
        V v_t_241539 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241540 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241546 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241540}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241547 = (g_std_2edoc_2e_3c_3e(v_t_241539, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241546})));
        V v_a_241548 = (g_std_2edoc_2egroup(v_t_241547));
        V v_b_241549 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241550 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str119)}), v_b_241549));
        return (g_std_2edoc_2e_3c_3e(v_a_241548, v_t_241550));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241538);
        V v_t_241551 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241552 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241558 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241552}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241559 = (g_std_2edoc_2e_3c_3e(v_t_241551, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241558})));
        return (g_std_2edoc_2egroup(v_t_241559));
      }
    }
    case TAG_EFDefault: {
      V v_t_241563 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241563) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241563);
        V v_t_241564 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241565 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241571 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241565}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241572 = (g_std_2edoc_2e_3c_3e(v_t_241564, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241571})));
        V v_a_241573 = (g_std_2edoc_2egroup(v_t_241572));
        V v_b_241574 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241575 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str120)}), v_b_241574));
        return (g_std_2edoc_2e_3c_3e(v_a_241573, v_t_241575));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241563);
        V v_t_241576 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241577 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241583 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241577}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241584 = (g_std_2edoc_2e_3c_3e(v_t_241576, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241583})));
        return (g_std_2edoc_2egroup(v_t_241584));
      }
    }
    case TAG_Sum: {
      V v_t_241590 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241590) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241590);
        V v_t_241591 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241592 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241598 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241592}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241599 = (g_std_2edoc_2e_3c_3e(v_t_241591, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241598})));
        V v_a_241600 = (g_std_2edoc_2egroup(v_t_241599));
        V v_b_241601 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241602 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str121)}), v_b_241601));
        return (g_std_2edoc_2e_3c_3e(v_a_241600, v_t_241602));
      } else {
        heff_drop_tag(v_x_241296, 5);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241590);
        V v_t_241603 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241604 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241610 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241604}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241611 = (g_std_2edoc_2e_3c_3e(v_t_241603, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241610})));
        return (g_std_2edoc_2egroup(v_t_241611));
      }
    }
    case TAG_ECon: {
      V v_t_241614 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241614) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241614);
        V v_t_241615 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241616 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241622 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241616}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241623 = (g_std_2edoc_2e_3c_3e(v_t_241615, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241622})));
        V v_a_241624 = (g_std_2edoc_2egroup(v_t_241623));
        V v_b_241625 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241626 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str122)}), v_b_241625));
        return (g_std_2edoc_2e_3c_3e(v_a_241624, v_t_241626));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241614);
        V v_t_241627 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241628 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241634 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241628}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241635 = (g_std_2edoc_2e_3c_3e(v_t_241627, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241634})));
        return (g_std_2edoc_2egroup(v_t_241635));
      }
    }
    case TAG_EField: {
      V v_t_241638 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241638) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241638);
        V v_t_241639 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241646 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241640}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241647 = (g_std_2edoc_2e_3c_3e(v_t_241639, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241646})));
        V v_a_241648 = (g_std_2edoc_2egroup(v_t_241647));
        V v_b_241649 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241650 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str123)}), v_b_241649));
        return (g_std_2edoc_2e_3c_3e(v_a_241648, v_t_241650));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241638);
        V v_t_241651 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241652 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241658 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241652}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241659 = (g_std_2edoc_2e_3c_3e(v_t_241651, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241658})));
        return (g_std_2edoc_2egroup(v_t_241659));
      }
    }
    case TAG_ENeg: {
      V v_t_241662 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241662) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241662);
        V v_t_241663 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241664 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241670 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241664}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241671 = (g_std_2edoc_2e_3c_3e(v_t_241663, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241670})));
        V v_a_241672 = (g_std_2edoc_2egroup(v_t_241671));
        V v_b_241673 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241674 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str124)}), v_b_241673));
        return (g_std_2edoc_2e_3c_3e(v_a_241672, v_t_241674));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241662);
        V v_t_241675 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241676 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241682 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241676}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241683 = (g_std_2edoc_2e_3c_3e(v_t_241675, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241682})));
        return (g_std_2edoc_2egroup(v_t_241683));
      }
    }
    case TAG_ETilde: {
      V v_t_241686 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241686) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241686);
        V v_t_241687 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241688 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241694 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241688}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241695 = (g_std_2edoc_2e_3c_3e(v_t_241687, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241694})));
        V v_a_241696 = (g_std_2edoc_2egroup(v_t_241695));
        V v_b_241697 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241698 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str125)}), v_b_241697));
        return (g_std_2edoc_2e_3c_3e(v_a_241696, v_t_241698));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241686);
        V v_t_241699 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241700 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241706 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241700}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241707 = (g_std_2edoc_2e_3c_3e(v_t_241699, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241706})));
        return (g_std_2edoc_2egroup(v_t_241707));
      }
    }
    case TAG_App: {
      V v_t_241710 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241710) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241710);
        V v_t_241711 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241712 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241718 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241712}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241719 = (g_std_2edoc_2e_3c_3e(v_t_241711, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241718})));
        V v_a_241720 = (g_std_2edoc_2egroup(v_t_241719));
        V v_b_241721 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241722 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str126)}), v_b_241721));
        return (g_std_2edoc_2e_3c_3e(v_a_241720, v_t_241722));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241710);
        V v_t_241723 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241730 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241724}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241731 = (g_std_2edoc_2e_3c_3e(v_t_241723, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241730})));
        return (g_std_2edoc_2egroup(v_t_241731));
      }
    }
    case TAG_Op: {
      V v_t_241735 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241735) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241735);
        V v_t_241736 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241737 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241743 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241737}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241744 = (g_std_2edoc_2e_3c_3e(v_t_241736, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241743})));
        V v_a_241745 = (g_std_2edoc_2egroup(v_t_241744));
        V v_b_241746 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241747 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str127)}), v_b_241746));
        return (g_std_2edoc_2e_3c_3e(v_a_241745, v_t_241747));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241735);
        V v_t_241748 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241755 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241749}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241756 = (g_std_2edoc_2e_3c_3e(v_t_241748, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241755})));
        return (g_std_2edoc_2egroup(v_t_241756));
      }
    }
    case TAG_Ops: {
      V v_t_241759 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241759) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241759);
        V v_t_241760 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241761 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241767 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241761}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241768 = (g_std_2edoc_2e_3c_3e(v_t_241760, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241767})));
        V v_a_241769 = (g_std_2edoc_2egroup(v_t_241768));
        V v_b_241770 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241771 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str128)}), v_b_241770));
        return (g_std_2edoc_2e_3c_3e(v_a_241769, v_t_241771));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241759);
        V v_t_241772 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241773 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241779 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241773}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241780 = (g_std_2edoc_2e_3c_3e(v_t_241772, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241779})));
        return (g_std_2edoc_2egroup(v_t_241780));
      }
    }
    case TAG_OpRhs: {
      V v_t_241783 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241783) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241783);
        V v_t_241784 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241785 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241791 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241785}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241792 = (g_std_2edoc_2e_3c_3e(v_t_241784, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241791})));
        V v_a_241793 = (g_std_2edoc_2egroup(v_t_241792));
        V v_b_241794 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241795 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str129)}), v_b_241794));
        return (g_std_2edoc_2e_3c_3e(v_a_241793, v_t_241795));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241783);
        V v_t_241796 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241797 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241803 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241797}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241804 = (g_std_2edoc_2e_3c_3e(v_t_241796, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241803})));
        return (g_std_2edoc_2egroup(v_t_241804));
      }
    }
    case TAG_Ann: {
      V v_t_241808 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241808) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241808);
        V v_t_241809 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241810 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241816 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241810}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241817 = (g_std_2edoc_2e_3c_3e(v_t_241809, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241816})));
        V v_a_241818 = (g_std_2edoc_2egroup(v_t_241817));
        V v_b_241819 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241820 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str130)}), v_b_241819));
        return (g_std_2edoc_2e_3c_3e(v_a_241818, v_t_241820));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241808);
        V v_t_241821 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241822 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241828 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241822}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241829 = (g_std_2edoc_2e_3c_3e(v_t_241821, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241828})));
        return (g_std_2edoc_2egroup(v_t_241829));
      }
    }
    case TAG_BVar: {
      V v_t_241831 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241831) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241831);
        V v_t_241832 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241833 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241839 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241833}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241840 = (g_std_2edoc_2e_3c_3e(v_t_241832, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241839})));
        V v_a_241841 = (g_std_2edoc_2egroup(v_t_241840));
        V v_b_241842 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241843 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str131)}), v_b_241842));
        return (g_std_2edoc_2e_3c_3e(v_a_241841, v_t_241843));
      } else {
        heff_drop_tag(v_x_241296, 1);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241831);
        V v_t_241844 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241845 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241851 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241845}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241852 = (g_std_2edoc_2e_3c_3e(v_t_241844, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241851})));
        return (g_std_2edoc_2egroup(v_t_241852));
      }
    }
    case TAG_BImp: {
      V v_t_241856 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241856) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241856);
        V v_t_241857 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241858 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241864 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241858}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241865 = (g_std_2edoc_2e_3c_3e(v_t_241857, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241864})));
        V v_a_241866 = (g_std_2edoc_2egroup(v_t_241865));
        V v_b_241867 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241868 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str132)}), v_b_241867));
        return (g_std_2edoc_2e_3c_3e(v_a_241866, v_t_241868));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241856);
        V v_t_241869 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241870 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241876 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241870}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241877 = (g_std_2edoc_2e_3c_3e(v_t_241869, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241876})));
        return (g_std_2edoc_2egroup(v_t_241877));
      }
    }
    case TAG_BAnn: {
      V v_t_241883 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241883) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241883);
        V v_t_241884 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241885 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241891 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241885}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241892 = (g_std_2edoc_2e_3c_3e(v_t_241884, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241891})));
        V v_a_241893 = (g_std_2edoc_2egroup(v_t_241892));
        V v_b_241894 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241895 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str133)}), v_b_241894));
        return (g_std_2edoc_2e_3c_3e(v_a_241893, v_t_241895));
      } else {
        heff_drop_tag(v_x_241296, 5);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241883);
        V v_t_241896 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241897 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241903 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241897}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241904 = (g_std_2edoc_2e_3c_3e(v_t_241896, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241903})));
        return (g_std_2edoc_2egroup(v_t_241904));
      }
    }
    case TAG_BPat: {
      V v_t_241906 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241906) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241906);
        V v_t_241907 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241908 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241914 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241908}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241915 = (g_std_2edoc_2e_3c_3e(v_t_241907, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241914})));
        V v_a_241916 = (g_std_2edoc_2egroup(v_t_241915));
        V v_b_241917 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241918 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str134)}), v_b_241917));
        return (g_std_2edoc_2e_3c_3e(v_a_241916, v_t_241918));
      } else {
        heff_drop_tag(v_x_241296, 1);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241906);
        V v_t_241919 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241920 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241926 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241920}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241927 = (g_std_2edoc_2e_3c_3e(v_t_241919, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241926})));
        return (g_std_2edoc_2egroup(v_t_241927));
      }
    }
    case TAG_Lam: {
      V v_t_241932 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241932) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241932);
        V v_t_241933 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241934 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241940 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 1, 1, (V[]){v_one_241934}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241941 = (g_std_2edoc_2e_3c_3e(v_t_241933, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241940})));
        V v_a_241942 = (g_std_2edoc_2egroup(v_t_241941));
        V v_b_241943 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241944 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str135)}), v_b_241943));
        return (g_std_2edoc_2e_3c_3e(v_a_241942, v_t_241944));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241932);
        V v_t_241945 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241946 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241952 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 1, 1, (V[]){v_one_241946}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241953 = (g_std_2edoc_2e_3c_3e(v_t_241945, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241952})));
        return (g_std_2edoc_2egroup(v_t_241953));
      }
    }
    case TAG_Case: {
      V v_t_241958 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241958) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241958);
        V v_t_241959 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241960 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241966 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 1, 1, (V[]){v_one_241960}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241967 = (g_std_2edoc_2e_3c_3e(v_t_241959, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241966})));
        V v_a_241968 = (g_std_2edoc_2egroup(v_t_241967));
        V v_b_241969 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241970 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str136)}), v_b_241969));
        return (g_std_2edoc_2e_3c_3e(v_a_241968, v_t_241970));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241958);
        V v_t_241971 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241972 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_241978 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 1, 1, (V[]){v_one_241972}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_241979 = (g_std_2edoc_2e_3c_3e(v_t_241971, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241978})));
        return (g_std_2edoc_2egroup(v_t_241979));
      }
    }
    case TAG_EAlt: {
      V v_t_241983 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_241983) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_241983);
        V v_t_241984 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241985 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_241991 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 1, 1, (V[]){v_one_241985}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_241992 = (g_std_2edoc_2e_3c_3e(v_t_241984, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241991})));
        V v_a_241993 = (g_std_2edoc_2egroup(v_t_241992));
        V v_b_241994 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_241995 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str137)}), v_b_241994));
        return (g_std_2edoc_2e_3c_3e(v_a_241993, v_t_241995));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_241983);
        V v_t_241996 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_241997 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242003 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_one_241997}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242004 = (g_std_2edoc_2e_3c_3e(v_t_241996, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242003})));
        return (g_std_2edoc_2egroup(v_t_242004));
      }
    }
    case TAG_If: {
      V v_t_242011 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242011) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242011);
        V v_t_242012 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242013 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242019 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_one_242013}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242020 = (g_std_2edoc_2e_3c_3e(v_t_242012, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242019})));
        V v_a_242021 = (g_std_2edoc_2egroup(v_t_242020));
        V v_b_242022 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242023 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str138)}), v_b_242022));
        return (g_std_2edoc_2e_3c_3e(v_a_242021, v_t_242023));
      } else {
        heff_drop_tag(v_x_241296, 6);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242011);
        V v_t_242024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242025 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242031 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 1, 1, (V[]){v_one_242025}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242032 = (g_std_2edoc_2e_3c_3e(v_t_242024, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242031})));
        return (g_std_2edoc_2egroup(v_t_242032));
      }
    }
    case TAG_Do: {
      V v_t_242035 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242035) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242035);
        V v_t_242036 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242037 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242043 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 1, 1, (V[]){v_one_242037}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242044 = (g_std_2edoc_2e_3c_3e(v_t_242036, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242043})));
        V v_a_242045 = (g_std_2edoc_2egroup(v_t_242044));
        V v_b_242046 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242047 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str139)}), v_b_242046));
        return (g_std_2edoc_2e_3c_3e(v_a_242045, v_t_242047));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242035);
        V v_t_242048 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242049 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242055 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 1, 1, (V[]){v_one_242049}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242056 = (g_std_2edoc_2e_3c_3e(v_t_242048, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242055})));
        return (g_std_2edoc_2egroup(v_t_242056));
      }
    }
    case TAG_ESBind: {
      V v_t_242060 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242060) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242060);
        V v_t_242061 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242062 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242068 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 1, 1, (V[]){v_one_242062}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242069 = (g_std_2edoc_2e_3c_3e(v_t_242061, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242068})));
        V v_a_242070 = (g_std_2edoc_2egroup(v_t_242069));
        V v_b_242071 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242072 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str140)}), v_b_242071));
        return (g_std_2edoc_2e_3c_3e(v_a_242070, v_t_242072));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242060);
        V v_t_242073 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242074 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242080 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam97, 1, 1, (V[]){v_one_242074}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242081 = (g_std_2edoc_2e_3c_3e(v_t_242073, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242080})));
        return (g_std_2edoc_2egroup(v_t_242081));
      }
    }
    case TAG_ELet: {
      V v_t_242088 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242088) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242088);
        V v_t_242089 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242090 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242096 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam98, 1, 1, (V[]){v_one_242090}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242097 = (g_std_2edoc_2e_3c_3e(v_t_242089, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242096})));
        V v_a_242098 = (g_std_2edoc_2egroup(v_t_242097));
        V v_b_242099 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242100 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str141)}), v_b_242099));
        return (g_std_2edoc_2e_3c_3e(v_a_242098, v_t_242100));
      } else {
        heff_drop_tag(v_x_241296, 6);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242088);
        V v_t_242101 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242102 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242108 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam99, 1, 1, (V[]){v_one_242102}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242109 = (g_std_2edoc_2e_3c_3e(v_t_242101, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242108})));
        return (g_std_2edoc_2egroup(v_t_242109));
      }
    }
    case TAG_ELetElse: {
      V v_t_242117 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242117) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242117);
        V v_t_242118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242119 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242125 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam100, 1, 1, (V[]){v_one_242119}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242126 = (g_std_2edoc_2e_3c_3e(v_t_242118, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242125})));
        V v_a_242127 = (g_std_2edoc_2egroup(v_t_242126));
        V v_b_242128 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242129 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str142)}), v_b_242128));
        return (g_std_2edoc_2e_3c_3e(v_a_242127, v_t_242129));
      } else {
        heff_drop_tag(v_x_241296, 7);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242117);
        V v_t_242130 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242131 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam101, 1, 1, (V[]){v_one_242131}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242138 = (g_std_2edoc_2e_3c_3e(v_t_242130, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242137})));
        return (g_std_2edoc_2egroup(v_t_242138));
      }
    }
    case TAG_ELetMut: {
      V v_t_242145 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242145) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242145);
        V v_t_242146 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242147 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242153 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam102, 1, 1, (V[]){v_one_242147}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242154 = (g_std_2edoc_2e_3c_3e(v_t_242146, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242153})));
        V v_a_242155 = (g_std_2edoc_2egroup(v_t_242154));
        V v_b_242156 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242157 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str143)}), v_b_242156));
        return (g_std_2edoc_2e_3c_3e(v_a_242155, v_t_242157));
      } else {
        heff_drop_tag(v_x_241296, 6);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242145);
        V v_t_242158 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242159 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242165 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam103, 1, 1, (V[]){v_one_242159}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242166 = (g_std_2edoc_2e_3c_3e(v_t_242158, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242165})));
        return (g_std_2edoc_2egroup(v_t_242166));
      }
    }
    case TAG_EAssign: {
      V v_t_242170 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242170) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242170);
        V v_t_242171 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242172 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242178 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam104, 1, 1, (V[]){v_one_242172}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242179 = (g_std_2edoc_2e_3c_3e(v_t_242171, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242178})));
        V v_a_242180 = (g_std_2edoc_2egroup(v_t_242179));
        V v_b_242181 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242182 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str144)}), v_b_242181));
        return (g_std_2edoc_2e_3c_3e(v_a_242180, v_t_242182));
      } else {
        heff_drop_tag(v_x_241296, 3);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242170);
        V v_t_242183 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242184 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242190 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam105, 1, 1, (V[]){v_one_242184}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242191 = (g_std_2edoc_2e_3c_3e(v_t_242183, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242190})));
        return (g_std_2edoc_2egroup(v_t_242191));
      }
    }
    case TAG_EWhile: {
      V v_t_242196 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242196) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242196);
        V v_t_242197 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242198 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242204 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam106, 1, 1, (V[]){v_one_242198}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242205 = (g_std_2edoc_2e_3c_3e(v_t_242197, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242204})));
        V v_a_242206 = (g_std_2edoc_2egroup(v_t_242205));
        V v_b_242207 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242208 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str145)}), v_b_242207));
        return (g_std_2edoc_2e_3c_3e(v_a_242206, v_t_242208));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242196);
        V v_t_242209 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242216 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam107, 1, 1, (V[]){v_one_242210}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242217 = (g_std_2edoc_2e_3c_3e(v_t_242209, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242216})));
        return (g_std_2edoc_2egroup(v_t_242217));
      }
    }
    case TAG_EFor: {
      V v_t_242224 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242224) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242224);
        V v_t_242225 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242226 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242232 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam108, 1, 1, (V[]){v_one_242226}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242233 = (g_std_2edoc_2e_3c_3e(v_t_242225, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242232})));
        V v_a_242234 = (g_std_2edoc_2egroup(v_t_242233));
        V v_b_242235 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242236 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str146)}), v_b_242235));
        return (g_std_2edoc_2e_3c_3e(v_a_242234, v_t_242236));
      } else {
        heff_drop_tag(v_x_241296, 6);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242224);
        V v_t_242237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242238 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242244 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam109, 1, 1, (V[]){v_one_242238}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242245 = (g_std_2edoc_2e_3c_3e(v_t_242237, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242244})));
        return (g_std_2edoc_2egroup(v_t_242245));
      }
    }
    case TAG_EJump: {
      V v_t_242247 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242247) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242247);
        V v_t_242248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242255 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam110, 1, 1, (V[]){v_one_242249}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242256 = (g_std_2edoc_2e_3c_3e(v_t_242248, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242255})));
        V v_a_242257 = (g_std_2edoc_2egroup(v_t_242256));
        V v_b_242258 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242259 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str147)}), v_b_242258));
        return (g_std_2edoc_2e_3c_3e(v_a_242257, v_t_242259));
      } else {
        heff_drop_tag(v_x_241296, 1);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242247);
        V v_t_242260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242261 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242267 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam111, 1, 1, (V[]){v_one_242261}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242268 = (g_std_2edoc_2e_3c_3e(v_t_242260, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242267})));
        return (g_std_2edoc_2egroup(v_t_242268));
      }
    }
    case TAG_EReturn: {
      V v_t_242271 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242271) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242271);
        V v_t_242272 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242273 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242279 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam112, 1, 1, (V[]){v_one_242273}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242280 = (g_std_2edoc_2e_3c_3e(v_t_242272, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242279})));
        V v_a_242281 = (g_std_2edoc_2egroup(v_t_242280));
        V v_b_242282 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242283 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str148)}), v_b_242282));
        return (g_std_2edoc_2e_3c_3e(v_a_242281, v_t_242283));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242271);
        V v_t_242284 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242285 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242291 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam113, 1, 1, (V[]){v_one_242285}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242292 = (g_std_2edoc_2e_3c_3e(v_t_242284, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242291})));
        return (g_std_2edoc_2egroup(v_t_242292));
      }
    }
    case TAG_ENest: {
      V v_t_242297 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242297) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242297);
        V v_t_242298 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242299 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242305 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam114, 1, 1, (V[]){v_one_242299}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242306 = (g_std_2edoc_2e_3c_3e(v_t_242298, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242305})));
        V v_a_242307 = (g_std_2edoc_2egroup(v_t_242306));
        V v_b_242308 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242309 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str149)}), v_b_242308));
        return (g_std_2edoc_2e_3c_3e(v_a_242307, v_t_242309));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242297);
        V v_t_242310 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242311 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242317 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam115, 1, 1, (V[]){v_one_242311}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242318 = (g_std_2edoc_2e_3c_3e(v_t_242310, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242317})));
        return (g_std_2edoc_2egroup(v_t_242318));
      }
    }
    case TAG_EArrow: {
      V v_t_242321 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242321) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242321);
        V v_t_242322 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242323 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242329 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam116, 1, 1, (V[]){v_one_242323}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242330 = (g_std_2edoc_2e_3c_3e(v_t_242322, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242329})));
        V v_a_242331 = (g_std_2edoc_2egroup(v_t_242330));
        V v_b_242332 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242333 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str150)}), v_b_242332));
        return (g_std_2edoc_2e_3c_3e(v_a_242331, v_t_242333));
      } else {
        heff_drop_tag(v_x_241296, 2);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242321);
        V v_t_242334 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242335 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242341 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam117, 1, 1, (V[]){v_one_242335}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242342 = (g_std_2edoc_2e_3c_3e(v_t_242334, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242341})));
        return (g_std_2edoc_2egroup(v_t_242342));
      }
    }
    case TAG_IfThen: {
      V v_t_242347 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242347) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242347);
        V v_t_242348 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242349 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242355 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam118, 1, 1, (V[]){v_one_242349}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242356 = (g_std_2edoc_2e_3c_3e(v_t_242348, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242355})));
        V v_a_242357 = (g_std_2edoc_2egroup(v_t_242356));
        V v_b_242358 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242359 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str151)}), v_b_242358));
        return (g_std_2edoc_2e_3c_3e(v_a_242357, v_t_242359));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242347);
        V v_t_242360 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242361 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242367 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam119, 1, 1, (V[]){v_one_242361}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242368 = (g_std_2edoc_2e_3c_3e(v_t_242360, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242367})));
        return (g_std_2edoc_2egroup(v_t_242368));
      }
    }
    case TAG_ETry: {
      V v_t_242373 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242373) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242373);
        V v_t_242374 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242375 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242381 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam120, 1, 1, (V[]){v_one_242375}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242382 = (g_std_2edoc_2e_3c_3e(v_t_242374, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242381})));
        V v_a_242383 = (g_std_2edoc_2egroup(v_t_242382));
        V v_b_242384 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242385 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str152)}), v_b_242384));
        return (g_std_2edoc_2e_3c_3e(v_a_242383, v_t_242385));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242373);
        V v_t_242386 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242387 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242393 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam121, 1, 1, (V[]){v_one_242387}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242394 = (g_std_2edoc_2e_3c_3e(v_t_242386, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242393})));
        return (g_std_2edoc_2egroup(v_t_242394));
      }
    }
    case TAG_ECatch: {
      V v_t_242399 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242399) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242399);
        V v_t_242400 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242401 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242407 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam122, 1, 1, (V[]){v_one_242401}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242408 = (g_std_2edoc_2e_3c_3e(v_t_242400, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242407})));
        V v_a_242409 = (g_std_2edoc_2egroup(v_t_242408));
        V v_b_242410 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242411 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str153)}), v_b_242410));
        return (g_std_2edoc_2e_3c_3e(v_a_242409, v_t_242411));
      } else {
        heff_drop_tag(v_x_241296, 4);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242399);
        V v_t_242412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242413 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam123, 1, 1, (V[]){v_one_242413}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242420 = (g_std_2edoc_2e_3c_3e(v_t_242412, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242419})));
        return (g_std_2edoc_2egroup(v_t_242420));
      }
    }
    case TAG_EWith: {
      V v_t_242427 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241296));
      if ((heff_dup(v_t_242427) == NTAG(TAG_True))) {
        heff_drop(v_args_241294);
        heff_drop(v_t_242427);
        V v_t_242428 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242429 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241292)}));
        V v_d_242435 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam124, 1, 1, (V[]){v_one_242429}); V a_2 = v_init2_241298; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241298); r_; });
        V v_t_242436 = (g_std_2edoc_2e_3c_3e(v_t_242428, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242435})));
        V v_a_242437 = (g_std_2edoc_2egroup(v_t_242436));
        V v_b_242438 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241292, v_x_241296}));
        V v_t_242439 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str154)}), v_b_242438));
        return (g_std_2edoc_2e_3c_3e(v_a_242437, v_t_242439));
      } else {
        heff_drop_tag(v_x_241296, 6);
        heff_drop(v_init2_241298);
        heff_drop(v_t_242427);
        V v_t_242440 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241292), v_h_241293}));
        V v_one_242441 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241292}));
        V v_d_242447 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam125, 1, 1, (V[]){v_one_242441}); V a_2 = v_args_241294; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241294); r_; });
        V v_t_242448 = (g_std_2edoc_2e_3c_3e(v_t_242440, heff_tag_at_n(v_ru_24x1_241295_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242447})));
        return (g_std_2edoc_2egroup(v_t_242448));
      }
    }
    default: return heff_nomatch(v_x_241296);
    }
  }
  default: return heff_nomatch(v_x1_241295);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args) {
  V v_env_242449 = args[0];
  V v_rest_242450 = args[1];
  V v_e_242451 = args[2];
  switch (heff_tag_of(v_e_242451)) {
  case TAG_Atom: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_242468 = heff_field(v_e_242451, 0);
    V v_fs_242469 = heff_field(v_e_242451, 1);
    V v_commas_242470 = heff_field(v_e_242451, 2);
    V v_c_242471 = heff_field(v_e_242451, 3);
    heff_take_n(v_e_242451, 15ULL, 4);
    switch (heff_tag_of(v_fs_242469)) {
    case TAG_Nil: {
      heff_drop(v_rest_242450);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_242449;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242468, v_fs_242469, v_commas_242470, v_c_242471});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_242472 = heff_dup(heff_field(v_fs_242469, 0));
      V v_rest2_242473 = heff_dup(heff_field(v_fs_242469, 1));
      switch (heff_tag_of(v_rest2_242473)) {
      case TAG_Nil: {
        V v_t_242474 = ({ V a_0 = v_rest_242450; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_242450); r_; });
        if ((heff_dup(v_t_242474) == NTAG(TAG_True))) {
          heff_drop(v_t_242474);
          V v_x1_242475 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_242472));
          if (!(heff_dup(v_x1_242475) == NTAG(TAG_True))) {
            heff_drop(v_x1_242475);
            switch (heff_tag_of(v_commas_242470)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_242469, 2);
              V v_t_242476 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242449), v_o_242468));
              V v_t_242477 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242449), v_d_242472}));
              V v_t_242478 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242449, v_c_242471));
              V v_t_242479 = (g_std_2edoc_2e_3c_3e(v_t_242477, v_t_242478));
              return (g_std_2edoc_2e_3c_3e(v_t_242476, v_t_242479));
            }
            case TAG_Cons: {
              heff_drop(v_d_242472);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_242449;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242468, v_fs_242469, v_commas_242470, v_c_242471});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_242470);
            }
          } else {
            heff_drop(v_d_242472);
            heff_drop(v_x1_242475);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_242449;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242468, v_fs_242469, v_commas_242470, v_c_242471});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
        } else {
          heff_drop(v_d_242472);
          heff_drop(v_t_242474);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_242449;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242468, v_fs_242469, v_commas_242470, v_c_242471});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_242473, 0ULL, 2);
        heff_drop(v_rest_242450);
        heff_drop(v_d_242472);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_242449;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242468, v_fs_242469, v_commas_242470, v_c_242471});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_242473);
      }
    }
    default: return heff_nomatch(v_fs_242469);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242450);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_e_242451;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_242451);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args) {
  V v_env_242620 = args[0];
  V v_b_242621 = args[1];
  switch (heff_tag_of(v_b_242621)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_242687 = heff_field(v_b_242621, 0);
    V v_ru_24b_242621_24BVar = heff_take_reuse_n(v_b_242621, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24b_242621_24BVar, v_env_242620, v_t_242687));
  }
  case TAG_BImp: {
    V v_o_242688 = heff_field(v_b_242621, 0);
    V v_x_242689 = heff_field(v_b_242621, 1);
    V v_c_242690 = heff_field(v_b_242621, 2);
    heff_take_n(v_b_242621, 7ULL, 3);
    V v_t_242691 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242620), v_o_242688));
    V v_t_242692 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242620), v_x_242689));
    V v_t_242693 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242620, v_c_242690));
    V v_t_242694 = (g_std_2edoc_2e_3c_3e(v_t_242692, v_t_242693));
    return (g_std_2edoc_2e_3c_3e(v_t_242691, v_t_242694));
  }
  case TAG_BAnn: {
    V v_o_242695 = heff_field(v_b_242621, 0);
    V v_x_242696 = heff_field(v_b_242621, 1);
    V v_cc_242697 = heff_field(v_b_242621, 2);
    V v_ty_242698 = heff_field(v_b_242621, 3);
    V v_c_242699 = heff_field(v_b_242621, 4);
    heff_take_n(v_b_242621, 31ULL, 5);
    V v_t_242700 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242620), v_o_242695));
    V v_a_242701 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242620), v_x_242696));
    V v_a_242702 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242620), v_cc_242697));
    V v_b_242703 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242620), v_ty_242698}));
    V v_t_242704 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str155)}), v_b_242703));
    V v_t_242705 = (g_std_2edoc_2e_3c_3e(v_a_242702, v_t_242704));
    V v_t_242706 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str156)}), v_t_242705));
    V v_t_242707 = (g_std_2edoc_2e_3c_3e(v_a_242701, v_t_242706));
    V v_t_242708 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242620, v_c_242699));
    V v_t_242709 = (g_std_2edoc_2e_3c_3e(v_t_242707, v_t_242708));
    return (g_std_2edoc_2e_3c_3e(v_t_242700, v_t_242709));
  }
  case TAG_BPat: {
    V v_p_242710 = heff_field(v_b_242621, 0);
    heff_take_n(v_b_242621, 1ULL, 1);
    return ({ V a_0 = v_env_242620; V a_1 = v_p_242710; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_242710); r_; });
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242620;
    args[1] = v_b_242621;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_242621);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args) {
  V v_env_242792 = args[0];
  V v_rest_242793 = args[1];
  V v_r_242794 = args[2];
  switch (heff_tag_of(v_r_242794)) {
  case TAG_Atom: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242855 = heff_field(v_r_242794, 0);
    V v_e_242856 = heff_field(v_r_242794, 1);
    heff_take_n(v_r_242794, 3ULL, 2);
    V v_a_242857 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242792), v_op_242855));
    V v_b_242858 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_242792, v_rest_242793, v_e_242856}));
    V v_t_242859 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str157)}), v_b_242858));
    return (g_std_2edoc_2e_3c_3e(v_a_242857, v_t_242859));
  }
  case TAG_Ann: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242793);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242792;
    args[1] = v_r_242794;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242794);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args) {
  V v_env_242954 = args[0];
  V v_r_242955 = args[1];
  switch (heff_tag_of(v_r_242955)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_243016 = heff_field(v_r_242955, 0);
    V v_e_243017 = heff_field(v_r_242955, 1);
    heff_take_n(v_r_242955, 3ULL, 2);
    V v_a_243018 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242954), v_op_243016));
    V v_b_243019 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_242954, v_e_243017}));
    V v_t_243020 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str158)}), v_b_243019));
    return (g_std_2edoc_2e_3c_3e(v_a_243018, v_t_243020));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242954;
    args[1] = v_r_242955;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242955);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam131(V self, V *args) {
  V v_r_243127 = args[0];
  V v_env_243115 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243128 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_243127));
  V v_t_243129;
  if ((heff_dup(v_x1_243128) == NTAG(TAG_True))) {
    heff_drop(v_x1_243128);
    v_t_243129 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_243128);
    v_t_243129 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_243130 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_243115, v_r_243127}));
  return (g_std_2edoc_2e_3c_3e(v_t_243129, v_t_243130));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam132(V self, V *args) {
  V v_r_243136 = args[0];
  V v_env_243115 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243137 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_243136));
  V v_t_243138;
  if ((heff_dup(v_x1_243137) == NTAG(TAG_True))) {
    heff_drop(v_x1_243137);
    v_t_243138 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_243137);
    v_t_243138 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_243139 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_243115, v_r_243136}));
  return (g_std_2edoc_2e_3c_3e(v_t_243138, v_t_243139));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args) {
  V v_env_243115 = args[0];
  V v_first_243116 = args[1];
  V v_rest_243117 = args[2];
  V v_f_243118 = heff_dup(heff_rfield(v_env_243115, 6));
  HeffT2 v_t_243119 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_243118), heff_dup(v_rest_243117)));
  {
    V v_field_243121 = v_t_243119.f[1];
    int64_t v_tag_243120 = ((int64_t)v_t_243119.f[0]);
    V v_t_243125;
    if ((v_tag_243120 == ((int64_t)0ULL))) {
      V v_it1_243122 = v_field_243121;
      switch (heff_tag_of(v_it1_243122)) {
      case TAG_Nil: {
        heff_drop(v_f_243118);
        v_t_243125 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_243123 = heff_field(v_it1_243122, 0);
        V v_os_243124 = heff_field(v_it1_243122, 1);
        heff_take_n(v_it1_243122, 3ULL, 2);
        v_t_243125 = ({ V a_0 = v_f_243118; V a_1 = v_o_243123; V a_2 = v_os_243124; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_243124); r_; });
        break;
      }
      default: heff_nomatch(v_it1_243122);
      }
    } else {
      heff_drop(v_f_243118);
      heff_drop(v_field_243121);
      v_t_243125 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_243125)) {
    case TAG_Nothing: {
      V v_t_243126 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243115), v_first_243116}));
      V v_t_243131 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam131, 1, 1, (V[]){v_env_243115}); V a_2 = v_rest_243117; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_243117); r_; });
      V v_t_243132 = (g_std_2edoc_2e_3c_3e(v_t_243126, v_t_243131));
      return (g_std_2edoc_2egroup(v_t_243132));
    }
    case TAG_Just: {
      V v_m_243133 = heff_field(v_t_243125, 0);
      heff_take_n(v_t_243125, 1ULL, 1);
      V v_t_243134 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_243115, 6)), heff_dup(v_m_243133), v_rest_243117));
      if ((heff_dup(v_t_243134) == NTAG(TAG_True))) {
        heff_drop(v_m_243133);
        heff_drop(v_t_243134);
        V v_t_243135 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243115), v_first_243116}));
        V v_t_243140 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam132, 1, 1, (V[]){v_env_243115}); V a_2 = v_rest_243117; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_243117); r_; });
        V v_t_243141 = (g_std_2edoc_2e_3c_3e(v_t_243135, v_t_243140));
        return (g_std_2edoc_2egroup(v_t_243141));
      } else {
        heff_drop(v_t_243134);
        V v_t_243142 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_243115, v_m_243133, v_first_243116, NTAG(TAG_Nil), v_rest_243117}));
        return (g_std_2edoc_2egroup(v_t_243142));
      }
    }
    default: return heff_nomatch(v_t_243125);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam133(V self, V *args) {
  V v_env_243143 = args[0];
  V v_m_243144 = args[1];
  V v_f_243145 = args[2];
  V v_acc_243146 = args[3];
  V v_rs_243147 = args[4];
  switch (heff_tag_of(v_rs_243147)) {
  case TAG_Nil: {
    heff_drop(v_m_243144);
    V v_t_243148 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243146));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_243143;
    args[1] = v_f_243145;
    args[2] = v_t_243148;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_243149 = heff_field(v_rs_243147, 0);
    V v_rest2_243150 = heff_field(v_rs_243147, 1);
    heff_take_n(v_rs_243147, 3ULL, 2);
    switch (heff_tag_of(v_r_243149)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETilde: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_243211 = heff_dup(heff_field(v_r_243149, 0));
      V v_e_243212 = heff_dup(heff_field(v_r_243149, 1));
      V v_t_243213 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_243143, 6)), heff_dup(v_m_243144), heff_dup(heff_rfield(v_op_243211, 1))));
      switch (heff_tag_of(v_t_243213)) {
      case TAG_Tighter: {
        heff_drop_rec(v_op_243211, 9);
        heff_drop(v_e_243212);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243143;
        args[1] = v_m_243144;
        args[2] = v_f_243145;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
        args[4] = v_rest2_243150;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Looser: {
        heff_drop_rec(v_op_243211, 9);
        heff_drop(v_e_243212);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243143;
        args[1] = v_m_243144;
        args[2] = v_f_243145;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
        args[4] = v_rest2_243150;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Same: {
        V v_ru_24t_243213_24Same = heff_take_reuse_n(v_t_243213, 0ULL, 1);
        V v_t_243215 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243146));
        V v_t_243216 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_243143), v_f_243145, v_t_243215}));
        V v_x1_243217 = ({ V a_0 = v_r_243149; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_243149, 2); r_; });
        V v_t_243218;
        if ((heff_dup(v_x1_243217) == NTAG(TAG_True))) {
          heff_drop(v_x1_243217);
          v_t_243218 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_243217);
          v_t_243218 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_243219 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243143), v_op_243211));
        V v_b_243220 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_243143, v_m_243144, v_e_243212, NTAG(TAG_Nil), v_rest2_243150}));
        V v_t_243221 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_243213_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str159)}), v_b_243220));
        V v_t_243222 = (g_std_2edoc_2e_3c_3e(v_a_243219, v_t_243221));
        V v_t_243223 = (g_std_2edoc_2e_3c_3e(v_t_243218, v_t_243222));
        return (g_std_2edoc_2e_3c_3e(v_t_243216, v_t_243223));
      }
      case TAG_Unrelated: {
        heff_drop_rec(v_op_243211, 9);
        heff_drop(v_e_243212);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243143;
        args[1] = v_m_243144;
        args[2] = v_f_243145;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
        args[4] = v_rest2_243150;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_243213, 0ULL, 1);
        heff_drop_rec(v_op_243211, 9);
        heff_drop(v_e_243212);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243143;
        args[1] = v_m_243144;
        args[2] = v_f_243145;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
        args[4] = v_rest2_243150;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_243213);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BPat: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetElse: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetMut: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAssign: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWhile: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFor: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EJump: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EReturn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENest: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EArrow: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_IfThen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETry: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECatch: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWith: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243143;
      args[1] = v_m_243144;
      args[2] = v_f_243145;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243149, v_acc_243146});
      args[4] = v_rest2_243150;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_243149);
    }
  }
  default: return heff_nomatch(v_rs_243147);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam134(V self, V *args) {
  V v_env_243319 = args[0];
  V v_a_243320 = args[1];
  switch (heff_tag_of(v_a_243320)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_243404 = heff_field(v_a_243320, 0);
    V v_arrow_243405 = heff_field(v_a_243320, 1);
    V v_body_243406 = heff_field(v_a_243320, 2);
    heff_take_n(v_a_243320, 7ULL, 3);
    V v_a_243407 = ({ V a_0 = heff_dup(v_env_243319); V a_1 = v_p_243404; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_243404); r_; });
    V v_b_243408 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243319), v_arrow_243405));
    V v_t_243409 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str160)}), v_b_243408));
    V v_t_243410 = (g_std_2edoc_2e_3c_3e(v_a_243407, v_t_243409));
    V v_t_243411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243319, v_body_243406}));
    return (g_std_2edoc_2e_3c_3e(v_t_243410, v_t_243411));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243319;
    args[1] = v_a_243320;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_243320);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam135(V self, V *args) {
  V v_env_243482 = args[0];
  V v_s_243483 = args[1];
  switch (heff_tag_of(v_s_243483)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V v_d_243576 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_243482, v_s_243483}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_243576});
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_243579 = heff_field(v_s_243483, 0);
    V v_arrow_243580 = heff_field(v_s_243483, 1);
    V v_e_243581 = heff_field(v_s_243483, 2);
    heff_take_n(v_s_243483, 7ULL, 3);
    V v_a_243582 = ({ V a_0 = heff_dup(v_env_243482); V a_1 = v_x_243579; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_243579); r_; });
    V v_b_243583 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243482), v_arrow_243580));
    V v_t_243584 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str161)}), v_b_243583));
    V v_t_243585 = (g_std_2edoc_2e_3c_3e(v_a_243582, v_t_243584));
    V v_t_243586 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243482, v_e_243581}));
    return (g_std_2edoc_2e_3c_3e(v_t_243585, v_t_243586));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V v_d_243632 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_243482, v_s_243483}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_243632});
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243482;
    args[1] = v_s_243483;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_243483);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam136(V self, V *args) {
  V v_env_243647 = args[0];
  V v_f_243648 = args[1];
  switch (heff_tag_of(v_f_243648)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_243675 = heff_field(v_f_243648, 0);
    V v_eq_243676 = heff_field(v_f_243648, 1);
    V v_e_243677 = heff_field(v_f_243648, 2);
    heff_take_n(v_f_243648, 7ULL, 3);
    V v_a_243678 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243647), v_x_243675}));
    V v_b_243679 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243647), v_eq_243676));
    V v_t_243680 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str162)}), v_b_243679));
    V v_t_243681 = (g_std_2edoc_2e_3c_3e(v_a_243678, v_t_243680));
    V v_t_243682 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243647, v_e_243677}));
    return (g_std_2edoc_2e_3c_3e(v_t_243681, v_t_243682));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_243688 = heff_field(v_f_243648, 0);
    V v_eq_243689 = heff_field(v_f_243648, 1);
    V v_e_243690 = heff_field(v_f_243648, 2);
    heff_take_n(v_f_243648, 7ULL, 3);
    V v_a_243691 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243647), v_x_243688));
    V v_b_243692 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243647), v_eq_243689));
    V v_t_243693 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str163)}), v_b_243692));
    V v_t_243694 = (g_std_2edoc_2e_3c_3e(v_a_243691, v_t_243693));
    V v_t_243695 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243647, v_e_243690}));
    return (g_std_2edoc_2e_3c_3e(v_t_243694, v_t_243695));
  }
  case TAG_EFDefault: {
    V v_d_243696 = heff_field(v_f_243648, 0);
    V v_eq_243697 = heff_field(v_f_243648, 1);
    V v_e_243698 = heff_field(v_f_243648, 2);
    heff_take_n(v_f_243648, 7ULL, 3);
    V v_a_243699 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243647), v_d_243696}));
    V v_b_243700 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243647), v_eq_243697));
    V v_t_243701 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str164)}), v_b_243700));
    V v_t_243702 = (g_std_2edoc_2e_3c_3e(v_a_243699, v_t_243701));
    V v_t_243703 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243647, v_e_243698}));
    return (g_std_2edoc_2e_3c_3e(v_t_243702, v_t_243703));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243647;
    args[1] = v_f_243648;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_243648);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        V v_ru_24x212_244_24Cons = heff_take_reuse_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        HEFF_LAST return g_std_2edoc_2egroup_24tok2(v_ru_24x212_244_24Cons, v_t_2426);
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_ix_244 = heff_take_field(v_t_243, 7);
    V v_blank_245 = heff_get_n(v_t_243, 8, 9);
    HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_ix_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2412;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = v_blank_245;
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop(v_blank_245);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_248);
        v_t_2412 = v_blank_245;
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0, 7, "doctest");
Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DFixity: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DSig: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DInstance: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DEqn: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DData: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DType: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTheory: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DMutual: {
    V v_ds_2434 = heff_field(v_d_241, 1);
    V v_x1_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ds_2434)));
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 7);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x1_2435, 0);
      V v_ru_24x1_2435_24Cons = heff_take_reuse_n(v_x1_2435, 1ULL, 2);
      switch (heff_tag_of(v_x_2436)) {
      case TAG_DImport: {
        heff_take_n(v_x_2436, 0ULL, 1);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DFixity: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DSig: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DInstance: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DEqn: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DData: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DType: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DTheory: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DMutual: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DPrimitive: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DTest: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        heff_drop_cell(v_ru_24x1_2435_24Cons, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_DWatch: {
        V v_w_2477 = heff_field(v_x_2436, 0);
        V v_e_2478 = heff_field(v_x_2436, 1);
        heff_take_n(v_x_2436, 3ULL, 2);
        V v_t_2479 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_2477, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0)));
        heff_drop_rec(v_w_2477, 9);
        V v_t_2480 = (g_heff_2esyntax_2ecst_2elastE(v_e_2478));
        V v_t_2481 = heff_intAdd(heff_get_n(v_t_2480, 7, 9), MK_INT(1LL));
        HeffT2 v_t_2482 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_t_2481; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2486;
        {
          V v_field_2484 = v_t_2482.f[1];
          int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
          if ((v_tag_2483 == ((int64_t)0ULL))) {
            V v_x_2485 = v_field_2484;
            v_t_2486 = v_x_2485;
          } else {
            heff_drop(v_field_2484);
            v_t_2486 = NTAG(TAG_Nil);
          }
        }
        return ({ V a_0 = v_ru_24x1_2435_24Cons; V a_1 = v_t_2479; V a_2 = v_t_2486; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(a_0, a_1, a_2)); heff_drop(v_t_2479); r_; });
      }
      default: return heff_nomatch(v_x_2436);
      }
    }
    default: return heff_nomatch(v_x1_2435);
    }
  }
  case TAG_DPrimitive: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTest: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DWatch: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eblockExpect(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_get_n(v_eof_243, 7, 9)));
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        v_t_249 = v_x_248;
      } else {
        heff_drop(v_field_247);
        v_t_249 = NTAG(TAG_Nil);
      }
    }
    return ({ V a_0 = v_env_240; V a_1 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_249); r_; });
  }
  case TAG_Cons: {
    V v_d_2410 = heff_field(v_x5_244, 0);
    V v_ds_2411 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2410));
    V v_t_2454;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_DImport: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2452 = heff_dup(heff_field(v_d_2410, 0));
      v_t_2454 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_2452, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0)));
      heff_drop_rec(v_w_2452, 9);
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    V v_t_2482;
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
      V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2455, v_t_2456, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2410)})));
      V v_t_2459 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2410); r_; });
      V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2459, v_eof_243, v_ds_2411));
      v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2460));
    } else {
      heff_drop(v_t_2454);
      V v_t_2461 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2461);
        V v_t_2462 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2410));
        V v_t_2464 = ({ V a_0 = v_t_2463; V a_1 = heff_dup(v_d_2410); V a_2 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
        V v_t_2465 = (g_heff_2esyntax_2ecst_2elastD(v_t_2464));
        V v_t_2466 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2462, v_t_2465));
        V v_t_2467 = ({ V a_0 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2410); r_; });
        V v_t_2468 = ({ V a_0 = v_t_2467; V a_1 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2467); r_; });
        V v_t_2469 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2468));
        v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2466, v_t_2469));
      } else {
        heff_drop(v_t_2461);
        V v_expect_2470 = (g_heff_2esyntax_2efmt_2elayout_2eblockExpect(heff_dup(v_env_240), v_d_2410));
        V v_t_2471 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_t_2472 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
        V v_t_2474 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2471, v_t_2472, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2410)})));
        V v_d_2475 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_2470));
        V v_t_2476 = (g_heff_2esyntax_2ecst_2elastD(v_d_2410));
        V v_t_2477 = heff_intAdd(heff_get_n(v_t_2476, 7, 9), MK_INT(1LL));
        V v_t_2478 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_2470; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_2470); r_; });
        V v_t_2479 = (g_heff_2esyntax_2efmt_2elayout_2eleadLaid(v_env_240, v_t_2477, v_t_2478));
        V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_2479, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2411));
        V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2475}), v_t_2480));
        v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2474, v_t_2481));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2482));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2457 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2457; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2473 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2473; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V v_f_240, V v_src_241, V v_claim_242, V v_l_243) {
top: ;
  V v_errors_244 = heff_take_field(v_l_243, 1);
  V v_tokens_245 = heff_take_field(v_l_243, 0);
  V v_comments_246 = heff_get_n(v_l_243, 2, 3);
  V v_exposing_247 = heff_take_field(v_claim_242, 1);
  V v_imports_248 = heff_get_n(v_claim_242, 0, 3);
  switch (heff_tag_of(v_errors_244)) {
  case TAG_Nil: {
    V v_t_249 = ({ V a_0 = v_exposing_247; V r_ = (g_heff_2esyntax_2efmt_2eimports_2eexposingToks(a_0)); heff_drop(v_exposing_247); r_; });
    V v_t_2410 = (g_list_2emap_24s1845612977x612508518(v_imports_248));
    V v_t_2411 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_tokens_245, v_t_249, v_t_2410));
    V v_t_2412 = (g_list_2esortBy_24s88152486x2058486153(v_t_2411));
    HeffT2 v_t_2413 = (g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(v_src_241, v_t_2412, v_comments_246));
    V v_t_2422;
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_src_2416 = heff_take_field(v_field_2415, 0);
      V v_lead_2417 = heff_take_field(v_field_2415, 1);
      V v_inline_2418 = heff_take_field(v_field_2415, 2);
      V v_trail_2419 = heff_take_field(v_field_2415, 3);
      V v_noLead_2420 = heff_take_field(v_field_2415, 4);
      V v_noTrail_2421 = heff_get_n(v_field_2415, 5, 7);
      v_t_2422 = heff_rec_n(2, shape_toks__env, (V[]){v_field_2414, heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_src_2416, v_lead_2417, v_inline_2418, v_trail_2419, v_noLead_2420, v_noTrail_2421, v_f_240})});
    }
    return (g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(v_t_2422));
  }
  case TAG_Cons: {
    heff_take_n(v_errors_244, 0ULL, 2);
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop(v_tokens_245);
    heff_drop(v_comments_246);
    heff_drop(v_exposing_247);
    heff_drop(v_imports_248);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_errors_244)}});
  }
}