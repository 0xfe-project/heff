// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_exposing 966605106
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks(V);
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eexposingToks_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(V);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
HeffT2 g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(V, V, V);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str111, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str113, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str115, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str116, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str117, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str118, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str119, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str120, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str122, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str123, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str125, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str126, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str127, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str128, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str129, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str131, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str132, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str133, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str135, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str136, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str137, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str138, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str140, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str141, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str142, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str143, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str144, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str145, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str146, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str147, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str148, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str149, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str150, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str151, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str152, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str153, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str154, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str155, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str156, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str157, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str158, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str159, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str160, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str161, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str162, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str163, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str164, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam126, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam127, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam128, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam129, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam131(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam132(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam130, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam133(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam133, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam134(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam134, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam135(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam135, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam136(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam136, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam129_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam130_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam133_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam134_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam135_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam136_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2445 = args[0];
  V v_e_2446 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2445));
  V v_one_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2446));
  V v_b_2453;
  if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
    heff_drop(v_t_2449);
    V v_d_2450 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2450});
  } else {
    heff_drop(v_t_2449);
    V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_2446));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop(v_t_2451);
      V v_d_2452 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
      v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2452});
    } else {
      heff_drop(v_t_2451);
      v_b_2453 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    }
  }
  V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2453));
  V v_t_2455 = (g_std_2edoc_2e_3c_3e(v_a_2447, v_t_2454));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2455));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  V v_d_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2467 = heff_intSub(v_k_2465, v_i_2466);
  if (heff_intEq_c_lent(v_i_2467, MK_INT(0LL), 2)) {
    heff_drop(v_i_2467);
    return v_d_2464;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2467, v_d_2464});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2465 = args[0];
  V v_d_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2465, v_d_2464})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2474 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2474));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2489 = args[0];
  V v_f_2490 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2489));
  V v_d_2492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2490}));
  V v_t_2493 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2492})));
  V v_t_2494 = (g_std_2edoc_2e_3c_3e(v_a_2491, v_t_2493));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2494));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24103 = args[0];
  V v_k_24102 = heff_env(self)[0];
  V v_d_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24104 = heff_intSub(v_k_24102, v_i_24103);
  if (heff_intEq_c_lent(v_i_24104, MK_INT(0LL), 2)) {
    heff_drop(v_i_24104);
    return v_d_24101;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24104, v_d_24101});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24102 = args[0];
  V v_d_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24102, v_d_24101})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24131 = args[0];
  V v_f_24132 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24133 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24131));
  V v_d_24134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24132}));
  V v_t_24135 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24134})));
  V v_t_24136 = (g_std_2edoc_2e_3c_3e(v_a_24133, v_t_24135));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24136));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24147 = args[0];
  V v_k_24146 = heff_env(self)[0];
  V v_d_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24148 = heff_intSub(v_k_24146, v_i_24147);
  if (heff_intEq_c_lent(v_i_24148, MK_INT(0LL), 2)) {
    heff_drop(v_i_24148);
    return v_d_24145;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24148, v_d_24145});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24146 = args[0];
  V v_d_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24146, v_d_24145})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24205 = args[0];
  V v_a_24206 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24188 = heff_env(self)[1];
  V v_c_24191 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24207 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24188, 4, 9), heff_get_n(v_c_24191, 3, 9)));
  V v_t_24208;
  if ((heff_dup(v_x1_24207) == NTAG(TAG_True))) {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24209 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24205));
  V v_b_24210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24206}));
  V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24210));
  V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
  return (g_std_2edoc_2e_3c_3e(v_t_24208, v_t_24212));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24219 = args[0];
  V v_k_24218 = heff_env(self)[0];
  V v_d_24217 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24220 = heff_intSub(v_k_24218, v_i_24219);
  if (heff_intEq_c_lent(v_i_24220, MK_INT(0LL), 2)) {
    heff_drop(v_i_24220);
    return v_d_24217;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24220, v_d_24217});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24218 = args[0];
  V v_d_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24218, v_d_24217})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24227 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24228 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24227}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24228));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24253 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24251 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24254 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24253));
  V v_t_24255;
  if ((heff_dup(v_x1_24254) == NTAG(TAG_True))) {
    heff_drop(v_x1_24254);
    v_t_24255 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24254);
    v_t_24255 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24256 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24251, v_r_24253}));
  return (g_std_2edoc_2e_3c_3e(v_t_24255, v_t_24256));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24370 = args[0];
  V v_k_24369 = heff_env(self)[0];
  V v_d_24368 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24371 = heff_intSub(v_k_24369, v_i_24370);
  if (heff_intEq_c_lent(v_i_24371, MK_INT(0LL), 2)) {
    heff_drop(v_i_24371);
    return v_d_24368;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24371, v_d_24368});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24369 = args[0];
  V v_d_24368 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24369, v_d_24368})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24435 = args[0];
  V v_k_24434 = heff_env(self)[0];
  V v_d_24431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24436 = heff_intSub(v_k_24434, v_i_24435);
  if (heff_intEq_c_lent(v_i_24436, MK_INT(0LL), 2)) {
    heff_drop(v_i_24436);
    return v_d_24431;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24436, v_d_24431});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24434 = args[0];
  V v_d_24431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24434, v_d_24431})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24455 = args[0];
  V v_k_24454 = heff_env(self)[0];
  V v_d_24451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24456 = heff_intSub(v_k_24454, v_i_24455);
  if (heff_intEq_c_lent(v_i_24456, MK_INT(0LL), 2)) {
    heff_drop(v_i_24456);
    return v_d_24451;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24456, v_d_24451});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24454 = args[0];
  V v_d_24451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24454, v_d_24451})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24508 = args[0];
  V v_k_24507 = heff_env(self)[0];
  V v_d_24506 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24509 = heff_intSub(v_k_24507, v_i_24508);
  if (heff_intEq_c_lent(v_i_24509, MK_INT(0LL), 2)) {
    heff_drop(v_i_24509);
    return v_d_24506;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24509, v_d_24506});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24507 = args[0];
  V v_d_24506 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24507, v_d_24506})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_i_24540 = args[0];
  V v_k_24539 = heff_env(self)[0];
  V v_d_24530 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24541 = heff_intSub(v_k_24539, v_i_24540);
  if (heff_intEq_c_lent(v_i_24541, MK_INT(0LL), 2)) {
    heff_drop(v_i_24541);
    return v_d_24530;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24541, v_d_24530});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_k_24539 = args[0];
  V v_d_24530 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 2, (V[]){v_k_24539, v_d_24530})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2429)));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_one_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2440 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2435));
      V v_t_2444;
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        V v_d_2441 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2441});
      } else {
        heff_drop(v_t_2440);
        V v_t_2442 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e1_2435));
        if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
          heff_drop(v_t_2442);
          V v_d_2443 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
          v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2443});
        } else {
          heff_drop(v_t_2442);
          v_t_2444 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        }
      }
      V v_t_2456 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2431; V a_3 = v_more_2436; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2431); heff_drop(v_more_2436); r_; });
      V v_x1_2457 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2429, 4, 9), heff_dup(heff_rfield(v_c_2432, 3))));
      V v_t_2458;
      if ((heff_dup(v_x1_2457) == NTAG(TAG_True))) {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
      V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2456, v_t_2460));
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2444, v_t_2461));
      V v_t_2463 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2462));
      V v_d_2464 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2463));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2464})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Seg: {
    V v_v_2469 = heff_field(v_e0_241, 0);
    V v_cc_2470 = heff_field(v_e0_241, 1);
    V v_spec_2471 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2469}));
    V v_t_2473 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2470));
    V v_t_2475 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2471; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2471); r_; });
    V v_t_2476 = (g_std_2edoc_2e_3c_3e(v_t_2473, v_t_2475));
    return (g_std_2edoc_2e_3c_3e(v_t_2472, v_t_2476));
  }
  case TAG_Braces: {
    V v_o_2477 = heff_field(v_e0_241, 0);
    V v_fs_2478 = heff_field(v_e0_241, 1);
    V v_commas_2479 = heff_field(v_e0_241, 2);
    V v_c_2480 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2478)) {
    case TAG_Nil: {
      heff_drop(v_commas_2479);
      V v_t_2481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2477));
      V v_t_2482 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      return (g_std_2edoc_2e_3c_3e(v_t_2481, v_t_2482));
    }
    case TAG_Cons: {
      V v_f1_2483 = heff_field(v_fs_2478, 0);
      V v_more_2484 = heff_field(v_fs_2478, 1);
      V v_ru_24fs_2478_24Cons = heff_take_reuse_n(v_fs_2478, 3ULL, 2);
      V v_a_2485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2477)));
      V v_d_2486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2483}));
      V v_t_2487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2478_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2486})));
      V v_t_2488 = (g_std_2edoc_2e_3c_3e(v_a_2485, v_t_2487));
      V v_t_2495 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2479; V a_3 = v_more_2484; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2479); heff_drop(v_more_2484); r_; });
      V v_x1_2496 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2477, 4, 9), heff_dup(heff_rfield(v_c_2480, 3))));
      V v_t_2497;
      if ((heff_dup(v_x1_2496) == NTAG(TAG_True))) {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2498 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      V v_t_2499 = (g_std_2edoc_2e_3c_3e(v_t_2497, v_t_2498));
      V v_t_24100 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2499));
      V v_d_24101 = (g_std_2edoc_2e_3c_3e(v_t_2488, v_t_24100));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_24101})})));
    }
    default: return heff_nomatch(v_fs_2478);
    }
  }
  case TAG_Update: {
    V v_o_24106 = heff_field(v_e0_241, 0);
    V v_r_24107 = heff_field(v_e0_241, 1);
    V v_bar_24108 = heff_field(v_e0_241, 2);
    V v_fs_24109 = heff_field(v_e0_241, 3);
    V v_commas_24110 = heff_field(v_e0_241, 4);
    V v_c_24111 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24109)) {
    case TAG_Nil: {
      heff_drop(v_commas_24110);
      V v_a_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24106));
      V v_a_24113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_a_24114 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_b_24115 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(v_a_24114, v_t_24116));
      V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24117));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24118));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24119));
      return (g_std_2edoc_2e_3c_3e(v_a_24112, v_t_24120));
    }
    case TAG_Cons: {
      V v_f1_24121 = heff_field(v_fs_24109, 0);
      V v_more_24122 = heff_field(v_fs_24109, 1);
      V v_ru_24fs_24109_24Cons = heff_take_reuse_n(v_fs_24109, 3ULL, 2);
      V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24106)));
      V v_d_24124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24109_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24124})));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
      V v_a_24127 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_d_24128 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24121}));
      V v_t_24129 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24128})));
      V v_t_24130 = (g_std_2edoc_2e_3c_3e(v_a_24127, v_t_24129));
      V v_t_24137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24110; V a_3 = v_more_24122; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24110); heff_drop(v_more_24122); r_; });
      V v_x1_24138 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24106, 4, 9), heff_dup(heff_rfield(v_c_24111, 3))));
      V v_t_24139;
      if ((heff_dup(v_x1_24138) == NTAG(TAG_True))) {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24140 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(v_t_24139, v_t_24140));
      V v_t_24142 = (g_std_2edoc_2e_3c_3e(v_t_24137, v_t_24141));
      V v_t_24143 = (g_std_2edoc_2e_3c_3e(v_t_24130, v_t_24142));
      V v_t_24144 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24143));
      V v_d_24145 = (g_std_2edoc_2e_3c_3e(v_t_24126, v_t_24144));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24145})})));
    }
    default: return heff_nomatch(v_fs_24109);
    }
  }
  case TAG_EUSet: {
    V v_x_24150 = heff_field(v_e0_241, 0);
    V v_eq_24151 = heff_field(v_e0_241, 1);
    V v_e_24152 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24150}));
    V v_b_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24151));
    V v_t_24155 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24154));
    V v_t_24156 = (g_std_2edoc_2e_3c_3e(v_a_24153, v_t_24155));
    V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24152}));
    return (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
  }
  case TAG_InstB: {
    V v_o_24158 = heff_field(v_e0_241, 0);
    V v_o2_24159 = heff_field(v_e0_241, 1);
    V v_d_24160 = heff_field(v_e0_241, 2);
    V v_c1_24161 = heff_field(v_e0_241, 3);
    V v_c_24162 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24158));
    V v_t_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24159));
    V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24160}));
    V v_t_24166 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24161));
    V v_t_24167 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24162));
    V v_t_24168 = (g_std_2edoc_2e_3c_3e(v_t_24166, v_t_24167));
    V v_t_24169 = (g_std_2edoc_2e_3c_3e(v_t_24165, v_t_24168));
    V v_t_24170 = (g_std_2edoc_2e_3c_3e(v_t_24164, v_t_24169));
    return (g_std_2edoc_2e_3c_3e(v_t_24163, v_t_24170));
  }
  case TAG_EFSet: {
    V v_x_24171 = heff_field(v_e0_241, 0);
    V v_eq_24172 = heff_field(v_e0_241, 1);
    V v_e_24173 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24174 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24171));
    V v_b_24175 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24172));
    V v_t_24176 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24175));
    V v_t_24177 = (g_std_2edoc_2e_3c_3e(v_a_24174, v_t_24176));
    V v_t_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24173}));
    return (g_std_2edoc_2e_3c_3e(v_t_24177, v_t_24178));
  }
  case TAG_EFDefault: {
    V v_d_24179 = heff_field(v_e0_241, 0);
    V v_eq_24180 = heff_field(v_e0_241, 1);
    V v_e_24181 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24179}));
    V v_b_24183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24180));
    V v_t_24184 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24183));
    V v_t_24185 = (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24184));
    V v_t_24186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24181}));
    return (g_std_2edoc_2e_3c_3e(v_t_24185, v_t_24186));
  }
  case TAG_Sum: {
    V v_kw_24187 = heff_field(v_e0_241, 0);
    V v_o_24188 = heff_field(v_e0_241, 1);
    V v_alts_24189 = heff_field(v_e0_241, 2);
    V v_bars_24190 = heff_field(v_e0_241, 3);
    V v_c_24191 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24189)) {
    case TAG_Nil: {
      heff_drop(v_bars_24190);
      V v_a_24192 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24193 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24188));
      V v_b_24194 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24195 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24194));
      V v_t_24196 = (g_std_2edoc_2e_3c_3e(v_a_24193, v_t_24195));
      V v_t_24197 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24196));
      return (g_std_2edoc_2e_3c_3e(v_a_24192, v_t_24197));
    }
    case TAG_Cons: {
      V v_a1_24198 = heff_field(v_alts_24189, 0);
      V v_more_24199 = heff_field(v_alts_24189, 1);
      heff_take_n(v_alts_24189, 3ULL, 2);
      V v_a_24200 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24201 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24188)));
      V v_b_24202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24198}));
      V v_t_24203 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24202));
      V v_t_24204 = (g_std_2edoc_2e_3c_3e(v_a_24201, v_t_24203));
      V v_a_24213 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24188, heff_dup(v_c_24191)}); V a_2 = v_bars_24190; V a_3 = v_more_24199; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24190); heff_drop(v_more_24199); r_; });
      V v_b_24214 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24215 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24214));
      V v_t_24216 = (g_std_2edoc_2e_3c_3e(v_a_24213, v_t_24215));
      V v_d_24217 = (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24216));
      V v_b_24222 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24217})})));
      V v_t_24223 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24222));
      return (g_std_2edoc_2e_3c_3e(v_a_24200, v_t_24223));
    }
    default: return heff_nomatch(v_alts_24189);
    }
  }
  case TAG_ECon: {
    V v_c_24224 = heff_field(v_e0_241, 0);
    V v_args_24225 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24224));
    V v_t_24229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24225; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24225); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24229));
  }
  case TAG_EField: {
    V v_e_24230 = heff_field(v_e0_241, 0);
    V v_f_24231 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24230}));
    V v_t_24233 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24231));
    return (g_std_2edoc_2e_3c_3e(v_t_24232, v_t_24233));
  }
  case TAG_ENeg: {
    V v_m_24234 = heff_field(v_e0_241, 0);
    V v_e_24235 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24236 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24234));
    V v_t_24237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24235}));
    return (g_std_2edoc_2e_3c_3e(v_t_24236, v_t_24237));
  }
  case TAG_ETilde: {
    V v_m_24238 = heff_field(v_e0_241, 0);
    V v_e_24239 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24240 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24238));
    V v_t_24241 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24239}));
    return (g_std_2edoc_2e_3c_3e(v_t_24240, v_t_24241));
  }
  case TAG_App: {
    V v_h_24242 = heff_field(v_e0_241, 0);
    V v_args_24243 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24242;
    heff_room[2] = v_args_24243;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24244 = heff_field(v_e0_241, 0);
    V v_op_24245 = heff_field(v_e0_241, 1);
    V v_b_24246 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24247 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24244, v_op_24245, v_b_24246})));
    {
      V v_field_24248 = v_t_24247.f[0];
      V v_field_24249 = v_t_24247.f[1];
      V v_first_24250 = v_field_24248;
      V v_rest_24251 = v_field_24249;
      V v_t_24252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24251), v_first_24250}));
      V v_t_24257 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24251)}); V a_2 = v_rest_24251; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24251); r_; });
      V v_t_24258 = (g_std_2edoc_2e_3c_3e(v_t_24252, v_t_24257));
      return (g_std_2edoc_2egroup(v_t_24258));
    }
  }
  case TAG_Ops: {
    V v_a_24259 = heff_field(v_e0_241, 0);
    V v_rest_24260 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24259;
    heff_room[2] = v_rest_24260;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24261 = heff_field(v_e0_241, 0);
    V v_e_24262 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24263 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24261));
    V v_b_24264 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24262}));
    V v_t_24265 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24264));
    return (g_std_2edoc_2e_3c_3e(v_a_24263, v_t_24265));
  }
  case TAG_Ann: {
    V v_e_24266 = heff_field(v_e0_241, 0);
    V v_cc_24267 = heff_field(v_e0_241, 1);
    V v_ty_24268 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24269 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24266}));
    V v_b_24270 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24267));
    V v_t_24271 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24270));
    V v_t_24272 = (g_std_2edoc_2e_3c_3e(v_a_24269, v_t_24271));
    V v_t_24273 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24268}));
    V v_d_24274 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24273));
    V v_t_24275 = (g_std_2edoc_2e_3c_3e(v_t_24272, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24274})));
    return (g_std_2edoc_2egroup(v_t_24275));
  }
  case TAG_BVar: {
    V v_t_24276 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24276));
  }
  case TAG_BImp: {
    V v_o_24277 = heff_field(v_e0_241, 0);
    V v_x_24278 = heff_field(v_e0_241, 1);
    V v_c_24279 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24280 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24277));
    V v_t_24281 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24278));
    V v_t_24282 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24279));
    V v_t_24283 = (g_std_2edoc_2e_3c_3e(v_t_24281, v_t_24282));
    return (g_std_2edoc_2e_3c_3e(v_t_24280, v_t_24283));
  }
  case TAG_BAnn: {
    V v_o_24284 = heff_field(v_e0_241, 0);
    V v_x_24285 = heff_field(v_e0_241, 1);
    V v_cc_24286 = heff_field(v_e0_241, 2);
    V v_ty_24287 = heff_field(v_e0_241, 3);
    V v_c_24288 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24289 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24284));
    V v_a_24290 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24285));
    V v_a_24291 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24286));
    V v_b_24292 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24287}));
    V v_t_24293 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24292));
    V v_t_24294 = (g_std_2edoc_2e_3c_3e(v_a_24291, v_t_24293));
    V v_t_24295 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24294));
    V v_t_24296 = (g_std_2edoc_2e_3c_3e(v_a_24290, v_t_24295));
    V v_t_24297 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24288));
    V v_t_24298 = (g_std_2edoc_2e_3c_3e(v_t_24296, v_t_24297));
    return (g_std_2edoc_2e_3c_3e(v_t_24289, v_t_24298));
  }
  case TAG_BPat: {
    V v_p_24299 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return ({ V a_0 = v_env_240; V a_1 = v_p_24299; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24299); r_; });
  }
  case TAG_Lam: {
    V v_bs_24300 = heff_field(v_e0_241, 0);
    V v_binders_24301 = heff_field(v_e0_241, 1);
    V v_arrow_24302 = heff_field(v_e0_241, 2);
    V v_body_24303 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24304 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24300));
    V v_t_24305 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24306 = (g_list_2emap(v_t_24305, v_binders_24301));
    V v_a_24307 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24306; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24306); r_; });
    V v_b_24308 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24302));
    V v_t_24309 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24308));
    V v_t_24310 = (g_std_2edoc_2e_3c_3e(v_a_24307, v_t_24309));
    V v_t_24311 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24303));
    V v_t_24315;
    if ((heff_dup(v_t_24311) == NTAG(TAG_True))) {
      heff_drop(v_t_24311);
      V v_t_24312 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24303}));
      v_t_24315 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24312));
    } else {
      heff_drop(v_t_24311);
      V v_t_24313 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24303}));
      V v_d_24314 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24313));
      v_t_24315 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24314})));
    }
    V v_t_24316 = (g_std_2edoc_2e_3c_3e(v_t_24310, v_t_24315));
    return (g_std_2edoc_2e_3c_3e(v_t_24304, v_t_24316));
  }
  case TAG_Case: {
    V v_kw_24317 = heff_field(v_e0_241, 0);
    V v_scrut_24318 = heff_field(v_e0_241, 1);
    V v_of2_24319 = heff_field(v_e0_241, 2);
    V v_alts_24320 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24321 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24317));
    V v_a_24322 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24318}));
    V v_b_24323 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24319));
    V v_t_24324 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24323));
    V v_t_24325 = (g_std_2edoc_2e_3c_3e(v_a_24322, v_t_24324));
    V v_t_24326 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24325));
    V v_t_24327 = (g_std_2edoc_2e_3c_3e(v_a_24321, v_t_24326));
    V v_t_24328 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24320; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24320); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24327, v_t_24328));
  }
  case TAG_EAlt: {
    V v_p_24329 = heff_field(v_e0_241, 0);
    V v_arrow_24330 = heff_field(v_e0_241, 1);
    V v_body_24331 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24332 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24329; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24329); r_; });
    V v_b_24333 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24330));
    V v_t_24334 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24333));
    V v_t_24335 = (g_std_2edoc_2e_3c_3e(v_a_24332, v_t_24334));
    V v_t_24336 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24331}));
    return (g_std_2edoc_2e_3c_3e(v_t_24335, v_t_24336));
  }
  case TAG_If: {
    V v_kw_24337 = heff_field(v_e0_241, 0);
    V v_c_24338 = heff_field(v_e0_241, 1);
    V v_th_24339 = heff_field(v_e0_241, 2);
    V v_a_24340 = heff_field(v_e0_241, 3);
    V v_el_24341 = heff_field(v_e0_241, 4);
    V v_b_24342 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24343 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24337, v_c_24338, v_th_24339, v_a_24340}));
    V v_t_24344 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24341, v_b_24342}));
    V v_t_24345 = (g_std_2edoc_2e_3c_3e(v_t_24343, v_t_24344));
    return (g_std_2edoc_2egroup(v_t_24345));
  }
  case TAG_Do: {
    V v_kw_24346 = heff_field(v_e0_241, 0);
    V v_stmts_24347 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24348 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24346));
    V v_t_24349 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24347; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24347); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24348, v_t_24349));
  }
  case TAG_ESBind: {
    V v_x_24350 = heff_field(v_e0_241, 0);
    V v_arrow_24351 = heff_field(v_e0_241, 1);
    V v_e_24352 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24353 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24350; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24350); r_; });
    V v_b_24354 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24351));
    V v_t_24355 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24354));
    V v_t_24356 = (g_std_2edoc_2e_3c_3e(v_a_24353, v_t_24355));
    V v_t_24357 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24352}));
    return (g_std_2edoc_2e_3c_3e(v_t_24356, v_t_24357));
  }
  case TAG_ELet: {
    V v_kw_24358 = heff_field(v_e0_241, 0);
    V v_p_24359 = heff_field(v_e0_241, 1);
    V v_ann_24360 = heff_field(v_e0_241, 2);
    V v_eq_24361 = heff_field(v_e0_241, 3);
    V v_e_24362 = heff_field(v_e0_241, 4);
    V v_body_24363 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24363)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24358, v_p_24359, v_ann_24360, v_eq_24361, v_e_24362});
    }
    case TAG_Just: {
      V v_it1_24364 = heff_field(v_body_24363, 0);
      V v_ru_24body_24363_24Just = heff_take_reuse_n(v_body_24363, 1ULL, 1);
      switch (heff_tag_of(v_it1_24364)) {
      case TAG_MkPair: {
        V v_i_24365 = heff_field(v_it1_24364, 0);
        V v_b_24366 = heff_field(v_it1_24364, 1);
        heff_take_n(v_it1_24364, 3ULL, 2);
        V v_t_24367 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24358, v_p_24359, v_ann_24360, v_eq_24361, v_e_24362, v_i_24365, v_b_24366}));
        V v_d_24368 = (g_std_2edoc_2egroup(v_t_24367));
        return heff_tag_at_n(v_ru_24body_24363_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24368})});
      }
      default: return heff_nomatch(v_it1_24364);
      }
    }
    default: return heff_nomatch(v_body_24363);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24373 = heff_field(v_e0_241, 0);
    V v_p_24374 = heff_field(v_e0_241, 1);
    V v_ann_24375 = heff_field(v_e0_241, 2);
    V v_eq_24376 = heff_field(v_e0_241, 3);
    V v_e_24377 = heff_field(v_e0_241, 4);
    V v_el_24378 = heff_field(v_e0_241, 5);
    V v_ss_24379 = heff_field(v_e0_241, 6);
    heff_take_n(v_e0_241, 127ULL, 7);
    V v_a_24380 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_240), v_kw_24373, v_p_24374, v_ann_24375, v_eq_24376, v_e_24377}));
    V v_b_24381 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_el_24378));
    V v_t_24382 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24381));
    V v_t_24383 = (g_std_2edoc_2e_3c_3e(v_a_24380, v_t_24382));
    V v_t_24391;
    switch (heff_tag_of(v_ss_24379)) {
    case TAG_Nil: {
      v_t_24391 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(v_env_240, MK_INT(0LL), v_ss_24379));
      break;
    }
    case TAG_Cons: {
      V v_s1_24384 = heff_dup(heff_field(v_ss_24379, 0));
      V v_it2_24385 = heff_dup(heff_field(v_ss_24379, 1));
      switch (heff_tag_of(v_it2_24385)) {
      case TAG_Nil: {
        V v_t_24386 = (g_heff_2esyntax_2ecst_2efirstE(v_s1_24384));
        V v_t_24387 = heff_get_n(v_t_24386, 6, 9);
        if ((heff_dup(v_t_24387) == NTAG(TAG_True))) {
          heff_drop(v_s1_24384);
          heff_drop(v_t_24387);
          v_t_24391 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24379; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop_tag(v_ss_24379, 2); r_; });
        } else {
          heff_drop_tag(v_ss_24379, 2);
          heff_drop(v_t_24387);
          V v_t_24388 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14)), 2, (V[]){v_env_240, v_s1_24384}));
          v_t_24391 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24388));
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it2_24385, 0ULL, 2);
        heff_drop(v_s1_24384);
        v_t_24391 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24379; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop_tag(v_ss_24379, 2); r_; });
        break;
      }
      default: heff_nomatch(v_it2_24385);
      }
      break;
    }
    default: heff_nomatch(v_ss_24379);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_24383, v_t_24391));
  }
  case TAG_ELetMut: {
    V v_kw_24392 = heff_field(v_e0_241, 0);
    V v_m_24393 = heff_field(v_e0_241, 1);
    V v_x_24394 = heff_field(v_e0_241, 2);
    V v_ann_24395 = heff_field(v_e0_241, 3);
    V v_eq_24396 = heff_field(v_e0_241, 4);
    V v_e_24397 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24398 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24392));
    V v_a_24399 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24393));
    V v_b_24400 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24394));
    V v_t_24401 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24400));
    V v_t_24402 = (g_std_2edoc_2e_3c_3e(v_a_24399, v_t_24401));
    V v_t_24403 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24402));
    V v_t_24404 = (g_std_2edoc_2e_3c_3e(v_a_24398, v_t_24403));
    V v_a_24412;
    switch (heff_tag_of(v_ann_24395)) {
    case TAG_Nothing: {
      v_a_24412 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24405 = heff_field(v_ann_24395, 0);
      V v_ru_24ann_24395_24Just = heff_take_reuse_n(v_ann_24395, 1ULL, 1);
      switch (heff_tag_of(v_it1_24405)) {
      case TAG_MkPair: {
        V v_cc_24406 = heff_field(v_it1_24405, 0);
        V v_ty_24407 = heff_field(v_it1_24405, 1);
        heff_take_n(v_it1_24405, 3ULL, 2);
        V v_a_24408 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24406));
        V v_b_24409 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24407}));
        V v_t_24410 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24395_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24409));
        V v_t_24411 = (g_std_2edoc_2e_3c_3e(v_a_24408, v_t_24410));
        v_a_24412 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_t_24411));
        break;
      }
      default: heff_nomatch(v_it1_24405);
      }
      break;
    }
    default: heff_nomatch(v_ann_24395);
    }
    V v_b_24413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24396));
    V v_t_24414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24413));
    V v_t_24415 = (g_std_2edoc_2e_3c_3e(v_a_24412, v_t_24414));
    V v_t_24416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24397}));
    V v_t_24417 = (g_std_2edoc_2e_3c_3e(v_t_24415, v_t_24416));
    return (g_std_2edoc_2e_3c_3e(v_t_24404, v_t_24417));
  }
  case TAG_EAssign: {
    V v_x_24418 = heff_field(v_e0_241, 0);
    V v_k_24419 = heff_field(v_e0_241, 1);
    V v_e_24420 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24418));
    V v_b_24422 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24419));
    V v_t_24423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_b_24422));
    V v_t_24424 = (g_std_2edoc_2e_3c_3e(v_a_24421, v_t_24423));
    V v_t_24425 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24420}));
    return (g_std_2edoc_2e_3c_3e(v_t_24424, v_t_24425));
  }
  case TAG_EWhile: {
    V v_kw_24426 = heff_field(v_e0_241, 0);
    V v_c_24427 = heff_field(v_e0_241, 1);
    V v_d_24428 = heff_field(v_e0_241, 2);
    V v_body_24429 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24430 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24426));
    V v_d_24431 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24427}));
    V v_b_24432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24428));
    V v_t_24433 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24432));
    V v_t_24438 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24431})}), v_t_24433));
    V v_t_24439 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24438));
    V v_t_24440 = (g_std_2edoc_2e_3c_3e(v_a_24430, v_t_24439));
    V v_t_24441 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24429; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24429); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24440, v_t_24441));
  }
  case TAG_EFor: {
    V v_kw_24442 = heff_field(v_e0_241, 0);
    V v_p_24443 = heff_field(v_e0_241, 1);
    V v_i_24444 = heff_field(v_e0_241, 2);
    V v_c_24445 = heff_field(v_e0_241, 3);
    V v_d_24446 = heff_field(v_e0_241, 4);
    V v_body_24447 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24448 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24442));
    V v_a_24449 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24443; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24443); r_; });
    V v_a_24450 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24444));
    V v_d_24451 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24445}));
    V v_b_24452 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24446));
    V v_t_24453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_b_24452));
    V v_t_24458 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24451})}), v_t_24453));
    V v_t_24459 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24458));
    V v_t_24460 = (g_std_2edoc_2e_3c_3e(v_a_24450, v_t_24459));
    V v_t_24461 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), v_t_24460));
    V v_t_24462 = (g_std_2edoc_2e_3c_3e(v_a_24449, v_t_24461));
    V v_t_24463 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_t_24462));
    V v_t_24464 = (g_std_2edoc_2e_3c_3e(v_a_24448, v_t_24463));
    V v_t_24465 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24447; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24447); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24464, v_t_24465));
  }
  case TAG_EJump: {
    V v_kw_24466 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_kw_24466));
  }
  case TAG_EReturn: {
    V v_kw_24467 = heff_field(v_e0_241, 0);
    V v_e_24468 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24469 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24467));
    V v_d_24470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24468}));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24470})));
    return (g_std_2edoc_2e_3c_3e(v_a_24469, v_t_24471));
  }
  case TAG_ENest: {
    V v_o_24472 = heff_field(v_e0_241, 0);
    V v_arrow_24473 = heff_field(v_e0_241, 1);
    V v_e_24474 = heff_field(v_e0_241, 2);
    V v_c_24475 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24476 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24472));
    V v_a_24477 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24473));
    V v_b_24478 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24474}));
    V v_t_24479 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24478));
    V v_t_24480 = (g_std_2edoc_2e_3c_3e(v_a_24477, v_t_24479));
    V v_t_24481 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24475));
    V v_t_24482 = (g_std_2edoc_2e_3c_3e(v_t_24480, v_t_24481));
    return (g_std_2edoc_2e_3c_3e(v_t_24476, v_t_24482));
  }
  case TAG_EArrow: {
    V v_arrow_24483 = heff_field(v_e0_241, 0);
    V v_e_24484 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24483));
    V v_b_24486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24484}));
    V v_t_24487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_b_24486));
    return (g_std_2edoc_2e_3c_3e(v_a_24485, v_t_24487));
  }
  case TAG_IfThen: {
    V v_kw_24488 = heff_field(v_e0_241, 0);
    V v_c_24489 = heff_field(v_e0_241, 1);
    V v_th_24490 = heff_field(v_e0_241, 2);
    V v_a_24491 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24488, v_c_24489, v_th_24490, v_a_24491}));
    return (g_std_2edoc_2egroup(v_t_24492));
  }
  case TAG_ETry: {
    V v_kw_24493 = heff_field(v_e0_241, 0);
    V v_ty_24494 = heff_field(v_e0_241, 1);
    V v_body_24495 = heff_field(v_e0_241, 2);
    V v_c_24496 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24497 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24493));
    V v_t_24500;
    switch (heff_tag_of(v_ty_24494)) {
    case TAG_Nothing: {
      v_t_24500 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24498 = heff_field(v_ty_24494, 0);
      V v_ru_24ty_24494_24Just = heff_take_reuse_n(v_ty_24494, 1ULL, 1);
      V v_t_24499 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_t_24498}));
      v_t_24500 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24494_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_t_24499));
      break;
    }
    default: heff_nomatch(v_ty_24494);
    }
    V v_d_24501 = ({ V a_0 = heff_dup(v_env_240); V a_1 = MK_INT(0LL); V a_2 = v_body_24495; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24495); r_; });
    V v_t_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_c_24496}));
    V v_t_24503 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24502));
    V v_t_24504 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24501}), v_t_24503));
    V v_t_24505 = (g_std_2edoc_2e_3c_3e(v_t_24500, v_t_24504));
    V v_d_24506 = (g_std_2edoc_2e_3c_3e(v_t_24497, v_t_24505));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24506})});
  }
  case TAG_ECatch: {
    V v_kw_24511 = heff_field(v_e0_241, 0);
    V v_b_24512 = heff_field(v_e0_241, 1);
    V v_arrow_24513 = heff_field(v_e0_241, 2);
    V v_body_24514 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24515 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24511));
    V v_a_24516 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 2, (V[]){heff_dup(v_env_240), v_b_24512}));
    V v_b_24517 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24513));
    V v_t_24518 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_b_24517));
    V v_t_24519 = (g_std_2edoc_2e_3c_3e(v_a_24516, v_t_24518));
    V v_t_24520 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_t_24519));
    V v_t_24521 = (g_std_2edoc_2e_3c_3e(v_a_24515, v_t_24520));
    V v_d_24522 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24514; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24514); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24521, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24522})));
  }
  case TAG_EWith: {
    V v_kw_24523 = heff_field(v_e0_241, 0);
    V v_e_24524 = heff_field(v_e0_241, 1);
    V v_a_24525 = heff_field(v_e0_241, 2);
    V v_x_24526 = heff_field(v_e0_241, 3);
    V v_d_24527 = heff_field(v_e0_241, 4);
    V v_body_24528 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24529 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24523));
    V v_d_24530 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24524}));
    V v_a_24531 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_a_24525));
    V v_a_24532 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24526; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24526); r_; });
    V v_b_24533 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24527));
    V v_t_24534 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_b_24533));
    V v_t_24535 = (g_std_2edoc_2e_3c_3e(v_a_24532, v_t_24534));
    V v_t_24536 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_t_24535));
    V v_t_24537 = (g_std_2edoc_2e_3c_3e(v_a_24531, v_t_24536));
    V v_t_24538 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24537));
    V v_t_24543 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_d_24530})}), v_t_24538));
    V v_t_24544 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_t_24543));
    V v_t_24545 = (g_std_2edoc_2e_3c_3e(v_a_24529, v_t_24544));
    V v_t_24546 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24528; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24528); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24545, v_t_24546));
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_env_24547 = args[0];
  V v_e_24548 = args[1];
  V v_t_24549 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24548));
  if ((heff_dup(v_t_24549) == NTAG(TAG_True))) {
    heff_drop(v_t_24549);
    V v_t_24550 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24547, v_e_24548}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), v_t_24550));
  } else {
    heff_drop(v_t_24549);
    V v_t_24551 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24547, v_e_24548}));
    V v_t_24552 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24551));
    return (g_std_2edoc_2egroup(v_t_24552));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_env_24553 = args[0];
  V v_kw_24554 = args[1];
  V v_p_24555 = args[2];
  V v_ann_24556 = args[3];
  V v_eq_24557 = args[4];
  V v_e_24558 = args[5];
  V v_a_24559 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24553), v_kw_24554));
  V v_b_24560 = ({ V a_0 = heff_dup(v_env_24553); V a_1 = v_p_24555; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24555); r_; });
  V v_t_24561 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), v_b_24560));
  V v_t_24562 = (g_std_2edoc_2e_3c_3e(v_a_24559, v_t_24561));
  V v_a_24570;
  switch (heff_tag_of(v_ann_24556)) {
  case TAG_Nothing: {
    v_a_24570 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24563 = heff_field(v_ann_24556, 0);
    V v_ru_24ann_24556_24Just = heff_take_reuse_n(v_ann_24556, 1ULL, 1);
    switch (heff_tag_of(v_it1_24563)) {
    case TAG_MkPair: {
      V v_cc_24564 = heff_field(v_it1_24563, 0);
      V v_ty_24565 = heff_field(v_it1_24563, 1);
      heff_take_n(v_it1_24563, 3ULL, 2);
      V v_a_24566 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24553), v_cc_24564));
      V v_b_24567 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24553), v_ty_24565}));
      V v_t_24568 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24556_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), v_b_24567));
      V v_t_24569 = (g_std_2edoc_2e_3c_3e(v_a_24566, v_t_24568));
      v_a_24570 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_t_24569));
      break;
    }
    default: heff_nomatch(v_it1_24563);
    }
    break;
  }
  default: heff_nomatch(v_ann_24556);
  }
  V v_b_24571 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24553), v_eq_24557));
  V v_t_24572 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24571));
  V v_t_24573 = (g_std_2edoc_2e_3c_3e(v_a_24570, v_t_24572));
  V v_t_24574 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24553, v_e_24558}));
  V v_t_24575 = (g_std_2edoc_2e_3c_3e(v_t_24573, v_t_24574));
  return (g_std_2edoc_2e_3c_3e(v_t_24562, v_t_24575));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_env_24576 = args[0];
  V v_kw_24577 = args[1];
  V v_p_24578 = args[2];
  V v_ann_24579 = args[3];
  V v_eq_24580 = args[4];
  V v_e_24581 = args[5];
  V v_i_24582 = args[6];
  V v_b_24583 = args[7];
  V v_d_24584 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24576), v_kw_24577, v_p_24578, v_ann_24579, v_eq_24580, v_e_24581}));
  V v_t_24585 = heff_dup(heff_rfield(v_i_24582, 6));
  V v_t_24588;
  if ((heff_dup(v_t_24585) == NTAG(TAG_True))) {
    heff_drop(v_t_24585);
    v_t_24588 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24585);
    V v_t_24586 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24583));
    V v_x1_24587 = heff_get_n(v_t_24586, 6, 9);
    if ((heff_dup(v_x1_24587) == NTAG(TAG_True))) {
      heff_drop(v_x1_24587);
      v_t_24588 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24587);
      v_t_24588 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24589 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24576), v_i_24582));
  V v_b_24749;
  switch (heff_tag_of(v_b_24583)) {
  case TAG_Atom: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EParen: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Named: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Tup: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Seg: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Braces: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Update: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EUSet: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_InstB: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EFSet: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Sum: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ECon: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EField: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ENeg: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ETilde: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_App: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Op: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Ops: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Ann: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_BVar: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_BImp: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_BAnn: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_BPat: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Lam: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Case: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EAlt: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_If: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_Do: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ESBind: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24687 = heff_dup(heff_field(v_b_24583, 0));
    V v_p2_24688 = heff_dup(heff_field(v_b_24583, 1));
    V v_ann2_24689 = heff_dup(heff_field(v_b_24583, 2));
    V v_eq2_24690 = heff_dup(heff_field(v_b_24583, 3));
    V v_e2_24691 = heff_dup(heff_field(v_b_24583, 4));
    V v_it6_24692 = heff_dup(heff_field(v_b_24583, 5));
    switch (heff_tag_of(v_it6_24692)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24687);
      heff_drop(v_p2_24688);
      heff_drop(v_ann2_24689);
      heff_drop(v_eq2_24690);
      heff_drop(v_e2_24691);
      v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
      break;
    }
    case TAG_Just: {
      V v_it61_24693 = heff_field(v_it6_24692, 0);
      heff_take_n(v_it6_24692, 1ULL, 1);
      heff_drop_tag(v_b_24583, 6);
      switch (heff_tag_of(v_it61_24693)) {
      case TAG_MkPair: {
        V v_i2_24694 = heff_field(v_it61_24693, 0);
        V v_b2_24695 = heff_field(v_it61_24693, 1);
        heff_take_n(v_it61_24693, 3ULL, 2);
        v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24576, v_kw2_24687, v_p2_24688, v_ann2_24689, v_eq2_24690, v_e2_24691, v_i2_24694, v_b2_24695}));
        break;
      }
      default: heff_nomatch(v_it61_24693);
      }
      break;
    }
    default: heff_nomatch(v_it6_24692);
    }
    break;
  }
  case TAG_ELetElse: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ELetMut: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EAssign: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EWhile: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EFor: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EJump: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EReturn: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ENest: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EArrow: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_IfThen: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ETry: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_ECatch: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  case TAG_EWith: {
    v_b_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24576, v_b_24583}));
    break;
  }
  default: heff_nomatch(v_b_24583);
  }
  V v_t_24750 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), v_b_24749));
  V v_t_24751 = (g_std_2edoc_2e_3c_3e(v_a_24589, v_t_24750));
  V v_t_24752 = (g_std_2edoc_2e_3c_3e(v_t_24588, v_t_24751));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24584}), v_t_24752));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_i_24761 = args[0];
  V v_k_24760 = heff_env(self)[0];
  V v_d_24759 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24762 = heff_intSub(v_k_24760, v_i_24761);
  if (heff_intEq_c_lent(v_i_24762, MK_INT(0LL), 2)) {
    heff_drop(v_i_24762);
    return v_d_24759;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24762, v_d_24759});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_k_24760 = args[0];
  V v_d_24759 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 2, (V[]){v_k_24760, v_d_24759})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_env_24753 = args[0];
  V v_kw_24754 = args[1];
  V v_c_24755 = args[2];
  V v_th_24756 = args[3];
  V v_a_24757 = args[4];
  V v_a_24758 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24753), v_kw_24754));
  V v_d_24759 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24753), v_c_24755}));
  V v_t_24764 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_d_24759})})));
  V v_t_24765 = (g_std_2edoc_2e_3c_3e(v_a_24758, v_t_24764));
  V v_t_24766 = heff_dup(heff_rfield(v_th_24756, 6));
  V v_t_24769;
  if ((heff_dup(v_t_24766) == NTAG(TAG_True))) {
    heff_drop(v_t_24766);
    v_t_24769 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24766);
    V v_t_24767 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24757));
    V v_x1_24768 = heff_get_n(v_t_24767, 6, 9);
    if ((heff_dup(v_x1_24768) == NTAG(TAG_True))) {
      heff_drop(v_x1_24768);
      v_t_24769 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24768);
      v_t_24769 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24770 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24753), v_th_24756));
  V v_d_24771 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24753, v_a_24757}));
  V v_t_24772 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24771})));
  V v_t_24773 = (g_std_2edoc_2e_3c_3e(v_a_24770, v_t_24772));
  V v_t_24774 = (g_std_2edoc_2e_3c_3e(v_t_24769, v_t_24773));
  V v_t_24775 = (g_std_2edoc_2e_3c_3e(v_t_24765, v_t_24774));
  return (g_std_2edoc_2egroup(v_t_24775));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_env_24776 = args[0];
  V v_el_24777 = args[1];
  V v_b_24778 = args[2];
  switch (heff_tag_of(v_b_24778)) {
  case TAG_Atom: {
    V v_t_24780 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24783;
    if ((heff_dup(v_t_24780) == NTAG(TAG_True))) {
      heff_drop(v_t_24780);
      v_t_24783 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24780);
      V v_t_24781 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24782 = heff_get_n(v_t_24781, 6, 9);
      if ((heff_dup(v_x1_24782) == NTAG(TAG_True))) {
        heff_drop(v_x1_24782);
        v_t_24783 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24782);
        v_t_24783 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24784 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24785 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24786 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24785})));
    V v_t_24787 = (g_std_2edoc_2e_3c_3e(v_a_24784, v_t_24786));
    return (g_std_2edoc_2e_3c_3e(v_t_24783, v_t_24787));
  }
  case TAG_EParen: {
    V v_t_24791 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24794;
    if ((heff_dup(v_t_24791) == NTAG(TAG_True))) {
      heff_drop(v_t_24791);
      v_t_24794 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24791);
      V v_t_24792 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24793 = heff_get_n(v_t_24792, 6, 9);
      if ((heff_dup(v_x1_24793) == NTAG(TAG_True))) {
        heff_drop(v_x1_24793);
        v_t_24794 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24793);
        v_t_24794 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24795 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24796 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24797 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24796})));
    V v_t_24798 = (g_std_2edoc_2e_3c_3e(v_a_24795, v_t_24797));
    return (g_std_2edoc_2e_3c_3e(v_t_24794, v_t_24798));
  }
  case TAG_Named: {
    V v_t_24804 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24807;
    if ((heff_dup(v_t_24804) == NTAG(TAG_True))) {
      heff_drop(v_t_24804);
      v_t_24807 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24804);
      V v_t_24805 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24806 = heff_get_n(v_t_24805, 6, 9);
      if ((heff_dup(v_x1_24806) == NTAG(TAG_True))) {
        heff_drop(v_x1_24806);
        v_t_24807 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24806);
        v_t_24807 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24808 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24809 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24810 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24809})));
    V v_t_24811 = (g_std_2edoc_2e_3c_3e(v_a_24808, v_t_24810));
    return (g_std_2edoc_2e_3c_3e(v_t_24807, v_t_24811));
  }
  case TAG_Tup: {
    V v_t_24816 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24819;
    if ((heff_dup(v_t_24816) == NTAG(TAG_True))) {
      heff_drop(v_t_24816);
      v_t_24819 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24816);
      V v_t_24817 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24818 = heff_get_n(v_t_24817, 6, 9);
      if ((heff_dup(v_x1_24818) == NTAG(TAG_True))) {
        heff_drop(v_x1_24818);
        v_t_24819 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24818);
        v_t_24819 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24820 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24821 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24822 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24821})));
    V v_t_24823 = (g_std_2edoc_2e_3c_3e(v_a_24820, v_t_24822));
    return (g_std_2edoc_2e_3c_3e(v_t_24819, v_t_24823));
  }
  case TAG_Seg: {
    V v_t_24827 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24830;
    if ((heff_dup(v_t_24827) == NTAG(TAG_True))) {
      heff_drop(v_t_24827);
      v_t_24830 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24827);
      V v_t_24828 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24829 = heff_get_n(v_t_24828, 6, 9);
      if ((heff_dup(v_x1_24829) == NTAG(TAG_True))) {
        heff_drop(v_x1_24829);
        v_t_24830 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24829);
        v_t_24830 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24831 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24832 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24833 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24832})));
    V v_t_24834 = (g_std_2edoc_2e_3c_3e(v_a_24831, v_t_24833));
    return (g_std_2edoc_2e_3c_3e(v_t_24830, v_t_24834));
  }
  case TAG_Braces: {
    V v_t_24839 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24842;
    if ((heff_dup(v_t_24839) == NTAG(TAG_True))) {
      heff_drop(v_t_24839);
      v_t_24842 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24839);
      V v_t_24840 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24841 = heff_get_n(v_t_24840, 6, 9);
      if ((heff_dup(v_x1_24841) == NTAG(TAG_True))) {
        heff_drop(v_x1_24841);
        v_t_24842 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24841);
        v_t_24842 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24843 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24844 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24845 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24844})));
    V v_t_24846 = (g_std_2edoc_2e_3c_3e(v_a_24843, v_t_24845));
    return (g_std_2edoc_2e_3c_3e(v_t_24842, v_t_24846));
  }
  case TAG_Update: {
    V v_t_24853 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24856;
    if ((heff_dup(v_t_24853) == NTAG(TAG_True))) {
      heff_drop(v_t_24853);
      v_t_24856 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24853);
      V v_t_24854 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24855 = heff_get_n(v_t_24854, 6, 9);
      if ((heff_dup(v_x1_24855) == NTAG(TAG_True))) {
        heff_drop(v_x1_24855);
        v_t_24856 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24855);
        v_t_24856 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24857 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24858 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24859 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24858})));
    V v_t_24860 = (g_std_2edoc_2e_3c_3e(v_a_24857, v_t_24859));
    return (g_std_2edoc_2e_3c_3e(v_t_24856, v_t_24860));
  }
  case TAG_EUSet: {
    V v_t_24864 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24867;
    if ((heff_dup(v_t_24864) == NTAG(TAG_True))) {
      heff_drop(v_t_24864);
      v_t_24867 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24864);
      V v_t_24865 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24866 = heff_get_n(v_t_24865, 6, 9);
      if ((heff_dup(v_x1_24866) == NTAG(TAG_True))) {
        heff_drop(v_x1_24866);
        v_t_24867 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24866);
        v_t_24867 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24868 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24869 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24870 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24869})));
    V v_t_24871 = (g_std_2edoc_2e_3c_3e(v_a_24868, v_t_24870));
    return (g_std_2edoc_2e_3c_3e(v_t_24867, v_t_24871));
  }
  case TAG_InstB: {
    V v_t_24877 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24880;
    if ((heff_dup(v_t_24877) == NTAG(TAG_True))) {
      heff_drop(v_t_24877);
      v_t_24880 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24877);
      V v_t_24878 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24879 = heff_get_n(v_t_24878, 6, 9);
      if ((heff_dup(v_x1_24879) == NTAG(TAG_True))) {
        heff_drop(v_x1_24879);
        v_t_24880 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24879);
        v_t_24880 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24881 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24882 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24883 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24882})));
    V v_t_24884 = (g_std_2edoc_2e_3c_3e(v_a_24881, v_t_24883));
    return (g_std_2edoc_2e_3c_3e(v_t_24880, v_t_24884));
  }
  case TAG_EFSet: {
    V v_t_24888 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24891;
    if ((heff_dup(v_t_24888) == NTAG(TAG_True))) {
      heff_drop(v_t_24888);
      v_t_24891 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24888);
      V v_t_24889 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24890 = heff_get_n(v_t_24889, 6, 9);
      if ((heff_dup(v_x1_24890) == NTAG(TAG_True))) {
        heff_drop(v_x1_24890);
        v_t_24891 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24890);
        v_t_24891 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24892 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24893 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24894 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24893})));
    V v_t_24895 = (g_std_2edoc_2e_3c_3e(v_a_24892, v_t_24894));
    return (g_std_2edoc_2e_3c_3e(v_t_24891, v_t_24895));
  }
  case TAG_EFDefault: {
    V v_t_24899 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24902;
    if ((heff_dup(v_t_24899) == NTAG(TAG_True))) {
      heff_drop(v_t_24899);
      v_t_24902 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24899);
      V v_t_24900 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24901 = heff_get_n(v_t_24900, 6, 9);
      if ((heff_dup(v_x1_24901) == NTAG(TAG_True))) {
        heff_drop(v_x1_24901);
        v_t_24902 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24901);
        v_t_24902 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24903 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24904 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24905 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24904})));
    V v_t_24906 = (g_std_2edoc_2e_3c_3e(v_a_24903, v_t_24905));
    return (g_std_2edoc_2e_3c_3e(v_t_24902, v_t_24906));
  }
  case TAG_Sum: {
    V v_t_24912 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24915;
    if ((heff_dup(v_t_24912) == NTAG(TAG_True))) {
      heff_drop(v_t_24912);
      v_t_24915 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24912);
      V v_t_24913 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24914 = heff_get_n(v_t_24913, 6, 9);
      if ((heff_dup(v_x1_24914) == NTAG(TAG_True))) {
        heff_drop(v_x1_24914);
        v_t_24915 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24914);
        v_t_24915 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24916 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24917 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24918 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24917})));
    V v_t_24919 = (g_std_2edoc_2e_3c_3e(v_a_24916, v_t_24918));
    return (g_std_2edoc_2e_3c_3e(v_t_24915, v_t_24919));
  }
  case TAG_ECon: {
    V v_t_24922 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24925;
    if ((heff_dup(v_t_24922) == NTAG(TAG_True))) {
      heff_drop(v_t_24922);
      v_t_24925 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24922);
      V v_t_24923 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24924 = heff_get_n(v_t_24923, 6, 9);
      if ((heff_dup(v_x1_24924) == NTAG(TAG_True))) {
        heff_drop(v_x1_24924);
        v_t_24925 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24924);
        v_t_24925 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24926 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24927 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24928 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24927})));
    V v_t_24929 = (g_std_2edoc_2e_3c_3e(v_a_24926, v_t_24928));
    return (g_std_2edoc_2e_3c_3e(v_t_24925, v_t_24929));
  }
  case TAG_EField: {
    V v_t_24932 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24935;
    if ((heff_dup(v_t_24932) == NTAG(TAG_True))) {
      heff_drop(v_t_24932);
      v_t_24935 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24932);
      V v_t_24933 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24934 = heff_get_n(v_t_24933, 6, 9);
      if ((heff_dup(v_x1_24934) == NTAG(TAG_True))) {
        heff_drop(v_x1_24934);
        v_t_24935 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24934);
        v_t_24935 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24936 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24937 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24938 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24937})));
    V v_t_24939 = (g_std_2edoc_2e_3c_3e(v_a_24936, v_t_24938));
    return (g_std_2edoc_2e_3c_3e(v_t_24935, v_t_24939));
  }
  case TAG_ENeg: {
    V v_t_24942 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24945;
    if ((heff_dup(v_t_24942) == NTAG(TAG_True))) {
      heff_drop(v_t_24942);
      v_t_24945 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24942);
      V v_t_24943 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24944 = heff_get_n(v_t_24943, 6, 9);
      if ((heff_dup(v_x1_24944) == NTAG(TAG_True))) {
        heff_drop(v_x1_24944);
        v_t_24945 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24944);
        v_t_24945 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24946 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24947 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24948 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24947})));
    V v_t_24949 = (g_std_2edoc_2e_3c_3e(v_a_24946, v_t_24948));
    return (g_std_2edoc_2e_3c_3e(v_t_24945, v_t_24949));
  }
  case TAG_ETilde: {
    V v_t_24952 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24955;
    if ((heff_dup(v_t_24952) == NTAG(TAG_True))) {
      heff_drop(v_t_24952);
      v_t_24955 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24952);
      V v_t_24953 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24954 = heff_get_n(v_t_24953, 6, 9);
      if ((heff_dup(v_x1_24954) == NTAG(TAG_True))) {
        heff_drop(v_x1_24954);
        v_t_24955 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24954);
        v_t_24955 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24956 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24957 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24958 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24957})));
    V v_t_24959 = (g_std_2edoc_2e_3c_3e(v_a_24956, v_t_24958));
    return (g_std_2edoc_2e_3c_3e(v_t_24955, v_t_24959));
  }
  case TAG_App: {
    V v_t_24962 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24965;
    if ((heff_dup(v_t_24962) == NTAG(TAG_True))) {
      heff_drop(v_t_24962);
      v_t_24965 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24962);
      V v_t_24963 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24964 = heff_get_n(v_t_24963, 6, 9);
      if ((heff_dup(v_x1_24964) == NTAG(TAG_True))) {
        heff_drop(v_x1_24964);
        v_t_24965 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24964);
        v_t_24965 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24966 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24967 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24968 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24967})));
    V v_t_24969 = (g_std_2edoc_2e_3c_3e(v_a_24966, v_t_24968));
    return (g_std_2edoc_2e_3c_3e(v_t_24965, v_t_24969));
  }
  case TAG_Op: {
    V v_t_24973 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24976;
    if ((heff_dup(v_t_24973) == NTAG(TAG_True))) {
      heff_drop(v_t_24973);
      v_t_24976 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24973);
      V v_t_24974 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24975 = heff_get_n(v_t_24974, 6, 9);
      if ((heff_dup(v_x1_24975) == NTAG(TAG_True))) {
        heff_drop(v_x1_24975);
        v_t_24976 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24975);
        v_t_24976 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24977 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24978 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24979 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24978})));
    V v_t_24980 = (g_std_2edoc_2e_3c_3e(v_a_24977, v_t_24979));
    return (g_std_2edoc_2e_3c_3e(v_t_24976, v_t_24980));
  }
  case TAG_Ops: {
    V v_t_24983 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24986;
    if ((heff_dup(v_t_24983) == NTAG(TAG_True))) {
      heff_drop(v_t_24983);
      v_t_24986 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24983);
      V v_t_24984 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24985 = heff_get_n(v_t_24984, 6, 9);
      if ((heff_dup(v_x1_24985) == NTAG(TAG_True))) {
        heff_drop(v_x1_24985);
        v_t_24986 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24985);
        v_t_24986 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24987 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24988 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24989 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24988})));
    V v_t_24990 = (g_std_2edoc_2e_3c_3e(v_a_24987, v_t_24989));
    return (g_std_2edoc_2e_3c_3e(v_t_24986, v_t_24990));
  }
  case TAG_OpRhs: {
    V v_t_24993 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_24996;
    if ((heff_dup(v_t_24993) == NTAG(TAG_True))) {
      heff_drop(v_t_24993);
      v_t_24996 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24993);
      V v_t_24994 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_24995 = heff_get_n(v_t_24994, 6, 9);
      if ((heff_dup(v_x1_24995) == NTAG(TAG_True))) {
        heff_drop(v_x1_24995);
        v_t_24996 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24995);
        v_t_24996 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24997 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_24998 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_24999 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24998})));
    V v_t_241000 = (g_std_2edoc_2e_3c_3e(v_a_24997, v_t_24999));
    return (g_std_2edoc_2e_3c_3e(v_t_24996, v_t_241000));
  }
  case TAG_Ann: {
    V v_t_241004 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241007;
    if ((heff_dup(v_t_241004) == NTAG(TAG_True))) {
      heff_drop(v_t_241004);
      v_t_241007 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241004);
      V v_t_241005 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241006 = heff_get_n(v_t_241005, 6, 9);
      if ((heff_dup(v_x1_241006) == NTAG(TAG_True))) {
        heff_drop(v_x1_241006);
        v_t_241007 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241006);
        v_t_241007 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241008 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241009 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241010 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241009})));
    V v_t_241011 = (g_std_2edoc_2e_3c_3e(v_a_241008, v_t_241010));
    return (g_std_2edoc_2e_3c_3e(v_t_241007, v_t_241011));
  }
  case TAG_BVar: {
    V v_t_241013 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241016;
    if ((heff_dup(v_t_241013) == NTAG(TAG_True))) {
      heff_drop(v_t_241013);
      v_t_241016 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241013);
      V v_t_241014 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241015 = heff_get_n(v_t_241014, 6, 9);
      if ((heff_dup(v_x1_241015) == NTAG(TAG_True))) {
        heff_drop(v_x1_241015);
        v_t_241016 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241015);
        v_t_241016 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241017 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241018 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241019 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241018})));
    V v_t_241020 = (g_std_2edoc_2e_3c_3e(v_a_241017, v_t_241019));
    return (g_std_2edoc_2e_3c_3e(v_t_241016, v_t_241020));
  }
  case TAG_BImp: {
    V v_t_241024 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241027;
    if ((heff_dup(v_t_241024) == NTAG(TAG_True))) {
      heff_drop(v_t_241024);
      v_t_241027 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241024);
      V v_t_241025 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241026 = heff_get_n(v_t_241025, 6, 9);
      if ((heff_dup(v_x1_241026) == NTAG(TAG_True))) {
        heff_drop(v_x1_241026);
        v_t_241027 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241026);
        v_t_241027 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241028 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241029 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241030 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241029})));
    V v_t_241031 = (g_std_2edoc_2e_3c_3e(v_a_241028, v_t_241030));
    return (g_std_2edoc_2e_3c_3e(v_t_241027, v_t_241031));
  }
  case TAG_BAnn: {
    V v_t_241037 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241040;
    if ((heff_dup(v_t_241037) == NTAG(TAG_True))) {
      heff_drop(v_t_241037);
      v_t_241040 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241037);
      V v_t_241038 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241039 = heff_get_n(v_t_241038, 6, 9);
      if ((heff_dup(v_x1_241039) == NTAG(TAG_True))) {
        heff_drop(v_x1_241039);
        v_t_241040 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241039);
        v_t_241040 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241041 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241042 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241043 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241042})));
    V v_t_241044 = (g_std_2edoc_2e_3c_3e(v_a_241041, v_t_241043));
    return (g_std_2edoc_2e_3c_3e(v_t_241040, v_t_241044));
  }
  case TAG_BPat: {
    V v_t_241046 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241049;
    if ((heff_dup(v_t_241046) == NTAG(TAG_True))) {
      heff_drop(v_t_241046);
      v_t_241049 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241046);
      V v_t_241047 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241048 = heff_get_n(v_t_241047, 6, 9);
      if ((heff_dup(v_x1_241048) == NTAG(TAG_True))) {
        heff_drop(v_x1_241048);
        v_t_241049 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241048);
        v_t_241049 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241050 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241051 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241052 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241051})));
    V v_t_241053 = (g_std_2edoc_2e_3c_3e(v_a_241050, v_t_241052));
    return (g_std_2edoc_2e_3c_3e(v_t_241049, v_t_241053));
  }
  case TAG_Lam: {
    V v_t_241058 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241061;
    if ((heff_dup(v_t_241058) == NTAG(TAG_True))) {
      heff_drop(v_t_241058);
      v_t_241061 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241058);
      V v_t_241059 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241060 = heff_get_n(v_t_241059, 6, 9);
      if ((heff_dup(v_x1_241060) == NTAG(TAG_True))) {
        heff_drop(v_x1_241060);
        v_t_241061 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241060);
        v_t_241061 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241062 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241063 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241064 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241063})));
    V v_t_241065 = (g_std_2edoc_2e_3c_3e(v_a_241062, v_t_241064));
    return (g_std_2edoc_2e_3c_3e(v_t_241061, v_t_241065));
  }
  case TAG_Case: {
    V v_t_241070 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241073;
    if ((heff_dup(v_t_241070) == NTAG(TAG_True))) {
      heff_drop(v_t_241070);
      v_t_241073 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241070);
      V v_t_241071 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241072 = heff_get_n(v_t_241071, 6, 9);
      if ((heff_dup(v_x1_241072) == NTAG(TAG_True))) {
        heff_drop(v_x1_241072);
        v_t_241073 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241072);
        v_t_241073 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241074 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241075 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241076 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241075})));
    V v_t_241077 = (g_std_2edoc_2e_3c_3e(v_a_241074, v_t_241076));
    return (g_std_2edoc_2e_3c_3e(v_t_241073, v_t_241077));
  }
  case TAG_EAlt: {
    V v_t_241081 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241084;
    if ((heff_dup(v_t_241081) == NTAG(TAG_True))) {
      heff_drop(v_t_241081);
      v_t_241084 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241081);
      V v_t_241082 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241083 = heff_get_n(v_t_241082, 6, 9);
      if ((heff_dup(v_x1_241083) == NTAG(TAG_True))) {
        heff_drop(v_x1_241083);
        v_t_241084 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241083);
        v_t_241084 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241085 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241086 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241087 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241086})));
    V v_t_241088 = (g_std_2edoc_2e_3c_3e(v_a_241085, v_t_241087));
    return (g_std_2edoc_2e_3c_3e(v_t_241084, v_t_241088));
  }
  case TAG_If: {
    V v_kw_241089 = heff_dup(heff_field(v_b_24778, 0));
    V v_c_241090 = heff_dup(heff_field(v_b_24778, 1));
    V v_th_241091 = heff_dup(heff_field(v_b_24778, 2));
    V v_a_241092 = heff_dup(heff_field(v_b_24778, 3));
    V v_el2_241093 = heff_dup(heff_field(v_b_24778, 4));
    V v_b2_241094 = heff_dup(heff_field(v_b_24778, 5));
    V v_t_241095 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241098;
    if ((heff_dup(v_t_241095) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24778, 6);
      heff_drop(v_t_241095);
      v_t_241098 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241095);
      V v_t_241096 = ({ V a_0 = v_b_24778; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24778, 6); r_; });
      V v_x1_241097 = heff_get_n(v_t_241096, 6, 9);
      if ((heff_dup(v_x1_241097) == NTAG(TAG_True))) {
        heff_drop(v_x1_241097);
        v_t_241098 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241097);
        v_t_241098 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241099 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_b_241100 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24776), v_kw_241089, v_c_241090, v_th_241091, v_a_241092}));
    V v_t_241101 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241100));
    V v_t_241102 = (g_std_2edoc_2e_3c_3e(v_a_241099, v_t_241101));
    V v_t_241103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24776, v_el2_241093, v_b2_241094}));
    V v_t_241104 = (g_std_2edoc_2e_3c_3e(v_t_241102, v_t_241103));
    return (g_std_2edoc_2e_3c_3e(v_t_241098, v_t_241104));
  }
  case TAG_Do: {
    V v_t_241107 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241110;
    if ((heff_dup(v_t_241107) == NTAG(TAG_True))) {
      heff_drop(v_t_241107);
      v_t_241110 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241107);
      V v_t_241108 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241109 = heff_get_n(v_t_241108, 6, 9);
      if ((heff_dup(v_x1_241109) == NTAG(TAG_True))) {
        heff_drop(v_x1_241109);
        v_t_241110 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241109);
        v_t_241110 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241111 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241112 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241113 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241112})));
    V v_t_241114 = (g_std_2edoc_2e_3c_3e(v_a_241111, v_t_241113));
    return (g_std_2edoc_2e_3c_3e(v_t_241110, v_t_241114));
  }
  case TAG_ESBind: {
    V v_t_241118 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241121;
    if ((heff_dup(v_t_241118) == NTAG(TAG_True))) {
      heff_drop(v_t_241118);
      v_t_241121 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241118);
      V v_t_241119 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241120 = heff_get_n(v_t_241119, 6, 9);
      if ((heff_dup(v_x1_241120) == NTAG(TAG_True))) {
        heff_drop(v_x1_241120);
        v_t_241121 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241120);
        v_t_241121 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241122 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241123 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241124 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241123})));
    V v_t_241125 = (g_std_2edoc_2e_3c_3e(v_a_241122, v_t_241124));
    return (g_std_2edoc_2e_3c_3e(v_t_241121, v_t_241125));
  }
  case TAG_ELet: {
    V v_t_241132 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241135;
    if ((heff_dup(v_t_241132) == NTAG(TAG_True))) {
      heff_drop(v_t_241132);
      v_t_241135 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241132);
      V v_t_241133 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241134 = heff_get_n(v_t_241133, 6, 9);
      if ((heff_dup(v_x1_241134) == NTAG(TAG_True))) {
        heff_drop(v_x1_241134);
        v_t_241135 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241134);
        v_t_241135 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241136 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241137 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241138 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241137})));
    V v_t_241139 = (g_std_2edoc_2e_3c_3e(v_a_241136, v_t_241138));
    return (g_std_2edoc_2e_3c_3e(v_t_241135, v_t_241139));
  }
  case TAG_ELetElse: {
    V v_t_241147 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241150;
    if ((heff_dup(v_t_241147) == NTAG(TAG_True))) {
      heff_drop(v_t_241147);
      v_t_241150 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241147);
      V v_t_241148 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241149 = heff_get_n(v_t_241148, 6, 9);
      if ((heff_dup(v_x1_241149) == NTAG(TAG_True))) {
        heff_drop(v_x1_241149);
        v_t_241150 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241149);
        v_t_241150 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241151 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241152 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241153 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241152})));
    V v_t_241154 = (g_std_2edoc_2e_3c_3e(v_a_241151, v_t_241153));
    return (g_std_2edoc_2e_3c_3e(v_t_241150, v_t_241154));
  }
  case TAG_ELetMut: {
    V v_t_241161 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241164;
    if ((heff_dup(v_t_241161) == NTAG(TAG_True))) {
      heff_drop(v_t_241161);
      v_t_241164 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241161);
      V v_t_241162 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241163 = heff_get_n(v_t_241162, 6, 9);
      if ((heff_dup(v_x1_241163) == NTAG(TAG_True))) {
        heff_drop(v_x1_241163);
        v_t_241164 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241163);
        v_t_241164 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241165 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241166 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241167 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241166})));
    V v_t_241168 = (g_std_2edoc_2e_3c_3e(v_a_241165, v_t_241167));
    return (g_std_2edoc_2e_3c_3e(v_t_241164, v_t_241168));
  }
  case TAG_EAssign: {
    V v_t_241172 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241175;
    if ((heff_dup(v_t_241172) == NTAG(TAG_True))) {
      heff_drop(v_t_241172);
      v_t_241175 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241172);
      V v_t_241173 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241174 = heff_get_n(v_t_241173, 6, 9);
      if ((heff_dup(v_x1_241174) == NTAG(TAG_True))) {
        heff_drop(v_x1_241174);
        v_t_241175 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241174);
        v_t_241175 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241176 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241177 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241178 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241177})));
    V v_t_241179 = (g_std_2edoc_2e_3c_3e(v_a_241176, v_t_241178));
    return (g_std_2edoc_2e_3c_3e(v_t_241175, v_t_241179));
  }
  case TAG_EWhile: {
    V v_t_241184 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241187;
    if ((heff_dup(v_t_241184) == NTAG(TAG_True))) {
      heff_drop(v_t_241184);
      v_t_241187 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241184);
      V v_t_241185 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241186 = heff_get_n(v_t_241185, 6, 9);
      if ((heff_dup(v_x1_241186) == NTAG(TAG_True))) {
        heff_drop(v_x1_241186);
        v_t_241187 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241186);
        v_t_241187 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241188 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241189 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241190 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241189})));
    V v_t_241191 = (g_std_2edoc_2e_3c_3e(v_a_241188, v_t_241190));
    return (g_std_2edoc_2e_3c_3e(v_t_241187, v_t_241191));
  }
  case TAG_EFor: {
    V v_t_241198 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241201;
    if ((heff_dup(v_t_241198) == NTAG(TAG_True))) {
      heff_drop(v_t_241198);
      v_t_241201 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241198);
      V v_t_241199 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241200 = heff_get_n(v_t_241199, 6, 9);
      if ((heff_dup(v_x1_241200) == NTAG(TAG_True))) {
        heff_drop(v_x1_241200);
        v_t_241201 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241200);
        v_t_241201 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241202 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241203 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241204 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241203})));
    V v_t_241205 = (g_std_2edoc_2e_3c_3e(v_a_241202, v_t_241204));
    return (g_std_2edoc_2e_3c_3e(v_t_241201, v_t_241205));
  }
  case TAG_EJump: {
    V v_t_241207 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241210;
    if ((heff_dup(v_t_241207) == NTAG(TAG_True))) {
      heff_drop(v_t_241207);
      v_t_241210 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241207);
      V v_t_241208 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241209 = heff_get_n(v_t_241208, 6, 9);
      if ((heff_dup(v_x1_241209) == NTAG(TAG_True))) {
        heff_drop(v_x1_241209);
        v_t_241210 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241209);
        v_t_241210 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241211 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241212 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241213 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241212})));
    V v_t_241214 = (g_std_2edoc_2e_3c_3e(v_a_241211, v_t_241213));
    return (g_std_2edoc_2e_3c_3e(v_t_241210, v_t_241214));
  }
  case TAG_EReturn: {
    V v_t_241217 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241220;
    if ((heff_dup(v_t_241217) == NTAG(TAG_True))) {
      heff_drop(v_t_241217);
      v_t_241220 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241217);
      V v_t_241218 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241219 = heff_get_n(v_t_241218, 6, 9);
      if ((heff_dup(v_x1_241219) == NTAG(TAG_True))) {
        heff_drop(v_x1_241219);
        v_t_241220 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241219);
        v_t_241220 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241221 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241223 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241222})));
    V v_t_241224 = (g_std_2edoc_2e_3c_3e(v_a_241221, v_t_241223));
    return (g_std_2edoc_2e_3c_3e(v_t_241220, v_t_241224));
  }
  case TAG_ENest: {
    V v_t_241229 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241232;
    if ((heff_dup(v_t_241229) == NTAG(TAG_True))) {
      heff_drop(v_t_241229);
      v_t_241232 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241229);
      V v_t_241230 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241231 = heff_get_n(v_t_241230, 6, 9);
      if ((heff_dup(v_x1_241231) == NTAG(TAG_True))) {
        heff_drop(v_x1_241231);
        v_t_241232 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241231);
        v_t_241232 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241233 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241234 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241235 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241234})));
    V v_t_241236 = (g_std_2edoc_2e_3c_3e(v_a_241233, v_t_241235));
    return (g_std_2edoc_2e_3c_3e(v_t_241232, v_t_241236));
  }
  case TAG_EArrow: {
    V v_t_241239 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241242;
    if ((heff_dup(v_t_241239) == NTAG(TAG_True))) {
      heff_drop(v_t_241239);
      v_t_241242 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241239);
      V v_t_241240 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241241 = heff_get_n(v_t_241240, 6, 9);
      if ((heff_dup(v_x1_241241) == NTAG(TAG_True))) {
        heff_drop(v_x1_241241);
        v_t_241242 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241241);
        v_t_241242 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241243 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241244 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241245 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241244})));
    V v_t_241246 = (g_std_2edoc_2e_3c_3e(v_a_241243, v_t_241245));
    return (g_std_2edoc_2e_3c_3e(v_t_241242, v_t_241246));
  }
  case TAG_IfThen: {
    V v_t_241251 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241254;
    if ((heff_dup(v_t_241251) == NTAG(TAG_True))) {
      heff_drop(v_t_241251);
      v_t_241254 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241251);
      V v_t_241252 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241253 = heff_get_n(v_t_241252, 6, 9);
      if ((heff_dup(v_x1_241253) == NTAG(TAG_True))) {
        heff_drop(v_x1_241253);
        v_t_241254 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241253);
        v_t_241254 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241255 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241256 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241257 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241256})));
    V v_t_241258 = (g_std_2edoc_2e_3c_3e(v_a_241255, v_t_241257));
    return (g_std_2edoc_2e_3c_3e(v_t_241254, v_t_241258));
  }
  case TAG_ETry: {
    V v_t_241263 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241266;
    if ((heff_dup(v_t_241263) == NTAG(TAG_True))) {
      heff_drop(v_t_241263);
      v_t_241266 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241263);
      V v_t_241264 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241265 = heff_get_n(v_t_241264, 6, 9);
      if ((heff_dup(v_x1_241265) == NTAG(TAG_True))) {
        heff_drop(v_x1_241265);
        v_t_241266 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241265);
        v_t_241266 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241267 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241268 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241269 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241268})));
    V v_t_241270 = (g_std_2edoc_2e_3c_3e(v_a_241267, v_t_241269));
    return (g_std_2edoc_2e_3c_3e(v_t_241266, v_t_241270));
  }
  case TAG_ECatch: {
    V v_t_241275 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241278;
    if ((heff_dup(v_t_241275) == NTAG(TAG_True))) {
      heff_drop(v_t_241275);
      v_t_241278 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241275);
      V v_t_241276 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241277 = heff_get_n(v_t_241276, 6, 9);
      if ((heff_dup(v_x1_241277) == NTAG(TAG_True))) {
        heff_drop(v_x1_241277);
        v_t_241278 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241277);
        v_t_241278 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241279 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241280 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241281 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241280})));
    V v_t_241282 = (g_std_2edoc_2e_3c_3e(v_a_241279, v_t_241281));
    return (g_std_2edoc_2e_3c_3e(v_t_241278, v_t_241282));
  }
  case TAG_EWith: {
    V v_t_241289 = heff_dup(heff_rfield(v_el_24777, 6));
    V v_t_241292;
    if ((heff_dup(v_t_241289) == NTAG(TAG_True))) {
      heff_drop(v_t_241289);
      v_t_241292 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241289);
      V v_t_241290 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24778));
      V v_x1_241291 = heff_get_n(v_t_241290, 6, 9);
      if ((heff_dup(v_x1_241291) == NTAG(TAG_True))) {
        heff_drop(v_x1_241291);
        v_t_241292 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241291);
        v_t_241292 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241293 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24776), v_el_24777));
    V v_d_241294 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24776, v_b_24778}));
    V v_t_241295 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241294})));
    V v_t_241296 = (g_std_2edoc_2e_3c_3e(v_a_241293, v_t_241295));
    return (g_std_2edoc_2e_3c_3e(v_t_241292, v_t_241296));
  }
  default: return heff_nomatch(v_b_24778);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241308 = args[0];
  V v_one_241307 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241309 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241308));
  V v_x1_241310 = heff_get_n(v_t_241309, 6, 9);
  V v_t_241311;
  if ((heff_dup(v_x1_241310) == NTAG(TAG_True))) {
    heff_drop(v_x1_241310);
    v_t_241311 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241310);
    v_t_241311 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241312 = heff_tr(heff_call(v_one_241307, 1, (V[]){v_a_241308}));
  return (g_std_2edoc_2e_3c_3e(v_t_241311, v_t_241312));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241320 = args[0];
  V v_one_241319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241321 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241320));
  V v_x1_241322 = heff_get_n(v_t_241321, 6, 9);
  V v_t_241323;
  if ((heff_dup(v_x1_241322) == NTAG(TAG_True))) {
    heff_drop(v_x1_241322);
    v_t_241323 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241322);
    v_t_241323 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241324 = heff_tr(heff_call(v_one_241319, 1, (V[]){v_a_241320}));
  return (g_std_2edoc_2e_3c_3e(v_t_241323, v_t_241324));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241333 = args[0];
  V v_one_241332 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241334 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241333));
  V v_x1_241335 = heff_get_n(v_t_241334, 6, 9);
  V v_t_241336;
  if ((heff_dup(v_x1_241335) == NTAG(TAG_True))) {
    heff_drop(v_x1_241335);
    v_t_241336 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241335);
    v_t_241336 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241337 = heff_tr(heff_call(v_one_241332, 1, (V[]){v_a_241333}));
  return (g_std_2edoc_2e_3c_3e(v_t_241336, v_t_241337));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241349 = args[0];
  V v_one_241348 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241350 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241349));
  V v_x1_241351 = heff_get_n(v_t_241350, 6, 9);
  V v_t_241352;
  if ((heff_dup(v_x1_241351) == NTAG(TAG_True))) {
    heff_drop(v_x1_241351);
    v_t_241352 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241351);
    v_t_241352 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241353 = heff_tr(heff_call(v_one_241348, 1, (V[]){v_a_241349}));
  return (g_std_2edoc_2e_3c_3e(v_t_241352, v_t_241353));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241364 = args[0];
  V v_one_241363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241365 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241364));
  V v_x1_241366 = heff_get_n(v_t_241365, 6, 9);
  V v_t_241367;
  if ((heff_dup(v_x1_241366) == NTAG(TAG_True))) {
    heff_drop(v_x1_241366);
    v_t_241367 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241366);
    v_t_241367 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241368 = heff_tr(heff_call(v_one_241363, 1, (V[]){v_a_241364}));
  return (g_std_2edoc_2e_3c_3e(v_t_241367, v_t_241368));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241376 = args[0];
  V v_one_241375 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241377 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241376));
  V v_x1_241378 = heff_get_n(v_t_241377, 6, 9);
  V v_t_241379;
  if ((heff_dup(v_x1_241378) == NTAG(TAG_True))) {
    heff_drop(v_x1_241378);
    v_t_241379 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241378);
    v_t_241379 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241380 = heff_tr(heff_call(v_one_241375, 1, (V[]){v_a_241376}));
  return (g_std_2edoc_2e_3c_3e(v_t_241379, v_t_241380));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241390 = args[0];
  V v_one_241389 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241391 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241390));
  V v_x1_241392 = heff_get_n(v_t_241391, 6, 9);
  V v_t_241393;
  if ((heff_dup(v_x1_241392) == NTAG(TAG_True))) {
    heff_drop(v_x1_241392);
    v_t_241393 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241392);
    v_t_241393 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241394 = heff_tr(heff_call(v_one_241389, 1, (V[]){v_a_241390}));
  return (g_std_2edoc_2e_3c_3e(v_t_241393, v_t_241394));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241402 = args[0];
  V v_one_241401 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241403 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241402));
  V v_x1_241404 = heff_get_n(v_t_241403, 6, 9);
  V v_t_241405;
  if ((heff_dup(v_x1_241404) == NTAG(TAG_True))) {
    heff_drop(v_x1_241404);
    v_t_241405 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241404);
    v_t_241405 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241406 = heff_tr(heff_call(v_one_241401, 1, (V[]){v_a_241402}));
  return (g_std_2edoc_2e_3c_3e(v_t_241405, v_t_241406));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241415 = args[0];
  V v_one_241414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241416 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241415));
  V v_x1_241417 = heff_get_n(v_t_241416, 6, 9);
  V v_t_241418;
  if ((heff_dup(v_x1_241417) == NTAG(TAG_True))) {
    heff_drop(v_x1_241417);
    v_t_241418 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241417);
    v_t_241418 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241419 = heff_tr(heff_call(v_one_241414, 1, (V[]){v_a_241415}));
  return (g_std_2edoc_2e_3c_3e(v_t_241418, v_t_241419));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241427 = args[0];
  V v_one_241426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241428 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241427));
  V v_x1_241429 = heff_get_n(v_t_241428, 6, 9);
  V v_t_241430;
  if ((heff_dup(v_x1_241429) == NTAG(TAG_True))) {
    heff_drop(v_x1_241429);
    v_t_241430 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241429);
    v_t_241430 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241431 = heff_tr(heff_call(v_one_241426, 1, (V[]){v_a_241427}));
  return (g_std_2edoc_2e_3c_3e(v_t_241430, v_t_241431));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241441 = args[0];
  V v_one_241440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241442 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241441));
  V v_x1_241443 = heff_get_n(v_t_241442, 6, 9);
  V v_t_241444;
  if ((heff_dup(v_x1_241443) == NTAG(TAG_True))) {
    heff_drop(v_x1_241443);
    v_t_241444 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241443);
    v_t_241444 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241445 = heff_tr(heff_call(v_one_241440, 1, (V[]){v_a_241441}));
  return (g_std_2edoc_2e_3c_3e(v_t_241444, v_t_241445));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241453 = args[0];
  V v_one_241452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241454 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241453));
  V v_x1_241455 = heff_get_n(v_t_241454, 6, 9);
  V v_t_241456;
  if ((heff_dup(v_x1_241455) == NTAG(TAG_True))) {
    heff_drop(v_x1_241455);
    v_t_241456 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241455);
    v_t_241456 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241457 = heff_tr(heff_call(v_one_241452, 1, (V[]){v_a_241453}));
  return (g_std_2edoc_2e_3c_3e(v_t_241456, v_t_241457));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241469 = args[0];
  V v_one_241468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241470 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241469));
  V v_x1_241471 = heff_get_n(v_t_241470, 6, 9);
  V v_t_241472;
  if ((heff_dup(v_x1_241471) == NTAG(TAG_True))) {
    heff_drop(v_x1_241471);
    v_t_241472 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241471);
    v_t_241472 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241473 = heff_tr(heff_call(v_one_241468, 1, (V[]){v_a_241469}));
  return (g_std_2edoc_2e_3c_3e(v_t_241472, v_t_241473));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241481 = args[0];
  V v_one_241480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241482 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241481));
  V v_x1_241483 = heff_get_n(v_t_241482, 6, 9);
  V v_t_241484;
  if ((heff_dup(v_x1_241483) == NTAG(TAG_True))) {
    heff_drop(v_x1_241483);
    v_t_241484 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241483);
    v_t_241484 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241485 = heff_tr(heff_call(v_one_241480, 1, (V[]){v_a_241481}));
  return (g_std_2edoc_2e_3c_3e(v_t_241484, v_t_241485));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241494 = args[0];
  V v_one_241493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241495 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241494));
  V v_x1_241496 = heff_get_n(v_t_241495, 6, 9);
  V v_t_241497;
  if ((heff_dup(v_x1_241496) == NTAG(TAG_True))) {
    heff_drop(v_x1_241496);
    v_t_241497 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241496);
    v_t_241497 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241498 = heff_tr(heff_call(v_one_241493, 1, (V[]){v_a_241494}));
  return (g_std_2edoc_2e_3c_3e(v_t_241497, v_t_241498));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241506 = args[0];
  V v_one_241505 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241507 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241506));
  V v_x1_241508 = heff_get_n(v_t_241507, 6, 9);
  V v_t_241509;
  if ((heff_dup(v_x1_241508) == NTAG(TAG_True))) {
    heff_drop(v_x1_241508);
    v_t_241509 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241508);
    v_t_241509 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241510 = heff_tr(heff_call(v_one_241505, 1, (V[]){v_a_241506}));
  return (g_std_2edoc_2e_3c_3e(v_t_241509, v_t_241510));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241521 = args[0];
  V v_one_241520 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241522 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241521));
  V v_x1_241523 = heff_get_n(v_t_241522, 6, 9);
  V v_t_241524;
  if ((heff_dup(v_x1_241523) == NTAG(TAG_True))) {
    heff_drop(v_x1_241523);
    v_t_241524 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241523);
    v_t_241524 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241525 = heff_tr(heff_call(v_one_241520, 1, (V[]){v_a_241521}));
  return (g_std_2edoc_2e_3c_3e(v_t_241524, v_t_241525));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241533 = args[0];
  V v_one_241532 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241534 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241533));
  V v_x1_241535 = heff_get_n(v_t_241534, 6, 9);
  V v_t_241536;
  if ((heff_dup(v_x1_241535) == NTAG(TAG_True))) {
    heff_drop(v_x1_241535);
    v_t_241536 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241535);
    v_t_241536 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241537 = heff_tr(heff_call(v_one_241532, 1, (V[]){v_a_241533}));
  return (g_std_2edoc_2e_3c_3e(v_t_241536, v_t_241537));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241546 = args[0];
  V v_one_241545 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241547 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241546));
  V v_x1_241548 = heff_get_n(v_t_241547, 6, 9);
  V v_t_241549;
  if ((heff_dup(v_x1_241548) == NTAG(TAG_True))) {
    heff_drop(v_x1_241548);
    v_t_241549 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241548);
    v_t_241549 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241550 = heff_tr(heff_call(v_one_241545, 1, (V[]){v_a_241546}));
  return (g_std_2edoc_2e_3c_3e(v_t_241549, v_t_241550));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241558 = args[0];
  V v_one_241557 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241559 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241558));
  V v_x1_241560 = heff_get_n(v_t_241559, 6, 9);
  V v_t_241561;
  if ((heff_dup(v_x1_241560) == NTAG(TAG_True))) {
    heff_drop(v_x1_241560);
    v_t_241561 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241560);
    v_t_241561 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241562 = heff_tr(heff_call(v_one_241557, 1, (V[]){v_a_241558}));
  return (g_std_2edoc_2e_3c_3e(v_t_241561, v_t_241562));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241571 = args[0];
  V v_one_241570 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241572 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241571));
  V v_x1_241573 = heff_get_n(v_t_241572, 6, 9);
  V v_t_241574;
  if ((heff_dup(v_x1_241573) == NTAG(TAG_True))) {
    heff_drop(v_x1_241573);
    v_t_241574 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241573);
    v_t_241574 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241575 = heff_tr(heff_call(v_one_241570, 1, (V[]){v_a_241571}));
  return (g_std_2edoc_2e_3c_3e(v_t_241574, v_t_241575));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241583 = args[0];
  V v_one_241582 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241584 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241583));
  V v_x1_241585 = heff_get_n(v_t_241584, 6, 9);
  V v_t_241586;
  if ((heff_dup(v_x1_241585) == NTAG(TAG_True))) {
    heff_drop(v_x1_241585);
    v_t_241586 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241585);
    v_t_241586 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241587 = heff_tr(heff_call(v_one_241582, 1, (V[]){v_a_241583}));
  return (g_std_2edoc_2e_3c_3e(v_t_241586, v_t_241587));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241598 = args[0];
  V v_one_241597 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241599 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241598));
  V v_x1_241600 = heff_get_n(v_t_241599, 6, 9);
  V v_t_241601;
  if ((heff_dup(v_x1_241600) == NTAG(TAG_True))) {
    heff_drop(v_x1_241600);
    v_t_241601 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241600);
    v_t_241601 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241602 = heff_tr(heff_call(v_one_241597, 1, (V[]){v_a_241598}));
  return (g_std_2edoc_2e_3c_3e(v_t_241601, v_t_241602));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241610 = args[0];
  V v_one_241609 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241611 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241610));
  V v_x1_241612 = heff_get_n(v_t_241611, 6, 9);
  V v_t_241613;
  if ((heff_dup(v_x1_241612) == NTAG(TAG_True))) {
    heff_drop(v_x1_241612);
    v_t_241613 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241612);
    v_t_241613 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241614 = heff_tr(heff_call(v_one_241609, 1, (V[]){v_a_241610}));
  return (g_std_2edoc_2e_3c_3e(v_t_241613, v_t_241614));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241622 = args[0];
  V v_one_241621 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241623 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241622));
  V v_x1_241624 = heff_get_n(v_t_241623, 6, 9);
  V v_t_241625;
  if ((heff_dup(v_x1_241624) == NTAG(TAG_True))) {
    heff_drop(v_x1_241624);
    v_t_241625 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241624);
    v_t_241625 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241626 = heff_tr(heff_call(v_one_241621, 1, (V[]){v_a_241622}));
  return (g_std_2edoc_2e_3c_3e(v_t_241625, v_t_241626));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241634 = args[0];
  V v_one_241633 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241635 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241634));
  V v_x1_241636 = heff_get_n(v_t_241635, 6, 9);
  V v_t_241637;
  if ((heff_dup(v_x1_241636) == NTAG(TAG_True))) {
    heff_drop(v_x1_241636);
    v_t_241637 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241636);
    v_t_241637 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241638 = heff_tr(heff_call(v_one_241633, 1, (V[]){v_a_241634}));
  return (g_std_2edoc_2e_3c_3e(v_t_241637, v_t_241638));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241646 = args[0];
  V v_one_241645 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241647 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241646));
  V v_x1_241648 = heff_get_n(v_t_241647, 6, 9);
  V v_t_241649;
  if ((heff_dup(v_x1_241648) == NTAG(TAG_True))) {
    heff_drop(v_x1_241648);
    v_t_241649 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241648);
    v_t_241649 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241650 = heff_tr(heff_call(v_one_241645, 1, (V[]){v_a_241646}));
  return (g_std_2edoc_2e_3c_3e(v_t_241649, v_t_241650));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241658 = args[0];
  V v_one_241657 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241659 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241658));
  V v_x1_241660 = heff_get_n(v_t_241659, 6, 9);
  V v_t_241661;
  if ((heff_dup(v_x1_241660) == NTAG(TAG_True))) {
    heff_drop(v_x1_241660);
    v_t_241661 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241660);
    v_t_241661 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241662 = heff_tr(heff_call(v_one_241657, 1, (V[]){v_a_241658}));
  return (g_std_2edoc_2e_3c_3e(v_t_241661, v_t_241662));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241670 = args[0];
  V v_one_241669 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241671 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241670));
  V v_x1_241672 = heff_get_n(v_t_241671, 6, 9);
  V v_t_241673;
  if ((heff_dup(v_x1_241672) == NTAG(TAG_True))) {
    heff_drop(v_x1_241672);
    v_t_241673 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241672);
    v_t_241673 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241674 = heff_tr(heff_call(v_one_241669, 1, (V[]){v_a_241670}));
  return (g_std_2edoc_2e_3c_3e(v_t_241673, v_t_241674));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241682 = args[0];
  V v_one_241681 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241683 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241682));
  V v_x1_241684 = heff_get_n(v_t_241683, 6, 9);
  V v_t_241685;
  if ((heff_dup(v_x1_241684) == NTAG(TAG_True))) {
    heff_drop(v_x1_241684);
    v_t_241685 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241684);
    v_t_241685 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241686 = heff_tr(heff_call(v_one_241681, 1, (V[]){v_a_241682}));
  return (g_std_2edoc_2e_3c_3e(v_t_241685, v_t_241686));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241694 = args[0];
  V v_one_241693 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241695 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241694));
  V v_x1_241696 = heff_get_n(v_t_241695, 6, 9);
  V v_t_241697;
  if ((heff_dup(v_x1_241696) == NTAG(TAG_True))) {
    heff_drop(v_x1_241696);
    v_t_241697 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241696);
    v_t_241697 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241698 = heff_tr(heff_call(v_one_241693, 1, (V[]){v_a_241694}));
  return (g_std_2edoc_2e_3c_3e(v_t_241697, v_t_241698));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241706 = args[0];
  V v_one_241705 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241707 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241706));
  V v_x1_241708 = heff_get_n(v_t_241707, 6, 9);
  V v_t_241709;
  if ((heff_dup(v_x1_241708) == NTAG(TAG_True))) {
    heff_drop(v_x1_241708);
    v_t_241709 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241708);
    v_t_241709 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241710 = heff_tr(heff_call(v_one_241705, 1, (V[]){v_a_241706}));
  return (g_std_2edoc_2e_3c_3e(v_t_241709, v_t_241710));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241718 = args[0];
  V v_one_241717 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241719 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241718));
  V v_x1_241720 = heff_get_n(v_t_241719, 6, 9);
  V v_t_241721;
  if ((heff_dup(v_x1_241720) == NTAG(TAG_True))) {
    heff_drop(v_x1_241720);
    v_t_241721 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241720);
    v_t_241721 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241722 = heff_tr(heff_call(v_one_241717, 1, (V[]){v_a_241718}));
  return (g_std_2edoc_2e_3c_3e(v_t_241721, v_t_241722));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241730 = args[0];
  V v_one_241729 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241731 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241730));
  V v_x1_241732 = heff_get_n(v_t_241731, 6, 9);
  V v_t_241733;
  if ((heff_dup(v_x1_241732) == NTAG(TAG_True))) {
    heff_drop(v_x1_241732);
    v_t_241733 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241732);
    v_t_241733 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241734 = heff_tr(heff_call(v_one_241729, 1, (V[]){v_a_241730}));
  return (g_std_2edoc_2e_3c_3e(v_t_241733, v_t_241734));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241743 = args[0];
  V v_one_241742 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241744 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241743));
  V v_x1_241745 = heff_get_n(v_t_241744, 6, 9);
  V v_t_241746;
  if ((heff_dup(v_x1_241745) == NTAG(TAG_True))) {
    heff_drop(v_x1_241745);
    v_t_241746 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241745);
    v_t_241746 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241747 = heff_tr(heff_call(v_one_241742, 1, (V[]){v_a_241743}));
  return (g_std_2edoc_2e_3c_3e(v_t_241746, v_t_241747));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241755 = args[0];
  V v_one_241754 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241756 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241755));
  V v_x1_241757 = heff_get_n(v_t_241756, 6, 9);
  V v_t_241758;
  if ((heff_dup(v_x1_241757) == NTAG(TAG_True))) {
    heff_drop(v_x1_241757);
    v_t_241758 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241757);
    v_t_241758 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241759 = heff_tr(heff_call(v_one_241754, 1, (V[]){v_a_241755}));
  return (g_std_2edoc_2e_3c_3e(v_t_241758, v_t_241759));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241767 = args[0];
  V v_one_241766 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241768 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241767));
  V v_x1_241769 = heff_get_n(v_t_241768, 6, 9);
  V v_t_241770;
  if ((heff_dup(v_x1_241769) == NTAG(TAG_True))) {
    heff_drop(v_x1_241769);
    v_t_241770 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241769);
    v_t_241770 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241771 = heff_tr(heff_call(v_one_241766, 1, (V[]){v_a_241767}));
  return (g_std_2edoc_2e_3c_3e(v_t_241770, v_t_241771));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241779 = args[0];
  V v_one_241778 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241780 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241779));
  V v_x1_241781 = heff_get_n(v_t_241780, 6, 9);
  V v_t_241782;
  if ((heff_dup(v_x1_241781) == NTAG(TAG_True))) {
    heff_drop(v_x1_241781);
    v_t_241782 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241781);
    v_t_241782 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241783 = heff_tr(heff_call(v_one_241778, 1, (V[]){v_a_241779}));
  return (g_std_2edoc_2e_3c_3e(v_t_241782, v_t_241783));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241791 = args[0];
  V v_one_241790 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241792 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241791));
  V v_x1_241793 = heff_get_n(v_t_241792, 6, 9);
  V v_t_241794;
  if ((heff_dup(v_x1_241793) == NTAG(TAG_True))) {
    heff_drop(v_x1_241793);
    v_t_241794 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241793);
    v_t_241794 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241795 = heff_tr(heff_call(v_one_241790, 1, (V[]){v_a_241791}));
  return (g_std_2edoc_2e_3c_3e(v_t_241794, v_t_241795));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241803 = args[0];
  V v_one_241802 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241804 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241803));
  V v_x1_241805 = heff_get_n(v_t_241804, 6, 9);
  V v_t_241806;
  if ((heff_dup(v_x1_241805) == NTAG(TAG_True))) {
    heff_drop(v_x1_241805);
    v_t_241806 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241805);
    v_t_241806 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241807 = heff_tr(heff_call(v_one_241802, 1, (V[]){v_a_241803}));
  return (g_std_2edoc_2e_3c_3e(v_t_241806, v_t_241807));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241816 = args[0];
  V v_one_241815 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241817 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241816));
  V v_x1_241818 = heff_get_n(v_t_241817, 6, 9);
  V v_t_241819;
  if ((heff_dup(v_x1_241818) == NTAG(TAG_True))) {
    heff_drop(v_x1_241818);
    v_t_241819 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241818);
    v_t_241819 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241820 = heff_tr(heff_call(v_one_241815, 1, (V[]){v_a_241816}));
  return (g_std_2edoc_2e_3c_3e(v_t_241819, v_t_241820));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241828 = args[0];
  V v_one_241827 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241829 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241828));
  V v_x1_241830 = heff_get_n(v_t_241829, 6, 9);
  V v_t_241831;
  if ((heff_dup(v_x1_241830) == NTAG(TAG_True))) {
    heff_drop(v_x1_241830);
    v_t_241831 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241830);
    v_t_241831 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241832 = heff_tr(heff_call(v_one_241827, 1, (V[]){v_a_241828}));
  return (g_std_2edoc_2e_3c_3e(v_t_241831, v_t_241832));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241839 = args[0];
  V v_one_241838 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241840 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241839));
  V v_x1_241841 = heff_get_n(v_t_241840, 6, 9);
  V v_t_241842;
  if ((heff_dup(v_x1_241841) == NTAG(TAG_True))) {
    heff_drop(v_x1_241841);
    v_t_241842 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241841);
    v_t_241842 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241843 = heff_tr(heff_call(v_one_241838, 1, (V[]){v_a_241839}));
  return (g_std_2edoc_2e_3c_3e(v_t_241842, v_t_241843));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241851 = args[0];
  V v_one_241850 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241852 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241851));
  V v_x1_241853 = heff_get_n(v_t_241852, 6, 9);
  V v_t_241854;
  if ((heff_dup(v_x1_241853) == NTAG(TAG_True))) {
    heff_drop(v_x1_241853);
    v_t_241854 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241853);
    v_t_241854 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241855 = heff_tr(heff_call(v_one_241850, 1, (V[]){v_a_241851}));
  return (g_std_2edoc_2e_3c_3e(v_t_241854, v_t_241855));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241864 = args[0];
  V v_one_241863 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241865 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241864));
  V v_x1_241866 = heff_get_n(v_t_241865, 6, 9);
  V v_t_241867;
  if ((heff_dup(v_x1_241866) == NTAG(TAG_True))) {
    heff_drop(v_x1_241866);
    v_t_241867 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241866);
    v_t_241867 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241868 = heff_tr(heff_call(v_one_241863, 1, (V[]){v_a_241864}));
  return (g_std_2edoc_2e_3c_3e(v_t_241867, v_t_241868));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241876 = args[0];
  V v_one_241875 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241877 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241876));
  V v_x1_241878 = heff_get_n(v_t_241877, 6, 9);
  V v_t_241879;
  if ((heff_dup(v_x1_241878) == NTAG(TAG_True))) {
    heff_drop(v_x1_241878);
    v_t_241879 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241878);
    v_t_241879 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241880 = heff_tr(heff_call(v_one_241875, 1, (V[]){v_a_241876}));
  return (g_std_2edoc_2e_3c_3e(v_t_241879, v_t_241880));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241891 = args[0];
  V v_one_241890 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241892 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241891));
  V v_x1_241893 = heff_get_n(v_t_241892, 6, 9);
  V v_t_241894;
  if ((heff_dup(v_x1_241893) == NTAG(TAG_True))) {
    heff_drop(v_x1_241893);
    v_t_241894 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241893);
    v_t_241894 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241895 = heff_tr(heff_call(v_one_241890, 1, (V[]){v_a_241891}));
  return (g_std_2edoc_2e_3c_3e(v_t_241894, v_t_241895));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241903 = args[0];
  V v_one_241902 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241904 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241903));
  V v_x1_241905 = heff_get_n(v_t_241904, 6, 9);
  V v_t_241906;
  if ((heff_dup(v_x1_241905) == NTAG(TAG_True))) {
    heff_drop(v_x1_241905);
    v_t_241906 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241905);
    v_t_241906 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241907 = heff_tr(heff_call(v_one_241902, 1, (V[]){v_a_241903}));
  return (g_std_2edoc_2e_3c_3e(v_t_241906, v_t_241907));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241914 = args[0];
  V v_one_241913 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241915 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241914));
  V v_x1_241916 = heff_get_n(v_t_241915, 6, 9);
  V v_t_241917;
  if ((heff_dup(v_x1_241916) == NTAG(TAG_True))) {
    heff_drop(v_x1_241916);
    v_t_241917 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241916);
    v_t_241917 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241918 = heff_tr(heff_call(v_one_241913, 1, (V[]){v_a_241914}));
  return (g_std_2edoc_2e_3c_3e(v_t_241917, v_t_241918));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241926 = args[0];
  V v_one_241925 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241927 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241926));
  V v_x1_241928 = heff_get_n(v_t_241927, 6, 9);
  V v_t_241929;
  if ((heff_dup(v_x1_241928) == NTAG(TAG_True))) {
    heff_drop(v_x1_241928);
    v_t_241929 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241928);
    v_t_241929 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241930 = heff_tr(heff_call(v_one_241925, 1, (V[]){v_a_241926}));
  return (g_std_2edoc_2e_3c_3e(v_t_241929, v_t_241930));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_a_241940 = args[0];
  V v_one_241939 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241941 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241940));
  V v_x1_241942 = heff_get_n(v_t_241941, 6, 9);
  V v_t_241943;
  if ((heff_dup(v_x1_241942) == NTAG(TAG_True))) {
    heff_drop(v_x1_241942);
    v_t_241943 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241942);
    v_t_241943 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241944 = heff_tr(heff_call(v_one_241939, 1, (V[]){v_a_241940}));
  return (g_std_2edoc_2e_3c_3e(v_t_241943, v_t_241944));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_a_241952 = args[0];
  V v_one_241951 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241953 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241952));
  V v_x1_241954 = heff_get_n(v_t_241953, 6, 9);
  V v_t_241955;
  if ((heff_dup(v_x1_241954) == NTAG(TAG_True))) {
    heff_drop(v_x1_241954);
    v_t_241955 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241954);
    v_t_241955 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241956 = heff_tr(heff_call(v_one_241951, 1, (V[]){v_a_241952}));
  return (g_std_2edoc_2e_3c_3e(v_t_241955, v_t_241956));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_a_241966 = args[0];
  V v_one_241965 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241967 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241966));
  V v_x1_241968 = heff_get_n(v_t_241967, 6, 9);
  V v_t_241969;
  if ((heff_dup(v_x1_241968) == NTAG(TAG_True))) {
    heff_drop(v_x1_241968);
    v_t_241969 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241968);
    v_t_241969 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241970 = heff_tr(heff_call(v_one_241965, 1, (V[]){v_a_241966}));
  return (g_std_2edoc_2e_3c_3e(v_t_241969, v_t_241970));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_a_241978 = args[0];
  V v_one_241977 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241979 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241978));
  V v_x1_241980 = heff_get_n(v_t_241979, 6, 9);
  V v_t_241981;
  if ((heff_dup(v_x1_241980) == NTAG(TAG_True))) {
    heff_drop(v_x1_241980);
    v_t_241981 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241980);
    v_t_241981 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241982 = heff_tr(heff_call(v_one_241977, 1, (V[]){v_a_241978}));
  return (g_std_2edoc_2e_3c_3e(v_t_241981, v_t_241982));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_a_241991 = args[0];
  V v_one_241990 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241992 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241991));
  V v_x1_241993 = heff_get_n(v_t_241992, 6, 9);
  V v_t_241994;
  if ((heff_dup(v_x1_241993) == NTAG(TAG_True))) {
    heff_drop(v_x1_241993);
    v_t_241994 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241993);
    v_t_241994 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241995 = heff_tr(heff_call(v_one_241990, 1, (V[]){v_a_241991}));
  return (g_std_2edoc_2e_3c_3e(v_t_241994, v_t_241995));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_a_242003 = args[0];
  V v_one_242002 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242004 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242003));
  V v_x1_242005 = heff_get_n(v_t_242004, 6, 9);
  V v_t_242006;
  if ((heff_dup(v_x1_242005) == NTAG(TAG_True))) {
    heff_drop(v_x1_242005);
    v_t_242006 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242005);
    v_t_242006 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242007 = heff_tr(heff_call(v_one_242002, 1, (V[]){v_a_242003}));
  return (g_std_2edoc_2e_3c_3e(v_t_242006, v_t_242007));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_a_242019 = args[0];
  V v_one_242018 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242020 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242019));
  V v_x1_242021 = heff_get_n(v_t_242020, 6, 9);
  V v_t_242022;
  if ((heff_dup(v_x1_242021) == NTAG(TAG_True))) {
    heff_drop(v_x1_242021);
    v_t_242022 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242021);
    v_t_242022 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242023 = heff_tr(heff_call(v_one_242018, 1, (V[]){v_a_242019}));
  return (g_std_2edoc_2e_3c_3e(v_t_242022, v_t_242023));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_a_242031 = args[0];
  V v_one_242030 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242032 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242031));
  V v_x1_242033 = heff_get_n(v_t_242032, 6, 9);
  V v_t_242034;
  if ((heff_dup(v_x1_242033) == NTAG(TAG_True))) {
    heff_drop(v_x1_242033);
    v_t_242034 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242033);
    v_t_242034 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242035 = heff_tr(heff_call(v_one_242030, 1, (V[]){v_a_242031}));
  return (g_std_2edoc_2e_3c_3e(v_t_242034, v_t_242035));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_a_242043 = args[0];
  V v_one_242042 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242044 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242043));
  V v_x1_242045 = heff_get_n(v_t_242044, 6, 9);
  V v_t_242046;
  if ((heff_dup(v_x1_242045) == NTAG(TAG_True))) {
    heff_drop(v_x1_242045);
    v_t_242046 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242045);
    v_t_242046 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242047 = heff_tr(heff_call(v_one_242042, 1, (V[]){v_a_242043}));
  return (g_std_2edoc_2e_3c_3e(v_t_242046, v_t_242047));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_a_242055 = args[0];
  V v_one_242054 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242056 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242055));
  V v_x1_242057 = heff_get_n(v_t_242056, 6, 9);
  V v_t_242058;
  if ((heff_dup(v_x1_242057) == NTAG(TAG_True))) {
    heff_drop(v_x1_242057);
    v_t_242058 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242057);
    v_t_242058 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242059 = heff_tr(heff_call(v_one_242054, 1, (V[]){v_a_242055}));
  return (g_std_2edoc_2e_3c_3e(v_t_242058, v_t_242059));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_a_242068 = args[0];
  V v_one_242067 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242069 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242068));
  V v_x1_242070 = heff_get_n(v_t_242069, 6, 9);
  V v_t_242071;
  if ((heff_dup(v_x1_242070) == NTAG(TAG_True))) {
    heff_drop(v_x1_242070);
    v_t_242071 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242070);
    v_t_242071 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242072 = heff_tr(heff_call(v_one_242067, 1, (V[]){v_a_242068}));
  return (g_std_2edoc_2e_3c_3e(v_t_242071, v_t_242072));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args) {
  V v_a_242080 = args[0];
  V v_one_242079 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242081 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242080));
  V v_x1_242082 = heff_get_n(v_t_242081, 6, 9);
  V v_t_242083;
  if ((heff_dup(v_x1_242082) == NTAG(TAG_True))) {
    heff_drop(v_x1_242082);
    v_t_242083 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242082);
    v_t_242083 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242084 = heff_tr(heff_call(v_one_242079, 1, (V[]){v_a_242080}));
  return (g_std_2edoc_2e_3c_3e(v_t_242083, v_t_242084));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args) {
  V v_a_242096 = args[0];
  V v_one_242095 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242097 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242096));
  V v_x1_242098 = heff_get_n(v_t_242097, 6, 9);
  V v_t_242099;
  if ((heff_dup(v_x1_242098) == NTAG(TAG_True))) {
    heff_drop(v_x1_242098);
    v_t_242099 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242098);
    v_t_242099 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242100 = heff_tr(heff_call(v_one_242095, 1, (V[]){v_a_242096}));
  return (g_std_2edoc_2e_3c_3e(v_t_242099, v_t_242100));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args) {
  V v_a_242108 = args[0];
  V v_one_242107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242109 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242108));
  V v_x1_242110 = heff_get_n(v_t_242109, 6, 9);
  V v_t_242111;
  if ((heff_dup(v_x1_242110) == NTAG(TAG_True))) {
    heff_drop(v_x1_242110);
    v_t_242111 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242110);
    v_t_242111 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242112 = heff_tr(heff_call(v_one_242107, 1, (V[]){v_a_242108}));
  return (g_std_2edoc_2e_3c_3e(v_t_242111, v_t_242112));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args) {
  V v_a_242125 = args[0];
  V v_one_242124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242126 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242125));
  V v_x1_242127 = heff_get_n(v_t_242126, 6, 9);
  V v_t_242128;
  if ((heff_dup(v_x1_242127) == NTAG(TAG_True))) {
    heff_drop(v_x1_242127);
    v_t_242128 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242127);
    v_t_242128 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242129 = heff_tr(heff_call(v_one_242124, 1, (V[]){v_a_242125}));
  return (g_std_2edoc_2e_3c_3e(v_t_242128, v_t_242129));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args) {
  V v_a_242137 = args[0];
  V v_one_242136 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242138 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242137));
  V v_x1_242139 = heff_get_n(v_t_242138, 6, 9);
  V v_t_242140;
  if ((heff_dup(v_x1_242139) == NTAG(TAG_True))) {
    heff_drop(v_x1_242139);
    v_t_242140 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242139);
    v_t_242140 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242141 = heff_tr(heff_call(v_one_242136, 1, (V[]){v_a_242137}));
  return (g_std_2edoc_2e_3c_3e(v_t_242140, v_t_242141));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args) {
  V v_a_242153 = args[0];
  V v_one_242152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242154 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242153));
  V v_x1_242155 = heff_get_n(v_t_242154, 6, 9);
  V v_t_242156;
  if ((heff_dup(v_x1_242155) == NTAG(TAG_True))) {
    heff_drop(v_x1_242155);
    v_t_242156 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242155);
    v_t_242156 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242157 = heff_tr(heff_call(v_one_242152, 1, (V[]){v_a_242153}));
  return (g_std_2edoc_2e_3c_3e(v_t_242156, v_t_242157));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args) {
  V v_a_242165 = args[0];
  V v_one_242164 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242166 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242165));
  V v_x1_242167 = heff_get_n(v_t_242166, 6, 9);
  V v_t_242168;
  if ((heff_dup(v_x1_242167) == NTAG(TAG_True))) {
    heff_drop(v_x1_242167);
    v_t_242168 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242167);
    v_t_242168 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242169 = heff_tr(heff_call(v_one_242164, 1, (V[]){v_a_242165}));
  return (g_std_2edoc_2e_3c_3e(v_t_242168, v_t_242169));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args) {
  V v_a_242178 = args[0];
  V v_one_242177 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242179 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242178));
  V v_x1_242180 = heff_get_n(v_t_242179, 6, 9);
  V v_t_242181;
  if ((heff_dup(v_x1_242180) == NTAG(TAG_True))) {
    heff_drop(v_x1_242180);
    v_t_242181 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242180);
    v_t_242181 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242182 = heff_tr(heff_call(v_one_242177, 1, (V[]){v_a_242178}));
  return (g_std_2edoc_2e_3c_3e(v_t_242181, v_t_242182));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args) {
  V v_a_242190 = args[0];
  V v_one_242189 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242191 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242190));
  V v_x1_242192 = heff_get_n(v_t_242191, 6, 9);
  V v_t_242193;
  if ((heff_dup(v_x1_242192) == NTAG(TAG_True))) {
    heff_drop(v_x1_242192);
    v_t_242193 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242192);
    v_t_242193 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242194 = heff_tr(heff_call(v_one_242189, 1, (V[]){v_a_242190}));
  return (g_std_2edoc_2e_3c_3e(v_t_242193, v_t_242194));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args) {
  V v_a_242204 = args[0];
  V v_one_242203 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242205 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242204));
  V v_x1_242206 = heff_get_n(v_t_242205, 6, 9);
  V v_t_242207;
  if ((heff_dup(v_x1_242206) == NTAG(TAG_True))) {
    heff_drop(v_x1_242206);
    v_t_242207 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242206);
    v_t_242207 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242208 = heff_tr(heff_call(v_one_242203, 1, (V[]){v_a_242204}));
  return (g_std_2edoc_2e_3c_3e(v_t_242207, v_t_242208));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args) {
  V v_a_242216 = args[0];
  V v_one_242215 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242217 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242216));
  V v_x1_242218 = heff_get_n(v_t_242217, 6, 9);
  V v_t_242219;
  if ((heff_dup(v_x1_242218) == NTAG(TAG_True))) {
    heff_drop(v_x1_242218);
    v_t_242219 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242218);
    v_t_242219 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242220 = heff_tr(heff_call(v_one_242215, 1, (V[]){v_a_242216}));
  return (g_std_2edoc_2e_3c_3e(v_t_242219, v_t_242220));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args) {
  V v_a_242232 = args[0];
  V v_one_242231 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242233 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242232));
  V v_x1_242234 = heff_get_n(v_t_242233, 6, 9);
  V v_t_242235;
  if ((heff_dup(v_x1_242234) == NTAG(TAG_True))) {
    heff_drop(v_x1_242234);
    v_t_242235 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242234);
    v_t_242235 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242236 = heff_tr(heff_call(v_one_242231, 1, (V[]){v_a_242232}));
  return (g_std_2edoc_2e_3c_3e(v_t_242235, v_t_242236));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args) {
  V v_a_242244 = args[0];
  V v_one_242243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242245 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242244));
  V v_x1_242246 = heff_get_n(v_t_242245, 6, 9);
  V v_t_242247;
  if ((heff_dup(v_x1_242246) == NTAG(TAG_True))) {
    heff_drop(v_x1_242246);
    v_t_242247 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242246);
    v_t_242247 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242248 = heff_tr(heff_call(v_one_242243, 1, (V[]){v_a_242244}));
  return (g_std_2edoc_2e_3c_3e(v_t_242247, v_t_242248));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args) {
  V v_a_242255 = args[0];
  V v_one_242254 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242256 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242255));
  V v_x1_242257 = heff_get_n(v_t_242256, 6, 9);
  V v_t_242258;
  if ((heff_dup(v_x1_242257) == NTAG(TAG_True))) {
    heff_drop(v_x1_242257);
    v_t_242258 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242257);
    v_t_242258 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242259 = heff_tr(heff_call(v_one_242254, 1, (V[]){v_a_242255}));
  return (g_std_2edoc_2e_3c_3e(v_t_242258, v_t_242259));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args) {
  V v_a_242267 = args[0];
  V v_one_242266 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242268 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242267));
  V v_x1_242269 = heff_get_n(v_t_242268, 6, 9);
  V v_t_242270;
  if ((heff_dup(v_x1_242269) == NTAG(TAG_True))) {
    heff_drop(v_x1_242269);
    v_t_242270 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242269);
    v_t_242270 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242271 = heff_tr(heff_call(v_one_242266, 1, (V[]){v_a_242267}));
  return (g_std_2edoc_2e_3c_3e(v_t_242270, v_t_242271));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args) {
  V v_a_242279 = args[0];
  V v_one_242278 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242280 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242279));
  V v_x1_242281 = heff_get_n(v_t_242280, 6, 9);
  V v_t_242282;
  if ((heff_dup(v_x1_242281) == NTAG(TAG_True))) {
    heff_drop(v_x1_242281);
    v_t_242282 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242281);
    v_t_242282 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242283 = heff_tr(heff_call(v_one_242278, 1, (V[]){v_a_242279}));
  return (g_std_2edoc_2e_3c_3e(v_t_242282, v_t_242283));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args) {
  V v_a_242291 = args[0];
  V v_one_242290 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242292 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242291));
  V v_x1_242293 = heff_get_n(v_t_242292, 6, 9);
  V v_t_242294;
  if ((heff_dup(v_x1_242293) == NTAG(TAG_True))) {
    heff_drop(v_x1_242293);
    v_t_242294 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242293);
    v_t_242294 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242295 = heff_tr(heff_call(v_one_242290, 1, (V[]){v_a_242291}));
  return (g_std_2edoc_2e_3c_3e(v_t_242294, v_t_242295));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args) {
  V v_a_242305 = args[0];
  V v_one_242304 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242306 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242305));
  V v_x1_242307 = heff_get_n(v_t_242306, 6, 9);
  V v_t_242308;
  if ((heff_dup(v_x1_242307) == NTAG(TAG_True))) {
    heff_drop(v_x1_242307);
    v_t_242308 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242307);
    v_t_242308 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242309 = heff_tr(heff_call(v_one_242304, 1, (V[]){v_a_242305}));
  return (g_std_2edoc_2e_3c_3e(v_t_242308, v_t_242309));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args) {
  V v_a_242317 = args[0];
  V v_one_242316 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242318 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242317));
  V v_x1_242319 = heff_get_n(v_t_242318, 6, 9);
  V v_t_242320;
  if ((heff_dup(v_x1_242319) == NTAG(TAG_True))) {
    heff_drop(v_x1_242319);
    v_t_242320 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242319);
    v_t_242320 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242321 = heff_tr(heff_call(v_one_242316, 1, (V[]){v_a_242317}));
  return (g_std_2edoc_2e_3c_3e(v_t_242320, v_t_242321));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args) {
  V v_a_242329 = args[0];
  V v_one_242328 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242330 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242329));
  V v_x1_242331 = heff_get_n(v_t_242330, 6, 9);
  V v_t_242332;
  if ((heff_dup(v_x1_242331) == NTAG(TAG_True))) {
    heff_drop(v_x1_242331);
    v_t_242332 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242331);
    v_t_242332 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242333 = heff_tr(heff_call(v_one_242328, 1, (V[]){v_a_242329}));
  return (g_std_2edoc_2e_3c_3e(v_t_242332, v_t_242333));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args) {
  V v_a_242341 = args[0];
  V v_one_242340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242342 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242341));
  V v_x1_242343 = heff_get_n(v_t_242342, 6, 9);
  V v_t_242344;
  if ((heff_dup(v_x1_242343) == NTAG(TAG_True))) {
    heff_drop(v_x1_242343);
    v_t_242344 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242343);
    v_t_242344 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242345 = heff_tr(heff_call(v_one_242340, 1, (V[]){v_a_242341}));
  return (g_std_2edoc_2e_3c_3e(v_t_242344, v_t_242345));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args) {
  V v_a_242355 = args[0];
  V v_one_242354 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242356 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242355));
  V v_x1_242357 = heff_get_n(v_t_242356, 6, 9);
  V v_t_242358;
  if ((heff_dup(v_x1_242357) == NTAG(TAG_True))) {
    heff_drop(v_x1_242357);
    v_t_242358 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242357);
    v_t_242358 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242359 = heff_tr(heff_call(v_one_242354, 1, (V[]){v_a_242355}));
  return (g_std_2edoc_2e_3c_3e(v_t_242358, v_t_242359));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args) {
  V v_a_242367 = args[0];
  V v_one_242366 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242368 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242367));
  V v_x1_242369 = heff_get_n(v_t_242368, 6, 9);
  V v_t_242370;
  if ((heff_dup(v_x1_242369) == NTAG(TAG_True))) {
    heff_drop(v_x1_242369);
    v_t_242370 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242369);
    v_t_242370 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242371 = heff_tr(heff_call(v_one_242366, 1, (V[]){v_a_242367}));
  return (g_std_2edoc_2e_3c_3e(v_t_242370, v_t_242371));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args) {
  V v_a_242381 = args[0];
  V v_one_242380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242382 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242381));
  V v_x1_242383 = heff_get_n(v_t_242382, 6, 9);
  V v_t_242384;
  if ((heff_dup(v_x1_242383) == NTAG(TAG_True))) {
    heff_drop(v_x1_242383);
    v_t_242384 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242383);
    v_t_242384 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242385 = heff_tr(heff_call(v_one_242380, 1, (V[]){v_a_242381}));
  return (g_std_2edoc_2e_3c_3e(v_t_242384, v_t_242385));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args) {
  V v_a_242393 = args[0];
  V v_one_242392 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242394 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242393));
  V v_x1_242395 = heff_get_n(v_t_242394, 6, 9);
  V v_t_242396;
  if ((heff_dup(v_x1_242395) == NTAG(TAG_True))) {
    heff_drop(v_x1_242395);
    v_t_242396 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242395);
    v_t_242396 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242397 = heff_tr(heff_call(v_one_242392, 1, (V[]){v_a_242393}));
  return (g_std_2edoc_2e_3c_3e(v_t_242396, v_t_242397));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args) {
  V v_a_242407 = args[0];
  V v_one_242406 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242408 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242407));
  V v_x1_242409 = heff_get_n(v_t_242408, 6, 9);
  V v_t_242410;
  if ((heff_dup(v_x1_242409) == NTAG(TAG_True))) {
    heff_drop(v_x1_242409);
    v_t_242410 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242409);
    v_t_242410 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242411 = heff_tr(heff_call(v_one_242406, 1, (V[]){v_a_242407}));
  return (g_std_2edoc_2e_3c_3e(v_t_242410, v_t_242411));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args) {
  V v_a_242419 = args[0];
  V v_one_242418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242420 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242419));
  V v_x1_242421 = heff_get_n(v_t_242420, 6, 9);
  V v_t_242422;
  if ((heff_dup(v_x1_242421) == NTAG(TAG_True))) {
    heff_drop(v_x1_242421);
    v_t_242422 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242421);
    v_t_242422 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242423 = heff_tr(heff_call(v_one_242418, 1, (V[]){v_a_242419}));
  return (g_std_2edoc_2e_3c_3e(v_t_242422, v_t_242423));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args) {
  V v_a_242435 = args[0];
  V v_one_242434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242436 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242435));
  V v_x1_242437 = heff_get_n(v_t_242436, 6, 9);
  V v_t_242438;
  if ((heff_dup(v_x1_242437) == NTAG(TAG_True))) {
    heff_drop(v_x1_242437);
    v_t_242438 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242437);
    v_t_242438 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242439 = heff_tr(heff_call(v_one_242434, 1, (V[]){v_a_242435}));
  return (g_std_2edoc_2e_3c_3e(v_t_242438, v_t_242439));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args) {
  V v_a_242447 = args[0];
  V v_one_242446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242448 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242447));
  V v_x1_242449 = heff_get_n(v_t_242448, 6, 9);
  V v_t_242450;
  if ((heff_dup(v_x1_242449) == NTAG(TAG_True))) {
    heff_drop(v_x1_242449);
    v_t_242450 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242449);
    v_t_242450 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242451 = heff_tr(heff_call(v_one_242446, 1, (V[]){v_a_242447}));
  return (g_std_2edoc_2e_3c_3e(v_t_242450, v_t_242451));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_env_241297 = args[0];
  V v_h_241298 = args[1];
  V v_args_241299 = args[2];
  V v_x1_241300 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_241299)));
  switch (heff_tag_of(v_x1_241300)) {
  case TAG_Nil: {
    heff_drop(v_args_241299);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241297;
    args[1] = v_h_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_241301 = heff_field(v_x1_241300, 0);
    V v_rev_241302 = heff_field(v_x1_241300, 1);
    V v_ru_24x1_241300_24Cons = heff_take_reuse_n(v_x1_241300, 3ULL, 2);
    V v_t_241303 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_241302));
    switch (heff_tag_of(v_x_241301)) {
    case TAG_Atom: {
      V v_t_241305 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241305) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241305);
        V v_t_241306 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241313 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241307}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241314 = (g_std_2edoc_2e_3c_3e(v_t_241306, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241313})));
        V v_a_241315 = (g_std_2edoc_2egroup(v_t_241314));
        V v_b_241316 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241317 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_241316));
        return (g_std_2edoc_2e_3c_3e(v_a_241315, v_t_241317));
      } else {
        heff_drop_tag(v_x_241301, 1);
        heff_drop(v_t_241303);
        heff_drop(v_t_241305);
        V v_t_241318 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241319 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241325 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241319}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241326 = (g_std_2edoc_2e_3c_3e(v_t_241318, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241325})));
        return (g_std_2edoc_2egroup(v_t_241326));
      }
    }
    case TAG_EParen: {
      V v_o_241327 = heff_field(v_x_241301, 0);
      V v_e_241328 = heff_field(v_x_241301, 1);
      V v_c_241329 = heff_field(v_x_241301, 2);
      heff_take_n(v_x_241301, 7ULL, 3);
      V v_t_241330 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_241328));
      if ((heff_dup(v_t_241330) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241330);
        V v_t_241331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241332 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241338 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241332}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241339 = (g_std_2edoc_2e_3c_3e(v_t_241331, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241338})));
        V v_a_241340 = (g_std_2edoc_2egroup(v_t_241339));
        V v_b_241341 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241297), v_o_241327));
        V v_t_241342 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str111)}), v_b_241341));
        V v_t_241343 = (g_std_2edoc_2e_3c_3e(v_a_241340, v_t_241342));
        V v_t_241344 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_e_241328}));
        V v_t_241345 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241297, v_c_241329));
        V v_t_241346 = (g_std_2edoc_2e_3c_3e(v_t_241344, v_t_241345));
        return (g_std_2edoc_2e_3c_3e(v_t_241343, v_t_241346));
      } else {
        heff_drop(v_t_241303);
        heff_drop(v_o_241327);
        heff_drop(v_e_241328);
        heff_drop(v_c_241329);
        heff_drop(v_t_241330);
        V v_t_241347 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241348 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241354 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241348}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241355 = (g_std_2edoc_2e_3c_3e(v_t_241347, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241354})));
        return (g_std_2edoc_2egroup(v_t_241355));
      }
    }
    case TAG_Named: {
      V v_t_241361 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241361) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241361);
        V v_t_241362 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241363 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241369 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241363}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241370 = (g_std_2edoc_2e_3c_3e(v_t_241362, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241369})));
        V v_a_241371 = (g_std_2edoc_2egroup(v_t_241370));
        V v_b_241372 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241373 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str112)}), v_b_241372));
        return (g_std_2edoc_2e_3c_3e(v_a_241371, v_t_241373));
      } else {
        heff_drop_tag(v_x_241301, 5);
        heff_drop(v_t_241303);
        heff_drop(v_t_241361);
        V v_t_241374 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241375 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241381 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241375}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241382 = (g_std_2edoc_2e_3c_3e(v_t_241374, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241381})));
        return (g_std_2edoc_2egroup(v_t_241382));
      }
    }
    case TAG_Tup: {
      V v_t_241387 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241387) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241387);
        V v_t_241388 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241389 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241395 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241389}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241396 = (g_std_2edoc_2e_3c_3e(v_t_241388, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241395})));
        V v_a_241397 = (g_std_2edoc_2egroup(v_t_241396));
        V v_b_241398 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241399 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str113)}), v_b_241398));
        return (g_std_2edoc_2e_3c_3e(v_a_241397, v_t_241399));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_241387);
        V v_t_241400 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241401 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241407 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241401}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241408 = (g_std_2edoc_2e_3c_3e(v_t_241400, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241407})));
        return (g_std_2edoc_2egroup(v_t_241408));
      }
    }
    case TAG_Seg: {
      V v_t_241412 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241412) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241412);
        V v_t_241413 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241420 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241414}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241421 = (g_std_2edoc_2e_3c_3e(v_t_241413, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241420})));
        V v_a_241422 = (g_std_2edoc_2egroup(v_t_241421));
        V v_b_241423 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241424 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str114)}), v_b_241423));
        return (g_std_2edoc_2e_3c_3e(v_a_241422, v_t_241424));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241412);
        V v_t_241425 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241426 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241432 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241426}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241433 = (g_std_2edoc_2e_3c_3e(v_t_241425, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241432})));
        return (g_std_2edoc_2egroup(v_t_241433));
      }
    }
    case TAG_Braces: {
      V v_t_241438 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241438) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241438);
        V v_t_241439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241440 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241446 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241440}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241447 = (g_std_2edoc_2e_3c_3e(v_t_241439, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241446})));
        V v_a_241448 = (g_std_2edoc_2egroup(v_t_241447));
        V v_b_241449 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241450 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str115)}), v_b_241449));
        return (g_std_2edoc_2e_3c_3e(v_a_241448, v_t_241450));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_241438);
        V v_t_241451 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241452 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241458 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241452}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241459 = (g_std_2edoc_2e_3c_3e(v_t_241451, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241458})));
        return (g_std_2edoc_2egroup(v_t_241459));
      }
    }
    case TAG_Update: {
      V v_t_241466 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241466) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241466);
        V v_t_241467 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241468 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241474 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241468}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241475 = (g_std_2edoc_2e_3c_3e(v_t_241467, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241474})));
        V v_a_241476 = (g_std_2edoc_2egroup(v_t_241475));
        V v_b_241477 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241478 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str116)}), v_b_241477));
        return (g_std_2edoc_2e_3c_3e(v_a_241476, v_t_241478));
      } else {
        heff_drop_tag(v_x_241301, 6);
        heff_drop(v_t_241303);
        heff_drop(v_t_241466);
        V v_t_241479 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241480 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241486 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241480}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241487 = (g_std_2edoc_2e_3c_3e(v_t_241479, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241486})));
        return (g_std_2edoc_2egroup(v_t_241487));
      }
    }
    case TAG_EUSet: {
      V v_t_241491 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241491) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241491);
        V v_t_241492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241493 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241499 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241493}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241500 = (g_std_2edoc_2e_3c_3e(v_t_241492, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241499})));
        V v_a_241501 = (g_std_2edoc_2egroup(v_t_241500));
        V v_b_241502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241503 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str117)}), v_b_241502));
        return (g_std_2edoc_2e_3c_3e(v_a_241501, v_t_241503));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241491);
        V v_t_241504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241505 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241511 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241505}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241512 = (g_std_2edoc_2e_3c_3e(v_t_241504, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241511})));
        return (g_std_2edoc_2egroup(v_t_241512));
      }
    }
    case TAG_InstB: {
      V v_t_241518 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241518) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241518);
        V v_t_241519 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241520 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241526 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241520}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241527 = (g_std_2edoc_2e_3c_3e(v_t_241519, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241526})));
        V v_a_241528 = (g_std_2edoc_2egroup(v_t_241527));
        V v_b_241529 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241530 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str118)}), v_b_241529));
        return (g_std_2edoc_2e_3c_3e(v_a_241528, v_t_241530));
      } else {
        heff_drop_tag(v_x_241301, 5);
        heff_drop(v_t_241303);
        heff_drop(v_t_241518);
        V v_t_241531 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241532 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241538 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241532}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241539 = (g_std_2edoc_2e_3c_3e(v_t_241531, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241538})));
        return (g_std_2edoc_2egroup(v_t_241539));
      }
    }
    case TAG_EFSet: {
      V v_t_241543 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241543) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241543);
        V v_t_241544 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241545 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241551 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241545}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241552 = (g_std_2edoc_2e_3c_3e(v_t_241544, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241551})));
        V v_a_241553 = (g_std_2edoc_2egroup(v_t_241552));
        V v_b_241554 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241555 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str119)}), v_b_241554));
        return (g_std_2edoc_2e_3c_3e(v_a_241553, v_t_241555));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241543);
        V v_t_241556 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241557 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241563 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241557}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241564 = (g_std_2edoc_2e_3c_3e(v_t_241556, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241563})));
        return (g_std_2edoc_2egroup(v_t_241564));
      }
    }
    case TAG_EFDefault: {
      V v_t_241568 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241568) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241568);
        V v_t_241569 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241570 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241576 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241570}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241577 = (g_std_2edoc_2e_3c_3e(v_t_241569, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241576})));
        V v_a_241578 = (g_std_2edoc_2egroup(v_t_241577));
        V v_b_241579 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241580 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str120)}), v_b_241579));
        return (g_std_2edoc_2e_3c_3e(v_a_241578, v_t_241580));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241568);
        V v_t_241581 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241582 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241588 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241582}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241589 = (g_std_2edoc_2e_3c_3e(v_t_241581, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241588})));
        return (g_std_2edoc_2egroup(v_t_241589));
      }
    }
    case TAG_Sum: {
      V v_t_241595 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241595) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241595);
        V v_t_241596 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241597 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241603 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241597}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241604 = (g_std_2edoc_2e_3c_3e(v_t_241596, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241603})));
        V v_a_241605 = (g_std_2edoc_2egroup(v_t_241604));
        V v_b_241606 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241607 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str121)}), v_b_241606));
        return (g_std_2edoc_2e_3c_3e(v_a_241605, v_t_241607));
      } else {
        heff_drop_tag(v_x_241301, 5);
        heff_drop(v_t_241303);
        heff_drop(v_t_241595);
        V v_t_241608 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241609 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241615 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241609}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241616 = (g_std_2edoc_2e_3c_3e(v_t_241608, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241615})));
        return (g_std_2edoc_2egroup(v_t_241616));
      }
    }
    case TAG_ECon: {
      V v_t_241619 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241619) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241619);
        V v_t_241620 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241621 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241627 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241621}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241628 = (g_std_2edoc_2e_3c_3e(v_t_241620, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241627})));
        V v_a_241629 = (g_std_2edoc_2egroup(v_t_241628));
        V v_b_241630 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241631 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str122)}), v_b_241630));
        return (g_std_2edoc_2e_3c_3e(v_a_241629, v_t_241631));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_241619);
        V v_t_241632 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241633 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241639 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241633}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241640 = (g_std_2edoc_2e_3c_3e(v_t_241632, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241639})));
        return (g_std_2edoc_2egroup(v_t_241640));
      }
    }
    case TAG_EField: {
      V v_t_241643 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241643) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241643);
        V v_t_241644 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241645 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241651 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241645}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241652 = (g_std_2edoc_2e_3c_3e(v_t_241644, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241651})));
        V v_a_241653 = (g_std_2edoc_2egroup(v_t_241652));
        V v_b_241654 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241655 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str123)}), v_b_241654));
        return (g_std_2edoc_2e_3c_3e(v_a_241653, v_t_241655));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_241643);
        V v_t_241656 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241657 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241663 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241657}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241664 = (g_std_2edoc_2e_3c_3e(v_t_241656, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241663})));
        return (g_std_2edoc_2egroup(v_t_241664));
      }
    }
    case TAG_ENeg: {
      V v_t_241667 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241667) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241667);
        V v_t_241668 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241669 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241675 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241669}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241676 = (g_std_2edoc_2e_3c_3e(v_t_241668, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241675})));
        V v_a_241677 = (g_std_2edoc_2egroup(v_t_241676));
        V v_b_241678 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241679 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str124)}), v_b_241678));
        return (g_std_2edoc_2e_3c_3e(v_a_241677, v_t_241679));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_241667);
        V v_t_241680 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241681 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241687 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241681}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241688 = (g_std_2edoc_2e_3c_3e(v_t_241680, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241687})));
        return (g_std_2edoc_2egroup(v_t_241688));
      }
    }
    case TAG_ETilde: {
      V v_t_241691 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241691) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241691);
        V v_t_241692 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241693 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241699 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241693}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241700 = (g_std_2edoc_2e_3c_3e(v_t_241692, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241699})));
        V v_a_241701 = (g_std_2edoc_2egroup(v_t_241700));
        V v_b_241702 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241703 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str125)}), v_b_241702));
        return (g_std_2edoc_2e_3c_3e(v_a_241701, v_t_241703));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_241691);
        V v_t_241704 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241705 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241711 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241705}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241712 = (g_std_2edoc_2e_3c_3e(v_t_241704, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241711})));
        return (g_std_2edoc_2egroup(v_t_241712));
      }
    }
    case TAG_App: {
      V v_t_241715 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241715) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241715);
        V v_t_241716 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241717 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241723 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241717}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241724 = (g_std_2edoc_2e_3c_3e(v_t_241716, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241723})));
        V v_a_241725 = (g_std_2edoc_2egroup(v_t_241724));
        V v_b_241726 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241727 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str126)}), v_b_241726));
        return (g_std_2edoc_2e_3c_3e(v_a_241725, v_t_241727));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_241715);
        V v_t_241728 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241729 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241735 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241729}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241736 = (g_std_2edoc_2e_3c_3e(v_t_241728, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241735})));
        return (g_std_2edoc_2egroup(v_t_241736));
      }
    }
    case TAG_Op: {
      V v_t_241740 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241740) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241740);
        V v_t_241741 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241748 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241742}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241749 = (g_std_2edoc_2e_3c_3e(v_t_241741, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241748})));
        V v_a_241750 = (g_std_2edoc_2egroup(v_t_241749));
        V v_b_241751 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241752 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str127)}), v_b_241751));
        return (g_std_2edoc_2e_3c_3e(v_a_241750, v_t_241752));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241740);
        V v_t_241753 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241754 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241760 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241754}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241761 = (g_std_2edoc_2e_3c_3e(v_t_241753, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241760})));
        return (g_std_2edoc_2egroup(v_t_241761));
      }
    }
    case TAG_Ops: {
      V v_t_241764 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241764) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241764);
        V v_t_241765 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241766 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241772 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241766}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241773 = (g_std_2edoc_2e_3c_3e(v_t_241765, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241772})));
        V v_a_241774 = (g_std_2edoc_2egroup(v_t_241773));
        V v_b_241775 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241776 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str128)}), v_b_241775));
        return (g_std_2edoc_2e_3c_3e(v_a_241774, v_t_241776));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_241764);
        V v_t_241777 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241778 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241784 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241778}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241785 = (g_std_2edoc_2e_3c_3e(v_t_241777, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241784})));
        return (g_std_2edoc_2egroup(v_t_241785));
      }
    }
    case TAG_OpRhs: {
      V v_t_241788 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241788) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241788);
        V v_t_241789 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241790 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241796 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241790}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241797 = (g_std_2edoc_2e_3c_3e(v_t_241789, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241796})));
        V v_a_241798 = (g_std_2edoc_2egroup(v_t_241797));
        V v_b_241799 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241800 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str129)}), v_b_241799));
        return (g_std_2edoc_2e_3c_3e(v_a_241798, v_t_241800));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_241788);
        V v_t_241801 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241802 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241808 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241802}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241809 = (g_std_2edoc_2e_3c_3e(v_t_241801, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241808})));
        return (g_std_2edoc_2egroup(v_t_241809));
      }
    }
    case TAG_Ann: {
      V v_t_241813 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241813) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241813);
        V v_t_241814 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241815 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241821 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241815}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241822 = (g_std_2edoc_2e_3c_3e(v_t_241814, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241821})));
        V v_a_241823 = (g_std_2edoc_2egroup(v_t_241822));
        V v_b_241824 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241825 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str130)}), v_b_241824));
        return (g_std_2edoc_2e_3c_3e(v_a_241823, v_t_241825));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241813);
        V v_t_241826 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241827 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241833 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241827}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241834 = (g_std_2edoc_2e_3c_3e(v_t_241826, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241833})));
        return (g_std_2edoc_2egroup(v_t_241834));
      }
    }
    case TAG_BVar: {
      V v_t_241836 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241836) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241836);
        V v_t_241837 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241838 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241844 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241838}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241845 = (g_std_2edoc_2e_3c_3e(v_t_241837, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241844})));
        V v_a_241846 = (g_std_2edoc_2egroup(v_t_241845));
        V v_b_241847 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241848 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str131)}), v_b_241847));
        return (g_std_2edoc_2e_3c_3e(v_a_241846, v_t_241848));
      } else {
        heff_drop_tag(v_x_241301, 1);
        heff_drop(v_t_241303);
        heff_drop(v_t_241836);
        V v_t_241849 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241850 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241856 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241850}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241857 = (g_std_2edoc_2e_3c_3e(v_t_241849, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241856})));
        return (g_std_2edoc_2egroup(v_t_241857));
      }
    }
    case TAG_BImp: {
      V v_t_241861 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241861) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241861);
        V v_t_241862 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241863 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241869 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241863}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241870 = (g_std_2edoc_2e_3c_3e(v_t_241862, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241869})));
        V v_a_241871 = (g_std_2edoc_2egroup(v_t_241870));
        V v_b_241872 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241873 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str132)}), v_b_241872));
        return (g_std_2edoc_2e_3c_3e(v_a_241871, v_t_241873));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241861);
        V v_t_241874 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241875 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241881 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241875}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241882 = (g_std_2edoc_2e_3c_3e(v_t_241874, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241881})));
        return (g_std_2edoc_2egroup(v_t_241882));
      }
    }
    case TAG_BAnn: {
      V v_t_241888 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241888) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241888);
        V v_t_241889 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241890 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241896 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241890}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241897 = (g_std_2edoc_2e_3c_3e(v_t_241889, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241896})));
        V v_a_241898 = (g_std_2edoc_2egroup(v_t_241897));
        V v_b_241899 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241900 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str133)}), v_b_241899));
        return (g_std_2edoc_2e_3c_3e(v_a_241898, v_t_241900));
      } else {
        heff_drop_tag(v_x_241301, 5);
        heff_drop(v_t_241303);
        heff_drop(v_t_241888);
        V v_t_241901 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241902 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241908 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241902}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241909 = (g_std_2edoc_2e_3c_3e(v_t_241901, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241908})));
        return (g_std_2edoc_2egroup(v_t_241909));
      }
    }
    case TAG_BPat: {
      V v_t_241911 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241911) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241911);
        V v_t_241912 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241913 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241919 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241913}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241920 = (g_std_2edoc_2e_3c_3e(v_t_241912, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241919})));
        V v_a_241921 = (g_std_2edoc_2egroup(v_t_241920));
        V v_b_241922 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241923 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str134)}), v_b_241922));
        return (g_std_2edoc_2e_3c_3e(v_a_241921, v_t_241923));
      } else {
        heff_drop_tag(v_x_241301, 1);
        heff_drop(v_t_241303);
        heff_drop(v_t_241911);
        V v_t_241924 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241925 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241931 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241925}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241932 = (g_std_2edoc_2e_3c_3e(v_t_241924, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241931})));
        return (g_std_2edoc_2egroup(v_t_241932));
      }
    }
    case TAG_Lam: {
      V v_t_241937 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241937) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241937);
        V v_t_241938 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241939 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241945 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 1, 1, (V[]){v_one_241939}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241946 = (g_std_2edoc_2e_3c_3e(v_t_241938, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241945})));
        V v_a_241947 = (g_std_2edoc_2egroup(v_t_241946));
        V v_b_241948 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241949 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str135)}), v_b_241948));
        return (g_std_2edoc_2e_3c_3e(v_a_241947, v_t_241949));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_241937);
        V v_t_241950 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241951 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241957 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 1, 1, (V[]){v_one_241951}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241958 = (g_std_2edoc_2e_3c_3e(v_t_241950, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241957})));
        return (g_std_2edoc_2egroup(v_t_241958));
      }
    }
    case TAG_Case: {
      V v_t_241963 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241963) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241963);
        V v_t_241964 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241965 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241971 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 1, 1, (V[]){v_one_241965}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241972 = (g_std_2edoc_2e_3c_3e(v_t_241964, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241971})));
        V v_a_241973 = (g_std_2edoc_2egroup(v_t_241972));
        V v_b_241974 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_241975 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str136)}), v_b_241974));
        return (g_std_2edoc_2e_3c_3e(v_a_241973, v_t_241975));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_241963);
        V v_t_241976 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241977 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_241983 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 1, 1, (V[]){v_one_241977}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_241984 = (g_std_2edoc_2e_3c_3e(v_t_241976, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241983})));
        return (g_std_2edoc_2egroup(v_t_241984));
      }
    }
    case TAG_EAlt: {
      V v_t_241988 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_241988) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_241988);
        V v_t_241989 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_241990 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_241996 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 1, 1, (V[]){v_one_241990}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_241997 = (g_std_2edoc_2e_3c_3e(v_t_241989, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241996})));
        V v_a_241998 = (g_std_2edoc_2egroup(v_t_241997));
        V v_b_241999 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242000 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str137)}), v_b_241999));
        return (g_std_2edoc_2e_3c_3e(v_a_241998, v_t_242000));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_241988);
        V v_t_242001 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242002 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242008 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_one_242002}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242009 = (g_std_2edoc_2e_3c_3e(v_t_242001, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242008})));
        return (g_std_2edoc_2egroup(v_t_242009));
      }
    }
    case TAG_If: {
      V v_t_242016 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242016) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242016);
        V v_t_242017 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242018 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242024 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_one_242018}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242025 = (g_std_2edoc_2e_3c_3e(v_t_242017, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242024})));
        V v_a_242026 = (g_std_2edoc_2egroup(v_t_242025));
        V v_b_242027 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242028 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str138)}), v_b_242027));
        return (g_std_2edoc_2e_3c_3e(v_a_242026, v_t_242028));
      } else {
        heff_drop_tag(v_x_241301, 6);
        heff_drop(v_t_241303);
        heff_drop(v_t_242016);
        V v_t_242029 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242030 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242036 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 1, 1, (V[]){v_one_242030}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242037 = (g_std_2edoc_2e_3c_3e(v_t_242029, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242036})));
        return (g_std_2edoc_2egroup(v_t_242037));
      }
    }
    case TAG_Do: {
      V v_t_242040 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242040) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242040);
        V v_t_242041 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242042 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242048 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 1, 1, (V[]){v_one_242042}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242049 = (g_std_2edoc_2e_3c_3e(v_t_242041, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242048})));
        V v_a_242050 = (g_std_2edoc_2egroup(v_t_242049));
        V v_b_242051 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242052 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str139)}), v_b_242051));
        return (g_std_2edoc_2e_3c_3e(v_a_242050, v_t_242052));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_242040);
        V v_t_242053 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242054 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242060 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 1, 1, (V[]){v_one_242054}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242061 = (g_std_2edoc_2e_3c_3e(v_t_242053, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242060})));
        return (g_std_2edoc_2egroup(v_t_242061));
      }
    }
    case TAG_ESBind: {
      V v_t_242065 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242065) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242065);
        V v_t_242066 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242067 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242073 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 1, 1, (V[]){v_one_242067}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242074 = (g_std_2edoc_2e_3c_3e(v_t_242066, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242073})));
        V v_a_242075 = (g_std_2edoc_2egroup(v_t_242074));
        V v_b_242076 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242077 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str140)}), v_b_242076));
        return (g_std_2edoc_2e_3c_3e(v_a_242075, v_t_242077));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_242065);
        V v_t_242078 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242079 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242085 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam97, 1, 1, (V[]){v_one_242079}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242086 = (g_std_2edoc_2e_3c_3e(v_t_242078, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242085})));
        return (g_std_2edoc_2egroup(v_t_242086));
      }
    }
    case TAG_ELet: {
      V v_t_242093 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242093) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242093);
        V v_t_242094 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242095 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242101 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam98, 1, 1, (V[]){v_one_242095}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242102 = (g_std_2edoc_2e_3c_3e(v_t_242094, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242101})));
        V v_a_242103 = (g_std_2edoc_2egroup(v_t_242102));
        V v_b_242104 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242105 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str141)}), v_b_242104));
        return (g_std_2edoc_2e_3c_3e(v_a_242103, v_t_242105));
      } else {
        heff_drop_tag(v_x_241301, 6);
        heff_drop(v_t_241303);
        heff_drop(v_t_242093);
        V v_t_242106 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242107 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242113 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam99, 1, 1, (V[]){v_one_242107}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242114 = (g_std_2edoc_2e_3c_3e(v_t_242106, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242113})));
        return (g_std_2edoc_2egroup(v_t_242114));
      }
    }
    case TAG_ELetElse: {
      V v_t_242122 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242122) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242122);
        V v_t_242123 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242130 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam100, 1, 1, (V[]){v_one_242124}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242131 = (g_std_2edoc_2e_3c_3e(v_t_242123, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242130})));
        V v_a_242132 = (g_std_2edoc_2egroup(v_t_242131));
        V v_b_242133 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242134 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str142)}), v_b_242133));
        return (g_std_2edoc_2e_3c_3e(v_a_242132, v_t_242134));
      } else {
        heff_drop_tag(v_x_241301, 7);
        heff_drop(v_t_241303);
        heff_drop(v_t_242122);
        V v_t_242135 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242136 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242142 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam101, 1, 1, (V[]){v_one_242136}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242143 = (g_std_2edoc_2e_3c_3e(v_t_242135, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242142})));
        return (g_std_2edoc_2egroup(v_t_242143));
      }
    }
    case TAG_ELetMut: {
      V v_t_242150 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242150) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242150);
        V v_t_242151 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242152 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242158 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam102, 1, 1, (V[]){v_one_242152}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242159 = (g_std_2edoc_2e_3c_3e(v_t_242151, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242158})));
        V v_a_242160 = (g_std_2edoc_2egroup(v_t_242159));
        V v_b_242161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242162 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str143)}), v_b_242161));
        return (g_std_2edoc_2e_3c_3e(v_a_242160, v_t_242162));
      } else {
        heff_drop_tag(v_x_241301, 6);
        heff_drop(v_t_241303);
        heff_drop(v_t_242150);
        V v_t_242163 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242164 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242170 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam103, 1, 1, (V[]){v_one_242164}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242171 = (g_std_2edoc_2e_3c_3e(v_t_242163, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242170})));
        return (g_std_2edoc_2egroup(v_t_242171));
      }
    }
    case TAG_EAssign: {
      V v_t_242175 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242175) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242175);
        V v_t_242176 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242177 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242183 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam104, 1, 1, (V[]){v_one_242177}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242184 = (g_std_2edoc_2e_3c_3e(v_t_242176, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242183})));
        V v_a_242185 = (g_std_2edoc_2egroup(v_t_242184));
        V v_b_242186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242187 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str144)}), v_b_242186));
        return (g_std_2edoc_2e_3c_3e(v_a_242185, v_t_242187));
      } else {
        heff_drop_tag(v_x_241301, 3);
        heff_drop(v_t_241303);
        heff_drop(v_t_242175);
        V v_t_242188 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242189 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242195 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam105, 1, 1, (V[]){v_one_242189}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242196 = (g_std_2edoc_2e_3c_3e(v_t_242188, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242195})));
        return (g_std_2edoc_2egroup(v_t_242196));
      }
    }
    case TAG_EWhile: {
      V v_t_242201 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242201) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242201);
        V v_t_242202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242203 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242209 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam106, 1, 1, (V[]){v_one_242203}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242210 = (g_std_2edoc_2e_3c_3e(v_t_242202, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242209})));
        V v_a_242211 = (g_std_2edoc_2egroup(v_t_242210));
        V v_b_242212 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242213 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str145)}), v_b_242212));
        return (g_std_2edoc_2e_3c_3e(v_a_242211, v_t_242213));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_242201);
        V v_t_242214 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242215 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242221 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam107, 1, 1, (V[]){v_one_242215}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242222 = (g_std_2edoc_2e_3c_3e(v_t_242214, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242221})));
        return (g_std_2edoc_2egroup(v_t_242222));
      }
    }
    case TAG_EFor: {
      V v_t_242229 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242229) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242229);
        V v_t_242230 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242231 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242237 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam108, 1, 1, (V[]){v_one_242231}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242238 = (g_std_2edoc_2e_3c_3e(v_t_242230, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242237})));
        V v_a_242239 = (g_std_2edoc_2egroup(v_t_242238));
        V v_b_242240 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242241 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str146)}), v_b_242240));
        return (g_std_2edoc_2e_3c_3e(v_a_242239, v_t_242241));
      } else {
        heff_drop_tag(v_x_241301, 6);
        heff_drop(v_t_241303);
        heff_drop(v_t_242229);
        V v_t_242242 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242243 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242249 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam109, 1, 1, (V[]){v_one_242243}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242250 = (g_std_2edoc_2e_3c_3e(v_t_242242, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242249})));
        return (g_std_2edoc_2egroup(v_t_242250));
      }
    }
    case TAG_EJump: {
      V v_t_242252 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242252) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242252);
        V v_t_242253 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242254 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242260 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam110, 1, 1, (V[]){v_one_242254}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242261 = (g_std_2edoc_2e_3c_3e(v_t_242253, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242260})));
        V v_a_242262 = (g_std_2edoc_2egroup(v_t_242261));
        V v_b_242263 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242264 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str147)}), v_b_242263));
        return (g_std_2edoc_2e_3c_3e(v_a_242262, v_t_242264));
      } else {
        heff_drop_tag(v_x_241301, 1);
        heff_drop(v_t_241303);
        heff_drop(v_t_242252);
        V v_t_242265 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242266 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242272 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam111, 1, 1, (V[]){v_one_242266}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242273 = (g_std_2edoc_2e_3c_3e(v_t_242265, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242272})));
        return (g_std_2edoc_2egroup(v_t_242273));
      }
    }
    case TAG_EReturn: {
      V v_t_242276 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242276) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242276);
        V v_t_242277 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242278 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242284 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam112, 1, 1, (V[]){v_one_242278}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242285 = (g_std_2edoc_2e_3c_3e(v_t_242277, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242284})));
        V v_a_242286 = (g_std_2edoc_2egroup(v_t_242285));
        V v_b_242287 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242288 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str148)}), v_b_242287));
        return (g_std_2edoc_2e_3c_3e(v_a_242286, v_t_242288));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_242276);
        V v_t_242289 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242290 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242296 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam113, 1, 1, (V[]){v_one_242290}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242297 = (g_std_2edoc_2e_3c_3e(v_t_242289, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242296})));
        return (g_std_2edoc_2egroup(v_t_242297));
      }
    }
    case TAG_ENest: {
      V v_t_242302 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242302) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242302);
        V v_t_242303 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242304 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242310 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam114, 1, 1, (V[]){v_one_242304}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242311 = (g_std_2edoc_2e_3c_3e(v_t_242303, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242310})));
        V v_a_242312 = (g_std_2edoc_2egroup(v_t_242311));
        V v_b_242313 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242314 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str149)}), v_b_242313));
        return (g_std_2edoc_2e_3c_3e(v_a_242312, v_t_242314));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_242302);
        V v_t_242315 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242316 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242322 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam115, 1, 1, (V[]){v_one_242316}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242323 = (g_std_2edoc_2e_3c_3e(v_t_242315, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242322})));
        return (g_std_2edoc_2egroup(v_t_242323));
      }
    }
    case TAG_EArrow: {
      V v_t_242326 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242326) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242326);
        V v_t_242327 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242328 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242334 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam116, 1, 1, (V[]){v_one_242328}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242335 = (g_std_2edoc_2e_3c_3e(v_t_242327, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242334})));
        V v_a_242336 = (g_std_2edoc_2egroup(v_t_242335));
        V v_b_242337 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242338 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str150)}), v_b_242337));
        return (g_std_2edoc_2e_3c_3e(v_a_242336, v_t_242338));
      } else {
        heff_drop_tag(v_x_241301, 2);
        heff_drop(v_t_241303);
        heff_drop(v_t_242326);
        V v_t_242339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242340 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242346 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam117, 1, 1, (V[]){v_one_242340}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242347 = (g_std_2edoc_2e_3c_3e(v_t_242339, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242346})));
        return (g_std_2edoc_2egroup(v_t_242347));
      }
    }
    case TAG_IfThen: {
      V v_t_242352 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242352) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242352);
        V v_t_242353 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242354 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242360 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam118, 1, 1, (V[]){v_one_242354}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242361 = (g_std_2edoc_2e_3c_3e(v_t_242353, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242360})));
        V v_a_242362 = (g_std_2edoc_2egroup(v_t_242361));
        V v_b_242363 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242364 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str151)}), v_b_242363));
        return (g_std_2edoc_2e_3c_3e(v_a_242362, v_t_242364));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_242352);
        V v_t_242365 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242366 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242372 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam119, 1, 1, (V[]){v_one_242366}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242373 = (g_std_2edoc_2e_3c_3e(v_t_242365, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242372})));
        return (g_std_2edoc_2egroup(v_t_242373));
      }
    }
    case TAG_ETry: {
      V v_t_242378 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242378) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242378);
        V v_t_242379 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242380 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242386 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam120, 1, 1, (V[]){v_one_242380}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242387 = (g_std_2edoc_2e_3c_3e(v_t_242379, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242386})));
        V v_a_242388 = (g_std_2edoc_2egroup(v_t_242387));
        V v_b_242389 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242390 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str152)}), v_b_242389));
        return (g_std_2edoc_2e_3c_3e(v_a_242388, v_t_242390));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_242378);
        V v_t_242391 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242398 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam121, 1, 1, (V[]){v_one_242392}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242399 = (g_std_2edoc_2e_3c_3e(v_t_242391, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242398})));
        return (g_std_2edoc_2egroup(v_t_242399));
      }
    }
    case TAG_ECatch: {
      V v_t_242404 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242404) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242404);
        V v_t_242405 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242406 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242412 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam122, 1, 1, (V[]){v_one_242406}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242413 = (g_std_2edoc_2e_3c_3e(v_t_242405, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242412})));
        V v_a_242414 = (g_std_2edoc_2egroup(v_t_242413));
        V v_b_242415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str153)}), v_b_242415));
        return (g_std_2edoc_2e_3c_3e(v_a_242414, v_t_242416));
      } else {
        heff_drop_tag(v_x_241301, 4);
        heff_drop(v_t_241303);
        heff_drop(v_t_242404);
        V v_t_242417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242418 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam123, 1, 1, (V[]){v_one_242418}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242425 = (g_std_2edoc_2e_3c_3e(v_t_242417, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242424})));
        return (g_std_2edoc_2egroup(v_t_242425));
      }
    }
    case TAG_EWith: {
      V v_t_242432 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241301));
      if ((heff_dup(v_t_242432) == NTAG(TAG_True))) {
        heff_drop(v_args_241299);
        heff_drop(v_t_242432);
        V v_t_242433 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242434 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241297)}));
        V v_d_242440 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam124, 1, 1, (V[]){v_one_242434}); V a_2 = v_t_241303; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241303); r_; });
        V v_t_242441 = (g_std_2edoc_2e_3c_3e(v_t_242433, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242440})));
        V v_a_242442 = (g_std_2edoc_2egroup(v_t_242441));
        V v_b_242443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241297, v_x_241301}));
        V v_t_242444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str154)}), v_b_242443));
        return (g_std_2edoc_2e_3c_3e(v_a_242442, v_t_242444));
      } else {
        heff_drop_tag(v_x_241301, 6);
        heff_drop(v_t_241303);
        heff_drop(v_t_242432);
        V v_t_242445 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241297), v_h_241298}));
        V v_one_242446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241297}));
        V v_d_242452 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam125, 1, 1, (V[]){v_one_242446}); V a_2 = v_args_241299; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241299); r_; });
        V v_t_242453 = (g_std_2edoc_2e_3c_3e(v_t_242445, heff_tag_at_n(v_ru_24x1_241300_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242452})));
        return (g_std_2edoc_2egroup(v_t_242453));
      }
    }
    default: return heff_nomatch(v_x_241301);
    }
  }
  default: return heff_nomatch(v_x1_241300);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args) {
  V v_env_242454 = args[0];
  V v_rest_242455 = args[1];
  V v_e_242456 = args[2];
  switch (heff_tag_of(v_e_242456)) {
  case TAG_Atom: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_242473 = heff_field(v_e_242456, 0);
    V v_fs_242474 = heff_field(v_e_242456, 1);
    V v_commas_242475 = heff_field(v_e_242456, 2);
    V v_c_242476 = heff_field(v_e_242456, 3);
    heff_take_n(v_e_242456, 15ULL, 4);
    switch (heff_tag_of(v_fs_242474)) {
    case TAG_Nil: {
      heff_drop(v_rest_242455);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_242454;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242473, v_fs_242474, v_commas_242475, v_c_242476});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_242477 = heff_dup(heff_field(v_fs_242474, 0));
      V v_rest2_242478 = heff_dup(heff_field(v_fs_242474, 1));
      switch (heff_tag_of(v_rest2_242478)) {
      case TAG_Nil: {
        V v_t_242479 = ({ V a_0 = v_rest_242455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_242455); r_; });
        if ((heff_dup(v_t_242479) == NTAG(TAG_True))) {
          heff_drop(v_t_242479);
          V v_x1_242480 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_242477));
          if ((heff_dup(v_x1_242480) == NTAG(TAG_True))) {
            heff_drop(v_d_242477);
            heff_drop(v_x1_242480);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_242454;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242473, v_fs_242474, v_commas_242475, v_c_242476});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_242480);
            switch (heff_tag_of(v_commas_242475)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_242474, 2);
              V v_t_242481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242454), v_o_242473));
              V v_t_242482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242454), v_d_242477}));
              V v_t_242483 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242454, v_c_242476));
              V v_t_242484 = (g_std_2edoc_2e_3c_3e(v_t_242482, v_t_242483));
              return (g_std_2edoc_2e_3c_3e(v_t_242481, v_t_242484));
            }
            case TAG_Cons: {
              heff_drop(v_d_242477);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_242454;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242473, v_fs_242474, v_commas_242475, v_c_242476});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_242475);
            }
          }
        } else {
          heff_drop(v_d_242477);
          heff_drop(v_t_242479);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_242454;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242473, v_fs_242474, v_commas_242475, v_c_242476});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_242478, 0ULL, 2);
        heff_drop(v_rest_242455);
        heff_drop(v_d_242477);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_242454;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242473, v_fs_242474, v_commas_242475, v_c_242476});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_242478);
      }
    }
    default: return heff_nomatch(v_fs_242474);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242455);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242454;
    args[1] = v_e_242456;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_242456);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args) {
  V v_env_242625 = args[0];
  V v_b_242626 = args[1];
  switch (heff_tag_of(v_b_242626)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_242692 = heff_field(v_b_242626, 0);
    heff_take_n(v_b_242626, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242625, v_t_242692));
  }
  case TAG_BImp: {
    V v_o_242693 = heff_field(v_b_242626, 0);
    V v_x_242694 = heff_field(v_b_242626, 1);
    V v_c_242695 = heff_field(v_b_242626, 2);
    heff_take_n(v_b_242626, 7ULL, 3);
    V v_t_242696 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242625), v_o_242693));
    V v_t_242697 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242625), v_x_242694));
    V v_t_242698 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242625, v_c_242695));
    V v_t_242699 = (g_std_2edoc_2e_3c_3e(v_t_242697, v_t_242698));
    return (g_std_2edoc_2e_3c_3e(v_t_242696, v_t_242699));
  }
  case TAG_BAnn: {
    V v_o_242700 = heff_field(v_b_242626, 0);
    V v_x_242701 = heff_field(v_b_242626, 1);
    V v_cc_242702 = heff_field(v_b_242626, 2);
    V v_ty_242703 = heff_field(v_b_242626, 3);
    V v_c_242704 = heff_field(v_b_242626, 4);
    heff_take_n(v_b_242626, 31ULL, 5);
    V v_t_242705 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242625), v_o_242700));
    V v_a_242706 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242625), v_x_242701));
    V v_a_242707 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242625), v_cc_242702));
    V v_b_242708 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242625), v_ty_242703}));
    V v_t_242709 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str155)}), v_b_242708));
    V v_t_242710 = (g_std_2edoc_2e_3c_3e(v_a_242707, v_t_242709));
    V v_t_242711 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str156)}), v_t_242710));
    V v_t_242712 = (g_std_2edoc_2e_3c_3e(v_a_242706, v_t_242711));
    V v_t_242713 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242625, v_c_242704));
    V v_t_242714 = (g_std_2edoc_2e_3c_3e(v_t_242712, v_t_242713));
    return (g_std_2edoc_2e_3c_3e(v_t_242705, v_t_242714));
  }
  case TAG_BPat: {
    V v_p_242715 = heff_field(v_b_242626, 0);
    heff_take_n(v_b_242626, 1ULL, 1);
    return ({ V a_0 = v_env_242625; V a_1 = v_p_242715; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_242715); r_; });
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242625;
    args[1] = v_b_242626;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_242626);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args) {
  V v_env_242797 = args[0];
  V v_rest_242798 = args[1];
  V v_r_242799 = args[2];
  switch (heff_tag_of(v_r_242799)) {
  case TAG_Atom: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242860 = heff_field(v_r_242799, 0);
    V v_e_242861 = heff_field(v_r_242799, 1);
    heff_take_n(v_r_242799, 3ULL, 2);
    V v_a_242862 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242797), v_op_242860));
    V v_b_242863 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_242797, v_rest_242798, v_e_242861}));
    V v_t_242864 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str157)}), v_b_242863));
    return (g_std_2edoc_2e_3c_3e(v_a_242862, v_t_242864));
  }
  case TAG_Ann: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242798);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242797;
    args[1] = v_r_242799;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242799);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args) {
  V v_env_242959 = args[0];
  V v_r_242960 = args[1];
  switch (heff_tag_of(v_r_242960)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_243021 = heff_field(v_r_242960, 0);
    V v_e_243022 = heff_field(v_r_242960, 1);
    heff_take_n(v_r_242960, 3ULL, 2);
    V v_a_243023 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242959), v_op_243021));
    V v_b_243024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_242959, v_e_243022}));
    V v_t_243025 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str158)}), v_b_243024));
    return (g_std_2edoc_2e_3c_3e(v_a_243023, v_t_243025));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242959;
    args[1] = v_r_242960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242960);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam131(V self, V *args) {
  V v_r_243133 = args[0];
  V v_env_243120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243134 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_243133));
  V v_t_243135;
  if ((heff_dup(v_x1_243134) == NTAG(TAG_True))) {
    heff_drop(v_x1_243134);
    v_t_243135 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_243134);
    v_t_243135 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_243136 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_243120, v_r_243133}));
  return (g_std_2edoc_2e_3c_3e(v_t_243135, v_t_243136));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam132(V self, V *args) {
  V v_r_243142 = args[0];
  V v_env_243120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243143 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_243142));
  V v_t_243144;
  if ((heff_dup(v_x1_243143) == NTAG(TAG_True))) {
    heff_drop(v_x1_243143);
    v_t_243144 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_243143);
    v_t_243144 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_243145 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_243120, v_r_243142}));
  return (g_std_2edoc_2e_3c_3e(v_t_243144, v_t_243145));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args) {
  V v_env_243120 = args[0];
  V v_first_243121 = args[1];
  V v_rest_243122 = args[2];
  V v_f_243123 = heff_dup(heff_rfield(v_env_243120, 6));
  HeffT2 v_t_243124 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_243123), heff_dup(v_rest_243122)));
  {
    V v_field_243126 = v_t_243124.f[1];
    int64_t v_tag_243125 = ((int64_t)v_t_243124.f[0]);
    V v_t_243131;
    if ((v_tag_243125 == ((int64_t)0ULL))) {
      V v_it1_243128 = v_field_243126;
      switch (heff_tag_of(v_it1_243128)) {
      case TAG_Nil: {
        heff_drop(v_f_243123);
        v_t_243131 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_243129 = heff_field(v_it1_243128, 0);
        V v_os_243130 = heff_field(v_it1_243128, 1);
        heff_take_n(v_it1_243128, 3ULL, 2);
        v_t_243131 = ({ V a_0 = v_f_243123; V a_1 = v_o_243129; V a_2 = v_os_243130; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_243130); r_; });
        break;
      }
      default: heff_nomatch(v_it1_243128);
      }
    } else {
      heff_drop(v_f_243123);
      heff_drop(v_field_243126);
      v_t_243131 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_243131)) {
    case TAG_Nothing: {
      V v_t_243132 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243120), v_first_243121}));
      V v_t_243137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam131, 1, 1, (V[]){v_env_243120}); V a_2 = v_rest_243122; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_243122); r_; });
      V v_t_243138 = (g_std_2edoc_2e_3c_3e(v_t_243132, v_t_243137));
      return (g_std_2edoc_2egroup(v_t_243138));
    }
    case TAG_Just: {
      V v_m_243139 = heff_field(v_t_243131, 0);
      heff_take_n(v_t_243131, 1ULL, 1);
      V v_t_243140 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_243120, 6)), heff_dup(v_m_243139), v_rest_243122));
      if ((heff_dup(v_t_243140) == NTAG(TAG_True))) {
        heff_drop(v_m_243139);
        heff_drop(v_t_243140);
        V v_t_243141 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243120), v_first_243121}));
        V v_t_243146 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam132, 1, 1, (V[]){v_env_243120}); V a_2 = v_rest_243122; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_243122); r_; });
        V v_t_243147 = (g_std_2edoc_2e_3c_3e(v_t_243141, v_t_243146));
        return (g_std_2edoc_2egroup(v_t_243147));
      } else {
        heff_drop(v_t_243140);
        V v_t_243148 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_243120, v_m_243139, v_first_243121, NTAG(TAG_Nil), v_rest_243122}));
        return (g_std_2edoc_2egroup(v_t_243148));
      }
    }
    default: return heff_nomatch(v_t_243131);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam133(V self, V *args) {
  V v_env_243149 = args[0];
  V v_m_243150 = args[1];
  V v_f_243151 = args[2];
  V v_acc_243152 = args[3];
  V v_rs_243153 = args[4];
  switch (heff_tag_of(v_rs_243153)) {
  case TAG_Nil: {
    heff_drop(v_m_243150);
    V v_t_243154 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243152));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_243149;
    args[1] = v_f_243151;
    args[2] = v_t_243154;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_243155 = heff_field(v_rs_243153, 0);
    V v_rest2_243156 = heff_field(v_rs_243153, 1);
    heff_take_n(v_rs_243153, 3ULL, 2);
    switch (heff_tag_of(v_r_243155)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETilde: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_243217 = heff_dup(heff_field(v_r_243155, 0));
      V v_e_243218 = heff_dup(heff_field(v_r_243155, 1));
      V v_t_243219 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_243149, 6)), heff_dup(v_m_243150), heff_dup(heff_rfield(v_op_243217, 1))));
      switch (heff_tag_of(v_t_243219)) {
      case TAG_Tighter: {
        heff_drop_rec(v_op_243217, 9);
        heff_drop(v_e_243218);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243149;
        args[1] = v_m_243150;
        args[2] = v_f_243151;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
        args[4] = v_rest2_243156;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Looser: {
        heff_drop_rec(v_op_243217, 9);
        heff_drop(v_e_243218);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243149;
        args[1] = v_m_243150;
        args[2] = v_f_243151;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
        args[4] = v_rest2_243156;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Same: {
        V v_ru_24t_243219_24Same = heff_take_reuse_n(v_t_243219, 0ULL, 1);
        V v_t_243221 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243152));
        V v_t_243222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_243149), v_f_243151, v_t_243221}));
        V v_x1_243223 = ({ V a_0 = v_r_243155; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_243155, 2); r_; });
        V v_t_243224;
        if ((heff_dup(v_x1_243223) == NTAG(TAG_True))) {
          heff_drop(v_x1_243223);
          v_t_243224 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_243223);
          v_t_243224 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_243225 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243149), v_op_243217));
        V v_b_243226 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_243149, v_m_243150, v_e_243218, NTAG(TAG_Nil), v_rest2_243156}));
        V v_t_243227 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_243219_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str159)}), v_b_243226));
        V v_t_243228 = (g_std_2edoc_2e_3c_3e(v_a_243225, v_t_243227));
        V v_t_243229 = (g_std_2edoc_2e_3c_3e(v_t_243224, v_t_243228));
        return (g_std_2edoc_2e_3c_3e(v_t_243222, v_t_243229));
      }
      case TAG_Unrelated: {
        heff_drop_rec(v_op_243217, 9);
        heff_drop(v_e_243218);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243149;
        args[1] = v_m_243150;
        args[2] = v_f_243151;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
        args[4] = v_rest2_243156;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_243219, 0ULL, 1);
        heff_drop_rec(v_op_243217, 9);
        heff_drop(v_e_243218);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243149;
        args[1] = v_m_243150;
        args[2] = v_f_243151;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
        args[4] = v_rest2_243156;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_243219);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BPat: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetElse: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetMut: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAssign: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWhile: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFor: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EJump: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EReturn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENest: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EArrow: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_IfThen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETry: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECatch: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWith: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243149;
      args[1] = v_m_243150;
      args[2] = v_f_243151;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243155, v_acc_243152});
      args[4] = v_rest2_243156;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_243155);
    }
  }
  default: return heff_nomatch(v_rs_243153);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam134(V self, V *args) {
  V v_env_243325 = args[0];
  V v_a_243326 = args[1];
  switch (heff_tag_of(v_a_243326)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_243410 = heff_field(v_a_243326, 0);
    V v_arrow_243411 = heff_field(v_a_243326, 1);
    V v_body_243412 = heff_field(v_a_243326, 2);
    heff_take_n(v_a_243326, 7ULL, 3);
    V v_a_243413 = ({ V a_0 = heff_dup(v_env_243325); V a_1 = v_p_243410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_243410); r_; });
    V v_b_243414 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243325), v_arrow_243411));
    V v_t_243415 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str160)}), v_b_243414));
    V v_t_243416 = (g_std_2edoc_2e_3c_3e(v_a_243413, v_t_243415));
    V v_t_243417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243325, v_body_243412}));
    return (g_std_2edoc_2e_3c_3e(v_t_243416, v_t_243417));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243325;
    args[1] = v_a_243326;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_243326);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam135(V self, V *args) {
  V v_env_243488 = args[0];
  V v_s_243489 = args[1];
  switch (heff_tag_of(v_s_243489)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V v_d_243582 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_243488, v_s_243489}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_243582});
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_243585 = heff_field(v_s_243489, 0);
    V v_arrow_243586 = heff_field(v_s_243489, 1);
    V v_e_243587 = heff_field(v_s_243489, 2);
    heff_take_n(v_s_243489, 7ULL, 3);
    V v_a_243588 = ({ V a_0 = heff_dup(v_env_243488); V a_1 = v_x_243585; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_243585); r_; });
    V v_b_243589 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243488), v_arrow_243586));
    V v_t_243590 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str161)}), v_b_243589));
    V v_t_243591 = (g_std_2edoc_2e_3c_3e(v_a_243588, v_t_243590));
    V v_t_243592 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243488, v_e_243587}));
    return (g_std_2edoc_2e_3c_3e(v_t_243591, v_t_243592));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V v_d_243638 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_243488, v_s_243489}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_243638});
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243488;
    args[1] = v_s_243489;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_243489);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam136(V self, V *args) {
  V v_env_243653 = args[0];
  V v_f_243654 = args[1];
  switch (heff_tag_of(v_f_243654)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_243681 = heff_field(v_f_243654, 0);
    V v_eq_243682 = heff_field(v_f_243654, 1);
    V v_e_243683 = heff_field(v_f_243654, 2);
    heff_take_n(v_f_243654, 7ULL, 3);
    V v_a_243684 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243653), v_x_243681}));
    V v_b_243685 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243653), v_eq_243682));
    V v_t_243686 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str162)}), v_b_243685));
    V v_t_243687 = (g_std_2edoc_2e_3c_3e(v_a_243684, v_t_243686));
    V v_t_243688 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243653, v_e_243683}));
    return (g_std_2edoc_2e_3c_3e(v_t_243687, v_t_243688));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_243694 = heff_field(v_f_243654, 0);
    V v_eq_243695 = heff_field(v_f_243654, 1);
    V v_e_243696 = heff_field(v_f_243654, 2);
    heff_take_n(v_f_243654, 7ULL, 3);
    V v_a_243697 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243653), v_x_243694));
    V v_b_243698 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243653), v_eq_243695));
    V v_t_243699 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str163)}), v_b_243698));
    V v_t_243700 = (g_std_2edoc_2e_3c_3e(v_a_243697, v_t_243699));
    V v_t_243701 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243653, v_e_243696}));
    return (g_std_2edoc_2e_3c_3e(v_t_243700, v_t_243701));
  }
  case TAG_EFDefault: {
    V v_d_243702 = heff_field(v_f_243654, 0);
    V v_eq_243703 = heff_field(v_f_243654, 1);
    V v_e_243704 = heff_field(v_f_243654, 2);
    heff_take_n(v_f_243654, 7ULL, 3);
    V v_a_243705 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243653), v_d_243702}));
    V v_b_243706 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243653), v_eq_243703));
    V v_t_243707 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str164)}), v_b_243706));
    V v_t_243708 = (g_std_2edoc_2e_3c_3e(v_a_243705, v_t_243707));
    V v_t_243709 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243653, v_e_243704}));
    return (g_std_2edoc_2e_3c_3e(v_t_243708, v_t_243709));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EArrow: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243653;
    args[1] = v_f_243654;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_243654);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = heff_take_field(v_t_244, 7); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2412;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = heff_get_n(v_t_244, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop_rec(v_t_244, 9);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_247);
        v_t_2412 = heff_get_n(v_t_244, 8, 9);
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0, 7, "doctest");
Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DFixity: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DSig: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DInstance: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DEqn: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DData: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DType: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTheory: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DMutual: {
    V v_ds_2434 = heff_field(v_d_241, 1);
    V v_x1_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ds_2434)));
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 7);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x1_2435, 0);
      heff_take_n(v_x1_2435, 1ULL, 2);
      switch (heff_tag_of(v_x_2436)) {
      case TAG_DImport: {
        heff_take_n(v_x_2436, 0ULL, 1);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DFixity: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DSig: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DInstance: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DEqn: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DData: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DType: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTheory: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DMutual: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DPrimitive: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTest: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DWatch: {
        V v_w_2477 = heff_field(v_x_2436, 0);
        V v_e_2478 = heff_field(v_x_2436, 1);
        heff_take_n(v_x_2436, 3ULL, 2);
        V v_t_2479 = heff_strEq(heff_get_n(v_w_2477, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0));
        V v_t_2480 = (g_heff_2esyntax_2ecst_2elastE(v_e_2478));
        V v_t_2481 = heff_intAdd(heff_get_n(v_t_2480, 7, 9), MK_INT(1LL));
        HeffT2 v_t_2482 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_t_2481; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2487;
        {
          V v_field_2484 = v_t_2482.f[1];
          int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
          if ((v_tag_2483 == ((int64_t)0ULL))) {
            V v_x_2486 = v_field_2484;
            v_t_2487 = v_x_2486;
          } else {
            heff_drop(v_field_2484);
            v_t_2487 = NTAG(TAG_Nil);
          }
        }
        return ({ V a_0 = v_t_2479; V a_1 = v_t_2487; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines(a_0, a_1)); heff_drop(v_t_2479); r_; });
      }
      default: return heff_nomatch(v_x_2436);
      }
    }
    default: return heff_nomatch(v_x1_2435);
    }
  }
  case TAG_DPrimitive: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTest: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DWatch: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eblockExpect(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_get_n(v_eof_243, 7, 9)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_247);
        v_t_2410 = NTAG(TAG_Nil);
      }
    }
    return ({ V a_0 = v_env_240; V a_1 = v_t_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_2410); r_; });
  }
  case TAG_Cons: {
    V v_d_2411 = heff_field(v_x5_244, 0);
    V v_ds_2412 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2411));
    V v_t_2455;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_DImport: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2453 = heff_dup(heff_field(v_d_2411, 0));
      v_t_2455 = heff_strEq(heff_get_n(v_w_2453, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    V v_t_2483;
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2455);
      V v_t_2456 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
      V v_t_2457 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
      V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2456, v_t_2457, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2411)})));
      V v_t_2460 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2411); r_; });
      V v_t_2461 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2460, v_eof_243, v_ds_2412));
      v_t_2483 = (g_std_2edoc_2e_3c_3e(v_t_2459, v_t_2461));
    } else {
      heff_drop(v_t_2455);
      V v_t_2462 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2462);
        V v_t_2463 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2411));
        V v_t_2465 = ({ V a_0 = v_t_2464; V a_1 = heff_dup(v_d_2411); V a_2 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2464); r_; });
        V v_t_2466 = (g_heff_2esyntax_2ecst_2elastD(v_t_2465));
        V v_t_2467 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2463, v_t_2466));
        V v_t_2468 = ({ V a_0 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2411); r_; });
        V v_t_2469 = ({ V a_0 = v_t_2468; V a_1 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2468); r_; });
        V v_t_2470 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2469));
        v_t_2483 = (g_std_2edoc_2e_3c_3e(v_t_2467, v_t_2470));
      } else {
        heff_drop(v_t_2462);
        V v_expect_2471 = (g_heff_2esyntax_2efmt_2elayout_2eblockExpect(heff_dup(v_env_240), v_d_2411));
        V v_t_2472 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2473 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
        V v_t_2475 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2472, v_t_2473, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2411)})));
        V v_d_2476 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_2471));
        V v_t_2477 = (g_heff_2esyntax_2ecst_2elastD(v_d_2411));
        V v_t_2478 = heff_intAdd(heff_get_n(v_t_2477, 7, 9), MK_INT(1LL));
        V v_t_2479 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_2471; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_2471); r_; });
        V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2eleadLaid(v_env_240, v_t_2478, v_t_2479));
        V v_t_2481 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_2480, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2412));
        V v_t_2482 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2476}), v_t_2481));
        v_t_2483 = (g_std_2edoc_2e_3c_3e(v_t_2475, v_t_2482));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2483));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2458 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2458; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2474 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2474; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V v_f_240, V v_src_241, V v_claim_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    V v_t_245 = (g_heff_2esyntax_2efmt_2eimports_2eexposingToks(heff_rfield(v_claim_242, 1)));
    V v_t_246 = (g_list_2emap_24s1845612977x612508518(heff_get_n(v_claim_242, 0, 3)));
    V v_t_247 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_take_field(v_l_243, 0), v_t_245, v_t_246));
    V v_t_248 = (g_list_2esortBy_24s88152486x2058486153(v_t_247));
    HeffT2 v_t_249 = (g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(v_src_241, v_t_248, heff_get_n(v_l_243, 2, 3)));
    V v_t_2413;
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_t_2412 = ({ V rv_6 = v_f_240; V rr_ = heff_rec_reuse_nf(v_field_2411, 63ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
      v_t_2413 = heff_rec_n(2, shape_toks__env, (V[]){v_field_2410, v_t_2412});
    }
    return (g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(v_t_2413));
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_claim_242, 3);
    heff_drop_rec(v_l_243, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_244)}});
  }
}