// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define LBL_body 9524841
#define LBL_entry 298026124
#define LBL_key 315609
#define LBL_lent 9813446
#define LBL_params 951713969
#define LBL_read 9991773
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_tested 1069972444
#define LBL_wrapper 1827365593
static uint32_t shape_key__params__lent__entry__body__reprs__ret__wrapper[] = {LBL_key, LBL_params, LBL_lent, LBL_entry, LBL_body, LBL_reprs, LBL_ret, LBL_wrapper};
V g_heff_2ecompile_2ebounds_2eallOf(V);
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eallOf_clo;
V g_heff_2ecompile_2ebounds_2eboundsDef(V);
V g_heff_2ecompile_2ebounds_2eboundsDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eboundsDef_clo;
V g_heff_2ecompile_2ebounds_2eboundsWith(V, V, V);
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo;
V g_heff_2ecompile_2ebounds_2echeckOf(V);
V g_heff_2ecompile_2ebounds_2echeckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2echeckOf_clo;
V g_heff_2ecompile_2ebounds_2echeckedWith(V, V, V);
V g_heff_2ecompile_2ebounds_2echeckedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2echeckedWith_clo;
V g_heff_2ecompile_2ebounds_2eelemS(V, V);
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eelemS_clo;
V g_heff_2ecompile_2ebounds_2efixStmts(V, V, V);
V g_heff_2ecompile_2ebounds_2efixStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixStmts_clo;
HeffT2 g_heff_2ecompile_2ebounds_2egivenTo_24cpr(V, V);
V g_heff_2ecompile_2ebounds_2eindexOf(V);
V g_heff_2ecompile_2ebounds_2eindexOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eindexOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eindexOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2eindices(V, V, V);
V g_heff_2ecompile_2ebounds_2eindices_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eindices_clo;
V g_heff_2ecompile_2ebounds_2ekept(V, V, V);
V g_heff_2ecompile_2ebounds_2ekept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2ekept_clo;
V g_heff_2ecompile_2ebounds_2elabel_get(void);
HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V);
HeffT2 g_heff_2ecompile_2ebounds_2elengthOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2elongEnough(V);
V g_heff_2ecompile_2ebounds_2elongEnough_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elongEnough_clo;
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(V, V, V);
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eneedAt_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2enubS(V, V);
V g_heff_2ecompile_2ebounds_2enubS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2enubS_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eownNeed_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erangeTest_24cpr(V, V);
HeffT2 g_heff_2ecompile_2ebounds_2erelTest_24cpr(V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs(V, V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2esameAs_clo;
V g_heff_2ecompile_2ebounds_2escoped(V, V, V);
V g_heff_2ecompile_2ebounds_2escoped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2escoped_clo;
V g_heff_2ecompile_2ebounds_2escopedSt(V, V, V, V);
V g_heff_2ecompile_2ebounds_2escopedSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2escopedSt_clo;
V g_heff_2ecompile_2ebounds_2estepOf(V, V);
V g_heff_2ecompile_2ebounds_2estepOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2estepOf_clo;
V g_heff_2ecompile_2ebounds_2eunchecked(V, V, V);
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eunchecked_clo;
V g_heff_2ecompile_2ebounds_2evarOf(V);
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2evarOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2evarOf_24cpr(V);
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1241151012x1129179210(V, V, V);
V g_list_2efoldl_24f1241151012x1129179210_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1241151012x1129179210_clo;
V g_list_2efoldl_24f428710765x1902475677(V, V, V);
V g_list_2efoldl_24f428710765x1902475677_entry(V self, V *a);
extern Clo g_list_2efoldl_24f428710765x1902475677_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1845523271x872922214(V, V, V);
V g_list_2efoldl_24s1845523271x872922214_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1845523271x872922214_clo;
V g_list_2efoldl_24s1922266401x1990263591(V, V);
V g_list_2efoldl_24s1922266401x1990263591_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1922266401x1990263591_clo;
V g_list_2efoldl_24s2015232937x23400545(V, V);
V g_list_2efoldl_24s2015232937x23400545_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2015232937x23400545_clo;
V g_list_2efoldl_24s345718350x1678852400(V, V);
V g_list_2efoldl_24s345718350x1678852400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s345718350x1678852400_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s176481989x1398310082(V, V);
V g_list_2ekeepIf_24s176481989x1398310082_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s176481989x1398310082_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1221888634x716224461(V, V);
V g_list_2emap_24f1221888634x716224461_entry(V self, V *a);
extern Clo g_list_2emap_24f1221888634x716224461_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1353477632x1698603588(V);
V g_list_2emap_24s1353477632x1698603588_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_clo;
V g_list_2emap_24s1440555322x1057233214(V, V, V, V);
V g_list_2emap_24s1440555322x1057233214_entry(V self, V *a);
extern Clo g_list_2emap_24s1440555322x1057233214_clo;
V g_list_2emap_24s1700608285x1639860354(V);
V g_list_2emap_24s1700608285x1639860354_entry(V self, V *a);
extern Clo g_list_2emap_24s1700608285x1639860354_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s215892288x1392224072(V, V);
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

HeffT2 g_heff_2ecompile_2ebounds_2evarOf_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_RLocal: {
    V v_x_241 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_241}});
  }
  case TAG_RDup: {
    V v_x_242 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
  }
  case TAG_RClo: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    heff_take_n(v_e_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    heff_take_n(v_e_240, 0ULL, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    heff_take_n(v_e_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    heff_take_n(v_e_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RLam: {
    heff_take_n(v_e_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    heff_take_n(v_e_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    heff_take_n(v_e_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    heff_take_n(v_e_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    heff_take_na(v_e_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
V g_heff_2ecompile_2ebounds_2eindices_lam1(V self, V *args);
V g_heff_2ecompile_2ebounds_2eindices_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eindices_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eindices_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eindices(V v_f_240, V v_ds_241, V v_ags_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_ags_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ag_243 = heff_field(v_ags_242, 0);
    v_t_245 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_ag_243)));
    break;
  }
  default: heff_nomatch(v_ags_242);
  }
  return (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ebounds_2eindices_lam0, 1, 3, (V[]){v_f_240, v_ds_241, heff_dup(v_ags_242)}), v_t_245));
}
V g_heff_2ecompile_2ebounds_2eindices_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ebounds_2eindices(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ebounds_2eindices_lam1(V self, V *args) {
  V v_ag_2415 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = (g_heff_2ecompile_2ebounds_2egivenTo_24cpr(v_x_246, v_ag_2415));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2418;
      return ({ V a_0 = v_x_246; V a_1 = v_x_2420; V r_ = (g_heff_2ecompile_2ebounds_2estepOf(a_0, a_1)); heff_drop(v_x_246); r_; });
    } else {
      heff_drop(v_x_246);
      heff_drop(v_field_2418);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2ebounds_2eindices_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_ds_241 = heff_env(self)[1];
  V v_ags_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_f_240, 5, 8); V a_1 = v_x_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_249;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_RepV: {
        heff_drop(v_x_246);
        heff_drop(v_ds_241);
        heff_drop(v_ags_242);
        return NTAG(TAG_False);
      }
      case TAG_RepFix: {
        heff_take_n(v_x_2411, 0ULL, 1);
        heff_drop(v_x_246);
        heff_drop(v_ds_241);
        heff_drop(v_ags_242);
        return NTAG(TAG_False);
      }
      case TAG_RepF64: {
        heff_drop(v_x_246);
        heff_drop(v_ds_241);
        heff_drop(v_ags_242);
        return NTAG(TAG_False);
      }
      case TAG_RepInt: {
        V v_t_2413 = (g_list_2ekeepIf_24s176481989x1398310082(v_x_246, v_ds_241));
        V v_x1_2414 = (g_list_2emap_24s1173914895x100384474(v_t_2413));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nil: {
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eindices_lam1, 1, 1, (V[]){v_x_246}); V a_1 = v_ags_242; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_ags_242); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2414, 0ULL, 2);
          heff_drop(v_x_246);
          heff_drop(v_ags_242);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x1_2414);
        }
      }
      default: return heff_nomatch(v_x_2411);
      }
    } else {
      heff_drop(v_x_246);
      heff_drop(v_ds_241);
      heff_drop(v_ags_242);
      heff_drop(v_field_249);
      return NTAG(TAG_False);
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2esameAs_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2ebounds_2esameAs_str1, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2ebounds_2esameAs_str2, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2ebounds_2esameAs_str3, 13, "arraySetOwned");
Clo g_heff_2ecompile_2ebounds_2esameAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2esameAs_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2esameAs(V v_ds_240, V v_seen_241, V v_b_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_RLocal: {
    V v_y_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_244, v_b_242, 0)) {
      heff_drop(v_ds_240);
      heff_drop(v_seen_241);
      heff_drop(v_b_242);
      heff_drop(v_y_244);
      return NTAG(TAG_True);
    } else {
      V v_x1_246 = (g_heff_2ecompile_2ebounds_2eelemS(v_y_244, v_seen_241));
      if ((heff_dup(v_x1_246) == NTAG(TAG_True))) {
        heff_drop(v_ds_240);
        heff_drop(v_seen_241);
        heff_drop(v_b_242);
        heff_drop(v_y_244);
        heff_drop(v_x1_246);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_x1_246);
        V v_t_247 = (g_list_2ekeepIf_24s176481989x1398310082(v_y_244, heff_dup(v_ds_240)));
        V v_x1_248 = (g_list_2emap_24s1173914895x100384474(v_t_247));
        switch (heff_tag_of(v_x1_248)) {
        case TAG_Nil: {
          heff_drop(v_ds_240);
          heff_drop(v_seen_241);
          heff_drop(v_b_242);
          heff_drop(v_y_244);
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          heff_take_n(v_x1_248, 0ULL, 2);
          V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){heff_dup(v_ds_240), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_244), v_seen_241}), v_b_242}));
          V v_t_2412 = ({ V a_0 = v_y_244; V a_1 = v_ds_240; V r_ = (g_list_2ekeepIf_24s176481989x1398310082(a_0, a_1)); heff_drop(v_y_244); r_; });
          V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_t_2412));
          return ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2413); r_; });
        }
        default: return heff_nomatch(v_x1_248);
        }
      }
    }
  }
  case TAG_RDup: {
    V v_y_2414 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24RDup = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V t_0 = v_ds_240;
    V t_1 = v_seen_241;
    V t_2 = v_b_242;
    V t_3 = heff_tag_at_n(v_ru_24e_243_24RDup, TAG_RLocal, 1, (V[]){v_y_2414});
    v_ds_240 = t_0;
    v_seen_241 = t_1;
    v_b_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_RClo: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    heff_take_n(v_e_243, 0ULL, 3);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    heff_take_n(v_e_243, 0ULL, 3);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    heff_take_n(v_e_243, 0ULL, 8);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    heff_take_n(v_e_243, 0ULL, 3);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    heff_take_n(v_e_243, 0ULL, 5);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    V v_p_2468 = heff_field(v_e_243, 0);
    V v_es_2469 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_p_2468, ((V)&g_heff_2ecompile_2ebounds_2esameAs_str0), 2)) {
      heff_drop(v_p_2468);
      V v_f_2471 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2469)) {
      case TAG_Nil: {
        heff_drop(v_f_2471);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_2472 = heff_field(v_es_2469, 0);
        heff_take_n(v_es_2469, 1ULL, 2);
        return heff_tail(v_f_2471, 1, (V[]){v_x_2472});
      }
      default: return heff_nomatch(v_es_2469);
      }
    } else {
      if (heff_strEq_c(v_p_2468, ((V)&g_heff_2ecompile_2ebounds_2esameAs_str1))) {
        V v_f_2475 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
        switch (heff_tag_of(v_es_2469)) {
        case TAG_Nil: {
          heff_drop(v_f_2475);
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_x_2476 = heff_field(v_es_2469, 0);
          heff_take_n(v_es_2469, 1ULL, 2);
          return heff_tail(v_f_2475, 1, (V[]){v_x_2476});
        }
        default: return heff_nomatch(v_es_2469);
        }
      } else {
        heff_drop(v_ds_240);
        heff_drop(v_seen_241);
        heff_drop(v_b_242);
        heff_drop(v_es_2469);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RLam: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    V v_p_2497 = heff_field(v_e_243, 0);
    V v_es_2499 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 5ULL, 3);
    if (heff_strEq_c_lent(v_p_2497, ((V)&g_heff_2ecompile_2ebounds_2esameAs_str2), 2)) {
      heff_drop(v_p_2497);
      V v_f_24101 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2499)) {
      case TAG_Nil: {
        heff_drop(v_f_24101);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_24102 = heff_field(v_es_2499, 0);
        heff_take_n(v_es_2499, 1ULL, 2);
        return heff_tail(v_f_24101, 1, (V[]){v_x_24102});
      }
      default: return heff_nomatch(v_es_2499);
      }
    } else {
      if (heff_strEq_c(v_p_2497, ((V)&g_heff_2ecompile_2ebounds_2esameAs_str3))) {
        V v_f_24105 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
        switch (heff_tag_of(v_es_2499)) {
        case TAG_Nil: {
          heff_drop(v_f_24105);
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_x_24106 = heff_field(v_es_2499, 0);
          heff_take_n(v_es_2499, 1ULL, 2);
          return heff_tail(v_f_24105, 1, (V[]){v_x_24106});
        }
        default: return heff_nomatch(v_es_2499);
        }
      } else {
        heff_drop(v_ds_240);
        heff_drop(v_seen_241);
        heff_drop(v_b_242);
        heff_drop(v_es_2499);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RFixU: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2ebounds_2esameAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2esameAs(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ebounds_2ekept_lam1(V self, V *args);
V g_heff_2ecompile_2ebounds_2ekept_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2ekept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2ekept_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2ekept(V v_f_240, V v_ds_241, V v_ags_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_ags_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ag_243 = heff_field(v_ags_242, 0);
    v_t_245 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_ag_243)));
    break;
  }
  default: heff_nomatch(v_ags_242);
  }
  return (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ebounds_2ekept_lam0, 1, 2, (V[]){v_ds_241, heff_dup(v_ags_242)}), v_t_245));
}
V g_heff_2ecompile_2ebounds_2ekept_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ebounds_2ekept(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ebounds_2ekept_lam1(V self, V *args) {
  V v_ag_249 = args[0];
  V v_b_246 = heff_env(self)[0];
  V v_ds_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = (g_heff_2ecompile_2ebounds_2egivenTo_24cpr(v_b_246, v_ag_249));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2412;
      return (g_heff_2ecompile_2ebounds_2esameAs(v_ds_241, NTAG(TAG_Nil), v_b_246, v_x_2414));
    } else {
      heff_drop(v_b_246);
      heff_drop(v_ds_241);
      heff_drop(v_field_2412);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2ebounds_2ekept_lam0(V self, V *args) {
  V v_b_246 = args[0];
  V v_ds_241 = heff_env(self)[0];
  V v_ags_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_list_2ekeepIf_24s176481989x1398310082(v_b_246, heff_dup(v_ds_241)));
  V v_x1_248 = (g_list_2emap_24s1173914895x100384474(v_t_247));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2ekept_lam1, 1, 2, (V[]){v_b_246, v_ds_241}); V a_1 = v_ags_242; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_ags_242); r_; });
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    heff_drop(v_b_246);
    heff_drop(v_ds_241);
    heff_drop(v_ags_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}

HeffT2 g_heff_2ecompile_2ebounds_2elengthOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    heff_take_n(v_x1_240, 0ULL, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RLam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    V v_x11_2471 = heff_field(v_x1_240, 0);
    V v_e_2472 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_RepV: {
      heff_drop(v_e_2472);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepFix: {
      heff_take_n(v_x11_2471, 0ULL, 1);
      heff_drop(v_e_2472);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepF64: {
      heff_drop(v_e_2472);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepInt: {
      HEFF_LAST return g_heff_2ecompile_2ebounds_2elengthArray_24cpr(v_e_2472);
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2471)}});
    }
  }
  case TAG_RPeek: {
    V v_x11_2474 = heff_field(v_x1_240, 0);
    V v_e_2475 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_2474)) {
    case TAG_RepV: {
      heff_drop(v_e_2475);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepFix: {
      heff_take_n(v_x11_2474, 0ULL, 1);
      heff_drop(v_e_2475);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepF64: {
      heff_drop(v_e_2475);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepInt: {
      HEFF_LAST return g_heff_2ecompile_2ebounds_2elengthArray_24cpr(v_e_2475);
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2474)}});
    }
  }
  case TAG_RPrimU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2ebounds_2erangeTest_24cpr(V v_info_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_CondFalse: {
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_CondRel: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_CondRelU: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return ({ V a_0 = v_info_240; V a_1 = v_p_244; V a_2 = v_es_245; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2erelTest_24cpr(a_0, a_1, a_2)); heff_drop(v_p_244); r_; });
  }
  case TAG_CondBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_CondNot: {
    V v_c_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_248 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(v_info_240, v_c_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x11_2412 = v_field_2410;
        switch (heff_tag_of(v_x11_2412)) {
        case TAG_MkPair: {
          V v_r_2413 = heff_field(v_x11_2412, 0);
          V v_yes_2414 = heff_field(v_x11_2412, 1);
          V v_ru_24x11_2412_24MkPair = heff_take_reuse_n(v_x11_2412, 3ULL, 2);
          V v_t_2415 = heff_bool(!(heff_dup(v_yes_2414) == NTAG(TAG_True)));
          heff_drop(v_yes_2414);
          V v_f_2416 = heff_tag_at_n(v_ru_24x11_2412_24MkPair, TAG_MkPair, 2, (V[]){v_r_2413, v_t_2415});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
        }
      } else {
        heff_drop(v_field_2410);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_CondIf: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_CondLet: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_info_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2eindexOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eindexOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2eindexOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ebounds_2eindexOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2eindexOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eindexOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2eneedAt_24cpr_str0, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eneedAt_24cpr_str1, 13, "arraySetOwned");
HEFF_LIT(g_heff_2ecompile_2ebounds_2eneedAt_24cpr_str2, 9, "arrayPeek");

HeffT2 g_heff_2ecompile_2ebounds_2eneedAt_24cpr(V v_info_240, V v_env_241, V v_p_242, V v_fl_243, V v_es_244) {
top: ;
  if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2ebounds_2eneedAt_24cpr_str0), 2)) {
    switch (heff_tag_of(v_es_244)) {
    case TAG_Nil: {
      heff_drop(v_info_240);
      heff_drop(v_env_241);
      heff_drop(v_fl_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_246 = heff_field(v_es_244, 0);
      V v_es2_247 = heff_field(v_es_244, 1);
      heff_take_n(v_es_244, 3ULL, 2);
      switch (heff_tag_of(v_es2_247)) {
      case TAG_Nil: {
        heff_drop(v_info_240);
        heff_drop(v_env_241);
        heff_drop(v_fl_243);
        heff_drop(v_a_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_i_248 = heff_field(v_es2_247, 0);
        heff_take_n(v_es2_247, 1ULL, 2);
        V v_t_2410 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_246));
        V v_t_2411 = (g_heff_2ecompile_2ebounds_2eindexOf(v_i_248));
        HEFF_LAST return g_heff_2ecompile_2ebounds_2eneedOf_24cpr(v_info_240, v_env_241, v_fl_243, v_t_2410, v_t_2411);
      }
      default: return ((HeffT2){{heff_nomatch(v_es2_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_es_244)}});
    }
  } else {
    if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2ebounds_2eneedAt_24cpr_str1), 2)) {
      switch (heff_tag_of(v_es_244)) {
      case TAG_Nil: {
        heff_drop(v_info_240);
        heff_drop(v_env_241);
        heff_drop(v_fl_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_a_2413 = heff_field(v_es_244, 0);
        V v_es2_2414 = heff_field(v_es_244, 1);
        heff_take_n(v_es_244, 3ULL, 2);
        switch (heff_tag_of(v_es2_2414)) {
        case TAG_Nil: {
          heff_drop(v_info_240);
          heff_drop(v_env_241);
          heff_drop(v_fl_243);
          heff_drop(v_a_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_i_2415 = heff_field(v_es2_2414, 0);
          heff_take_n(v_es2_2414, 1ULL, 2);
          V v_t_2417 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_2413));
          V v_t_2418 = (g_heff_2ecompile_2ebounds_2eindexOf(v_i_2415));
          HEFF_LAST return g_heff_2ecompile_2ebounds_2eneedOf_24cpr(v_info_240, v_env_241, v_fl_243, v_t_2417, v_t_2418);
        }
        default: return ((HeffT2){{heff_nomatch(v_es2_2414)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_es_244)}});
      }
    } else {
      if (heff_strEq_c_lent(v_p_242, ((V)&g_heff_2ecompile_2ebounds_2eneedAt_24cpr_str2), 2)) {
        switch (heff_tag_of(v_es_244)) {
        case TAG_Nil: {
          heff_drop(v_info_240);
          heff_drop(v_env_241);
          heff_drop(v_fl_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_a_2420 = heff_field(v_es_244, 0);
          V v_es2_2421 = heff_field(v_es_244, 1);
          heff_take_n(v_es_244, 3ULL, 2);
          switch (heff_tag_of(v_es2_2421)) {
          case TAG_Nil: {
            heff_drop(v_info_240);
            heff_drop(v_env_241);
            heff_drop(v_fl_243);
            heff_drop(v_a_2420);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_i_2422 = heff_field(v_es2_2421, 0);
            heff_take_n(v_es2_2421, 1ULL, 2);
            V v_t_2424 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_2420));
            V v_t_2425 = (g_heff_2ecompile_2ebounds_2eindexOf(v_i_2422));
            HEFF_LAST return g_heff_2ecompile_2ebounds_2eneedOf_24cpr(v_info_240, v_env_241, v_fl_243, v_t_2424, v_t_2425);
          }
          default: return ((HeffT2){{heff_nomatch(v_es2_2421)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_es_244)}});
        }
      } else {
        heff_drop(v_info_240);
        heff_drop(v_env_241);
        heff_drop(v_fl_243);
        heff_drop(v_es_244);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2eownNeed_24cpr_str0, 10, "arrayIndex");

HeffT2 g_heff_2ecompile_2ebounds_2eownNeed_24cpr(V v_info_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_RLocal: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    heff_take_n(v_e_242, 0ULL, 8);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    heff_take_n(v_e_242, 0ULL, 3);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    heff_take_n(v_e_242, 0ULL, 5);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    V v_p_2458 = heff_field(v_e_242, 0);
    V v_es_2459 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    return ({ V a_0 = v_info_240; V a_1 = v_env_241; V a_2 = v_p_2458; V a_3 = NTAG(TAG_Nothing); V a_4 = v_es_2459; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_2458); r_; });
  }
  case TAG_RLam: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    heff_take_n(v_e_242, 0ULL, 4);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    heff_take_n(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    V v_p_2479 = heff_field(v_e_242, 0);
    V v_r_2480 = heff_field(v_e_242, 1);
    V v_es_2481 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2484;
    switch (heff_tag_of(v_r_2480)) {
    case TAG_RepV: {
      v_t_2484 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_RepFix: {
      V v_w_2482 = heff_field(v_r_2480, 0);
      V v_ru_24r_2480_24RepFix = heff_take_reuse_n(v_r_2480, 1ULL, 1);
      if (heff_strEq_c_lent(v_p_2479, ((V)&g_heff_2ecompile_2ebounds_2eownNeed_24cpr_str0), 2)) {
        v_t_2484 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24r_2480_24RepFix, TAG_RepFix, 1, (V[]){v_w_2482})});
      } else {
        heff_drop(v_w_2482);
        heff_drop_cell(v_ru_24r_2480_24RepFix, 1);
        v_t_2484 = NTAG(TAG_Nothing);
      }
      break;
    }
    case TAG_RepF64: {
      v_t_2484 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_RepInt: {
      v_t_2484 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_r_2480);
    }
    return ({ V a_0 = v_info_240; V a_1 = v_env_241; V a_2 = v_p_2479; V a_3 = v_t_2484; V a_4 = v_es_2481; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_2479); r_; });
  }
  case TAG_RFixU: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    heff_take_na(v_e_242, 0ULL, 1);
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2ecompile_2ebounds_2escopedSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2escopedSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2escopedSt_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2escopedSt(V v_go_240, V v_info_241, V v_env_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_CDrop: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CLet: {
    V v_e_246 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CLet = heff_take_reuse_n(v_s_243, 2ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    V v_t_247 = heff_tag_at_n(v_ru_24s_243_24CLet, TAG_Cons, 2, (V[]){v_e_246, NTAG(TAG_Nil)});
    return (g_list_2emap_24s215892288x1392224072(v_env_242, v_t_247));
  }
  case TAG_CDecl: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CSet: {
    V v_e_2410 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CSet = heff_take_reuse_n(v_s_243, 2ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    V v_t_2411 = heff_tag_at_n(v_ru_24s_243_24CSet, TAG_Cons, 2, (V[]){v_e_2410, NTAG(TAG_Nil)});
    return (g_list_2emap_24s215892288x1392224072(v_env_242, v_t_2411));
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CIf: {
    V v_c_2412 = heff_field(v_s_243, 0);
    V v_a_2413 = heff_field(v_s_243, 1);
    V v_b_2414 = heff_field(v_s_243, 2);
    heff_take_n(v_s_243, 7ULL, 3);
    V v_t_2415 = (g_list_2emap_24f1221888634x716224461(heff_dup(v_env_242), v_c_2412));
    HeffT2 v_t_2416 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(heff_dup(v_info_241), heff_dup(v_c_2412)));
    V v_t_2423;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_x21_2420 = v_field_2418;
        switch (heff_tag_of(v_x21_2420)) {
        case TAG_MkPair: {
          V v_r_2421 = heff_field(v_x21_2420, 0);
          V v_x212_2422 = heff_field(v_x21_2420, 1);
          V v_ru_24x21_2420_24MkPair = heff_take_reuse_n(v_x21_2420, 3ULL, 2);
          if ((heff_dup(v_x212_2422) == NTAG(TAG_True))) {
            heff_drop(v_x212_2422);
            v_t_2423 = heff_tag_at_n(v_ru_24x21_2420_24MkPair, TAG_Cons, 2, (V[]){v_r_2421, heff_dup(v_env_242)});
          } else {
            heff_drop(v_r_2421);
            heff_drop(v_x212_2422);
            heff_drop_cell(v_ru_24x21_2420_24MkPair, 2);
            v_t_2423 = heff_dup(v_env_242);
          }
          break;
        }
        default: heff_nomatch(v_x21_2420);
        }
      } else {
        heff_drop(v_field_2418);
        v_t_2423 = heff_dup(v_env_242);
      }
    }
    V v_t_2424 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_t_2423, v_a_2413}));
    HeffT2 v_t_2425 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(v_info_241, v_c_2412));
    V v_t_2432;
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_x21_2429 = v_field_2427;
        switch (heff_tag_of(v_x21_2429)) {
        case TAG_MkPair: {
          V v_r_2430 = heff_field(v_x21_2429, 0);
          V v_x212_2431 = heff_field(v_x21_2429, 1);
          V v_ru_24x21_2429_24MkPair = heff_take_reuse_n(v_x21_2429, 3ULL, 2);
          if ((heff_dup(v_x212_2431) == NTAG(TAG_True))) {
            heff_drop(v_r_2430);
            heff_drop(v_x212_2431);
            heff_drop_cell(v_ru_24x21_2429_24MkPair, 2);
            v_t_2432 = v_env_242;
          } else {
            heff_drop(v_x212_2431);
            v_t_2432 = heff_tag_at_n(v_ru_24x21_2429_24MkPair, TAG_Cons, 2, (V[]){v_r_2430, v_env_242});
          }
          break;
        }
        default: heff_nomatch(v_x21_2429);
        }
      } else {
        heff_drop(v_field_2427);
        v_t_2432 = v_env_242;
      }
    }
    V v_t_2433 = heff_tr(heff_call(v_go_240, 2, (V[]){v_t_2432, v_b_2414}));
    V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2433));
    return (g_prelude_2e_2b_2b(v_t_2415, v_t_2434));
  }
  case TAG_CSwitch: {
    V v_e_2435 = heff_field(v_s_243, 0);
    V v_arms_2436 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 3ULL, 3);
    heff_drop(v_info_241);
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2436));
    V v_t_2451 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2escopedSt_lam0, 2, 2, (V[]){v_go_240, heff_dup(v_env_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2438; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2438); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_env_242, v_e_2435}), v_t_2451});
  }
  case TAG_CReturn: {
    V v_e_2452 = heff_field(v_s_243, 0);
    heff_take_n(v_s_243, 1ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2452, NTAG(TAG_Nil)});
    return (g_list_2emap_24s215892288x1392224072(v_env_242, v_t_2453));
  }
  case TAG_CInPlace: {
    V v_f_2454 = heff_field(v_s_243, 0);
    V v_es_2455 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CInPlace = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072(v_env_242, heff_tag_at_n(v_ru_24s_243_24CInPlace, TAG_Cons, 2, (V[]){v_f_2454, v_es_2455})));
  }
  case TAG_CRoomed: {
    V v_f_2456 = heff_field(v_s_243, 0);
    V v_es_2457 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CRoomed = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072(v_env_242, heff_tag_at_n(v_ru_24s_243_24CRoomed, TAG_Cons, 2, (V[]){v_f_2456, v_es_2457})));
  }
  case TAG_CTail: {
    V v_f_2458 = heff_field(v_s_243, 0);
    V v_es_2459 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CTail = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072(v_env_242, heff_tag_at_n(v_ru_24s_243_24CTail, TAG_Cons, 2, (V[]){v_f_2458, v_es_2459})));
  }
  case TAG_CLoop: {
    V v_es_2461 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 2ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072(v_env_242, v_es_2461));
  }
  case TAG_CLoopTo: {
    heff_take_n(v_s_243, 0ULL, 3);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CLabel: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CJump: {
    V v_es_2468 = heff_field(v_s_243, 2);
    heff_take_n(v_s_243, 4ULL, 3);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072(v_env_242, v_es_2468));
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_heff_2ecompile_2ebounds_2escopedSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2escopedSt(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ebounds_2escopedSt_lam0(V self, V *args) {
  V v_acc_2439 = args[0];
  V v_x_2440 = args[1];
  V v_go_240 = heff_env(self)[0];
  V v_env_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_MkCArm: {
    V v_body_2447 = heff_field(v_x_2440, 6);
    heff_take_n(v_x_2440, 64ULL, 8);
    v_t_2449 = v_body_2447;
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V v_t_2450 = heff_tr(heff_call(v_go_240, 2, (V[]){v_env_242, v_t_2449}));
  return (g_prelude_2e_2b_2b(v_t_2450, v_acc_2439));
}
V g_heff_2ecompile_2ebounds_2escoped_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2escoped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2escoped_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2escoped(V v_info_240, V v_env_241, V v_ss_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2escoped_clo), 1, (V[]){heff_dup(v_info_240)}));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_242));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2escoped_lam0, 2, 3, (V[]){v_t_243, v_info_240, v_env_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
}
V g_heff_2ecompile_2ebounds_2escoped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2escoped(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ebounds_2escoped_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_t_243 = heff_env(self)[0];
  V v_info_240 = heff_env(self)[1];
  V v_env_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = (g_heff_2ecompile_2ebounds_2escopedSt(v_t_243, v_info_240, v_env_241, v_x_246));
  return (g_prelude_2e_2b_2b(v_t_247, v_acc_245));
}
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_lam0(V self, V *args);
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_lam1(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_RLocal: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RDup: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RClo: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RGet: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RGetRaw: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RInt: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RFloat: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RStr: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RBytes: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RFixed: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RF32: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RNTag: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RTag: {
    V v_t_2416 = heff_field(v_x2_242, 0);
    V v_b_2417 = heff_field(v_x2_242, 1);
    V v_es_2418 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RTag = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_2420 = (g_list_2emap(v_t_2419, v_es_2418));
    V v_a_2421 = heff_tag_at_n(v_ru_24x2_242_24RTag, TAG_RTag, 3, (V[]){v_t_2416, v_b_2417, v_t_2420});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2421);
  }
  case TAG_RTagIn: {
    V v_e_2422 = heff_field(v_x2_242, 0);
    V v_t_2423 = heff_field(v_x2_242, 1);
    V v_b_2424 = heff_field(v_x2_242, 2);
    V v_es_2425 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24RTagIn = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    V v_t_2426 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2422));
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_2428 = (g_list_2emap(v_t_2427, v_es_2425));
    V v_a_2429 = heff_tag_at_n(v_ru_24x2_242_24RTagIn, TAG_RTagIn, 4, (V[]){v_t_2426, v_t_2423, v_b_2424, v_t_2428});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2429);
  }
  case TAG_RRec: {
    V v_ls_2430 = heff_field(v_x2_242, 0);
    V v_b_2431 = heff_field(v_x2_242, 1);
    V v_es_2432 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RRec = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_2434 = (g_list_2emap(v_t_2433, v_es_2432));
    V v_a_2435 = heff_tag_at_n(v_ru_24x2_242_24RRec, TAG_RRec, 3, (V[]){v_ls_2430, v_b_2431, v_t_2434});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2435);
  }
  case TAG_RRecIn: {
    V v_x_2436 = heff_field(v_x2_242, 0);
    V v_n_2437 = heff_field(v_x2_242, 1);
    V v_k_2438 = heff_field(v_x2_242, 2);
    V v_g_2439 = heff_field(v_x2_242, 3);
    V v_s_2440 = heff_field(v_x2_242, 4);
    V v_ls_2441 = heff_field(v_x2_242, 5);
    V v_fs_2442 = heff_field(v_x2_242, 6);
    V v_sure_2443 = heff_field(v_x2_242, 7);
    V v_ru_24x2_242_24RRecIn = heff_take_reuse_n(v_x2_242, 255ULL, 8);
    V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_lam0, 1, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_fs_2442));
    V v_a_2453 = heff_tag_at_n(v_ru_24x2_242_24RRecIn, TAG_RRecIn, 8, (V[]){v_x_2436, v_n_2437, v_k_2438, v_g_2439, v_s_2440, v_ls_2441, v_t_2452, v_sure_2443});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2453);
  }
  case TAG_RField: {
    V v_e_2454 = heff_field(v_x2_242, 0);
    V v_i_2455 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RField = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2456 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2454));
    V v_a_2457 = heff_tag_at_n(v_ru_24x2_242_24RField, TAG_RField, 2, (V[]){v_t_2456, v_i_2455});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2457);
  }
  case TAG_RDupE: {
    V v_e_2458 = heff_field(v_x2_242, 0);
    V v_ru_24x2_242_24RDupE = heff_take_reuse_n(v_x2_242, 1ULL, 1);
    V v_t_2459 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2458));
    V v_a_2460 = heff_tag_at_n(v_ru_24x2_242_24RDupE, TAG_RDupE, 1, (V[]){v_t_2459});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2460);
  }
  case TAG_RFieldV: {
    V v_e_2461 = heff_field(v_x2_242, 0);
    V v_i_2462 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RFieldV = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2463 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2461));
    V v_a_2464 = heff_tag_at_n(v_ru_24x2_242_24RFieldV, TAG_RFieldV, 2, (V[]){v_t_2463, v_i_2462});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2464);
  }
  case TAG_RGetN: {
    V v_e_2465 = heff_field(v_x2_242, 0);
    V v_i_2466 = heff_field(v_x2_242, 1);
    V v_n_2467 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RGetN = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_2468 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2465));
    V v_a_2469 = heff_tag_at_n(v_ru_24x2_242_24RGetN, TAG_RGetN, 3, (V[]){v_t_2468, v_i_2466, v_n_2467});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2469);
  }
  case TAG_RFieldU: {
    V v_r_2470 = heff_field(v_x2_242, 0);
    V v_s_2471 = heff_field(v_x2_242, 1);
    V v_e_2472 = heff_field(v_x2_242, 2);
    V v_i_2473 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24RFieldU = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    V v_t_2474 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2472));
    V v_a_2475 = heff_tag_at_n(v_ru_24x2_242_24RFieldU, TAG_RFieldU, 4, (V[]){v_r_2470, v_s_2471, v_t_2474, v_i_2473});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2475);
  }
  case TAG_RGetNU: {
    V v_r_2476 = heff_field(v_x2_242, 0);
    V v_s_2477 = heff_field(v_x2_242, 1);
    V v_e_2478 = heff_field(v_x2_242, 2);
    V v_i_2479 = heff_field(v_x2_242, 3);
    V v_n_2480 = heff_field(v_x2_242, 4);
    V v_ru_24x2_242_24RGetNU = heff_take_reuse_n(v_x2_242, 31ULL, 5);
    V v_t_2481 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2478));
    V v_a_2482 = heff_tag_at_n(v_ru_24x2_242_24RGetNU, TAG_RGetNU, 5, (V[]){v_r_2476, v_s_2477, v_t_2481, v_i_2479, v_n_2480});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2482);
  }
  case TAG_RWord: {
    V v_r_2483 = heff_field(v_x2_242, 0);
    V v_e_2484 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RWord = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2485 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2484));
    V v_a_2486 = heff_tag_at_n(v_ru_24x2_242_24RWord, TAG_RWord, 2, (V[]){v_r_2483, v_t_2485});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2486);
  }
  case TAG_RTakeField: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RGetLabel: {
    V v_e_2489 = heff_field(v_x2_242, 0);
    V v_l_2490 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RGetLabel = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2491 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_2489));
    V v_a_2492 = heff_tag_at_n(v_ru_24x2_242_24RGetLabel, TAG_RGetLabel, 2, (V[]){v_t_2491, v_l_2490});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2492);
  }
  case TAG_RPrimFn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RPrim: {
    V v_p_2494 = heff_field(v_x2_242, 0);
    V v_es_2495 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RPrim = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_2497 = (g_list_2emap(v_t_2496, v_es_2495));
    V v_a_2498 = heff_tag_at_n(v_ru_24x2_242_24RPrim, TAG_RPrim, 2, (V[]){v_p_2494, v_t_2497});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_2498);
  }
  case TAG_RLam: {
    V v_xs_2499 = heff_field(v_x2_242, 0);
    V v_fv_24100 = heff_field(v_x2_242, 1);
    V v_held_24101 = heff_field(v_x2_242, 2);
    V v_body_24102 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24RLam = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    V v_t_24103 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24104 = (g_list_2emap(v_t_24103, v_held_24101));
    V v_a_24105 = heff_tag_at_n(v_ru_24x2_242_24RLam, TAG_RLam, 4, (V[]){v_xs_2499, v_fv_24100, v_t_24104, v_body_24102});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24105);
  }
  case TAG_RCall: {
    V v_g_24106 = heff_field(v_x2_242, 0);
    V v_tr_24107 = heff_field(v_x2_242, 1);
    V v_w_24108 = heff_field(v_x2_242, 2);
    V v_args_24109 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24RCall = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    V v_f_24110 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24121 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_lam1, 1, 1, (V[]){v_f_24110}), v_args_24109));
    V v_a_24122 = heff_tag_at_n(v_ru_24x2_242_24RCall, TAG_RCall, 4, (V[]){v_g_24106, v_tr_24107, v_w_24108, v_t_24121});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24122);
  }
  case TAG_RApply: {
    V v_g_24123 = heff_field(v_x2_242, 0);
    V v_es_24124 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RApply = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24125 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_g_24123));
    V v_t_24126 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24127 = (g_list_2emap(v_t_24126, v_es_24124));
    V v_a_24128 = heff_tag_at_n(v_ru_24x2_242_24RApply, TAG_RApply, 2, (V[]){v_t_24125, v_t_24127});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24128);
  }
  case TAG_RBool: {
    V v_c_24129 = heff_field(v_x2_242, 0);
    V v_ru_24x2_242_24RBool = heff_take_reuse_n(v_x2_242, 1ULL, 1);
    V v_t_24130 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24131 = (g_heff_2ecompile_2eowned_2emapCond(v_t_24130, v_c_24129));
    V v_a_24132 = heff_tag_at_n(v_ru_24x2_242_24RBool, TAG_RBool, 1, (V[]){v_t_24131});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24132);
  }
  case TAG_RAbandon: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RBox: {
    V v_r_24133 = heff_field(v_x2_242, 0);
    V v_e_24134 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RBox = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24135 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_24134));
    V v_a_24136 = heff_tag_at_n(v_ru_24x2_242_24RBox, TAG_RBox, 2, (V[]){v_r_24133, v_t_24135});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24136);
  }
  case TAG_RUnbox: {
    V v_r_24137 = heff_field(v_x2_242, 0);
    V v_e_24138 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RUnbox = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24139 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_24138));
    V v_a_24140 = heff_tag_at_n(v_ru_24x2_242_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_24137, v_t_24139});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24140);
  }
  case TAG_RPeek: {
    V v_r_24141 = heff_field(v_x2_242, 0);
    V v_e_24142 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RPeek = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24143 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(heff_dup(v_lit_240), heff_dup(v_lit_241), v_e_24142));
    V v_a_24144 = heff_tag_at_n(v_ru_24x2_242_24RPeek, TAG_RPeek, 2, (V[]){v_r_24141, v_t_24143});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24144);
  }
  case TAG_RPrimU: {
    V v_p_24145 = heff_field(v_x2_242, 0);
    V v_es_24146 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RPrimU = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24147 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24148 = (g_list_2emap(v_t_24147, v_es_24146));
    V v_a_24149 = heff_tag_at_n(v_ru_24x2_242_24RPrimU, TAG_RPrimU, 2, (V[]){v_p_24145, v_t_24148});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24149);
  }
  case TAG_RPrimAt: {
    V v_p_24150 = heff_field(v_x2_242, 0);
    V v_r_24151 = heff_field(v_x2_242, 1);
    V v_es_24152 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RPrimAt = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24154 = (g_list_2emap(v_t_24153, v_es_24152));
    V v_a_24155 = heff_tag_at_n(v_ru_24x2_242_24RPrimAt, TAG_RPrimAt, 3, (V[]){v_p_24150, v_r_24151, v_t_24154});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_a_24155);
  }
  case TAG_RFixU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RF32U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  case TAG_RF64U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_x2_242);
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_lam0(V self, V *args) {
  V v_p_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447;
  switch (heff_tag_of(v_p_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_dup(heff_field(v_p_2444, 0));
    v_t_2447 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_p_2444);
  }
  V v_t_2450;
  switch (heff_tag_of(v_p_2444)) {
  case TAG_MkPair: {
    V v_y_2449 = heff_field(v_p_2444, 1);
    heff_take_n(v_p_2444, 2ULL, 2);
    v_t_2450 = v_y_2449;
    break;
  }
  default: heff_nomatch(v_p_2444);
  }
  V v_t_2451 = (g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180(v_lit_240, v_lit_241, v_t_2450));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2447, v_t_2451});
}
V g_heff_2ecompile_2ebounds_2emapExp_24s1928809534x1632309180_lam1(V self, V *args) {
  V v_a_24111 = args[0];
  V v_f_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24111)) {
  case TAG_Given: {
    V v_e_24112 = heff_field(v_a_24111, 0);
    V v_ru_24a_24111_24Given = heff_take_reuse_n(v_a_24111, 1ULL, 1);
    V v_t_24113 = heff_tr(heff_call(v_f_24110, 1, (V[]){v_e_24112}));
    return heff_tag_at_n(v_ru_24a_24111_24Given, TAG_Given, 1, (V[]){v_t_24113});
  }
  case TAG_GivenU: {
    V v_r_24114 = heff_field(v_a_24111, 0);
    V v_e_24115 = heff_field(v_a_24111, 1);
    V v_ru_24a_24111_24GivenU = heff_take_reuse_n(v_a_24111, 3ULL, 2);
    V v_t_24116 = heff_tr(heff_call(v_f_24110, 1, (V[]){v_e_24115}));
    return heff_tag_at_n(v_ru_24a_24111_24GivenU, TAG_GivenU, 2, (V[]){v_r_24114, v_t_24116});
  }
  case TAG_LentVar: {
    heff_drop(v_f_24110);
    return v_a_24111;
  }
  case TAG_LentValue: {
    V v_e_24119 = heff_field(v_a_24111, 0);
    V v_ru_24a_24111_24LentValue = heff_take_reuse_n(v_a_24111, 1ULL, 1);
    V v_t_24120 = heff_tr(heff_call(v_f_24110, 1, (V[]){v_e_24119}));
    return heff_tag_at_n(v_ru_24a_24111_24LentValue, TAG_LentValue, 1, (V[]){v_t_24120});
  }
  default: return heff_nomatch(v_a_24111);
  }
}
Clo g_heff_2ecompile_2ebounds_2efixStmts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2efixStmts_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2efixStmts(V v_info_240, V v_env_241, V v_ss_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2efixStmts_clo), 1, (V[]){heff_dup(v_info_240)}));
  return (g_list_2emap_24s1440555322x1057233214(v_t_243, v_info_240, v_env_241, v_ss_242));
}
V g_heff_2ecompile_2ebounds_2efixStmts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2efixStmts(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2elongEnough_str0, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2ebounds_2elongEnough_str1, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2ebounds_2elongEnough_str2, 6, "wordLe");
Clo g_heff_2ecompile_2ebounds_2elongEnough_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2elongEnough_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2elongEnough(V v_n_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_n_240, 1)), heff_dup(heff_rfield(v_n_240, 2)))) {
    heff_drop_rec(v_n_240, 4);
    return NTAG(TAG_Nil);
  } else {
    V v_t_242 = heff_tag_n(TAG_RDup, 1, (V[]){heff_take_field(v_n_240, 1)});
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
    V v_t_244 = heff_tag_n(TAG_RUnbox, 2, (V[]){NTAG(TAG_RepInt), heff_tag_n(TAG_RPrim, 2, (V[]){((V)&g_heff_2ecompile_2ebounds_2elongEnough_str0), v_t_243})});
    V v_t_245 = heff_tag_n(TAG_RDup, 1, (V[]){heff_get_n(v_n_240, 2, 4)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_RUnbox, 2, (V[]){NTAG(TAG_RepInt), heff_tag_n(TAG_RPrim, 2, (V[]){((V)&g_heff_2ecompile_2ebounds_2elongEnough_str1), v_t_246})});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_CondRelU, 2, (V[]){((V)&g_heff_2ecompile_2ebounds_2elongEnough_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_248})});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  }
}
V g_heff_2ecompile_2ebounds_2elongEnough_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2elongEnough(a[0]);
}
Clo g_heff_2ecompile_2ebounds_2enubS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2enubS_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2enubS(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2ebounds_2eelemS(v_x_242, v_acc_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_acc_240;
      V t_1 = v_xs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_240});
      V t_1 = v_xs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ebounds_2enubS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2enubS(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2echeckOf_str0, 10, "arrayKeeps");
Clo g_heff_2ecompile_2ebounds_2echeckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2echeckOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2echeckOf(V v_ns_240) {
top: ;
  V v_t_241 = (g_list_2emap_24s1700608285x1639860354(heff_dup(v_ns_240)));
  V v_t_242 = (g_heff_2ecompile_2ebounds_2enubS(NTAG(TAG_Nil), v_t_241));
  V v_t_243 = (g_list_2emap_24s1353477632x1698603588(v_t_242));
  V v_t_244 = (g_list_2efoldl_24f1241151012x1129179210(NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_ns_240)));
  V v_t_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1922266401x1990263591(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_list_2efoldl_24f428710765x1902475677(NTAG(TAG_Nil), NTAG(TAG_Nil), v_ns_240));
  V v_t_247 = (g_list_2efoldl_24s1845523271x872922214(((V)&g_heff_2ecompile_2ebounds_2echeckOf_str0), NTAG(TAG_Nil), v_t_246));
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_245, v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_243, v_t_248));
  return ({ V a_0 = v_t_249; V r_ = (g_heff_2ecompile_2ebounds_2eallOf(a_0)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2ebounds_2echeckOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2echeckOf(a[0]);
}
Clo g_heff_2ecompile_2ebounds_2echeckedWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2echeckedWith_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2echeckedWith(V v_f_240, V v_info_241, V v_ns_242) {
top: ;
  switch (heff_tag_of(v_ns_242)) {
  case TAG_Nil: {
    heff_drop(v_info_241);
    return v_f_240;
  }
  case TAG_Cons: {
    V v_t_245 = (g_heff_2ecompile_2ebounds_2echeckOf(v_ns_242));
    V v_t_246 = (g_heff_2ecompile_2ebounds_2efixStmts(v_info_241, NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_240, 4))));
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLabel, 1, (V[]){heff_dup(g_heff_2ecompile_2ebounds_2elabel_get())}), v_t_246});
    V v_t_248 = heff_tag_n(TAG_CIf, 3, (V[]){v_t_245, v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_f_240, 3), v_t_249));
    return ({ V rv_3 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_f_240, 247ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_ns_242);
  }
}
V g_heff_2ecompile_2ebounds_2echeckedWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2echeckedWith(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2ebounds_2eboundsDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eboundsDef_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2eboundsDef(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DFun: {
    V v_f_241 = heff_field(v_d_240, 0);
    V v_ru_24d_240_24DFun = heff_take_reuse_n(v_d_240, 1ULL, 1);
    V v_ags_242 = (g_list_2efoldl_24s2015232937x23400545(NTAG(TAG_Nil), heff_rfield(v_f_241, 4)));
    V v_t_247;
    switch (heff_tag_of(v_ags_242)) {
    case TAG_Nil: {
      v_t_247 = v_f_241;
      break;
    }
    case TAG_Cons: {
      V v_t_245 = (g_list_2efoldl_24s345718350x1678852400(NTAG(TAG_False), heff_rfield(v_f_241, 4)));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop_tag(v_ags_242, 2);
        heff_drop(v_t_245);
        v_t_247 = v_f_241;
      } else {
        heff_drop(v_t_245);
        V v_t_246 = (g_list_2efoldl_24s490001784x345683100(NTAG(TAG_Nil), heff_rfield(v_f_241, 4)));
        v_t_247 = ({ V a_0 = v_f_241; V a_1 = v_t_246; V a_2 = v_ags_242; V r_ = (g_heff_2ecompile_2ebounds_2eboundsWith(a_0, a_1, a_2)); heff_drop_tag(v_ags_242, 2); r_; });
      }
      break;
    }
    default: heff_nomatch(v_ags_242);
    }
    return heff_tag_at_n(v_ru_24d_240_24DFun, TAG_DFun, 1, (V[]){v_t_247});
  }
  case TAG_DVal: {
    return v_d_240;
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2ecompile_2ebounds_2eboundsDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eboundsDef(a[0]);
}