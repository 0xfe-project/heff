// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexInAny 674
#define TAG_ArrayOwn 58870
#define TAG_ArrayPeek 2264
#define TAG_ArraySet 62162
#define TAG_ArraySetOwned 53556
#define TAG_ArraySetOwnedIn 22211
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define LBL_arrays 537976933
#define LBL_defs 9574869
V g_heff_2ecompile_2ebounds_2eallOf(V);
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eallOf_clo;
V g_heff_2ecompile_2ebounds_2echeckOf(V, V);
V g_heff_2ecompile_2ebounds_2echeckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2echeckOf_clo;
V g_heff_2ecompile_2ebounds_2eelemS(V, V);
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eelemS_clo;
V g_heff_2ecompile_2ebounds_2efixStmts(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2efixStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixStmts_clo;
HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V);
V g_heff_2ecompile_2ebounds_2elengthOf(V);
V g_heff_2ecompile_2ebounds_2elengthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elengthOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2elengthOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(V, V, V, V);
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eneedAt_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2enubS(V, V);
V g_heff_2ecompile_2ebounds_2enubS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2enubS_clo;
V g_heff_2ecompile_2ebounds_2eownedSt(V);
V g_heff_2ecompile_2ebounds_2eownedSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eownedSt_clo;
HeffT2 g_heff_2ecompile_2ebounds_2erangeOf_24cpr(V, V, V);
HeffT3 g_heff_2ecompile_2ebounds_2erangeTest_24cpr(V, V);
V g_heff_2ecompile_2ebounds_2ereadsIn(V, V);
V g_heff_2ecompile_2ebounds_2ereadsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2ereadsIn_clo;
V g_heff_2ecompile_2ebounds_2esameAs(V, V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2esameAs_clo;
V g_heff_2ecompile_2ebounds_2escoped(V, V, V);
V g_heff_2ecompile_2ebounds_2escoped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2escoped_clo;
V g_heff_2ecompile_2ebounds_2escopedSt(V, V, V, V);
V g_heff_2ecompile_2ebounds_2escopedSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2escopedSt_clo;
V g_heff_2ecompile_2ebounds_2eunchecked(V, V, V, V);
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eunchecked_clo;
V g_heff_2ecompile_2ebounds_2evarOf(V);
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2evarOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2evarOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2evarOf_24tok1(V, V);
V g_heff_2ecompile_2ebounds_2evarOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2evarOf_24tok1_clo;
V g_heff_2ecompile_2eowned_2ekids(V);
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ekids_clo;
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f380832527x418567417(V, V, V);
V g_list_2efoldl_24f380832527x418567417_entry(V self, V *a);
extern Clo g_list_2efoldl_24f380832527x418567417_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1922266401x1990263591(V, V);
V g_list_2efoldl_24s1922266401x1990263591_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1922266401x1990263591_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s708019417x1279437633(V, V);
V g_list_2ekeepIf_24s708019417x1279437633_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s708019417x1279437633_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1221888634x716224461(V, V);
V g_list_2emap_24f1221888634x716224461_entry(V self, V *a);
extern Clo g_list_2emap_24f1221888634x716224461_clo;
V g_list_2emap_24s1136209598x1881409718(V);
V g_list_2emap_24s1136209598x1881409718_entry(V self, V *a);
extern Clo g_list_2emap_24s1136209598x1881409718_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1353477632x1698603588(V);
V g_list_2emap_24s1353477632x1698603588_entry(V self, V *a);
extern Clo g_list_2emap_24s1353477632x1698603588_clo;
V g_list_2emap_24s1417440002x1148747973(V, V, V, V, V, V);
V g_list_2emap_24s1417440002x1148747973_entry(V self, V *a);
extern Clo g_list_2emap_24s1417440002x1148747973_clo;
V g_list_2emap_24s1700608285x1639860354(V);
V g_list_2emap_24s1700608285x1639860354_entry(V self, V *a);
extern Clo g_list_2emap_24s1700608285x1639860354_clo;
V g_list_2emap_24s215892288x1392224072(V, V);
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_clo;
V g_list_2emap_24s215892288x1392224072_24tok2(V, V, V);
V g_list_2emap_24s215892288x1392224072_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;

HeffT2 g_heff_2ecompile_2ebounds_2evarOf_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_RLocal: {
    V v_x_241 = heff_field(v_e_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_241)}});
  }
  case TAG_RDup: {
    V v_x_242 = heff_field(v_e_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
  }
  case TAG_RClo: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RLam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2esameAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2esameAs_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2esameAs(V v_ds_240, V v_seen_241, V v_b_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_RLocal: {
    V v_y_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_244, v_b_242, 0)) {
      heff_drop(v_ds_240);
      heff_drop(v_seen_241);
      heff_drop(v_b_242);
      heff_drop(v_y_244);
      return NTAG(TAG_True);
    } else {
      V v_x1_245 = (g_heff_2ecompile_2ebounds_2eelemS(v_y_244, v_seen_241));
      if (!(heff_dup(v_x1_245) == NTAG(TAG_True))) {
        heff_drop(v_x1_245);
        V v_t_246 = (g_list_2ekeepIf_24s708019417x1279437633(v_y_244, heff_dup(v_ds_240)));
        V v_x1_247 = (g_list_2emap_24s1173914895x100384474(v_t_246));
        switch (heff_tag_of(v_x1_247)) {
        case TAG_Nil: {
          heff_drop(v_ds_240);
          heff_drop(v_seen_241);
          heff_drop(v_b_242);
          heff_drop(v_y_244);
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_ru_24x1_247_24Cons = heff_take_reuse_n(v_x1_247, 0ULL, 2);
          V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){heff_dup(v_ds_240), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_244), v_seen_241}), v_b_242}));
          V v_t_2411 = ({ V a_0 = v_y_244; V a_1 = v_ds_240; V r_ = (g_list_2ekeepIf_24s708019417x1279437633(a_0, a_1)); heff_drop(v_y_244); r_; });
          V v_t_2412 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x1_247_24Cons, v_t_2411));
          return ({ V a_0 = v_t_2410; V a_1 = v_t_2412; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2412); r_; });
        }
        default: return heff_nomatch(v_x1_247);
        }
      } else {
        heff_drop(v_ds_240);
        heff_drop(v_seen_241);
        heff_drop(v_b_242);
        heff_drop(v_y_244);
        heff_drop(v_x1_245);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_RDup: {
    V v_y_2413 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24RDup = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V t_0 = v_ds_240;
    V t_1 = v_seen_241;
    V t_2 = v_b_242;
    V t_3 = heff_tag_at_n(v_ru_24e_243_24RDup, TAG_RLocal, 1, (V[]){v_y_2413});
    v_ds_240 = t_0;
    v_seen_241 = t_1;
    v_b_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_RClo: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    heff_take_n(v_e_243, 0ULL, 3);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    heff_take_n(v_e_243, 0ULL, 3);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    heff_take_n(v_e_243, 0ULL, 8);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    heff_take_n(v_e_243, 0ULL, 3);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    heff_take_n(v_e_243, 0ULL, 5);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RTakeField: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    V v_p_2467 = heff_field(v_e_243, 0);
    V v_es_2468 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    switch (heff_tag_of(v_p_2467)) {
    case TAG_ArraySet: {
      V v_f_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2468)) {
      case TAG_Nil: {
        heff_drop(v_f_2469);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_2470 = heff_field(v_es_2468, 0);
        heff_take_n(v_es_2468, 1ULL, 2);
        return heff_tail(v_f_2469, 1, (V[]){v_x_2470});
      }
      default: return heff_nomatch(v_es_2468);
      }
    }
    case TAG_ArraySetOwned: {
      V v_f_2472 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2468)) {
      case TAG_Nil: {
        heff_drop(v_f_2472);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_2473 = heff_field(v_es_2468, 0);
        heff_take_n(v_es_2468, 1ULL, 2);
        return heff_tail(v_f_2472, 1, (V[]){v_x_2473});
      }
      default: return heff_nomatch(v_es_2468);
      }
    }
    case TAG_ArraySetOwnedIn: {
      V v_f_2475 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2468)) {
      case TAG_Nil: {
        heff_drop(v_f_2475);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_2476 = heff_field(v_es_2468, 0);
        heff_take_n(v_es_2468, 1ULL, 2);
        return heff_tail(v_f_2475, 1, (V[]){v_x_2476});
      }
      default: return heff_nomatch(v_es_2468);
      }
    }
    default: {
      heff_drop(v_ds_240);
      heff_drop(v_seen_241);
      heff_drop(v_b_242);
      heff_drop(v_p_2467);
      heff_drop(v_es_2468);
      return NTAG(TAG_False);
    }
    }
  }
  case TAG_RLam: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    heff_take_n(v_e_243, 0ULL, 4);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    heff_take_n(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    V v_p_2497 = heff_field(v_e_243, 0);
    V v_es_2499 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 5ULL, 3);
    switch (heff_tag_of(v_p_2497)) {
    case TAG_ArraySet: {
      V v_f_24100 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2499)) {
      case TAG_Nil: {
        heff_drop(v_f_24100);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_24101 = heff_field(v_es_2499, 0);
        heff_take_n(v_es_2499, 1ULL, 2);
        return heff_tail(v_f_24100, 1, (V[]){v_x_24101});
      }
      default: return heff_nomatch(v_es_2499);
      }
    }
    case TAG_ArraySetOwned: {
      V v_f_24103 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2499)) {
      case TAG_Nil: {
        heff_drop(v_f_24103);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_24104 = heff_field(v_es_2499, 0);
        heff_take_n(v_es_2499, 1ULL, 2);
        return heff_tail(v_f_24103, 1, (V[]){v_x_24104});
      }
      default: return heff_nomatch(v_es_2499);
      }
    }
    case TAG_ArraySetOwnedIn: {
      V v_f_24106 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2esameAs_clo), 3, (V[]){v_ds_240, v_seen_241, v_b_242}));
      switch (heff_tag_of(v_es_2499)) {
      case TAG_Nil: {
        heff_drop(v_f_24106);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_24107 = heff_field(v_es_2499, 0);
        heff_take_n(v_es_2499, 1ULL, 2);
        return heff_tail(v_f_24106, 1, (V[]){v_x_24107});
      }
      default: return heff_nomatch(v_es_2499);
      }
    }
    default: {
      heff_drop(v_ds_240);
      heff_drop(v_seen_241);
      heff_drop(v_b_242);
      heff_drop(v_p_2497);
      heff_drop(v_es_2499);
      return NTAG(TAG_False);
    }
    }
  }
  case TAG_RFixU: {
    heff_take_n(v_e_243, 0ULL, 2);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    heff_take_na(v_e_243, 0ULL, 1);
    heff_drop(v_ds_240);
    heff_drop(v_seen_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2ebounds_2esameAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2esameAs(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2ebounds_2elengthOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RLam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    V v_x11_2471 = heff_field(v_x1_240, 0);
    V v_e_2472 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_RepV: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepFix: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepF64: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepInt: {
      HEFF_LAST return g_heff_2ecompile_2ebounds_2elengthArray_24cpr(v_e_2472);
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2471)}});
    }
  }
  case TAG_RPeek: {
    V v_x11_2474 = heff_field(v_x1_240, 0);
    V v_e_2475 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_2474)) {
    case TAG_RepV: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepFix: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepF64: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RepInt: {
      HEFF_LAST return g_heff_2ecompile_2ebounds_2elengthArray_24cpr(v_e_2475);
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2474)}});
    }
  }
  case TAG_RPrimU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT3 g_heff_2ecompile_2ebounds_2erangeTest_24cpr(V v_info_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    heff_drop(v_info_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_CondFalse: {
    heff_drop(v_info_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_CondRel: {
    heff_drop(v_info_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_CondRelU: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    V v_info_246 = v_info_240;
    V v_p_247 = heff_dup(v_p_244);
    V v_es_248 = heff_dup(v_es_245);
    switch (heff_tag_of(v_p_247)) {
    case TAG_WordLt: {
      switch (heff_tag_of(v_es_248)) {
      case TAG_Nil: {
        heff_drop(v_info_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_a_249 = heff_field(v_es_248, 0);
        V v_es2_2410 = heff_field(v_es_248, 1);
        heff_take_n(v_es_248, 3ULL, 2);
        switch (heff_tag_of(v_es2_2410)) {
        case TAG_Nil: {
          heff_drop(v_info_246);
          heff_drop(v_a_249);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_b_2411 = heff_field(v_es2_2410, 0);
          V v_es22_2412 = heff_field(v_es2_2410, 1);
          heff_take_n(v_es2_2410, 3ULL, 2);
          switch (heff_tag_of(v_es22_2412)) {
          case TAG_Nil: {
            V v_t_2413 = ({ V a_0 = v_a_249; V r_ = (g_heff_2ecompile_2ebounds_2evarOf(a_0)); heff_drop(v_a_249); r_; });
            V v_t_2414 = ({ V a_0 = v_b_2411; V r_ = (g_heff_2ecompile_2ebounds_2elengthOf(a_0)); heff_drop(v_b_2411); r_; });
            HeffT2 v_t_2415 = (g_heff_2ecompile_2ebounds_2erangeOf_24cpr(v_info_246, v_t_2413, v_t_2414));
            {
              V v_field_2417 = v_t_2415.f[1];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_r_2418 = v_field_2417;
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_r_2418, NTAG(TAG_True)}});
              } else {
                heff_drop(v_field_2417);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_es22_2412, 0ULL, 2);
            heff_drop(v_info_246);
            heff_drop(v_a_249);
            heff_drop(v_b_2411);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          default: return ((HeffT3){{heff_nomatch(v_es22_2412)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_es2_2410)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_es_248)}});
      }
    }
    case TAG_WordLe: {
      switch (heff_tag_of(v_es_248)) {
      case TAG_Nil: {
        heff_drop(v_info_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_a_2421 = heff_field(v_es_248, 0);
        V v_es2_2422 = heff_field(v_es_248, 1);
        heff_take_n(v_es_248, 3ULL, 2);
        switch (heff_tag_of(v_es2_2422)) {
        case TAG_Nil: {
          heff_drop(v_info_246);
          heff_drop(v_a_2421);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_b_2423 = heff_field(v_es2_2422, 0);
          V v_es22_2424 = heff_field(v_es2_2422, 1);
          heff_take_n(v_es2_2422, 3ULL, 2);
          switch (heff_tag_of(v_es22_2424)) {
          case TAG_Nil: {
            V v_t_2425 = ({ V a_0 = v_b_2423; V r_ = (g_heff_2ecompile_2ebounds_2evarOf(a_0)); heff_drop(v_b_2423); r_; });
            V v_t_2426 = ({ V a_0 = v_a_2421; V r_ = (g_heff_2ecompile_2ebounds_2elengthOf(a_0)); heff_drop(v_a_2421); r_; });
            HeffT2 v_t_2427 = (g_heff_2ecompile_2ebounds_2erangeOf_24cpr(v_info_246, v_t_2425, v_t_2426));
            {
              V v_field_2429 = v_t_2427.f[1];
              int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
              if ((v_tag_2428 == ((int64_t)0ULL))) {
                V v_r_2430 = v_field_2429;
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_r_2430, NTAG(TAG_False)}});
              } else {
                heff_drop(v_field_2429);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_es22_2424, 0ULL, 2);
            heff_drop(v_info_246);
            heff_drop(v_a_2421);
            heff_drop(v_b_2423);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          default: return ((HeffT3){{heff_nomatch(v_es22_2424)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_es2_2422)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_es_248)}});
      }
    }
    default: {
      heff_drop(v_info_246);
      heff_drop(v_p_247);
      heff_drop(v_es_248);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    }
  }
  case TAG_CondBool: {
    heff_drop(v_info_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_CondNot: {
    V v_c_2434 = heff_field(v_x2_241, 0);
    HeffT3 v_t_2435 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(v_info_240, v_c_2434));
    {
      V v_field_2437 = v_t_2435.f[1];
      V v_field_2438 = v_t_2435.f[2];
      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
      if ((v_tag_2436 == ((int64_t)0ULL))) {
        V v_r_2439 = v_field_2437;
        V v_yes_2440 = v_field_2438;
        V v_t_2441 = heff_bool(!(heff_dup(v_yes_2440) == NTAG(TAG_True)));
        heff_drop(v_yes_2440);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_r_2439, v_t_2441}});
      } else {
        heff_drop(v_field_2437);
        heff_drop(v_field_2438);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  }
  case TAG_CondIf: {
    heff_drop(v_info_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_CondLet: {
    heff_drop(v_info_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2ecompile_2ebounds_2eneedAt_24cpr(V v_info_240, V v_env_241, V v_p_242, V v_fl_243, V v_es_244) {
top: ;
  switch (heff_tag_of(v_p_242)) {
  case TAG_ArrayIndex: {
    switch (heff_tag_of(v_es_244)) {
    case TAG_Nil: {
      heff_drop(v_info_240);
      heff_drop(v_env_241);
      heff_drop(v_fl_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_es_244, 0);
      V v_es2_246 = heff_field(v_es_244, 1);
      switch (heff_tag_of(v_es2_246)) {
      case TAG_Nil: {
        heff_drop(v_info_240);
        heff_drop(v_env_241);
        heff_drop(v_fl_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_i_247 = heff_field(v_es2_246, 0);
        V v_t_249 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_245));
        V v_t_2412;
        switch (heff_tag_of(v_i_247)) {
        case TAG_RBox: {
          V v_e_2411 = heff_field(v_i_247, 1);
          v_t_2412 = (g_heff_2ecompile_2ebounds_2evarOf(v_e_2411));
          break;
        }
        default: {
          v_t_2412 = (g_heff_2ecompile_2ebounds_2evarOf(v_i_247));
          break;
        }
        }
        HEFF_LAST return g_heff_2ecompile_2ebounds_2eneedOf_24cpr(v_info_240, v_env_241, v_fl_243, v_t_249, v_t_2412);
      }
      default: return ((HeffT2){{heff_nomatch(v_es2_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_es_244)}});
    }
  }
  case TAG_ArrayPeek: {
    switch (heff_tag_of(v_es_244)) {
    case TAG_Nil: {
      heff_drop(v_info_240);
      heff_drop(v_env_241);
      heff_drop(v_fl_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_2413 = heff_field(v_es_244, 0);
      V v_es2_2414 = heff_field(v_es_244, 1);
      switch (heff_tag_of(v_es2_2414)) {
      case TAG_Nil: {
        heff_drop(v_info_240);
        heff_drop(v_env_241);
        heff_drop(v_fl_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_i_2415 = heff_field(v_es2_2414, 0);
        V v_t_2417 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_2413));
        V v_t_2420;
        switch (heff_tag_of(v_i_2415)) {
        case TAG_RBox: {
          V v_e_2419 = heff_field(v_i_2415, 1);
          v_t_2420 = (g_heff_2ecompile_2ebounds_2evarOf(v_e_2419));
          break;
        }
        default: {
          v_t_2420 = (g_heff_2ecompile_2ebounds_2evarOf(v_i_2415));
          break;
        }
        }
        HEFF_LAST return g_heff_2ecompile_2ebounds_2eneedOf_24cpr(v_info_240, v_env_241, v_fl_243, v_t_2417, v_t_2420);
      }
      default: return ((HeffT2){{heff_nomatch(v_es2_2414)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_es_244)}});
    }
  }
  case TAG_ArraySetOwned: {
    switch (heff_tag_of(v_es_244)) {
    case TAG_Nil: {
      heff_drop(v_info_240);
      heff_drop(v_env_241);
      heff_drop(v_fl_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_a_2421 = heff_field(v_es_244, 0);
      V v_es2_2422 = heff_field(v_es_244, 1);
      switch (heff_tag_of(v_es2_2422)) {
      case TAG_Nil: {
        heff_drop(v_info_240);
        heff_drop(v_env_241);
        heff_drop(v_fl_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_i_2423 = heff_field(v_es2_2422, 0);
        V v_t_2425 = (g_heff_2ecompile_2ebounds_2evarOf(v_a_2421));
        V v_t_2428;
        switch (heff_tag_of(v_i_2423)) {
        case TAG_RBox: {
          V v_e_2427 = heff_field(v_i_2423, 1);
          v_t_2428 = (g_heff_2ecompile_2ebounds_2evarOf(v_e_2427));
          break;
        }
        default: {
          v_t_2428 = (g_heff_2ecompile_2ebounds_2evarOf(v_i_2423));
          break;
        }
        }
        HEFF_LAST return g_heff_2ecompile_2ebounds_2eneedOf_24cpr(v_info_240, v_env_241, v_fl_243, v_t_2425, v_t_2428);
      }
      default: return ((HeffT2){{heff_nomatch(v_es2_2422)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_es_244)}});
    }
  }
  default: {
    heff_drop(v_info_240);
    heff_drop(v_env_241);
    heff_drop(v_fl_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  }
}
V g_heff_2ecompile_2ebounds_2escopedSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2escopedSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2escopedSt_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2escopedSt(V v_go_240, V v_info_241, V v_env_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_s_243)) {
  case TAG_CDrop: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CLet: {
    V v_e_246 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CLet = heff_take_reuse_n(v_s_243, 2ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return heff_tag_at_n(v_ru_24s_243_24CLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_env_242, v_e_246}), NTAG(TAG_Nil)});
  }
  case TAG_CDecl: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CSet: {
    V v_e_249 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CSet = heff_take_reuse_n(v_s_243, 2ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return heff_tag_at_n(v_ru_24s_243_24CSet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_env_242, v_e_249}), NTAG(TAG_Nil)});
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CIf: {
    V v_c_2410 = heff_field(v_s_243, 0);
    V v_a_2411 = heff_field(v_s_243, 1);
    V v_b_2412 = heff_field(v_s_243, 2);
    heff_take_n(v_s_243, 7ULL, 3);
    V v_t_2413 = (g_list_2emap_24f1221888634x716224461(heff_dup(v_env_242), v_c_2410));
    HeffT3 v_t_2414 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(heff_dup(v_info_241), v_c_2410));
    V v_t_2420;
    {
      V v_field_2416 = v_t_2414.f[1];
      V v_field_2417 = v_t_2414.f[2];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        V v_r_2418 = v_field_2416;
        V v_x212_2419 = v_field_2417;
        if ((heff_dup(v_x212_2419) == NTAG(TAG_True))) {
          heff_drop(v_x212_2419);
          v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2418, heff_dup(v_env_242)});
        } else {
          heff_drop(v_r_2418);
          heff_drop(v_x212_2419);
          v_t_2420 = heff_dup(v_env_242);
        }
      } else {
        heff_drop(v_field_2416);
        heff_drop(v_field_2417);
        v_t_2420 = heff_dup(v_env_242);
      }
    }
    V v_t_2421 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_t_2420, v_a_2411}));
    HeffT3 v_t_2422 = ({ V a_0 = v_info_241; V a_1 = v_c_2410; HeffT3 r_ = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(a_0, a_1)); heff_drop(v_c_2410); r_; });
    V v_t_2428;
    {
      V v_field_2424 = v_t_2422.f[1];
      V v_field_2425 = v_t_2422.f[2];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_r_2426 = v_field_2424;
        V v_x212_2427 = v_field_2425;
        if ((heff_dup(v_x212_2427) == NTAG(TAG_True))) {
          heff_drop(v_r_2426);
          heff_drop(v_x212_2427);
          v_t_2428 = v_env_242;
        } else {
          heff_drop(v_x212_2427);
          v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2426, v_env_242});
        }
      } else {
        heff_drop(v_field_2424);
        heff_drop(v_field_2425);
        v_t_2428 = v_env_242;
      }
    }
    V v_t_2429 = heff_tr(heff_call(v_go_240, 2, (V[]){v_t_2428, v_b_2412}));
    V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2429));
    return (g_prelude_2e_2b_2b(v_t_2413, v_t_2430));
  }
  case TAG_CSwitch: {
    V v_e_2431 = heff_field(v_s_243, 0);
    V v_arms_2432 = heff_field(v_s_243, 1);
    heff_take_n(v_s_243, 3ULL, 3);
    heff_drop(v_info_241);
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2432));
    V v_t_2447 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2escopedSt_lam0, 2, 2, (V[]){v_go_240, heff_dup(v_env_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2434; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_env_242, v_e_2431}), v_t_2447});
  }
  case TAG_CReturn: {
    V v_e_2448 = heff_field(v_s_243, 0);
    heff_take_n(v_s_243, 1ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_env_242, v_e_2448}), NTAG(TAG_Nil)});
  }
  case TAG_CInPlace: {
    V v_f_2449 = heff_field(v_s_243, 0);
    V v_es_2450 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CInPlace = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    V v_t_2451 = (g_list_2emap_24s215892288x1392224072(heff_dup(v_env_242), v_es_2450));
    return heff_tag_at_n(v_ru_24s_243_24CInPlace, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_env_242, v_f_2449}), v_t_2451});
  }
  case TAG_CRoomed: {
    V v_f_2452 = heff_field(v_s_243, 0);
    V v_es_2453 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CRoomed = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    V v_t_2454 = (g_list_2emap_24s215892288x1392224072(heff_dup(v_env_242), v_es_2453));
    return heff_tag_at_n(v_ru_24s_243_24CRoomed, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_env_242, v_f_2452}), v_t_2454});
  }
  case TAG_CTail: {
    V v_f_2455 = heff_field(v_s_243, 0);
    V v_es_2456 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CTail = heff_take_reuse_n(v_s_243, 3ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072(v_env_242, heff_tag_at_n(v_ru_24s_243_24CTail, TAG_Cons, 2, (V[]){v_f_2455, v_es_2456})));
  }
  case TAG_CLoop: {
    V v_es_2458 = heff_field(v_s_243, 1);
    V v_ru_24s_243_24CLoop = heff_take_reuse_n(v_s_243, 2ULL, 2);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072_24tok2(v_ru_24s_243_24CLoop, v_env_242, v_es_2458));
  }
  case TAG_CLoopTo: {
    heff_take_n(v_s_243, 0ULL, 3);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CLabel: {
    heff_take_n(v_s_243, 0ULL, 1);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_env_242);
    return NTAG(TAG_Nil);
  }
  case TAG_CJump: {
    V v_es_2465 = heff_field(v_s_243, 2);
    heff_take_n(v_s_243, 4ULL, 3);
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    return (g_list_2emap_24s215892288x1392224072(v_env_242, v_es_2465));
  }
  default: return heff_nomatch(v_s_243);
  }
}
V g_heff_2ecompile_2ebounds_2escopedSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2escopedSt(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ebounds_2escopedSt_lam0(V self, V *args) {
  V v_acc_2435 = args[0];
  V v_x_2436 = args[1];
  V v_go_240 = heff_env(self)[0];
  V v_env_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkCArm: {
    V v_body_2443 = heff_field(v_x_2436, 6);
    heff_take_n(v_x_2436, 64ULL, 8);
    v_t_2445 = v_body_2443;
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V v_t_2446 = heff_tr(heff_call(v_go_240, 2, (V[]){v_env_242, v_t_2445}));
  return (g_prelude_2e_2b_2b(v_t_2446, v_acc_2435));
}
V g_heff_2ecompile_2ebounds_2escoped_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2escoped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2escoped_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2escoped(V v_info_240, V v_env_241, V v_ss_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2escoped_clo), 1, (V[]){heff_dup(v_info_240)}));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_242));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2escoped_lam0, 2, 3, (V[]){v_t_243, v_info_240, v_env_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
}
V g_heff_2ecompile_2ebounds_2escoped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2escoped(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ebounds_2escoped_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_t_243 = heff_env(self)[0];
  V v_info_240 = heff_env(self)[1];
  V v_env_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = (g_heff_2ecompile_2ebounds_2escopedSt(v_t_243, v_info_240, v_env_241, v_x_246));
  return (g_prelude_2e_2b_2b(v_t_247, v_acc_245));
}
V g_heff_2ecompile_2ebounds_2ereadsIn_lam0(V self, V *args);
V g_heff_2ecompile_2ebounds_2ereadsIn_lam1(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2ereadsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2ereadsIn_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2ereadsIn(V v_info_240, V v_e_241) {
top: ;
  V v_info_242 = heff_dup(v_info_240);
  V v_defs_243 = heff_take_field(v_info_242, 2);
  V v_arrays_244 = heff_get_n(v_info_242, 1, 3);
  V v_e_245 = heff_dup(v_e_241);
  V v_t_2499;
  switch (heff_tag_of(v_e_245)) {
  case TAG_RLocal: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RDup: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RClo: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RGet: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RGetRaw: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RInt: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RFloat: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RStr: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RBytes: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RFixed: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RF32: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RNTag: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RTag: {
    heff_take_n(v_e_245, 0ULL, 3);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RTagIn: {
    heff_take_n(v_e_245, 0ULL, 4);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RRec: {
    heff_take_n(v_e_245, 0ULL, 3);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RRecIn: {
    heff_take_n(v_e_245, 0ULL, 8);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RField: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RDupE: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RFieldV: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RGetN: {
    heff_take_n(v_e_245, 0ULL, 3);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RFieldU: {
    heff_take_n(v_e_245, 0ULL, 4);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RGetNU: {
    heff_take_n(v_e_245, 0ULL, 5);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RWord: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RTakeField: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RGetLabel: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RPrimFn: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RPrim: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RLam: {
    heff_take_n(v_e_245, 0ULL, 4);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RCall: {
    heff_take_n(v_e_245, 0ULL, 4);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RApply: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RBool: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RAbandon: {
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RBox: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RUnbox: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RPeek: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RPrimU: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RPrimAt: {
    V v_e1_2482 = heff_field(v_e_245, 0);
    V v_r_2483 = heff_field(v_e_245, 1);
    V v_e3_2484 = heff_field(v_e_245, 2);
    heff_take_n(v_e_245, 7ULL, 3);
    switch (heff_tag_of(v_e1_2482)) {
    case TAG_ArrayIndexInAny: {
      switch (heff_tag_of(v_e3_2484)) {
      case TAG_Nil: {
        heff_drop(v_defs_243);
        heff_drop(v_arrays_244);
        heff_drop(v_r_2483);
        v_t_2499 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_a_2485 = heff_field(v_e3_2484, 0);
        V v_ru_24e3_2484_24Cons = heff_take_reuse_n(v_e3_2484, 1ULL, 2);
        HeffT2 v_t_2487 = ({ V a_0 = v_a_2485; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(a_0)); heff_drop(v_a_2485); r_; });
        {
          V v_field_2489 = v_t_2487.f[1];
          int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
          if ((v_tag_2488 == ((int64_t)0ULL))) {
            V v_y_2490 = v_field_2489;
            V v_x1_2492 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2ebounds_2ereadsIn_lam0, 1, 2, (V[]){v_defs_243, v_y_2490}), v_arrays_244));
            switch (heff_tag_of(v_x1_2492)) {
            case TAG_Nil: {
              heff_drop(v_r_2483);
              heff_drop_cell(v_ru_24e3_2484_24Cons, 2);
              v_t_2499 = NTAG(TAG_Nil);
              break;
            }
            case TAG_Cons: {
              V v_x_2493 = heff_field(v_x1_2492, 0);
              V v_ru_24x1_2492_24Cons = heff_take_reuse_n(v_x1_2492, 1ULL, 2);
              v_t_2499 = heff_tag_at_n(v_ru_24e3_2484_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_2492_24Cons, TAG_MkPair, 2, (V[]){v_x_2493, v_r_2483}), NTAG(TAG_Nil)});
              break;
            }
            default: heff_nomatch(v_x1_2492);
            }
          } else {
            heff_drop(v_defs_243);
            heff_drop(v_arrays_244);
            heff_drop(v_r_2483);
            heff_drop_cell(v_ru_24e3_2484_24Cons, 2);
            heff_drop(v_field_2489);
            v_t_2499 = NTAG(TAG_Nil);
          }
        }
        break;
      }
      default: heff_nomatch(v_e3_2484);
      }
      break;
    }
    default: {
      heff_drop(v_defs_243);
      heff_drop(v_arrays_244);
      heff_drop(v_e1_2482);
      heff_drop(v_r_2483);
      heff_drop(v_e3_2484);
      v_t_2499 = NTAG(TAG_Nil);
      break;
    }
    }
    break;
  }
  case TAG_RFixU: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RF32U: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  case TAG_RF64U: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_defs_243);
    heff_drop(v_arrays_244);
    v_t_2499 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_e_245);
  }
  V v_f_24100 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2ereadsIn_clo), 1, (V[]){v_info_240}));
  V v_xs_24101 = (g_heff_2ecompile_2eowned_2ekids(v_e_241));
  V v_t_24102 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24101));
  V v_t_24106 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2ereadsIn_lam1, 2, 1, (V[]){v_f_24100}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24102; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24102); r_; });
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_2499, v_t_24106);
}
V g_heff_2ecompile_2ebounds_2ereadsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2ereadsIn(a[0], a[1]);
}
V g_heff_2ecompile_2ebounds_2ereadsIn_lam0(V self, V *args) {
  V v_b_2491 = args[0];
  V v_defs_243 = heff_env(self)[0];
  V v_y_2490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2ebounds_2esameAs(v_defs_243, NTAG(TAG_Nil), v_b_2491, heff_tag_n(TAG_RLocal, 1, (V[]){v_y_2490})));
}
V g_heff_2ecompile_2ebounds_2ereadsIn_lam1(V self, V *args) {
  V v_acc_24103 = args[0];
  V v_x_24104 = args[1];
  V v_f_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24105 = heff_tr(heff_call(v_f_24100, 1, (V[]){v_x_24104}));
  return (g_prelude_2e_2b_2b(v_t_24105, v_acc_24103));
}
Clo g_heff_2ecompile_2ebounds_2eownedSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eownedSt_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2eownedSt(V v_s_240) {
top: ;
  switch (heff_tag_of(v_s_240)) {
  case TAG_CDrop: {
    heff_take_n(v_s_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_CLet: {
    heff_take_n(v_s_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_CDecl: {
    heff_take_n(v_s_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_CSet: {
    V v_x_245 = heff_field(v_s_240, 0);
    V v_s2_246 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24CSet = heff_take_reuse_n(v_s_240, 3ULL, 2);
    switch (heff_tag_of(v_s2_246)) {
    case TAG_RLocal: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RDup: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RClo: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RGet: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RGetRaw: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RInt: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RFloat: {
      heff_take_na(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RStr: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RBytes: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RFixed: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RF32: {
      heff_take_na(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RNTag: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RTag: {
      heff_take_n(v_s2_246, 0ULL, 3);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RTagIn: {
      heff_take_n(v_s2_246, 0ULL, 4);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RRec: {
      heff_take_n(v_s2_246, 0ULL, 3);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RRecIn: {
      heff_take_n(v_s2_246, 0ULL, 8);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RField: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RDupE: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RFieldV: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RGetN: {
      heff_take_n(v_s2_246, 0ULL, 3);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RFieldU: {
      heff_take_n(v_s2_246, 0ULL, 4);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RGetNU: {
      heff_take_n(v_s2_246, 0ULL, 5);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RWord: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RTakeField: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RGetLabel: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RPrimFn: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RPrim: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RLam: {
      heff_take_n(v_s2_246, 0ULL, 4);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RCall: {
      heff_take_n(v_s2_246, 0ULL, 4);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RApply: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RBool: {
      heff_take_n(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RAbandon: {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RBox: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RUnbox: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RPeek: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RPrimU: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RPrimAt: {
      V v_s21_2483 = heff_field(v_s2_246, 0);
      V v_r_2484 = heff_field(v_s2_246, 1);
      V v_s23_2485 = heff_field(v_s2_246, 2);
      heff_take_n(v_s2_246, 7ULL, 3);
      switch (heff_tag_of(v_s21_2483)) {
      case TAG_ArrayOwn: {
        switch (heff_tag_of(v_s23_2485)) {
        case TAG_Nil: {
          heff_drop(v_x_245);
          heff_drop_cell(v_ru_24s_240_24CSet, 2);
          heff_drop(v_r_2484);
          return NTAG(TAG_Nil);
        }
        case TAG_Cons: {
          V v_s231_2486 = heff_field(v_s23_2485, 0);
          V v_s232_2487 = heff_field(v_s23_2485, 1);
          V v_ru_24s23_2485_24Cons = heff_take_reuse_n(v_s23_2485, 3ULL, 2);
          switch (heff_tag_of(v_s231_2486)) {
          case TAG_RLocal: {
            V v_y_2488 = heff_field(v_s231_2486, 0);
            heff_take_n(v_s231_2486, 1ULL, 1);
            switch (heff_tag_of(v_s232_2487)) {
            case TAG_Nil: {
              if (heff_strEq_c_lent(v_x_245, v_y_2488, 2)) {
                return heff_tag_at_n(v_ru_24s_240_24CSet, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24s23_2485_24Cons, TAG_MkPair, 2, (V[]){v_x_245, v_r_2484}), NTAG(TAG_Nil)});
              } else {
                heff_drop(v_x_245);
                heff_drop_cell(v_ru_24s_240_24CSet, 2);
                heff_drop(v_r_2484);
                heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
                return NTAG(TAG_Nil);
              }
            }
            case TAG_Cons: {
              heff_take_n(v_s232_2487, 0ULL, 2);
              heff_drop(v_x_245);
              heff_drop_cell(v_ru_24s_240_24CSet, 2);
              heff_drop(v_r_2484);
              heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
              heff_drop(v_y_2488);
              return NTAG(TAG_Nil);
            }
            default: return heff_nomatch(v_s232_2487);
            }
          }
          case TAG_RDup: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RClo: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RGet: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RGetRaw: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RInt: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RFloat: {
            heff_take_na(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RStr: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RBytes: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RFixed: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RF32: {
            heff_take_na(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RNTag: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RTag: {
            heff_take_n(v_s231_2486, 0ULL, 3);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RTagIn: {
            heff_take_n(v_s231_2486, 0ULL, 4);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RRec: {
            heff_take_n(v_s231_2486, 0ULL, 3);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RRecIn: {
            heff_take_n(v_s231_2486, 0ULL, 8);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RField: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RDupE: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RFieldV: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RGetN: {
            heff_take_n(v_s231_2486, 0ULL, 3);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RFieldU: {
            heff_take_n(v_s231_2486, 0ULL, 4);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RGetNU: {
            heff_take_n(v_s231_2486, 0ULL, 5);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RWord: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RTakeField: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RGetLabel: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RPrimFn: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RPrim: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RLam: {
            heff_take_n(v_s231_2486, 0ULL, 4);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RCall: {
            heff_take_n(v_s231_2486, 0ULL, 4);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RApply: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RBool: {
            heff_take_n(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RAbandon: {
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RBox: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RUnbox: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RPeek: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RPrimU: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RPrimAt: {
            heff_take_n(v_s231_2486, 0ULL, 3);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RFixU: {
            heff_take_n(v_s231_2486, 0ULL, 2);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RF32U: {
            heff_take_na(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_RF64U: {
            heff_take_na(v_s231_2486, 0ULL, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24s_240_24CSet, 2);
            heff_drop(v_r_2484);
            heff_drop(v_s232_2487);
            heff_drop_cell(v_ru_24s23_2485_24Cons, 2);
            return NTAG(TAG_Nil);
          }
          default: return heff_nomatch(v_s231_2486);
          }
        }
        default: return heff_nomatch(v_s23_2485);
        }
      }
      default: {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24s_240_24CSet, 2);
        heff_drop(v_s21_2483);
        heff_drop(v_r_2484);
        heff_drop(v_s23_2485);
        return NTAG(TAG_Nil);
      }
      }
    }
    case TAG_RFixU: {
      heff_take_n(v_s2_246, 0ULL, 2);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RF32U: {
      heff_take_na(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_RF64U: {
      heff_take_na(v_s2_246, 0ULL, 1);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24s_240_24CSet, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_s2_246);
    }
  }
  case TAG_CAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_CIf: {
    heff_take_n(v_s_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_CSwitch: {
    heff_take_n(v_s_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_CReturn: {
    heff_take_n(v_s_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_CInPlace: {
    heff_take_n(v_s_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_CRoomed: {
    heff_take_n(v_s_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_CTail: {
    heff_take_n(v_s_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_CLoop: {
    heff_take_n(v_s_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_CLoopTo: {
    heff_take_n(v_s_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_CLabel: {
    heff_take_n(v_s_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_CJump: {
    heff_take_n(v_s_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_s_240);
  }
}
V g_heff_2ecompile_2ebounds_2eownedSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eownedSt(a[0]);
}
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_lam0(V self, V *args);
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_lam1(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_RLocal: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RDup: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RClo: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RGet: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RGetRaw: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RInt: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RFloat: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RStr: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RBytes: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RFixed: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RF32: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RNTag: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RTag: {
    V v_t_2417 = heff_field(v_x2_243, 0);
    V v_b_2418 = heff_field(v_x2_243, 1);
    V v_es_2419 = heff_field(v_x2_243, 2);
    V v_ru_24x2_243_24RTag = heff_take_reuse_n(v_x2_243, 7ULL, 3);
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_2421 = (g_list_2emap(v_t_2420, v_es_2419));
    V v_a_2422 = heff_tag_at_n(v_ru_24x2_243_24RTag, TAG_RTag, 3, (V[]){v_t_2417, v_b_2418, v_t_2421});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2422);
  }
  case TAG_RTagIn: {
    V v_e_2423 = heff_field(v_x2_243, 0);
    V v_t_2424 = heff_field(v_x2_243, 1);
    V v_b_2425 = heff_field(v_x2_243, 2);
    V v_es_2426 = heff_field(v_x2_243, 3);
    V v_ru_24x2_243_24RTagIn = heff_take_reuse_n(v_x2_243, 15ULL, 4);
    V v_t_2427 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2423));
    V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_2429 = (g_list_2emap(v_t_2428, v_es_2426));
    V v_a_2430 = heff_tag_at_n(v_ru_24x2_243_24RTagIn, TAG_RTagIn, 4, (V[]){v_t_2427, v_t_2424, v_b_2425, v_t_2429});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2430);
  }
  case TAG_RRec: {
    V v_ls_2431 = heff_field(v_x2_243, 0);
    V v_b_2432 = heff_field(v_x2_243, 1);
    V v_es_2433 = heff_field(v_x2_243, 2);
    V v_ru_24x2_243_24RRec = heff_take_reuse_n(v_x2_243, 7ULL, 3);
    V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_2435 = (g_list_2emap(v_t_2434, v_es_2433));
    V v_a_2436 = heff_tag_at_n(v_ru_24x2_243_24RRec, TAG_RRec, 3, (V[]){v_ls_2431, v_b_2432, v_t_2435});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2436);
  }
  case TAG_RRecIn: {
    V v_x_2437 = heff_field(v_x2_243, 0);
    V v_n_2438 = heff_field(v_x2_243, 1);
    V v_k_2439 = heff_field(v_x2_243, 2);
    V v_g_2440 = heff_field(v_x2_243, 3);
    V v_s_2441 = heff_field(v_x2_243, 4);
    V v_ls_2442 = heff_field(v_x2_243, 5);
    V v_fs_2443 = heff_field(v_x2_243, 6);
    V v_sure_2444 = heff_field(v_x2_243, 7);
    V v_ru_24x2_243_24RRecIn = heff_take_reuse_n(v_x2_243, 255ULL, 8);
    V v_t_2453 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_lam0, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_fs_2443));
    V v_a_2454 = heff_tag_at_n(v_ru_24x2_243_24RRecIn, TAG_RRecIn, 8, (V[]){v_x_2437, v_n_2438, v_k_2439, v_g_2440, v_s_2441, v_ls_2442, v_t_2453, v_sure_2444});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2454);
  }
  case TAG_RField: {
    V v_e_2455 = heff_field(v_x2_243, 0);
    V v_i_2456 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RField = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2457 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2455));
    V v_a_2458 = heff_tag_at_n(v_ru_24x2_243_24RField, TAG_RField, 2, (V[]){v_t_2457, v_i_2456});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2458);
  }
  case TAG_RDupE: {
    V v_e_2459 = heff_field(v_x2_243, 0);
    V v_ru_24x2_243_24RDupE = heff_take_reuse_n(v_x2_243, 1ULL, 1);
    V v_t_2460 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2459));
    V v_a_2461 = heff_tag_at_n(v_ru_24x2_243_24RDupE, TAG_RDupE, 1, (V[]){v_t_2460});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2461);
  }
  case TAG_RFieldV: {
    V v_e_2462 = heff_field(v_x2_243, 0);
    V v_i_2463 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RFieldV = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2464 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2462));
    V v_a_2465 = heff_tag_at_n(v_ru_24x2_243_24RFieldV, TAG_RFieldV, 2, (V[]){v_t_2464, v_i_2463});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2465);
  }
  case TAG_RGetN: {
    V v_e_2466 = heff_field(v_x2_243, 0);
    V v_i_2467 = heff_field(v_x2_243, 1);
    V v_n_2468 = heff_field(v_x2_243, 2);
    V v_ru_24x2_243_24RGetN = heff_take_reuse_n(v_x2_243, 7ULL, 3);
    V v_t_2469 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2466));
    V v_a_2470 = heff_tag_at_n(v_ru_24x2_243_24RGetN, TAG_RGetN, 3, (V[]){v_t_2469, v_i_2467, v_n_2468});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2470);
  }
  case TAG_RFieldU: {
    V v_r_2471 = heff_field(v_x2_243, 0);
    V v_s_2472 = heff_field(v_x2_243, 1);
    V v_e_2473 = heff_field(v_x2_243, 2);
    V v_i_2474 = heff_field(v_x2_243, 3);
    V v_ru_24x2_243_24RFieldU = heff_take_reuse_n(v_x2_243, 15ULL, 4);
    V v_t_2475 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2473));
    V v_a_2476 = heff_tag_at_n(v_ru_24x2_243_24RFieldU, TAG_RFieldU, 4, (V[]){v_r_2471, v_s_2472, v_t_2475, v_i_2474});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2476);
  }
  case TAG_RGetNU: {
    V v_r_2477 = heff_field(v_x2_243, 0);
    V v_s_2478 = heff_field(v_x2_243, 1);
    V v_e_2479 = heff_field(v_x2_243, 2);
    V v_i_2480 = heff_field(v_x2_243, 3);
    V v_n_2481 = heff_field(v_x2_243, 4);
    V v_ru_24x2_243_24RGetNU = heff_take_reuse_n(v_x2_243, 31ULL, 5);
    V v_t_2482 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2479));
    V v_a_2483 = heff_tag_at_n(v_ru_24x2_243_24RGetNU, TAG_RGetNU, 5, (V[]){v_r_2477, v_s_2478, v_t_2482, v_i_2480, v_n_2481});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2483);
  }
  case TAG_RWord: {
    V v_r_2484 = heff_field(v_x2_243, 0);
    V v_e_2485 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RWord = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2486 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2485));
    V v_a_2487 = heff_tag_at_n(v_ru_24x2_243_24RWord, TAG_RWord, 2, (V[]){v_r_2484, v_t_2486});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2487);
  }
  case TAG_RTakeField: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RGetLabel: {
    V v_e_2490 = heff_field(v_x2_243, 0);
    V v_l_2491 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RGetLabel = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2492 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_2490));
    V v_a_2493 = heff_tag_at_n(v_ru_24x2_243_24RGetLabel, TAG_RGetLabel, 2, (V[]){v_t_2492, v_l_2491});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2493);
  }
  case TAG_RPrimFn: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RPrim: {
    V v_p_2495 = heff_field(v_x2_243, 0);
    V v_es_2496 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RPrim = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_2498 = (g_list_2emap(v_t_2497, v_es_2496));
    V v_a_2499 = heff_tag_at_n(v_ru_24x2_243_24RPrim, TAG_RPrim, 2, (V[]){v_p_2495, v_t_2498});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_2499);
  }
  case TAG_RLam: {
    V v_xs_24100 = heff_field(v_x2_243, 0);
    V v_fv_24101 = heff_field(v_x2_243, 1);
    V v_held_24102 = heff_field(v_x2_243, 2);
    V v_body_24103 = heff_field(v_x2_243, 3);
    V v_ru_24x2_243_24RLam = heff_take_reuse_n(v_x2_243, 15ULL, 4);
    V v_t_24104 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_24105 = (g_list_2emap(v_t_24104, v_held_24102));
    V v_a_24106 = heff_tag_at_n(v_ru_24x2_243_24RLam, TAG_RLam, 4, (V[]){v_xs_24100, v_fv_24101, v_t_24105, v_body_24103});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24106);
  }
  case TAG_RCall: {
    V v_g_24107 = heff_field(v_x2_243, 0);
    V v_tr_24108 = heff_field(v_x2_243, 1);
    V v_w_24109 = heff_field(v_x2_243, 2);
    V v_args_24110 = heff_field(v_x2_243, 3);
    V v_ru_24x2_243_24RCall = heff_take_reuse_n(v_x2_243, 15ULL, 4);
    V v_f_24111 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_24122 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_lam1, 1, 1, (V[]){v_f_24111}), v_args_24110));
    V v_a_24123 = heff_tag_at_n(v_ru_24x2_243_24RCall, TAG_RCall, 4, (V[]){v_g_24107, v_tr_24108, v_w_24109, v_t_24122});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24123);
  }
  case TAG_RApply: {
    V v_g_24124 = heff_field(v_x2_243, 0);
    V v_es_24125 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RApply = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_24126 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_g_24124));
    V v_t_24127 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_24128 = (g_list_2emap(v_t_24127, v_es_24125));
    V v_a_24129 = heff_tag_at_n(v_ru_24x2_243_24RApply, TAG_RApply, 2, (V[]){v_t_24126, v_t_24128});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24129);
  }
  case TAG_RBool: {
    V v_c_24130 = heff_field(v_x2_243, 0);
    V v_ru_24x2_243_24RBool = heff_take_reuse_n(v_x2_243, 1ULL, 1);
    V v_t_24131 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_24132 = (g_heff_2ecompile_2eowned_2emapCond(v_t_24131, v_c_24130));
    V v_a_24133 = heff_tag_at_n(v_ru_24x2_243_24RBool, TAG_RBool, 1, (V[]){v_t_24132});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24133);
  }
  case TAG_RAbandon: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RBox: {
    V v_r_24134 = heff_field(v_x2_243, 0);
    V v_e_24135 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RBox = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_24136 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_24135));
    V v_a_24137 = heff_tag_at_n(v_ru_24x2_243_24RBox, TAG_RBox, 2, (V[]){v_r_24134, v_t_24136});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24137);
  }
  case TAG_RUnbox: {
    V v_r_24138 = heff_field(v_x2_243, 0);
    V v_e_24139 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RUnbox = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_24140 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_24139));
    V v_a_24141 = heff_tag_at_n(v_ru_24x2_243_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_24138, v_t_24140});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24141);
  }
  case TAG_RPeek: {
    V v_r_24142 = heff_field(v_x2_243, 0);
    V v_e_24143 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RPeek = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_24144 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_24143));
    V v_a_24145 = heff_tag_at_n(v_ru_24x2_243_24RPeek, TAG_RPeek, 2, (V[]){v_r_24142, v_t_24144});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24145);
  }
  case TAG_RPrimU: {
    V v_p_24146 = heff_field(v_x2_243, 0);
    V v_es_24147 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24RPrimU = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_24148 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_24149 = (g_list_2emap(v_t_24148, v_es_24147));
    V v_a_24150 = heff_tag_at_n(v_ru_24x2_243_24RPrimU, TAG_RPrimU, 2, (V[]){v_p_24146, v_t_24149});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24150);
  }
  case TAG_RPrimAt: {
    V v_p_24151 = heff_field(v_x2_243, 0);
    V v_r_24152 = heff_field(v_x2_243, 1);
    V v_es_24153 = heff_field(v_x2_243, 2);
    V v_ru_24x2_243_24RPrimAt = heff_take_reuse_n(v_x2_243, 7ULL, 3);
    V v_t_24154 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}));
    V v_t_24155 = (g_list_2emap(v_t_24154, v_es_24153));
    V v_a_24156 = heff_tag_at_n(v_ru_24x2_243_24RPrimAt, TAG_RPrimAt, 3, (V[]){v_p_24151, v_r_24152, v_t_24155});
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_a_24156);
  }
  case TAG_RFixU: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RF32U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  case TAG_RF64U: {
    HEFF_LAST return g_heff_2ecompile_2ebounds_2eunchecked(v_lit_240, v_lit_241, v_lit_242, v_x2_243);
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_lam0(V self, V *args) {
  V v_p_2445 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2448;
  switch (heff_tag_of(v_p_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_dup(heff_field(v_p_2445, 0));
    v_t_2448 = v_x_2446;
    break;
  }
  default: heff_nomatch(v_p_2445);
  }
  V v_t_2451;
  switch (heff_tag_of(v_p_2445)) {
  case TAG_MkPair: {
    V v_y_2450 = heff_field(v_p_2445, 1);
    heff_take_n(v_p_2445, 2ULL, 2);
    v_t_2451 = v_y_2450;
    break;
  }
  default: heff_nomatch(v_p_2445);
  }
  V v_t_2452 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(v_lit_240, v_lit_241, v_lit_242, v_t_2451));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_t_2452});
}
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_lam1(V self, V *args) {
  V v_a_24112 = args[0];
  V v_f_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24112)) {
  case TAG_Given: {
    V v_e_24113 = heff_field(v_a_24112, 0);
    V v_ru_24a_24112_24Given = heff_take_reuse_n(v_a_24112, 1ULL, 1);
    V v_t_24114 = heff_tr(heff_call(v_f_24111, 1, (V[]){v_e_24113}));
    return heff_tag_at_n(v_ru_24a_24112_24Given, TAG_Given, 1, (V[]){v_t_24114});
  }
  case TAG_GivenU: {
    V v_r_24115 = heff_field(v_a_24112, 0);
    V v_e_24116 = heff_field(v_a_24112, 1);
    V v_ru_24a_24112_24GivenU = heff_take_reuse_n(v_a_24112, 3ULL, 2);
    V v_t_24117 = heff_tr(heff_call(v_f_24111, 1, (V[]){v_e_24116}));
    return heff_tag_at_n(v_ru_24a_24112_24GivenU, TAG_GivenU, 2, (V[]){v_r_24115, v_t_24117});
  }
  case TAG_LentVar: {
    heff_drop(v_f_24111);
    return v_a_24112;
  }
  case TAG_LentValue: {
    V v_e_24120 = heff_field(v_a_24112, 0);
    V v_ru_24a_24112_24LentValue = heff_take_reuse_n(v_a_24112, 1ULL, 1);
    V v_t_24121 = heff_tr(heff_call(v_f_24111, 1, (V[]){v_e_24120}));
    return heff_tag_at_n(v_ru_24a_24112_24LentValue, TAG_LentValue, 1, (V[]){v_t_24121});
  }
  default: return heff_nomatch(v_a_24112);
  }
}
Clo g_heff_2ecompile_2ebounds_2efixStmts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2efixStmts_entry, 5, 0};

V g_heff_2ecompile_2ebounds_2efixStmts(V v_info_240, V v_flat_241, V v_toCopy_242, V v_env_243, V v_ss_244) {
top: ;
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2efixStmts_clo), 3, (V[]){heff_dup(v_info_240), heff_dup(v_flat_241), heff_dup(v_toCopy_242)}));
  return ({ V a_0 = v_t_245; V a_1 = v_info_240; V a_2 = v_flat_241; V a_3 = v_toCopy_242; V a_4 = v_env_243; V a_5 = v_ss_244; V r_ = (g_list_2emap_24s1417440002x1148747973(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_toCopy_242); r_; });
}
V g_heff_2ecompile_2ebounds_2efixStmts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2efixStmts(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2ebounds_2enubS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2enubS_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2enubS(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2ebounds_2eelemS(v_x_242, v_acc_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_acc_240;
      V t_1 = v_xs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_240});
      V t_1 = v_xs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ebounds_2enubS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2enubS(a[0], a[1]);
}
Clo g_heff_2ecompile_2ebounds_2echeckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2echeckOf_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2echeckOf(V v_ns_240, V v_rs_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s1700608285x1639860354(heff_dup(v_ns_240)));
  V v_t_243 = (g_heff_2ecompile_2ebounds_2enubS(NTAG(TAG_Nil), v_t_242));
  V v_t_244 = (g_list_2emap_24s1353477632x1698603588(v_t_243));
  V v_t_245 = (g_list_2efoldl_24f380832527x418567417(NTAG(TAG_Nil), NTAG(TAG_Nil), v_ns_240));
  V v_t_246 = (g_list_2efoldl_24s1922266401x1990263591(NTAG(TAG_Nil), v_t_245));
  V v_t_247 = (g_list_2emap_24s1136209598x1881409718(v_rs_241));
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_244, v_t_248));
  return ({ V a_0 = v_t_249; V r_ = (g_heff_2ecompile_2ebounds_2eallOf(a_0)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2ebounds_2echeckOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2echeckOf(a[0], a[1]);
}