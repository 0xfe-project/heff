// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FromLam 36578
#define TAG_FromNone 27319
#define TAG_FromVar 46193
#define TAG_MkArm 55352
#define TAG_Tip 31527
#define TAG_ToOut 34591
#define TAG_ToVar 40696
#define LBL_after 294093302
#define LBL_applies 1586106057
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_bad 306815
#define LBL_bodies 563425515
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_classes 1085478500
#define LBL_col 308218
#define LBL_entries 787768015
#define LBL_esc 310255
#define LBL_fl 10029
#define LBL_flows 298885407
#define LBL_fvs 311325
#define LBL_given 299725719
#define LBL_grew 9676708
#define LBL_group 299987609
#define LBL_grown 299987669
#define LBL_head 9693863
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_known 303562589
#define LBL_labels 836724522
#define LBL_labs 9809229
#define LBL_lams 9809570
#define LBL_n 328
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_outs 9918380
#define LBL_params 951713969
#define LBL_st 10440
#define LBL_supply 1056026650
#define LBL_tag 324116
#define LBL_vars 10107635
static uint32_t shape_bad__given[] = {LBL_bad, LBL_given};
static uint32_t shape_bodies__grown__supply[] = {LBL_bodies, LBL_grown, LBL_supply};
static uint32_t shape_col__st__classes__known__given[] = {LBL_col, LBL_st, LBL_classes, LBL_known, LBL_given};
static uint32_t shape_fl__op__bad__esc__grew__lams[] = {LBL_fl, LBL_op, LBL_bad, LBL_esc, LBL_grew, LBL_lams};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_key__n__labels[] = {LBL_key, LBL_n, LBL_labels};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__known__entries[] = {LBL_keys, LBL_known, LBL_entries};
static uint32_t shape_labels__vars[] = {LBL_labels, LBL_vars};
static uint32_t shape_labs__vars__applies__lams[] = {LBL_labs, LBL_vars, LBL_applies, LBL_lams};
static uint32_t shape_n__flows__outs__calls__lams[] = {LBL_n, LBL_flows, LBL_outs, LBL_calls, LBL_lams};
static uint32_t shape_params__body[] = {LBL_params, LBL_body};
V g_heff_2ecompile_2ecallarity_2eextendAt(V, V);
V g_heff_2ecompile_2ecallarity_2eextendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextendAt_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V, V);
V g_heff_2ecompile_2edefun_2eaddLabel(V, V, V);
V g_heff_2ecompile_2edefun_2eaddLabel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eaddLabel_clo;
V g_heff_2ecompile_2edefun_2eallGiven(V, V, V);
V g_heff_2ecompile_2edefun_2eallGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eallGiven_clo;
HeffT2 g_heff_2ecompile_2edefun_2eanalyse_24cpr(V, V, V);
V g_heff_2ecompile_2edefun_2eappCol(V, V, V, V, V);
V g_heff_2ecompile_2edefun_2eappCol_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eappCol_clo;
HeffT2 g_heff_2ecompile_2edefun_2eargsAs_24cpr(V, V, V, V);
V g_heff_2ecompile_2edefun_2eargsStep(V, V, V, V);
V g_heff_2ecompile_2edefun_2eargsStep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eargsStep_clo;
V g_heff_2ecompile_2edefun_2eargsTo(V, V, V, V);
V g_heff_2ecompile_2edefun_2eargsTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eargsTo_clo;
V g_heff_2ecompile_2edefun_2earityOfClass(V, V);
V g_heff_2ecompile_2edefun_2earityOfClass_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2earityOfClass_clo;
V g_heff_2ecompile_2edefun_2ecolE(V, V, V, V);
V g_heff_2ecompile_2edefun_2ecolE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2ecolE_clo;
V g_heff_2ecompile_2edefun_2edefOut(V, V);
V g_heff_2ecompile_2edefun_2edefOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2edefOut_clo;
V g_heff_2ecompile_2edefun_2eescape(V, V);
V g_heff_2ecompile_2edefun_2eescape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eescape_clo;
V g_heff_2ecompile_2edefun_2eextGo(V, V);
V g_heff_2ecompile_2edefun_2eextGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eextGo_clo;
V g_heff_2ecompile_2edefun_2eextLam(V, V, V, V, V);
V g_heff_2ecompile_2edefun_2eextLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eextLam_clo;
V g_heff_2ecompile_2edefun_2eextLam_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2edefun_2eextLam_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eextLam_24tok2_clo;
V g_heff_2ecompile_2edefun_2eflowInto(V, V, V, V);
V g_heff_2ecompile_2edefun_2eflowInto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eflowInto_clo;
V g_heff_2ecompile_2edefun_2egivenUse(V, V, V, V);
V g_heff_2ecompile_2edefun_2egivenUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2egivenUse_clo;
V g_heff_2ecompile_2edefun_2egivenW(V, V);
V g_heff_2ecompile_2edefun_2egivenW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2egivenW_clo;
V g_heff_2ecompile_2edefun_2egroupOf(V, V, V, V);
V g_heff_2ecompile_2edefun_2egroupOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2egroupOf_clo;
HeffT2 g_heff_2ecompile_2edefun_2egrow_24cpr(V, V, V);
V g_heff_2ecompile_2edefun_2egrownBy(V, V, V, V);
V g_heff_2ecompile_2edefun_2egrownBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2egrownBy_clo;
V g_heff_2ecompile_2edefun_2ehandsW(V, V);
V g_heff_2ecompile_2edefun_2ehandsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2ehandsW_clo;
V g_heff_2ecompile_2edefun_2einto(V, V, V);
V g_heff_2ecompile_2edefun_2einto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2einto_clo;
V g_heff_2ecompile_2edefun_2eknownOf(V, V, V);
V g_heff_2ecompile_2edefun_2eknownOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eknownOf_clo;
V g_heff_2ecompile_2edefun_2elamAmong(V);
V g_heff_2ecompile_2edefun_2elamAmong_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2elamAmong_clo;
V g_heff_2ecompile_2edefun_2emarkBad(V, V);
V g_heff_2ecompile_2edefun_2emarkBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2emarkBad_clo;
V g_heff_2ecompile_2edefun_2enumberedGo(V, V);
V g_heff_2ecompile_2edefun_2enumberedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2enumberedGo_clo;
V g_heff_2ecompile_2edefun_2enumberedGo_24dps(V, V, V);
V g_heff_2ecompile_2edefun_2enumberedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2enumberedGo_24dps_clo;
HeffT2 g_heff_2ecompile_2edefun_2eplanOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2edefun_2erw(V, V);
V g_heff_2ecompile_2edefun_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2erw_clo;
HeffT2 g_heff_2ecompile_2edefun_2esolve_24cpr(V, V, V, V);
V g_heff_2ecompile_2edefun_2euseOf(V, V, V, V, V);
V g_heff_2ecompile_2edefun_2euseOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2euseOf_clo;
V g_heff_2ecompile_2edefun_2eusesW(V, V, V);
V g_heff_2ecompile_2edefun_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eusesW_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2efoldParts(V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2eir_2ewaysMap(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1395959145x1097496552(V, V);
V g_list_2eall_24s1395959145x1097496552_entry(V self, V *a);
extern Clo g_list_2eall_24s1395959145x1097496552_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f511009896x1182531686(V, V);
V g_list_2efoldl_24f511009896x1182531686_entry(V self, V *a);
extern Clo g_list_2efoldl_24f511009896x1182531686_clo;
V g_list_2efoldl_24s1242386649x1014712668(V, V);
V g_list_2efoldl_24s1242386649x1014712668_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1242386649x1014712668_clo;
V g_list_2efoldl_24s1291139432x731366752(V, V);
V g_list_2efoldl_24s1291139432x731366752_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1291139432x731366752_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1540385767x593157740(V, V);
V g_list_2efoldl_24s1540385767x593157740_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1540385767x593157740_clo;
V g_list_2efoldl_24s1712223094x1811507279(V, V);
V g_list_2efoldl_24s1712223094x1811507279_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1712223094x1811507279_clo;
V g_list_2efoldl_24s1715799092x2143201243(V, V);
V g_list_2efoldl_24s1715799092x2143201243_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1715799092x2143201243_clo;
V g_list_2efoldl_24s1788567467x1730846999(V, V);
V g_list_2efoldl_24s1788567467x1730846999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1788567467x1730846999_clo;
V g_list_2efoldl_24s2076975989x1982453350(V, V);
V g_list_2efoldl_24s2076975989x1982453350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2076975989x1982453350_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s329749357x1092795161(V, V);
V g_list_2efoldl_24s329749357x1092795161_entry(V self, V *a);
extern Clo g_list_2efoldl_24s329749357x1092795161_clo;
V g_list_2efoldl_24s500871478x288223602(V, V, V);
V g_list_2efoldl_24s500871478x288223602_entry(V self, V *a);
extern Clo g_list_2efoldl_24s500871478x288223602_clo;
V g_list_2efoldl_24s594483157x1279518362(V, V, V);
V g_list_2efoldl_24s594483157x1279518362_entry(V self, V *a);
extern Clo g_list_2efoldl_24s594483157x1279518362_clo;
V g_list_2efoldl_24s648184591x1070837587(V, V);
V g_list_2efoldl_24s648184591x1070837587_entry(V self, V *a);
extern Clo g_list_2efoldl_24s648184591x1070837587_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029035892x1571084362_24tok2(V, V);
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1589519835x26889547(V, V, V, V);
V g_prelude_2e_2b_2b_24f1589519835x26889547_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1589519835x26889547_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2edefun_2enumberedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2enumberedGo_entry, 2, 0};

V g_heff_2ecompile_2edefun_2enumberedGo(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2edefun_2enumberedGo_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2edefun_2enumberedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2enumberedGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2edefun_2enumberedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2enumberedGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2edefun_2enumberedGo_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2edefun_2enumberedGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2enumberedGo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2edefun_2egivenUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2egivenUse_entry, 4, 0};

V g_heff_2ecompile_2edefun_2egivenUse(V v_ks_240, V v_g_241, V v_k_242, V v_m_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_ks_240, v_g_241));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      heff_drop(v_x_247);
      HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_243, v_g_241));
      V v_t_2416;
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x21_2411 = v_field_2410;
          switch (heff_tag_of(v_x21_2411)) {
          case TAG_MkPair: {
            V v_lo_2412 = heff_field(v_x21_2411, 0);
            V v_hi_2413 = heff_field(v_x21_2411, 1);
            V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
            V v_t_2414;
            if (heff_intLe_c_lent(v_lo_2412, v_k_242, 0)) {
              v_t_2414 = v_lo_2412;
            } else {
              heff_drop(v_lo_2412);
              v_t_2414 = heff_dup(v_k_242);
            }
            V v_t_2415;
            if (heff_intLe_c_lent(v_hi_2413, v_k_242, 0)) {
              heff_drop(v_hi_2413);
              v_t_2415 = v_k_242;
            } else {
              heff_drop(v_k_242);
              v_t_2415 = v_hi_2413;
            }
            v_t_2416 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_t_2415});
            break;
          }
          default: heff_nomatch(v_x21_2411);
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_242), v_k_242});
        }
      }
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_243, v_g_241, v_t_2416));
    } else {
      heff_drop(v_g_241);
      heff_drop(v_k_242);
      heff_drop(v_field_246);
      return v_m_243;
    }
  }
}
V g_heff_2ecompile_2edefun_2egivenUse_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2edefun_2egivenUse(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2edefun_2egivenW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2egivenW_entry, 2, 0};

V g_heff_2ecompile_2edefun_2egivenW(V v_ks_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_m_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Nil: {
      heff_drop(v_ks_240);
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return v_m_243;
    }
    case TAG_Cons: {
      V v_x211_244 = heff_field(v_x21_242, 0);
      V v_rest_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24Cons = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_244)) {
      case TAG_EGlobal: {
        V v_g_246 = heff_field(v_x211_244, 0);
        heff_take_n(v_x211_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24Cons, 2);
        V v_t_247 = (g_heff_2ecompile_2edefun_2egivenUse(v_ks_240, v_g_246, MK_INT(0LL), v_m_243));
        V t_0 = v_ks_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_rest_245, v_t_247});
        v_ks_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_EApp: {
        V v_f_248 = heff_field(v_x211_244, 0);
        V v_args_249 = heff_field(v_x211_244, 1);
        V v_ru_24x211_244_24EApp = heff_take_reuse_n(v_x211_244, 3ULL, 2);
        V v_ks_2410 = heff_dup(v_ks_240);
        HeffT2 v_t_2411 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_248));
        V v_x2_2417;
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_h_2414 = v_field_2412;
          V v_bs_2415 = v_field_2413;
          V v_t_2416 = (g_heff_2ecompile_2eir_2eappendI(v_bs_2415, v_args_249));
          v_x2_2417 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_h_2414, v_t_2416});
        }
        V v_rest_2418 = v_rest_245;
        V v_m_2419 = v_m_243;
        V v_t_2427;
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x21_2420 = heff_field(v_x2_2417, 0);
          V v_args_2421 = heff_field(v_x2_2417, 1);
          V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
          switch (heff_tag_of(v_x21_2420)) {
          case TAG_EGlobal: {
            V v_g_2422 = heff_field(v_x21_2420, 0);
            heff_take_n(v_x21_2420, 1ULL, 1);
            heff_drop_cell(v_ru_24x21_242_24Cons, 2);
            V v_t_2423 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_2417_24MkPair, heff_dup(v_args_2421), v_rest_2418));
            V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2421; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2421); r_; });
            V v_t_2425 = ({ V a_0 = v_ks_2410; V a_1 = v_g_2422; V a_2 = v_t_2424; V a_3 = v_m_2419; V r_ = (g_heff_2ecompile_2edefun_2egivenUse(a_0, a_1, a_2, a_3)); heff_drop(v_ks_2410); r_; });
            v_t_2427 = heff_tag_at_n(v_ru_24x211_244_24EApp, TAG_MkPair, 2, (V[]){v_t_2423, v_t_2425});
            break;
          }
          default: {
            heff_drop(v_ks_2410);
            V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_2417_24MkPair, v_args_2421, v_rest_2418));
            v_t_2427 = heff_tag_at_n(v_ru_24x211_244_24EApp, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24Cons, TAG_Cons, 2, (V[]){v_x21_2420, v_t_2426}), v_m_2419});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_x2_2417);
        }
        V t_0 = v_ks_240;
        V t_1 = v_t_2427;
        v_ks_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_ECall: {
        V v_g_2428 = heff_field(v_x211_244, 0);
        V v_args_2429 = heff_field(v_x211_244, 1);
        heff_take_n(v_x211_244, 3ULL, 2);
        V v_t_2430 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24Cons, heff_dup(v_args_2429), v_rest_245));
        V v_t_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2429; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2429); r_; });
        V v_t_2432 = (g_heff_2ecompile_2edefun_2egivenUse(v_ks_240, v_g_2428, v_t_2431, v_m_243));
        V t_0 = v_ks_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_t_2432});
        v_ks_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: {
        heff_drop_cell(v_ru_24x21_242_24Cons, 2);
        V v_t_2433 = (g_heff_2ecompile_2eir_2epartsOnto(v_x211_244, v_rest_245));
        V t_0 = v_ks_240;
        V t_1 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2433, v_m_243});
        v_ks_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2edefun_2egivenW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2egivenW(a[0], a[1]);
}
Clo g_heff_2ecompile_2edefun_2elamAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2elamAmong_entry, 1, 0};

V g_heff_2ecompile_2edefun_2elamAmong(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EGlobal: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELam: {
      return NTAG(TAG_True);
    }
    case TAG_EApp: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ERecord: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EProj: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ETag: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EMatch: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EPrim: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EPrimCall: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECall: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EInt: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFloat: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EStr: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EBytes: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFixed: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFloat32: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAbandon: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EBool: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESet: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EValues: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFix: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2edefun_2elamAmong_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2edefun_2elamAmong(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2edefun_2ehandsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2ehandsW_entry, 2, 0};

V g_heff_2ecompile_2edefun_2ehandsW(V v_ks_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ks_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EApp: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_args_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_f_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2edefun_2ehandsW_clo), 1, (V[]){heff_dup(v_ks_240)}));
      V v_ks_247 = v_ks_240;
      HeffT2 v_t_248 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_244));
      V v_x2_2414;
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_h_2411 = v_field_249;
        V v_bs_2412 = v_field_2410;
        V v_t_2413 = (g_heff_2ecompile_2eir_2eappendI(v_bs_2412, v_args_245));
        v_x2_2414 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_MkPair, 2, (V[]){v_h_2411, v_t_2413});
      }
      V v_rest_2415 = v_rest_243;
      V v_x3_2427;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x21_2416 = heff_field(v_x2_2414, 0);
        V v_args_2417 = heff_field(v_x2_2414, 1);
        V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
        switch (heff_tag_of(v_x21_2416)) {
        case TAG_EGlobal: {
          V v_g_2418 = heff_field(v_x21_2416, 0);
          V v_ru_24x21_2416_24EGlobal = heff_take_reuse_n(v_x21_2416, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          HeffT2 v_t_2419 = ({ V a_0 = v_ks_247; V a_1 = v_g_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_ks_247); heff_drop(v_g_2418); r_; });
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_x_2422 = v_field_2421;
              heff_drop(v_x_2422);
              V v_t_2423 = (g_heff_2ecompile_2edefun_2elamAmong(v_args_2417));
              if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
                heff_drop(v_rest_2415);
                heff_drop(v_args_2417);
                heff_drop_cell(v_ru_24x2_2414_24MkPair, 2);
                heff_drop_cell(v_ru_24x21_2416_24EGlobal, 1);
                heff_drop(v_t_2423);
                v_x3_2427 = NTAG(TAG_Nothing);
              } else {
                heff_drop(v_t_2423);
                V v_t_2424 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_2414_24MkPair, v_args_2417, v_rest_2415));
                v_x3_2427 = heff_tag_at_n(v_ru_24x21_2416_24EGlobal, TAG_Just, 1, (V[]){v_t_2424});
              }
            } else {
              heff_drop(v_field_2421);
              V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_2414_24MkPair, v_args_2417, v_rest_2415));
              v_x3_2427 = heff_tag_at_n(v_ru_24x21_2416_24EGlobal, TAG_Just, 1, (V[]){v_t_2425});
            }
          }
          break;
        }
        default: {
          heff_drop(v_ks_247);
          V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_2414_24MkPair, v_args_2417, v_rest_2415));
          v_x3_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x21_2416, v_t_2426})});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      switch (heff_tag_of(v_x3_2427)) {
      case TAG_Nothing: {
        heff_drop(v_f_246);
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        V v_x_2428 = heff_field(v_x3_2427, 0);
        heff_take_n(v_x3_2427, 1ULL, 1);
        return heff_tail(v_f_246, 1, (V[]){v_x_2428});
      }
      default: return heff_nomatch(v_x3_2427);
      }
    }
    case TAG_ECall: {
      V v_g_2429 = heff_field(v_x21_242, 0);
      V v_args_2430 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_f_2431 = heff_tr(heff_call(((V)&g_heff_2ecompile_2edefun_2ehandsW_clo), 1, (V[]){heff_dup(v_ks_240)}));
      V v_lit_2432 = v_g_2429;
      V v_lit_2433 = v_args_2430;
      V v_ks_2434 = v_ks_240;
      V v_rest_2435 = v_rest_243;
      HeffT2 v_t_2436 = ({ V a_0 = v_ks_2434; V a_1 = v_lit_2432; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_ks_2434); heff_drop(v_lit_2432); r_; });
      V v_x3_2443;
      {
        V v_field_2438 = v_t_2436.f[1];
        int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
        if ((v_tag_2437 == ((int64_t)0ULL))) {
          V v_x_2439 = v_field_2438;
          heff_drop(v_x_2439);
          V v_t_2440 = (g_heff_2ecompile_2edefun_2elamAmong(v_lit_2433));
          if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_lit_2433);
            heff_drop(v_rest_2435);
            heff_drop(v_t_2440);
            v_x3_2443 = NTAG(TAG_Nothing);
          } else {
            heff_drop(v_t_2440);
            V v_t_2441 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_lit_2433, v_rest_2435));
            v_x3_2443 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
          }
        } else {
          heff_drop(v_field_2438);
          V v_t_2442 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_lit_2433, v_rest_2435));
          v_x3_2443 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2442});
        }
      }
      switch (heff_tag_of(v_x3_2443)) {
      case TAG_Nothing: {
        heff_drop(v_f_2431);
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        V v_x_2444 = heff_field(v_x3_2443, 0);
        heff_take_n(v_x3_2443, 1ULL, 1);
        return heff_tail(v_f_2431, 1, (V[]){v_x_2444});
      }
      default: return heff_nomatch(v_x3_2443);
      }
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2445 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_ks_240;
      V t_1 = v_t_2445;
      v_ks_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2edefun_2ehandsW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2ehandsW(a[0], a[1]);
}
Clo g_heff_2ecompile_2edefun_2euseOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2euseOf_entry, 5, 0};

V g_heff_2ecompile_2edefun_2euseOf(V v_c_240, V v_user_241, V v_g_242, V v_k_243, V v_u_244) {
top: ;
  HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_c_240, 0), v_g_242));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      heff_drop(v_x_248);
      V v_c_249 = heff_dup(v_c_240);
      V v_group_2410 = heff_take_field(v_c_249, 0);
      V v_arity_2411 = heff_get_n(v_c_249, 1, 2);
      V v_user_2412 = v_user_241;
      V v_g_2413 = heff_dup(v_g_242);
      V v_k_2414 = heff_dup(v_k_243);
      HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_c_240, 0, 2); V a_1 = v_g_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2429;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_bad_2418 = heff_dup(heff_rfield(v_u_244, 0));
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_r_2419 = v_field_2417;
          HeffT2 v_t_2420 = ({ V a_0 = v_group_2410; V a_1 = v_user_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_group_2410); heff_drop(v_user_2412); r_; });
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              V v_r_2423 = v_field_2422;
              if (heff_strEq_c(v_r_2423, v_r_2419)) {
                HeffT2 v_t_2424 = ({ V a_0 = v_arity_2411; V a_1 = v_g_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_arity_2411); r_; });
                {
                  V v_field_2426 = v_t_2424.f[1];
                  int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
                  V v_t_2428;
                  if ((v_tag_2425 == ((int64_t)0ULL))) {
                    V v_x_2427 = v_field_2426;
                    v_t_2428 = v_x_2427;
                  } else {
                    heff_drop(v_field_2426);
                    v_t_2428 = MK_INT(1000000LL);
                  }
                  if (heff_intLe_c(v_t_2428, v_k_2414)) {
                    heff_drop(v_g_2413);
                    v_t_2429 = v_bad_2418;
                  } else {
                    v_t_2429 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_bad_2418, v_g_2413, NTAG(TAG_MkUnit)));
                  }
                }
              } else {
                heff_drop(v_arity_2411);
                heff_drop(v_k_2414);
                v_t_2429 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_bad_2418, v_g_2413, NTAG(TAG_MkUnit)));
              }
            } else {
              heff_drop(v_arity_2411);
              heff_drop(v_k_2414);
              heff_drop(v_r_2419);
              heff_drop(v_field_2422);
              v_t_2429 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_bad_2418, v_g_2413, NTAG(TAG_MkUnit)));
            }
          }
        } else {
          heff_drop(v_group_2410);
          heff_drop(v_arity_2411);
          heff_drop(v_user_2412);
          heff_drop(v_g_2413);
          heff_drop(v_k_2414);
          heff_drop(v_field_2417);
          v_t_2429 = v_bad_2418;
        }
      }
      HeffT2 v_t_2430 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_u_244, 1), v_g_242));
      V v_t_2438;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_x21_2433 = v_field_2432;
          switch (heff_tag_of(v_x21_2433)) {
          case TAG_MkPair: {
            V v_lo_2434 = heff_field(v_x21_2433, 0);
            V v_hi_2435 = heff_field(v_x21_2433, 1);
            V v_ru_24x21_2433_24MkPair = heff_take_reuse_n(v_x21_2433, 3ULL, 2);
            V v_t_2436;
            if (heff_intLe_c_lent(v_lo_2434, v_k_243, 0)) {
              v_t_2436 = v_lo_2434;
            } else {
              heff_drop(v_lo_2434);
              v_t_2436 = heff_dup(v_k_243);
            }
            V v_t_2437;
            if (heff_intLe_c_lent(v_hi_2435, v_k_243, 0)) {
              heff_drop(v_hi_2435);
              v_t_2437 = v_k_243;
            } else {
              heff_drop(v_k_243);
              v_t_2437 = v_hi_2435;
            }
            v_t_2438 = heff_tag_at_n(v_ru_24x21_2433_24MkPair, TAG_MkPair, 2, (V[]){v_t_2436, v_t_2437});
            break;
          }
          default: heff_nomatch(v_x21_2433);
          }
        } else {
          heff_drop(v_field_2432);
          v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_243), v_k_243});
        }
      }
      V v_t_2439 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_get_n(v_u_244, 1, 2), v_g_242, v_t_2438));
      return heff_rec_n(2, shape_bad__given, (V[]){v_t_2429, v_t_2439});
    } else {
      heff_drop_rec(v_c_240, 2);
      heff_drop(v_user_241);
      heff_drop(v_g_242);
      heff_drop(v_k_243);
      heff_drop(v_field_247);
      return v_u_244;
    }
  }
}
V g_heff_2ecompile_2edefun_2euseOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2euseOf(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2edefun_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eusesW_entry, 3, 0};

V g_heff_2ecompile_2edefun_2eusesW(V v_c_240, V v_user_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_u_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_user_241);
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      return v_u_244;
    }
    case TAG_Cons: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      V v_rest_246 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24Cons = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_EGlobal: {
        V v_g_247 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24Cons, 2);
        V v_t_248 = (g_heff_2ecompile_2edefun_2euseOf(heff_dup(v_c_240), heff_dup(v_user_241), v_g_247, MK_INT(0LL), v_u_244));
        V t_0 = v_c_240;
        V t_1 = v_user_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_rest_246, v_t_248});
        v_c_240 = t_0;
        v_user_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EApp: {
        V v_f_249 = heff_field(v_x311_245, 0);
        V v_args_2410 = heff_field(v_x311_245, 1);
        V v_ru_24x311_245_24EApp = heff_take_reuse_n(v_x311_245, 3ULL, 2);
        V v_c_2411 = heff_dup(v_c_240);
        V v_user_2412 = heff_dup(v_user_241);
        HeffT2 v_t_2413 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_249));
        V v_x3_2419;
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_h_2416 = v_field_2414;
          V v_bs_2417 = v_field_2415;
          V v_t_2418 = (g_heff_2ecompile_2eir_2eappendI(v_bs_2417, v_args_2410));
          v_x3_2419 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_h_2416, v_t_2418});
        }
        V v_rest_2420 = v_rest_246;
        V v_u_2421 = v_u_244;
        V v_t_2429;
        switch (heff_tag_of(v_x3_2419)) {
        case TAG_MkPair: {
          V v_x31_2422 = heff_field(v_x3_2419, 0);
          V v_args_2423 = heff_field(v_x3_2419, 1);
          V v_ru_24x3_2419_24MkPair = heff_take_reuse_n(v_x3_2419, 3ULL, 2);
          switch (heff_tag_of(v_x31_2422)) {
          case TAG_EGlobal: {
            V v_g_2424 = heff_field(v_x31_2422, 0);
            heff_take_n(v_x31_2422, 1ULL, 1);
            heff_drop_cell(v_ru_24x31_243_24Cons, 2);
            V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_2419_24MkPair, heff_dup(v_args_2423), v_rest_2420));
            V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2423; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2423); r_; });
            V v_t_2427 = (g_heff_2ecompile_2edefun_2euseOf(v_c_2411, v_user_2412, v_g_2424, v_t_2426, v_u_2421));
            v_t_2429 = heff_tag_at_n(v_ru_24x311_245_24EApp, TAG_MkPair, 2, (V[]){v_t_2425, v_t_2427});
            break;
          }
          default: {
            heff_drop(v_c_2411);
            heff_drop(v_user_2412);
            V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_2419_24MkPair, v_args_2423, v_rest_2420));
            v_t_2429 = heff_tag_at_n(v_ru_24x311_245_24EApp, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24Cons, TAG_Cons, 2, (V[]){v_x31_2422, v_t_2428}), v_u_2421});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_x3_2419);
        }
        V t_0 = v_c_240;
        V t_1 = v_user_241;
        V t_2 = v_t_2429;
        v_c_240 = t_0;
        v_user_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ECall: {
        V v_g_2430 = heff_field(v_x311_245, 0);
        V v_args_2431 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 2);
        V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24Cons, heff_dup(v_args_2431), v_rest_246));
        V v_t_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2431; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2431); r_; });
        V v_t_2434 = (g_heff_2ecompile_2edefun_2euseOf(heff_dup(v_c_240), heff_dup(v_user_241), v_g_2430, v_t_2433, v_u_244));
        V t_0 = v_c_240;
        V t_1 = v_user_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_t_2434});
        v_c_240 = t_0;
        v_user_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: {
        heff_drop_cell(v_ru_24x31_243_24Cons, 2);
        V v_t_2435 = (g_heff_2ecompile_2eir_2epartsOnto(v_x311_245, v_rest_246));
        V t_0 = v_c_240;
        V t_1 = v_user_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_2435, v_u_244});
        v_c_240 = t_0;
        v_user_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2edefun_2eusesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2eusesW(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2edefun_2eknownOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2edefun_2eknownOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eknownOf_entry, 3, 0};

V g_heff_2ecompile_2edefun_2eknownOf(V v_bodies_240, V v_bad_241, V v_ks_242) {
top: ;
  HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2edefun_2eknownOf_lam0, 2, 2, (V[]){heff_dup(v_bad_241), heff_dup(v_bodies_240)}), heff_dup(g_std_2eordmap_2eempty_get()), v_ks_242);
}
V g_heff_2ecompile_2edefun_2eknownOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2edefun_2eknownOf(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2edefun_2eknownOf_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_k_244 = args[1];
  V v_bad_241 = heff_env(self)[0];
  V v_bodies_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_245 = ({ V a_0 = v_bad_241; V a_1 = v_k_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_bad_241); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_k_244);
      heff_drop(v_bodies_240);
      V v_x_248 = v_field_247;
      heff_drop(v_x_248);
      return v_m_243;
    } else {
      heff_drop(v_field_247);
      HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_bodies_240, v_k_244));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          switch (heff_tag_of(v_x_2412)) {
          case TAG_EVar: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EGlobal: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_ELam: {
            V v_xs_2415 = heff_field(v_x_2412, 0);
            heff_take_n(v_x_2412, 1ULL, 2);
            switch (heff_tag_of(v_xs_2415)) {
            case TAG_Nil: {
              heff_drop(v_k_244);
              heff_drop(v_bodies_240);
              return v_m_243;
            }
            case TAG_Cons: {
              heff_take_n(v_xs_2415, 0ULL, 2);
              HeffT2 v_t_2419 = ({ V a_0 = v_bodies_240; V a_1 = v_k_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_240); r_; });
              V v_t_2462;
              {
                V v_field_2421 = v_t_2419.f[1];
                int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                if ((v_tag_2420 == ((int64_t)0ULL))) {
                  V v_x_2422 = v_field_2421;
                  switch (heff_tag_of(v_x_2422)) {
                  case TAG_EVar: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EGlobal: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_ELam: {
                    V v_xs_2425 = heff_field(v_x_2422, 0);
                    heff_take_n(v_x_2422, 1ULL, 2);
                    v_t_2462 = v_xs_2425;
                    break;
                  }
                  case TAG_EApp: {
                    heff_take_n(v_x_2422, 0ULL, 2);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_ELet: {
                    heff_take_n(v_x_2422, 0ULL, 3);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_ERecord: {
                    heff_take_n(v_x_2422, 0ULL, 2);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EProj: {
                    heff_take_n(v_x_2422, 0ULL, 4);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_ETag: {
                    heff_take_n(v_x_2422, 0ULL, 3);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EMatch: {
                    heff_take_n(v_x_2422, 0ULL, 2);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EPrim: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EPrimCall: {
                    heff_take_n(v_x_2422, 0ULL, 2);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_ECall: {
                    heff_take_n(v_x_2422, 0ULL, 2);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EInt: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EFloat: {
                    heff_take_nf(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EStr: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EBytes: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EFixed: {
                    heff_take_n(v_x_2422, 0ULL, 2);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EFloat32: {
                    heff_take_na(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EAbandon: {
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EBool: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_ESet: {
                    heff_take_n(v_x_2422, 0ULL, 3);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EValues: {
                    heff_take_n(v_x_2422, 0ULL, 1);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  case TAG_EFix: {
                    heff_take_n(v_x_2422, 0ULL, 2);
                    v_t_2462 = NTAG(TAG_Nil);
                    break;
                  }
                  default: heff_nomatch(v_x_2422);
                  }
                } else {
                  heff_drop(v_field_2421);
                  v_t_2462 = NTAG(TAG_Nil);
                }
              }
              return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_243, v_k_244, v_t_2462));
            }
            default: return heff_nomatch(v_xs_2415);
            }
          }
          case TAG_EApp: {
            heff_take_n(v_x_2412, 0ULL, 2);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_ELet: {
            heff_take_n(v_x_2412, 0ULL, 3);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_ERecord: {
            heff_take_n(v_x_2412, 0ULL, 2);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EProj: {
            heff_take_n(v_x_2412, 0ULL, 4);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_ETag: {
            heff_take_n(v_x_2412, 0ULL, 3);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EMatch: {
            heff_take_n(v_x_2412, 0ULL, 2);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EPrim: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_x_2412, 0ULL, 2);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_ECall: {
            heff_take_n(v_x_2412, 0ULL, 2);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EInt: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EFloat: {
            heff_take_nf(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EStr: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EBytes: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EFixed: {
            heff_take_n(v_x_2412, 0ULL, 2);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EFloat32: {
            heff_take_na(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EAbandon: {
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EBool: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_ESet: {
            heff_take_n(v_x_2412, 0ULL, 3);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EValues: {
            heff_take_n(v_x_2412, 0ULL, 1);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          case TAG_EFix: {
            heff_take_n(v_x_2412, 0ULL, 2);
            heff_drop(v_k_244);
            heff_drop(v_bodies_240);
            return v_m_243;
          }
          default: return heff_nomatch(v_x_2412);
          }
        } else {
          heff_drop(v_k_244);
          heff_drop(v_bodies_240);
          heff_drop(v_field_2411);
          return v_m_243;
        }
      }
    }
  }
}
V g_heff_2ecompile_2edefun_2egroupOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2edefun_2egroupOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2egroupOf_entry, 4, 0};

V g_heff_2ecompile_2edefun_2egroupOf(V v_bodies_240, V v_bad_241, V v_given_242, V v_ks_243) {
top: ;
  V v_known_244 = (g_heff_2ecompile_2edefun_2eknownOf(v_bodies_240, v_bad_241, v_ks_243));
  V v_t_2463 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2edefun_2egroupOf_lam0, 2, 3, (V[]){heff_dup(v_bodies_240), heff_dup(v_given_242), heff_dup(v_known_244)}), heff_dup(g_std_2eordmap_2eempty_get()), v_ks_243));
  return heff_rec_n(3, shape_keys__known__entries, (V[]){v_ks_243, v_known_244, v_t_2463});
}
V g_heff_2ecompile_2edefun_2egroupOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2edefun_2egroupOf(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2edefun_2egroupOf_lam0(V self, V *args) {
  V v_m_245 = args[0];
  V v_k_246 = args[1];
  V v_bodies_240 = heff_env(self)[0];
  V v_given_242 = heff_env(self)[1];
  V v_known_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_247 = ({ V a_0 = v_bodies_240; V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_240); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_t_2450;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      switch (heff_tag_of(v_x_2410)) {
      case TAG_EVar: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        V v_xs_2413 = heff_field(v_x_2410, 0);
        heff_take_n(v_x_2410, 1ULL, 2);
        v_t_2450 = v_xs_2413;
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_2410, 0ULL, 2);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_2410, 0ULL, 3);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_2410, 0ULL, 2);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_2410, 0ULL, 4);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_2410, 0ULL, 3);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x_2410, 0ULL, 2);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_2410, 0ULL, 2);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_2410, 0ULL, 2);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_2410, 0ULL, 2);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x_2410, 0ULL, 3);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x_2410, 0ULL, 1);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_2410, 0ULL, 2);
        v_t_2450 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_2410);
      }
    } else {
      heff_drop(v_field_249);
      v_t_2450 = NTAG(TAG_Nil);
    }
    V v_n_2451 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2450; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2450); r_; });
    HeffT2 v_t_2452 = ({ V a_0 = v_given_242; V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_given_242); r_; });
    {
      V v_field_2454 = v_t_2452.f[1];
      int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
      if ((v_tag_2453 == ((int64_t)0ULL))) {
        V v_x51_2455 = v_field_2454;
        switch (heff_tag_of(v_x51_2455)) {
        case TAG_MkPair: {
          V v_lo_2456 = heff_field(v_x51_2455, 0);
          heff_take_n(v_x51_2455, 1ULL, 2);
          HeffT2 v_t_2458 = ({ V a_0 = v_known_244; V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_known_244); r_; });
          V v_t_2462;
          {
            V v_field_2460 = v_t_2458.f[1];
            int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
            v_t_2462 = heff_bool(((v_tag_2459 == ((int64_t)0ULL)) && ({ V v_x_2461 = heff_dup(v_field_2460); int c_ = 1; heff_drop(v_x_2461); c_; })));
            heff_drop(v_field_2460);
          }
          if (((heff_dup(v_t_2462) == NTAG(TAG_True)) || (heff_intEq_c_lent(v_n_2451, MK_INT(0LL), 2) || heff_intLe_c_lent(v_lo_2456, v_n_2451, 0)))) {
            heff_drop(v_k_246);
            heff_drop(v_n_2451);
            heff_drop(v_lo_2456);
            heff_drop(v_t_2462);
            return v_m_245;
          } else {
            heff_drop(v_n_2451);
            heff_drop(v_t_2462);
            return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_245, v_k_246, v_lo_2456));
          }
        }
        default: return heff_nomatch(v_x51_2455);
        }
      } else {
        heff_drop(v_k_246);
        heff_drop(v_known_244);
        heff_drop(v_n_2451);
        heff_drop(v_field_2454);
        return v_m_245;
      }
    }
  }
}
Clo g_heff_2ecompile_2edefun_2einto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2einto_entry, 3, 0};

V g_heff_2ecompile_2edefun_2einto(V v_x1_240, V v_s_241, V v_c_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_ToVar: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_241, heff_dup(v_x_243)}), heff_take_field(v_c_242, 1)});
    return ({ V rv_1 = v_t_244; V rr_ = heff_rec_reuse_nf(v_c_242, 29ULL, 5, shape_n__flows__outs__calls__lams, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ToOut: {
    switch (heff_tag_of(v_s_241)) {
    case TAG_FromLam: {
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_241, heff_take_field(v_c_242, 2)});
      return ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_nf(v_c_242, 27ULL, 5, shape_n__flows__outs__calls__lams, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    case TAG_FromVar: {
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_241, heff_take_field(v_c_242, 2)});
      return ({ V rv_2 = v_t_248; V rr_ = heff_rec_reuse_nf(v_c_242, 27ULL, 5, shape_n__flows__outs__calls__lams, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    }
    case TAG_FromNone: {
      return v_c_242;
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2edefun_2einto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2edefun_2einto(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2edefun_2eargsAs_24cpr_str0, 1, "%");
HEFF_LIT(g_heff_2ecompile_2edefun_2eargsAs_24cpr_str1, 1, "%");

HeffT2 g_heff_2ecompile_2edefun_2eargsAs_24cpr(V v_go_240, V v_x2_241, V v_acc_242, V v_c_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    V v_f_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return ((HeffT2){{v_f_244, v_c_243}});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x2_241, 0);
    V v_es_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_c_243, 0)));
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2edefun_2eargsAs_24cpr_str0), v_t_247), v_acc_242});
    V v_t_249 = heff_intShow(heff_dup(heff_rfield(v_c_243, 0)));
    V v_t_2410 = heff_tag_n(TAG_ToVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2edefun_2eargsAs_24cpr_str1), v_t_249)});
    V v_t_2411 = heff_intAdd(heff_take_field(v_c_243, 0), MK_INT(1LL));
    V v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_c_243, 30ULL, 5, shape_n__flows__outs__calls__lams, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2413 = heff_tr(heff_call(heff_dup(v_go_240), 3, (V[]){v_t_2410, v_a_245, v_t_2412}));
    V t_0 = v_go_240;
    V t_1 = v_es_246;
    V t_2 = v_t_248;
    V t_3 = v_t_2413;
    v_go_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    v_c_243 = t_3;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2edefun_2eargsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eargsTo_entry, 4, 0};

V g_heff_2ecompile_2edefun_2eargsTo(V v_go_240, V v_x2_241, V v_x3_242, V v_c_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_x3_242);
    return v_c_243;
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V v_t_246 = heff_tr(heff_call(heff_dup(v_go_240), 3, (V[]){NTAG(TAG_ToOut), heff_dup(v_a_244), v_c_243}));
      V t_0 = v_go_240;
      V t_1 = v_es_245;
      V t_2 = NTAG(TAG_Nil);
      V t_3 = v_t_246;
      v_go_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_c_243 = t_3;
      goto top;
    }
    case TAG_Cons: {
      V v_p_247 = heff_field(v_x3_242, 0);
      V v_ps_248 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(v_go_240), 3, (V[]){heff_tag_n(TAG_ToVar, 1, (V[]){v_p_247}), heff_dup(v_a_244), v_c_243}));
      V t_0 = v_go_240;
      V t_1 = v_es_245;
      V t_2 = v_ps_248;
      V t_3 = v_t_249;
      v_go_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_c_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2edefun_2eargsTo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2edefun_2eargsTo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2edefun_2eappCol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eappCol_entry, 5, 0};

V g_heff_2ecompile_2edefun_2eappCol(V v_go_240, V v_known_241, V v_ctx_242, V v_x4_243, V v_c_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    V v_args_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_EVar: {
      V v_x_247 = heff_field(v_x41_245, 0);
      heff_take_n(v_x41_245, 1ULL, 1);
      HeffT2 v_t_248 = (g_heff_2ecompile_2edefun_2eargsAs_24cpr(v_go_240, v_args_246, NTAG(TAG_Nil), v_c_244));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_xs_2411 = v_field_249;
        V v_c_2412 = v_field_2410;
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_head__args, (V[]){v_x_247, v_xs_2411}), heff_take_field(v_c_2412, 3)});
        V v_c_2414 = ({ V rv_3 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_c_2412, 23ULL, 5, shape_n__flows__outs__calls__lams, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        switch (heff_tag_of(v_ctx_242)) {
        case TAG_ToVar: {
          V v_x_2415 = heff_field(v_ctx_242, 0);
          V v_t_2416 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_FromNone), heff_dup(v_x_2415)});
          V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_take_field(v_c_2414, 1)});
          return ({ V rv_1 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_c_2414, 29ULL, 5, shape_n__flows__outs__calls__lams, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        case TAG_ToOut: {
          heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
          return v_c_2414;
        }
        default: return heff_nomatch(v_ctx_242);
        }
      }
    }
    case TAG_EGlobal: {
      V v_g_2418 = heff_field(v_x41_245, 0);
      heff_take_n(v_x41_245, 1ULL, 1);
      HeffT2 v_t_2419 = ({ V a_0 = v_known_241; V a_1 = v_g_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2418); r_; });
      {
        V v_field_2421 = v_t_2419.f[1];
        int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
        V v_c_2423;
        if ((v_tag_2420 == ((int64_t)0ULL))) {
          V v_ps_2422 = v_field_2421;
          v_c_2423 = ({ V a_0 = v_go_240; V a_1 = v_args_246; V a_2 = v_ps_2422; V a_3 = v_c_244; V r_ = (g_heff_2ecompile_2edefun_2eargsTo(a_0, a_1, a_2, a_3)); heff_drop(v_args_246); r_; });
        } else {
          heff_drop(v_field_2421);
          v_c_2423 = ({ V a_0 = v_go_240; V a_1 = v_args_246; V a_2 = NTAG(TAG_Nil); V a_3 = v_c_244; V r_ = (g_heff_2ecompile_2edefun_2eargsTo(a_0, a_1, a_2, a_3)); heff_drop(v_args_246); r_; });
        }
        switch (heff_tag_of(v_ctx_242)) {
        case TAG_ToVar: {
          V v_x_2424 = heff_field(v_ctx_242, 0);
          V v_t_2425 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_FromNone), heff_dup(v_x_2424)});
          V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_take_field(v_c_2423, 1)});
          return ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_c_2423, 29ULL, 5, shape_n__flows__outs__calls__lams, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        case TAG_ToOut: {
          heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
          return v_c_2423;
        }
        default: return heff_nomatch(v_ctx_242);
        }
      }
    }
    default: {
      V v_t_2427 = heff_tr(heff_call(heff_dup(v_go_240), 3, (V[]){NTAG(TAG_ToOut), v_x41_245, v_c_244}));
      V v_c_2428 = ({ V a_0 = v_go_240; V a_1 = v_args_246; V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2427; V r_ = (g_heff_2ecompile_2edefun_2eargsTo(a_0, a_1, a_2, a_3)); heff_drop(v_args_246); r_; });
      switch (heff_tag_of(v_ctx_242)) {
      case TAG_ToVar: {
        V v_x_2429 = heff_field(v_ctx_242, 0);
        V v_t_2430 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_FromNone), heff_dup(v_x_2429)});
        V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, heff_take_field(v_c_2428, 1)});
        return ({ V rv_1 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_c_2428, 29ULL, 5, shape_n__flows__outs__calls__lams, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_ToOut: {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        return v_c_2428;
      }
      default: return heff_nomatch(v_ctx_242);
      }
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2edefun_2eappCol_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2edefun_2eappCol(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2edefun_2ecolE_lam0(V self, V *args);
V g_heff_2ecompile_2edefun_2ecolE_lam1(V self, V *args);
V g_heff_2ecompile_2edefun_2ecolE_lam2(V self, V *args);
Clo g_heff_2ecompile_2edefun_2ecolE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2ecolE_entry, 4, 0};

V g_heff_2ecompile_2edefun_2ecolE(V v_known_240, V v_ctx_241, V v_e_242, V v_c_243) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_known_240);
    return ({ V a_0 = v_ctx_241; V a_1 = heff_tag_at_n(v_ru_24e_242_24EVar, TAG_FromVar, 1, (V[]){v_x_244}); V a_2 = v_c_243; V r_ = (g_heff_2ecompile_2edefun_2einto(a_0, a_1, a_2)); heff_drop(v_ctx_241); r_; });
  }
  case TAG_ELam: {
    V v_e1_245 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_245)) {
    case TAG_Nil: {
      V v_c_2411 = heff_tr(g_heff_2ecompile_2eir_2efoldParts(heff_clo_n(g_heff_2ecompile_2edefun_2ecolE_lam0, 3, 1, (V[]){v_known_240}), v_e_242, v_c_243));
      switch (heff_tag_of(v_ctx_241)) {
      case TAG_ToVar: {
        V v_x_2412 = heff_field(v_ctx_241, 0);
        heff_take_n(v_ctx_241, 1ULL, 1);
        V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_FromNone), v_x_2412});
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_take_field(v_c_2411, 1)});
        return ({ V rv_1 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_c_2411, 29ULL, 5, shape_n__flows__outs__calls__lams, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_ToOut: {
        return v_c_2411;
      }
      default: return heff_nomatch(v_ctx_241);
      }
    }
    case TAG_Cons: {
      V v_y_2415 = heff_field(v_e1_245, 0);
      V v_ys_2416 = heff_field(v_e1_245, 1);
      heff_take_n(v_e1_245, 3ULL, 2);
      switch (heff_tag_of(v_e_242)) {
      case TAG_ELam: {
        V v_b_2418 = heff_field(v_e_242, 1);
        heff_take_n(v_e_242, 2ULL, 2);
        V v_t_2419 = heff_rec_n(2, shape_params__body, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_2415), v_ys_2416}), heff_dup(v_b_2418)});
        V v_t_2420 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_c_243, 4), heff_dup(v_y_2415), v_t_2419));
        V v_t_2421 = ({ V rv_4 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_c_243, 15ULL, 5, shape_n__flows__outs__calls__lams, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        V v_t_2422 = ({ V a_0 = v_ctx_241; V a_1 = heff_tag_n(TAG_FromLam, 1, (V[]){v_y_2415}); V a_2 = v_t_2421; V r_ = (g_heff_2ecompile_2edefun_2einto(a_0, a_1, a_2)); heff_drop(v_ctx_241); r_; });
        V t_0 = v_known_240;
        V t_1 = NTAG(TAG_ToOut);
        V t_2 = v_b_2418;
        V t_3 = v_t_2422;
        v_known_240 = t_0;
        v_ctx_241 = t_1;
        v_e_242 = t_2;
        v_c_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    default: return heff_nomatch(v_e1_245);
    }
  }
  case TAG_EApp: {
    V v_f_2423 = heff_field(v_e_242, 0);
    V v_args_2424 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2edefun_2ecolE_clo), 1, (V[]){heff_dup(v_known_240)}));
    HeffT2 v_t_2426 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_2423));
    V v_t_2432;
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_h_2429 = v_field_2427;
      V v_bs_2430 = v_field_2428;
      V v_t_2431 = (g_heff_2ecompile_2eir_2eappendI(v_bs_2430, v_args_2424));
      v_t_2432 = heff_tag_at_n(v_ru_24e_242_24EApp, TAG_MkPair, 2, (V[]){v_h_2429, v_t_2431});
    }
    return ({ V a_0 = v_t_2425; V a_1 = v_known_240; V a_2 = v_ctx_241; V a_3 = v_t_2432; V a_4 = v_c_243; V r_ = (g_heff_2ecompile_2edefun_2eappCol(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_known_240); heff_drop(v_ctx_241); r_; });
  }
  case TAG_ELet: {
    V v_x_2433 = heff_field(v_e_242, 0);
    V v_a_2434 = heff_field(v_e_242, 1);
    V v_b_2435 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2436 = (g_heff_2ecompile_2edefun_2ecolE(heff_dup(v_known_240), heff_tag_n(TAG_ToVar, 1, (V[]){v_x_2433}), v_a_2434, v_c_243));
    V t_0 = v_known_240;
    V t_1 = v_ctx_241;
    V t_2 = v_b_2435;
    V t_3 = v_t_2436;
    v_known_240 = t_0;
    v_ctx_241 = t_1;
    v_e_242 = t_2;
    v_c_243 = t_3;
    goto top;
  }
  case TAG_EMatch: {
    V v_s_2437 = heff_field(v_e_242, 0);
    V v_arms_2438 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2439 = (g_heff_2ecompile_2edefun_2ecolE(heff_dup(v_known_240), NTAG(TAG_ToOut), v_s_2437, v_c_243));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2ecolE_lam1, 2, 2, (V[]){v_known_240, v_ctx_241}); V a_1 = v_t_2439; V a_2 = v_arms_2438; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2438); r_; });
  }
  case TAG_ECall: {
    V v_g_2451 = heff_field(v_e_242, 0);
    V v_args_2452 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_lit_2453 = v_g_2451;
    V v_lit_2454 = v_args_2452;
    V v_go_2455 = heff_tr(heff_call(((V)&g_heff_2ecompile_2edefun_2ecolE_clo), 1, (V[]){heff_dup(v_known_240)}));
    V v_known_2456 = v_known_240;
    V v_ctx_2457 = v_ctx_241;
    V v_c_2458 = v_c_243;
    HeffT2 v_t_2459 = ({ V a_0 = v_known_2456; V a_1 = v_lit_2453; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_known_2456); heff_drop(v_lit_2453); r_; });
    {
      V v_field_2461 = v_t_2459.f[1];
      int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
      V v_c_2463;
      if ((v_tag_2460 == ((int64_t)0ULL))) {
        V v_ps_2462 = v_field_2461;
        v_c_2463 = ({ V a_0 = v_go_2455; V a_1 = v_lit_2454; V a_2 = v_ps_2462; V a_3 = v_c_2458; V r_ = (g_heff_2ecompile_2edefun_2eargsTo(a_0, a_1, a_2, a_3)); heff_drop(v_lit_2454); r_; });
      } else {
        heff_drop(v_field_2461);
        v_c_2463 = ({ V a_0 = v_go_2455; V a_1 = v_lit_2454; V a_2 = NTAG(TAG_Nil); V a_3 = v_c_2458; V r_ = (g_heff_2ecompile_2edefun_2eargsTo(a_0, a_1, a_2, a_3)); heff_drop(v_lit_2454); r_; });
      }
      switch (heff_tag_of(v_ctx_2457)) {
      case TAG_ToVar: {
        V v_x_2464 = heff_field(v_ctx_2457, 0);
        heff_take_n(v_ctx_2457, 1ULL, 1);
        V v_t_2465 = heff_tag_at_n(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_FromNone), v_x_2464});
        V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, heff_take_field(v_c_2463, 1)});
        return ({ V rv_1 = v_t_2466; V rr_ = heff_rec_reuse_nf(v_c_2463, 29ULL, 5, shape_n__flows__outs__calls__lams, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_ToOut: {
        heff_drop_cell(v_ru_24e_242_24ECall, 2);
        return v_c_2463;
      }
      default: return heff_nomatch(v_ctx_2457);
      }
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    heff_drop(v_ctx_241);
    return v_c_243;
  }
  case TAG_ESet: {
    V v_e1_2467 = heff_field(v_e_242, 0);
    V v_a_2468 = heff_field(v_e_242, 1);
    V v_b_2469 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2470 = (g_list_2efoldl_24s1242386649x1014712668(v_c_243, v_e1_2467));
    V v_t_2471 = (g_heff_2ecompile_2edefun_2ecolE(heff_dup(v_known_240), NTAG(TAG_ToOut), v_a_2468, v_t_2470));
    V t_0 = v_known_240;
    V t_1 = v_ctx_241;
    V t_2 = v_b_2469;
    V t_3 = v_t_2471;
    v_known_240 = t_0;
    v_ctx_241 = t_1;
    v_e_242 = t_2;
    v_c_243 = t_3;
    goto top;
  }
  default: {
    V v_c_2476 = heff_tr(g_heff_2ecompile_2eir_2efoldParts(heff_clo_n(g_heff_2ecompile_2edefun_2ecolE_lam2, 3, 1, (V[]){v_known_240}), v_e_242, v_c_243));
    switch (heff_tag_of(v_ctx_241)) {
    case TAG_ToVar: {
      V v_x_2477 = heff_field(v_ctx_241, 0);
      heff_take_n(v_ctx_241, 1ULL, 1);
      V v_t_2478 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_FromNone), v_x_2477});
      V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, heff_take_field(v_c_2476, 1)});
      return ({ V rv_1 = v_t_2479; V rr_ = heff_rec_reuse_nf(v_c_2476, 29ULL, 5, shape_n__flows__outs__calls__lams, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    case TAG_ToOut: {
      return v_c_2476;
    }
    default: return heff_nomatch(v_ctx_241);
    }
  }
  }
}
V g_heff_2ecompile_2edefun_2ecolE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2ecolE(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2edefun_2ecolE_lam0(V self, V *args) {
  V v_xs_247 = args[0];
  V v_p_248 = args[1];
  V v_acc_249 = args[2];
  V v_known_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_list_2efoldl_24s1242386649x1014712668(v_acc_249, v_xs_247));
  return (g_heff_2ecompile_2edefun_2ecolE(v_known_240, NTAG(TAG_ToOut), v_p_248, v_t_2410));
}
V g_heff_2ecompile_2edefun_2ecolE_lam1(V self, V *args) {
  V v_acc_2440 = args[0];
  V v_a_2441 = args[1];
  V v_known_240 = heff_env(self)[0];
  V v_ctx_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445;
  switch (heff_tag_of(v_a_2441)) {
  case TAG_MkArm: {
    V v_b_2444 = heff_dup(heff_field(v_a_2441, 2));
    v_t_2445 = v_b_2444;
    break;
  }
  default: heff_nomatch(v_a_2441);
  }
  V v_t_2449;
  switch (heff_tag_of(v_a_2441)) {
  case TAG_MkArm: {
    V v_vs_2447 = heff_field(v_a_2441, 1);
    heff_take_n(v_a_2441, 2ULL, 3);
    v_t_2449 = v_vs_2447;
    break;
  }
  default: heff_nomatch(v_a_2441);
  }
  V v_t_2450 = (g_list_2efoldl_24s1242386649x1014712668(v_acc_2440, v_t_2449));
  return (g_heff_2ecompile_2edefun_2ecolE(v_known_240, v_ctx_241, v_t_2445, v_t_2450));
}
V g_heff_2ecompile_2edefun_2ecolE_lam2(V self, V *args) {
  V v_xs_2472 = args[0];
  V v_p_2473 = args[1];
  V v_acc_2474 = args[2];
  V v_known_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = (g_list_2efoldl_24s1242386649x1014712668(v_acc_2474, v_xs_2472));
  return (g_heff_2ecompile_2edefun_2ecolE(v_known_240, NTAG(TAG_ToOut), v_p_2473, v_t_2475));
}
Clo g_heff_2ecompile_2edefun_2eescape_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eescape_entry, 2, 0};

V g_heff_2ecompile_2edefun_2eescape(V v_st_240, V v_l_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_st_240, 3), v_l_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_l_241);
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      return v_st_240;
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_240, 3), heff_dup(v_l_241), NTAG(TAG_MkUnit)));
      V v_t_247 = heff_intAdd(heff_take_field(v_st_240, 4), MK_INT(1LL));
      V v_t_248 = heff_rec_n(6, shape_fl__op__bad__esc__grew__lams, (V[]){heff_take_field(v_st_240, 0), heff_take_field(v_st_240, 1), heff_take_field(v_st_240, 2), v_t_246, v_t_247, heff_dup(heff_rfield(v_st_240, 5))});
      HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_st_240, 5, 6); V a_1 = v_l_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_l_241); r_; });
      V v_t_2413;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          v_t_2413 = heff_get_n(v_x_2412, 0, 2);
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = NTAG(TAG_Nil);
        }
      }
      return ({ V a_0 = v_t_248; V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s1715799092x2143201243(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
  }
}
V g_heff_2ecompile_2edefun_2eescape_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2eescape(a[0], a[1]);
}
Clo g_heff_2ecompile_2edefun_2eaddLabel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eaddLabel_entry, 3, 0};

V g_heff_2ecompile_2edefun_2eaddLabel(V v_x_240, V v_st_241, V v_l_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_x_240));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_247;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      v_t_247 = v_x_246;
    } else {
      heff_drop(v_field_245);
      v_t_247 = heff_dup(g_std_2eordmap_2eempty_get());
    }
    HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_l_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        heff_drop(v_x_240);
        heff_drop(v_l_242);
        V v_x_2411 = v_field_2410;
        heff_drop(v_x_2411);
        return v_st_241;
      } else {
        heff_drop(v_field_2410);
        HeffT2 v_t_2412 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_st_241, 2), v_x_240));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2414;
            heff_drop(v_x_2415);
            HeffT2 v_t_2416 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_x_240));
            V v_t_2421;
            {
              V v_field_2418 = v_t_2416.f[1];
              int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
              V v_t_2420;
              if ((v_tag_2417 == ((int64_t)0ULL))) {
                V v_x_2419 = v_field_2418;
                v_t_2420 = v_x_2419;
              } else {
                heff_drop(v_field_2418);
                v_t_2420 = heff_dup(g_std_2eordmap_2eempty_get());
              }
              v_t_2421 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2420, heff_dup(v_l_242), NTAG(TAG_MkUnit)));
            }
            V v_t_2422 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_241, 0), v_x_240, v_t_2421));
            V v_t_2423 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
            V v_t_2424 = ({ V rv_0 = v_t_2422; V rv_4 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_st_241, 46ULL, 6, shape_fl__op__bad__esc__grew__lams, 3324u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; rr_; });
            return (g_heff_2ecompile_2edefun_2eescape(v_t_2424, v_l_242));
          } else {
            heff_drop(v_field_2414);
            HeffT2 v_t_2425 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_x_240));
            V v_t_2430;
            {
              V v_field_2427 = v_t_2425.f[1];
              int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
              V v_t_2429;
              if ((v_tag_2426 == ((int64_t)0ULL))) {
                V v_x_2428 = v_field_2427;
                v_t_2429 = v_x_2428;
              } else {
                heff_drop(v_field_2427);
                v_t_2429 = heff_dup(g_std_2eordmap_2eempty_get());
              }
              v_t_2430 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2429, v_l_242, NTAG(TAG_MkUnit)));
            }
            V v_t_2431 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_241, 0), v_x_240, v_t_2430));
            V v_t_2432 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
            return ({ V rv_0 = v_t_2431; V rv_4 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_st_241, 46ULL, 6, shape_fl__op__bad__esc__grew__lams, 3324u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; rr_; });
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2edefun_2eaddLabel_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2eaddLabel(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2edefun_2emarkBad_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2emarkBad_entry, 2, 0};

V g_heff_2ecompile_2edefun_2emarkBad(V v_x_240, V v_st_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_st_241, 2), v_x_240));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      return v_st_241;
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_241, 2), heff_dup(v_x_240), NTAG(TAG_MkUnit)));
      V v_t_247 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
      V v_t_248 = heff_rec_n(6, shape_fl__op__bad__esc__grew__lams, (V[]){heff_dup(heff_rfield(v_st_241, 0)), heff_take_field(v_st_241, 1), v_t_246, heff_take_field(v_st_241, 3), v_t_247, heff_take_field(v_st_241, 5)});
      HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_st_241, 0, 6); V a_1 = v_x_240; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_240); r_; });
      V v_t_2415;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_t_2413;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          v_t_2413 = v_x_2412;
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = heff_dup(g_std_2eordmap_2eempty_get());
        }
        V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_t_2413); r_; });
        v_t_2415 = (g_list_2emap_24s1415906091x1371825187(v_t_2414));
      }
      return ({ V a_0 = v_t_248; V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1788567467x1730846999(a_0, a_1)); heff_drop(v_t_2415); r_; });
    }
  }
}
V g_heff_2ecompile_2edefun_2emarkBad_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2emarkBad(a[0], a[1]);
}
Clo g_heff_2ecompile_2edefun_2eflowInto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eflowInto_entry, 4, 0};

V g_heff_2ecompile_2edefun_2eflowInto(V v_x_240, V v_ls_241, V v_o_242, V v_st_243) {
top: ;
  V v_t_2410;
  if ((heff_dup(v_o_242) == NTAG(TAG_True))) {
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_st_243, 1), v_x_240));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        v_t_2410 = v_st_243;
      } else {
        heff_drop(v_field_246);
        V v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_243, 1), heff_dup(v_x_240), NTAG(TAG_MkUnit)));
        V v_t_249 = heff_intAdd(heff_take_field(v_st_243, 4), MK_INT(1LL));
        v_t_2410 = ({ V rv_1 = v_t_248; V rv_4 = v_t_249; V rr_ = heff_rec_reuse_nf(v_st_243, 45ULL, 6, shape_fl__op__bad__esc__grew__lams, 3315u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; rr_; });
      }
    }
  } else {
    v_t_2410 = v_st_243;
  }
  V v_t_2411 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_ls_241, NTAG(TAG_Nil)));
  V v_t_2412 = (g_list_2emap_24s1415906091x1371825187(v_t_2411));
  return ({ V a_0 = v_x_240; V a_1 = v_t_2410; V a_2 = v_t_2412; V r_ = (g_list_2efoldl_24s594483157x1279518362(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
}
V g_heff_2ecompile_2edefun_2eflowInto_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2edefun_2eflowInto(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2edefun_2eargsStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eargsStep_entry, 4, 0};

V g_heff_2ecompile_2edefun_2eargsStep(V v_strict_240, V v_x2_241, V v_x3_242, V v_st_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return v_st_243;
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      if ((heff_dup(v_strict_240) == NTAG(TAG_True))) {
        V v_t_246 = (g_heff_2ecompile_2edefun_2emarkBad(heff_dup(v_a_244), v_st_243));
        V t_0 = v_strict_240;
        V t_1 = v_es_245;
        V t_2 = NTAG(TAG_Nil);
        V t_3 = v_t_246;
        v_strict_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        v_st_243 = t_3;
        goto top;
      } else {
        return v_st_243;
      }
    }
    case TAG_Cons: {
      V v_p_247 = heff_field(v_x3_242, 0);
      V v_ps_248 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_243, 0), v_a_244));
      V v_t_2413;
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          v_t_2413 = v_x_2412;
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = heff_dup(g_std_2eordmap_2eempty_get());
        }
      }
      HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_st_243, 1), v_a_244));
      V v_t_2418;
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        v_t_2418 = heff_bool(((v_tag_2415 == ((int64_t)0ULL)) && ({ V v_x_2417 = heff_dup(v_field_2416); int c_ = 1; heff_drop(v_x_2417); c_; })));
        heff_drop(v_field_2416);
      }
      V v_t_2419 = ({ V a_0 = v_p_247; V a_1 = v_t_2413; V a_2 = v_t_2418; V a_3 = v_st_243; V r_ = (g_heff_2ecompile_2edefun_2eflowInto(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); heff_drop(v_t_2418); r_; });
      V t_0 = v_strict_240;
      V t_1 = v_es_245;
      V t_2 = v_ps_248;
      V t_3 = v_t_2419;
      v_strict_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_st_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2edefun_2eargsStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2edefun_2eargsStep(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2edefun_2esolve_24cpr(V v_strict_240, V v_c_241, V v_box_24left_242, V v_st_243) {
  int64_t v_left_242 = heff_unbox_word(v_box_24left_242);
top: ;
  V v_t_244 = (g_list_2efoldl_24s1291139432x731366752(heff_dup(v_st_243), heff_rfield(v_c_241, 1)));
  V v_t_245 = (g_list_2efoldl_24s329749357x1092795161(v_t_244, heff_rfield(v_c_241, 2)));
  V v_st2_246 = (g_list_2efoldl_24s500871478x288223602(heff_dup(v_strict_240), v_t_245, heff_rfield(v_c_241, 3)));
  if (heff_intEq_c(heff_dup(heff_rfield(v_st2_246, 4)), heff_get_n(v_st_243, 4, 6))) {
    heff_drop(v_strict_240);
    heff_drop_rec(v_c_241, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_st2_246}});
  } else {
    if ((v_left_242 <= ((int64_t)0ULL))) {
      heff_drop(v_strict_240);
      heff_drop_rec(v_c_241, 5);
      heff_drop_rec(v_st2_246, 6);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V t_0 = v_strict_240;
      V t_1 = v_c_241;
      int64_t t_2 = (v_left_242 - ((int64_t)1ULL));
      V t_3 = v_st2_246;
      v_strict_240 = t_0;
      v_c_241 = t_1;
      v_left_242 = t_2;
      v_st_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2edefun_2earityOfClass_lam0(V self, V *args);
Clo g_heff_2ecompile_2edefun_2earityOfClass_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2earityOfClass_entry, 2, 0};

V g_heff_2ecompile_2edefun_2earityOfClass(V v_c_240, V v_k_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2earityOfClass_lam0, 2, 1, (V[]){v_k_241}); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_c_240, 3, 5); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ecompile_2edefun_2earityOfClass_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2earityOfClass(a[0], a[1]);
}
V g_heff_2ecompile_2edefun_2earityOfClass_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_call_243 = args[1];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_head_244 = heff_take_field(v_call_243, 0);
  V v_args_245 = heff_get_n(v_call_243, 1, 2);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_k_241, 1, 2); V a_1 = v_head_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_head_244); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      heff_drop(v_x_249);
      V v_y_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_245); r_; });
      if (heff_intLe_c_lent(v_n_242, v_y_2410, 0)) {
        heff_drop(v_n_242);
        return v_y_2410;
      } else {
        heff_drop(v_y_2410);
        return v_n_242;
      }
    } else {
      heff_drop(v_args_245);
      heff_drop(v_field_248);
      return v_n_242;
    }
  }
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam4(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam6(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam5(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam8(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam7(V self, V *args);
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2ecompile_2edefun_2eanalyse_24cpr(V v_strict_240, V v_g_241, V v_bodies_242) {
top: ;
  V v_g_243 = heff_dup(v_g_241);
  V v_bodies_244 = heff_dup(v_bodies_242);
  V v_t_245 = ({ V b_0 = heff_get_n(v_g_243, 1, 3); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_246 = (g_list_2emap_24s1415906091x1371825187(v_t_245));
  V v_ps_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam0, 1, 1, (V[]){v_bodies_244}), v_t_246));
  V v_known_2453 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2452; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2452); r_; });
  V v_known_2454 = heff_dup(v_known_2453);
  V v_g_2455 = heff_dup(v_g_241);
  V v_bodies_2456 = heff_dup(v_bodies_242);
  V v_t_2457 = heff_rec_n(5, shape_n__flows__outs__calls__lams, (V[]){MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_col_2477 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam1, 2, 2, (V[]){v_known_2454, v_bodies_2456}); V a_1 = v_t_2457; V b_2 = heff_get_n(v_g_2455, 0, 3); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2478 = (g_list_2efoldl_24s278088687x1269971185(heff_dup(g_std_2eordmap_2eempty_get()), heff_rfield(v_g_241, 0)));
  V v_t_2484 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam2, 1, 1, (V[]){v_bodies_242}), heff_get_n(v_g_241, 0, 3)));
  V v_given_2485 = (g_heff_2ecompile_2edefun_2egivenW(v_t_2478, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2484, heff_dup(g_std_2eordmap_2eempty_get())})));
  V v_t_2486 = heff_rec_n(6, shape_fl__op__bad__esc__grew__lams, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), heff_dup(heff_rfield(v_col_2477, 4))});
  HeffT2 v_t_2487 = (g_heff_2ecompile_2edefun_2esolve_24cpr(v_strict_240, heff_dup(v_col_2477), MK_INT(60LL), v_t_2486));
  {
    V v_field_2489 = v_t_2487.f[1];
    int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
    if ((v_tag_2488 == ((int64_t)0ULL))) {
      V v_st_2490 = v_field_2489;
      V v_st_2491 = heff_dup(v_st_2490);
      V v_c_2492 = heff_dup(v_col_2477);
      V v_m_2493 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V b_1 = heff_get_n(v_c_2492, 3, 5); V r_ = (g_list_2efoldl_24s1712223094x1811507279(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2494 = ({ V a_0 = v_m_2493; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2493); r_; });
      V v_t_2495 = (g_list_2emap_24s1415906091x1371825187(v_t_2494));
      V v_t_24160 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam3, 2, 1, (V[]){v_st_2491}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2495; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2495); r_; });
      V v_f_24161 = heff_rec_n(5, shape_col__st__classes__known__given, (V[]){v_col_2477, v_st_2490, v_t_24160, v_known_2453, v_given_2485});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24161}});
    } else {
      heff_drop(v_known_2453);
      heff_drop_rec(v_col_2477, 5);
      heff_drop(v_given_2485);
      heff_drop(v_field_2489);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam0(V self, V *args) {
  V v_k_247 = args[0];
  V v_bodies_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = v_bodies_244; V a_1 = v_k_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); r_; });
  V v_t_2451;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_EVar: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        V v_xs_2414 = heff_field(v_x_2411, 0);
        heff_take_n(v_x_2411, 1ULL, 2);
        v_t_2451 = v_xs_2414;
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_2411, 0ULL, 4);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x_2411, 0ULL, 3);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x_2411, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_2411, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_2411);
      }
    } else {
      heff_drop(v_field_2410);
      v_t_2451 = NTAG(TAG_Nil);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_k_247, v_t_2451});
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam1(V self, V *args) {
  V v_c_2458 = args[0];
  V v_k_2459 = args[1];
  V v_known_2454 = heff_env(self)[0];
  V v_bodies_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_known_2460 = heff_dup(v_known_2454);
  HeffT2 v_t_2461 = ({ V a_0 = v_known_2454; V a_1 = v_k_2459; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_known_2454); r_; });
  V v_k_2465;
  {
    V v_field_2463 = v_t_2461.f[1];
    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
    v_k_2465 = heff_bool(((v_tag_2462 == ((int64_t)0ULL)) && ({ V v_x_2464 = heff_dup(v_field_2463); int c_ = 1; heff_drop(v_x_2464); c_; })));
    heff_drop(v_field_2463);
  }
  HeffT2 v_t_2466 = ({ V a_0 = v_bodies_2456; V a_1 = v_k_2459; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_2456); heff_drop(v_k_2459); r_; });
  V v_e_2470;
  {
    V v_field_2468 = v_t_2466.f[1];
    int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
    if ((v_tag_2467 == ((int64_t)0ULL))) {
      V v_x_2469 = v_field_2468;
      v_e_2470 = v_x_2469;
    } else {
      heff_drop(v_field_2468);
      v_e_2470 = NTAG(TAG_EAbandon);
    }
  }
  V v_c_2471 = v_c_2458;
  if ((heff_dup(v_k_2465) == NTAG(TAG_True))) {
    heff_drop(v_k_2465);
    switch (heff_tag_of(v_e_2470)) {
    case TAG_ELam: {
      V v_b_2473 = heff_field(v_e_2470, 1);
      heff_take_n(v_e_2470, 2ULL, 2);
      return (g_heff_2ecompile_2edefun_2ecolE(v_known_2460, NTAG(TAG_ToOut), v_b_2473, v_c_2471));
    }
    default: {
      return (g_heff_2ecompile_2edefun_2ecolE(v_known_2460, NTAG(TAG_ToOut), v_e_2470, v_c_2471));
    }
    }
  } else {
    heff_drop(v_k_2465);
    switch (heff_tag_of(v_e_2470)) {
    case TAG_ELam: {
      V v_ps_2474 = heff_field(v_e_2470, 0);
      V v_b_2475 = heff_field(v_e_2470, 1);
      heff_take_n(v_e_2470, 3ULL, 2);
      V v_t_2476 = (g_list_2efoldl_24s1242386649x1014712668(v_c_2471, v_ps_2474));
      return (g_heff_2ecompile_2edefun_2ecolE(v_known_2460, NTAG(TAG_ToOut), v_b_2475, v_t_2476));
    }
    default: {
      return (g_heff_2ecompile_2edefun_2ecolE(v_known_2460, NTAG(TAG_ToOut), v_e_2470, v_c_2471));
    }
    }
  }
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam2(V self, V *args) {
  V v_k_2479 = args[0];
  V v_bodies_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2480 = ({ V a_0 = v_bodies_242; V a_1 = v_k_2479; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_242); heff_drop(v_k_2479); r_; });
  {
    V v_field_2482 = v_t_2480.f[1];
    int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
    if ((v_tag_2481 == ((int64_t)0ULL))) {
      V v_x_2483 = v_field_2482;
      return v_x_2483;
    } else {
      heff_drop(v_field_2482);
      return NTAG(TAG_EAbandon);
    }
  }
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam4(V self, V *args) {
  V v_x_24125 = args[0];
  V v_esc_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24126 = ({ V a_0 = v_esc_24102; V a_1 = v_x_24125; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_esc_24102); heff_drop(v_x_24125); r_; });
  {
    V v_field_24128 = v_t_24126.f[1];
    int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24127 == ((int64_t)0ULL)) && ({ V v_x_24129 = heff_dup(v_field_24128); int c_ = 1; heff_drop(v_x_24129); c_; })));
    heff_drop(v_field_24128);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam6(V self, V *args) {
  V v_x_24143 = args[0];
  V v_c_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24144 = ({ V b_0 = heff_get_n(v_c_24139, 0, 2); V a_1 = v_x_24143; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_24143); r_; });
  {
    V v_field_24146 = v_t_24144.f[1];
    int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24145 == ((int64_t)0ULL)) && ({ V v_x_24147 = heff_dup(v_field_24146); int c_ = 1; heff_drop(v_x_24147); c_; })));
    heff_drop(v_field_24146);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam5(V self, V *args) {
  V v_k_24140 = args[0];
  V v_c_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24141 = ({ V b_0 = heff_get_n(v_k_24140, 0, 2); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_24142 = (g_list_2emap_24s1415906091x1371825187(v_t_24141));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam6, 1, 1, (V[]){v_c_24139}); V a_1 = v_t_24142; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24142); r_; });
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam8(V self, V *args) {
  V v_x_24153 = args[0];
  V v_c_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24154 = ({ V b_0 = heff_get_n(v_c_24139, 0, 2); V a_1 = v_x_24153; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_24153); r_; });
  {
    V v_field_24156 = v_t_24154.f[1];
    int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24155 == ((int64_t)0ULL)) && ({ V v_x_24157 = heff_dup(v_field_24156); int c_ = 1; heff_drop(v_x_24157); c_; })));
    heff_drop(v_field_24156);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam7(V self, V *args) {
  V v_k_24150 = args[0];
  V v_c_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24151 = ({ V b_0 = heff_get_n(v_k_24150, 0, 2); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_24152 = (g_list_2emap_24s1415906091x1371825187(v_t_24151));
  V v_x1_24158 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam8, 1, 1, (V[]){v_c_24139}); V a_1 = v_t_24152; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24152); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24158) == NTAG(TAG_True)));
  heff_drop(v_x1_24158);
  return v_ret_24bool;
}
V g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam3(V self, V *args) {
  V v_cls_2496 = args[0];
  V v_x_2497 = args[1];
  V v_st_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2498 = heff_dup(v_st_2491);
  V v_bad_2499 = heff_take_field(v_st_2498, 2);
  V v_op_24100 = heff_take_field(v_st_2498, 1);
  V v_fl_24101 = heff_take_field(v_st_2498, 0);
  V v_esc_24102 = heff_get_n(v_st_2498, 3, 6);
  V v_x_24103 = heff_dup(v_x_2497);
  HeffT2 v_t_24104 = ({ V a_0 = v_bad_2499; V a_1 = v_x_24103; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_bad_2499); r_; });
  V v_t_24131;
  {
    V v_field_24106 = v_t_24104.f[1];
    int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
    if ((v_tag_24105 == ((int64_t)0ULL))) {
      heff_drop(v_op_24100);
      heff_drop(v_fl_24101);
      heff_drop(v_esc_24102);
      heff_drop(v_x_24103);
      V v_x_24107 = v_field_24106;
      heff_drop(v_x_24107);
      v_t_24131 = NTAG(TAG_False);
    } else {
      heff_drop(v_field_24106);
      HeffT2 v_t_24108 = ({ V a_0 = v_op_24100; V a_1 = v_x_24103; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_op_24100); r_; });
      {
        V v_field_24110 = v_t_24108.f[1];
        int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
        if ((v_tag_24109 == ((int64_t)0ULL))) {
          heff_drop(v_fl_24101);
          heff_drop(v_esc_24102);
          heff_drop(v_x_24103);
          V v_x_24111 = v_field_24110;
          heff_drop(v_x_24111);
          v_t_24131 = NTAG(TAG_False);
        } else {
          heff_drop(v_field_24110);
          HeffT2 v_t_24112 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_fl_24101, v_x_24103));
          V v_t_24116;
          {
            V v_field_24114 = v_t_24112.f[1];
            int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
            if ((v_tag_24113 == ((int64_t)0ULL))) {
              V v_x_24115 = v_field_24114;
              v_t_24116 = v_x_24115;
            } else {
              heff_drop(v_field_24114);
              v_t_24116 = heff_dup(g_std_2eordmap_2eempty_get());
            }
          }
          V v_x_24117 = ({ V a_0 = v_t_24116; V r_ = (g_std_2eordmap_2esize(a_0)); heff_drop(v_t_24116); r_; });
          if (heff_intLt_c(MK_INT(0LL), v_x_24117)) {
            HeffT2 v_t_24118 = ({ V a_0 = v_fl_24101; V a_1 = v_x_24103; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_fl_24101); heff_drop(v_x_24103); r_; });
            {
              V v_field_24120 = v_t_24118.f[1];
              int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
              V v_t_24122;
              if ((v_tag_24119 == ((int64_t)0ULL))) {
                V v_x_24121 = v_field_24120;
                v_t_24122 = v_x_24121;
              } else {
                heff_drop(v_field_24120);
                v_t_24122 = heff_dup(g_std_2eordmap_2eempty_get());
              }
              V v_t_24123 = ({ V a_0 = v_t_24122; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_t_24122); r_; });
              V v_t_24124 = (g_list_2emap_24s1415906091x1371825187(v_t_24123));
              V v_x1_24130 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam4, 1, 1, (V[]){v_esc_24102}); V a_1 = v_t_24124; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24124); r_; });
              v_t_24131 = heff_bool(!(heff_dup(v_x1_24130) == NTAG(TAG_True)));
              heff_drop(v_x1_24130);
            }
          } else {
            heff_drop(v_fl_24101);
            heff_drop(v_esc_24102);
            heff_drop(v_x_24103);
            v_t_24131 = NTAG(TAG_False);
          }
        }
      }
    }
  }
  if ((heff_dup(v_t_24131) == NTAG(TAG_True))) {
    heff_drop(v_t_24131);
    V v_cls_24132 = v_cls_2496;
    HeffT2 v_t_24133 = ({ V b_0 = heff_get_n(v_st_2491, 0, 6); V a_1 = v_x_2497; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_24137;
    {
      V v_field_24135 = v_t_24133.f[1];
      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
      if ((v_tag_24134 == ((int64_t)0ULL))) {
        V v_x_24136 = v_field_24135;
        v_t_24137 = v_x_24136;
      } else {
        heff_drop(v_field_24135);
        v_t_24137 = heff_dup(g_std_2eordmap_2eempty_get());
      }
    }
    V v_z_24138 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), v_x_2497, NTAG(TAG_MkUnit)));
    V v_c_24139 = heff_rec_n(2, shape_labels__vars, (V[]){v_t_24137, v_z_24138});
    V v_t_24148 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam5, 1, 1, (V[]){heff_dup(v_c_24139)}), heff_dup(v_cls_24132)));
    V v_t_24149 = ({ V a_0 = heff_dup(v_c_24139); V a_1 = v_t_24148; V r_ = (g_list_2efoldl_24s648184591x1070837587(a_0, a_1)); heff_drop(v_t_24148); r_; });
    V v_t_24159 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2edefun_2eanalyse_24cpr_lam7, 1, 1, (V[]){v_c_24139}), v_cls_24132));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24149, v_t_24159});
  } else {
    heff_drop(v_x_2497);
    heff_drop_rec(v_st_2491, 6);
    heff_drop(v_t_24131);
    return v_cls_2496;
  }
}
V g_heff_2ecompile_2edefun_2eallGiven_lam0(V self, V *args);
V g_heff_2ecompile_2edefun_2eallGiven_lam1(V self, V *args);
Clo g_heff_2ecompile_2edefun_2eallGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eallGiven_entry, 3, 0};

V g_heff_2ecompile_2edefun_2eallGiven(V v_g_240, V v_bodies_241, V v_s_242) {
top: ;
  V v_given_243 = heff_take_field(v_s_242, 4);
  V v_known_244 = heff_get_n(v_s_242, 3, 5);
  V v_t_245 = ({ V a_0 = v_known_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_known_244); r_; });
  V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eallGiven_lam0, 1, 1, (V[]){heff_dup(v_given_243)}); V a_1 = v_t_245; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_245); r_; });
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    V v_t_2422 = ({ V b_0 = heff_get_n(v_g_240, 2, 3); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2423 = (g_list_2emap_24s1415906091x1371825187(v_t_2422));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eallGiven_lam1, 1, 2, (V[]){v_given_243, heff_dup(v_bodies_241)}); V a_1 = v_t_2423; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2423); r_; });
  } else {
    heff_drop_rec(v_g_240, 3);
    heff_drop(v_given_243);
    heff_drop(v_t_2421);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2edefun_2eallGiven_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2edefun_2eallGiven(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2edefun_2eallGiven_lam0(V self, V *args) {
  V v_kp_246 = args[0];
  V v_given_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_kp_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_dup(heff_field(v_kp_246, 0));
    v_t_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_kp_246);
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_given_243; V a_1 = v_t_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_given_243); heff_drop(v_t_249); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_t_2415;
    switch (heff_tag_of(v_kp_246)) {
    case TAG_MkPair: {
      V v_y_2414 = heff_field(v_kp_246, 1);
      heff_take_n(v_kp_246, 2ULL, 2);
      v_t_2415 = v_y_2414;
      break;
    }
    default: heff_nomatch(v_kp_246);
    }
    V v_y_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2415; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
    V v_t_2420;
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2417 = v_field_2412;
      switch (heff_tag_of(v_x_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x_2417, 0);
        heff_take_n(v_x_2417, 1ULL, 2);
        v_t_2420 = v_x_2418;
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
    } else {
      heff_drop(v_field_2412);
      v_t_2420 = MK_INT(0LL);
    }
    V v_ret_24bool = heff_bool(heff_intLe_c_lent(v_y_2416, v_t_2420, 0));
    heff_drop(v_y_2416);
    heff_drop(v_t_2420);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2edefun_2eallGiven_lam1(V self, V *args) {
  V v_k_2424 = args[0];
  V v_given_243 = heff_env(self)[0];
  V v_bodies_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2425 = ({ V a_0 = v_given_243; V a_1 = v_k_2424; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_given_243); r_; });
  {
    V v_field_2427 = v_t_2425.f[1];
    int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
    HeffT2 v_t_2428 = ({ V a_0 = v_bodies_241; V a_1 = v_k_2424; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_241); heff_drop(v_k_2424); r_; });
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      V v_t_2471;
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_x_2431 = v_field_2430;
        switch (heff_tag_of(v_x_2431)) {
        case TAG_EVar: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELam: {
          V v_xs_2434 = heff_field(v_x_2431, 0);
          heff_take_n(v_x_2431, 1ULL, 2);
          v_t_2471 = v_xs_2434;
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_x_2431, 0ULL, 2);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_x_2431, 0ULL, 3);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_x_2431, 0ULL, 2);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_x_2431, 0ULL, 4);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_x_2431, 0ULL, 3);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_x_2431, 0ULL, 2);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_x_2431, 0ULL, 2);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_x_2431, 0ULL, 2);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EStr: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_x_2431, 0ULL, 2);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EAbandon: {
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_x_2431, 0ULL, 3);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_x_2431, 0ULL, 1);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_x_2431, 0ULL, 2);
          v_t_2471 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_x_2431);
        }
      } else {
        heff_drop(v_field_2430);
        v_t_2471 = NTAG(TAG_Nil);
      }
      V v_y_2472 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2471; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2471); r_; });
      V v_t_2476;
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_x_2473 = v_field_2427;
        switch (heff_tag_of(v_x_2473)) {
        case TAG_MkPair: {
          V v_x_2474 = heff_field(v_x_2473, 0);
          heff_take_n(v_x_2473, 1ULL, 2);
          v_t_2476 = v_x_2474;
          break;
        }
        default: heff_nomatch(v_x_2473);
        }
      } else {
        heff_drop(v_field_2427);
        v_t_2476 = MK_INT(1000000LL);
      }
      V v_ret_24bool = heff_bool(heff_intLe_c_lent(v_y_2472, v_t_2476, 0));
      heff_drop(v_y_2472);
      heff_drop(v_t_2476);
      return v_ret_24bool;
    }
  }
}
Clo g_heff_2ecompile_2edefun_2eextLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eextLam_entry, 5, 0};

V g_heff_2ecompile_2edefun_2eextLam(V v_y_240, V v_ys_241, V v_b_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_y_240, v_ys_241}), v_b_242});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_z_244});
  }
  case TAG_Just: {
    V v_n_246 = heff_field(v_x4_243, 0);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_241));
    V v_y_248 = heff_intAdd(MK_INT(1LL), v_t_247);
    if (heff_intLt_c_lent(v_y_248, v_n_246, 1)) {
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_241));
      V v_t_2410 = heff_intSub(heff_intSub(heff_dup(v_n_246), MK_INT(1LL)), v_t_249);
      HeffT2 v_t_2411 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_2410, v_z_244));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_x_2414 = v_field_2412;
        V v_n_2415 = v_field_2413;
        V v_t_2416 = (g_prelude_2e_2b_2b(v_ys_241, heff_dup(v_x_2414)));
        V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextendAt_clo), 1, (V[]){v_x_2414}));
        V v_t_2418 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_t_2417, v_b_242));
        V v_x_2419 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_y_240, v_t_2416}), v_t_2418});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_n_2415});
      }
    } else {
      V v_t_2420 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_y_240, v_ys_241}), v_b_242});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_z_244});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2edefun_2eextLam_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2edefun_2eextLam(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2edefun_2eextGo_lam0(V self, V *args);
V g_heff_2ecompile_2edefun_2eextGo_lam1(V self, V *args);
V g_heff_2ecompile_2edefun_2eextGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2edefun_2eextGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eextGo_entry, 2, 0};

V g_heff_2ecompile_2edefun_2eextGo(V v_w_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELam: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_Nil: {
      HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2edefun_2eextGo_lam0, 2, 1, (V[]){heff_dup(v_w_240)}), v_e_241);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_e1_242, 0);
      V v_ys_247 = heff_field(v_e1_242, 1);
      heff_take_n(v_e1_242, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_ELam: {
        V v_b_249 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        V v_m_2410 = (g_heff_2ecompile_2edefun_2eextGo(v_w_240, v_b_249));
        return heff_clo_n(g_heff_2ecompile_2edefun_2eextGo_lam1, 1, 4, (V[]){v_m_2410, heff_dup(v_w_240), v_y_246, v_ys_247});
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2edefun_2eextGo_lam2, 2, 1, (V[]){heff_dup(v_w_240)}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2edefun_2eextGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2edefun_2eextGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2edefun_2eextGo_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_p_245 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_244);
  return ({ V a_0 = v_w_240; V a_1 = v_p_245; V r_ = (g_heff_2ecompile_2edefun_2eextGo(a_0, a_1)); heff_drop(v_w_240); r_; });
}
V g_heff_2ecompile_2edefun_2eextGo_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_ys_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = ({ V a_0 = v_w_240; V a_1 = v_y_246; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_w_240); r_; });
    return ({ V a_0 = v_ru_24x2_2412_24MkPair; V a_1 = v_y_246; V a_2 = v_ys_247; V a_3 = v_x_2413; V a_4 = v_t_2415; V a_5 = v_n_2414; V r_ = (g_heff_2ecompile_2edefun_2eextLam_24tok2(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2415); r_; });
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2edefun_2eextGo_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_p_2417 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2416);
  return ({ V a_0 = v_w_240; V a_1 = v_p_2417; V r_ = (g_heff_2ecompile_2edefun_2eextGo(a_0, a_1)); heff_drop(v_w_240); r_; });
}
V g_heff_2ecompile_2edefun_2egrownBy_lam1(V self, V *args);
V g_heff_2ecompile_2edefun_2egrownBy_lam0(V self, V *args);
Clo g_heff_2ecompile_2edefun_2egrownBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2egrownBy_entry, 4, 0};

V g_heff_2ecompile_2edefun_2egrownBy(V v_g_240, V v_gr_241, V v_w_242, V v_tops_243) {
top: ;
  V v_bodies_244 = heff_take_field(v_gr_241, 0);
  V v_supply_245 = heff_take_field(v_gr_241, 2);
  V v_grown_246 = heff_get_n(v_gr_241, 1, 3);
  V v_ps_247 = (g_prelude_2e_2b_2b(heff_dup(v_w_242), v_tops_243));
  V v_w_248 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_247; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_247); r_; });
  V v_t_2420 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2edefun_2egrownBy_lam0, 1, 2, (V[]){v_bodies_244, v_w_248}), heff_get_n(v_g_240, 0, 3)));
  V v_x3_2421 = heff_tr(heff_call(v_t_2420, 1, (V[]){v_supply_245}));
  switch (heff_tag_of(v_x3_2421)) {
  case TAG_MkPair: {
    V v_kbs_2422 = heff_field(v_x3_2421, 0);
    V v_n_2423 = heff_field(v_x3_2421, 1);
    V v_ru_24x3_2421_24MkPair = heff_take_reuse_n(v_x3_2421, 3ULL, 2);
    V v_t_2424 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_kbs_2422; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_kbs_2422); r_; });
    V v_xs_2425 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x3_2421_24MkPair, v_w_242));
    V v_b_2426 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2425; V r_ = (g_list_2efoldl_24s278088687x1269971185(a_0, a_1)); heff_drop(v_xs_2425); r_; });
    V v_t_2427 = ({ V a_0 = v_b_2426; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_b_2426); r_; });
    V v_t_2428 = (g_list_2emap_24s1415906091x1371825187(v_t_2427));
    V v_t_2429 = ({ V a_0 = v_grown_246; V a_1 = v_t_2428; V r_ = (g_list_2efoldl_24s278088687x1269971185(a_0, a_1)); heff_drop(v_t_2428); r_; });
    return heff_rec_n(3, shape_bodies__grown__supply, (V[]){v_t_2424, v_t_2429, v_n_2423});
  }
  default: return heff_nomatch(v_x3_2421);
  }
}
V g_heff_2ecompile_2edefun_2egrownBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2egrownBy(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2edefun_2egrownBy_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_249, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2edefun_2egrownBy_lam0(V self, V *args) {
  V v_k_249 = args[0];
  V v_bodies_244 = heff_env(self)[0];
  V v_w_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = ({ V a_0 = v_bodies_244; V a_1 = v_k_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_244); r_; });
  V v_t_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      v_t_2414 = v_x_2413;
    } else {
      heff_drop(v_field_2412);
      v_t_2414 = NTAG(TAG_EAbandon);
    }
  }
  V v_m_2415 = ({ V a_0 = v_w_248; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2edefun_2eextGo(a_0, a_1)); heff_drop(v_w_248); r_; });
  return heff_clo_n(g_heff_2ecompile_2edefun_2egrownBy_lam1, 1, 2, (V[]){v_m_2415, v_k_249});
}
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2ecompile_2edefun_2egrow_24cpr(V v_g_240, V v_box_24left_241, V v_gr_242) {
  int64_t v_left_241 = heff_unbox_word(v_box_24left_241);
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2edefun_2eanalyse_24cpr(NTAG(TAG_False), heff_dup(v_g_240), heff_dup(heff_rfield(v_gr_242, 0))));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_s_246 = v_field_245;
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_246, 2))));
      V v_w_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2egrow_24cpr_lam0, 2, 1, (V[]){heff_dup(v_s_246)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
      V v_g_2425 = heff_dup(v_g_240);
      V v_bodies_2426 = heff_dup(heff_rfield(v_gr_242, 0));
      V v_s_2427 = heff_dup(v_s_246);
      V v_known_2428 = heff_take_field(v_s_2427, 3);
      V v_given_2429 = heff_get_n(v_s_2427, 4, 5);
      V v_xs_2430 = ({ V a_0 = v_known_2428; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_known_2428); r_; });
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
      V v_t_2457 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2egrow_24cpr_lam2, 2, 1, (V[]){v_given_2429}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
      V v_xs_2458 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_g_2425, 2), NTAG(TAG_Nil)));
      V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2458));
      V v_t_24115 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2egrow_24cpr_lam3, 2, 2, (V[]){v_g_2425, v_bodies_2426}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2459; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2459); r_; });
      V v_tops_24116 = (g_prelude_2e_2b_2b(v_t_2457, v_t_24115));
      V v_t_24117 = heff_get_n(v_s_246, 2, 5);
      switch (heff_tag_of(v_t_24117)) {
      case TAG_Nil: {
        heff_drop(v_g_240);
        heff_drop_rec(v_gr_242, 3);
        heff_drop(v_w_2424);
        heff_drop(v_tops_24116);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        heff_take_n(v_t_24117, 0ULL, 2);
        switch (heff_tag_of(v_w_2424)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_tops_24116)) {
          case TAG_Nil: {
            heff_drop(v_g_240);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_gr_242}});
          }
          case TAG_Cons: {
            if ((v_left_241 <= ((int64_t)0ULL))) {
              heff_drop(v_g_240);
              heff_drop_rec(v_gr_242, 3);
              heff_drop_tag(v_tops_24116, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            } else {
              V v_t_24122 = (g_heff_2ecompile_2edefun_2egrownBy(heff_dup(v_g_240), v_gr_242, v_w_2424, v_tops_24116));
              V t_0 = v_g_240;
              int64_t t_1 = (v_left_241 - ((int64_t)1ULL));
              V t_2 = v_t_24122;
              v_g_240 = t_0;
              v_left_241 = t_1;
              v_gr_242 = t_2;
              goto top;
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_tops_24116)}});
          }
        }
        case TAG_Cons: {
          if ((v_left_241 <= ((int64_t)0ULL))) {
            heff_drop(v_g_240);
            heff_drop_rec(v_gr_242, 3);
            heff_drop_tag(v_w_2424, 2);
            heff_drop(v_tops_24116);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            V v_t_24125 = (g_heff_2ecompile_2edefun_2egrownBy(heff_dup(v_g_240), v_gr_242, v_w_2424, v_tops_24116));
            V t_0 = v_g_240;
            int64_t t_1 = (v_left_241 - ((int64_t)1ULL));
            V t_2 = v_t_24125;
            v_g_240 = t_0;
            v_left_241 = t_1;
            v_gr_242 = t_2;
            goto top;
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_w_2424)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24117)}});
      }
    } else {
      heff_drop(v_g_240);
      heff_drop_rec(v_gr_242, 3);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam1(V self, V *args) {
  V v_acc_2415 = args[0];
  V v_x_2416 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_n_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = ({ V b_0 = heff_get_n(v_c_2410, 4, 5); V a_1 = v_x_2416; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2419;
      v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2420, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    } else {
      heff_drop(v_field_2419);
      v_t_2421 = MK_INT(0LL);
    }
  }
  V v_t_2422;
  if (heff_intLt_c_lent(v_t_2421, v_n_2412, 1)) {
    v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_n_2412}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_x_2416);
    heff_drop(v_n_2412);
    v_t_2422 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2422, v_acc_2415));
}
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_s_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2410 = heff_dup(heff_rfield(v_s_246, 0));
  V v_k_2411 = heff_dup(v_x_249);
  V v_n_2412 = (g_heff_2ecompile_2edefun_2earityOfClass(heff_get_n(v_s_246, 0, 5), v_x_249));
  V v_t_2413 = ({ V b_0 = heff_get_n(v_k_2411, 0, 2); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2414 = (g_list_2efoldl_24f511009896x1182531686(NTAG(TAG_Nil), v_t_2413));
  V v_t_2423 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2egrow_24cpr_lam1, 2, 2, (V[]){v_c_2410, v_n_2412}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2414; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  return (g_prelude_2e_2b_2b(v_t_2423, v_acc_248));
}
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam2(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_x_2433 = args[1];
  V v_given_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_given_2434 = v_given_2429;
  V v_kp_2435 = v_x_2433;
  V v_t_2456;
  switch (heff_tag_of(v_kp_2435)) {
  case TAG_MkPair: {
    V v_k_2436 = heff_field(v_kp_2435, 0);
    V v_kp2_2437 = heff_field(v_kp_2435, 1);
    V v_ru_24kp_2435_24MkPair = heff_take_reuse_n(v_kp_2435, 3ULL, 2);
    switch (heff_tag_of(v_kp2_2437)) {
    case TAG_Nil: {
      heff_drop(v_given_2434);
      heff_drop(v_k_2436);
      heff_drop_cell(v_ru_24kp_2435_24MkPair, 2);
      v_t_2456 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_p_2438 = heff_field(v_kp2_2437, 0);
      V v_ps_2439 = heff_field(v_kp2_2437, 1);
      V v_ru_24kp2_2437_24Cons = heff_take_reuse_n(v_kp2_2437, 3ULL, 2);
      HeffT2 v_t_2440 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_given_2434, v_k_2436));
      {
        V v_field_2442 = v_t_2440.f[1];
        int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
        V v_t_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ps_2439; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ps_2439); r_; });
        V v_y_2444 = heff_intAdd(MK_INT(1LL), v_t_2443);
        V v_t_2448;
        if ((v_tag_2441 == ((int64_t)0ULL))) {
          V v_x_2445 = v_field_2442;
          switch (heff_tag_of(v_x_2445)) {
          case TAG_MkPair: {
            V v_y_2447 = heff_field(v_x_2445, 1);
            heff_take_n(v_x_2445, 2ULL, 2);
            v_t_2448 = v_y_2447;
            break;
          }
          default: heff_nomatch(v_x_2445);
          }
        } else {
          heff_drop(v_field_2442);
          v_t_2448 = MK_INT(0LL);
        }
        if (heff_intLt_c(v_y_2444, v_t_2448)) {
          HeffT2 v_t_2449 = ({ V a_0 = v_given_2434; V a_1 = v_k_2436; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_given_2434); heff_drop(v_k_2436); r_; });
          V v_t_2455;
          {
            V v_field_2451 = v_t_2449.f[1];
            int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
            if ((v_tag_2450 == ((int64_t)0ULL))) {
              V v_x_2452 = v_field_2451;
              switch (heff_tag_of(v_x_2452)) {
              case TAG_MkPair: {
                V v_y_2454 = heff_field(v_x_2452, 1);
                heff_take_n(v_x_2452, 2ULL, 2);
                v_t_2455 = v_y_2454;
                break;
              }
              default: heff_nomatch(v_x_2452);
              }
            } else {
              heff_drop(v_field_2451);
              v_t_2455 = MK_INT(0LL);
            }
          }
          v_t_2456 = heff_tag_at_n(v_ru_24kp2_2437_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24kp_2435_24MkPair, TAG_MkPair, 2, (V[]){v_p_2438, v_t_2455}), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_given_2434);
          heff_drop(v_k_2436);
          heff_drop_cell(v_ru_24kp_2435_24MkPair, 2);
          heff_drop(v_p_2438);
          heff_drop_cell(v_ru_24kp2_2437_24Cons, 2);
          v_t_2456 = NTAG(TAG_Nil);
        }
      }
      break;
    }
    default: heff_nomatch(v_kp2_2437);
    }
    break;
  }
  default: heff_nomatch(v_kp_2435);
  }
  return (g_prelude_2e_2b_2b(v_t_2456, v_acc_2432));
}
V g_heff_2ecompile_2edefun_2egrow_24cpr_lam3(V self, V *args) {
  V v_acc_2460 = args[0];
  V v_x_2461 = args[1];
  V v_g_2425 = heff_env(self)[0];
  V v_bodies_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_g_2462 = v_g_2425;
  heff_drop(v_g_2462);
  V v_bodies_2463 = v_bodies_2426;
  V v_x3_2464 = v_x_2461;
  V v_t_24114;
  switch (heff_tag_of(v_x3_2464)) {
  case TAG_MkPair: {
    V v_k_2465 = heff_field(v_x3_2464, 0);
    V v_n_2466 = heff_field(v_x3_2464, 1);
    V v_ru_24x3_2464_24MkPair = heff_take_reuse_n(v_x3_2464, 3ULL, 2);
    HeffT2 v_t_2467 = ({ V a_0 = v_bodies_2463; V a_1 = v_k_2465; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_2463); heff_drop(v_k_2465); r_; });
    {
      V v_field_2469 = v_t_2467.f[1];
      int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
      if ((v_tag_2468 == ((int64_t)0ULL))) {
        V v_x_2470 = v_field_2469;
        switch (heff_tag_of(v_x_2470)) {
        case TAG_EVar: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELam: {
          V v_xs_2473 = heff_field(v_x_2470, 0);
          V v_ru_24x_2470_24ELam = heff_take_reuse_n(v_x_2470, 1ULL, 2);
          switch (heff_tag_of(v_xs_2473)) {
          case TAG_Nil: {
            heff_drop(v_n_2466);
            heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
            heff_drop_cell(v_ru_24x_2470_24ELam, 2);
            v_t_24114 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_p_2475 = heff_field(v_xs_2473, 0);
            V v_ps_2476 = heff_field(v_xs_2473, 1);
            heff_take_n(v_xs_2473, 3ULL, 2);
            V v_t_2477 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ps_2476; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ps_2476); r_; });
            V v_y_2478 = heff_intAdd(MK_INT(1LL), v_t_2477);
            if (heff_intLt_c_lent(v_y_2478, v_n_2466, 1)) {
              v_t_24114 = heff_tag_at_n(v_ru_24x_2470_24ELam, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_2464_24MkPair, TAG_MkPair, 2, (V[]){v_p_2475, v_n_2466}), NTAG(TAG_Nil)});
            } else {
              heff_drop(v_n_2466);
              heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
              heff_drop_cell(v_ru_24x_2470_24ELam, 2);
              heff_drop(v_p_2475);
              v_t_24114 = NTAG(TAG_Nil);
            }
            break;
          }
          default: heff_nomatch(v_xs_2473);
          }
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_x_2470, 0ULL, 2);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_x_2470, 0ULL, 3);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_x_2470, 0ULL, 2);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_x_2470, 0ULL, 4);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_x_2470, 0ULL, 3);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_x_2470, 0ULL, 2);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_x_2470, 0ULL, 2);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_x_2470, 0ULL, 2);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EStr: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_x_2470, 0ULL, 2);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EAbandon: {
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_x_2470, 0ULL, 3);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_x_2470, 0ULL, 1);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_x_2470, 0ULL, 2);
          heff_drop(v_n_2466);
          heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
          v_t_24114 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_x_2470);
        }
      } else {
        heff_drop(v_n_2466);
        heff_drop_cell(v_ru_24x3_2464_24MkPair, 2);
        heff_drop(v_field_2469);
        v_t_24114 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_x3_2464);
  }
  return (g_prelude_2e_2b_2b(v_t_24114, v_acc_2460));
}
HEFF_LIT(g_heff_2ecompile_2edefun_2eplanOf_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2edefun_2eplanOf_24cpr_str1, 6, "$apply");
V g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2ecompile_2edefun_2eplanOf_24cpr(V v_g_240, V v_grown_241, V v_bodies_242, V v_s_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2edefun_2enumberedGo(MK_INT(0LL), heff_dup(heff_rfield(v_s_243, 2))));
  V v_es_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_s_243)}), v_t_244));
  switch (heff_tag_of(v_es_2416)) {
  case TAG_Nil: {
    heff_drop_rec(v_g_240, 3);
    heff_drop_rec(v_s_243, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_2416));
    if (heff_intLt_c(MK_INT(4LL), v_x_2419)) {
      heff_drop_rec(v_g_240, 3);
      heff_drop_rec(v_s_243, 5);
      heff_drop_tag(v_es_2416, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V v_x1_2420 = (g_heff_2ecompile_2edefun_2eallGiven(v_g_240, v_bodies_242, heff_dup(v_s_243)));
      if (!(heff_dup(v_x1_2420) == NTAG(TAG_True))) {
        heff_drop_rec(v_s_243, 5);
        heff_drop_tag(v_es_2416, 2);
        heff_drop(v_x1_2420);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_x1_2420);
        V v_x1_2421 = (g_list_2eall_24s1395959145x1097496552(heff_dup(heff_rfield(v_s_243, 0)), heff_dup(v_es_2416)));
        if (!(heff_dup(v_x1_2421) == NTAG(TAG_True))) {
          heff_drop_rec(v_s_243, 5);
          heff_drop_tag(v_es_2416, 2);
          heff_drop(v_x1_2421);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          heff_drop(v_x1_2421);
          V v_b_2422 = (g_list_2efoldl_24s2076975989x1982453350(heff_dup(g_std_2eordmap_2eempty_get()), heff_rfield(v_s_243, 2)));
          V v_t_2423 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_grown_241, NTAG(TAG_Nil)));
          V v_t_2424 = (g_list_2emap_24s1415906091x1371825187(v_t_2423));
          V v_x1_2430 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam1, 1, 1, (V[]){v_b_2422}); V a_1 = v_t_2424; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2424); r_; });
          if (!(heff_dup(v_x1_2430) == NTAG(TAG_True))) {
            heff_drop_rec(v_s_243, 5);
            heff_drop_tag(v_es_2416, 2);
            heff_drop(v_x1_2430);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          } else {
            heff_drop(v_x1_2430);
            V v_s_2431 = heff_dup(v_s_243);
            V v_es_2432 = heff_dup(v_es_2416);
            V v_pairs_2433 = (g_list_2ezipWith_24s1876717925x1404326288(v_es_2416, heff_get_n(v_s_243, 2, 5)));
            V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2432)));
            V v_ps_2438 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam2, 2, 1, (V[]){heff_dup(v_s_2431)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2434; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
            V v_t_2439 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2438; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2438); r_; });
            V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_pairs_2433));
            V v_ps_2441 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2440; V r_ = (g_list_2efoldl_24s1540385767x593157740(a_0, a_1)); heff_drop(v_t_2440); r_; });
            V v_t_2442 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2441; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2441); r_; });
            V v_t_2443 = heff_get_n(heff_get_n(v_s_2431, 0, 5), 4, 5);
            V v_f_2444 = heff_rec_n(4, shape_labs__vars__applies__lams, (V[]){v_t_2439, v_t_2442, v_es_2432, v_t_2443});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2444}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_es_2416)}});
  }
}
V g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam0(V self, V *args) {
  V v_x3_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_s_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_245)) {
  case TAG_MkPair: {
    V v_i_246 = heff_field(v_x3_245, 0);
    V v_k_247 = heff_field(v_x3_245, 1);
    heff_take_n(v_x3_245, 3ULL, 2);
    V v_t_248 = heff_get_n(v_g_240, 0, 3);
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2edefun_2eplanOf_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 2);
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2edefun_2eplanOf_24cpr_str1)), heff_intShow(v_i_246));
    V v_t_2413 = (g_heff_2ecompile_2edefun_2earityOfClass(heff_get_n(v_s_243, 0, 5), heff_dup(v_k_247)));
    V v_t_2414 = ({ V b_0 = heff_get_n(v_k_247, 0, 2); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2415 = (g_list_2emap_24s1415906091x1371825187(v_t_2414));
    return heff_rec_n(3, shape_key__n__labels, (V[]){v_t_2412, v_t_2413, v_t_2415});
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_b_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2426 = ({ V a_0 = v_b_2422; V a_1 = v_x_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_b_2422); heff_drop(v_x_2425); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2427 == ((int64_t)0ULL)) && ({ V v_x_2429 = heff_dup(v_field_2428); int c_ = 1; heff_drop(v_x_2429); c_; })));
    heff_drop(v_field_2428);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2edefun_2eplanOf_24cpr_lam2(V self, V *args) {
  V v_acc_2435 = args[0];
  V v_x_2436 = args[1];
  V v_s_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2437 = (g_heff_2ecompile_2edefun_2enumberedGo(MK_INT(0LL), heff_dup(heff_rfield(v_x_2436, 2))));
  return (g_prelude_2e_2b_2b_24f1589519835x26889547(v_acc_2435, heff_get_n(v_s_2431, 0, 5), v_x_2436, v_t_2437));
}
V g_heff_2ecompile_2edefun_2erw_lam0(V self, V *args);
V g_heff_2ecompile_2edefun_2erw_lam1(V self, V *args);
V g_heff_2ecompile_2edefun_2erw_lam2(V self, V *args);
V g_heff_2ecompile_2edefun_2erw_lam3(V self, V *args);
Clo g_heff_2ecompile_2edefun_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2erw_entry, 2, 0};

V g_heff_2ecompile_2edefun_2erw(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELam: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_Nil: {
      HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2edefun_2erw_lam0, 2, 1, (V[]){v_p_240}), v_e_241);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_e1_242, 0);
      V v_ys_247 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24Cons = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_ELam: {
        V v_b_249 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_go_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2edefun_2erw_clo), 1, (V[]){heff_dup(v_p_240)}));
        HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_p_240, 0, 4); V a_1 = v_y_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_y_246);
            heff_drop(v_ys_247);
            heff_drop(v_b_249);
            heff_drop(v_go_2410);
            V v_i_2414 = v_field_2413;
            V v_tag_2415 = heff_take_field(v_i_2414, 0);
            V v_fvs_2416 = heff_get_n(v_i_2414, 1, 2);
            V v_t_2417 = (g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24e1_242_24Cons, heff_dup(v_fvs_2416)));
            V v_t_2418 = (g_list_2emap_24s2029035892x1571084362_24tok2(v_ru_24e_241_24ELam, v_fvs_2416));
            return heff_tag_n(TAG_ETag, 3, (V[]){v_tag_2415, v_t_2417, v_t_2418});
          } else {
            heff_drop(v_field_2413);
            V v_t_2419 = heff_tr(heff_call(v_go_2410, 1, (V[]){v_b_249}));
            return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_247}), v_t_2419});
          }
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  case TAG_EApp: {
    V v_f_2420 = heff_field(v_e_241, 0);
    V v_args_2421 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2edefun_2erw_clo), 1, (V[]){heff_dup(v_p_240)}));
    V v_p_2423 = v_p_240;
    V v_e_2424 = heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_dup(v_f_2420), heff_dup(v_args_2421)});
    HeffT2 v_t_2425 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_2420));
    V v_sp_2431;
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_h_2428 = v_field_2426;
      V v_bs_2429 = v_field_2427;
      V v_t_2430 = (g_heff_2ecompile_2eir_2eappendI(v_bs_2429, v_args_2421));
      v_sp_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2428, v_t_2430});
    }
    switch (heff_tag_of(v_sp_2431)) {
    case TAG_MkPair: {
      V v_sp1_2432 = heff_field(v_sp_2431, 0);
      V v_args_2433 = heff_field(v_sp_2431, 1);
      V v_ru_24sp_2431_24MkPair = heff_take_reuse_n(v_sp_2431, 3ULL, 2);
      switch (heff_tag_of(v_sp1_2432)) {
      case TAG_EVar: {
        V v_x_2434 = heff_field(v_sp1_2432, 0);
        V v_ru_24sp1_2432_24EVar = heff_take_reuse_n(v_sp1_2432, 1ULL, 1);
        V v_go_2435 = v_go_2422;
        V v_x_2436 = heff_dup(v_x_2434);
        V v_args_2437 = v_args_2433;
        HeffT2 v_t_2438 = ({ V b_0 = heff_get_n(v_p_2423, 1, 4); V a_1 = v_x_2434; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2434); r_; });
        {
          V v_field_2440 = v_t_2438.f[1];
          int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
          V v_e_2441 = v_e_2424;
          if ((v_tag_2439 == ((int64_t)0ULL))) {
            heff_drop(v_e_2441);
            V v_a_2442 = v_field_2440;
            V v_key_2443 = heff_take_field(v_a_2442, 0);
            V v_n_2444 = heff_get_n(v_a_2442, 1, 3);
            V v_key_2445 = v_key_2443;
            V v_t_2446 = (g_list_2etake(heff_dup(v_n_2444), heff_dup(v_args_2437)));
            V v_t_2447 = (g_list_2emap(heff_dup(v_go_2435), v_t_2446));
            V v_es_2448 = heff_tag_at_n(v_ru_24sp_2431_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24sp1_2432_24EVar, TAG_EVar, 1, (V[]){v_x_2436}), v_t_2447});
            V v_t_2449 = ({ V a_0 = v_n_2444; V a_1 = v_args_2437; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_args_2437); r_; });
            V v_rest_2450 = (g_list_2emap(v_go_2435, v_t_2449));
            switch (heff_tag_of(v_rest_2450)) {
            case TAG_Nil: {
              return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2445}), v_es_2448});
            }
            case TAG_Cons: {
              V v_t_2453 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_2445}), v_es_2448});
              return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2453, v_rest_2450});
            }
            default: return heff_nomatch(v_rest_2450);
            }
          } else {
            heff_drop_cell(v_ru_24sp1_2432_24EVar, 1);
            heff_drop(v_x_2436);
            heff_drop(v_args_2437);
            heff_drop(v_field_2440);
            return (g_heff_2ecompile_2eir_2emapParts_24tok2(v_ru_24sp_2431_24MkPair, heff_clo_n(g_heff_2ecompile_2edefun_2erw_lam1, 1, 1, (V[]){v_go_2435}), v_e_2441));
          }
        }
      }
      default: {
        heff_drop_rec(v_p_2423, 4);
        heff_drop(v_sp1_2432);
        heff_drop(v_args_2433);
        return (g_heff_2ecompile_2eir_2emapParts_24tok2(v_ru_24sp_2431_24MkPair, heff_clo_n(g_heff_2ecompile_2edefun_2erw_lam2, 1, 1, (V[]){v_go_2422}), v_e_2424));
      }
      }
    }
    default: return heff_nomatch(v_sp_2431);
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2edefun_2erw_lam3, 2, 1, (V[]){v_p_240}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2edefun_2erw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2erw(a[0], a[1]);
}
V g_heff_2ecompile_2edefun_2erw_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_q_245 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_244);
  return (g_heff_2ecompile_2edefun_2erw(v_p_240, v_q_245));
}
V g_heff_2ecompile_2edefun_2erw_lam1(V self, V *args) {
  V v_x_2454 = args[0];
  V v_go_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2454);
  return v_go_2435;
}
V g_heff_2ecompile_2edefun_2erw_lam2(V self, V *args) {
  V v_x_2455 = args[0];
  V v_go_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2455);
  return v_go_2422;
}
V g_heff_2ecompile_2edefun_2erw_lam3(V self, V *args) {
  V v_x_2456 = args[0];
  V v_q_2457 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2456);
  return (g_heff_2ecompile_2edefun_2erw(v_p_240, v_q_2457));
}
Clo g_heff_2ecompile_2edefun_2edefOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2edefOut_entry, 2, 0};

V g_heff_2ecompile_2edefun_2edefOut(V v_d_240, V v_def_241) {
top: ;
  V v_bodies_242 = heff_take_field(v_d_240, 0);
  V v_after_243 = heff_get_n(v_d_240, 1, 3);
  HeffT2 v_t_244 = ({ V a_0 = v_bodies_242; V a_1 = heff_rfield(v_def_241, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_242); r_; });
  V v_t_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_t_248;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = NTAG(TAG_EAbandon);
    }
    v_t_249 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_def_241, 0)), heff_dup(heff_rfield(v_def_241, 1)), v_t_248});
  }
  HeffT2 v_t_2410 = ({ V a_0 = v_after_243; V b_1 = heff_get_n(v_def_241, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_after_243); heff_drop(b_1); r_; });
  V v_t_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      v_t_2414 = v_x_2413;
    } else {
      heff_drop(v_field_2412);
      v_t_2414 = NTAG(TAG_Nil);
    }
  }
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2414});
}
V g_heff_2ecompile_2edefun_2edefOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edefun_2edefOut(a[0], a[1]);
}
Clo g_heff_2ecompile_2edefun_2eextLam_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edefun_2eextLam_24tok2_entry, 6, 0};

V g_heff_2ecompile_2edefun_2eextLam_24tok2(V v_tok_240, V v_y_241, V v_ys_242, V v_b_243, V v_x4_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_at_n(v_tok_240, TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, v_ys_242}), v_b_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_z_245});
  }
  case TAG_Just: {
    V v_n_247 = heff_field(v_x4_244, 0);
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_242));
    V v_y_249 = heff_intAdd(MK_INT(1LL), v_t_248);
    if (heff_intLt_c_lent(v_y_249, v_n_247, 1)) {
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_242));
      V v_t_2411 = heff_intSub(heff_intSub(heff_dup(v_n_247), MK_INT(1LL)), v_t_2410);
      HeffT2 v_t_2412 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_2411, v_z_245));
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_x_2415 = v_field_2413;
        V v_n_2416 = v_field_2414;
        V v_t_2417 = (g_prelude_2e_2b_2b(v_ys_242, heff_dup(v_x_2415)));
        V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextendAt_clo), 1, (V[]){v_x_2415}));
        V v_t_2419 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_t_2418, v_b_243));
        V v_x_2420 = heff_tag_at_n(v_tok_240, TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, v_t_2417}), v_t_2419});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_n_2416});
      }
    } else {
      V v_t_2421 = heff_tag_at_n(v_tok_240, TAG_ELam, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, v_ys_242}), v_b_243});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_z_245});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ecompile_2edefun_2eextLam_24tok2_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2edefun_2eextLam_24tok2(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}