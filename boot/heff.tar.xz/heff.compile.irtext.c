// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
static uint32_t shape_go[] = {LBL_go};
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2eint(V, V);
V g_heff_2ebuild_2edecoder_2eint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eint_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ecompile_2eirtext_2earmD(V, V, V);
V g_heff_2ecompile_2eirtext_2earmD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmD_clo;
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
V g_heff_2ecompile_2eirtext_2ebytesH(V, V, V, V);
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ebytesH_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eexprOf(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprOf_clo;
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldD(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldD_clo;
V g_heff_2ecompile_2eirtext_2efieldsH(V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
V g_heff_2ecompile_2eirtext_2efixedD(V, V);
V g_heff_2ecompile_2eirtext_2efixedD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efixedD_clo;
V g_heff_2ecompile_2eirtext_2ehashW(V, V, V);
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ehashW_clo;
V g_heff_2ecompile_2eirtext_2enD(V, V);
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_clo;
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsT_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2estrsT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsT_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsT(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength(heff_dup(v_x_242)));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2estrsT_str0), v_x_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2ecompile_2eirtext_2estrsT(v_xs_243, v_rest_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsT(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_rest_244 = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(v_es_243, v_rest_241));
    HEFF_LAST return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_242), v_rest_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_fs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_intShow(heff_strLength(heff_dup(v_l_244)));
      V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_str0), v_l_244));
      V v_rest_248 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_243, v_rest_241));
      V v_t_249 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_245, v_rest_248));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_t_249});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_arms_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_247 = heff_intShow(heff_strLength(heff_dup(v_t_244)));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_str0), v_t_244));
      V v_rest_249 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_243, v_rest_241));
      V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_246, v_rest_249));
      V v_t_2411 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_245));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), (g_heff_2ecompile_2eirtext_2estrsT(v_vs_245, v_rest_2410))});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2412});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41, 1, "F");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_intShow(heff_strLength(heff_dup(v_x_242)));
    V v_t_244 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str0), v_x_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_rest_241})});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength(heff_dup(v_g_245)));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str2), v_g_245));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_249, v_rest_241));
    V v_t_2411 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), (g_heff_2ecompile_2eirtext_2estrsT(v_xs_248, v_rest_2410))});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str4), v_t_2412});
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_240, 0);
    V v_as_2414 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2414));
    V v_rest_2416 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2415), ({ V a_0 = v_as_2414; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2414); r_; })});
    V v_t_2417 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_f_2413, v_rest_2416));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str5), v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_x2_240, 0);
    V v_a_2419 = heff_field(v_x2_240, 1);
    V v_b_2420 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2421 = heff_intShow(heff_strLength(heff_dup(v_x_2418)));
    V v_t_2422 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str6), v_x_2418));
    V v_rest_2423 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2420, v_rest_241));
    V v_t_2424 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_2419, v_rest_2423));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2424})});
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2426 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_2425));
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2426), (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2425, v_rest_241))});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str8), v_t_2427});
  }
  case TAG_EProj: {
    V v_e_2428 = heff_field(v_x2_240, 0);
    V v_l_2429 = heff_field(v_x2_240, 1);
    V v_sh_2430 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2431 = heff_intShow(heff_strLength(heff_dup(v_l_2429)));
    V v_t_2432 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str9), v_l_2429));
    V v_t_2433 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_sh_2430));
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2433), (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2430, v_rest_241))});
    V v_rest_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2434});
    V v_t_2436 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_2428, v_rest_2435));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str10), v_t_2436});
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_x2_240, 0);
    V v_as_2438 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ETag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439 = heff_intShow(heff_strLength(heff_dup(v_t_2437)));
    V v_t_2440 = heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str11), v_t_2437));
    V v_t_2441 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2438));
    V v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24ETag, TAG_Cons, 2, (V[]){heff_intShow(v_t_2441), ({ V a_0 = v_as_2438; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2438); r_; })});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str12), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2442})});
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_field(v_x2_240, 0);
    V v_arms_2444 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2445 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2444));
    V v_rest_2446 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2445), (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2444, v_rest_241))});
    V v_t_2447 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_s_2443, v_rest_2446));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str13), v_t_2447});
  }
  case TAG_EPrim: {
    V v_p_2448 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2449 = heff_intShow(heff_strLength(heff_dup(v_p_2448)));
    V v_t_2450 = heff_strAppend(v_t_2449, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str14), v_p_2448));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str15), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_rest_241})});
  }
  case TAG_EPrimCall: {
    V v_p_2451 = heff_field(v_x2_240, 0);
    V v_as_2452 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2453 = heff_intShow(heff_strLength(heff_dup(v_p_2451)));
    V v_t_2454 = heff_strAppend(v_t_2453, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str16), v_p_2451));
    V v_t_2455 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2452));
    V v_t_2456 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2455), ({ V a_0 = v_as_2452; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2452); r_; })});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str17), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, v_t_2456})});
  }
  case TAG_ECall: {
    V v_g_2457 = heff_field(v_x2_240, 0);
    V v_as_2458 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2459 = heff_intShow(heff_strLength(heff_dup(v_g_2457)));
    V v_t_2460 = heff_strAppend(v_t_2459, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str18), v_g_2457));
    V v_t_2461 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2458));
    V v_t_2462 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2461), ({ V a_0 = v_as_2458; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2458); r_; })});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str19), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2462})});
  }
  case TAG_EInt: {
    V v_i_2463 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2464 = heff_intShow(v_i_2463);
    V v_t_2465 = heff_intShow(heff_strLength(heff_dup(v_s_2464)));
    V v_t_2466 = heff_strAppend(v_t_2465, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str20), v_s_2464));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str21), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2467 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2468 = heff_floatShow(v_x_2467);
    V v_t_2469 = heff_intShow(heff_strLength(heff_dup(v_s_2468)));
    V v_t_2470 = heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str22), v_s_2468));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str23), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2471 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2472 = heff_intShow(heff_strLength(heff_dup(v_s_2471)));
    V v_t_2473 = heff_strAppend(v_t_2472, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str24), v_s_2471));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_rest_241})});
  }
  case TAG_EFixed: {
    V v_w_2474 = heff_field(v_x2_240, 0);
    V v_n_2475 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2476;
    switch (heff_tag_of(v_w_2474)) {
    case TAG_I8: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str26);
      break;
    }
    case TAG_I16: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str27);
      break;
    }
    case TAG_I32: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str28);
      break;
    }
    case TAG_I64: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str29);
      break;
    }
    case TAG_U8: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str30);
      break;
    }
    case TAG_U16: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str31);
      break;
    }
    case TAG_U32: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str32);
      break;
    }
    case TAG_U64: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str33);
      break;
    }
    case TAG_F32: {
      v_t_2476 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str34);
      break;
    }
    default: heff_nomatch(v_w_2474);
    }
    V v_s_2477 = heff_intShow(v_n_2475);
    V v_t_2478 = heff_intShow(heff_strLength(heff_dup(v_s_2477)));
    V v_t_2479 = heff_strAppend(v_t_2478, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str35), v_s_2477));
    V v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_2476, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str36), v_t_2480});
  }
  case TAG_EFloat32: {
    V v_x_2481 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2482 = heff_floatShow(v_x_2481);
    V v_t_2483 = heff_intShow(heff_strLength(heff_dup(v_s_2482)));
    V v_t_2484 = heff_strAppend(v_t_2483, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str37), v_s_2482));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str39), v_rest_241});
  }
  case TAG_EFix: {
    V v_f_2485 = heff_field(v_x2_240, 0);
    V v_b_2486 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2487 = heff_intShow(heff_strLength(heff_dup(v_f_2485)));
    V v_t_2488 = heff_strAppend(v_t_2487, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str40), v_f_2485));
    V v_t_2489 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){v_t_2488, (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2486, v_rest_241))});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_str41), v_t_2489});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2econsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2econsD(V v_d_240, V v_more_241, V v_s_242, V v_i_243) {
top: ;
  V v_x3_244 = heff_tr(heff_call(v_d_240, 2, (V[]){heff_dup(v_s_242), v_i_243}));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_more_241);
    heff_drop(v_s_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_244, 0);
    V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_245, 0);
      V v_j_247 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_x3_248 = heff_tr(heff_call(v_more_241, 2, (V[]){v_s_242, v_j_247}));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_244_24Just, 1);
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_249 = heff_field(v_x3_248, 0);
        heff_take_n(v_x3_248, 1ULL, 1);
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          heff_take_n(v_x31_249, 3ULL, 2);
          V v_t_2412 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_x_2410}), v_j_2411});
          return heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
        }
        default: return heff_nomatch(v_x31_249);
        }
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enD(V v_d_240, V v_n_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), MK_INT(0LL))) {
    heff_drop(v_d_240);
    heff_drop(v_n_241);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_lam0_clo);
  } else {
    V v_t_246 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_dup(v_d_240), heff_intSub(v_n_241, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_clo), 2, (V[]){v_d_240, v_t_246});
  }
}
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2enD_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  heff_drop(v_s_243);
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_244});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
}
Clo g_heff_2ecompile_2eirtext_2efieldD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldD_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2efieldD(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 1);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_s_241, v_j_246}));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_x_249}), v_j_2410});
          return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_x31_248);
        }
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldD(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V v_more_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_more_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = heff_tr(heff_call(v_more_240, 2, (V[]){v_s_241, v_j_246}));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_x_249}), v_j_2410});
          return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_x31_248);
        }
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0, 2, 0};
Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V v_n_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0_clo);
  } else {
    V v_t_245 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_tail(((V)&g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo), 1, (V[]){v_t_245});
  }
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(a[0]);
}
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
Clo g_heff_2ecompile_2eirtext_2earmD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmD_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2earmD(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 1);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_j_246));
      V v_x3_2412;
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        v_x3_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_249));
          v_x3_2412 = heff_tr(heff_call(v_t_2411, 2, (V[]){heff_dup(v_s_241), v_j_2410}));
          break;
        }
        default: heff_nomatch(v_x31_248);
        }
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
      switch (heff_tag_of(v_x3_2412)) {
      case TAG_Nothing: {
        heff_drop_rec(v_k_240, 1);
        heff_drop(v_s_241);
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2413 = heff_field(v_x3_2412, 0);
        heff_take_n(v_x3_2412, 1ULL, 1);
        switch (heff_tag_of(v_x31_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x31_2413, 0);
          V v_j_2415 = heff_field(v_x31_2413, 1);
          heff_take_n(v_x31_2413, 3ULL, 2);
          V v_x3_2416 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_s_241, v_j_2415}));
          switch (heff_tag_of(v_x3_2416)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x3_243_24Just, 1);
            heff_drop(v_x_245);
            heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
            heff_drop(v_x_2414);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2417 = heff_field(v_x3_2416, 0);
            heff_take_n(v_x3_2416, 1ULL, 1);
            switch (heff_tag_of(v_x31_2417)) {
            case TAG_MkPair: {
              V v_x_2418 = heff_field(v_x31_2417, 0);
              V v_j_2419 = heff_field(v_x31_2417, 1);
              heff_take_n(v_x31_2417, 3ULL, 2);
              V v_t_2420 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_x_245, v_x_2414, v_x_2418}), v_j_2419});
              return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2420});
            }
            default: return heff_nomatch(v_x31_2417);
            }
          }
          default: return heff_nomatch(v_x3_2416);
          }
        }
        default: return heff_nomatch(v_x31_2413);
        }
      }
      default: return heff_nomatch(v_x3_2412);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eirtext_2earmD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmD(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str8, 7, "Float32");
V g_heff_2ecompile_2eirtext_2efixedD_lam0(V self, V *args);
Clo g_heff_2ecompile_2eirtext_2efixedD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efixedD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efixedD(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x1_248 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eirtext_2efixedD_lam0, 1, 1, (V[]){v_x_244}); V b_1 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x1_248)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_j_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_j_245})});
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eirtext_2efixedD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efixedD(a[0], a[1]);
}
V g_heff_2ecompile_2eirtext_2efixedD_lam0(V self, V *args) {
  V v_w_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_w_246)) {
  case TAG_I8: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str0);
    break;
  }
  case TAG_I16: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str1);
    break;
  }
  case TAG_I32: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str2);
    break;
  }
  case TAG_I64: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str3);
    break;
  }
  case TAG_U8: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str4);
    break;
  }
  case TAG_U16: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str5);
    break;
  }
  case TAG_U32: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str6);
    break;
  }
  case TAG_U64: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str7);
    break;
  }
  case TAG_F32: {
    v_t_247 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str8);
    break;
  }
  default: heff_nomatch(v_w_246);
  }
  return heff_strEq(v_t_247, v_x_244);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str2, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str3, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str5, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str6, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str7, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str8, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str9, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str10, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str11, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str12, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str13, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str14, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str17, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str18, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str19, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str23, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str24, 1, "F");
Clo g_heff_2ecompile_2eirtext_2eexprOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprOf_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2eexprOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str0))) {
    heff_drop_rec(v_k_240, 1);
    heff_drop(v_x2_241);
    V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24Just, TAG_EVar, 1, (V[]){v_x_247}), v_j_248});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  } else {
    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str1))) {
      heff_drop_rec(v_k_240, 1);
      heff_drop(v_x2_241);
      V v_x3_2411 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2412 = heff_field(v_x3_2411, 0);
        V v_ru_24x3_2411_24Just = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x31_2412, 0);
          V v_j_2414 = heff_field(v_x31_2412, 1);
          V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
          V v_t_2415 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2411_24Just, TAG_EGlobal, 1, (V[]){v_x_2413}), v_j_2414});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
        }
        default: return heff_nomatch(v_x31_2412);
        }
      }
      default: return heff_nomatch(v_x3_2411);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str2))) {
        heff_drop(v_x2_241);
        V v_x3_2417 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_z_243));
        V v_x3_2422;
        switch (heff_tag_of(v_x3_2417)) {
        case TAG_Nothing: {
          v_x3_2422 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x31_2418 = heff_field(v_x3_2417, 0);
          heff_take_n(v_x3_2417, 1ULL, 1);
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            heff_take_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2419));
            v_x3_2422 = heff_tr(heff_call(v_t_2421, 2, (V[]){heff_dup(v_z_242), v_j_2420}));
            break;
          }
          default: heff_nomatch(v_x31_2418);
          }
          break;
        }
        default: heff_nomatch(v_x3_2417);
        }
        switch (heff_tag_of(v_x3_2422)) {
        case TAG_Nothing: {
          heff_drop_rec(v_k_240, 1);
          heff_drop(v_z_242);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2423 = heff_field(v_x3_2422, 0);
          V v_ru_24x3_2422_24Just = heff_take_reuse_n(v_x3_2422, 1ULL, 1);
          switch (heff_tag_of(v_x31_2423)) {
          case TAG_MkPair: {
            V v_x_2424 = heff_field(v_x31_2423, 0);
            V v_j_2425 = heff_field(v_x31_2423, 1);
            V v_ru_24x31_2423_24MkPair = heff_take_reuse_n(v_x31_2423, 3ULL, 2);
            V v_x3_2426 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2425}));
            switch (heff_tag_of(v_x3_2426)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x3_2422_24Just, 1);
              heff_drop(v_x_2424);
              heff_drop_cell(v_ru_24x31_2423_24MkPair, 2);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2427 = heff_field(v_x3_2426, 0);
              heff_take_n(v_x3_2426, 1ULL, 1);
              switch (heff_tag_of(v_x31_2427)) {
              case TAG_MkPair: {
                V v_x_2428 = heff_field(v_x31_2427, 0);
                V v_j_2429 = heff_field(v_x31_2427, 1);
                heff_take_n(v_x31_2427, 3ULL, 2);
                V v_t_2430 = heff_tag_at_n(v_ru_24x31_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_x_2424, v_x_2428}), v_j_2429});
                return heff_tag_at_n(v_ru_24x3_2422_24Just, TAG_Just, 1, (V[]){v_t_2430});
              }
              default: return heff_nomatch(v_x31_2427);
              }
            }
            default: return heff_nomatch(v_x3_2426);
            }
          }
          default: return heff_nomatch(v_x31_2423);
          }
        }
        default: return heff_nomatch(v_x3_2422);
        }
      } else {
        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str3))) {
          heff_drop(v_x2_241);
          V v_x3_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2432)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2433 = heff_field(v_x3_2432, 0);
            V v_ru_24x3_2432_24Just = heff_take_reuse_n(v_x3_2432, 1ULL, 1);
            switch (heff_tag_of(v_x31_2433)) {
            case TAG_MkPair: {
              V v_x_2434 = heff_field(v_x31_2433, 0);
              V v_j_2435 = heff_field(v_x31_2433, 1);
              V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
              V v_x3_2436 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_2435));
              V v_x3_2441;
              switch (heff_tag_of(v_x3_2436)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                v_x3_2441 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2437 = heff_field(v_x3_2436, 0);
                heff_take_n(v_x3_2436, 1ULL, 1);
                switch (heff_tag_of(v_x31_2437)) {
                case TAG_MkPair: {
                  V v_x_2438 = heff_field(v_x31_2437, 0);
                  V v_j_2439 = heff_field(v_x31_2437, 1);
                  heff_take_n(v_x31_2437, 3ULL, 2);
                  V v_t_2440 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_2438));
                  v_x3_2441 = heff_tr(heff_call(v_t_2440, 2, (V[]){v_z_242, v_j_2439}));
                  break;
                }
                default: heff_nomatch(v_x31_2437);
                }
                break;
              }
              default: heff_nomatch(v_x3_2436);
              }
              switch (heff_tag_of(v_x3_2441)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x3_2432_24Just, 1);
                heff_drop(v_x_2434);
                heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2442 = heff_field(v_x3_2441, 0);
                heff_take_n(v_x3_2441, 1ULL, 1);
                switch (heff_tag_of(v_x31_2442)) {
                case TAG_MkPair: {
                  V v_x_2443 = heff_field(v_x31_2442, 0);
                  V v_j_2444 = heff_field(v_x31_2442, 1);
                  heff_take_n(v_x31_2442, 3ULL, 2);
                  V v_t_2445 = heff_tag_at_n(v_ru_24x31_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2434, v_x_2443}), v_j_2444});
                  return heff_tag_at_n(v_ru_24x3_2432_24Just, TAG_Just, 1, (V[]){v_t_2445});
                }
                default: return heff_nomatch(v_x31_2442);
                }
              }
              default: return heff_nomatch(v_x3_2441);
              }
            }
            default: return heff_nomatch(v_x31_2433);
            }
          }
          default: return heff_nomatch(v_x3_2432);
          }
        } else {
          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str4))) {
            heff_drop(v_x2_241);
            V v_x3_2447 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
            switch (heff_tag_of(v_x3_2447)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 1);
              heff_drop(v_z_242);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2448 = heff_field(v_x3_2447, 0);
              V v_ru_24x3_2447_24Just = heff_take_reuse_n(v_x3_2447, 1ULL, 1);
              switch (heff_tag_of(v_x31_2448)) {
              case TAG_MkPair: {
                V v_x_2449 = heff_field(v_x31_2448, 0);
                V v_j_2450 = heff_field(v_x31_2448, 1);
                V v_ru_24x31_2448_24MkPair = heff_take_reuse_n(v_x31_2448, 3ULL, 2);
                V v_x3_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_2450}));
                switch (heff_tag_of(v_x3_2451)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop_cell(v_ru_24x3_2447_24Just, 1);
                  heff_drop(v_x_2449);
                  heff_drop_cell(v_ru_24x31_2448_24MkPair, 2);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2452 = heff_field(v_x3_2451, 0);
                  heff_take_n(v_x3_2451, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2452)) {
                  case TAG_MkPair: {
                    V v_x_2453 = heff_field(v_x31_2452, 0);
                    V v_j_2454 = heff_field(v_x31_2452, 1);
                    heff_take_n(v_x31_2452, 3ULL, 2);
                    V v_x3_2455 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2454}));
                    switch (heff_tag_of(v_x3_2455)) {
                    case TAG_Nothing: {
                      heff_drop_cell(v_ru_24x3_2447_24Just, 1);
                      heff_drop(v_x_2449);
                      heff_drop_cell(v_ru_24x31_2448_24MkPair, 2);
                      heff_drop(v_x_2453);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2456 = heff_field(v_x3_2455, 0);
                      heff_take_n(v_x3_2455, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2456)) {
                      case TAG_MkPair: {
                        V v_x_2457 = heff_field(v_x31_2456, 0);
                        V v_j_2458 = heff_field(v_x31_2456, 1);
                        heff_take_n(v_x31_2456, 3ULL, 2);
                        V v_t_2459 = heff_tag_at_n(v_ru_24x31_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2449, v_x_2453, v_x_2457}), v_j_2458});
                        return heff_tag_at_n(v_ru_24x3_2447_24Just, TAG_Just, 1, (V[]){v_t_2459});
                      }
                      default: return heff_nomatch(v_x31_2456);
                      }
                    }
                    default: return heff_nomatch(v_x3_2455);
                    }
                  }
                  default: return heff_nomatch(v_x31_2452);
                  }
                }
                default: return heff_nomatch(v_x3_2451);
                }
              }
              default: return heff_nomatch(v_x31_2448);
              }
            }
            default: return heff_nomatch(v_x3_2447);
            }
          } else {
            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str5))) {
              heff_drop(v_x2_241);
              V v_x3_2461 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_z_243));
              V v_x3_2467;
              switch (heff_tag_of(v_x3_2461)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                v_x3_2467 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2462 = heff_field(v_x3_2461, 0);
                heff_take_n(v_x3_2461, 1ULL, 1);
                switch (heff_tag_of(v_x31_2462)) {
                case TAG_MkPair: {
                  V v_x_2463 = heff_field(v_x31_2462, 0);
                  V v_j_2464 = heff_field(v_x31_2462, 1);
                  heff_take_n(v_x31_2462, 3ULL, 2);
                  V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2efieldD_clo), 1, (V[]){v_k_240}));
                  V v_t_2466 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_2465, v_x_2463));
                  v_x3_2467 = heff_tr(heff_call(v_t_2466, 2, (V[]){v_z_242, v_j_2464}));
                  break;
                }
                default: heff_nomatch(v_x31_2462);
                }
                break;
              }
              default: heff_nomatch(v_x3_2461);
              }
              switch (heff_tag_of(v_x3_2467)) {
              case TAG_Nothing: {
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2468 = heff_field(v_x3_2467, 0);
                V v_ru_24x3_2467_24Just = heff_take_reuse_n(v_x3_2467, 1ULL, 1);
                switch (heff_tag_of(v_x31_2468)) {
                case TAG_MkPair: {
                  V v_x_2469 = heff_field(v_x31_2468, 0);
                  V v_j_2470 = heff_field(v_x31_2468, 1);
                  V v_ru_24x31_2468_24MkPair = heff_take_reuse_n(v_x31_2468, 3ULL, 2);
                  V v_t_2471 = heff_tag_at_n(v_ru_24x31_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2467_24Just, TAG_ERecord, 1, (V[]){v_x_2469}), v_j_2470});
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2471});
                }
                default: return heff_nomatch(v_x31_2468);
                }
              }
              default: return heff_nomatch(v_x3_2467);
              }
            } else {
              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str6))) {
                heff_drop(v_x2_241);
                V v_x3_2473 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2473)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2474 = heff_field(v_x3_2473, 0);
                  V v_ru_24x3_2473_24Just = heff_take_reuse_n(v_x3_2473, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2474)) {
                  case TAG_MkPair: {
                    V v_x_2475 = heff_field(v_x31_2474, 0);
                    V v_j_2476 = heff_field(v_x31_2474, 1);
                    V v_ru_24x31_2474_24MkPair = heff_take_reuse_n(v_x31_2474, 3ULL, 2);
                    V v_x3_2477 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_j_2476));
                    switch (heff_tag_of(v_x3_2477)) {
                    case TAG_Nothing: {
                      heff_drop(v_z_242);
                      heff_drop_cell(v_ru_24x3_2473_24Just, 1);
                      heff_drop(v_x_2475);
                      heff_drop_cell(v_ru_24x31_2474_24MkPair, 2);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2478 = heff_field(v_x3_2477, 0);
                      heff_take_n(v_x3_2477, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2478)) {
                      case TAG_MkPair: {
                        V v_x_2479 = heff_field(v_x31_2478, 0);
                        V v_j_2480 = heff_field(v_x31_2478, 1);
                        heff_take_n(v_x31_2478, 3ULL, 2);
                        V v_x3_2481 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_2480));
                        V v_x3_2486;
                        switch (heff_tag_of(v_x3_2481)) {
                        case TAG_Nothing: {
                          heff_drop(v_z_242);
                          v_x3_2486 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x31_2482 = heff_field(v_x3_2481, 0);
                          heff_take_n(v_x3_2481, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2482)) {
                          case TAG_MkPair: {
                            V v_x_2483 = heff_field(v_x31_2482, 0);
                            V v_j_2484 = heff_field(v_x31_2482, 1);
                            heff_take_n(v_x31_2482, 3ULL, 2);
                            V v_t_2485 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2483));
                            v_x3_2486 = heff_tr(heff_call(v_t_2485, 2, (V[]){v_z_242, v_j_2484}));
                            break;
                          }
                          default: heff_nomatch(v_x31_2482);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x3_2481);
                        }
                        switch (heff_tag_of(v_x3_2486)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x3_2473_24Just, 1);
                          heff_drop(v_x_2475);
                          heff_drop_cell(v_ru_24x31_2474_24MkPair, 2);
                          heff_drop(v_x_2479);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2487 = heff_field(v_x3_2486, 0);
                          heff_take_n(v_x3_2486, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2487)) {
                          case TAG_MkPair: {
                            V v_x_2488 = heff_field(v_x31_2487, 0);
                            V v_j_2489 = heff_field(v_x31_2487, 1);
                            heff_take_n(v_x31_2487, 3ULL, 2);
                            V v_t_2490 = heff_tag_at_n(v_ru_24x31_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_x_2475, v_x_2479, v_x_2488}), v_j_2489});
                            return heff_tag_at_n(v_ru_24x3_2473_24Just, TAG_Just, 1, (V[]){v_t_2490});
                          }
                          default: return heff_nomatch(v_x31_2487);
                          }
                        }
                        default: return heff_nomatch(v_x3_2486);
                        }
                      }
                      default: return heff_nomatch(v_x31_2478);
                      }
                    }
                    default: return heff_nomatch(v_x3_2477);
                    }
                  }
                  default: return heff_nomatch(v_x31_2474);
                  }
                }
                default: return heff_nomatch(v_x3_2473);
                }
              } else {
                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str7))) {
                  heff_drop(v_x2_241);
                  V v_x3_2492 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                  switch (heff_tag_of(v_x3_2492)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_k_240, 1);
                    heff_drop(v_z_242);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2493 = heff_field(v_x3_2492, 0);
                    V v_ru_24x3_2492_24Just = heff_take_reuse_n(v_x3_2492, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2493)) {
                    case TAG_MkPair: {
                      V v_x_2494 = heff_field(v_x31_2493, 0);
                      V v_j_2495 = heff_field(v_x31_2493, 1);
                      V v_ru_24x31_2493_24MkPair = heff_take_reuse_n(v_x31_2493, 3ULL, 2);
                      V v_x3_2496 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_2495));
                      V v_x3_24101;
                      switch (heff_tag_of(v_x3_2496)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 1);
                        heff_drop(v_z_242);
                        v_x3_24101 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_2497 = heff_field(v_x3_2496, 0);
                        heff_take_n(v_x3_2496, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2497)) {
                        case TAG_MkPair: {
                          V v_x_2498 = heff_field(v_x31_2497, 0);
                          V v_j_2499 = heff_field(v_x31_2497, 1);
                          heff_take_n(v_x31_2497, 3ULL, 2);
                          V v_t_24100 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_2498));
                          v_x3_24101 = heff_tr(heff_call(v_t_24100, 2, (V[]){v_z_242, v_j_2499}));
                          break;
                        }
                        default: heff_nomatch(v_x31_2497);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_2496);
                      }
                      switch (heff_tag_of(v_x3_24101)) {
                      case TAG_Nothing: {
                        heff_drop_cell(v_ru_24x3_2492_24Just, 1);
                        heff_drop(v_x_2494);
                        heff_drop_cell(v_ru_24x31_2493_24MkPair, 2);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_24102 = heff_field(v_x3_24101, 0);
                        heff_take_n(v_x3_24101, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24102)) {
                        case TAG_MkPair: {
                          V v_x_24103 = heff_field(v_x31_24102, 0);
                          V v_j_24104 = heff_field(v_x31_24102, 1);
                          heff_take_n(v_x31_24102, 3ULL, 2);
                          V v_t_24105 = heff_tag_at_n(v_ru_24x31_2493_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_x_2494, v_x_24103}), v_j_24104});
                          return heff_tag_at_n(v_ru_24x3_2492_24Just, TAG_Just, 1, (V[]){v_t_24105});
                        }
                        default: return heff_nomatch(v_x31_24102);
                        }
                      }
                      default: return heff_nomatch(v_x3_24101);
                      }
                    }
                    default: return heff_nomatch(v_x31_2493);
                    }
                  }
                  default: return heff_nomatch(v_x3_2492);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str8))) {
                    heff_drop(v_x2_241);
                    V v_x3_24107 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_24107)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_24108 = heff_field(v_x3_24107, 0);
                      V v_ru_24x3_24107_24Just = heff_take_reuse_n(v_x3_24107, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24108)) {
                      case TAG_MkPair: {
                        V v_x_24109 = heff_field(v_x31_24108, 0);
                        V v_j_24110 = heff_field(v_x31_24108, 1);
                        V v_ru_24x31_24108_24MkPair = heff_take_reuse_n(v_x31_24108, 3ULL, 2);
                        V v_x3_24111 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24110));
                        V v_x3_24117;
                        switch (heff_tag_of(v_x3_24111)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_k_240, 1);
                          heff_drop(v_z_242);
                          v_x3_24117 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x31_24112 = heff_field(v_x3_24111, 0);
                          heff_take_n(v_x3_24111, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24112)) {
                          case TAG_MkPair: {
                            V v_x_24113 = heff_field(v_x31_24112, 0);
                            V v_j_24114 = heff_field(v_x31_24112, 1);
                            heff_take_n(v_x31_24112, 3ULL, 2);
                            V v_t_24115 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2earmD_clo), 1, (V[]){v_k_240}));
                            V v_t_24116 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_24115, v_x_24113));
                            v_x3_24117 = heff_tr(heff_call(v_t_24116, 2, (V[]){v_z_242, v_j_24114}));
                            break;
                          }
                          default: heff_nomatch(v_x31_24112);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x3_24111);
                        }
                        switch (heff_tag_of(v_x3_24117)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x3_24107_24Just, 1);
                          heff_drop(v_x_24109);
                          heff_drop_cell(v_ru_24x31_24108_24MkPair, 2);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_24118 = heff_field(v_x3_24117, 0);
                          heff_take_n(v_x3_24117, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24118)) {
                          case TAG_MkPair: {
                            V v_x_24119 = heff_field(v_x31_24118, 0);
                            V v_j_24120 = heff_field(v_x31_24118, 1);
                            heff_take_n(v_x31_24118, 3ULL, 2);
                            V v_t_24121 = heff_tag_at_n(v_ru_24x31_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24109, v_x_24119}), v_j_24120});
                            return heff_tag_at_n(v_ru_24x3_24107_24Just, TAG_Just, 1, (V[]){v_t_24121});
                          }
                          default: return heff_nomatch(v_x31_24118);
                          }
                        }
                        default: return heff_nomatch(v_x3_24117);
                        }
                      }
                      default: return heff_nomatch(v_x31_24108);
                      }
                    }
                    default: return heff_nomatch(v_x3_24107);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str9))) {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_x2_241);
                      V v_x3_24123 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                      switch (heff_tag_of(v_x3_24123)) {
                      case TAG_Nothing: {
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_24124 = heff_field(v_x3_24123, 0);
                        V v_ru_24x3_24123_24Just = heff_take_reuse_n(v_x3_24123, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24124)) {
                        case TAG_MkPair: {
                          V v_x_24125 = heff_field(v_x31_24124, 0);
                          V v_j_24126 = heff_field(v_x31_24124, 1);
                          V v_ru_24x31_24124_24MkPair = heff_take_reuse_n(v_x31_24124, 3ULL, 2);
                          V v_t_24127 = heff_tag_at_n(v_ru_24x31_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24123_24Just, TAG_EPrim, 1, (V[]){v_x_24125}), v_j_24126});
                          return heff_tag_n(TAG_Just, 1, (V[]){v_t_24127});
                        }
                        default: return heff_nomatch(v_x31_24124);
                        }
                      }
                      default: return heff_nomatch(v_x3_24123);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str10))) {
                        heff_drop(v_x2_241);
                        V v_x3_24129 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                        switch (heff_tag_of(v_x3_24129)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_k_240, 1);
                          heff_drop(v_z_242);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_24130 = heff_field(v_x3_24129, 0);
                          V v_ru_24x3_24129_24Just = heff_take_reuse_n(v_x3_24129, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24130)) {
                          case TAG_MkPair: {
                            V v_x_24131 = heff_field(v_x31_24130, 0);
                            V v_j_24132 = heff_field(v_x31_24130, 1);
                            V v_ru_24x31_24130_24MkPair = heff_take_reuse_n(v_x31_24130, 3ULL, 2);
                            V v_x3_24133 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24132));
                            V v_x3_24138;
                            switch (heff_tag_of(v_x3_24133)) {
                            case TAG_Nothing: {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_z_242);
                              v_x3_24138 = NTAG(TAG_Nothing);
                              break;
                            }
                            case TAG_Just: {
                              V v_x31_24134 = heff_field(v_x3_24133, 0);
                              heff_take_n(v_x3_24133, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24134)) {
                              case TAG_MkPair: {
                                V v_x_24135 = heff_field(v_x31_24134, 0);
                                V v_j_24136 = heff_field(v_x31_24134, 1);
                                heff_take_n(v_x31_24134, 3ULL, 2);
                                V v_t_24137 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24135));
                                v_x3_24138 = heff_tr(heff_call(v_t_24137, 2, (V[]){v_z_242, v_j_24136}));
                                break;
                              }
                              default: heff_nomatch(v_x31_24134);
                              }
                              break;
                            }
                            default: heff_nomatch(v_x3_24133);
                            }
                            switch (heff_tag_of(v_x3_24138)) {
                            case TAG_Nothing: {
                              heff_drop_cell(v_ru_24x3_24129_24Just, 1);
                              heff_drop(v_x_24131);
                              heff_drop_cell(v_ru_24x31_24130_24MkPair, 2);
                              return NTAG(TAG_Nothing);
                            }
                            case TAG_Just: {
                              V v_x31_24139 = heff_field(v_x3_24138, 0);
                              heff_take_n(v_x3_24138, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24139)) {
                              case TAG_MkPair: {
                                V v_x_24140 = heff_field(v_x31_24139, 0);
                                V v_j_24141 = heff_field(v_x31_24139, 1);
                                heff_take_n(v_x31_24139, 3ULL, 2);
                                V v_t_24142 = heff_tag_at_n(v_ru_24x31_24130_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x_24131, v_x_24140}), v_j_24141});
                                return heff_tag_at_n(v_ru_24x3_24129_24Just, TAG_Just, 1, (V[]){v_t_24142});
                              }
                              default: return heff_nomatch(v_x31_24139);
                              }
                            }
                            default: return heff_nomatch(v_x3_24138);
                            }
                          }
                          default: return heff_nomatch(v_x31_24130);
                          }
                        }
                        default: return heff_nomatch(v_x3_24129);
                        }
                      } else {
                        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str11))) {
                          heff_drop(v_x2_241);
                          V v_x3_24144 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                          switch (heff_tag_of(v_x3_24144)) {
                          case TAG_Nothing: {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_24145 = heff_field(v_x3_24144, 0);
                            V v_ru_24x3_24144_24Just = heff_take_reuse_n(v_x3_24144, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24145)) {
                            case TAG_MkPair: {
                              V v_x_24146 = heff_field(v_x31_24145, 0);
                              V v_j_24147 = heff_field(v_x31_24145, 1);
                              V v_ru_24x31_24145_24MkPair = heff_take_reuse_n(v_x31_24145, 3ULL, 2);
                              V v_x3_24148 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24147));
                              V v_x3_24153;
                              switch (heff_tag_of(v_x3_24148)) {
                              case TAG_Nothing: {
                                heff_drop_rec(v_k_240, 1);
                                heff_drop(v_z_242);
                                v_x3_24153 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x31_24149 = heff_field(v_x3_24148, 0);
                                heff_take_n(v_x3_24148, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24149)) {
                                case TAG_MkPair: {
                                  V v_x_24150 = heff_field(v_x31_24149, 0);
                                  V v_j_24151 = heff_field(v_x31_24149, 1);
                                  heff_take_n(v_x31_24149, 3ULL, 2);
                                  V v_t_24152 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24150));
                                  v_x3_24153 = heff_tr(heff_call(v_t_24152, 2, (V[]){v_z_242, v_j_24151}));
                                  break;
                                }
                                default: heff_nomatch(v_x31_24149);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x3_24148);
                              }
                              switch (heff_tag_of(v_x3_24153)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24x3_24144_24Just, 1);
                                heff_drop(v_x_24146);
                                heff_drop_cell(v_ru_24x31_24145_24MkPair, 2);
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_24154 = heff_field(v_x3_24153, 0);
                                heff_take_n(v_x3_24153, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24154)) {
                                case TAG_MkPair: {
                                  V v_x_24155 = heff_field(v_x31_24154, 0);
                                  V v_j_24156 = heff_field(v_x31_24154, 1);
                                  heff_take_n(v_x31_24154, 3ULL, 2);
                                  V v_t_24157 = heff_tag_at_n(v_ru_24x31_24145_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_x_24146, v_x_24155}), v_j_24156});
                                  return heff_tag_at_n(v_ru_24x3_24144_24Just, TAG_Just, 1, (V[]){v_t_24157});
                                }
                                default: return heff_nomatch(v_x31_24154);
                                }
                              }
                              default: return heff_nomatch(v_x3_24153);
                              }
                            }
                            default: return heff_nomatch(v_x31_24145);
                            }
                          }
                          default: return heff_nomatch(v_x3_24144);
                          }
                        } else {
                          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str12))) {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_x2_241);
                            V v_x3_24159 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                            switch (heff_tag_of(v_x3_24159)) {
                            case TAG_Nothing: {
                              return NTAG(TAG_Nothing);
                            }
                            case TAG_Just: {
                              V v_x31_24160 = heff_field(v_x3_24159, 0);
                              V v_ru_24x3_24159_24Just = heff_take_reuse_n(v_x3_24159, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24160)) {
                              case TAG_MkPair: {
                                V v_x_24161 = heff_field(v_x31_24160, 0);
                                V v_j_24162 = heff_field(v_x31_24160, 1);
                                V v_ru_24x31_24160_24MkPair = heff_take_reuse_n(v_x31_24160, 3ULL, 2);
                                V v_x_24163 = heff_tag_at_n(v_ru_24x3_24159_24Just, TAG_EInt, 1, (V[]){(g_heff_2esyntax_2esurface_2eintOfText(v_x_24161))});
                                return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24160_24MkPair, TAG_MkPair, 2, (V[]){v_x_24163, v_j_24162})});
                              }
                              default: return heff_nomatch(v_x31_24160);
                              }
                            }
                            default: return heff_nomatch(v_x3_24159);
                            }
                          } else {
                            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str13))) {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_x2_241);
                              V v_x3_24165 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                              switch (heff_tag_of(v_x3_24165)) {
                              case TAG_Nothing: {
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_24166 = heff_field(v_x3_24165, 0);
                                V v_ru_24x3_24165_24Just = heff_take_reuse_n(v_x3_24165, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24166)) {
                                case TAG_MkPair: {
                                  V v_x_24167 = heff_field(v_x31_24166, 0);
                                  V v_j_24168 = heff_field(v_x31_24166, 1);
                                  V v_ru_24x31_24166_24MkPair = heff_take_reuse_n(v_x31_24166, 3ULL, 2);
                                  V v_x2_24169 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eirtext_2eexprOf_str14), v_x_24167, MK_INT(0LL), NTAG(TAG_Nil)));
                                  V v_t_24172;
                                  switch (heff_tag_of(v_x2_24169)) {
                                  case TAG_Nil: {
                                    v_t_24172 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str15);
                                    break;
                                  }
                                  case TAG_Cons: {
                                    V v_x_24170 = heff_field(v_x2_24169, 0);
                                    V v_xs_24171 = heff_field(v_x2_24169, 1);
                                    heff_take_n(v_x2_24169, 3ULL, 2);
                                    v_t_24172 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str16); V a_1 = v_x_24170; V a_2 = v_xs_24171; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24171); r_; });
                                    break;
                                  }
                                  default: heff_nomatch(v_x2_24169);
                                  }
                                  V v_x_24173 = heff_tag_at_n(v_ru_24x3_24165_24Just, TAG_EFloat, 1, (V[]){(g_heff_2esyntax_2esurface_2efloatOfDigits(v_t_24172))});
                                  return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24166_24MkPair, TAG_MkPair, 2, (V[]){v_x_24173, v_j_24168})});
                                }
                                default: return heff_nomatch(v_x31_24166);
                                }
                              }
                              default: return heff_nomatch(v_x3_24165);
                              }
                            } else {
                              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str17))) {
                                heff_drop_rec(v_k_240, 1);
                                heff_drop(v_x2_241);
                                V v_x3_24175 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                switch (heff_tag_of(v_x3_24175)) {
                                case TAG_Nothing: {
                                  return NTAG(TAG_Nothing);
                                }
                                case TAG_Just: {
                                  V v_x31_24176 = heff_field(v_x3_24175, 0);
                                  V v_ru_24x3_24175_24Just = heff_take_reuse_n(v_x3_24175, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24176)) {
                                  case TAG_MkPair: {
                                    V v_x_24177 = heff_field(v_x31_24176, 0);
                                    V v_j_24178 = heff_field(v_x31_24176, 1);
                                    V v_ru_24x31_24176_24MkPair = heff_take_reuse_n(v_x31_24176, 3ULL, 2);
                                    V v_t_24179 = heff_tag_at_n(v_ru_24x31_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24175_24Just, TAG_EStr, 1, (V[]){v_x_24177}), v_j_24178});
                                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_24179});
                                  }
                                  default: return heff_nomatch(v_x31_24176);
                                  }
                                }
                                default: return heff_nomatch(v_x3_24175);
                                }
                              } else {
                                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str18))) {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_x2_241);
                                  V v_x3_24181 = (g_heff_2ecompile_2eirtext_2efixedD(heff_dup(v_z_242), v_z_243));
                                  switch (heff_tag_of(v_x3_24181)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_z_242);
                                    return NTAG(TAG_Nothing);
                                  }
                                  case TAG_Just: {
                                    V v_x31_24182 = heff_field(v_x3_24181, 0);
                                    V v_ru_24x3_24181_24Just = heff_take_reuse_n(v_x3_24181, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24182)) {
                                    case TAG_MkPair: {
                                      V v_x_24183 = heff_field(v_x31_24182, 0);
                                      V v_j_24184 = heff_field(v_x31_24182, 1);
                                      V v_ru_24x31_24182_24MkPair = heff_take_reuse_n(v_x31_24182, 3ULL, 2);
                                      V v_x3_24185 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_j_24184));
                                      switch (heff_tag_of(v_x3_24185)) {
                                      case TAG_Nothing: {
                                        heff_drop_cell(v_ru_24x3_24181_24Just, 1);
                                        heff_drop(v_x_24183);
                                        heff_drop_cell(v_ru_24x31_24182_24MkPair, 2);
                                        return NTAG(TAG_Nothing);
                                      }
                                      case TAG_Just: {
                                        V v_x31_24186 = heff_field(v_x3_24185, 0);
                                        heff_take_n(v_x3_24185, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24186)) {
                                        case TAG_MkPair: {
                                          V v_x_24187 = heff_field(v_x31_24186, 0);
                                          V v_j_24188 = heff_field(v_x31_24186, 1);
                                          heff_take_n(v_x31_24186, 3ULL, 2);
                                          V v_x_24189 = heff_tag_at_n(v_ru_24x31_24182_24MkPair, TAG_EFixed, 2, (V[]){v_x_24183, (g_heff_2esyntax_2esurface_2eintOfText(v_x_24187))});
                                          return heff_tag_at_n(v_ru_24x3_24181_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24189, v_j_24188})});
                                        }
                                        default: return heff_nomatch(v_x31_24186);
                                        }
                                      }
                                      default: return heff_nomatch(v_x3_24185);
                                      }
                                    }
                                    default: return heff_nomatch(v_x31_24182);
                                    }
                                  }
                                  default: return heff_nomatch(v_x3_24181);
                                  }
                                } else {
                                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str19))) {
                                    heff_drop_rec(v_k_240, 1);
                                    heff_drop(v_x2_241);
                                    V v_x3_24191 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                    switch (heff_tag_of(v_x3_24191)) {
                                    case TAG_Nothing: {
                                      return NTAG(TAG_Nothing);
                                    }
                                    case TAG_Just: {
                                      V v_x31_24192 = heff_field(v_x3_24191, 0);
                                      V v_ru_24x3_24191_24Just = heff_take_reuse_n(v_x3_24191, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24192)) {
                                      case TAG_MkPair: {
                                        V v_x_24193 = heff_field(v_x31_24192, 0);
                                        V v_j_24194 = heff_field(v_x31_24192, 1);
                                        V v_ru_24x31_24192_24MkPair = heff_take_reuse_n(v_x31_24192, 3ULL, 2);
                                        V v_x2_24195 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eirtext_2eexprOf_str20), v_x_24193, MK_INT(0LL), NTAG(TAG_Nil)));
                                        V v_t_24198;
                                        switch (heff_tag_of(v_x2_24195)) {
                                        case TAG_Nil: {
                                          v_t_24198 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str21);
                                          break;
                                        }
                                        case TAG_Cons: {
                                          V v_x_24196 = heff_field(v_x2_24195, 0);
                                          V v_xs_24197 = heff_field(v_x2_24195, 1);
                                          heff_take_n(v_x2_24195, 3ULL, 2);
                                          v_t_24198 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str22); V a_1 = v_x_24196; V a_2 = v_xs_24197; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24197); r_; });
                                          break;
                                        }
                                        default: heff_nomatch(v_x2_24195);
                                        }
                                        V v_x_24199 = heff_tag_at_n(v_ru_24x3_24191_24Just, TAG_EFloat32, 1, (V[]){(g_heff_2esyntax_2esurface_2efloatOfDigits(v_t_24198))});
                                        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24192_24MkPair, TAG_MkPair, 2, (V[]){v_x_24199, v_j_24194})});
                                      }
                                      default: return heff_nomatch(v_x31_24192);
                                      }
                                    }
                                    default: return heff_nomatch(v_x3_24191);
                                    }
                                  } else {
                                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str23))) {
                                      heff_drop_rec(v_k_240, 1);
                                      heff_drop(v_x2_241);
                                      heff_drop(v_z_242);
                                      V v_t_24201 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_z_243});
                                      return heff_tag_n(TAG_Just, 1, (V[]){v_t_24201});
                                    } else {
                                      if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str24))) {
                                        V v_x3_24203 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                                        switch (heff_tag_of(v_x3_24203)) {
                                        case TAG_Nothing: {
                                          heff_drop_rec(v_k_240, 1);
                                          heff_drop(v_z_242);
                                          return NTAG(TAG_Nothing);
                                        }
                                        case TAG_Just: {
                                          V v_x31_24204 = heff_field(v_x3_24203, 0);
                                          V v_ru_24x3_24203_24Just = heff_take_reuse_n(v_x3_24203, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24204)) {
                                          case TAG_MkPair: {
                                            V v_x_24205 = heff_field(v_x31_24204, 0);
                                            V v_j_24206 = heff_field(v_x31_24204, 1);
                                            V v_ru_24x31_24204_24MkPair = heff_take_reuse_n(v_x31_24204, 3ULL, 2);
                                            V v_x3_24207 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24206}));
                                            switch (heff_tag_of(v_x3_24207)) {
                                            case TAG_Nothing: {
                                              heff_drop_cell(v_ru_24x3_24203_24Just, 1);
                                              heff_drop(v_x_24205);
                                              heff_drop_cell(v_ru_24x31_24204_24MkPair, 2);
                                              return NTAG(TAG_Nothing);
                                            }
                                            case TAG_Just: {
                                              V v_x31_24208 = heff_field(v_x3_24207, 0);
                                              heff_take_n(v_x3_24207, 1ULL, 1);
                                              switch (heff_tag_of(v_x31_24208)) {
                                              case TAG_MkPair: {
                                                V v_x_24209 = heff_field(v_x31_24208, 0);
                                                V v_j_24210 = heff_field(v_x31_24208, 1);
                                                heff_take_n(v_x31_24208, 3ULL, 2);
                                                V v_t_24211 = heff_tag_at_n(v_ru_24x31_24204_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24205, v_x_24209}), v_j_24210});
                                                return heff_tag_at_n(v_ru_24x3_24203_24Just, TAG_Just, 1, (V[]){v_t_24211});
                                              }
                                              default: return heff_nomatch(v_x31_24208);
                                              }
                                            }
                                            default: return heff_nomatch(v_x3_24207);
                                            }
                                          }
                                          default: return heff_nomatch(v_x31_24204);
                                          }
                                        }
                                        default: return heff_nomatch(v_x3_24203);
                                        }
                                      } else {
                                        heff_drop_rec(v_k_240, 1);
                                        return ({ V a_0 = v_z_242; V a_1 = v_z_243; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eirtext_2eexprOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eexprOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eirtext_2edk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2edk_lam0, 2, 0};

static V g_heff_2ecompile_2eirtext_2edk_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2edk_st;
static V g_heff_2ecompile_2eirtext_2edk_init(void) {
  return heff_rec_n(1, shape_go, (V[]){((V)&g_heff_2ecompile_2eirtext_2edk_lam0_clo)});
}
V g_heff_2ecompile_2eirtext_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2edk_st)) return g_heff_2ecompile_2eirtext_2edk_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2edk_val, &g_heff_2ecompile_2eirtext_2edk_st, g_heff_2ecompile_2eirtext_2edk_init);
}
V g_heff_2ecompile_2eirtext_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_t_242 = heff_dup(g_heff_2ecompile_2eirtext_2edk_get());
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_t_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      return (g_heff_2ecompile_2eirtext_2eexprOf(v_t_242, v_x_245, v_s_240, v_j_246));
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}

static V g_heff_2ecompile_2eirtext_2etakeExpr_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2etakeExpr_st;
static V g_heff_2ecompile_2eirtext_2etakeExpr_init(void) {
  return heff_dup(heff_rfield(g_heff_2ecompile_2eirtext_2edk_get(), 0));
}
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2etakeExpr_st)) return g_heff_2ecompile_2eirtext_2etakeExpr_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2etakeExpr_val, &g_heff_2ecompile_2eirtext_2etakeExpr_st, g_heff_2ecompile_2eirtext_2etakeExpr_init);
}
Clo g_heff_2ecompile_2eirtext_2ebytesH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2ebytesH_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2ebytesH(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    V v_t_245 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), MK_INT(256LL));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_247 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), MK_INT(256LL));
    V v_t_248 = heff_intMod(heff_intAdd(v_t_247, MK_INT(1LL)), MK_INT(2147483629LL));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_t_248});
  } else {
    V v_t_249 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_2410 = heff_intMod(heff_intAdd(v_t_249, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_2411 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_2412 = heff_intMod(heff_intAdd(v_t_2411, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_2410;
    V t_3 = v_t_2412;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2ebytesH(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eirtext_2estrsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2estrsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), (g_heff_2ecompile_2eirtext_2estrsH(v_xs_243, v_rest_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_es_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_242}), (g_heff_2ecompile_2eirtext_2eexprsH(v_es_243, v_rest_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eexprsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      V v_e_245 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24MkPair = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_245}), (g_heff_2ecompile_2eirtext_2efieldsH(v_fs_243, v_rest_241))});
      return heff_tag_at_n(v_ru_24x11_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_244}), v_t_246});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2earmsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2earmsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_arms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x11_242, 0);
      V v_vs_245 = heff_field(v_x11_242, 1);
      V v_b_246 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 7ULL, 3);
      V v_t_247 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_245))});
      V v_t_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_246}), (g_heff_2ecompile_2eirtext_2earmsH(v_arms_243, v_rest_241))});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, (g_heff_2ecompile_2eirtext_2estrsH(v_vs_245, v_t_248))});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_244}), v_t_249});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmsH(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2enodeH_str8, 7, "Float32");
Clo g_heff_2ecompile_2eirtext_2enodeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2enodeH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2enodeH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EVar = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_HS, 1, (V[]){v_x_242}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(1LL)}), v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EGlobal = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EGlobal, TAG_HS, 1, (V[]){v_g_244}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(2LL)}), v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_246))});
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_247}), v_rest_241});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, (g_heff_2ecompile_2eirtext_2estrsH(v_xs_246, v_t_249))});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(3LL)}), v_t_2410});
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_x1_240, 0);
    V v_as_2412 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2413 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2412))});
    V v_t_2414 = heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){v_t_2413, (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2412, v_rest_241))});
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_f_2411}), v_t_2414});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(4LL)}), v_t_2415});
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_x1_240, 0);
    V v_a_2417 = heff_field(v_x1_240, 1);
    V v_b_2418 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2418}), v_rest_241});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_a_2417}), v_t_2419});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_2416}), v_t_2420});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(5LL)}), v_t_2421});
  }
  case TAG_ERecord: {
    V v_fs_2422 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2423 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_2422))});
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, (g_heff_2ecompile_2eirtext_2efieldsH(v_fs_2422, v_rest_241))});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(6LL)}), v_t_2424});
  }
  case TAG_EProj: {
    V v_e_2425 = heff_field(v_x1_240, 0);
    V v_l_2426 = heff_field(v_x1_240, 1);
    V v_sh_2427 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2428 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_sh_2427))});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, (g_heff_2ecompile_2eirtext_2estrsH(v_sh_2427, v_rest_241))});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_2426}), v_t_2429});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_2425}), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(7LL)}), v_t_2431});
  }
  case TAG_ETag: {
    V v_t_2432 = heff_field(v_x1_240, 0);
    V v_as_2433 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ETag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2434 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2433))});
    V v_t_2435 = heff_tag_at_n(v_ru_24x1_240_24ETag, TAG_Cons, 2, (V[]){v_t_2434, (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2433, v_rest_241))});
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2432}), v_t_2435});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(8LL)}), v_t_2436});
  }
  case TAG_EMatch: {
    V v_s_2437 = heff_field(v_x1_240, 0);
    V v_arms_2438 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2439 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2438))});
    V v_t_2440 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_t_2439, (g_heff_2ecompile_2eirtext_2earmsH(v_arms_2438, v_rest_241))});
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_s_2437}), v_t_2440});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(9LL)}), v_t_2441});
  }
  case TAG_EPrim: {
    V v_p_2442 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EPrim, TAG_HS, 1, (V[]){v_p_2442}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(10LL)}), v_t_2443});
  }
  case TAG_EPrimCall: {
    V v_p_2444 = heff_field(v_x1_240, 0);
    V v_as_2445 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2446 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2445))});
    V v_t_2447 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_Cons, 2, (V[]){v_t_2446, (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2445, v_rest_241))});
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_p_2444}), v_t_2447});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(11LL)}), v_t_2448});
  }
  case TAG_ECall: {
    V v_g_2449 = heff_field(v_x1_240, 0);
    V v_as_2450 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2451 = heff_tag_n(TAG_HN, 1, (V[]){(g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2450))});
    V v_t_2452 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){v_t_2451, (g_heff_2ecompile_2eirtext_2eexprsH(v_as_2450, v_rest_241))});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_2449}), v_t_2452});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(12LL)}), v_t_2453});
  }
  case TAG_EInt: {
    V v_i_2454 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EInt = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2455 = heff_tag_at_n(v_ru_24x1_240_24EInt, TAG_HS, 1, (V[]){heff_intShow(v_i_2454)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(13LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_rest_241})});
  }
  case TAG_EFloat: {
    V v_x_2456 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2457 = heff_tag_at_n(v_ru_24x1_240_24EFloat, TAG_HS, 1, (V[]){heff_floatShow(v_x_2456)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(14LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_rest_241})});
  }
  case TAG_EStr: {
    V v_s_2458 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EStr = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EStr, TAG_HS, 1, (V[]){v_s_2458}), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(15LL)}), v_t_2459});
  }
  case TAG_EFixed: {
    V v_w_2460 = heff_field(v_x1_240, 0);
    V v_n_2461 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2462;
    switch (heff_tag_of(v_w_2460)) {
    case TAG_I8: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str0);
      break;
    }
    case TAG_I16: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str1);
      break;
    }
    case TAG_I32: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str2);
      break;
    }
    case TAG_I64: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str3);
      break;
    }
    case TAG_U8: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str4);
      break;
    }
    case TAG_U16: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str5);
      break;
    }
    case TAG_U32: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str6);
      break;
    }
    case TAG_U64: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str7);
      break;
    }
    case TAG_F32: {
      v_t_2462 = ((V)&g_heff_2ecompile_2eirtext_2enodeH_str8);
      break;
    }
    default: heff_nomatch(v_w_2460);
    }
    V v_t_2463 = heff_tag_n(TAG_HS, 1, (V[]){heff_intShow(v_n_2461)});
    V v_t_2464 = heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2462}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(16LL)}), v_t_2464});
  }
  case TAG_EFloat32: {
    V v_x_2465 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat32 = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2466 = heff_tag_at_n(v_ru_24x1_240_24EFloat32, TAG_HS, 1, (V[]){heff_floatShow(v_x_2465)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(17LL)}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, v_rest_241})});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(18LL)}), v_rest_241});
  }
  case TAG_EFix: {
    V v_f_2467 = heff_field(v_x1_240, 0);
    V v_b_2468 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2469 = heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_2468}), v_rest_241});
    V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_f_2467}), v_t_2469});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){MK_INT(19LL)}), v_t_2470});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2enodeH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2ehashW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2ehashW_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2ehashW(V v_a_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_240, v_b_241});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_HE: {
      V v_e_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_246 = (g_heff_2ecompile_2eirtext_2enodeH(v_e_245, v_rest_244));
      V t_0 = v_a_240;
      V t_1 = v_b_241;
      V t_2 = v_t_246;
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_HS: {
      V v_s_247 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_x3_248 = (g_heff_2ecompile_2eirtext_2ebytesH(v_s_247, MK_INT(0LL), v_a_240, v_b_241));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_MkPair: {
        V v_a_249 = heff_field(v_x3_248, 0);
        V v_b_2410 = heff_field(v_x3_248, 1);
        heff_take_n(v_x3_248, 3ULL, 2);
        V t_0 = v_a_249;
        V t_1 = v_b_2410;
        V t_2 = v_rest_244;
        v_a_240 = t_0;
        v_b_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    case TAG_HN: {
      V v_n_2411 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2412 = heff_intAdd(heff_intMul(v_a_240, MK_INT(1000003LL)), heff_intAdd(heff_dup(v_n_2411), MK_INT(300LL)));
      V v_t_2413 = heff_intMod(heff_intAdd(v_t_2412, MK_INT(1LL)), MK_INT(2147483647LL));
      V v_t_2414 = heff_intAdd(heff_intMul(v_b_241, MK_INT(999983LL)), heff_intAdd(v_n_2411, MK_INT(300LL)));
      V v_t_2415 = heff_intMod(heff_intAdd(v_t_2414, MK_INT(1LL)), MK_INT(2147483629LL));
      V t_0 = v_t_2413;
      V t_1 = v_t_2415;
      V t_2 = v_rest_244;
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2ehashW(a[0], a[1], a[2]);
}