// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Inverse 25398
#define TAG_Plain 3036
#define LBL_style 311138763
#define LBL_text 10052084
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_list_2emap_24s857425298x1024652640(V);
V g_list_2emap_24s857425298x1024652640_entry(V self, V *a);
extern Clo g_list_2emap_24s857425298x1024652640_clo;
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240(V, V, V);
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_clo;
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps(V, V, V, V);
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_clo;
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_str0, 2, "> ");
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_str1, 2, "  ");
Clo g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_entry, 3, 0};

V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240(V v_at_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248;
    if (heff_intEq_c_lent(v_i_241, v_at_240, 0)) {
      V v_t_245 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_str0), NTAG(TAG_Inverse)});
      V v_t_246 = (g_list_2emap_24s857425298x1024652640(v_r_243));
      v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_246});
    } else {
      V v_t_247 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_str1), NTAG(TAG_Plain)});
      v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_r_243});
    }
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps(v_at_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), v_rs_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_str0, 2, "> ");
HEFF_LIT(g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_str1, 2, "  ");
Clo g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_entry, 4, 0};

V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps(V v_at_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x3_242, 0);
    V v_rs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249;
    if (heff_intEq_c_lent(v_i_241, v_at_240, 0)) {
      V v_t_246 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_str0), NTAG(TAG_Inverse)});
      V v_t_247 = (g_list_2emap_24s857425298x1024652640(v_r_244));
      v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, v_t_247});
    } else {
      V v_t_248 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_str1), NTAG(TAG_Plain)});
      v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, v_r_244});
    }
    V v_cell_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_at_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_rs_245;
    V t_3 = v_cell_2410;
    v_at_240 = t_0;
    v_i_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_24dps(a[0], a[1], a[2], a[3]);
}