// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_group 299987609
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2emoduleText(V);
V g_heff_2ebuild_2ecommands_2emoduleText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emoduleText_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s2126463095x904664881(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s2126463095x904664881_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s2126463095x904664881_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter_24s1875062608x222844981(V, V, V, V, V, V);
V g_list_2efilter_24s1875062608x222844981_entry(V self, V *a);
extern Clo g_list_2efilter_24s1875062608x222844981_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s313075719x1688564285(V);
V g_list_2efilter_24s313075719x1688564285_entry(V self, V *a);
extern Clo g_list_2efilter_24s313075719x1688564285_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efilter_24s639151216x1214259357(V, V, V);
V g_list_2efilter_24s639151216x1214259357_entry(V self, V *a);
extern Clo g_list_2efilter_24s639151216x1214259357_clo;
V g_list_2efilter_24s770154907x42702486(V);
V g_list_2efilter_24s770154907x42702486_entry(V self, V *a);
extern Clo g_list_2efilter_24s770154907x42702486_clo;
V g_list_2efoldl_24f1117322828x1334654706(V, V, V);
V g_list_2efoldl_24f1117322828x1334654706_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1117322828x1334654706_clo;
V g_list_2efoldl_24f1189266312x1583313228(V, V, V);
V g_list_2efoldl_24f1189266312x1583313228_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1189266312x1583313228_clo;
V g_list_2efoldl_24f1824632076x1202317442(V, V, V);
V g_list_2efoldl_24f1824632076x1202317442_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1824632076x1202317442_clo;
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprocess_2ewithProcess_24s461807610x1567722616(V, V, V, V);
V g_std_2eprocess_2ewithProcess_24s461807610x1567722616_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s461807610x1567722616_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0));
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1));
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_244);
        return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2));
      }
      case TAG_Cons: {
        V v_s_248 = heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3));
        V v_s_249 = heff_strAppend(v_s_248, heff_dup(v_b_244));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4));
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_244, v_x122_245});
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn_24acc(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2eaddRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eaddRes_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eaddRes(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intAdd(heff_take_field(v_a_240, 0), heff_take_field(v_b_241, 0));
  V v_t_243 = heff_intAdd(heff_take_field(v_a_240, 1), heff_take_field(v_b_241, 1));
  V v_t_244 = heff_intAdd(heff_take_field(v_a_240, 2), heff_take_field(v_b_241, 2));
  V v_t_245 = heff_intAdd(heff_take_field(v_a_240, 3), heff_take_field(v_b_241, 3));
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_a_240, 4), heff_take_field(v_b_241, 4)));
  V v_t_247 = heff_intAdd(heff_take_field(v_a_240, 5), heff_take_field(v_b_241, 5));
  V v_t_248 = heff_intAdd(heff_take_field(v_a_240, 6), heff_take_field(v_b_241, 6));
  V v_t_249 = heff_intAdd(heff_get_n(v_a_240, 7, 8), heff_get_n(v_b_241, 7, 8));
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, v_t_249});
}
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eaddRes(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str3, 0, "");

HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V v_n_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_245;
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_l_243 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 2);
      v_t_245 = v_l_243;
      break;
    }
    default: heff_nomatch(v_x2_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str1);
      break;
    }
    case TAG_Cons: {
      V v_l_246 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 2);
      v_t_248 = v_l_246;
      break;
    }
    default: heff_nomatch(v_x3_242);
    }
    V v_f_249 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_248});
    return ((HeffT2){{v_n_240, v_f_249}});
  }
  case TAG_Cons: {
    V v_a_2410 = heff_dup(heff_field(v_x2_241, 0));
    V v_argv_2411 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_a_2410);
      heff_drop(v_argv_2411);
      V v_t_2414;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_l_2412 = heff_field(v_x2_241, 0);
        heff_take_n(v_x2_241, 1ULL, 2);
        v_t_2414 = v_l_2412;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      V v_t_2417;
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_l_2415 = heff_field(v_x3_242, 0);
        heff_take_n(v_x3_242, 1ULL, 2);
        v_t_2417 = v_l_2415;
        break;
      }
      default: heff_nomatch(v_x3_242);
      }
      V v_f_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2417});
      return ((HeffT2){{v_n_240, v_f_2418}});
    }
    case TAG_Cons: {
      V v_b_2419 = heff_field(v_x3_242, 0);
      V v_bs_2420 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (heff_strEq_c_lent(v_a_2410, v_b_2419, 0)) {
        heff_drop(v_a_2410);
        heff_drop(v_b_2419);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_argv_2411;
        V t_2 = v_bs_2420;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_argv_2411);
        heff_drop(v_bs_2420);
        return ((HeffT2){{v_n_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_a_2410, v_b_2419})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str3, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2elastLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elastLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elastLines(V v_n_240, V v_t_241) {
top: ;
  V v_xs_242 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2elastLines_str0); V a_1 = v_t_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2elastLines_str1), v_t_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x2_244 = (g_list_2efoldl_24f932140008x904662204(NTAG(TAG_Nil), v_n_240, v_t_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2elastLines_str2);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2elastLines_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elastLines(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str0, 7, "module ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str1, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str3, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str4, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str5, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str6, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str8, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str11, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str12, 52, "-- checks them all, and `heff test` their doc tests.");
Clo g_heff_2ebuild_2ecommands_2emoduleText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emoduleText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2emoduleText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2emoduleText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2emoduleText_str1)));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str4), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str6), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str8), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_245})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2emoduleText_str10); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2emoduleText_str11); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str12), v_t_246}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2emoduleText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emoduleText(a[0]);
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(a[0]);
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam4(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2429;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    v_x_2429 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Just = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    HeffT2 v_t_2417 = ({ V a_0 = v_src_2416; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_src_2416); r_; });
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2415_24Just, 1);
        V v_p_2421 = v_field_2419;
        heff_drop(v_p_2421);
        v_x_2429 = NTAG(TAG_Nothing);
      } else {
        V v_x_2422 = v_field_2419;
        HeffT2 v_t_2423 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2422));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2415_24Just, 1);
            V v_x_2427 = v_field_2425;
            heff_drop(v_x_2427);
            v_x_2429 = NTAG(TAG_Nothing);
          } else {
            V v_p_2428 = v_field_2425;
            v_x_2429 = heff_tag_at_n(v_ru_24x_2415_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2428, 1, 4)});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2430 = ({ V a_0 = v_x_2429; V a_1 = heff_dup(heff_rfield(v_x_246, 4)); V r_ = (g_heff_2ebuild_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2429); r_; });
  V v_x_2431 = (g_list_2efoldl_24s571074576x1179600767(v_x_246, v_t_2430));
  V f_ = v_k_243;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_247, ((V)&g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam4_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam5, 1, 2, (V[]){v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam3, 1, 3, (V[]){v_hd_242, v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s2126463095x904664881(v_x_244, v_file_240));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324(V v_rep_240, V v_badLoad_241, V v_cs_242, V v_z_243, V v_z_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_cs_242)));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_lam0, 1, 4, (V[]){v_cs_242, v_z_243, heff_dup(v_badLoad_241), v_z_244})});
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_badLoad_241 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cs_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2420);
  if ((heff_dup(v_badLoad_241) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_241);
    heff_drop(v_cs_242);
    V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_243, v_z_244));
  } else {
    heff_drop(v_badLoad_241);
    V v_t_2428 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_242); r_; });
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_z_243, v_z_244));
    } else {
      heff_drop(v_z_243);
      heff_drop(v_t_2428);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_badLoad_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_242)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2411 = v_field_249;
      V v_str_2412 = (g_heff_2ebuild_2edriver_2einterface(v_c_2411));
      V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s4924381x637866324_lam1, 1, 4, (V[]){v_badLoad_241, v_z_243, v_z_244, v_cs_242})));
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badLoad_241);
      heff_drop(v_field_249);
      V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_243, v_z_244));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str2, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str3, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str7, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str9, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str11, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744(V v_ex_240, V v_argv_241, V v_n_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2415;
  if ((heff_peek_word(v_n_242) == ((int64_t)0ULL))) {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam0_clo);
  } else {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str0), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    v_t_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
  }
  return heff_tail(v_t_2415, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam1, 1, 5, (V[]){v_hd_243, v_ex_240, v_argv_241, v_n_242, v_k_244})});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam7(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2447 = args[1];
  V v_k_2448 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2446);
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2427 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V f_ = v_k_2427;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam7, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_intShow(heff_box_word((heff_peek_word(v_n_242) + ((int64_t)1ULL))));
  V v_t_2431 = heff_get_n(v_x_2429, 0, 3);
  V v_t_2435;
  switch (heff_tag_of(v_t_2431)) {
  case TAG_Exited: {
    V v_n_2432 = heff_field(v_t_2431, 0);
    heff_take_n(v_t_2431, 1ULL, 1);
    if (heff_intEq_c(v_n_2432, MK_INT(0LL))) {
      v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str2);
    } else {
      v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str3);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2431, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str4);
    break;
  }
  case TAG_TimedOut: {
    v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str5);
    break;
  }
  case TAG_NotRun: {
    v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str6);
    break;
  }
  default: heff_nomatch(v_t_2431);
  }
  V v_t_2436 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str7), heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str8)));
  V v_t_2437 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str9), heff_strAppend(v_t_2430, v_t_2436));
  V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str10)), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_2426, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam6, 1, 2, (V[]){v_k_2427, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2425, v_argv_241, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str1), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  return (g_std_2eprocess_2ewithProcess_24s461807610x1567722616(v_ex_240, v_t_2428, heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam5, 1, 3, (V[]){v_n_242, v_hd_2426, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam10(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_2461 = args[1];
  V v_k_2462 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2460);
  heff_drop(v_hd_2461);
  V f_ = v_k_2462;
  args[0] = heff_box_word((heff_unbox_word(v_n_242) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam9(V self, V *args) {
  V v_x_2459 = args[0];
  V v_k_2451 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2459);
  V f_ = v_k_2451;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam10, 3, 1, (V[]){v_n_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam8(V self, V *args) {
  V v_err_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_err_2449);
  V v_t_2452 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_str11), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_hd_2450, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam9, 1, 2, (V[]){v_k_2451, v_n_242})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam11(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2464;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_hd_243;
  heff_room[2] = v_k_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2463 = heff_tr(heff_call(heff_dup(v_ex_240), 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam4, 2, 4, (V[]){v_x_2425, v_argv_241, v_ex_240, heff_dup(v_n_242)}), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam8, 3, 1, (V[]){v_n_242})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2463, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam11, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_argv_241 = heff_env(self)[2];
  V v_n_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam2_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s495635622x733177935(v_t_2424, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1567870654x899898744_lam3, 1, 5, (V[]){v_ex_240, v_argv_241, v_n_242, v_hd_243, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str1, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str5, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(V v_rep_240, V v_f_241, V v_wrong_242, V v_ts_243, V v_os_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_248 = heff_tr(heff_call(v_rep_240, 1, (V[]){heff_tag_n(TAG_UseColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam0_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_248, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam1, 1, 6, (V[]){v_ts_243, v_f_241, v_z_245, v_os_244, v_wrong_242, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam0(V self, V *args) {
  V v_b_247 = args[0];
  return v_b_247;
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_wrong_242 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2440);
  V v_t_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_243; V r_ = (g_list_2efoldl_24f1117322828x1334654706(a_0, a_1, a_2)); heff_drop(v_ts_243); r_; });
  V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_244));
  V v_t_2444 = (g_list_2efoldl_24f1189266312x1583313228(MK_INT(1LL), MK_INT(0LL), v_os_244));
  V v_t_2445 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_244; V r_ = (g_list_2efoldl_24f1824632076x1202317442(a_0, a_1, a_2)); heff_drop(v_os_244); r_; });
  V v_x_2446 = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), v_t_2441, v_t_2442, v_wrong_242, v_t_2443, v_t_2444, v_t_2445});
  V f_ = v_z_246;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_wrong_242 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  V v_x1_2415 = (g_list_2efilter_24s313075719x1688564285(heff_dup(v_ts_243)));
  V v_t_2423;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nil: {
    V v_x1_2416 = (g_list_2efilter_24s770154907x42702486(heff_dup(v_os_244)));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_wrong_242)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str0);
        break;
      }
      case TAG_Cons: {
        v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str1);
        break;
      }
      default: heff_nomatch(v_wrong_242);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2416, 0ULL, 2);
      v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str2);
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2415, 0ULL, 2);
    v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str3);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2425 = (g_list_2efoldl_24f1117322828x1334654706(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2426 = heff_intShow(heff_intSub(v_t_2424, v_t_2425));
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_243));
  V v_t_2428 = (g_heff_2ebuild_2ecommands_2etestsSaid(v_os_244));
  V v_t_2429 = heff_strAppend(heff_intShow(v_t_2427), v_t_2428);
  V v_t_2430 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str4), v_t_2429));
  V v_t_2431 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str5), v_t_2430));
  V v_str_2432 = heff_strAppend(v_t_2423, v_t_2431);
  V v_t_2433 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2432, ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_str6)), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam4, 1, 4, (V[]){v_ts_243, v_os_244, v_wrong_242, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_os_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_ts_243 = heff_env(self)[3];
  V v_wrong_242 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_c_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_os_244); V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam3, 1, 6, (V[]){v_ts_243, v_os_244, v_wrong_242, v_f_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ts_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_os_244 = heff_env(self)[3];
  V v_wrong_242 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2410 = (g_list_2efilter_24s313075719x1688564285(heff_dup(v_ts_243)));
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193(heff_dup(v_f_241), v_x_249, v_t_2410));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1653809894x443385359_lam2, 1, 7, (V[]){v_x_249, v_os_244, v_z_245, v_ts_243, v_wrong_242, v_f_241, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str1, 11, ".provider.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str2, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str3, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385(V v_host_240, V v_s_241, V v_p_242, V v_p_243) {
top: ;
  V v_p_244 = heff_dup(heff_rfield(v_s_241, 2));
  int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_244, 0)) - ((int64_t)3ULL));
  V v_t_246 = heff_strSlice(heff_dup(v_p_244), heff_box_word(v_t_245), heff_strLength_lent(v_p_244, 0));
  V v_t_249;
  if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str0))) {
    int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_p_244, 0)) - ((int64_t)3ULL));
    v_t_249 = heff_strSlice(v_p_244, MK_INT(0LL), heff_box_word(v_t_248));
  } else {
    v_t_249 = v_p_244;
  }
  V v_path_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str1));
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2410, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam1, 1, 4, (V[]){v_s_241, v_p_242, heff_dup(v_host_240), v_p_243})));
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam0(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam2(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2442;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_x_2433);
    heff_drop(v_host_240);
    v_x_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2418, 0ULL, 1);
    switch (heff_tag_of(v_x_2433)) {
    case TAG_Nothing: {
      heff_drop(v_host_240);
      v_x_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      V v_t_2435 = heff_field(v_x_2433, 0);
      heff_take_n(v_x_2433, 1ULL, 1);
      V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str4); V a_1 = v_t_2435; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str5), v_t_2435, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_t_2435); r_; });
      V v_t_2437 = (g_list_2emap_24s649333309x1802289391(v_t_2436));
      V v_x1_2438 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2437));
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_Nil: {
        heff_drop(v_host_240);
        v_x_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 2);
        v_x_2442 = heff_bool(!heff_strEq_c_lent(v_x_2439, v_host_240, 0));
        heff_drop(v_host_240);
        heff_drop(v_x_2439);
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      break;
    }
    default: heff_nomatch(v_x_2433);
    }
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_p_243;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_2419 = heff_get_n(v_s_241, 2, 8);
  int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_p_2419, 0)) - ((int64_t)3ULL));
  V v_t_2421 = heff_strSlice(heff_dup(v_p_2419), heff_box_word(v_t_2420), heff_strLength_lent(v_p_2419, 0));
  V v_t_2424;
  if (heff_strEq_c(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str2))) {
    int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_p_2419, 0)) - ((int64_t)3ULL));
    v_t_2424 = heff_strSlice(v_p_2419, MK_INT(0LL), heff_box_word(v_t_2423));
  } else {
    v_t_2424 = v_p_2419;
  }
  V v_path_2425 = heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_str3));
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2425, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam2_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s2027626854x258329385_lam3, 1, 3, (V[]){v_x_2418, v_host_240, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str7, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2411;
      V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam0, 1, 1, (V[]){heff_dup(v_c_2413)}), heff_dup(heff_rfield(v_c_2413, 7))));
      V v_t_2422 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2421));
      V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2422); r_; });
      V v_t_2424 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2423));
      V v_xs_2425 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str3); V a_6 = v_t_2424; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2426 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2425));
      V v_c_2427 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1449898586x243475742(v_sources_241, v_t_2426));
      return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam1, 1, 8, (V[]){v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245, v_c_2413, v_z_247, v_z_248})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_field_2411);
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str7), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam0(V self, V *args) {
  V v_o_2414 = args[0];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_2413, heff_rfield(v_o_2414, 1)));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_eff_2419 = v_field_2417;
      V v_t_2420 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2414, 0), heff_get_n(v_o_2414, 1, 2), v_eff_2419});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
    } else {
      heff_drop_rec(v_o_2414, 2);
      heff_drop(v_field_2417);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2413 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str4); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str5); V b_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_str6); V a_5 = v_x_2428; V r_ = (g_list_2efilter_24s1875062608x222844981(b_0, a_1, b_2, b_3, b_4, a_5)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); heff_drop(b_4); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2413; V a_6 = v_t_2429; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s150922887x2060964650(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s341026157x147192577_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str2, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str3, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str4, 24, ": its tag has been moved");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str5, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str6, 1, " ");
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902(V v_prog_240, V v_ps_241, V v_root_242, V v_sums_243, V v_by_244, V v_path_245, V v_v_246) {
top: ;
  V v_t_247 = (g_list_2efilter_24s2128134357x1680551385(v_path_245, heff_take_field(v_root_242, 2)));
  V v_t_2413;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_242, 4);
    v_t_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2410 = (g_list_2efilter_24s50027113x1989932102(v_r_248, heff_get_n(v_root_242, 3, 4)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2411, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    V v_c_2414 = (g_heff_2ebuild_2ecommands_2efetched_24s955833502x941424416(v_prog_240, heff_dup(v_ps_241), heff_dup(v_path_245), heff_dup(v_v_246)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_lam0, 2, 6, (V[]){v_c_2414, v_v_246, v_path_245, v_by_244, v_sums_243, v_ps_241});
  }
  case TAG_Just: {
    V v_d_2436 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_sums_243);
    heff_drop(v_by_244);
    heff_drop(v_v_246);
    V v_t_2437 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), heff_dup(heff_rfield(v_ps_241, 0)), v_d_2436));
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257(v_ps_241, v_t_2437, v_path_245));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_v_246 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_by_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_hd_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_why_2418 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    heff_drop(v_sums_243);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_hd_2415);
    V v_t_2419 = heff_strAppend(v_v_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str0), v_why_2418));
    V v_t_2420 = heff_strAppend(v_path_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str1), v_t_2419));
    V v_t_2421 = heff_strAppend(v_by_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str2), v_t_2420));
    V f_ = v_k_2416;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2422 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    heff_drop(v_by_244);
    V v_t_2423 = (g_list_2efilter_24s639151216x1214259357(v_path_245, v_v_246, v_sums_243));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      heff_drop(v_h_2422);
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      V v_t_2424 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
      V v_t_2425 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257(v_ps_241, v_t_2424, v_path_245));
      V f_ = v_t_2425;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      V v_s_2426 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 2);
      V v_want_2428 = heff_get_n(v_s_2426, 2, 3);
      if (heff_strEq_c_lent(v_h_2422, v_want_2428, 0)) {
        heff_drop(v_h_2422);
        heff_drop_cell(v_ru_24x_2417_24Right, 1);
        heff_drop(v_want_2428);
        V v_t_2430 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
        V v_t_2431 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1059098573x623404257(v_ps_241, v_t_2430, v_path_245));
        V f_ = v_t_2431;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_hd_2415);
        V v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str3), heff_strAppend(v_want_2428, ((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str4)));
        V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str5), heff_strAppend(v_h_2422, v_t_2432));
        V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_str6), heff_strAppend(v_v_246, v_t_2433));
        V v_t_2435 = heff_tag_at_n(v_ru_24x_2417_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_path_245, v_t_2434)});
        V f_ = v_k_2416;
        args[0] = v_t_2435;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_v_246 = heff_env(self)[1];
  V v_path_245 = heff_env(self)[2];
  V v_by_244 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1815205463x1962273902_lam1, 1, 7, (V[]){v_v_246, v_path_245, v_by_244, v_k_2416, v_sums_243, v_ps_241, v_hd_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_list_2emap_24s152505078x225062837(heff_dup(heff_rfield(v_c_244, 7))));
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471(heff_dup(v_c_244), v_t_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2412); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_str0), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(heff_get_n(v_c_244, 0, 14), v_t_2411, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s2038199265x112036224_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}