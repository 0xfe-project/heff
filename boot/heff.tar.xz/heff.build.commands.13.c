// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Inherited 58190
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Release 43671
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Wait 10206
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_bin 307073
#define LBL_bug 307438
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_group 299987609
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_paths 307797256
#define LBL_pending 1696753626
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_text 10052084
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_value 313331083
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s1503604731x11983968(V, V, V, V, V);
V g_co_2eop_24s1503604731x11983968_entry(V self, V *a);
extern Clo g_co_2eop_24s1503604731x11983968_clo;
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866(V);
V g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851(V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_clo;
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_clo;
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter_24s1505276232x1076898175(V, V);
V g_list_2efilter_24s1505276232x1076898175_entry(V self, V *a);
extern Clo g_list_2efilter_24s1505276232x1076898175_clo;
HeffT2 g_list_2efind_24s1983706162x228765702_24cpr(V, V);
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1819215186x476901667(V, V, V, V);
V g_list_2emap_24f1819215186x476901667_entry(V self, V *a);
extern Clo g_list_2emap_24f1819215186x476901667_clo;
V g_list_2emap_24s1498757180x165099811(V);
V g_list_2emap_24s1498757180x165099811_entry(V self, V *a);
extern Clo g_list_2emap_24s1498757180x165099811_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2esortBy_24s196358923x1153659155(V);
V g_list_2esortBy_24s196358923x1153659155_entry(V self, V *a);
extern Clo g_list_2esortBy_24s196358923x1153659155_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0));
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1));
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_244);
        return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2));
      }
      case TAG_Cons: {
        V v_s_248 = heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3));
        V v_s_249 = heff_strAppend(v_s_248, heff_dup(v_b_244));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4));
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_244, v_x122_245});
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn_24acc(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2eaddRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eaddRes_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eaddRes(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intAdd(heff_take_field(v_a_240, 0), heff_take_field(v_b_241, 0));
  V v_t_243 = heff_intAdd(heff_take_field(v_a_240, 1), heff_take_field(v_b_241, 1));
  V v_t_244 = heff_intAdd(heff_take_field(v_a_240, 2), heff_take_field(v_b_241, 2));
  V v_t_245 = heff_intAdd(heff_take_field(v_a_240, 3), heff_take_field(v_b_241, 3));
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_a_240, 4), heff_take_field(v_b_241, 4)));
  V v_t_247 = heff_intAdd(heff_take_field(v_a_240, 5), heff_take_field(v_b_241, 5));
  V v_t_248 = heff_intAdd(heff_take_field(v_a_240, 6), heff_take_field(v_b_241, 6));
  V v_t_249 = heff_intAdd(heff_get_n(v_a_240, 7, 8), heff_get_n(v_b_241, 7, 8));
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, v_t_249});
}
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eaddRes(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str3, 0, "");

HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V v_n_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_245;
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_l_243 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 2);
      v_t_245 = v_l_243;
      break;
    }
    default: heff_nomatch(v_x2_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str1);
      break;
    }
    case TAG_Cons: {
      V v_l_246 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 2);
      v_t_248 = v_l_246;
      break;
    }
    default: heff_nomatch(v_x3_242);
    }
    V v_f_249 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_248});
    return ((HeffT2){{v_n_240, v_f_249}});
  }
  case TAG_Cons: {
    V v_a_2410 = heff_dup(heff_field(v_x2_241, 0));
    V v_as_2411 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_a_2410);
      heff_drop(v_as_2411);
      V v_t_2414;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_l_2412 = heff_field(v_x2_241, 0);
        heff_take_n(v_x2_241, 1ULL, 2);
        v_t_2414 = v_l_2412;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      V v_t_2417;
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_l_2415 = heff_field(v_x3_242, 0);
        heff_take_n(v_x3_242, 1ULL, 2);
        v_t_2417 = v_l_2415;
        break;
      }
      default: heff_nomatch(v_x3_242);
      }
      V v_f_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2417});
      return ((HeffT2){{v_n_240, v_f_2418}});
    }
    case TAG_Cons: {
      V v_b_2419 = heff_field(v_x3_242, 0);
      V v_bs_2420 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (heff_strEq_c_lent(v_a_2410, v_b_2419, 0)) {
        heff_drop(v_a_2410);
        heff_drop(v_b_2419);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_as_2411;
        V t_2 = v_bs_2420;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_as_2411);
        heff_drop(v_bs_2420);
        return ((HeffT2){{v_n_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_a_2410, v_b_2419})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str3, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2elastLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elastLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elastLines(V v_n_240, V v_t_241) {
top: ;
  V v_xs_242 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2elastLines_str0); V a_1 = v_t_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2elastLines_str1), v_t_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x2_244 = (g_list_2efoldl_24f932140008x904662204(NTAG(TAG_Nil), v_n_240, v_t_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2elastLines_str2);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2elastLines_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elastLines(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_str0), v_e_243), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_str1));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s1503604731x11983968(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_outPath_240, heff_dup(heff_rfield(v_o_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(v_t_2411, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam1, 1, 4, (V[]){v_o_242, v_hd_243, heff_dup(v_bad_241), v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_o_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  if ((heff_dup(v_x_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_2412);
    if ((heff_dup(v_bad_241) == NTAG(TAG_True))) {
      heff_drop(v_bad_241);
      heff_drop_rec(v_o_242, 2);
      V v_t_2414 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_hd_243, v_k_244));
    } else {
      heff_drop(v_bad_241);
      V v_t_2420 = heff_get_n(v_o_242, 1, 2);
      switch (heff_tag_of(v_t_2420)) {
      case TAG_Nil: {
        heff_drop(v_hd_243);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2420_24Cons = heff_take_reuse_n(v_t_2420, 0ULL, 2);
        V v_t_2423 = heff_tag_at_n(v_ru_24t_2420_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_243, v_k_244));
      }
      default: return heff_nomatch(v_t_2420);
      }
    }
  } else {
    heff_drop(v_x_2412);
    heff_drop(v_bad_241);
    heff_drop_rec(v_o_242, 2);
    V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_hd_243, v_k_244));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s2019663154x2030353279(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_lam2, 1, 5, (V[]){v_x_2412, v_bad_241, v_hd_243, v_k_244, v_o_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str1, 60, "heff test: cannot run heff; tested again at the next change\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str2, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str3, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str6, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str7, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str9, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str11, 0, "");
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804(V v_as_240, V v_n_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_2413;
  if ((heff_peek_word(v_n_241) == ((int64_t)0ULL))) {
    v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam0_clo);
  } else {
    V v_t_247 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str0), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    v_t_2413 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})}));
  }
  return heff_tail(v_t_2413, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam1, 1, 4, (V[]){v_hd_242, v_n_241, v_as_240, v_k_243})});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  return v_s_2415;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V f_ = v_k_2426;
  args[0] = heff_box_word((heff_unbox_word(v_n_241) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam5(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_n_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str1), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_2425, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam6, 1, 2, (V[]){v_k_2426, v_n_241})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2451);
  V f_ = v_k_2436;
  args[0] = heff_box_word((heff_unbox_word(v_n_241) + ((int64_t)1ULL)));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam7(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_n_241 = heff_env(self)[0];
  V v_r_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_intShow(heff_box_word((heff_peek_word(v_n_241) + ((int64_t)1ULL))));
  V v_t_2438 = heff_get_n(v_r_2434, 0, 3);
  V v_t_2442;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_Exited: {
    V v_n_2439 = heff_field(v_t_2438, 0);
    heff_take_n(v_t_2438, 1ULL, 1);
    if (heff_intEq_c(v_n_2439, MK_INT(0LL))) {
      v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str2);
    } else {
      v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str3);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2438, 0ULL, 1);
    v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str4);
    break;
  }
  case TAG_TimedOut: {
    v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str5);
    break;
  }
  case TAG_NotRun: {
    v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str6);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str7), heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str8)));
  V v_t_2444 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str9), heff_strAppend(v_t_2437, v_t_2443));
  V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str10)), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_hd_2435, heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam8, 1, 2, (V[]){v_k_2436, v_n_241})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam4(V self, V *args) {
  V v_c_2423 = args[0];
  V v_n_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_c_2423)) {
  case TAG_Left: {
    heff_take_n(v_c_2423, 0ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam5, 2, 1, (V[]){v_n_241});
  }
  case TAG_Right: {
    V v_r_2434 = heff_field(v_c_2423, 0);
    heff_take_n(v_c_2423, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam7, 2, 2, (V[]){v_n_241, v_r_2434});
  }
  default: return heff_nomatch(v_c_2423);
  }
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam9(V self, V *args) {
  V v_s_2454 = args[0];
  return v_s_2454;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam11(V self, V *args) {
  V v_r_2464 = args[0];
  return v_r_2464;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam13(V self, V *args) {
  V v_r_2472 = args[0];
  return v_r_2472;
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam14(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_2471 = heff_env(self)[0];
  V v_f_2452 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2482;
  switch (heff_tag_of(v_x_2479)) {
  case TAG_Left: {
    V v_err_2480 = heff_field(v_x_2479, 0);
    V v_ru_24x_2479_24Left = heff_take_reuse_n(v_x_2479, 1ULL, 1);
    heff_drop(v_x_2471);
    v_t_2482 = heff_tag_at_n(v_ru_24x_2479_24Left, TAG_Left, 1, (V[]){v_err_2480});
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2479_24Right = heff_take_reuse_n(v_x_2479, 0ULL, 1);
    v_t_2482 = heff_tag_at_n(v_ru_24x_2479_24Right, TAG_Right, 1, (V[]){v_x_2471});
    break;
  }
  default: heff_nomatch(v_x_2479);
  }
  V f_ = v_f_2452;
  heff_room[0] = v_t_2482;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam12(V self, V *args) {
  V v_x_2471 = args[0];
  V v_x_2463 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_f_2452 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_2463, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam13_clo)})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s94900133x232571340(v_t_2478, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam14, 1, 4, (V[]){v_x_2471, v_f_2452, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_f_2452 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Left: {
    V v_err_2462 = heff_field(v_x_2461, 0);
    heff_take_n(v_x_2461, 1ULL, 1);
    V f_ = v_f_2452;
    heff_room[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2462});
    heff_room[1] = v_hd_242;
    heff_room[2] = v_k_243;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Right: {
    V v_x_2463 = heff_field(v_x_2461, 0);
    V v_ru_24x_2461_24Right = heff_take_reuse_n(v_x_2461, 1ULL, 1);
    V v_t_2465 = heff_tag_at_n(v_ru_24x_2461_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){heff_dup(v_x_2463), ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam11_clo)})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    return (g_co_2eop_24s94900133x232571340(v_t_2470, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam12, 1, 4, (V[]){v_x_2463, v_hd_242, v_f_2452, v_k_243})));
  }
  default: return heff_nomatch(v_x_2461);
  }
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_as_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_f_2452 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam4, 1, 1, (V[]){v_n_241});
  V v_t_2453 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2422, v_as_240, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_str11), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){v_t_2453, ((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam9_clo)})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s94900133x232571340(v_t_2460, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam10, 1, 3, (V[]){v_f_2452, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_as_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam2_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(v_t_2421, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestedAgain_24s1180266376x1446617804_lam3, 1, 4, (V[]){v_n_241, v_as_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925(V v_opts_240, V v_done_241, V v_x3_242, V v_acc_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_done_241);
    heff_drop(v_z_244);
    return heff_tail(v_z_245, 1, (V[]){v_acc_243});
  }
  case TAG_Cons: {
    V v_r_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    V v_p_248 = heff_dup(heff_rfield(v_r_246, 1));
    V v_t_249 = (g_list_2efilter_24s1505276232x1076898175(heff_dup(heff_rfield(v_r_246, 0)), heff_dup(v_done_241)));
    V v_t_2410 = (g_list_2esortBy_24s196358923x1153659155(v_t_249));
    V v_more_2411 = (g_list_2emap_24s1498757180x165099811(v_t_2410));
    V v_t_2412 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_248, 3)), v_more_2411));
    V v_c_2413 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(heff_rfield(v_opts_240, 3), heff_dup(heff_rfield(v_p_248, 0)), v_t_2412));
    return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_lam0, 1, 7, (V[]){v_opts_240, v_acc_243, v_done_241, heff_dup(v_rest_247), v_z_244, v_z_245, v_p_248})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_done_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_243, v_x_2417));
  return ({ V a_0 = v_opts_240; V a_1 = v_done_241; V a_2 = v_rest_247; V a_3 = v_t_2418; V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_247); r_; });
}
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_done_241 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2epassedOver(heff_dup(v_opts_240), heff_dup(v_x_2414)));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop_rec(v_p_248, 7);
    heff_drop(v_t_2415);
    V v_t_2416 = (g_heff_2ebuild_2ecommands_2eaddRes_24s1345625460x883944866(v_acc_243));
    return ({ V a_0 = v_opts_240; V a_1 = v_done_241; V a_2 = v_rest_247; V a_3 = v_t_2416; V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_247); r_; });
  } else {
    heff_drop(v_t_2415);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(heff_dup(heff_rfield(v_p_248, 0)), heff_dup(heff_rfield(v_p_248, 1)), heff_get_n(v_p_248, 2, 7), v_x_2414, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_lam1, 1, 6, (V[]){v_acc_243, v_opts_240, v_done_241, v_rest_247, v_z_244, v_z_245})));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150(V v_failed_240, V v_l_241, V v_name_242, V v_outPath_243, V v_file_244, V v_done_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str0), heff_dup(heff_rfield(v_l_241, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam0, 1, 8, (V[]){v_l_241, v_hd_246, v_file_244, v_failed_240, v_k_247, v_name_242, v_outPath_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam2(V self, V *args) {
  V v_c_2413 = args[0];
  V v_sources_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2414 = (g_list_2efind_24s1983706162x228765702_24cpr(heff_dup(v_c_2413), v_sources_2411));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_s_2418 = v_field_2416;
      V v_t_2419 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2412, v_s_2418));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2413, v_t_2419));
    } else {
      heff_drop(v_x_2412);
      heff_drop(v_field_2416);
      return v_c_2413;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_file_244 = heff_env(self)[2];
  V v_failed_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_x_2410 = heff_env(self)[6];
  V v_l_241 = heff_env(self)[7];
  V v_name_242 = heff_env(self)[8];
  V v_outPath_243 = heff_env(self)[9];
  V v_done_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2421);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop_rec(v_x_2410, 2);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_name_242);
    heff_drop(v_outPath_243);
    heff_drop(v_done_245);
    HeffT2 v_t_2423 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x_2420));
    V v_t_2428;
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        heff_drop(v_file_244);
        V v_x_2427 = v_field_2425;
        v_t_2428 = v_x_2427;
      } else {
        heff_drop(v_field_2425);
        v_t_2428 = heff_strAppend(v_file_244, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str3));
      }
    }
    V f_ = v_failed_240;
    heff_room[0] = v_t_2428;
    heff_room[1] = v_hd_246;
    heff_room[2] = v_k_247;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    V v_t_2429 = (g_list_2eany_24s469495312x865582084(v_x_2420));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2410, 2);
      heff_drop_rec(v_l_241, 5);
      heff_drop(v_name_242);
      heff_drop(v_outPath_243);
      heff_drop(v_done_245);
      heff_drop(v_t_2429);
      HeffT2 v_t_2430 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x_2420));
      V v_t_2435;
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          heff_drop(v_file_244);
          V v_x_2434 = v_field_2432;
          v_t_2435 = v_x_2434;
        } else {
          heff_drop(v_field_2432);
          v_t_2435 = heff_strAppend(v_file_244, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str4));
        }
      }
      V f_ = v_failed_240;
      heff_room[0] = v_t_2435;
      heff_room[1] = v_hd_246;
      heff_room[2] = v_k_247;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_t_2429);
      V v_t_2436 = (g_list_2emap_24s1698496827x1884878103(heff_take_field(v_x_2410, 0)));
      V v_t_2437 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_241, 2), heff_get_n(v_x_2410, 1, 2), v_t_2436});
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1367496791x1594795416(v_t_2437, heff_get_n(v_l_241, 0, 5), v_file_244, v_name_242, v_outPath_243, v_failed_240, v_done_245, v_x_2420, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_file_244 = heff_env(self)[3];
  V v_failed_240 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_name_242 = heff_env(self)[6];
  V v_outPath_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_sources_2411 = heff_dup(heff_rfield(v_l_241, 0));
  V v_x_2412 = (g_list_2emap_24f1819215186x476901667(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_str2), heff_dup(v_sources_2411)));
  V v_x_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam2, 1, 2, (V[]){v_sources_2411, v_x_2412}), heff_dup(heff_rfield(v_x_2410, 0))));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_x_2420), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam3, 1, 11, (V[]){v_x_248, v_x_2420, v_file_244, v_failed_240, v_hd_246, v_k_247, v_x_2410, v_l_241, v_name_242, v_outPath_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_file_244 = heff_env(self)[2];
  V v_failed_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_name_242 = heff_env(self)[5];
  V v_outPath_243 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_l_241)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_lam1, 1, 9, (V[]){v_l_241, v_hd_246, v_x_248, v_file_244, v_failed_240, v_k_247, v_name_242, v_outPath_243, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_246 = v_field_244;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam0, 2, 2, (V[]){v_path_246, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2422 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Just = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    v_t_2423 = heff_tag_at_n(v_ru_24x_2421_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2422})});
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V f_ = v_k_248;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_path_246 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
  V v_t_2410 = heff_strSlice(heff_dup(v_path_246), heff_box_word(v_t_249), heff_strLength_lent(v_path_246, 0));
  V v_t_2413;
  if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_str0))) {
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
    v_t_2413 = heff_strSlice(v_path_246, MK_INT(0LL), heff_box_word(v_t_2412));
  } else {
    v_t_2413 = v_path_246;
  }
  V v_t_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_str1)), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam1_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(v_t_2420, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam2, 1, 2, (V[]){v_m_241, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderAt_24s1674965845x1936879691(heff_dup(v_sources_240), v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam1, 2, 3, (V[]){v_c_246, v_sources_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816(v_sources_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1632029803x422432816_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str1, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str4, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str5, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str9, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str10, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str12, 1, "\012");
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s94900133x232571340(v_t_249, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam3(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam5(V self, V *args) {
  V v_s_2433 = args[0];
  return v_s_2433;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam8(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2468) == NTAG(TAG_True))) {
    heff_drop(v_x_2468);
    V v_t_2469 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str4), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str5)));
    V v_t_2470 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str6)), NTAG(TAG_MkUnit)});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), v_hd_241, v_k_242));
  } else {
    heff_drop(v_x_2468);
    heff_drop(v_dir_240);
    V v_t_2476 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam10(V self, V *args) {
  V v_x_2495 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_2446 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2449;
  if (heff_strEq_c_lent(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str2), 2)) {
    v_t_2449 = v_x_2410;
  } else {
    heff_drop(v_x_2410);
    v_t_2449 = heff_dup(v_dir_240);
  }
  HeffT2 v_t_2450 = (g_heff_2ebuild_2ecommands_2einitProblem_24cpr(v_t_2449, v_x_2443));
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      heff_drop(v_x_2447);
      heff_drop(v_dir_240);
      heff_drop(v_x_2446);
      V v_why_2454 = v_field_2452;
      V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_2454, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str3)), NTAG(TAG_MkUnit)});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam8, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      heff_drop(v_field_2452);
      switch (heff_tag_of(v_x_2447)) {
      case TAG_Nil: {
        return (g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487(heff_dup(v_dir_240), v_x_2446, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam9, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
      }
      case TAG_Cons: {
        heff_drop(v_x_2446);
        V v_t_2486;
        switch (heff_tag_of(v_x_2447)) {
        case TAG_Nil: {
          v_t_2486 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2484 = heff_field(v_x_2447, 0);
          V v_xs_2485 = heff_field(v_x_2447, 1);
          heff_take_n(v_x_2447, 3ULL, 2);
          v_t_2486 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str8); V a_1 = v_x_2484; V a_2 = v_xs_2485; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2485); r_; });
          break;
        }
        default: heff_nomatch(v_x_2447);
        }
        V v_t_2487 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str9), heff_strAppend(v_t_2486, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str10)));
        V v_str_2488 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str11), heff_strAppend(v_dir_240, v_t_2487));
        V v_t_2489 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2488, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str12)), NTAG(TAG_MkUnit)});
        V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
        V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
        V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
        V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
        V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2494}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam10, 1, 2, (V[]){v_hd_241, v_k_242})));
      }
      default: return heff_nomatch(v_x_2447);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2432 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2442;
  if (heff_strEq_c(v_x_2440, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str0))) {
    v_t_2442 = NTAG(TAG_Windows);
  } else {
    v_t_2442 = NTAG(TAG_Posix);
  }
  V v_x_2443 = ({ V a_0 = v_t_2442; V a_1 = heff_dup(v_dir_240); V a_2 = heff_dup(v_x_2410); V r_ = (g_heff_2ebuild_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_t_2442); r_; });
  V v_t_2445;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Nothing: {
    v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2444 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  V v_x_2446 = (g_heff_2ebuild_2ecommands_2eprojectFiles(heff_dup(v_x_2443), v_t_2445));
  return (g_heff_2ebuild_2ecommands_2eexisting_24s1589655271x472657650(heff_dup(v_dir_240), heff_dup(v_x_2446), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam7, 1, 6, (V[]){v_dir_240, v_x_2410, v_x_2443, v_hd_241, v_k_242, v_x_2446})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2432;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    v_x_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    HeffT2 v_t_2420 = ({ V a_0 = v_src_2419; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_src_2419); r_; });
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2418_24Just, 1);
        V v_p_2424 = v_field_2422;
        heff_drop(v_p_2424);
        v_x_2432 = NTAG(TAG_Nothing);
      } else {
        V v_x_2425 = v_field_2422;
        HeffT2 v_t_2426 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2425));
        {
          V v_field_2428 = v_t_2426.f[1];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2418_24Just, 1);
            V v_x_2430 = v_field_2428;
            heff_drop(v_x_2430);
            v_x_2432 = NTAG(TAG_Nothing);
          } else {
            V v_p_2431 = v_field_2428;
            v_x_2432 = heff_tag_at_n(v_ru_24x_2418_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2431, 1, 4)});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam5_clo)})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s94900133x232571340(v_t_2439, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam6, 1, 5, (V[]){v_dir_240, v_x_2410, v_x_2432, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam3_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam4, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_2410, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s960832757x1646818692_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_2410, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str2, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str3, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str4, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str5, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str7, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str8, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str9, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851(V v_prog_240, V v_dir_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s94900133x232571340(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam1, 1, 4, (V[]){v_hd_242, v_dir_241, v_k_243, v_prog_240})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam3(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam7(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_2456 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2465);
  V v_t_2466 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_hd_2456, v_k_2457));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam6(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_dir_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str8), heff_strAppend(v_dir_241, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str9)));
  V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2458, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str10)), NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(v_hd_2456), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam7, 1, 2, (V[]){v_hd_2456, v_k_2457})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = (g_std_2epath_2ejoin(v_st_2413, heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str2)));
  V v_x_2424 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_241), v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str3), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2414)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str4)});
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_st_2413);
    heff_drop(v_x_2414);
    heff_drop(v_prog_240);
    heff_drop_rec(v_x_2424, 6);
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str5), v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str6));
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam5, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_t_2455;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_Nothing: {
      heff_drop(v_x_2414);
      v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2424, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2440 = heff_field(v_x_2422, 0);
      heff_take_n(v_x_2422, 1ULL, 1);
      HeffT2 v_t_2441 = ({ V a_0 = v_text_2440; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_text_2440); r_; });
      {
        V v_field_2443 = v_t_2441.f[1];
        int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
        if ((v_tag_2442 == ((int64_t)0ULL))) {
          heff_drop(v_x_2414);
          V v_p_2445 = v_field_2443;
          heff_drop(v_p_2445);
          v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2424, 1))}));
        } else {
          V v_x_2446 = v_field_2443;
          HeffT2 v_t_2447 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2446));
          {
            V v_field_2449 = v_t_2447.f[1];
            int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
            if ((v_tag_2448 == ((int64_t)0ULL))) {
              heff_drop(v_x_2414);
              V v_x11_2451 = v_field_2449;
              heff_drop(v_x11_2451);
              v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2424, 1))}));
            } else {
              V v_pk_2452 = v_field_2449;
              if (heff_strEq_c(heff_get_n(v_pk_2452, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2424, 1))}));
                v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_clo), 5, (V[]){heff_dup(v_st_2413), heff_dup(v_x_2424), v_x_2414, heff_dup(v_dir_241), v_t_2454}));
              } else {
                heff_drop(v_x_2414);
                v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo), 2, (V[]){heff_dup(v_st_2413), heff_dup(heff_rfield(v_x_2424, 1))}));
              }
            }
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s76790599x1987194(v_prog_240, v_st_2413, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str7), v_x_2424, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam6, 2, 1, (V[]){v_dir_241}), v_t_2455, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2415 = (g_std_2epath_2ejoin(v_st_2413, heff_dup(v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str1)));
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2415, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam4, 1, 6, (V[]){v_st_2413, v_x_2414, v_dir_241, v_hd_242, v_k_243, v_prog_240})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_str0))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1367652885x1825008851_lam2, 1, 5, (V[]){v_st_2413, v_dir_241, v_hd_242, v_k_243, v_prog_240})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str6, 3, "src");
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610(V v_v_240, V v_l_241, V v_pk_242, V v_z_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(heff_rfield(v_pk_242, 0)), heff_dup(v_v_240)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_v_240);
      heff_drop_rec(v_l_241, 5);
      V v_why_249 = v_field_247;
      V v_t_2410 = heff_strAppend(heff_get_n(v_pk_242, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str0), v_why_249));
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str1), v_t_2410), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str2));
      V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam0, 1, 2, (V[]){v_z_243, v_z_244})));
    } else {
      heff_drop(v_field_247);
      V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
      V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 0, 6);
      V v_t_2427 = ({ V a_0 = v_t_2425; V a_1 = v_t_2426; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str3); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
      return (g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(heff_dup(heff_rfield(v_l_241, 2)), v_t_2427, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam1, 1, 5, (V[]){v_z_243, v_z_244, v_l_241, v_v_240, v_pk_242})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    V v_why_2429 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Left = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_242, 4);
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str4), v_why_2429), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str5));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_at_n(v_ru_24x_2428_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_lam2, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2428, 0ULL, 1);
    V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    V v_t_2446 = heff_get_n(heff_get_n(v_l_241, 2, 5), 0, 6);
    V v_t_2447 = ({ V a_0 = v_t_2445; V a_1 = v_t_2446; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_str6); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2445); r_; });
    return (g_heff_2ebuild_2ecommands_2epublishGit_24s1583189030x1634423901(v_v_240, v_pk_242, v_t_2447, v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x_2428);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_str0), heff_dup(heff_rfield(v_d_243, 1)));
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_d_243, 0)), v_t_245);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_str1)), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    HEFF_LAST return g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_lam0, 1, 4, (V[]){v_rest_244, v_p_241, v_d_243, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_get_n(v_d_243, 2, 3);
  V v_t_2416;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop(v_t_2415);
    v_t_2416 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2415);
    v_t_2416 = v_x_2414;
  }
  V f_ = v_p_242;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2413);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s370316181x1600102003_lam1, 1, 2, (V[]){v_d_243, v_p_242})));
}