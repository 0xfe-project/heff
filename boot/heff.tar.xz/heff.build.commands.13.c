// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Close 2276
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MkGroup 19195
#define TAG_Open 48267
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bind 9519364
#define LBL_copies 592412158
#define LBL_emits 297985818
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_groups 709681407
#define LBL_jobs 9763101
#define LBL_jss 315076
#define LBL_malg 9839318
#define LBL_mods 9852536
#define LBL_modules 1459291593
#define LBL_olds 9909235
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_root 10001833
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
V g_co_2eop_24s1178127530x1610393171(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1178127530x1610393171_entry(V self, V *a);
extern Clo g_co_2eop_24s1178127530x1610393171_clo;
V g_co_2eop_24s17678202x252484985(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s17678202x252484985_entry(V self, V *a);
extern Clo g_co_2eop_24s17678202x252484985_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589_clo;
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_clo;
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755(V);
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_clo;
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403(V, V, V);
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2emoduleText(V);
V g_heff_2ebuild_2ecommands_2emoduleText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emoduleText_clo;
V g_heff_2ebuild_2ecommands_2enewerTagged(V, V, V);
V g_heff_2ebuild_2ecommands_2enewerTagged_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewerTagged_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_clo;
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395_clo;
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_clo;
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s192900907x155689445(V, V, V);
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a);
extern Clo g_list_2efoldl_24s192900907x155689445_clo;
V g_list_2efoldl_24s591739608x1065283968(V, V);
V g_list_2efoldl_24s591739608x1065283968_entry(V self, V *a);
extern Clo g_list_2efoldl_24s591739608x1065283968_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0));
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1));
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_244);
        return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2));
      }
      case TAG_Cons: {
        V v_s_248 = heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3));
        V v_s_249 = heff_strAppend(v_s_248, heff_dup(v_b_244));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4));
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_244, v_x122_245});
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str1, 5, "build");
Clo g_heff_2ebuild_2ecommands_2epartsDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epartsDir_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2epartsDir(V v_st_240, V v_t_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str1)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_a_246 = ({ V a_0 = v_st_240; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_std_2epath_2eparse(v_st_240, v_a_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_p_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_p_2410));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2epartsDir(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ecommands_2eaddRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eaddRes_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eaddRes(V v_a_240, V v_b_241) {
top: ;
  V v_files_242 = heff_take_field(v_b_241, 0);
  V v_expectErrors_243 = heff_take_field(v_b_241, 1);
  V v_total_244 = heff_take_field(v_b_241, 2);
  V v_failed_245 = heff_take_field(v_b_241, 3);
  V v_unchecked_246 = heff_take_field(v_b_241, 4);
  V v_tests_247 = heff_take_field(v_b_241, 5);
  V v_testsFailed_248 = heff_take_field(v_b_241, 6);
  V v_testsSkipped_249 = heff_get_n(v_b_241, 7, 8);
  V v_files_2410 = heff_take_field(v_a_240, 0);
  V v_expectErrors_2411 = heff_take_field(v_a_240, 1);
  V v_total_2412 = heff_take_field(v_a_240, 2);
  V v_failed_2413 = heff_take_field(v_a_240, 3);
  V v_unchecked_2414 = heff_take_field(v_a_240, 4);
  V v_tests_2415 = heff_take_field(v_a_240, 5);
  V v_testsFailed_2416 = heff_take_field(v_a_240, 6);
  V v_testsSkipped_2417 = heff_get_n(v_a_240, 7, 8);
  V v_t_2418 = (g_prelude_2e_2b_2b(v_unchecked_2414, v_unchecked_246));
  return heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){heff_intAdd(v_files_2410, v_files_242), heff_intAdd(v_expectErrors_2411, v_expectErrors_243), heff_intAdd(v_total_2412, v_total_244), heff_intAdd(v_failed_2413, v_failed_245), v_t_2418, heff_intAdd(v_tests_2415, v_tests_247), heff_intAdd(v_testsFailed_2416, v_testsFailed_248), heff_intAdd(v_testsSkipped_2417, v_testsSkipped_249)});
}
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eaddRes(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str3, 0, "");

HeffT2 g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr(V v_n_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_245;
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_l_243 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 2);
      v_t_245 = v_l_243;
      break;
    }
    default: heff_nomatch(v_x2_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str1);
      break;
    }
    case TAG_Cons: {
      V v_l_246 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 2);
      v_t_248 = v_l_246;
      break;
    }
    default: heff_nomatch(v_x3_242);
    }
    V v_f_249 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_248});
    return ((HeffT2){{v_n_240, v_f_249}});
  }
  case TAG_Cons: {
    V v_a_2410 = heff_dup(heff_field(v_x2_241, 0));
    V v_argv_2411 = heff_dup(heff_field(v_x2_241, 1));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_a_2410);
      heff_drop(v_argv_2411);
      V v_t_2414;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_l_2412 = heff_field(v_x2_241, 0);
        heff_take_n(v_x2_241, 1ULL, 2);
        v_t_2414 = v_l_2412;
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      V v_t_2417;
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2ebuild_2ecommands_2efirstDiffering_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_l_2415 = heff_field(v_x3_242, 0);
        heff_take_n(v_x3_242, 1ULL, 2);
        v_t_2417 = v_l_2415;
        break;
      }
      default: heff_nomatch(v_x3_242);
      }
      V v_f_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_t_2417});
      return ((HeffT2){{v_n_240, v_f_2418}});
    }
    case TAG_Cons: {
      V v_b_2419 = heff_field(v_x3_242, 0);
      V v_bs_2420 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      heff_drop_tag(v_x2_241, 2);
      if (heff_strEq_c_lent(v_a_2410, v_b_2419, 0)) {
        heff_drop(v_a_2410);
        heff_drop(v_b_2419);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_argv_2411;
        V t_2 = v_bs_2420;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_argv_2411);
        heff_drop(v_bs_2420);
        return ((HeffT2){{v_n_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_a_2410, v_b_2419})}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elastLines_str3, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2elastLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elastLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elastLines(V v_n_240, V v_t_241) {
top: ;
  V v_xs_242 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2elastLines_str0); V a_1 = v_t_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2elastLines_str1), v_t_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x2_244 = (g_list_2efoldl_24f932140008x904662204(NTAG(TAG_Nil), v_n_240, v_t_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2elastLines_str2);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2elastLines_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elastLines(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str0, 7, "module ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str1, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str3, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str4, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str5, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str6, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str8, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str11, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emoduleText_str12, 52, "-- checks them all, and `heff test` their doc tests.");
Clo g_heff_2ebuild_2ecommands_2emoduleText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emoduleText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2emoduleText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2emoduleText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2emoduleText_str1)));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str4), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str6), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str8), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str9), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_245})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2emoduleText_str10); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2emoduleText_str11); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emoduleText_str12), v_t_246}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2emoduleText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emoduleText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewerTagged_str0, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewerTagged_str1, 11, "refs/tags/v");
Clo g_heff_2ebuild_2ecommands_2enewerTagged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewerTagged_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enewerTagged(V v_path_240, V v_best_241, V v_line_242) {
top: ;
  V v_it_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewerTagged_str0); V a_1 = v_line_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewerTagged_str1), v_line_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_241;
  }
  case TAG_Cons: {
    V v_it2_245 = heff_field(v_it_243, 1);
    heff_take_n(v_it_243, 2ULL, 2);
    switch (heff_tag_of(v_it2_245)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      return v_best_241;
    }
    case TAG_Cons: {
      V v_v_246 = heff_field(v_it2_245, 0);
      V v_it22_247 = heff_field(v_it2_245, 1);
      heff_take_n(v_it2_245, 3ULL, 2);
      switch (heff_tag_of(v_it22_247)) {
      case TAG_Nil: {
        V v_t_248 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
        V v_t_2410 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_249), MK_INT(-1LL)));
        V v_t_2411 = heff_strSlice(heff_dup(v_v_246), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
        HeffT2 v_t_2412 = ({ V a_0 = v_t_2411; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2411); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2414;
            heff_drop(v_x_2415);
            V v_t_2416 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
            int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
            V v_t_2418 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2417), MK_INT(-1LL)));
            V v_t_2419 = heff_strSlice(heff_dup(v_v_246), v_t_2416, heff_intAdd(v_t_2418, MK_INT(1LL)));
            HeffT2 v_t_2420 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(v_path_240, v_t_2419));
            {
              V v_field_2422 = v_t_2420.f[1];
              int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
              if ((v_tag_2421 == ((int64_t)0ULL))) {
                heff_drop(v_v_246);
                V v_x_2423 = v_field_2422;
                heff_drop(v_x_2423);
                return v_best_241;
              } else {
                heff_drop(v_field_2422);
                switch (heff_tag_of(v_best_241)) {
                case TAG_Nothing: {
                  V v_t_2424 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2426 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2425), MK_INT(-1LL)));
                  V v_t_2427 = heff_strSlice(v_v_246, v_t_2424, heff_intAdd(v_t_2426, MK_INT(1LL)));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2427});
                }
                case TAG_Just: {
                  V v_b_2428 = heff_dup(heff_field(v_best_241, 0));
                  V v_t_2429 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2430 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2431 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2430), MK_INT(-1LL)));
                  V v_t_2432 = heff_strSlice(heff_dup(v_v_246), v_t_2429, heff_intAdd(v_t_2431, MK_INT(1LL)));
                  V v_t_2433 = ({ V a_0 = v_t_2432; V a_1 = v_b_2428; V r_ = (g_heff_2ebuild_2eproject_2enewer(a_0, a_1)); heff_drop(v_t_2432); heff_drop(v_b_2428); r_; });
                  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
                    heff_drop_tag(v_best_241, 1);
                    heff_drop(v_t_2433);
                    V v_t_2434 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                    V v_t_2436 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2435), MK_INT(-1LL)));
                    V v_t_2437 = heff_strSlice(v_v_246, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2437});
                  } else {
                    heff_drop(v_v_246);
                    heff_drop(v_t_2433);
                    return v_best_241;
                  }
                }
                default: return heff_nomatch(v_best_241);
                }
              }
            }
          } else {
            heff_drop(v_path_240);
            heff_drop(v_v_246);
            heff_drop(v_field_2414);
            return v_best_241;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_247, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop(v_v_246);
        return v_best_241;
      }
      default: return heff_nomatch(v_it22_247);
      }
    }
    default: return heff_nomatch(v_it2_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ebuild_2ecommands_2enewerTagged_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2enewerTagged(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str0), v_l_245));
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s1178127530x1610393171(v_m_240, v_rest_246, v_n_242, MK_INT(1LL), heff_dup(v_p_243), v_p_244, heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_p_243));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str2, 8, "heff.zig");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(V v_bi_240, V v_dir_241, V v_zig_242, V v_id_243, V v_texts_244, V v_backs_245, V v_done_246, V v_out_247, V v_z_248, V v_z_249) {
top: ;
  V v_groups_2410 = heff_take_field(v_out_247, 2);
  V v_copies_2411 = heff_take_field(v_out_247, 3);
  V v_emits_2412 = heff_take_field(v_out_247, 4);
  V v_parts_2413 = heff_take_field(v_out_247, 0);
  V v_errors_2414 = heff_get_n(v_out_247, 1, 5);
  V v_paths_2415 = heff_take_field(v_bi_240, 0);
  V v_modules_2416 = heff_get_n(v_bi_240, 2, 3);
  V v_t_2433;
  if (heff_strEq_c_lent(v_id_243, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str0), 2)) {
    heff_drop(v_id_243);
    heff_drop(v_backs_245);
    heff_drop(v_groups_2410);
    heff_drop(v_copies_2411);
    heff_drop(v_emits_2412);
    heff_drop(v_paths_2415);
    heff_drop(v_modules_2416);
    v_t_2433 = v_done_246;
  } else {
    V v_s_2417 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2415)));
    V v_path_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2417; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2419 = ({ V a_0 = v_path_2418; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_2418); r_; });
    V v_c_2423 = heff_tr(heff_call(v_c_2419, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0_clo)}));
    v_t_2433 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1, 2, 10, (V[]){v_c_2423, heff_dup(v_texts_244), v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_243, v_backs_245, v_paths_2415, v_done_246});
  }
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str2), v_zig_242}), v_parts_2413});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(v_dir_241, v_t_2433, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_errors_2414}), v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2421 = args[1];
  V v_k_2422 = args[2];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2424;
  heff_room[1] = v_k_2425;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_texts_244 = heff_env(self)[0];
  V v_modules_2416 = heff_env(self)[1];
  V v_groups_2410 = heff_env(self)[2];
  V v_copies_2411 = heff_env(self)[3];
  V v_emits_2412 = heff_env(self)[4];
  V v_id_243 = heff_env(self)[5];
  V v_backs_245 = heff_env(self)[6];
  V v_paths_2415 = heff_env(self)[7];
  V v_hd_2424 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  V v_k_2425 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2426);
  V v_t_2427 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s591739608x1065283968(a_0, a_1)); heff_drop(v_texts_244); r_; });
  V v_t_2428 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str1), v_modules_2416}); V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2429 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2410, v_copies_2411, v_emits_2412, NTAG(TAG_Nil)});
  V v_t_2430 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2428, v_backs_245}), v_t_2429));
  V v_c_2431 = ({ V a_0 = v_paths_2415; V a_1 = v_t_2427; V a_2 = v_t_2430; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a_0, a_1, a_2)); heff_drop(v_t_2427); heff_drop(v_t_2430); r_; });
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam3, 1, 3, (V[]){v_done_246, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_texts_244 = heff_env(self)[1];
  V v_modules_2416 = heff_env(self)[2];
  V v_groups_2410 = heff_env(self)[3];
  V v_copies_2411 = heff_env(self)[4];
  V v_emits_2412 = heff_env(self)[5];
  V v_id_243 = heff_env(self)[6];
  V v_backs_245 = heff_env(self)[7];
  V v_paths_2415 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam2, 1, 11, (V[]){v_texts_244, v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_243, v_backs_245, v_paths_2415, v_hd_2424, v_done_246, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str1, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str3, 77, "heff test: no src/ nor test/ here: test at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str5, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str6, 77, "heff test: no src/ nor test/ here: test at the project's root, or give FILEs\012");
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_242 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_241));
    V v_c_247 = heff_tr(heff_call(v_c_242, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam0_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam2, 2, 1, (V[]){v_c_247});
  }
  case TAG_Cons: {
    V v_t_2477 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_t_2477, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752(a[0]);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_244 = (g_list_2emap_24s219049803x1458391381(v_x_243));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam1, 2, 1, (V[]){v_x_244});
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2417 = (g_list_2emap_24s219049803x1458391381(v_x_2416));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam5, 2, 1, (V[]){v_x_2417});
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam8, 1, 1, (V[]){v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam10(V self, V *args) {
  V v_x_2470 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2470);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam9(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  heff_room[0] = v_t_2469;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam10, 1, 1, (V[]){v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 0ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_Nothing: {
      v_t_2424 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x_2413, 0ULL, 1);
      v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str2), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_it_2425 = (g_prelude_2e_2b_2b(v_t_2424, NTAG(TAG_Nil)));
    switch (heff_tag_of(v_it_2425)) {
    case TAG_Nil: {
      V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str3), NTAG(TAG_MkUnit)});
      V v_t_2427 = heff_tag_at_n(v_ru_24x_2421_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
      V f_ = heff_dup(heff_rfield(v_hd_248, 1));
      heff_room[0] = v_t_2433;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam7, 1, 2, (V[]){v_hd_248, v_k_249});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x_2421_24Left, 1);
      V v_t_2446 = (g_list_2emap_24s1420651609x666245096(v_it_2425));
      V v_t_2447 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_t_2446, NTAG(TAG_Nil)));
      V f_ = v_t_2447;
      heff_room[0] = v_hd_248;
      heff_room[1] = v_k_249;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it_2425);
    }
  }
  case TAG_Right: {
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 0ULL, 1);
    V v_t_2450;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_Nothing: {
      v_t_2450 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x_2413, 0ULL, 1);
      v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str4), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str5), NTAG(TAG_Nil)});
    V v_it_2452 = (g_prelude_2e_2b_2b(v_t_2450, v_t_2451));
    switch (heff_tag_of(v_it_2452)) {
    case TAG_Nil: {
      V v_t_2453 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str6), NTAG(TAG_MkUnit)});
      V v_t_2454 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})}));
      V f_ = heff_dup(heff_rfield(v_hd_248, 1));
      heff_room[0] = v_t_2460;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam9, 1, 2, (V[]){v_hd_248, v_k_249});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_drop_cell(v_ru_24x_2421_24Right, 1);
      V v_t_2473 = (g_list_2emap_24s1420651609x666245096(v_it_2452));
      V v_t_2474 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_t_2473, NTAG(TAG_Nil)));
      V f_ = v_t_2474;
      heff_room[0] = v_hd_248;
      heff_room[1] = v_k_249;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it_2452);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    heff_take_n(v_x_2410, 0ULL, 1);
    v_x_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2412 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Right = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    v_x_2413 = heff_tag_at_n(v_ru_24x_2410_24Right, TAG_Just, 1, (V[]){v_y_2412});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_path_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_str1); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2415 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_2414));
  V v_c_2420 = heff_tr(heff_call(v_c_2415, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam4_clo)}));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam6, 1, 3, (V[]){v_x_2413, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_lam3, 1, 2, (V[]){v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_str0, 17, "integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_str1, 0, "");
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770(V v_rep_240, V v_prog_241, V v_rx_242, V v_ex_243, V v_opts_244, V v_ready_245, V v_acc_246) {
top: ;
  switch (heff_tag_of(v_ready_245)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_rx_242);
    heff_drop(v_ex_243);
    heff_drop_rec(v_opts_244, 4);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam0, 2, 1, (V[]){v_acc_246});
  }
  case TAG_Cons: {
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam2, 2, 8, (V[]){v_t_2412, v_rx_242, v_opts_244, v_ready_245, v_ex_243, v_prog_241, v_rep_240, v_acc_246});
  }
  default: return heff_nomatch(v_ready_245);
  }
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_acc_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_acc_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam4(V self, V *args) {
  V v_i_2416 = args[0];
  return v_i_2416;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_244 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_acc_246 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2437);
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_244; V a_2 = v_x_2431; V a_3 = v_ready_245; V a_4 = v_acc_246; V a_5 = v_hd_2413; V a_6 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s1175850862x243178395(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_ready_245, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_opts_244 = heff_env(self)[4];
  V v_x_2431 = heff_env(self)[5];
  V v_ready_245 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2435}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2436, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam8, 1, 7, (V[]){v_rep_240, v_opts_244, v_x_2431, v_ready_245, v_acc_246, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_rx_242 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_opts_244 = heff_env(self)[6];
  V v_ready_245 = heff_env(self)[7];
  V v_acc_246 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2432 = heff_tag_n(TAG_Close, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tr(heff_call(v_rx_242, 1, (V[]){v_t_2432}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2433, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam7, 1, 9, (V[]){v_x_2415, v_prog_241, v_hd_2413, v_rep_240, v_opts_244, v_x_2431, v_ready_245, v_acc_246, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_opts_244 = heff_env(self)[0];
  V v_ready_245 = heff_env(self)[1];
  V v_ex_243 = heff_env(self)[2];
  V v_rx_242 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_acc_246 = heff_env(self)[8];
  V v_k_2414 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_p_2419 = heff_dup(heff_rfield(v_opts_244, 1));
  V v_t_2427;
  if (heff_strEq_c_lent(v_p_2419, ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_str1), 2)) {
    heff_drop(v_p_2419);
    v_t_2427 = NTAG(TAG_Nil);
  } else {
    V v_t_2420 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_2419; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_2419); r_; });
    V v_t_2421 = (g_list_2emap_24s1007499915x73800978(v_t_2420));
    HeffT2 v_t_2422 = (g_regex_2eallRead_24cpr(v_t_2421));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_why_2425 = v_field_2424;
        heff_drop(v_why_2425);
        v_t_2427 = NTAG(TAG_Nil);
      } else {
        V v_sel_2426 = v_field_2424;
        v_t_2427 = v_sel_2426;
      }
    }
  }
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ready_245)));
  V v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2428; V r_ = (g_list_2efoldl_24s192900907x155689445(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
  V v_c_2430 = ({ V a_0 = v_ex_243; V a_1 = heff_dup(v_rx_242); V a_2 = v_t_2427; V a_3 = heff_dup(heff_rfield(v_opts_244, 2)); V b_4 = heff_tag_n(TAG_MkGroup, 1, (V[]){heff_dup(v_x_2418)}); V a_5 = v_t_2429; V a_6 = MK_INT(0LL); V a_7 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7)); heff_drop(b_4); r_; });
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam6, 1, 10, (V[]){v_x_2418, v_rx_242, v_hd_2413, v_x_2415, v_prog_241, v_rep_240, v_opts_244, v_ready_245, v_acc_246, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_rx_242 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_opts_244 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_ex_243 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_rx_242), 1, (V[]){heff_tag_n(TAG_Open, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam4_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2417, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam5, 1, 10, (V[]){v_opts_244, v_ready_245, v_ex_243, v_rx_242, v_hd_2413, v_x_2415, v_prog_241, v_rep_240, v_acc_246, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_rx_242 = heff_env(self)[1];
  V v_opts_244 = heff_env(self)[2];
  V v_ready_245 = heff_env(self)[3];
  V v_ex_243 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_acc_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s615738393x1686646143(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1206393877x1290242770_lam3, 1, 9, (V[]){v_rx_242, v_hd_2413, v_opts_244, v_ready_245, v_ex_243, v_prog_241, v_rep_240, v_acc_246, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str1, 11, ".provider.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str2, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str3, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str4, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str5, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(V v_host_240, V v_s_241) {
top: ;
  V v_p_242 = heff_dup(heff_rfield(v_s_241, 2));
  int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_p_242, 0)) - ((int64_t)3ULL));
  V v_t_244 = heff_strSlice(heff_dup(v_p_242), heff_box_word(v_t_243), heff_strLength_lent(v_p_242, 0));
  V v_t_246;
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str0))) {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_242, 0)) - ((int64_t)3ULL));
    v_t_246 = heff_strSlice(v_p_242, MK_INT(0LL), heff_box_word(v_t_245));
  } else {
    v_t_246 = v_p_242;
  }
  V v_s_247 = heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str1));
  V v_path_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_247; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_249 = ({ V a_0 = v_path_248; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_248); r_; });
  V v_c_2413 = heff_tr(heff_call(v_c_249, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1, 2, 3, (V[]){v_c_2413, v_s_241, heff_dup(v_host_240)});
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    V f_ = v_k_2415;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2430, 0ULL, 1);
    V f_ = v_k_2415;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_2443 = args[1];
  V v_k_2444 = args[2];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Left: {
    heff_take_n(v_x_2446, 0ULL, 1);
    heff_drop(v_host_240);
    V f_ = v_k_2415;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2448 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    V v_t_2449 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str6); V a_1 = v_y_2448; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str7), v_y_2448, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_y_2448); r_; });
    V v_t_2450 = (g_list_2emap_24s649333309x1802289391(v_t_2449));
    V v_x1_2451 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2450));
    V v_t_2454;
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nil: {
      heff_drop(v_host_240);
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 2);
      v_t_2454 = heff_bool(!heff_strEq_c_lent(v_x_2452, v_host_240, 0));
      heff_drop(v_host_240);
      heff_drop(v_x_2452);
      break;
    }
    default: heff_nomatch(v_x1_2451);
    }
    V f_ = v_k_2415;
    args[0] = v_t_2454;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2446);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_host_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    heff_take_n(v_x_2416, 0ULL, 1);
    heff_drop(v_host_240);
    V v_p_2418 = heff_get_n(v_s_241, 2, 8);
    int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_2418, 0)) - ((int64_t)3ULL));
    V v_t_2420 = heff_strSlice(heff_dup(v_p_2418), heff_box_word(v_t_2419), heff_strLength_lent(v_p_2418, 0));
    V v_t_2422;
    if (heff_strEq_c(v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str2))) {
      int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_p_2418, 0)) - ((int64_t)3ULL));
      v_t_2422 = heff_strSlice(v_p_2418, MK_INT(0LL), heff_box_word(v_t_2421));
    } else {
      v_t_2422 = v_p_2418;
    }
    V v_s_2423 = heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str3));
    V v_path_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2423; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2425 = ({ V a_0 = v_path_2424; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2424); r_; });
    V v_c_2429 = heff_tr(heff_call(v_c_2425, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3_clo)}));
    V f_ = v_c_2429;
    heff_room[0] = v_hd_2414;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam4, 1, 1, (V[]){v_k_2415});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2416, 0ULL, 1);
    V v_p_2434 = heff_get_n(v_s_241, 2, 8);
    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_p_2434, 0)) - ((int64_t)3ULL));
    V v_t_2436 = heff_strSlice(heff_dup(v_p_2434), heff_box_word(v_t_2435), heff_strLength_lent(v_p_2434, 0));
    V v_t_2438;
    if (heff_strEq_c(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str4))) {
      int64_t v_t_2437 = (heff_unbox_word(heff_strLength_lent(v_p_2434, 0)) - ((int64_t)3ULL));
      v_t_2438 = heff_strSlice(v_p_2434, MK_INT(0LL), heff_box_word(v_t_2437));
    } else {
      v_t_2438 = v_p_2434;
    }
    V v_s_2439 = heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str5));
    V v_path_2440 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2439; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2441 = ({ V a_0 = v_path_2440; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2440); r_; });
    V v_c_2445 = heff_tr(heff_call(v_c_2441, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5_clo)}));
    V f_ = v_c_2445;
    heff_room[0] = v_hd_2414;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6, 1, 2, (V[]){v_k_2415, v_host_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam2, 1, 4, (V[]){v_s_241, v_hd_2414, v_k_2415, v_host_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_str1, 68, "heff doc: no src/ here: run it at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_str2, 3, "src");
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_242 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_241));
    V v_c_247 = heff_tr(heff_call(v_c_242, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam0_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam2, 2, 1, (V[]){v_c_247});
  }
  case TAG_Cons: {
    V v_t_2436 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_t_2436, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755(a[0]);
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_244 = (g_list_2emap_24s219049803x1458391381(v_x_243));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam1, 2, 1, (V[]){v_x_244});
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  heff_room[0] = v_t_2428;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam5, 1, 1, (V[]){v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_248 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 0ULL, 1);
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_str1), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
    V f_ = heff_dup(heff_rfield(v_hd_248, 1));
    heff_room[0] = v_t_2419;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam4, 1, 2, (V[]){v_hd_248, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2410, 0ULL, 1);
    V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_str2)});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    V v_t_2433 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_t_2432, NTAG(TAG_Nil)));
    V f_ = v_t_2433;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755_lam3, 1, 2, (V[]){v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_str0, 16, "checking modules");
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109(V v_rep_240, V v_prog_241, V v_out_242, V v_given_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2ecommands_2edocFiles_24s963853261x1261070755(v_given_243));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam0, 2, 4, (V[]){v_c_244, v_prog_241, v_rep_240, v_out_242});
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam2(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2418);
  V v_t_2419 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2413; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_247); r_; });
  if (heff_intLt_c(v_t_2419, v_t_2420)) {
    V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_245, v_k_246));
  } else {
    heff_drop(v_hd_245);
    V f_ = v_k_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_out_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2416);
  V v_c_2417 = heff_tr(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403(v_prog_241, v_out_242, heff_dup(v_x_2413)));
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam6, 1, 4, (V[]){v_x_2413, v_x_247, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_out_242 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2414}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam5, 1, 6, (V[]){v_prog_241, v_out_242, v_x_2413, v_hd_245, v_x_247, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_out_242 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2edocChecked_24s1321980490x2061639589(v_rep_240, heff_dup(v_prog_241), heff_dup(v_x_2411), heff_dup(v_x_247), NTAG(TAG_Nil)));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam4, 1, 6, (V[]){v_x_2411, v_prog_241, v_hd_245, v_out_242, v_x_247, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_out_242 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_total_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_247));
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_str0), v_total_248, ((V)&g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam2_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2410, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam3, 1, 6, (V[]){v_rep_240, v_prog_241, v_x_247, v_hd_245, v_out_242, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_out_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocCmd_24s1715540899x577473109_lam1, 1, 5, (V[]){v_prog_241, v_hd_245, v_rep_240, v_out_242, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_str0, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(V v_prog_240, V v_st_241, V v_t_242, V v_rd_243, V v_acc_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_rd_243);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_244, 0)));
    V v_x_247 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_acc_244, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam0, 2, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x5_245, 0);
    V v_rest_2411 = heff_field(v_x5_245, 1);
    heff_take_n(v_x5_245, 3ULL, 2);
    V v_s_2412 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_241, heff_dup(v_t_242), heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_str0)));
    V v_path_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2412; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2414 = ({ V a_0 = v_path_2413; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2413); r_; });
    V v_c_2418 = heff_tr(heff_call(v_c_2414, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam1_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam2, 2, 8, (V[]){v_c_2418, heff_dup(v_st_241), v_t_242, v_acc_244, v_x_2410, v_rd_243, v_prog_240, v_rest_2411});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_2416 = args[1];
  V v_k_2417 = args[2];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_rd_243 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_rest_2411 = heff_env(self)[4];
  V v_hd_2419 = heff_env(self)[5];
  V v_k_2420 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_243), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2427}));
  return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_rd_243; V a_4 = v_x_2426; V a_5 = v_rest_2411; V a_6 = heff_dup(v_hd_2419); V a_7 = v_k_2420; V a_8 = v_t_2428; V a_9 = v_hd_2419; V r_ = (g_co_2eop_24s17678202x252484985(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_st_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_hd_2419 = heff_env(self)[4];
  V v_rd_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_k_2420 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2424;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_Just, 1, (V[]){v_y_2423});
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_c_2425 = (g_heff_2ebuild_2ecommands_2eappRead_24s1549623878x1480612342(v_st_241, heff_dup(v_t_242), v_acc_244, v_x_2410, v_t_2424));
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_2419);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam4, 1, 7, (V[]){v_rd_243, v_prog_240, v_st_241, v_t_242, v_rest_2411, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_rd_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_lam3, 1, 9, (V[]){v_st_241, v_t_242, v_acc_244, v_x_2410, v_hd_2419, v_rd_243, v_prog_240, v_rest_2411, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str0, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str1, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str2, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580(V v_v_240, V v_pk_241, V v_r_242, V v_z_243, V v_z_244) {
top: ;
  V v_failed_245 = heff_take_field(v_r_242, 3);
  V v_testsFailed_246 = heff_take_field(v_r_242, 6);
  V v_unchecked_247 = heff_take_field(v_r_242, 4);
  V v_total_248 = heff_take_field(v_r_242, 2);
  V v_tests_249 = heff_get_n(v_r_242, 5, 8);
  V v_t_2412;
  if (heff_intLt_c_lent(MK_INT(0LL), v_failed_245, 1)) {
    heff_drop(v_unchecked_247);
    v_t_2412 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c_lent(MK_INT(0LL), v_testsFailed_246, 1)) {
      heff_drop(v_unchecked_247);
      v_t_2412 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_unchecked_247)) {
      case TAG_Nil: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_unchecked_247, 0ULL, 2);
        v_t_2412 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_unchecked_247);
      }
    }
  }
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    heff_drop(v_t_2412);
    V v_t_2413 = heff_strAppend(heff_intShow(v_tests_249), ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str0));
    V v_t_2414 = heff_strAppend(heff_intShow(v_testsFailed_246), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str1), v_t_2413));
    V v_t_2415 = heff_strAppend(heff_intShow(v_total_248), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str2), v_t_2414));
    V v_t_2416 = heff_strAppend(heff_intShow(v_failed_245), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str3), v_t_2415));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str4), v_t_2416), ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_str5));
    V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
    return heff_tail(heff_dup(heff_rfield(v_z_243, 1)), 2, (V[]){v_t_2425, heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_lam0, 1, 2, (V[]){v_z_243, v_z_244})});
  } else {
    heff_drop(v_failed_245);
    heff_drop(v_testsFailed_246);
    heff_drop(v_total_248);
    heff_drop(v_tests_249);
    heff_drop(v_t_2412);
    return (g_heff_2ebuild_2ecommands_2epublishTag_24s2088023142x1060825394(v_v_240, v_pk_241, v_z_243, v_z_244));
  }
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_z_243, v_z_244));
}