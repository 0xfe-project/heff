// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Become 65038
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_right 309870134
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s441514442x2097556756(V, V, V, V);
V g_co_2ebind_24s441514442x2097556756_entry(V self, V *a);
extern Clo g_co_2ebind_24s441514442x2097556756_clo;
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2ememoed_2edecode(V);
V g_heff_2eelab_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2edecode_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecordFormation(V);
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordFormation_clo;
V g_heff_2eelab_2erules_2erecordTypeIntro(V, V);
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V);
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V);
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V);
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edefineD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edefineD_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2efailedAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efailedAt_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2emetasInV(V, V);
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2emetasInV_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn(V);
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo;
V g_heff_2eelab_2etoplevel_2enominalTyp(V);
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V, V, V);
V g_heff_2eelab_2etoplevel_2epatName(V, V, V);
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epatName_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2eshownV(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eshownV_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
HeffT2 g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(V);
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(V, V, V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s579110916x1535220277(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s579110916x1535220277_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s579110916x1535220277_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithOne(V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2edelete_24s805420727x38051515(V, V);
V g_map_2edelete_24s805420727x38051515_entry(V self, V *a);
extern Clo g_map_2edelete_24s805420727x38051515_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
HeffT2 g_map_2elookup_24s567992785x1569911877_24cpr(V, V);
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalSyn(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_res_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  V v_x1_2412 = heff_tr(heff_call(heff_get_n(v_res_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2416});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_res_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    V v_ru_24x_247_24MkPair = heff_take_reuse_n(v_x_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_res_248, 0))});
    V v_t_2417 = heff_tag_at_n(v_ru_24x_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam3, 1, 1, (V[]){v_res_248})}), v_a_249});
    V f_ = v_k_246;
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkSyn: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_call(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam1, 2, 1, (V[]){v_c_244});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str0, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str1, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str2, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str3, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str4, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str5, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str6, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str7, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str8, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str9, 54, "an argument of a `case` pattern is a pattern or a name");
Clo g_heff_2eelab_2etoplevel_2epatName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epatName_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2epatName(V v_p_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      heff_drop_rec(v_p_241, 3);
      return heff_tail(v_p_242, 1, (V[]){heff_dup(v_x_245)});
    }
    case TAG_PatTag: {
      V v_t_2411;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2410 = heff_field(v_p_240, 1);
        v_t_2411 = heff_dup(v_s_2410);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str0), v_t_2411, NTAG(TAG_Nothing)});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2414}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2415, v_p_242});
    }
    case TAG_PatOp: {
      V v_t_2421;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_p_240, 1);
        v_t_2421 = heff_dup(v_s_2420);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str1), v_t_2421, NTAG(TAG_Nothing)});
      V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2424}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2425, v_p_242});
    }
    case TAG_PatInt: {
      V v_t_2429;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2428 = heff_field(v_p_240, 1);
        v_t_2429 = heff_dup(v_s_2428);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str2), v_t_2429, NTAG(TAG_Nothing)});
      V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2432}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2433, v_p_242});
    }
    case TAG_PatFloat: {
      V v_t_2437;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2436 = heff_field(v_p_240, 1);
        v_t_2437 = heff_dup(v_s_2436);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str3), v_t_2437, NTAG(TAG_Nothing)});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2440}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2441, v_p_242});
    }
    case TAG_PatString: {
      V v_t_2445;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_p_240, 1);
        v_t_2445 = heff_dup(v_s_2444);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str4), v_t_2445, NTAG(TAG_Nothing)});
      V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2448}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2449, v_p_242});
    }
    case TAG_PatBinary: {
      V v_t_2453;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2452 = heff_field(v_p_240, 1);
        v_t_2453 = heff_dup(v_s_2452);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str5), v_t_2453, NTAG(TAG_Nothing)});
      V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2456}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2457, v_p_242});
    }
    case TAG_PatRune: {
      V v_t_2461;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2460 = heff_field(v_p_240, 1);
        v_t_2461 = heff_dup(v_s_2460);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2462 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str6), v_t_2461, NTAG(TAG_Nothing)});
      V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2462})});
      V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2464}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2465, v_p_242});
    }
    case TAG_PatRecord: {
      V v_t_2469;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2468 = heff_field(v_p_240, 1);
        v_t_2469 = heff_dup(v_s_2468);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str7), v_t_2469, NTAG(TAG_Nothing)});
      V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2472}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2473, v_p_242});
    }
    case TAG_PatWord: {
      V v_t_2477;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_p_240, 1);
        v_t_2477 = heff_dup(v_s_2476);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2478 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str8), v_t_2477, NTAG(TAG_Nothing)});
      V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2480}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2481, v_p_242});
    }
    case TAG_PatAs: {
      V v_t_2487;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2486 = heff_field(v_p_240, 1);
        v_t_2487 = heff_dup(v_s_2486);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2488 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str9), v_t_2487, NTAG(TAG_Nothing)});
      V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_2490}));
      return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_2491, v_p_242});
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2epatName(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    return ({ V a_0 = v_x_243; V a_1 = heff_dup(v_p_241); V a_2 = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0, 1, 3, (V[]){v_xs_244, v_p_241, v_p_242}); V r_ = (g_heff_2eelab_2etoplevel_2epatName(a_0, a_1, a_2)); heff_drop(v_x_243); r_; });
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(v_xs_244, v_p_241, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1, 1, 2, (V[]){v_p_242, v_x_245})));
}
Clo g_heff_2eelab_2etoplevel_2etagSpans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpans_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSpans(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 2);
        V v_acc_247 = (g_heff_2eelab_2etoplevel_2etagSpans(v_rest_242));
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_245));
        V v_t_249 = heff_get_n(v_t_248, 0, 2);
        switch (heff_tag_of(v_t_249)) {
        case TAG_At: {
          V v_it1_2410 = heff_field(v_t_249, 0);
          V v_tsp_2411 = heff_field(v_t_249, 1);
          heff_take_n(v_t_249, 3ULL, 2);
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_PatVar: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatTag: {
            V v_x_2413 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 3);
            return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_tsp_2411}), v_acc_247});
          }
          case TAG_PatOp: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatInt: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatFloat: {
            heff_take_na(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatString: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatBinary: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRune: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRecord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatWord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatAs: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          default: return heff_nomatch(v_it1_2410);
          }
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSpans(a[0]);
}

HeffT2 g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(V v_ge_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(MK_INT(0LL), MK_INT(0LL), heff_take_field(v_ge_240, 1)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_it1_245 = v_field_243;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_MkPair: {
        V v_i_246 = heff_field(v_it1_245, 0);
        V v_k_247 = heff_field(v_it1_245, 1);
        V v_ru_24it1_245_24MkPair = heff_take_reuse_n(v_it1_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2eelab_2etoplevel_2elamsOf_24cpr(MK_INT(0LL), heff_get_n(v_ge_240, 0, 4)));
        {
          V v_field_249 = v_t_248.f[0];
          V v_field_2410 = v_t_248.f[1];
          V v_n_2411 = v_field_249;
          V v_it2_2412 = v_field_2410;
          switch (heff_tag_of(v_it2_2412)) {
          case TAG_SLocal: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SGlobal: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SCode: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SApp: {
            heff_take_n(v_it2_2412, 0ULL, 2);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLam: {
            heff_take_n(v_it2_2412, 0ULL, 2);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SCons: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SProj: {
            heff_take_n(v_it2_2412, 0ULL, 2);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_STag: {
            V v_t_2423 = heff_field(v_it2_2412, 0);
            V v_args_2424 = heff_field(v_it2_2412, 1);
            heff_take_n(v_it2_2412, 3ULL, 2);
            if (heff_intEq_c(v_n_2411, heff_intAdd(v_i_246, heff_dup(v_k_247)))) {
              V v_t_2426 = ({ V a_0 = heff_dup(v_k_247); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_args_2424); V r_ = (g_heff_2eelab_2etoplevel_2eparamsInOrder(a_0, a_1, b_2)); heff_drop(b_2); r_; });
              if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
                heff_drop(v_t_2426);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24it1_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_k_247})}});
              } else {
                heff_drop(v_k_247);
                heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
                heff_drop(v_t_2423);
                heff_drop(v_t_2426);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_k_247);
              heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
              heff_drop(v_t_2423);
              heff_drop(v_args_2424);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_SMatch: {
            heff_take_n(v_it2_2412, 0ULL, 2);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SSpecialize: {
            heff_take_n(v_it2_2412, 0ULL, 3);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SIs: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SOpaque: {
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SAbandon: {
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SRec: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SFix: {
            heff_take_n(v_it2_2412, 0ULL, 2);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SImplicit: {
            heff_take_n(v_it2_2412, 0ULL, 2);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SPrim: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SMetaApp: {
            heff_take_n(v_it2_2412, 0ULL, 3);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitInt: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitFloat: {
            heff_take_na(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitString: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitBytes: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitRune: {
            heff_take_n(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitFixed: {
            heff_take_n(v_it2_2412, 0ULL, 2);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SLitFloat32: {
            heff_take_na(v_it2_2412, 0ULL, 1);
            heff_drop(v_i_246);
            heff_drop(v_k_247);
            heff_drop_cell(v_ru_24it1_245_24MkPair, 2);
            heff_drop(v_n_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it2_2412)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_245)}});
      }
    } else {
      heff_drop_rec(v_ge_240, 4);
      heff_drop(v_field_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_x_241));
    if ((heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_a_243);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_a_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_244));
      v_t_246 = heff_bool(!(heff_dup(v_a_245) == NTAG(TAG_True)));
      heff_drop(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(v_a_247));
        v_t_2410 = heff_bool((heff_dup(v_a_249) == NTAG(TAG_True)));
        heff_drop(v_a_249);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2410);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_a_247 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_245));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_a_247);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_At: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_sp_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_ArgExplicit: {
      V v_c_245 = heff_field(v_x41_243, 0);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0, 2, 5, (V[]){v_t_246, heff_dup(v_c_245), v_start_240, heff_dup(v_sp_244), heff_dup(v_s_241)});
    }
    case TAG_ArgProject: {
      V v_x_2413 = heff_field(v_x41_243, 0);
      heff_drop(v_start_240);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2, 2, 3, (V[]){heff_dup(v_sp_244), heff_dup(v_s_241), heff_dup(v_x_2413)});
    }
    case TAG_ArgNamed: {
      V v_x_2417 = heff_field(v_x41_243, 0);
      V v_c_2418 = heff_field(v_x41_243, 1);
      V v_t_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2418)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3, 2, 5, (V[]){v_t_2419, heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2417)});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = ({ V a_0 = v_c_245; V r_ = (g_heff_2eelab_2etoplevel_2echecksOnly(a_0)); heff_drop(v_c_245); r_; });
  V v_t_2411 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2412 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V a_2 = v_s_241; V a_3 = v_x_249; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); heff_drop(v_s_241); heff_drop(v_x_249); r_; });
  V f_ = v_k_248;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_s_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_246, v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1, 1, 5, (V[]){v_c_245, v_start_240, v_sp_244, v_s_241, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_sp_244 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2414);
  V v_t_2416 = ({ V a_0 = v_sp_244; V a_1 = v_s_241; V a_2 = v_x_2413; V r_ = (g_heff_2eelab_2erules_2erecordElim(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
  V f_ = v_k_2415;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_e_2423 = heff_env(self)[4];
  V v_hd_2426 = heff_env(self)[5];
  V v_k_2427 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_ecallee_2429 = heff_field(v_x_2428, 0);
    V v_a0_2430 = heff_field(v_x_2428, 1);
    heff_take_n(v_x_2428, 3ULL, 2);
    V v_t_2431 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ({ V a_0 = v_t_2431; V a_1 = v_x_2417; V a_2 = v_x_2422; V a_3 = v_e_2423; V a_4 = v_ecallee_2429; V a_5 = v_a0_2430; V a_6 = v_hd_2426; V a_7 = v_k_2427; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2422); r_; });
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_e_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7, 1, 7, (V[]){v_start_240, v_sp_244, v_x_2417, v_x_2422, v_e_2423, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args) {
  V v_e_2423 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2425;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2424 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2425 = heff_tr(heff_call(v_f_2424, 1, (V[]){heff_dup(v_e_2423)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6, 2, 6, (V[]){v_c_2425, v_start_240, v_sp_244, v_x_2417, v_x_2422, v_e_2423});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5, 1, 5, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2417, v_x_2422})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4, 1, 5, (V[]){v_k_2421, v_s_241, v_start_240, v_sp_244, v_x_2417})));
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V v_sp_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_t1_242 = heff_field(v_t_241, 0);
    switch (heff_tag_of(v_t1_242)) {
    case TAG_TPi: {
      V v_c_246 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0, 2, 2, (V[]){v_c_246, v_sp_240});
    }
    case TAG_TSig: {
      V v_fields_2411 = heff_field(v_t1_242, 0);
      V v_c_2412 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(heff_dup(v_fields_2411)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2, 2, 2, (V[]){v_c_2412, v_sp_240});
    }
    case TAG_TSum: {
      V v_c_2418 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4, 2, 2, (V[]){v_c_2418, v_sp_240});
    }
    case TAG_TType: {
      V v_c_2423 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6, 2, 2, (V[]){v_c_2423, v_sp_240});
    }
    case TAG_TInt: {
      V v_c_2428 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8, 2, 2, (V[]){v_c_2428, v_sp_240});
    }
    case TAG_TFloat: {
      V v_c_2433 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10, 2, 2, (V[]){v_c_2433, v_sp_240});
    }
    case TAG_TString: {
      V v_c_2438 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12, 2, 2, (V[]){v_c_2438, v_sp_240});
    }
    case TAG_TRune: {
      V v_c_2443 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14, 2, 2, (V[]){v_c_2443, v_sp_240});
    }
    case TAG_TArray: {
      V v_c_2449 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16, 2, 2, (V[]){v_c_2449, v_sp_240});
    }
    case TAG_TFixed: {
      V v_c_2455 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18, 2, 2, (V[]){v_c_2455, v_sp_240});
    }
    case TAG_TInf: {
      V v_c_2461 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20, 2, 2, (V[]){v_c_2461, v_sp_240});
    }
    case TAG_TChk: {
      V v_c_2467 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22, 2, 2, (V[]){v_c_2467, v_sp_240});
    }
    case TAG_TNominal: {
      V v_c_2473 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24, 2, 2, (V[]){v_c_2473, v_sp_240});
    }
    default: return heff_nomatch(v_t1_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_sp_240; V a_1 = v_x_249; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1, 1, 2, (V[]){v_sp_240, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = (g_heff_2eelab_2erules_2erecordTypeIntro(v_sp_240, v_x_2415));
  V f_ = v_k_2414;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3, 1, 2, (V[]){v_sp_240, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = ({ V a_0 = v_sp_240; V a_1 = v_x_2421; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2421); r_; });
  V f_ = v_k_2420;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5, 1, 2, (V[]){v_sp_240, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = ({ V a_0 = v_sp_240; V a_1 = v_x_2426; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2426); r_; });
  V f_ = v_k_2425;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7, 1, 2, (V[]){v_sp_240, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = ({ V a_0 = v_sp_240; V a_1 = v_x_2431; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2431); r_; });
  V f_ = v_k_2430;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9, 1, 2, (V[]){v_sp_240, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args) {
  V v_x_2436 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = ({ V a_0 = v_sp_240; V a_1 = v_x_2436; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2436); r_; });
  V f_ = v_k_2435;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2433;
  args[0] = v_hd_2434;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11, 1, 2, (V[]){v_sp_240, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args) {
  V v_x_2441 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = ({ V a_0 = v_sp_240; V a_1 = v_x_2441; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2441); r_; });
  V f_ = v_k_2440;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13, 1, 2, (V[]){v_sp_240, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args) {
  V v_x_2446 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = ({ V a_0 = v_sp_240; V a_1 = v_x_2446; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2446); r_; });
  V f_ = v_k_2445;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2443;
  args[0] = v_hd_2444;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15, 1, 2, (V[]){v_sp_240, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args) {
  V v_x_2452 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = ({ V a_0 = v_sp_240; V a_1 = v_x_2452; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2452); r_; });
  V f_ = v_k_2451;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2449;
  args[0] = v_hd_2450;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17, 1, 2, (V[]){v_sp_240, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args) {
  V v_x_2458 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = ({ V a_0 = v_sp_240; V a_1 = v_x_2458; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V f_ = v_k_2457;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19, 1, 2, (V[]){v_sp_240, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args) {
  V v_x_2464 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = ({ V a_0 = v_sp_240; V a_1 = v_x_2464; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2464); r_; });
  V f_ = v_k_2463;
  args[0] = v_t_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2461;
  args[0] = v_hd_2462;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21, 1, 2, (V[]){v_sp_240, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args) {
  V v_x_2470 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471 = ({ V a_0 = v_sp_240; V a_1 = v_x_2470; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2470); r_; });
  V f_ = v_k_2469;
  args[0] = v_t_2471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_c_2467 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2467;
  args[0] = v_hd_2468;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23, 1, 2, (V[]){v_sp_240, v_k_2469});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args) {
  V v_x_2476 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477 = ({ V a_0 = v_sp_240; V a_1 = v_x_2476; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2476); r_; });
  V f_ = v_k_2475;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_c_2473 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2473;
  args[0] = v_hd_2474;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25, 1, 2, (V[]){v_sp_240, v_k_2475});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1, 2, 2, (V[]){v_t_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_t_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_245, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247})));
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0, 45, "unexpected notation for variant in a sum type");
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 5ULL, 3);
      heff_drop(v_x22_242);
      V v_c_246 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s579110916x1535220277(v_args_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0, 2, 2, (V[]){v_c_246, v_x_243});
    }
    case TAG_BadVariant: {
      heff_take_n(v_x21_241, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2, 2, 1, (V[]){v_x22_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(a[0]);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, heff_arrayFromList(v_x_249)});
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1, 1, 2, (V[]){v_x_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8, 3, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TPi: {
      V v_b_243 = heff_field(v_x21_241, 0);
      V v_codN_244 = heff_field(v_x21_241, 1);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(heff_dup(v_b_243)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0, 2, 2, (V[]){v_c_245, heff_dup(v_codN_244)});
    }
    case TAG_TSig: {
      V v_fields_2412 = heff_field(v_x21_241, 0);
      V v_c_2413 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(heff_dup(v_fields_2412)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3, 2, 1, (V[]){v_c_2413});
    }
    case TAG_TSum: {
      V v_variantNs_2418 = heff_field(v_x21_241, 0);
      V v_c_2419 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(heff_dup(v_variantNs_2418)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5, 2, 1, (V[]){v_c_2419});
    }
    case TAG_TType: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7_clo);
    }
    case TAG_TInt: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo);
    }
    case TAG_TFloat: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo);
    }
    case TAG_TString: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo);
    }
    case TAG_TRune: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo);
    }
    case TAG_TArray: {
      V v_a0_2444 = heff_field(v_x21_241, 0);
      V v_c_2445 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_a0_2444));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14, 2, 1, (V[]){v_c_2445});
    }
    case TAG_TFixed: {
      V v_w_2450 = heff_field(v_x21_241, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16, 2, 1, (V[]){heff_dup(v_w_2450)});
    }
    case TAG_TInf: {
      V v_i_2458 = heff_field(v_x21_241, 0);
      V v_c_2459 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_2458)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19, 2, 2, (V[]){v_c_2459, heff_dup(v_x22_242)});
    }
    case TAG_TChk: {
      V v_ch_2464 = heff_field(v_x21_241, 0);
      V v_c_2465 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_ch_2464)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21, 2, 1, (V[]){v_c_2465});
    }
    case TAG_TNominal: {
      V v_t_2477 = heff_field(v_x21_241, 0);
      V v_c_2478 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2477));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26, 2, 1, (V[]){v_c_2478});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = ({ V a_0 = v_x_248; V a_1 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_k_247;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_codN_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = ({ V a_0 = v_codN_244; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_codN_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_codN_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1, 1, 3, (V[]){v_codN_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2eelab_2erules_2erecordFormation(v_x_2416));
  V f_ = v_k_2415;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2422)));
  V v_t_2424 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2422));
  V v_t_2425 = (g_list_2emap_24s1173914895x100384474(v_x_2422));
  V v_t_2426 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2423), v_t_2424, heff_arrayFromList(v_t_2425)});
  V v_x_2427 = (g_heff_2eelab_2erules_2esumFormation(v_t_2426));
  V f_ = v_k_2421;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6, 1, 1, (V[]){v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args) {
  V v_u2_2434 = args[0];
  heff_drop(v_u2_2434);
  V v_t_2435 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2435});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args) {
  V v_e_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  heff_drop(v_e_2430);
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
  V f_ = v_k_2432;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2433, ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = ({ V a_0 = v_x_2448; V r_ = (g_heff_2eelab_2erules_2eprimArray(a_0)); heff_drop(v_x_2448); r_; });
  V f_ = v_k_2447;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15, 1, 1, (V[]){v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args) {
  V v_u_2456 = args[0];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2450})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args) {
  V v_e_2453 = args[0];
  V v_hd_2454 = args[1];
  V v_k_2455 = args[2];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2453);
  heff_drop(v_hd_2454);
  V v_t_2457 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){heff_dup(v_w_2450)}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18, 1, 1, (V[]){v_w_2450})});
  V f_ = v_k_2455;
  args[0] = v_t_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17, 3, 1, (V[]){v_w_2450})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x22_242 = heff_env(self)[0];
  V v_k_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = ({ V a_0 = v_x22_242; V a_1 = v_x_2462; V r_ = (g_heff_2eelab_2erules_2euniverseElimSyn(a_0, a_1)); heff_drop(v_x_2462); r_; });
  V f_ = v_k_2461;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_c_2459 = heff_env(self)[0];
  V v_x22_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2459;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20, 1, 2, (V[]){v_x22_242, v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args) {
  V v_x_2475 = args[0];
  V v_k_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = (g_heff_2eelab_2ememoed_2edecode(v_x_2475));
  V f_ = v_k_2474;
  args[0] = v_t_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_c_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2472;
  args[0] = v_hd_2473;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25, 1, 1, (V[]){v_k_2474});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args) {
  V v_e_2469 = args[0];
  V v_x_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2472;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_MkChk: {
    V v_f_2470 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24MkChk = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    V v_t_2471 = heff_tag_at_n(v_ru_24x_2468_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
    v_c_2472 = heff_tr(heff_call(v_f_2470, 2, (V[]){v_e_2469, v_t_2471}));
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24, 2, 1, (V[]){v_c_2472});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2467;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23, 1, 1, (V[]){v_x_2468})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2465;
  args[0] = v_hd_2466;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22, 1, 1, (V[]){v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args) {
  V v_x_2481 = args[0];
  V v_k_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2482 = ({ V a_0 = v_x_2481; V r_ = (g_heff_2eelab_2etoplevel_2enominalTyp(a_0)); heff_drop(v_x_2481); r_; });
  V f_ = v_k_2480;
  args[0] = v_t_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_c_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2478;
  args[0] = v_hd_2479;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27, 1, 1, (V[]){v_k_2480});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithOne(V v_ab_240, V v_x2_241) {
top: ;
  V v_t_242 = heff_take_field(v_ab_240, 3);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Expl: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_243 = heff_field(v_x2_241, 0);
      V v_c_244 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_245 = heff_tag_n(TAG_Named, 2, (V[]){heff_dup(heff_rfield(v_ab_240, 1)), heff_take_field(v_ab_240, 2)});
      V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_t_243; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_243); r_; });
      V v_t_247 = ({ V a_0 = heff_take_field(v_ab_240, 0); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_244; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_c_244); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_246, v_t_247});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Impl: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_248 = heff_field(v_x2_241, 0);
      V v_c_249 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_2410 = heff_tag_n(TAG_NamedImplicit, 4, (V[]){heff_dup(heff_rfield(v_ab_240, 0)), heff_dup(heff_rfield(v_ab_240, 1)), heff_take_field(v_ab_240, 2), NTAG(TAG_Nothing)});
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_t_248; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_t_2412 = ({ V a_0 = heff_take_field(v_ab_240, 0); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_249; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_249); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_t_2412});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Inst: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_2413 = heff_field(v_x2_241, 0);
      V v_c_2414 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_2415 = heff_tag_n(TAG_NamedInstance, 3, (V[]){heff_dup(heff_rfield(v_ab_240, 0)), heff_dup(heff_rfield(v_ab_240, 1)), heff_take_field(v_ab_240, 2)});
      V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2413); r_; });
      V v_t_2417 = ({ V a_0 = heff_take_field(v_ab_240, 0); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_2414; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2414); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2416, v_t_2417});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithOne(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edefineD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edefineD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2edefineD(V v_name_240, V v_params_241, V v_tyN_242, V v_bodyN_243) {
top: ;
  V v_c_244 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(v_params_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam0, 2, 4, (V[]){v_c_244, heff_dup(v_tyN_242), heff_dup(v_bodyN_243), v_name_240});
}
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2edefineD(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2418 = ({ V a_0 = v_x_247; V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, v_x_2417}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_247); r_; });
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_ty_2419 = heff_field(v_x2_2418, 0);
    V v_tm_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2419, v_tm_2420, NTAG(TAG_False)});
    V f_ = v_k_246;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_bodyN_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2415;
  switch (heff_tag_of(v_bodyN_243)) {
  case TAG_At: {
    V v_n_2413 = heff_field(v_bodyN_243, 0);
    V v_sp_2414 = heff_field(v_bodyN_243, 1);
    heff_take_n(v_bodyN_243, 3ULL, 2);
    v_n_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
    break;
  }
  default: heff_nomatch(v_bodyN_243);
  }
  V v_c_2416 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2415));
  V f_ = v_c_2416;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam3, 1, 4, (V[]){v_x_247, v_x_2412, v_name_240, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_tyN_242 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2410;
  switch (heff_tag_of(v_tyN_242)) {
  case TAG_At: {
    V v_n_248 = heff_field(v_tyN_242, 0);
    V v_sp_249 = heff_field(v_tyN_242, 1);
    heff_take_n(v_tyN_242, 3ULL, 2);
    v_n_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_249, v_n_248));
    break;
  }
  default: heff_nomatch(v_tyN_242);
  }
  V v_c_2411 = ({ V a_0 = v_n_2410; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2410); r_; });
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam2, 1, 5, (V[]){v_bodyN_243, v_hd_245, v_x_247, v_name_240, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_tyN_242 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam1, 1, 5, (V[]){v_tyN_242, v_hd_245, v_bodyN_243, v_name_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epoisonedLeft_str0, 54, "an implicit argument an error kept from being inferred");
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2epoisonedLeft(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epoisonedLeft(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 2, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args) {
  V v_m_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = v_x_2411; HeffT2 r_ = (g_map_2elookup_24s567992785x1569911877_24cpr(a_0, a_1)); heff_drop(v_x_2411); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_me_2419 = v_field_2417;
      V v_t_2420 = heff_get_n(v_me_2419, 1, 6);
      switch (heff_tag_of(v_t_2420)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_t_2420, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2420);
      }
    } else {
      heff_drop(v_field_2417);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = ({ V a_0 = v_x_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_t_2413 = (g_list_2emap_24s1415906091x1371825187(v_t_2412));
  V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4, 1, 1, (V[]){v_x_2411}); V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2413); r_; });
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_t_2422);
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop_rec(v_hd_240, 3);
    heff_drop(v_t_2422);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2eappendM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendM(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2etoplevel_2eappendM_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendM_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2etoplevel_2espineVals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2espineVals_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2espineVals(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_e_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_241));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_e_242, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_243, v_t_244));
  }
  case TAG_SpProj: {
    V v_sp_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V t_0 = v_sp_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_247 = heff_field(v_x1_240, 0);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    V v_t_2410 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_247));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2espineVals(a[0]);
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2emetasInV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emetasInV_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2emetasInV(V v_mc_240, V v_v_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_t_242, 0);
    V v_sp_244 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_h_243, 0);
      heff_take_n(v_h_243, 1ULL, 1);
      v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_HError: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_244));
    V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2emetasInV_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2etoplevel_2econcatMapM(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_2411, v_t_2414);
  }
  case TAG_VCode: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VLam: {
    heff_take_n(v_t_242, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_VCons: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2emetasInV(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args) {
  V v_v2_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_mc_240; V a_1 = v_v2_2413; V r_ = (g_heff_2eelab_2etoplevel_2emetasInV(a_0, a_1)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eshownV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eshownV_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_243));
  V v_e_245 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_take_field(v_cs_242, 0), v_t_244));
  V v_t_2414 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2etoplevel_2eshownV_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 0, 2), 1, (V[]){v_e_245}));
  HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_242, 1, 2), v_e_2415);
}
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eshownV(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_247 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_246)));
  V v_t_248 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_249 = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(v_t_248, v_x_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_d_247);
      V v_x_2413 = v_field_2411;
      return v_x_2413;
    } else {
      heff_drop(v_field_2411);
      return v_d_247;
    }
  }
}
Clo g_heff_2eelab_2etoplevel_2estuckAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_245 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 2))));
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245));
  V v_x1_247 = (g_heff_2eelab_2etoplevel_2enubInt(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = (g_map_2elookup_24s567992785x1569911877(v_x_248, v_mc_243));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2411 = (g_heff_2eelab_2etoplevel_2eshownV(heff_dup(v_g_240), v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_2412 = (g_heff_2eelab_2etoplevel_2eshownV(v_g_240, v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 2))));
  return (g_heff_2eelab_2etoplevel_2estuckWith(v_fallback_241, v_p_242, v_t_2410, v_t_2411, v_t_2412));
}
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2estuckAt(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eentryFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eentryFor_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244) {
top: ;
  V v_t_2414;
  if ((heff_dup(v_prim_242) == NTAG(TAG_True))) {
    v_t_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eentryFor_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_243)}), NTAG(TAG_Nothing)));
  } else {
    v_t_2414 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), v_k_241, heff_dup(v_tyStx_243), heff_dup(v_bodyStx_244)));
  }
  HeffT2 v_t_2415 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
  V v_t_2423;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      v_t_2423 = v_x_2419;
    } else {
      if ((v_tag_2416 == ((int64_t)1ULL))) {
        V v_x11_2421 = v_field_2417;
        heff_drop(v_x11_2421);
        v_t_2423 = heff_abandon();
      } else {
        V v_x_2422 = v_field_2417;
        v_t_2423 = v_x_2422;
      }
    }
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_244, v_tyStx_243, v_t_2414, v_t_2423});
}
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eentryFor(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_245);
  HeffT2 v_t_246 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_tyStx_243, NTAG(TAG_LNil)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_248;
      return v_x_2410;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2412 = v_field_248;
        heff_drop(v_x11_2412);
        return heff_abandon();
      } else {
        V v_x_2413 = v_field_248;
        return v_x_2413;
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2echeckStuck(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){v_t_249}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2echeckStuck_lam1, 1, 5, (V[]){v_g_240, v_sp_241, heff_dup(v_p_245), v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2echeckStuck(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2412 = ({ V a_0 = v_g_240; V a_1 = v_sp_241; V a_2 = v_p_245; V a_3 = v_x_2411; V r_ = (g_heff_2eelab_2etoplevel_2estuckAt(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_x_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2414}));
  V f_ = heff_get_n(v_p_243, 1, 3);
  heff_room[0] = v_t_2415;
  heff_room[1] = v_p_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efailedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efailedAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2efailedAt(V v_aval_240, V v_d_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2eelab_2emeta_2eblockedTy(v_aval_240, heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2etoplevel_2efailedAt_lam0, 1, 3, (V[]){v_d_241, v_hd_242, v_k_243})));
}
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2efailedAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245;
  if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    v_t_245 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_d_241, 30ULL, 5, shape_code__severity__msg__span__note, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_x_244);
    v_t_245 = v_d_241;
  }
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_247}));
  V f_ = heff_get_n(v_hd_242, 1, 3);
  heff_room[0] = v_t_248;
  heff_room[1] = v_k_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_entry, 7, 0};

V g_heff_2eelab_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_248;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    v_t_248 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_247);
    v_t_248 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_k_249 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam0, 1, 1, (V[]){v_k_249})})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam1, 1, 7, (V[]){v_z_245, heff_dup(v_n_242), v_d_243, v_key_240, v_a_244, v_g_241, v_z_246})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabBody(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_249; V rr_ = heff_rec_reuse_nf(v_c_2410, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args) {
  V v_u_2427 = args[0];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2427);
  V v_x1_2428 = heff_tr(heff_call(heff_get_n(v_a_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_Nom: {
    V v_x_2429 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    return v_x_2429;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2431 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    return v_x_2431;
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args) {
  V v_c_2452 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_2452, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args) {
  V v_c_2466 = args[0];
  return heff_get_n(v_c_2466, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args) {
  V v_x_2470 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_body_2449 = heff_env(self)[5];
  V v_hd_2450 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2496;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2471 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_DeclEquations: {
      V v_x113_2475 = heff_field(v_x11_2471, 2);
      V v_tyN_2476 = heff_field(v_x11_2471, 3);
      heff_take_n(v_x11_2471, 12ULL, 5);
      switch (heff_tag_of(v_x113_2475)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2476);
        v_t_2496 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2480;
        switch (heff_tag_of(v_tyN_2476)) {
        case TAG_At: {
          V v_s_2479 = heff_field(v_tyN_2476, 1);
          heff_take_n(v_tyN_2476, 2ULL, 2);
          v_t_2480 = v_s_2479;
          break;
        }
        default: heff_nomatch(v_tyN_2476);
        }
        v_t_2496 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2480});
        break;
      }
      default: heff_nomatch(v_x113_2475);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2471, 0ULL, 5);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2471, 0ULL, 4);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2471, 0ULL, 3);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2471, 0ULL, 2);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2471, 0ULL, 1);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2471);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2498;
  switch (heff_tag_of(v_t_2496)) {
  case TAG_Nothing: {
    v_t_2498 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2496, 0ULL, 1);
    v_t_2498 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2496);
  }
  V v_t_2499 = (g_heff_2eelab_2eunify_2ezonker(v_x_2470));
  V v_t_24100 = heff_tr(heff_call(heff_get_n(v_t_2499, 1, 2), 1, (V[]){heff_get_n(v_a_244, 0, 2)}));
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_d_243; V a_3 = v_t_2498; V a_4 = v_t_24100; V a_5 = v_x_2470; V a_6 = v_body_2449; V a_7 = v_hd_2450; V a_8 = v_k_2451; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2470); heff_drop_rec(v_hd_2450, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2465);
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo)})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){v_t_2468}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  heff_room[0] = v_t_2469;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam10, 1, 8, (V[]){v_n_242, v_a_244, v_key_240, v_g_241, v_d_243, v_body_2449, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args) {
  V v_x_2460 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_hd_2450 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2460);
  V v_t_2463;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2462 = heff_dup(heff_field(v_n_242, 1));
    v_t_2463 = v_s_2462;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2464 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2463, heff_dup(v_d_243)));
  V f_ = v_c_2464;
  heff_room[0] = heff_dup(v_hd_2450);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam8, 1, 8, (V[]){v_hd_2450, v_n_242, v_a_244, v_key_240, v_g_241, v_d_243, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2457 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2456, NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  heff_room[0] = v_t_2459;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam7, 1, 8, (V[]){v_n_242, v_d_243, v_hd_2450, v_a_244, v_key_240, v_g_241, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args) {
  V v_body_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo)})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){v_t_2454}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  args[0] = v_t_2455;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam6, 1, 8, (V[]){v_hd_2450, v_n_242, v_d_243, v_a_244, v_key_240, v_g_241, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2418);
  V v_t_2421;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2420 = heff_dup(heff_field(v_n_242, 1));
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2422 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2423;
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_t_2422);
    v_t_2423 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2422);
    v_t_2423 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_t_2424 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2425;
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_t_2424);
    v_t_2425 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2424);
    v_t_2425 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_h_2426 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2425});
  V v_t_2432 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2426, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam3, 1, 1, (V[]){heff_dup(v_a_244)}), NTAG(TAG_Nothing)));
  V v_x1_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2437;
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_Nom: {
    V v_x_2434 = heff_field(v_x1_2433, 0);
    heff_take_n(v_x1_2433, 1ULL, 1);
    v_t_2437 = v_x_2434;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2437 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2436 = heff_field(v_x1_2433, 0);
    heff_take_n(v_x1_2433, 1ULL, 1);
    v_t_2437 = v_x_2436;
    break;
  }
  default: heff_nomatch(v_x1_2433);
  }
  V v_t_2438 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_244, 0)), v_t_2432, v_t_2437});
  V v_t_2439 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2423, v_t_2438, heff_dup(v_g_241)));
  V v_t_2440 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2441;
  if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
    heff_drop(v_t_2440);
    v_t_2441 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2440);
    v_t_2441 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_x1_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nom: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2443;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2442, 0ULL, 1);
    v_t_2446 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2445 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_t_2447 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2421, heff_dup(v_d_243), v_t_2439, v_t_2441, v_t_2446));
  V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2447}));
  return (g_co_2ebind_24s441514442x2097556756(v_t_2448, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam4, 3, 5, (V[]){v_n_242, v_d_243, v_a_244, v_key_240, v_g_241}), v_z_245, v_z_246));
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam2, 1, 7, (V[]){v_n_242, v_d_243, v_key_240, v_a_244, v_g_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_244 = heff_field(v_n_242, 0);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_DeclEquations: {
      V v_f_246 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_246)});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2411 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2411)});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2416 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2420 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2420)});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2423 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2423)});
      break;
    }
    case TAG_DeclWatch: {
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    return ({ V rv_1 = v_diags_243; V rr_ = heff_rec_reuse_nf(v_acc_241, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_k_2428 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_t_2429 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_g_2435;
    if (heff_strEq_c_lent(v_t_2429, v_x_2427, 1)) {
      v_g_2435 = heff_dup(heff_rfield(v_acc_241, 0));
    } else {
      V v_k_2431 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
      V v_g_2432 = heff_dup(heff_rfield(v_acc_241, 0));
      V v_t_2433 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_x_2427), heff_take_field(v_g_2432, 4)));
      V v_t_2434 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2427), v_k_2431, heff_take_field(v_g_2432, 2)));
      v_g_2435 = ({ V rv_2 = v_t_2434; V rv_4 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_g_2432, 107ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 15567u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
    }
    V v_t_2436 = (g_map_2einsert_24s1341440536x470972936(v_k_2428, NTAG(TAG_MkUnit), heff_take_field(v_g_2435, 3)));
    V v_t_2437 = ({ V rv_3 = v_t_2436; V rr_ = heff_rec_reuse_nf(v_g_2435, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_globals_2438 = (g_heff_2eelab_2etoplevel_2ewithBrokenInstance(v_kf_240, v_n_242, v_t_2437));
    V v_t_2441;
    switch (heff_tag_of(v_n_242)) {
    case TAG_At: {
      V v_s_2440 = heff_field(v_n_242, 1);
      v_t_2441 = heff_dup(v_s_2440);
      break;
    }
    default: heff_nomatch(v_n_242);
    }
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_t_2441}), heff_take_field(v_acc_241, 3)});
    return ({ V rv_0 = v_globals_2438; V rv_1 = v_diags_243; V rv_3 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_acc_241, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 261936u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etopBroken(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ekeepSt_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_242 = heff_field(v_st_240, 0);
    v_t_245 = heff_dup(v_c_242);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_infos_246 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_245, 0, 8), heff_take_field(v_acc_241, 7)));
  V v_t_2410;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_247 = heff_field(v_st_240, 0);
    v_t_2410 = heff_dup(v_c_247);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_trace_2411 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2410, 6, 8), heff_take_field(v_acc_241, 8)));
  return ({ V rv_7 = v_infos_246; V rv_8 = v_trace_2411; V rr_ = heff_rec_reuse_nf(v_acc_241, 127ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ekeepSt(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etopOne_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_lam0, 2, 0};
Clo g_heff_2eelab_2etoplevel_2etopOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_n1_243 = heff_dup(heff_field(v_n_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_n_242, 1));
    switch (heff_tag_of(v_n1_243)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_243, 0ULL, 5);
      heff_drop(v_sp_244);
      V v_t_2410 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2410; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_243, 0ULL, 5);
      heff_drop(v_sp_244);
      V v_t_2416 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2416; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_243, 0ULL, 4);
      heff_drop(v_sp_244);
      V v_t_2421 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2421; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_243, 0ULL, 3);
      heff_drop(v_sp_244);
      V v_t_2425 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2425; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTest: {
      V v_x_2426 = heff_field(v_n1_243, 0);
      V v_ru_24n1_243_24DeclTest = heff_take_reuse_n(v_n1_243, 1ULL, 2);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_t_2428 = heff_tag_at_n(v_ru_24n1_243_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2426, v_sp_244}), heff_dup(heff_rfield(v_acc_241, 5))});
      return ({ V rv_5 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_acc_241, 479ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_DeclWatch: {
      V v_e_2429 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_m_2430 = (g_heff_2eelab_2etoplevel_2eelabWatch(heff_dup(heff_rfield(v_acc_241, 0)), v_e_2429));
      V v_t_2433 = heff_tr(heff_call(v_m_2430, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2etopOne_lam0_clo), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())}));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_241, v_sp_244, v_t_2433);
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_2432 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2431}), v_st_2432});
}
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(V v_lit_240, V v_lit_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    V v_diags_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 1)));
    V v_keys_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 2)));
    V v_broken_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 3)));
    V v_watches_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 4)));
    V v_tests_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 5)));
    V v_spans_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 6)));
    V v_infos_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 7)));
    V v_trace_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 8)));
    return ({ V rv_1 = v_diags_244; V rv_2 = v_keys_245; V rv_3 = v_broken_246; V rv_4 = v_watches_247; V rv_5 = v_tests_248; V rv_6 = v_spans_249; V rv_7 = v_infos_2410; V rv_8 = v_trace_2411; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2412 = heff_field(v_x3_243, 0);
    V v_rest_2413 = heff_field(v_x3_243, 1);
    V v_t_2415 = (g_heff_2eelab_2etoplevel_2etopOne(heff_clo_n(g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_lam0, 1, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_acc_242, heff_dup(v_n_2412)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2415;
    V t_3 = v_rest_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_acc_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_lam0(V self, V *args) {
  V v_a_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_strAppend(v_lit_240, heff_strAppend(v_lit_241, v_a_2414));
}
Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V v_acc_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_st_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_244, heff_dup(v_acc_240)));
      V v_t_2410;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_247 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2410 = v_c_247;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2410, 1, 8)));
      V v_t_2412 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2411));
      V v_t_2414;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_rec(v_d_245, 5);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2415 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_240, 1, 9), v_t_2412, v_t_2414));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(v_t_246, v_n_241, v_t_2415);
    }
    case TAG_Right: {
      V v_r_2416 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_x_2417 = heff_dup(heff_rfield(v_r_2416, 0));
      V v_g_2418 = heff_take_field(v_acc_240, 0);
      V v_t_2419 = heff_take_field(v_r_2416, 2);
      V v_g_2425;
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        HeffT2 v_t_2420 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(heff_rfield(v_r_2416, 1)), heff_rfield(v_g_2418, 1)));
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_e_2424 = v_field_2422;
            heff_drop(v_e_2424);
            v_g_2425 = v_g_2418;
          } else {
            heff_drop(v_field_2422);
            v_g_2425 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2416, 1)), heff_dup(heff_rfield(v_r_2416, 4)), v_g_2418));
          }
        }
      } else {
        heff_drop(v_t_2419);
        v_g_2425 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2416, 1)), heff_dup(heff_rfield(v_r_2416, 4)), v_g_2418));
      }
      V v_t_2426 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_x_2417), heff_take_field(v_g_2425, 4)));
      V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_x_2417, heff_dup(heff_rfield(v_r_2416, 1)), heff_take_field(v_g_2425, 2)));
      V v_t_2428 = ({ V rv_2 = v_t_2427; V rv_4 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_g_2425, 107ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 15567u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_globals_2429 = (g_heff_2eelab_2etoplevel_2ewithInstance(heff_rfield(v_r_2416, 3), heff_dup(heff_rfield(v_r_2416, 1)), heff_dup(heff_rfield(v_r_2416, 0)), v_t_2428));
      V v_t_2433;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2430 = heff_dup(heff_field(v_st_244, 0));
        v_t_2433 = v_c_2430;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2433, 1, 8)));
      V v_t_2435 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2434));
      V v_t_2436 = heff_take_field(v_r_2416, 5);
      V v_t_2439;
      switch (heff_tag_of(v_t_2436)) {
      case TAG_Nothing: {
        v_t_2439 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2437 = heff_field(v_t_2436, 0);
        heff_take_n(v_t_2436, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2437, 0)), MK_INT(-1LL))) {
          heff_drop_rec(v_d_2437, 5);
          v_t_2439 = NTAG(TAG_Nil);
        } else {
          v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2437, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      V v_diags_2440 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_240, 1), v_t_2435, v_t_2439));
      V v_t_2444;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2441 = heff_dup(heff_field(v_st_244, 0));
        v_t_2444 = v_c_2441;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2445 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2444, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2449;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2446 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2449 = v_c_2446;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2450 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2449, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_2416, 1), heff_take_field(v_acc_240, 2)});
      V v_t_2454;
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_s_2453 = heff_field(v_n_241, 1);
        v_t_2454 = heff_dup(v_s_2453);
        break;
      }
      default: heff_nomatch(v_n_241);
      }
      V v_t_2455 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_r_2416, 0, 6), v_t_2454});
      V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, heff_take_field(v_acc_240, 6)});
      return ({ V rv_0 = v_globals_2429; V rv_1 = v_diags_2440; V rv_2 = v_t_2451; V rv_6 = v_t_2456; V rv_7 = v_infos_2445; V rv_8 = v_trace_2450; V rr_ = heff_rec_reuse_nf(v_acc_240, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 4032u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry, 8, 0};

V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V v_g_240, V v_d_241, V v_isInstance_242, V v_tyStx_243, V v_mc_244, V v_x7_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Left: {
    V v_failed_248 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    HeffT2 v_t_249 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
    V v_t_2419;
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_a_2417;
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2411;
        v_a_2417 = v_x_2413;
      } else {
        if ((v_tag_2410 == ((int64_t)1ULL))) {
          V v_x11_2415 = v_field_2411;
          heff_drop(v_x11_2415);
          v_a_2417 = heff_abandon();
        } else {
          V v_x_2416 = v_field_2411;
          v_a_2417 = v_x_2416;
        }
      }
      v_t_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0, 1, 1, (V[]){v_a_2417}), NTAG(TAG_Nothing)));
    }
    HeffT2 v_t_2420 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
    V v_t_2428;
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2424 = v_field_2422;
        v_t_2428 = v_x_2424;
      } else {
        if ((v_tag_2421 == ((int64_t)1ULL))) {
          V v_x11_2426 = v_field_2422;
          heff_drop(v_x11_2426);
          v_t_2428 = heff_abandon();
        } else {
          V v_x_2427 = v_field_2422;
          v_t_2428 = v_x_2427;
        }
      }
    }
    V v_entry_2429 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_243, v_t_2419, v_t_2428});
    V v_t_2430 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_2431;
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      v_t_2431 = heff_dup(heff_rfield(v_d_241, 0));
    } else {
      heff_drop(v_t_2430);
      v_t_2431 = heff_dup(heff_rfield(v_d_241, 0));
    }
    V v_t_2432 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_241, 0), v_t_2431, heff_get_n(v_d_241, 3, 4), v_isInstance_242, v_entry_2429, heff_tag_n(TAG_Just, 1, (V[]){v_failed_248})});
    return heff_tail(v_z_247, 1, (V[]){v_t_2432});
  }
  case TAG_Right: {
    V v_t_2433 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_t_2434 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_2435;
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_t_2434);
      v_t_2435 = heff_dup(heff_rfield(v_d_241, 0));
    } else {
      heff_drop(v_t_2434);
      v_t_2435 = heff_dup(heff_rfield(v_d_241, 0));
    }
    V v_t_2436 = (g_heff_2eelab_2eunify_2ezonker(v_mc_244));
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_t_2436, 0, 2), 1, (V[]){heff_get_n(v_t_2433, 0, 2)}));
    V v_t_2438 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_2439;
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      v_t_2439 = heff_dup(heff_rfield(v_d_241, 0));
    } else {
      heff_drop(v_t_2438);
      v_t_2439 = heff_dup(heff_rfield(v_d_241, 0));
    }
    V v_t_2440 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_t_2439));
    V v_t_2441 = heff_tr(heff_call(heff_get_n(v_t_2440, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2437}));
    V v_entry_2442 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_240, v_t_2435, heff_rfield(v_d_241, 3), v_tyStx_243, v_t_2441));
    V v_t_2443 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_2444;
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      v_t_2444 = heff_dup(heff_rfield(v_d_241, 0));
    } else {
      heff_drop(v_t_2443);
      v_t_2444 = heff_dup(heff_rfield(v_d_241, 0));
    }
    V v_t_2445 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_241, 0), v_t_2444, heff_get_n(v_d_241, 3, 4), v_isInstance_242, v_entry_2442, NTAG(TAG_Nothing)});
    return heff_tail(v_z_247, 1, (V[]){v_t_2445});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a[0], a[1], a[2], a[3], a4, a[5], a6, a[7]); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args) {
  V v_u_2418 = args[0];
  V v_a_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_a_2417;
}
Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawGlobals_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawGlobals(V v_acc_240, V v_d_241) {
top: ;
  V v_x_242 = heff_dup(heff_rfield(v_d_241, 0));
  V v_t_243 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 5)));
  V v_t_244 = ({ V a_0 = heff_dup(heff_rfield(v_acc_240, 0)); V a_1 = heff_dup(heff_rfield(v_d_241, 1)); V a_2 = v_t_243; V a_3 = heff_take_field(v_d_241, 4); V a_4 = heff_take_field(v_d_241, 5); V r_ = (g_heff_2eelab_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_243); r_; });
  V v_g_245 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_d_241, 1)), v_t_244, heff_get_n(v_acc_240, 0, 9)));
  V v_t_246 = (g_map_2edelete_24s805420727x38051515(heff_dup(v_x_242), heff_take_field(v_g_245, 4)));
  V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_x_242, heff_dup(heff_rfield(v_d_241, 1)), heff_take_field(v_g_245, 2)));
  V v_t_248 = ({ V rv_2 = v_t_247; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_g_245, 107ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 15567u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
  return ({ V b_0 = heff_dup(heff_rfield(v_d_241, 2)); V a_1 = heff_dup(heff_rfield(v_d_241, 1)); V a_2 = heff_get_n(v_d_241, 0, 6); V a_3 = v_t_248; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawGlobals(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyDump_str0, 20, "<no such definition>");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyDump_str1, 20, "<no such definition>");
Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ebodyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  HeffT2 v_t_243 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_k_241);
      heff_drop_rec(v_g_242, 7);
      V v_e_247 = v_field_245;
      return ({ V b_0 = heff_get_n(v_e_247, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_248 = (g_map_2elookup_24s1546226666x2146984184_24cpr(v_k_241, heff_rfield(v_g_242, 2)));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_k2_2412 = v_field_2410;
          HeffT2 v_t_2413 = ({ V a_0 = v_k2_2412; V b_1 = heff_get_n(v_g_242, 1, 7); HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_e_2417 = v_field_2415;
              return ({ V b_0 = heff_get_n(v_e_2417, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
            } else {
              heff_drop(v_field_2415);
              return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str0);
            }
          }
        } else {
          heff_drop_rec(v_g_242, 7);
          heff_drop(v_field_2410);
          return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str1);
        }
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyDump(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etyDump_str0, 20, "<no such definition>");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etyDump_str1, 20, "<no such definition>");
Clo g_heff_2eelab_2etoplevel_2etyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  HeffT2 v_t_243 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_k_241);
      heff_drop_rec(v_g_242, 7);
      V v_e_247 = v_field_245;
      return ({ V b_0 = heff_get_n(v_e_247, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_248 = (g_map_2elookup_24s1546226666x2146984184_24cpr(v_k_241, heff_rfield(v_g_242, 2)));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_k2_2412 = v_field_2410;
          HeffT2 v_t_2413 = ({ V a_0 = v_k2_2412; V b_1 = heff_get_n(v_g_242, 1, 7); HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_e_2417 = v_field_2415;
              return ({ V b_0 = heff_get_n(v_e_2417, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
            } else {
              heff_drop(v_field_2415);
              return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str0);
            }
          }
        } else {
          heff_drop_rec(v_g_242, 7);
          heff_drop(v_field_2410);
          return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str1);
        }
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etyDump(a[0], a[1]);
}