// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588 6711
#define TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009 47022
#define TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422 47314
#define TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054 60739
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntNum 31256
#define TAG_IsCheckable 22614
#define TAG_LNil 57394
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SIs 29577
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SOpaque 44226
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpId 35501
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_hidden 729654485
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_right 309870134
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntroSyn(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo;
V g_heff_2eelab_2erules_2elazySyn(V, V);
V g_heff_2eelab_2erules_2elazySyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazySyn_clo;
V g_heff_2eelab_2erules_2elitBytes(V, V);
V g_heff_2eelab_2erules_2elitBytes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitBytes_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2enumLitSyn(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordFormation(V);
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordFormation_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2erecordTypeIntro(V, V);
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo;
V g_heff_2eelab_2erules_2erecordUpdate(V, V, V, V);
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordUpdate_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2etupleSyn(V, V, V, V);
V g_heff_2eelab_2erules_2etupleSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etupleSyn_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2efailedAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efailedAt_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo;
V g_heff_2eelab_2etoplevel_2emetasInV(V, V);
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2emetasInV_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn(V);
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo;
V g_heff_2eelab_2etoplevel_2enominalTyp(V);
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
V g_heff_2eelab_2etoplevel_2epairOfHoles(V);
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2eshownV(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eshownV_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24tok1(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24tok1_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo;
V g_heff_2eelab_2etoplevel_2etupleTypeRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleTypeRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleTypeRev_clo;
V g_heff_2eelab_2etoplevel_2etupleValueRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2edecodeEv(V);
V g_heff_2eelab_2evalue_2edecodeEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeEv_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2etraverse_24s2094958103x549422471(V);
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2094958103x549422471_clo;
V g_prelude_2etraverse_24s390133767x1613463851(V);
V g_prelude_2etraverse_24s390133767x1613463851_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s390133767x1613463851_clo;
V g_prelude_2etraverse_24s515579549x140669784(V);
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s515579549x140669784_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2emap_2elookup_24s1702756637x1169753568(V, V);
V g_std_2emap_2elookup_24s1702756637x1169753568_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1702756637x1169753568_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalSyn(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args) {
  V v_u_2417 = args[0];
  V v_val_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  V v_x1_2418 = heff_tr(heff_call(v_val_2416, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_t_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2422});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_res_2413 = heff_field(v_x_2412, 0);
    V v_a_2414 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 3ULL, 2);
    V v_stx_2415 = heff_take_field(v_res_2413, 0);
    V v_val_2416 = heff_get_n(v_res_2413, 1, 2);
    V v_t_2423 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){v_stx_2415}), heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam3, 1, 1, (V[]){v_val_2416})});
    V f_ = v_k_2411;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_a_2414});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam2, 1, 1, (V[]){v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_scope_242 = heff_take_field(v_e_241, 0);
  V v_globals_243 = heff_take_field(v_e_241, 1);
  V v_lams_244 = heff_take_field(v_e_241, 3);
  V v_self_245 = heff_take_field(v_e_241, 4);
  V v_insts_246 = heff_get_n(v_e_241, 5, 6);
  V v_c_249;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkSyn: {
    V v_f_247 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_248 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_242, v_globals_243, NTAG(TAG_ForNominative), v_lams_244, v_self_245, v_insts_246});
    v_c_249 = heff_tr(heff_call(v_f_247, 1, (V[]){v_t_248}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam1, 2, 1, (V[]){v_c_249});
}
Clo g_heff_2eelab_2etoplevel_2etagSpans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpans_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSpans(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 2);
        V v_acc_247 = (g_heff_2eelab_2etoplevel_2etagSpans(v_rest_242));
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_245));
        V v_t_249 = heff_get_n(v_t_248, 0, 2);
        switch (heff_tag_of(v_t_249)) {
        case TAG_At: {
          V v_it1_2410 = heff_field(v_t_249, 0);
          V v_tsp_2411 = heff_field(v_t_249, 1);
          heff_take_n(v_t_249, 3ULL, 2);
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_PatVar: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatTag: {
            V v_x_2413 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 3);
            return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_tsp_2411}), v_acc_247});
          }
          case TAG_PatOp: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatInt: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatFloat: {
            heff_take_na(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatString: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatBinary: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRune: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRecord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatWord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatAs: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          default: return heff_nomatch(v_it1_2410);
          }
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSpans(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str0, 12, "builtin.Lazy");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str9, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str10, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str11, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str13, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str14, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str15, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str16, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str17, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str18, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str19, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str20, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str21, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str22, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str23, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str24, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str25, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str26, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str27, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str28, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str29, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str30, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str31, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str32, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str33, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str34, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str35, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str36, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str37, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str38, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str39, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str40, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str41, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str42, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str43, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str44, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str45, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str46, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str47, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str48, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str49, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str50, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str51, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str52, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str53, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str54, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str55, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str56, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str57, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str58, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str59, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str60, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str61, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str62, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str63, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str64, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str65, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str66, 1, "r");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str67, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str68, 0, "");
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21, 1, 0};
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26, 1, 0};
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam34(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam32(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam37(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam36(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam35(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam40(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam39(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam38(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam41(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam42(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam44(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam43(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam46(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam45(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry, 10, 0};

V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V v_tag_240, V v_sp_241, V v_c_242, V v_sp_243, V v_i_244, V v_x4_245, V v_sp_246, V v_x3_247, V v_cs_248, V v_n_249) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009: ;
    heff_drop(v_n_249);
    switch (heff_tag_of(v_c_242)) {
    case TAG_At: {
      V v_c1_2410 = heff_dup(heff_field(v_c_242, 0));
      switch (heff_tag_of(v_c1_2410)) {
      case TAG_CInf: {
        V v_i_2412 = heff_field(v_c1_2410, 0);
        heff_take_n(v_c1_2410, 1ULL, 1);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_c_242)) {
        case TAG_At: {
          heff_take_n(v_c_242, 0ULL, 2);
          V v_c_2415 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_2412));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam0, 2, 2, (V[]){v_c_2415, v_sp_241});
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      case TAG_CType: {
        heff_take_n(v_c1_2410, 0ULL, 1);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        V v_c_2421 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_c_242));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam2, 2, 2, (V[]){v_c_2421, v_sp_241});
      }
      case TAG_CLam: {
        heff_take_n(v_c1_2410, 0ULL, 3);
        heff_drop(v_sp_241);
        V v_n_2430 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str1);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str2);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2430;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_c1_2410, 0ULL, 3);
        heff_drop(v_sp_241);
        V v_n_2434 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str3);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str4);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2434;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CAnnLam: {
        heff_take_n(v_c1_2410, 0ULL, 4);
        heff_drop(v_sp_241);
        V v_n_2439 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str5);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str6);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2439;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CTag: {
        heff_take_n(v_c1_2410, 0ULL, 3);
        heff_drop(v_sp_241);
        V v_n_2443 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str7);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str8);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2443;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CStruct: {
        V v_ru_24c1_2410_24CStruct = heff_take_reuse_n(v_c1_2410, 0ULL, 1);
        heff_drop(v_sp_241);
        V v_n_2445 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_at_n(v_ru_24c1_2410_24CStruct, TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str9);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str10);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2445;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CMatch: {
        heff_take_n(v_c1_2410, 0ULL, 2);
        heff_drop(v_sp_241);
        V v_n_2448 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str11);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str12);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2448;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CLetIn: {
        heff_take_n(v_c1_2410, 0ULL, 2);
        heff_drop(v_sp_241);
        V v_n_2451 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str13);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str14);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2451;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CLocal: {
        heff_take_n(v_c1_2410, 0ULL, 2);
        heff_drop(v_sp_241);
        V v_n_2454 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str15);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str16);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2454;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CAbandon: {
        heff_drop(v_sp_241);
        V v_n_2455 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str17);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str18);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2455;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CNominal: {
        V v_ru_24c1_2410_24CNominal = heff_take_reuse_n(v_c1_2410, 0ULL, 1);
        heff_drop(v_sp_241);
        V v_n_2457 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_at_n(v_ru_24c1_2410_24CNominal, TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str19);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str20);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2457;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      default: return heff_nomatch(v_c1_2410);
      }
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054: ;
    heff_drop(v_n_249);
    switch (heff_tag_of(v_x4_245)) {
    case TAG_Nil: {
      heff_drop_rec(v_sp_243, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
      V t_1 = v_sp_241;
      V t_2 = v_c_242;
      V t_3 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str21);
      V t_4 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str22);
      V t_5 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str23);
      V t_6 = v_sp_246;
      V t_7 = v_x3_247;
      V t_8 = v_cs_248;
      V t_9 = v_i_244;
      v_tag_240 = t_0;
      v_sp_241 = t_1;
      v_c_242 = t_2;
      v_sp_243 = t_3;
      v_i_244 = t_4;
      v_x4_245 = t_5;
      v_sp_246 = t_6;
      v_x3_247 = t_7;
      v_cs_248 = t_8;
      v_n_249 = t_9;
      goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
    }
    case TAG_Cons: {
      V v_z_2458 = heff_field(v_x4_245, 0);
      V v_x42_2459 = heff_field(v_x4_245, 1);
      V v_ru_24x4_245_24Cons = heff_take_reuse_n(v_x4_245, 3ULL, 2);
      heff_drop(v_sp_241);
      heff_drop(v_c_242);
      heff_drop(v_sp_246);
      heff_drop(v_x3_247);
      heff_drop(v_cs_248);
      switch (heff_tag_of(v_x42_2459)) {
      case TAG_Nil: {
        heff_drop(v_i_244);
        V v_n_2468;
        switch (heff_tag_of(v_x42_2459)) {
        case TAG_Nil: {
          V v_t_2460 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
          v_n_2468 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){v_t_2460, heff_dup(v_sp_243)});
          break;
        }
        case TAG_Cons: {
          V v_r_2461 = heff_dup(heff_field(v_x42_2459, 0));
          V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x42_2459));
          V v_t_2466;
          switch (heff_tag_of(v_r_2461)) {
          case TAG_At: {
            V v_s_2465 = heff_field(v_r_2461, 1);
            heff_take_n(v_r_2461, 2ULL, 2);
            v_t_2466 = v_s_2465;
            break;
          }
          default: heff_nomatch(v_r_2461);
          }
          V v_t_2467 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_2466, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          v_n_2468 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_2463}), v_t_2467});
          break;
        }
        default: heff_nomatch(v_x42_2459);
        }
        V v_c_2469 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n_2468));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam4, 2, 3, (V[]){v_c_2469, v_z_2458, v_sp_243});
      }
      case TAG_Cons: {
        V v_x422_2480 = heff_dup(heff_field(v_x42_2459, 1));
        switch (heff_tag_of(v_x422_2480)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x4_245_24Cons, 2);
          switch (heff_tag_of(v_x42_2459)) {
          case TAG_Cons: {
            heff_take_n(v_x42_2459, 0ULL, 2);
            V v_c_2483 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_244));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam8, 2, 3, (V[]){v_c_2483, v_z_2458, v_sp_243});
          }
          default: return heff_nomatch(v_x42_2459);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x422_2480, 0ULL, 2);
          heff_drop(v_i_244);
          V v_n_24103;
          switch (heff_tag_of(v_x42_2459)) {
          case TAG_Nil: {
            V v_t_2495 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
            v_n_24103 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){v_t_2495, heff_dup(v_sp_243)});
            break;
          }
          case TAG_Cons: {
            V v_r_2496 = heff_dup(heff_field(v_x42_2459, 0));
            V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x42_2459));
            V v_t_24101;
            switch (heff_tag_of(v_r_2496)) {
            case TAG_At: {
              V v_s_24100 = heff_field(v_r_2496, 1);
              heff_take_n(v_r_2496, 2ULL, 2);
              v_t_24101 = v_s_24100;
              break;
            }
            default: heff_nomatch(v_r_2496);
            }
            V v_t_24102 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_24101, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            v_n_24103 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_2498}), v_t_24102});
            break;
          }
          default: heff_nomatch(v_x42_2459);
          }
          V v_c_24104 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n_24103));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam12, 2, 3, (V[]){v_c_24104, v_z_2458, v_sp_243});
        }
        default: return heff_nomatch(v_x422_2480);
        }
      }
      default: return heff_nomatch(v_x42_2459);
      }
    }
    default: return heff_nomatch(v_x4_245);
    }
  }
  case TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422: ;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nil: {
      heff_drop(v_n_249);
      V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
      V v_n_24115 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24114));
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
      V t_1 = v_sp_241;
      V t_2 = v_c_242;
      V t_3 = v_sp_243;
      V t_4 = v_i_244;
      V t_5 = v_x4_245;
      V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str24);
      V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str25);
      V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str26);
      V t_9 = v_n_24115;
      v_tag_240 = t_0;
      v_sp_241 = t_1;
      v_c_242 = t_2;
      v_sp_243 = t_3;
      v_i_244 = t_4;
      v_x4_245 = t_5;
      v_sp_246 = t_6;
      v_x3_247 = t_7;
      v_cs_248 = t_8;
      v_n_249 = t_9;
      goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
    }
    case TAG_Cons: {
      V v_x31_24116 = heff_field(v_x3_247, 0);
      V v_x32_24117 = heff_field(v_x3_247, 1);
      heff_take_n(v_x3_247, 3ULL, 2);
      switch (heff_tag_of(v_x31_24116)) {
      case TAG_At: {
        V v_x311_24118 = heff_field(v_x31_24116, 0);
        heff_take_n(v_x31_24116, 1ULL, 2);
        switch (heff_tag_of(v_x311_24118)) {
        case TAG_CInf: {
          V v_i_24120 = heff_field(v_x311_24118, 0);
          heff_take_n(v_x311_24118, 1ULL, 1);
          switch (heff_tag_of(v_x32_24117)) {
          case TAG_Nil: {
            heff_drop(v_n_249);
            heff_drop(v_i_24120);
            V v_t_24121 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
            V v_n_24122 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24121));
            V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
            V t_1 = v_sp_241;
            V t_2 = v_c_242;
            V t_3 = v_sp_243;
            V t_4 = v_i_244;
            V t_5 = v_x4_245;
            V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str27);
            V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str28);
            V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str29);
            V t_9 = v_n_24122;
            v_tag_240 = t_0;
            v_sp_241 = t_1;
            v_c_242 = t_2;
            v_sp_243 = t_3;
            v_i_244 = t_4;
            v_x4_245 = t_5;
            v_sp_246 = t_6;
            v_x3_247 = t_7;
            v_cs_248 = t_8;
            v_n_249 = t_9;
            goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
          }
          case TAG_Cons: {
            heff_take_n(v_x32_24117, 0ULL, 2);
            heff_drop_rec(v_sp_243, 2);
            heff_drop(v_i_244);
            heff_drop(v_x4_245);
            V v_t_24125 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
            V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054);
            V t_1 = v_sp_241;
            V t_2 = v_c_242;
            V t_3 = v_sp_246;
            V t_4 = v_i_24120;
            V t_5 = v_t_24125;
            V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str30);
            V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str31);
            V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str32);
            V t_9 = v_n_249;
            v_tag_240 = t_0;
            v_sp_241 = t_1;
            v_c_242 = t_2;
            v_sp_243 = t_3;
            v_i_244 = t_4;
            v_x4_245 = t_5;
            v_sp_246 = t_6;
            v_x3_247 = t_7;
            v_cs_248 = t_8;
            v_n_249 = t_9;
            goto top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054;
          }
          default: return heff_nomatch(v_x32_24117);
          }
        }
        case TAG_CType: {
          heff_take_n(v_x311_24118, 0ULL, 1);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24128 = (g_heff_2eelab_2etoplevel_2etupleTypeRev(v_sp_246, v_t_24127));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str33);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str34);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str35);
          V t_9 = v_n_24128;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CLam: {
          heff_take_n(v_x311_24118, 0ULL, 3);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24132 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24133 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24132));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str36);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str37);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str38);
          V t_9 = v_n_24133;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CImplicitLam: {
          heff_take_n(v_x311_24118, 0ULL, 3);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24137 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24138 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24137));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str39);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str40);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str41);
          V t_9 = v_n_24138;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CAnnLam: {
          heff_take_n(v_x311_24118, 0ULL, 4);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24143 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24144 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24143));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str42);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str43);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str44);
          V t_9 = v_n_24144;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CTag: {
          heff_take_n(v_x311_24118, 0ULL, 3);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24148 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24149 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24148));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str45);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str46);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str47);
          V t_9 = v_n_24149;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CStruct: {
          heff_take_n(v_x311_24118, 0ULL, 1);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24151 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24152 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24151));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str48);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str49);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str50);
          V t_9 = v_n_24152;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CMatch: {
          heff_take_n(v_x311_24118, 0ULL, 2);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24155 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24156 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24155));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str51);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str52);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str53);
          V t_9 = v_n_24156;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CLetIn: {
          heff_take_n(v_x311_24118, 0ULL, 2);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24159 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24160 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24159));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str54);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str55);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str56);
          V t_9 = v_n_24160;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CLocal: {
          heff_take_n(v_x311_24118, 0ULL, 2);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24163 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24164 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24163));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str57);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str58);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str59);
          V t_9 = v_n_24164;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CAbandon: {
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24165 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24166 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24165));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str60);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str61);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str62);
          V t_9 = v_n_24166;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CNominal: {
          heff_take_n(v_x311_24118, 0ULL, 1);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24168 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24169 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24168));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str63);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str64);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str65);
          V t_9 = v_n_24169;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        default: return heff_nomatch(v_x311_24118);
        }
      }
      default: return heff_nomatch(v_x31_24116);
      }
    }
    default: return heff_nomatch(v_x3_247);
    }
  }
  case TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588: ;
    switch (heff_tag_of(v_n_249)) {
    case TAG_At: {
      V v_n1_27_24170 = heff_dup(heff_field(v_n_249, 0));
      switch (heff_tag_of(v_n1_27_24170)) {
      case TAG_IVar: {
        V v_x_24172 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24174 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam16, 2, 2, (V[]){v_sp_24174, v_x_24172});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IInt: {
        V v_i_24178 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24180 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam17, 2, 2, (V[]){v_sp_24180, v_i_24178});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IFloat: {
        V v_x_24184 = heff_tget_v(v_n1_27_24170, 0);
        heff_take_na(v_n1_27_24170, 0ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24186 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam18, 2, 2, (V[]){v_sp_24186, v_x_24184});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IString: {
        V v_s_24190 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam19, 2, 1, (V[]){v_s_24190});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IBytes: {
        V v_s_24201 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24203 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam22, 2, 2, (V[]){v_sp_24203, v_s_24201});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IPrim: {
        V v_p_24207 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24209 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam23, 2, 2, (V[]){v_sp_24209, v_p_24207});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IRune: {
        V v_c_24213 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24, 2, 1, (V[]){v_c_24213});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IApp: {
        V v_h_24224 = heff_field(v_n1_27_24170, 0);
        V v_args_24225 = heff_field(v_n1_27_24170, 1);
        heff_take_n(v_n1_27_24170, 3ULL, 2);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24228 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_h_24224)));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27, 2, 3, (V[]){v_c_24228, v_h_24224, v_args_24225});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IAnn: {
        V v_n0_24236 = heff_field(v_n1_27_24170, 0);
        V v_n1_24237 = heff_field(v_n1_27_24170, 1);
        heff_take_n(v_n1_27_24170, 3ULL, 2);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24240 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n0_24236));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam29, 2, 2, (V[]){v_c_24240, v_n1_24237});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ISpec: {
        V v_n0_24247 = heff_field(v_n1_27_24170, 0);
        V v_x_24248 = heff_field(v_n1_27_24170, 1);
        V v_v_24250 = heff_field(v_n1_27_24170, 3);
        heff_take_n(v_n1_27_24170, 11ULL, 4);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        V v_c_24251 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_v_24250));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam32, 2, 4, (V[]){v_c_24251, v_n0_24247, v_n_249, v_x_24248});
      }
      case TAG_IUpdate: {
        V v_n0_24261 = heff_field(v_n1_27_24170, 0);
        V v_fs_24262 = heff_field(v_n1_27_24170, 1);
        heff_take_n(v_n1_27_24170, 3ULL, 2);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24264 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V v_c_24265 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_24261));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam35, 2, 3, (V[]){v_c_24265, v_fs_24262, v_sp_24264});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IAnnLam: {
        V v_x_24275 = heff_field(v_n1_27_24170, 0);
        V v_tyN_24277 = heff_field(v_n1_27_24170, 2);
        V v_body_24278 = heff_field(v_n1_27_24170, 3);
        heff_take_n(v_n1_27_24170, 13ULL, 4);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24281 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_tyN_24277));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam38, 2, 3, (V[]){v_c_24281, v_body_24278, v_x_24275});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IInvalid: {
        V v_code_24288 = heff_field(v_n1_27_24170, 0);
        V v_why_24289 = heff_field(v_n1_27_24170, 1);
        V v_n1_273_24290 = heff_field(v_n1_27_24170, 2);
        heff_take_n(v_n1_27_24170, 7ULL, 3);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24292 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          switch (heff_tag_of(v_n1_273_24290)) {
          case TAG_Nothing: {
            return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam41, 2, 3, (V[]){v_code_24288, v_why_24289, v_sp_24292});
          }
          case TAG_Just: {
            V v_note_24301 = heff_field(v_n1_273_24290, 0);
            heff_take_n(v_n1_273_24290, 1ULL, 1);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam42, 2, 4, (V[]){v_code_24288, v_why_24289, v_sp_24292, v_note_24301});
          }
          default: return heff_nomatch(v_n1_273_24290);
          }
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_INominal: {
        V v_i_24310 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24313 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_24310));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam43, 2, 1, (V[]){v_c_24313});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ILitEq: {
        V v_x_24318 = heff_field(v_n1_27_24170, 0);
        V v_xsp_24319 = heff_field(v_n1_27_24170, 1);
        V v_eq_24320 = heff_field(v_n1_27_24170, 2);
        V v_lit_24321 = heff_field(v_n1_27_24170, 3);
        heff_take_n(v_n1_27_24170, 15ULL, 4);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24323 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V v_c_24324 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_lit_24321));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam45, 2, 5, (V[]){v_c_24324, v_sp_24323, v_x_24318, v_xsp_24319, v_eq_24320});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ILazy: {
        V v_c_24329 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24331 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009);
          V t_1 = v_sp_24331;
          V t_2 = v_c_24329;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = v_sp_246;
          V t_7 = v_x3_247;
          V t_8 = v_cs_248;
          V t_9 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str67);
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009;
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ITuple: {
        V v_cs_24332 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24334 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = v_sp_24334;
          V t_7 = heff_dup(v_cs_24332);
          V t_8 = v_cs_24332;
          V t_9 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str68);
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422;
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      default: return heff_nomatch(v_n1_27_24170);
      }
    }
    default: return heff_nomatch(v_n_249);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = ({ V a_0 = v_sp_241; V a_1 = v_x_2418; V r_ = (g_heff_2eelab_2erules_2elazySyn(a_0, a_1)); heff_drop(v_x_2418); r_; });
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam1, 1, 2, (V[]){v_sp_241, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_241), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str0)));
  V v_t_2426 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_sp_241; V a_2 = v_t_2425; V a_3 = v_x_2424; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2425); heff_drop(v_x_2424); r_; });
  V f_ = v_k_2423;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam3, 1, 2, (V[]){v_sp_241, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam7(V self, V *args) {
  V v_x_2477 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_x_2472 = heff_env(self)[1];
  V v_x_2474 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2478 = ({ V a_0 = v_sp_243; V a_1 = v_x_2472; V a_2 = v_x_2474; V a_3 = v_x_2477; V r_ = (g_heff_2eelab_2erules_2etupleSyn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2472); heff_drop(v_x_2477); r_; });
  V f_ = v_k_2471;
  args[0] = v_t_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam6(V self, V *args) {
  V v_x_2474 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_hd_2470 = heff_env(self)[1];
  V v_x_2472 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2475 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_243)));
  V v_c_2476 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2475));
  V f_ = v_c_2476;
  heff_room[0] = v_hd_2470;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam7, 1, 4, (V[]){v_sp_243, v_x_2472, v_x_2474, v_k_2471});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam5(V self, V *args) {
  V v_x_2472 = args[0];
  V v_z_2458 = heff_env(self)[0];
  V v_hd_2470 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2473 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_z_2458));
  V f_ = v_c_2473;
  heff_room[0] = heff_dup(v_hd_2470);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam6, 1, 4, (V[]){v_sp_243, v_hd_2470, v_x_2472, v_k_2471});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam4(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_c_2469 = heff_env(self)[0];
  V v_z_2458 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2469;
  args[0] = heff_dup(v_hd_2470);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam5, 1, 4, (V[]){v_z_2458, v_hd_2470, v_sp_243, v_k_2471});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam11(V self, V *args) {
  V v_x_2491 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_x_2486 = heff_env(self)[1];
  V v_x_2488 = heff_env(self)[2];
  V v_k_2485 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2492 = ({ V a_0 = v_sp_243; V a_1 = v_x_2486; V a_2 = v_x_2488; V a_3 = v_x_2491; V r_ = (g_heff_2eelab_2erules_2etupleSyn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2486); heff_drop(v_x_2491); r_; });
  V f_ = v_k_2485;
  args[0] = v_t_2492;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam10(V self, V *args) {
  V v_x_2488 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_hd_2484 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_k_2485 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2489 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_243)));
  V v_c_2490 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2489));
  V f_ = v_c_2490;
  heff_room[0] = v_hd_2484;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam11, 1, 4, (V[]){v_sp_243, v_x_2486, v_x_2488, v_k_2485});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam9(V self, V *args) {
  V v_x_2486 = args[0];
  V v_z_2458 = heff_env(self)[0];
  V v_hd_2484 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_k_2485 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2487 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_z_2458));
  V f_ = v_c_2487;
  heff_room[0] = heff_dup(v_hd_2484);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam10, 1, 4, (V[]){v_sp_243, v_hd_2484, v_x_2486, v_k_2485});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam8(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_c_2483 = heff_env(self)[0];
  V v_z_2458 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2483;
  args[0] = heff_dup(v_hd_2484);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam9, 1, 4, (V[]){v_z_2458, v_hd_2484, v_sp_243, v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam15(V self, V *args) {
  V v_x_24112 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_x_24107 = heff_env(self)[1];
  V v_x_24109 = heff_env(self)[2];
  V v_k_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24113 = ({ V a_0 = v_sp_243; V a_1 = v_x_24107; V a_2 = v_x_24109; V a_3 = v_x_24112; V r_ = (g_heff_2eelab_2erules_2etupleSyn(a_0, a_1, a_2, a_3)); heff_drop(v_x_24107); heff_drop(v_x_24112); r_; });
  V f_ = v_k_24106;
  args[0] = v_t_24113;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam14(V self, V *args) {
  V v_x_24109 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_hd_24105 = heff_env(self)[1];
  V v_x_24107 = heff_env(self)[2];
  V v_k_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24110 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_243)));
  V v_c_24111 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_24110));
  V f_ = v_c_24111;
  heff_room[0] = v_hd_24105;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam15, 1, 4, (V[]){v_sp_243, v_x_24107, v_x_24109, v_k_24106});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam13(V self, V *args) {
  V v_x_24107 = args[0];
  V v_z_2458 = heff_env(self)[0];
  V v_hd_24105 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_k_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_24108 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_z_2458));
  V f_ = v_c_24108;
  heff_room[0] = heff_dup(v_hd_24105);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam14, 1, 4, (V[]){v_sp_243, v_hd_24105, v_x_24107, v_k_24106});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam12(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k_24106 = args[1];
  V v_c_24104 = heff_env(self)[0];
  V v_z_2458 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24104;
  args[0] = heff_dup(v_hd_24105);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam13, 1, 4, (V[]){v_z_2458, v_hd_24105, v_sp_243, v_k_24106});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam16(V self, V *args) {
  V v_hd_24175 = args[0];
  V v_k_24176 = args[1];
  V v_sp_24174 = heff_env(self)[0];
  V v_x_24172 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_24175);
  V v_t_24177 = (g_heff_2eelab_2erules_2efind(v_sp_24174, v_x_24172));
  V f_ = v_k_24176;
  args[0] = v_t_24177;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam17(V self, V *args) {
  V v_hd_24181 = args[0];
  V v_k_24182 = args[1];
  V v_sp_24180 = heff_env(self)[0];
  V v_i_24178 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_24181);
  V v_t_24183 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_24180, heff_tag_n(TAG_IntNum, 1, (V[]){v_i_24178})));
  V f_ = v_k_24182;
  args[0] = v_t_24183;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam18(V self, V *args) {
  V v_hd_24187 = args[0];
  V v_k_24188 = args[1];
  V v_sp_24186 = heff_env(self)[0];
  V v_x_24184 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_24187);
  V v_t_24189 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_24186, heff_tag_nf(TAG_FracNum, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_24184))})));
  V f_ = v_k_24188;
  args[0] = v_t_24189;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21(V self, V *args) {
  V v_u_24198 = args[0];
  heff_drop(v_u_24198);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam20(V self, V *args) {
  V v_e_24195 = args[0];
  V v_hd_24196 = args[1];
  V v_k_24197 = args[2];
  V v_s_24190 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_24195);
  heff_drop(v_hd_24196);
  V v_t_24199 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_s_24190}), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21_clo)});
  V v_t_24200 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24199, NTAG(TAG_VPrimString)});
  V f_ = v_k_24197;
  args[0] = v_t_24200;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam19(V self, V *args) {
  V v_hd_24193 = args[0];
  V v_k_24194 = args[1];
  V v_s_24190 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24193);
  V f_ = v_k_24194;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam20, 3, 1, (V[]){v_s_24190})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam22(V self, V *args) {
  V v_hd_24204 = args[0];
  V v_k_24205 = args[1];
  V v_sp_24203 = heff_env(self)[0];
  V v_s_24201 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_24204);
  V v_t_24206 = (g_heff_2eelab_2erules_2elitBytes(v_sp_24203, v_s_24201));
  V f_ = v_k_24205;
  args[0] = v_t_24206;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam23(V self, V *args) {
  V v_hd_24210 = args[0];
  V v_k_24211 = args[1];
  V v_sp_24209 = heff_env(self)[0];
  V v_p_24207 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_24210);
  V v_t_24212 = (g_heff_2eelab_2erules_2efindPrim(v_sp_24209, v_p_24207));
  V f_ = v_k_24211;
  args[0] = v_t_24212;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26(V self, V *args) {
  V v_u_24221 = args[0];
  heff_drop(v_u_24221);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam25(V self, V *args) {
  V v_e_24218 = args[0];
  V v_hd_24219 = args[1];
  V v_k_24220 = args[2];
  V v_c_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_24218);
  heff_drop(v_hd_24219);
  V v_t_24222 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitRune, 1, (V[]){v_c_24213}), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26_clo)});
  V v_t_24223 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24222, NTAG(TAG_VPrimRune)});
  V f_ = v_k_24220;
  args[0] = v_t_24223;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24(V self, V *args) {
  V v_hd_24216 = args[0];
  V v_k_24217 = args[1];
  V v_c_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24216);
  V f_ = v_k_24217;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam25, 3, 1, (V[]){v_c_24213})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam28(V self, V *args) {
  V v_x_24231 = args[0];
  V v_h_24224 = heff_env(self)[0];
  V v_args_24225 = heff_env(self)[1];
  V v_hd_24229 = heff_env(self)[2];
  V v_k_24230 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24234;
  switch (heff_tag_of(v_h_24224)) {
  case TAG_At: {
    V v_s_24233 = heff_field(v_h_24224, 1);
    heff_take_n(v_h_24224, 2ULL, 2);
    v_t_24234 = v_s_24233;
    break;
  }
  default: heff_nomatch(v_h_24224);
  }
  V v_c_24235 = ({ V a_0 = heff_get_n(v_t_24234, 0, 2); V a_1 = v_x_24231; V a_2 = v_args_24225; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_args_24225); r_; });
  V f_ = v_c_24235;
  heff_room[0] = v_hd_24229;
  heff_room[1] = v_k_24230;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27(V self, V *args) {
  V v_hd_24229 = args[0];
  V v_k_24230 = args[1];
  V v_c_24228 = heff_env(self)[0];
  V v_h_24224 = heff_env(self)[1];
  V v_args_24225 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24228;
  args[0] = heff_dup(v_hd_24229);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam28, 1, 4, (V[]){v_h_24224, v_args_24225, v_hd_24229, v_k_24230});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam31(V self, V *args) {
  V v_x_24245 = args[0];
  V v_x_24243 = heff_env(self)[0];
  V v_k_24242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24246 = ({ V a_0 = v_x_24245; V a_1 = v_x_24243; V r_ = (g_heff_2eelab_2erules_2eannot(a_0, a_1)); heff_drop(v_x_24245); heff_drop(v_x_24243); r_; });
  V f_ = v_k_24242;
  args[0] = v_t_24246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam30(V self, V *args) {
  V v_x_24243 = args[0];
  V v_n1_24237 = heff_env(self)[0];
  V v_hd_24241 = heff_env(self)[1];
  V v_k_24242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24244 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n1_24237));
  V f_ = v_c_24244;
  heff_room[0] = v_hd_24241;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam31, 1, 2, (V[]){v_x_24243, v_k_24242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam29(V self, V *args) {
  V v_hd_24241 = args[0];
  V v_k_24242 = args[1];
  V v_c_24240 = heff_env(self)[0];
  V v_n1_24237 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24240;
  args[0] = heff_dup(v_hd_24241);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam30, 1, 3, (V[]){v_n1_24237, v_hd_24241, v_k_24242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam34(V self, V *args) {
  V v_x_24256 = args[0];
  V v_n_249 = heff_env(self)[0];
  V v_x_24248 = heff_env(self)[1];
  V v_x_24254 = heff_env(self)[2];
  V v_k_24253 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24259;
  switch (heff_tag_of(v_n_249)) {
  case TAG_At: {
    V v_s_24258 = heff_field(v_n_249, 1);
    heff_take_n(v_n_249, 2ULL, 2);
    v_t_24259 = v_s_24258;
    break;
  }
  default: heff_nomatch(v_n_249);
  }
  V v_t_24260 = ({ V a_0 = v_t_24259; V a_1 = v_x_24256; V a_2 = v_x_24248; V a_3 = v_x_24254; V r_ = (g_heff_2eelab_2erules_2erecordSpec(a_0, a_1, a_2, a_3)); heff_drop(v_x_24256); heff_drop(v_x_24254); r_; });
  V f_ = v_k_24253;
  args[0] = v_t_24260;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33(V self, V *args) {
  V v_x_24254 = args[0];
  V v_n0_24247 = heff_env(self)[0];
  V v_hd_24252 = heff_env(self)[1];
  V v_n_249 = heff_env(self)[2];
  V v_x_24248 = heff_env(self)[3];
  V v_k_24253 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24255 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_24247));
  V f_ = v_c_24255;
  heff_room[0] = v_hd_24252;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam34, 1, 4, (V[]){v_n_249, v_x_24248, v_x_24254, v_k_24253});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam32(V self, V *args) {
  V v_hd_24252 = args[0];
  V v_k_24253 = args[1];
  V v_c_24251 = heff_env(self)[0];
  V v_n0_24247 = heff_env(self)[1];
  V v_n_249 = heff_env(self)[2];
  V v_x_24248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24251;
  args[0] = heff_dup(v_hd_24252);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33, 1, 5, (V[]){v_n0_24247, v_hd_24252, v_n_249, v_x_24248, v_k_24253});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam37(V self, V *args) {
  V v_x_24270 = args[0];
  V v_fs_24262 = heff_env(self)[0];
  V v_sp_24264 = heff_env(self)[1];
  V v_x_24268 = heff_env(self)[2];
  V v_k_24267 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24271 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_24262));
  V v_t_24272 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24271; V r_ = (g_list_2efoldl_24s1991317015x801331450(a_0, a_1)); heff_drop(v_t_24271); r_; });
  V v_t_24273 = ({ V a_0 = v_t_24272; V a_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str66); V r_ = (g_heff_2eelab_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_24272); r_; });
  V v_x_24274 = ({ V a_0 = v_sp_24264; V a_1 = v_x_24268; V a_2 = v_t_24273; V a_3 = v_x_24270; V r_ = (g_heff_2eelab_2erules_2erecordUpdate(a_0, a_1, a_2, a_3)); heff_drop(v_x_24268); r_; });
  V f_ = v_k_24267;
  args[0] = v_x_24274;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam36(V self, V *args) {
  V v_x_24268 = args[0];
  V v_fs_24262 = heff_env(self)[0];
  V v_hd_24266 = heff_env(self)[1];
  V v_sp_24264 = heff_env(self)[2];
  V v_k_24267 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_24269 = (g_prelude_2etraverse_24s515579549x140669784(heff_dup(v_fs_24262)));
  V f_ = v_c_24269;
  heff_room[0] = v_hd_24266;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam37, 1, 4, (V[]){v_fs_24262, v_sp_24264, v_x_24268, v_k_24267});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam35(V self, V *args) {
  V v_hd_24266 = args[0];
  V v_k_24267 = args[1];
  V v_c_24265 = heff_env(self)[0];
  V v_fs_24262 = heff_env(self)[1];
  V v_sp_24264 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24265;
  args[0] = heff_dup(v_hd_24266);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam36, 1, 4, (V[]){v_fs_24262, v_hd_24266, v_sp_24264, v_k_24267});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam40(V self, V *args) {
  V v_x_24286 = args[0];
  V v_x_24275 = heff_env(self)[0];
  V v_x_24284 = heff_env(self)[1];
  V v_k_24283 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24287 = ({ V a_0 = v_x_24275; V a_1 = v_x_24284; V a_2 = v_x_24286; V r_ = (g_heff_2eelab_2erules_2efunctionIntroSyn(a_0, a_1, a_2)); heff_drop(v_x_24284); heff_drop(v_x_24286); r_; });
  V f_ = v_k_24283;
  args[0] = v_t_24287;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam39(V self, V *args) {
  V v_x_24284 = args[0];
  V v_body_24278 = heff_env(self)[0];
  V v_hd_24282 = heff_env(self)[1];
  V v_x_24275 = heff_env(self)[2];
  V v_k_24283 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_24285 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_body_24278));
  V f_ = v_c_24285;
  heff_room[0] = v_hd_24282;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam40, 1, 3, (V[]){v_x_24275, v_x_24284, v_k_24283});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam38(V self, V *args) {
  V v_hd_24282 = args[0];
  V v_k_24283 = args[1];
  V v_c_24281 = heff_env(self)[0];
  V v_body_24278 = heff_env(self)[1];
  V v_x_24275 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24281;
  args[0] = heff_dup(v_hd_24282);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam39, 1, 4, (V[]){v_body_24278, v_hd_24282, v_x_24275, v_k_24283});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam41(V self, V *args) {
  V v_hd_24293 = args[0];
  V v_k2_24294 = args[1];
  V v_code_24288 = heff_env(self)[0];
  V v_why_24289 = heff_env(self)[1];
  V v_sp_24292 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_24295 = heff_take_field(v_hd_24293, 1);
  V v_malg_24296 = heff_get_n(v_hd_24293, 2, 3);
  V v_t_24297 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_24288), NTAG(TAG_SError), v_why_24289, v_sp_24292, NTAG(TAG_Nothing)});
  V v_t_24298 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24297})});
  V v_t_24299 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24298})});
  V v_t_24300 = heff_tr(heff_call(v_malg_24296, 1, (V[]){v_t_24299}));
  V f_ = v_bind_24295;
  args[0] = v_t_24300;
  args[1] = v_k2_24294;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam42(V self, V *args) {
  V v_hd_24302 = args[0];
  V v_k2_24303 = args[1];
  V v_code_24288 = heff_env(self)[0];
  V v_why_24289 = heff_env(self)[1];
  V v_sp_24292 = heff_env(self)[2];
  V v_note_24301 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_bind_24304 = heff_take_field(v_hd_24302, 1);
  V v_malg_24305 = heff_get_n(v_hd_24302, 2, 3);
  V v_t_24306 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_24288), NTAG(TAG_SError), v_why_24289, v_sp_24292, heff_tag_n(TAG_Just, 1, (V[]){v_note_24301})});
  V v_t_24307 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24306})});
  V v_t_24308 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24307})});
  V v_t_24309 = heff_tr(heff_call(v_malg_24305, 1, (V[]){v_t_24308}));
  V f_ = v_bind_24304;
  args[0] = v_t_24309;
  args[1] = v_k2_24303;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam44(V self, V *args) {
  V v_x_24316 = args[0];
  V v_k_24315 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24317 = ({ V a_0 = v_x_24316; V r_ = (g_heff_2eelab_2etoplevel_2enominalSyn(a_0)); heff_drop(v_x_24316); r_; });
  V f_ = v_k_24315;
  args[0] = v_t_24317;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam43(V self, V *args) {
  V v_hd_24314 = args[0];
  V v_k_24315 = args[1];
  V v_c_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24313;
  args[0] = v_hd_24314;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam44, 1, 1, (V[]){v_k_24315});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam46(V self, V *args) {
  V v_x_24327 = args[0];
  V v_sp_24323 = heff_env(self)[0];
  V v_x_24318 = heff_env(self)[1];
  V v_xsp_24319 = heff_env(self)[2];
  V v_eq_24320 = heff_env(self)[3];
  V v_k_24326 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24328 = ({ V a_0 = v_sp_24323; V a_1 = v_x_24318; V a_2 = v_xsp_24319; V a_3 = v_eq_24320; V a_4 = v_x_24327; V r_ = (g_heff_2eelab_2erules_2elitEq(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_24327); r_; });
  V f_ = v_k_24326;
  args[0] = v_t_24328;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam45(V self, V *args) {
  V v_hd_24325 = args[0];
  V v_k_24326 = args[1];
  V v_c_24324 = heff_env(self)[0];
  V v_sp_24323 = heff_env(self)[1];
  V v_x_24318 = heff_env(self)[2];
  V v_xsp_24319 = heff_env(self)[3];
  V v_eq_24320 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24324;
  args[0] = v_hd_24325;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam46, 1, 5, (V[]){v_sp_24323, v_x_24318, v_xsp_24319, v_eq_24320, v_k_24326});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V v_sp_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_t1_242 = heff_dup(heff_field(v_t_241, 0));
    switch (heff_tag_of(v_t1_242)) {
    case TAG_TPi: {
      heff_take_n(v_t1_242, 0ULL, 2);
      V v_c_246 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0, 2, 2, (V[]){v_c_246, v_sp_240});
    }
    case TAG_TSig: {
      V v_fields_2411 = heff_field(v_t1_242, 0);
      heff_take_n(v_t1_242, 1ULL, 1);
      switch (heff_tag_of(v_t_241)) {
      case TAG_At: {
        heff_take_n(v_t_241, 0ULL, 2);
        V v_c_2414 = (g_prelude_2etraverse_24s2094958103x549422471(v_fields_2411));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2, 2, 2, (V[]){v_c_2414, v_sp_240});
      }
      default: return heff_nomatch(v_t_241);
      }
    }
    case TAG_TSum: {
      heff_take_n(v_t1_242, 0ULL, 1);
      V v_c_2420 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4, 2, 2, (V[]){v_c_2420, v_sp_240});
    }
    case TAG_TType: {
      V v_c_2425 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6, 2, 2, (V[]){v_c_2425, v_sp_240});
    }
    case TAG_TInt: {
      V v_c_2430 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8, 2, 2, (V[]){v_c_2430, v_sp_240});
    }
    case TAG_TFloat: {
      V v_c_2435 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10, 2, 2, (V[]){v_c_2435, v_sp_240});
    }
    case TAG_TString: {
      V v_c_2440 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12, 2, 2, (V[]){v_c_2440, v_sp_240});
    }
    case TAG_TRune: {
      V v_c_2445 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14, 2, 2, (V[]){v_c_2445, v_sp_240});
    }
    case TAG_TArray: {
      heff_take_n(v_t1_242, 0ULL, 1);
      V v_c_2451 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16, 2, 2, (V[]){v_c_2451, v_sp_240});
    }
    case TAG_TFixed: {
      heff_take_n(v_t1_242, 0ULL, 1);
      V v_c_2457 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18, 2, 2, (V[]){v_c_2457, v_sp_240});
    }
    case TAG_TInf: {
      heff_take_n(v_t1_242, 0ULL, 1);
      V v_c_2463 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20, 2, 2, (V[]){v_c_2463, v_sp_240});
    }
    case TAG_TChk: {
      heff_take_n(v_t1_242, 0ULL, 1);
      V v_c_2469 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22, 2, 2, (V[]){v_c_2469, v_sp_240});
    }
    case TAG_TNominal: {
      heff_take_n(v_t1_242, 0ULL, 1);
      V v_c_2475 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24, 2, 2, (V[]){v_c_2475, v_sp_240});
    }
    default: return heff_nomatch(v_t1_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_sp_240; V a_1 = v_x_249; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1, 1, 2, (V[]){v_sp_240, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = (g_heff_2eelab_2erules_2erecordTypeIntro(v_sp_240, v_x_2417));
  V f_ = v_k_2416;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3, 1, 2, (V[]){v_sp_240, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = ({ V a_0 = v_sp_240; V a_1 = v_x_2423; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2423); r_; });
  V f_ = v_k_2422;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5, 1, 2, (V[]){v_sp_240, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = ({ V a_0 = v_sp_240; V a_1 = v_x_2428; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2428); r_; });
  V f_ = v_k_2427;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7, 1, 2, (V[]){v_sp_240, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = ({ V a_0 = v_sp_240; V a_1 = v_x_2433; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2433); r_; });
  V f_ = v_k_2432;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9, 1, 2, (V[]){v_sp_240, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = ({ V a_0 = v_sp_240; V a_1 = v_x_2438; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2438); r_; });
  V f_ = v_k_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11, 1, 2, (V[]){v_sp_240, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args) {
  V v_x_2443 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = ({ V a_0 = v_sp_240; V a_1 = v_x_2443; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2443); r_; });
  V f_ = v_k_2442;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2440;
  args[0] = v_hd_2441;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13, 1, 2, (V[]){v_sp_240, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args) {
  V v_x_2448 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449 = ({ V a_0 = v_sp_240; V a_1 = v_x_2448; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2448); r_; });
  V f_ = v_k_2447;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15, 1, 2, (V[]){v_sp_240, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args) {
  V v_x_2454 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = ({ V a_0 = v_sp_240; V a_1 = v_x_2454; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2454); r_; });
  V f_ = v_k_2453;
  args[0] = v_t_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_c_2451 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2451;
  args[0] = v_hd_2452;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17, 1, 2, (V[]){v_sp_240, v_k_2453});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args) {
  V v_x_2460 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461 = ({ V a_0 = v_sp_240; V a_1 = v_x_2460; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2460); r_; });
  V f_ = v_k_2459;
  args[0] = v_t_2461;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2457;
  args[0] = v_hd_2458;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19, 1, 2, (V[]){v_sp_240, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args) {
  V v_x_2466 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2465 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467 = ({ V a_0 = v_sp_240; V a_1 = v_x_2466; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2466); r_; });
  V f_ = v_k_2465;
  args[0] = v_t_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_c_2463 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2463;
  args[0] = v_hd_2464;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21, 1, 2, (V[]){v_sp_240, v_k_2465});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args) {
  V v_x_2472 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2473 = ({ V a_0 = v_sp_240; V a_1 = v_x_2472; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2472); r_; });
  V f_ = v_k_2471;
  args[0] = v_t_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_c_2469 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2469;
  args[0] = v_hd_2470;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23, 1, 2, (V[]){v_sp_240, v_k_2471});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args) {
  V v_x_2478 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2477 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2479 = ({ V a_0 = v_sp_240; V a_1 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2478); r_; });
  V f_ = v_k_2477;
  args[0] = v_t_2479;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  V v_c_2475 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2475;
  args[0] = v_hd_2476;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25, 1, 2, (V[]){v_sp_240, v_k_2477});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8, 3, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam32(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam34(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam33(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TPi: {
      V v_b_243 = heff_field(v_x21_241, 0);
      V v_codN_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(v_b_243));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0, 2, 2, (V[]){v_c_245, v_codN_244});
    }
    case TAG_TSig: {
      V v_fields_2412 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_2413 = (g_prelude_2etraverse_24s2094958103x549422471(v_fields_2412));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3, 2, 1, (V[]){v_c_2413});
    }
    case TAG_TSum: {
      V v_variantNs_2418 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_2419 = (g_prelude_2etraverse_24s390133767x1613463851(v_variantNs_2418));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5, 2, 1, (V[]){v_c_2419});
    }
    case TAG_TType: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7_clo);
    }
    case TAG_TInt: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo);
    }
    case TAG_TFloat: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo);
    }
    case TAG_TString: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo);
    }
    case TAG_TRune: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo);
    }
    case TAG_TArray: {
      V v_a0_2444 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_2445 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_a0_2444));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14, 2, 1, (V[]){v_c_2445});
    }
    case TAG_TFixed: {
      V v_w_2450 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16, 2, 1, (V[]){v_w_2450});
    }
    case TAG_TInf: {
      V v_i_2458 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24TInf = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2494;
      switch (heff_tag_of(v_i_2458)) {
      case TAG_At: {
        V v_x11_2459 = heff_dup(heff_field(v_i_2458, 0));
        switch (heff_tag_of(v_x11_2459)) {
        case TAG_IVar: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IInt: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IFloat: {
          heff_take_na(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IString: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IBytes: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IPrim: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IRune: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IApp: {
          heff_take_n(v_x11_2459, 0ULL, 2);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IAnn: {
          heff_take_n(v_x11_2459, 0ULL, 2);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_ISpec: {
          heff_take_n(v_x11_2459, 0ULL, 4);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IUpdate: {
          heff_take_n(v_x11_2459, 0ULL, 2);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IAnnLam: {
          heff_take_n(v_x11_2459, 0ULL, 4);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_IInvalid: {
          heff_take_n(v_x11_2459, 0ULL, 3);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_INominal: {
          V v_i_2485 = heff_field(v_x11_2459, 0);
          heff_take_n(v_x11_2459, 1ULL, 1);
          switch (heff_tag_of(v_i_2458)) {
          case TAG_At: {
            v_t_2494 = v_i_2485;
            break;
          }
          default: heff_nomatch(v_i_2458);
          }
          break;
        }
        case TAG_ILitEq: {
          heff_take_n(v_x11_2459, 0ULL, 4);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_ILazy: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        case TAG_ITuple: {
          heff_take_n(v_x11_2459, 0ULL, 1);
          v_t_2494 = heff_dup(v_i_2458);
          break;
        }
        default: heff_nomatch(v_x11_2459);
        }
        break;
      }
      default: heff_nomatch(v_i_2458);
      }
      V v_t_24128;
      switch (heff_tag_of(v_t_2494)) {
      case TAG_At: {
        V v_x11_2495 = heff_field(v_t_2494, 0);
        V v_sp_2496 = heff_field(v_t_2494, 1);
        heff_take_n(v_t_2494, 3ULL, 2);
        switch (heff_tag_of(v_x11_2495)) {
        case TAG_IVar: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IInt: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IFloat: {
          heff_take_na(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IString: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IBytes: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IPrim: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IRune: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IApp: {
          heff_take_n(v_x11_2495, 0ULL, 2);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IAnn: {
          heff_take_n(v_x11_2495, 0ULL, 2);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ISpec: {
          heff_take_n(v_x11_2495, 0ULL, 4);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IUpdate: {
          heff_take_n(v_x11_2495, 0ULL, 2);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IAnnLam: {
          heff_take_n(v_x11_2495, 0ULL, 4);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IInvalid: {
          heff_take_n(v_x11_2495, 0ULL, 3);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_INominal: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ILitEq: {
          heff_take_n(v_x11_2495, 0ULL, 4);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ILazy: {
          heff_take_n(v_x11_2495, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_2496);
          v_t_24128 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ITuple: {
          V v_cs_24127 = heff_field(v_x11_2495, 0);
          heff_take_n(v_x11_2495, 1ULL, 1);
          v_t_24128 = heff_tag_at_n(v_ru_24x21_241_24TInf, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_MkPair, 2, (V[]){v_sp_2496, v_cs_24127})});
          break;
        }
        default: heff_nomatch(v_x11_2495);
        }
        break;
      }
      default: heff_nomatch(v_t_2494);
      }
      switch (heff_tag_of(v_t_24128)) {
      case TAG_Nothing: {
        V v_c_24129 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_2458));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19, 2, 2, (V[]){v_c_24129, v_x22_242});
      }
      case TAG_Just: {
        V v_it1_24134 = heff_field(v_t_24128, 0);
        heff_take_n(v_t_24128, 1ULL, 1);
        heff_drop(v_x22_242);
        switch (heff_tag_of(v_it1_24134)) {
        case TAG_MkPair: {
          V v_isp_24135 = heff_field(v_it1_24134, 0);
          V v_cs_24136 = heff_field(v_it1_24134, 1);
          heff_take_n(v_it1_24134, 3ULL, 2);
          V v_t_24170;
          switch (heff_tag_of(v_i_2458)) {
          case TAG_At: {
            V v_x11_24137 = heff_field(v_i_2458, 0);
            heff_take_n(v_i_2458, 1ULL, 2);
            switch (heff_tag_of(v_x11_24137)) {
            case TAG_IVar: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IInt: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IFloat: {
              heff_take_na(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IString: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IBytes: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IPrim: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IRune: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IApp: {
              heff_take_n(v_x11_24137, 0ULL, 2);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_24137, 0ULL, 2);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_24137, 0ULL, 4);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_24137, 0ULL, 2);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_24137, 0ULL, 4);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_24137, 0ULL, 3);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_INominal: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_True);
              break;
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_24137, 0ULL, 4);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_ILazy: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            case TAG_ITuple: {
              heff_take_n(v_x11_24137, 0ULL, 1);
              v_t_24170 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_x11_24137);
            }
            break;
          }
          default: heff_nomatch(v_i_2458);
          }
          V v_c_24171 = ({ V a_0 = v_t_24170; V a_1 = v_isp_24135; V a_2 = v_cs_24136; V r_ = (g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(a_0, a_1, a_2)); heff_drop(v_t_24170); r_; });
          return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21, 2, 1, (V[]){v_c_24171});
        }
        default: return heff_nomatch(v_it1_24134);
        }
      }
      default: return heff_nomatch(v_t_24128);
      }
    }
    case TAG_TChk: {
      V v_ch_24187 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_24188 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_ch_24187));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27, 2, 1, (V[]){v_c_24188});
    }
    case TAG_TNominal: {
      V v_t_24204 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_24205 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_24204));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam33, 2, 1, (V[]){v_c_24205});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a[0]);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = ({ V a_0 = v_x_248; V a_1 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_k_247;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_codN_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_codN_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_codN_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1, 1, 3, (V[]){v_codN_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2eelab_2erules_2erecordFormation(v_x_2416));
  V f_ = v_k_2415;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2422)));
  V v_t_2424 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2422));
  V v_t_2425 = (g_list_2emap_24s1173914895x100384474(v_x_2422));
  V v_t_2426 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2423), v_t_2424, heff_arrayFromList(v_t_2425)});
  V v_x_2427 = (g_heff_2eelab_2erules_2esumFormation(v_t_2426));
  V f_ = v_k_2421;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6, 1, 1, (V[]){v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args) {
  V v_u2_2434 = args[0];
  heff_drop(v_u2_2434);
  V v_t_2435 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2435});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args) {
  V v_e_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  heff_drop(v_e_2430);
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
  V f_ = v_k_2432;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2433, ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = ({ V a_0 = v_x_2448; V r_ = (g_heff_2eelab_2erules_2eprimArray(a_0)); heff_drop(v_x_2448); r_; });
  V f_ = v_k_2447;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15, 1, 1, (V[]){v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args) {
  V v_u_2456 = args[0];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2450})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args) {
  V v_e_2453 = args[0];
  V v_hd_2454 = args[1];
  V v_k_2455 = args[2];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2453);
  heff_drop(v_hd_2454);
  V v_t_2457 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){heff_dup(v_w_2450)}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18, 1, 1, (V[]){v_w_2450})});
  V f_ = v_k_2455;
  args[0] = v_t_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17, 3, 1, (V[]){v_w_2450})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args) {
  V v_x_24132 = args[0];
  V v_x22_242 = heff_env(self)[0];
  V v_k_24131 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24133 = ({ V a_0 = v_x22_242; V a_1 = v_x_24132; V r_ = (g_heff_2eelab_2erules_2euniverseElimSyn(a_0, a_1)); heff_drop(v_x_24132); r_; });
  V f_ = v_k_24131;
  args[0] = v_t_24133;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k_24131 = args[1];
  V v_c_24129 = heff_env(self)[0];
  V v_x22_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24129;
  args[0] = v_hd_24130;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20, 1, 2, (V[]){v_x22_242, v_k_24131});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args) {
  V v_u_24184 = args[0];
  V v_val_24183 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24184);
  V v_t_24185 = heff_tr(heff_call(v_val_24183, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_t_24185; V r_ = (g_heff_2eelab_2evalue_2edecodeEv(a_0)); heff_drop(v_t_24185); r_; });
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args) {
  V v_x_24181 = args[0];
  V v_k_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_stx_24182 = heff_take_field(v_x_24181, 0);
  V v_val_24183 = heff_get_n(v_x_24181, 1, 2);
  V v_t_24186 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_stx_24182}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26, 1, 1, (V[]){v_val_24183})});
  V f_ = v_k_24180;
  args[0] = v_t_24186;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args) {
  V v_hd_24179 = args[0];
  V v_k_24180 = args[1];
  V v_c_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24178;
  args[0] = v_hd_24179;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25, 1, 1, (V[]){v_k_24180});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args) {
  V v_e_24175 = args[0];
  V v_x_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_24178;
  switch (heff_tag_of(v_x_24174)) {
  case TAG_MkChk: {
    V v_f_24176 = heff_field(v_x_24174, 0);
    V v_ru_24x_24174_24MkChk = heff_take_reuse_n(v_x_24174, 1ULL, 1);
    V v_t_24177 = heff_tag_at_n(v_ru_24x_24174_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
    v_c_24178 = heff_tr(heff_call(v_f_24176, 2, (V[]){v_e_24175, v_t_24177}));
    break;
  }
  default: heff_nomatch(v_x_24174);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24, 2, 1, (V[]){v_c_24178});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args) {
  V v_x_24174 = args[0];
  V v_k_24173 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_24173;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23, 1, 1, (V[]){v_x_24174})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args) {
  V v_hd_24172 = args[0];
  V v_k_24173 = args[1];
  V v_c_24171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24171;
  args[0] = v_hd_24172;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22, 1, 1, (V[]){v_k_24173});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam32(V self, V *args) {
  V v_u_24201 = args[0];
  V v_val_24200 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24201);
  V v_t_24202 = heff_tr(heff_call(v_val_24200, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_t_24202; V r_ = (g_heff_2eelab_2evalue_2edecodeEv(a_0)); heff_drop(v_t_24202); r_; });
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam31(V self, V *args) {
  V v_x_24198 = args[0];
  V v_k_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_stx_24199 = heff_take_field(v_x_24198, 0);
  V v_val_24200 = heff_get_n(v_x_24198, 1, 2);
  V v_t_24203 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_stx_24199}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam32, 1, 1, (V[]){v_val_24200})});
  V f_ = v_k_24197;
  args[0] = v_t_24203;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args) {
  V v_hd_24196 = args[0];
  V v_k_24197 = args[1];
  V v_c_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24195;
  args[0] = v_hd_24196;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam31, 1, 1, (V[]){v_k_24197});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args) {
  V v_e_24192 = args[0];
  V v_x_24191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_24195;
  switch (heff_tag_of(v_x_24191)) {
  case TAG_MkChk: {
    V v_f_24193 = heff_field(v_x_24191, 0);
    V v_ru_24x_24191_24MkChk = heff_take_reuse_n(v_x_24191, 1ULL, 1);
    V v_t_24194 = heff_tag_at_n(v_ru_24x_24191_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
    v_c_24195 = heff_tr(heff_call(v_f_24193, 2, (V[]){v_e_24192, v_t_24194}));
    break;
  }
  default: heff_nomatch(v_x_24191);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30, 2, 1, (V[]){v_c_24195});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args) {
  V v_x_24191 = args[0];
  V v_k_24190 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_24190;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29, 1, 1, (V[]){v_x_24191})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args) {
  V v_hd_24189 = args[0];
  V v_k_24190 = args[1];
  V v_c_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24188;
  args[0] = v_hd_24189;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28, 1, 1, (V[]){v_k_24190});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam34(V self, V *args) {
  V v_x_24208 = args[0];
  V v_k_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24209 = ({ V a_0 = v_x_24208; V r_ = (g_heff_2eelab_2etoplevel_2enominalTyp(a_0)); heff_drop(v_x_24208); r_; });
  V f_ = v_k_24207;
  args[0] = v_t_24209;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam33(V self, V *args) {
  V v_hd_24206 = args[0];
  V v_k_24207 = args[1];
  V v_c_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24205;
  args[0] = v_hd_24206;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam34, 1, 1, (V[]){v_k_24207});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epoisonedLeft_str0, 54, "an implicit argument an error kept from being inferred");
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2epoisonedLeft(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epoisonedLeft(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get_n(v_c_244, 2, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args) {
  V v_m_2416 = args[0];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2417 = ({ V a_0 = v_x_2413; V a_1 = v_m_2416; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2413); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_me_2420 = v_field_2419;
      V v_t_2421 = heff_get_n(v_me_2420, 1, 6);
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_t_2421, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2421);
      }
    } else {
      heff_drop(v_field_2419);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_malg_243 = heff_env(self)[1];
  V v_bind_242 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = ({ V a_0 = v_x_248; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_x_248); r_; });
  V v_t_2415 = (g_list_2emap_24s1415906091x1371825187(v_t_2414));
  V v_t_2423 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4, 1, 1, (V[]){v_x_2413}); V a_1 = v_t_2415; V r_ = (g_heff_2eelab_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2415); r_; });
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_t_2423);
    V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2426}));
    V f_ = v_bind_242;
    heff_room[0] = v_t_2427;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_malg_243);
    heff_drop(v_bind_242);
    heff_drop(v_t_2423);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3, 1, 4, (V[]){v_x_248, v_malg_243, v_bind_242, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2emetasInV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emetasInV_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2emetasInV(V v_mc_240, V v_v_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_t_242, 0);
    V v_sp_244 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_h_243, 0);
      heff_take_n(v_h_243, 1ULL, 1);
      v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_HError: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_244));
    V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2emetasInV_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2etoplevel_2econcatMapM(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_2411, v_t_2414);
  }
  case TAG_VCode: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VLam: {
    heff_take_n(v_t_242, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_VCons: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2emetasInV(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args) {
  V v_v2_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_mc_240; V a_1 = v_v2_2413; V r_ = (g_heff_2eelab_2etoplevel_2emetasInV(a_0, a_1)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eshownV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eshownV_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243) {
top: ;
  V v_len_244 = heff_take_field(v_cs_242, 0);
  V v_names_245 = heff_get_n(v_cs_242, 1, 2);
  V v_t_246 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_243));
  V v_e_247 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_len_244, v_t_246));
  V v_t_2415 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2etoplevel_2eshownV_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2416 = heff_tr(heff_call(heff_get_n(v_t_2415, 0, 2), 1, (V[]){v_e_247}));
  HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), v_names_245, v_e_2416);
}
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eshownV(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_249 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_248)));
  V v_t_2410 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_248; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_248); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_d_249);
      V v_x_2414 = v_field_2413;
      return v_x_2414;
    } else {
      heff_drop(v_field_2413);
      return v_d_249;
    }
  }
}
Clo g_heff_2eelab_2etoplevel_2estuckAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_245 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 2))));
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245));
  V v_x1_247 = (g_heff_2eelab_2etoplevel_2enubInt(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = (g_std_2emap_2elookup_24s1702756637x1169753568(v_mc_243, v_x_248));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2411 = (g_heff_2eelab_2etoplevel_2eshownV(heff_dup(v_g_240), v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_2412 = (g_heff_2eelab_2etoplevel_2eshownV(v_g_240, v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 2))));
  return (g_heff_2eelab_2etoplevel_2estuckWith(v_fallback_241, v_p_242, v_t_2410, v_t_2411, v_t_2412));
}
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2estuckAt(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eentryFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eentryFor_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244) {
top: ;
  V v_t_2412;
  if ((heff_dup(v_prim_242) == NTAG(TAG_True))) {
    v_t_2412 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eentryFor_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_243)}), NTAG(TAG_Nothing)));
  } else {
    v_t_2412 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), v_k_241, heff_dup(v_tyStx_243), heff_dup(v_bodyStx_244)));
  }
  HeffT2 v_t_2413 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
  V v_t_2419;
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2415;
      v_t_2419 = v_x_2416;
    } else {
      if ((v_tag_2414 == ((int64_t)1ULL))) {
        V v_x11_2417 = v_field_2415;
        heff_drop(v_x11_2417);
        v_t_2419 = heff_abandon();
      } else {
        V v_x_2418 = v_field_2415;
        v_t_2419 = v_x_2418;
      }
    }
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_244, v_tyStx_243, v_t_2412, v_t_2419});
}
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eentryFor(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_245);
  HeffT2 v_t_246 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_tyStx_243, NTAG(TAG_LNil)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      return v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        return heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        return v_x_2411;
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2echeckStuck(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  V v_bind_245 = heff_take_field(v_p_243, 1);
  V v_malg_246 = heff_get_n(v_p_243, 2, 3);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_sp_241);
    heff_drop(v_bind_245);
    heff_drop(v_malg_246);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_p_247 = heff_field(v_x3_242, 0);
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo)})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2411}));
    return heff_tail(heff_dup(v_bind_245), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2etoplevel_2echeckStuck_lam1, 1, 6, (V[]){v_g_240, v_sp_241, heff_dup(v_p_247), v_malg_246, v_bind_245, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2echeckStuck(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 8);
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  V v_malg_246 = heff_env(self)[3];
  V v_bind_245 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2414 = ({ V a_0 = v_g_240; V a_1 = v_sp_241; V a_2 = v_p_247; V a_3 = v_x_2413; V r_ = (g_heff_2eelab_2etoplevel_2estuckAt(a_0, a_1, a_2, a_3)); heff_drop(v_x_2413); r_; });
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_x_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2416}));
  V f_ = v_bind_245;
  heff_room[0] = v_t_2417;
  heff_room[1] = v_p_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efailedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efailedAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2efailedAt(V v_aval_240, V v_d_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2eelab_2emeta_2eblockedTy(v_aval_240, heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2etoplevel_2efailedAt_lam0, 1, 3, (V[]){v_d_241, v_hd_242, v_k_243})));
}
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2efailedAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245;
  if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    v_t_245 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_d_241, 30ULL, 5, shape_code__severity__msg__span__note, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_x_244);
    v_t_245 = v_d_241;
  }
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_247}));
  V f_ = heff_get_n(v_hd_242, 1, 3);
  heff_room[0] = v_t_248;
  heff_room[1] = v_k_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_entry, 7, 0};

V g_heff_2eelab_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244, V v_z_245, V v_z_246) {
top: ;
  V v_stx_247 = heff_take_field(v_a_244, 0);
  V v_val_248 = heff_get_n(v_a_244, 1, 2);
  V v_t_249 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2410;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    v_t_2410 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_249);
    v_t_2410 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_k_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam0, 1, 1, (V[]){v_k_2411})})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2421}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2422, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam1, 1, 8, (V[]){v_z_245, heff_dup(v_n_242), v_d_243, v_key_240, v_val_248, v_stx_247, v_g_241, v_z_246})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabBody(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args) {
  V v_c_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_infos_2413 = heff_take_field(v_c_2412, 0);
  V v_recovered_2414 = heff_take_field(v_c_2412, 1);
  V v_poisoned_2415 = heff_take_field(v_c_2412, 2);
  V v_metas_2416 = heff_take_field(v_c_2412, 3);
  V v_nextMeta_2417 = heff_take_field(v_c_2412, 4);
  V v_postponed_2418 = heff_take_field(v_c_2412, 5);
  V v_trace_2419 = heff_get_n(v_c_2412, 6, 8);
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_2413, v_recovered_2414, v_poisoned_2415, v_metas_2416, v_nextMeta_2417, v_postponed_2418, v_trace_2419, v_k_2411});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args) {
  V v_u_2436 = args[0];
  V v_val_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2436);
  V v_x1_2437 = heff_tr(heff_call(v_val_248, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nom: {
    V v_x_2438 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    return v_x_2438;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2440 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    return v_x_2440;
  }
  default: return heff_nomatch(v_x1_2437);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args) {
  V v_c_2461 = args[0];
  V v_infos_2462 = heff_take_field(v_c_2461, 0);
  V v_recovered_2463 = heff_take_field(v_c_2461, 1);
  V v_poisoned_2464 = heff_take_field(v_c_2461, 2);
  V v_metas_2465 = heff_take_field(v_c_2461, 3);
  V v_nextMeta_2466 = heff_take_field(v_c_2461, 4);
  V v_postponed_2467 = heff_take_field(v_c_2461, 5);
  V v_trace_2468 = heff_get_n(v_c_2461, 6, 8);
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_2462, v_recovered_2463, v_poisoned_2464, v_metas_2465, v_nextMeta_2466, v_postponed_2467, v_trace_2468, NTAG(TAG_Nothing)});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args) {
  V v_c_2482 = args[0];
  return heff_get_n(v_c_2482, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args) {
  V v_x_2486 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_stx_247 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_body_2458 = heff_env(self)[5];
  V v_hd_2459 = heff_env(self)[6];
  V v_k_2460 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24109;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2487 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 2);
    switch (heff_tag_of(v_x11_2487)) {
    case TAG_DeclEquations: {
      V v_x113_2491 = heff_field(v_x11_2487, 2);
      heff_take_n(v_x11_2487, 4ULL, 5);
      switch (heff_tag_of(v_x113_2491)) {
      case TAG_AsDefinition: {
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_AsInstance: {
        v_t_24109 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x113_2491);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2487, 0ULL, 5);
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2487, 0ULL, 4);
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2487, 0ULL, 3);
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2487, 0ULL, 2);
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2487, 0ULL, 1);
      v_t_24109 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2487);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_24110 = (g_heff_2eelab_2eunify_2ezonker(v_x_2486));
  V v_t_24111 = heff_tr(heff_call(heff_get_n(v_t_24110, 1, 2), 1, (V[]){v_stx_247}));
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_d_243; V a_3 = v_t_24109; V a_4 = v_t_24111; V a_5 = v_x_2486; V a_6 = v_body_2458; V a_7 = v_hd_2459; V a_8 = v_k_2460; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2486); heff_drop_rec(v_hd_2459, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args) {
  V v_x_2481 = args[0];
  V v_hd_2459 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_stx_247 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_body_2458 = heff_env(self)[6];
  V v_k_2460 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2481);
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo)})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2459, 2)), 1, (V[]){v_t_2484}));
  V f_ = heff_dup(heff_rfield(v_hd_2459, 1));
  heff_room[0] = v_t_2485;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam10, 1, 8, (V[]){v_n_242, v_stx_247, v_key_240, v_g_241, v_d_243, v_body_2458, v_hd_2459, v_k_2460});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args) {
  V v_x_2476 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_hd_2459 = heff_env(self)[2];
  V v_stx_247 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2458 = heff_env(self)[6];
  V v_k_2460 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2476);
  V v_t_2479;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2478 = heff_dup(heff_field(v_n_242, 1));
    v_t_2479 = v_s_2478;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2480 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2479, heff_dup(v_d_243)));
  V f_ = v_c_2480;
  heff_room[0] = heff_dup(v_hd_2459);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam8, 1, 8, (V[]){v_hd_2459, v_n_242, v_stx_247, v_key_240, v_g_241, v_d_243, v_body_2458, v_k_2460});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args) {
  V v_x_2472 = args[0];
  V v_hd_2459 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_stx_247 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2458 = heff_env(self)[6];
  V v_k_2460 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2473 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2472, NTAG(TAG_MkUnit)});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2459, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})}));
  V f_ = heff_dup(heff_rfield(v_hd_2459, 1));
  heff_room[0] = v_t_2475;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam7, 1, 8, (V[]){v_n_242, v_d_243, v_hd_2459, v_stx_247, v_key_240, v_g_241, v_body_2458, v_k_2460});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args) {
  V v_body_2458 = args[0];
  V v_hd_2459 = args[1];
  V v_k_2460 = args[2];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_stx_247 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo)})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2459, 2)), 1, (V[]){v_t_2470}));
  V f_ = heff_dup(heff_rfield(v_hd_2459, 1));
  args[0] = v_t_2471;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam6, 1, 8, (V[]){v_hd_2459, v_n_242, v_d_243, v_stx_247, v_key_240, v_g_241, v_body_2458, v_k_2460});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_val_248 = heff_env(self)[3];
  V v_stx_247 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2427);
  V v_t_2430;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2429 = heff_dup(heff_field(v_n_242, 1));
    v_t_2430 = v_s_2429;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2431 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2432;
  if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
    heff_drop(v_t_2431);
    v_t_2432 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2431);
    v_t_2432 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_t_2433 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2434;
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_t_2433);
    v_t_2434 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2433);
    v_t_2434 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_h_2435 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2434});
  V v_t_2441 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2435, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam3, 1, 1, (V[]){heff_dup(v_val_248)}), NTAG(TAG_Nothing)));
  V v_x1_2442 = heff_tr(heff_call(heff_dup(v_val_248), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nom: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2443;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2442, 0ULL, 1);
    v_t_2446 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2445 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_t_2447 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(v_stx_247), v_t_2441, v_t_2446});
  V v_t_2448 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2432, v_t_2447, heff_dup(v_g_241)));
  V v_t_2449 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2450;
  if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
    heff_drop(v_t_2449);
    v_t_2450 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2449);
    v_t_2450 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_x1_2451 = heff_tr(heff_call(v_val_248, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2455;
  switch (heff_tag_of(v_x1_2451)) {
  case TAG_Nom: {
    V v_x_2452 = heff_field(v_x1_2451, 0);
    heff_take_n(v_x1_2451, 1ULL, 1);
    v_t_2455 = v_x_2452;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2451, 0ULL, 1);
    v_t_2455 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2454 = heff_field(v_x1_2451, 0);
    heff_take_n(v_x1_2451, 1ULL, 1);
    v_t_2455 = v_x_2454;
    break;
  }
  default: heff_nomatch(v_x1_2451);
  }
  V v_t_2456 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2430, heff_dup(v_d_243), v_t_2448, v_t_2450, v_t_2455));
  V v_t_2457 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2456}));
  return (g_co_2ebind_24s1421083649x484987773(v_t_2457, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam4, 3, 5, (V[]){v_n_242, v_d_243, v_stx_247, v_key_240, v_g_241}), v_z_245, v_z_246));
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_val_248 = heff_env(self)[4];
  V v_stx_247 = heff_env(self)[5];
  V v_g_241 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2424 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2426;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam2, 1, 8, (V[]){v_n_242, v_d_243, v_key_240, v_val_248, v_stx_247, v_g_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243) {
top: ;
  V v_globals_244 = heff_take_field(v_acc_241, 0);
  V v_keys_245 = heff_take_field(v_acc_241, 2);
  V v_broken_246 = heff_take_field(v_acc_241, 3);
  V v_watches_247 = heff_take_field(v_acc_241, 4);
  V v_tests_248 = heff_take_field(v_acc_241, 5);
  V v_spans_249 = heff_take_field(v_acc_241, 6);
  V v_infos_2410 = heff_take_field(v_acc_241, 7);
  V v_trace_2411 = heff_get_n(v_acc_241, 8, 9);
  V v_t_2434;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2412 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_DeclEquations: {
      V v_f_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 5);
      v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_f_2414});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2419 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 5);
      v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2424 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 4);
      v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2424});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2428 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 3);
      v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2428});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2431 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 2);
      v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2431});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2434 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2412);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  switch (heff_tag_of(v_t_2434)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    heff_drop(v_n_242);
    return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_244, v_diags_243, v_keys_245, v_broken_246, v_watches_247, v_tests_248, v_spans_249, v_infos_2410, v_trace_2411});
  }
  case TAG_Just: {
    V v_x_2435 = heff_field(v_t_2434, 0);
    heff_take_n(v_t_2434, 1ULL, 1);
    V v_k_2436 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2435)}));
    V v_t_2437 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2435)}));
    V v_g_2439;
    if (heff_strEq_c_lent(v_t_2437, v_x_2435, 1)) {
      v_g_2439 = v_globals_244;
    } else {
      V v_t_2438 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2435)}));
      v_g_2439 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2435), v_t_2438, v_globals_244));
    }
    V v_order_2440 = heff_take_field(v_g_2439, 0);
    V v_entries_2441 = heff_take_field(v_g_2439, 1);
    V v_aliases_2442 = heff_take_field(v_g_2439, 2);
    V v_broken_2443 = heff_take_field(v_g_2439, 3);
    V v_ambiguous_2444 = heff_take_field(v_g_2439, 4);
    V v_places_2445 = heff_take_field(v_g_2439, 5);
    V v_hidden_2446 = heff_take_field(v_g_2439, 6);
    V v_instances_2447 = heff_get_n(v_g_2439, 7, 8);
    V v_t_2448 = (g_std_2emap_2einsert_24s93785294x875597928(v_broken_2443, v_k_2436, NTAG(TAG_MkUnit)));
    V v_globals_2449 = (g_heff_2eelab_2etoplevel_2ewithBrokenInstance(v_kf_240, heff_dup(v_n_242), heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_order_2440, v_entries_2441, v_aliases_2442, v_t_2448, v_ambiguous_2444, v_places_2445, v_hidden_2446, v_instances_2447})));
    V v_t_2452;
    switch (heff_tag_of(v_n_242)) {
    case TAG_At: {
      V v_s_2451 = heff_field(v_n_242, 1);
      heff_take_n(v_n_242, 2ULL, 2);
      v_t_2452 = v_s_2451;
      break;
    }
    default: heff_nomatch(v_n_242);
    }
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2435, v_t_2452}), v_broken_246});
    return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_2449, v_diags_243, v_keys_245, v_t_2453, v_watches_247, v_tests_248, v_spans_249, v_infos_2410, v_trace_2411});
  }
  default: return heff_nomatch(v_t_2434);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopBroken(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ekeepSt_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ekeepSt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ekeepSt_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241) {
top: ;
  V v_infos_242 = heff_take_field(v_acc_241, 7);
  V v_trace_243 = heff_take_field(v_acc_241, 8);
  V v_globals_244 = heff_take_field(v_acc_241, 0);
  V v_diags_245 = heff_take_field(v_acc_241, 1);
  V v_keys_246 = heff_take_field(v_acc_241, 2);
  V v_broken_247 = heff_take_field(v_acc_241, 3);
  V v_watches_248 = heff_take_field(v_acc_241, 4);
  V v_tests_249 = heff_take_field(v_acc_241, 5);
  V v_spans_2410 = heff_get_n(v_acc_241, 6, 9);
  V v_t_2414;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_2411 = heff_field(v_st_240, 0);
    v_t_2414 = heff_dup(v_c_2411);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_infos_2426 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(v_infos_242, heff_clo_n(g_heff_2eelab_2etoplevel_2ekeepSt_lam0, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get_n(v_t_2414, 0, 8)));
  V v_t_2430;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_2427 = heff_field(v_st_240, 0);
    v_t_2430 = heff_dup(v_c_2427);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_trace_2431 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2430, 6, 8), v_trace_243));
  return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_244, v_diags_245, v_keys_246, v_broken_247, v_watches_248, v_tests_249, v_spans_2410, v_infos_2426, v_trace_2431});
}
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ekeepSt(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ekeepSt_lam1(V self, V *args) {
  V v_u_2421 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_ty_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2421);
  V v_t_2425;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_2422 = heff_field(v_st_240, 0);
    heff_take_n(v_st_240, 1ULL, 3);
    v_t_2425 = v_c_2422;
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V f_ = v_ty_2420;
  args[0] = heff_get_n(v_t_2425, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ekeepSt_lam0(V self, V *args) {
  V v_n_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2416 = heff_take_field(v_n_2415, 0);
  V v_name_2417 = heff_take_field(v_n_2415, 1);
  V v_key_2418 = heff_take_field(v_n_2415, 2);
  V v_member_2419 = heff_take_field(v_n_2415, 3);
  V v_ty_2420 = heff_get_n(v_n_2415, 4, 5);
  return heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_span_2416, v_name_2417, v_key_2418, v_member_2419, heff_clo_n(g_heff_2eelab_2etoplevel_2ekeepSt_lam1, 1, 2, (V[]){v_st_240, v_ty_2420})});
}
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(V v_lit_240, V v_lit_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 1)));
    V v_diags_245 = (g_heff_2eelab_2etoplevel_2eonceEach(NTAG(TAG_Nil), v_t_244));
    V v_keys_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 2)));
    V v_broken_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 3)));
    V v_watches_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 4)));
    V v_tests_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 5)));
    V v_spans_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 6)));
    V v_infos_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 7)));
    V v_trace_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 8)));
    return ({ V rv_1 = v_diags_245; V rv_2 = v_keys_246; V rv_3 = v_broken_247; V rv_4 = v_watches_248; V rv_5 = v_tests_249; V rv_6 = v_spans_2410; V rv_7 = v_infos_2411; V rv_8 = v_trace_2412; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2413 = heff_field(v_x3_243, 0);
    V v_rest_2414 = heff_field(v_x3_243, 1);
    V v_t_2416 = (g_heff_2eelab_2etoplevel_2etopOne(heff_clo_n(g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_lam0, 1, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_acc_242, heff_dup(v_n_2413)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2416;
    V t_3 = v_rest_2414;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_acc_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_strAppend(v_lit_240, heff_strAppend(v_lit_241, v_a_2415));
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V v_acc_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_st_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_244, heff_dup(v_acc_240)));
      V v_t_2410;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_247 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2410 = v_c_247;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2410, 1, 8)));
      V v_t_2412 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2411));
      V v_t_2413;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_rec(v_d_245, 5);
        v_t_2413 = NTAG(TAG_Nil);
      } else {
        v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2414 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_240, 1, 9), v_t_2412, v_t_2413));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(v_t_246, v_n_241, v_t_2414);
    }
    case TAG_Right: {
      V v_r_2415 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_isInstance_2416 = heff_take_field(v_r_2415, 3);
      V v_key_2417 = heff_take_field(v_r_2415, 1);
      V v_name_2418 = heff_take_field(v_r_2415, 0);
      V v_prim_2419 = heff_take_field(v_r_2415, 2);
      V v_entry_2420 = heff_take_field(v_r_2415, 4);
      V v_failed_2421 = heff_get_n(v_r_2415, 5, 6);
      V v_g_2422 = heff_take_field(v_acc_240, 0);
      V v_t_2427;
      if ((heff_dup(v_prim_2419) == NTAG(TAG_True))) {
        heff_drop(v_prim_2419);
        HeffT2 v_t_2423 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_2422, 1), v_key_2417));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop(v_entry_2420);
            V v_e_2426 = v_field_2425;
            heff_drop(v_e_2426);
            v_t_2427 = v_g_2422;
          } else {
            heff_drop(v_field_2425);
            v_t_2427 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2417), v_entry_2420, v_g_2422));
          }
        }
      } else {
        heff_drop(v_prim_2419);
        v_t_2427 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2417), v_entry_2420, v_g_2422));
      }
      V v_t_2428 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_name_2418), heff_dup(v_key_2417), v_t_2427));
      V v_globals_2429 = ({ V a_0 = v_isInstance_2416; V a_1 = heff_dup(v_key_2417); V a_2 = v_name_2418; V a_3 = v_t_2428; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(a_0, a_1, a_2, a_3)); heff_drop(v_isInstance_2416); r_; });
      V v_t_2433;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2430 = heff_dup(heff_field(v_st_244, 0));
        v_t_2433 = v_c_2430;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2433, 1, 8)));
      V v_t_2435 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2434));
      V v_t_2437;
      switch (heff_tag_of(v_failed_2421)) {
      case TAG_Nothing: {
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2436 = heff_field(v_failed_2421, 0);
        heff_take_n(v_failed_2421, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2436, 0)), MK_INT(-1LL))) {
          heff_drop_rec(v_d_2436, 5);
          v_t_2437 = NTAG(TAG_Nil);
        } else {
          v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2436, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_failed_2421);
      }
      V v_diags_2438 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_240, 1), v_t_2435, v_t_2437));
      V v_t_2442;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2439 = heff_dup(heff_field(v_st_244, 0));
        v_t_2442 = v_c_2439;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2454 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_240, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam0, 1, 1, (V[]){heff_dup(v_st_244)}), heff_get_n(v_t_2442, 0, 8)));
      V v_t_2458;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2455 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2458 = v_c_2455;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2459 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2458, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_key_2417, heff_take_field(v_acc_240, 2)});
      V v_t_2463;
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_n_241, 1);
        heff_take_n(v_n_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_n_241);
      }
      V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_MkPair, 2, (V[]){v_name_2418, v_t_2463}), heff_take_field(v_acc_240, 6)});
      return ({ V rv_0 = v_globals_2429; V rv_1 = v_diags_2438; V rv_2 = v_t_2460; V rv_6 = v_t_2464; V rv_7 = v_infos_2454; V rv_8 = v_trace_2459; V rr_ = heff_rec_reuse_nf(v_acc_240, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 4032u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam1(V self, V *args) {
  V v_u_2449 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_ty_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2449);
  V v_t_2453;
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_2450 = heff_field(v_st_244, 0);
    heff_take_n(v_st_244, 1ULL, 3);
    v_t_2453 = v_c_2450;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V f_ = v_ty_2448;
  args[0] = heff_get_n(v_t_2453, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam0(V self, V *args) {
  V v_n_2443 = args[0];
  V v_st_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_span_2444 = heff_take_field(v_n_2443, 0);
  V v_name_2445 = heff_take_field(v_n_2443, 1);
  V v_key_2446 = heff_take_field(v_n_2443, 2);
  V v_member_2447 = heff_take_field(v_n_2443, 3);
  V v_ty_2448 = heff_get_n(v_n_2443, 4, 5);
  return heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_span_2444, v_name_2445, v_key_2446, v_member_2447, heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam1, 1, 2, (V[]){v_st_244, v_ty_2448})});
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_24tok1_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2etopBroken_24tok1(V v_tok_240, V v_kf_241, V v_acc_242, V v_n_243, V v_diags_244) {
top: ;
  V v_globals_245 = heff_take_field(v_acc_242, 0);
  V v_keys_246 = heff_take_field(v_acc_242, 2);
  V v_broken_247 = heff_take_field(v_acc_242, 3);
  V v_watches_248 = heff_take_field(v_acc_242, 4);
  V v_tests_249 = heff_take_field(v_acc_242, 5);
  V v_spans_2410 = heff_take_field(v_acc_242, 6);
  V v_infos_2411 = heff_take_field(v_acc_242, 7);
  V v_trace_2412 = heff_get_n(v_acc_242, 8, 9);
  V v_t_2435;
  switch (heff_tag_of(v_n_243)) {
  case TAG_At: {
    V v_x11_2413 = heff_dup(heff_field(v_n_243, 0));
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_DeclEquations: {
      V v_f_2415 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 5);
      v_t_2435 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_f_2415});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2420 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 5);
      v_t_2435 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_x_2420});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2425 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 4);
      v_t_2435 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_x_2425});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2429 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 3);
      v_t_2435 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_x_2429});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2432 = heff_field(v_x11_2413, 0);
      heff_take_n(v_x11_2413, 1ULL, 2);
      v_t_2435 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_x_2432});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2413, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      v_t_2435 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2413);
    }
    break;
  }
  default: heff_nomatch(v_n_243);
  }
  switch (heff_tag_of(v_t_2435)) {
  case TAG_Nothing: {
    heff_drop(v_kf_241);
    heff_drop(v_n_243);
    return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_245, v_diags_244, v_keys_246, v_broken_247, v_watches_248, v_tests_249, v_spans_2410, v_infos_2411, v_trace_2412});
  }
  case TAG_Just: {
    V v_x_2436 = heff_field(v_t_2435, 0);
    heff_take_n(v_t_2435, 1ULL, 1);
    V v_k_2437 = heff_tr(heff_call(heff_dup(v_kf_241), 1, (V[]){heff_dup(v_x_2436)}));
    V v_t_2438 = heff_tr(heff_call(heff_dup(v_kf_241), 1, (V[]){heff_dup(v_x_2436)}));
    V v_g_2440;
    if (heff_strEq_c_lent(v_t_2438, v_x_2436, 1)) {
      v_g_2440 = v_globals_245;
    } else {
      V v_t_2439 = heff_tr(heff_call(heff_dup(v_kf_241), 1, (V[]){heff_dup(v_x_2436)}));
      v_g_2440 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2436), v_t_2439, v_globals_245));
    }
    V v_order_2441 = heff_take_field(v_g_2440, 0);
    V v_entries_2442 = heff_take_field(v_g_2440, 1);
    V v_aliases_2443 = heff_take_field(v_g_2440, 2);
    V v_broken_2444 = heff_take_field(v_g_2440, 3);
    V v_ambiguous_2445 = heff_take_field(v_g_2440, 4);
    V v_places_2446 = heff_take_field(v_g_2440, 5);
    V v_hidden_2447 = heff_take_field(v_g_2440, 6);
    V v_instances_2448 = heff_get_n(v_g_2440, 7, 8);
    V v_t_2449 = (g_std_2emap_2einsert_24s93785294x875597928(v_broken_2444, v_k_2437, NTAG(TAG_MkUnit)));
    V v_globals_2450 = (g_heff_2eelab_2etoplevel_2ewithBrokenInstance(v_kf_241, heff_dup(v_n_243), heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_order_2441, v_entries_2442, v_aliases_2443, v_t_2449, v_ambiguous_2445, v_places_2446, v_hidden_2447, v_instances_2448})));
    V v_t_2453;
    switch (heff_tag_of(v_n_243)) {
    case TAG_At: {
      V v_s_2452 = heff_field(v_n_243, 1);
      heff_take_n(v_n_243, 2ULL, 2);
      v_t_2453 = v_s_2452;
      break;
    }
    default: heff_nomatch(v_n_243);
    }
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2436, v_t_2453}), v_broken_247});
    return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_2450, v_diags_244, v_keys_246, v_t_2454, v_watches_248, v_tests_249, v_spans_2410, v_infos_2411, v_trace_2412});
  }
  default: return heff_nomatch(v_t_2435);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopBroken_24tok1(a[0], a[1], a[2], a[3], a[4]);
}