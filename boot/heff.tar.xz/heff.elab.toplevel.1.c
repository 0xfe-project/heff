// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588 6711
#define TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009 47022
#define TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422 47314
#define TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054 60739
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IsCheckable 22614
#define TAG_LNil 57394
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLitBytes 43891
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_evidence 1128105991
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_right 309870134
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_unreached 121683306
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_name__level[] = {LBL_name, LBL_level};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
HeffT2 g_heff_2eelab_2erename_2erkOf_24cpr(V);
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2efindOr(V, V, V);
V g_heff_2eelab_2erules_2efindOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindOr_clo;
HeffT1 g_heff_2eelab_2erules_2efindOr_24cpr(V, V, V);
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2eformRecord(V, V);
V g_heff_2eelab_2erules_2eformRecord_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformRecord_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2elamSynthesised(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elamSynthesised_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elamSynthesised_clo;
V g_heff_2eelab_2erules_2elazySyn(V, V);
V g_heff_2eelab_2erules_2elazySyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazySyn_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432_clo;
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2etupleSyn(V, V, V, V);
V g_heff_2eelab_2erules_2etupleSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etupleSyn_clo;
V g_heff_2eelab_2erules_2eunboundIn(V, V, V);
V g_heff_2eelab_2erules_2eunboundIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunboundIn_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2eupdateOf(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateOf_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2earmsSaid(V, V, V);
V g_heff_2eelab_2etoplevel_2earmsSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2earmsSaid_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo;
V g_heff_2eelab_2etoplevel_2emetasInV(V, V);
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2emetasInV_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2epairOfHoles(V);
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_24generate0(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_24generate0_clo;
V g_heff_2eelab_2etoplevel_2eshownV(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eshownV_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etagSpanOf(V, V);
V g_heff_2eelab_2etoplevel_2etagSpanOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpanOf_clo;
V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo;
V g_heff_2eelab_2etoplevel_2etupleTypeRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleTypeRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleTypeRev_clo;
V g_heff_2eelab_2etoplevel_2etupleValueRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_24rec0_get(void);
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2edecodeEv(V);
V g_heff_2eelab_2evalue_2edecodeEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeEv_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(V);
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2ekeepIf_24s2115931744x466898799(V, V);
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2etraverse_24s2094958103x549422471(V);
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2094958103x549422471_clo;
V g_prelude_2etraverse_24s390133767x1613463851(V);
V g_prelude_2etraverse_24s390133767x1613463851_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s390133767x1613463851_clo;
V g_prelude_2etraverse_24s515579549x140669784(V, V, V);
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s515579549x140669784_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s1088265102x456727156(V, V);
V g_std_2eordmap_2elookup_24s1088265102x456727156_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s1088265102x456727156_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2eelab_2etoplevel_2eselfTermF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTermF_24generate0_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eselfTermF_24generate0(V v_xs_240, V v_r_241, V v_d_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if (((((int64_t)0ULL) <= v_i_243) && (heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_p_245 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_243));
      V v_t_2410;
      switch (heff_tag_of(v_p_245)) {
      case TAG_MkPair: {
        V v_xs_246 = heff_field(v_p_245, 0);
        V v_b_247 = heff_field(v_p_245, 1);
        V v_t_248 = heff_intAdd_lent(v_d_242, heff_arrayLength_lent(v_xs_246, 0), 2);
        V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){v_t_248, heff_dup(v_b_247)}));
        v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_246), v_t_249});
        break;
      }
      default: heff_nomatch(v_p_245);
      }
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      V t_2 = v_d_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2410);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_d_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_241, 2);
      heff_drop(v_d_242);
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_p_245 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_243));
    V v_t_2410;
    switch (heff_tag_of(v_p_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_p_245, 0);
      V v_b_247 = heff_field(v_p_245, 1);
      V v_t_248 = heff_intAdd_lent(v_d_242, heff_arrayLength_lent(v_xs_246, 0), 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){v_t_248, heff_dup(v_b_247)}));
      v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_246), v_t_249});
      break;
    }
    default: heff_nomatch(v_p_245);
    }
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    V t_2 = v_d_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2410);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    heff_drop_rec(v_r_241, 2);
    heff_drop(v_d_242);
    return v_a_244;
  }
}
V g_heff_2eelab_2etoplevel_2eselfTermF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eselfTermF_24generate0(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etagSpanOf_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etagSpanOf_str1, 1, "_");
Clo g_heff_2eelab_2etoplevel_2etagSpanOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpanOf_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etagSpanOf(V v_p_240, V v_acc_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(v_p_240));
  {
    V v_field_243 = v_t_242.f[0];
    heff_drop(v_t_242.f[1]);
    V v_t_245 = v_field_243;
    switch (heff_tag_of(v_t_245)) {
    case TAG_At: {
      V v_it1_246 = heff_field(v_t_245, 0);
      V v_tsp_247 = heff_field(v_t_245, 1);
      V v_ru_24t_245_24At = heff_take_reuse_n(v_t_245, 3ULL, 2);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_PatVar: {
        V v_it11_248 = heff_field(v_it1_246, 0);
        heff_take_n(v_it1_246, 1ULL, 1);
        if (heff_strEq_c(v_it11_248, ((V)&g_heff_2eelab_2etoplevel_2etagSpanOf_str0))) {
          return heff_tag_at_n(v_ru_24t_245_24At, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2etagSpanOf_str1), v_tsp_247}), v_acc_241});
        } else {
          heff_drop(v_tsp_247);
          heff_drop_cell(v_ru_24t_245_24At, 2);
          return v_acc_241;
        }
      }
      case TAG_PatTag: {
        V v_x_249 = heff_field(v_it1_246, 0);
        heff_take_n(v_it1_246, 1ULL, 3);
        return heff_tag_at_n(v_ru_24t_245_24At, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_tsp_247}), v_acc_241});
      }
      case TAG_PatOp: {
        heff_take_n(v_it1_246, 0ULL, 3);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatFloat: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatString: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatBinary: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatRune: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatRecord: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatWord: {
        heff_take_n(v_it1_246, 0ULL, 1);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      case TAG_PatAs: {
        heff_take_n(v_it1_246, 0ULL, 3);
        heff_drop(v_tsp_247);
        heff_drop_cell(v_ru_24t_245_24At, 2);
        return v_acc_241;
      }
      default: return heff_nomatch(v_it1_246);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
}
V g_heff_2eelab_2etoplevel_2etagSpanOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSpanOf(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2etagSpans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpans_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSpans(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x111_243, 0);
        V v_t_247 = (g_heff_2eelab_2etoplevel_2etagSpans(v_rest_242));
        return (g_heff_2eelab_2etoplevel_2etagSpanOf(heff_dup(v_p_245), v_t_247));
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2etagSpans(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str0, 12, "builtin.Lazy");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str9, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str10, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str11, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str13, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str14, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str15, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str16, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str17, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str18, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str19, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str20, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str21, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str22, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str23, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str24, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str25, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str26, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str27, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str28, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str29, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str30, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str31, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str32, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str33, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str34, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str35, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str36, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str37, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str38, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str39, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str40, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str41, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str42, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str43, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str44, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str45, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str46, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str47, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str48, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str49, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str50, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str51, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str52, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str53, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str54, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str55, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str56, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str57, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str58, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str59, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str60, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str61, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str62, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str63, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str64, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str65, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str66, 13, "prelude.Bytes");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str67, 13, "prelude.Bytes");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str68, 64, "a binary is of the prelude's `Bytes`, which is not in scope here");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str69, 1, "r");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str70, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str71, 0, "");
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24, 1, 0};
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27, 1, 0};
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33, 1, 0};
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam32(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam35(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam34(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam38(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam37(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam36(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam41(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam40(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam39(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam49(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam48(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam47(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam46(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam45(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam44(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam43(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam42(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam56(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam57(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam55(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam54(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam53(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam52(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam51(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam50(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam58(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam59(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam65(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam64(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam63(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam62(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam61(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam60(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam67(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam66(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry, 10, 0};

V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V v_tag_240, V v_sp_241, V v_c_242, V v_sp_243, V v_i_244, V v_x4_245, V v_sp_246, V v_x3_247, V v_cs_248, V v_n_249) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009: ;
    heff_drop(v_n_249);
    switch (heff_tag_of(v_c_242)) {
    case TAG_At: {
      V v_c1_2410 = heff_dup(heff_field(v_c_242, 0));
      switch (heff_tag_of(v_c1_2410)) {
      case TAG_CInf: {
        V v_i_2412 = heff_field(v_c1_2410, 0);
        heff_take_n(v_c1_2410, 1ULL, 1);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_c_242)) {
        case TAG_At: {
          heff_take_n(v_c_242, 0ULL, 2);
          V v_c_2415 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_2412));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam0, 2, 2, (V[]){v_c_2415, v_sp_241});
        }
        default: return heff_nomatch(v_c_242);
        }
      }
      case TAG_CType: {
        heff_take_n(v_c1_2410, 0ULL, 1);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        V v_c_2421 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_c_242));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam2, 2, 2, (V[]){v_c_2421, v_sp_241});
      }
      case TAG_CLam: {
        heff_take_n(v_c1_2410, 0ULL, 3);
        heff_drop(v_sp_241);
        V v_n_2430 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str1);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str2);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2430;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_c1_2410, 0ULL, 3);
        heff_drop(v_sp_241);
        V v_n_2434 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str3);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str4);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2434;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CAnnLam: {
        heff_take_n(v_c1_2410, 0ULL, 4);
        heff_drop(v_sp_241);
        V v_n_2439 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str5);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str6);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2439;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CTag: {
        heff_take_n(v_c1_2410, 0ULL, 3);
        heff_drop(v_sp_241);
        V v_n_2443 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str7);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str8);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2443;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CStruct: {
        V v_ru_24c1_2410_24CStruct = heff_take_reuse_n(v_c1_2410, 0ULL, 1);
        heff_drop(v_sp_241);
        V v_n_2445 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_at_n(v_ru_24c1_2410_24CStruct, TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str9);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str10);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2445;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CMatch: {
        heff_take_n(v_c1_2410, 0ULL, 2);
        heff_drop(v_sp_241);
        V v_n_2448 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str11);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str12);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2448;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CLetIn: {
        heff_take_n(v_c1_2410, 0ULL, 2);
        heff_drop(v_sp_241);
        V v_n_2451 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str13);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str14);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2451;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CLocal: {
        heff_take_n(v_c1_2410, 0ULL, 2);
        heff_drop(v_sp_241);
        V v_n_2454 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str15);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str16);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2454;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CAbandon: {
        heff_drop(v_sp_241);
        V v_n_2455 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_n(TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str17);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str18);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2455;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      case TAG_CNominal: {
        V v_ru_24c1_2410_24CNominal = heff_take_reuse_n(v_c1_2410, 0ULL, 1);
        heff_drop(v_sp_241);
        V v_n_2457 = (g_heff_2esyntax_2epresyntax_2etoInferable(heff_tag_at_n(v_ru_24c1_2410_24CNominal, TAG_IsCheckable, 1, (V[]){v_c_242})));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
        V t_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str19);
        V t_2 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str20);
        V t_3 = v_sp_243;
        V t_4 = v_i_244;
        V t_5 = v_x4_245;
        V t_6 = v_sp_246;
        V t_7 = v_x3_247;
        V t_8 = v_cs_248;
        V t_9 = v_n_2457;
        v_tag_240 = t_0;
        v_sp_241 = t_1;
        v_c_242 = t_2;
        v_sp_243 = t_3;
        v_i_244 = t_4;
        v_x4_245 = t_5;
        v_sp_246 = t_6;
        v_x3_247 = t_7;
        v_cs_248 = t_8;
        v_n_249 = t_9;
        goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
      }
      default: return heff_nomatch(v_c1_2410);
      }
    }
    default: return heff_nomatch(v_c_242);
    }
  }
  case TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054: ;
    heff_drop(v_n_249);
    switch (heff_tag_of(v_x4_245)) {
    case TAG_Nil: {
      heff_drop_rec(v_sp_243, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
      V t_1 = v_sp_241;
      V t_2 = v_c_242;
      V t_3 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str21);
      V t_4 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str22);
      V t_5 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str23);
      V t_6 = v_sp_246;
      V t_7 = v_x3_247;
      V t_8 = v_cs_248;
      V t_9 = v_i_244;
      v_tag_240 = t_0;
      v_sp_241 = t_1;
      v_c_242 = t_2;
      v_sp_243 = t_3;
      v_i_244 = t_4;
      v_x4_245 = t_5;
      v_sp_246 = t_6;
      v_x3_247 = t_7;
      v_cs_248 = t_8;
      v_n_249 = t_9;
      goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
    }
    case TAG_Cons: {
      V v_z_2458 = heff_field(v_x4_245, 0);
      V v_x42_2459 = heff_field(v_x4_245, 1);
      V v_ru_24x4_245_24Cons = heff_take_reuse_n(v_x4_245, 3ULL, 2);
      heff_drop(v_sp_241);
      heff_drop(v_c_242);
      heff_drop(v_sp_246);
      heff_drop(v_x3_247);
      heff_drop(v_cs_248);
      switch (heff_tag_of(v_x42_2459)) {
      case TAG_Nil: {
        heff_drop(v_i_244);
        V v_n_2468;
        switch (heff_tag_of(v_x42_2459)) {
        case TAG_Nil: {
          V v_t_2460 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
          v_n_2468 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){v_t_2460, heff_dup(v_sp_243)});
          break;
        }
        case TAG_Cons: {
          V v_r_2461 = heff_dup(heff_field(v_x42_2459, 0));
          V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x42_2459));
          V v_t_2466;
          switch (heff_tag_of(v_r_2461)) {
          case TAG_At: {
            V v_s_2465 = heff_field(v_r_2461, 1);
            heff_take_n(v_r_2461, 2ULL, 2);
            v_t_2466 = v_s_2465;
            break;
          }
          default: heff_nomatch(v_r_2461);
          }
          V v_t_2467 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_2466, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          v_n_2468 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_2463}), v_t_2467});
          break;
        }
        default: heff_nomatch(v_x42_2459);
        }
        V v_c_2469 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n_2468));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam4, 2, 3, (V[]){v_c_2469, v_z_2458, v_sp_243});
      }
      case TAG_Cons: {
        V v_x422_2480 = heff_dup(heff_field(v_x42_2459, 1));
        switch (heff_tag_of(v_x422_2480)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x4_245_24Cons, 2);
          switch (heff_tag_of(v_x42_2459)) {
          case TAG_Cons: {
            heff_take_n(v_x42_2459, 0ULL, 2);
            V v_c_2483 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_244));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam8, 2, 3, (V[]){v_c_2483, v_z_2458, v_sp_243});
          }
          default: return heff_nomatch(v_x42_2459);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x422_2480, 0ULL, 2);
          heff_drop(v_i_244);
          V v_n_24103;
          switch (heff_tag_of(v_x42_2459)) {
          case TAG_Nil: {
            V v_t_2495 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
            v_n_24103 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){v_t_2495, heff_dup(v_sp_243)});
            break;
          }
          case TAG_Cons: {
            V v_r_2496 = heff_dup(heff_field(v_x42_2459, 0));
            V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x42_2459));
            V v_t_24101;
            switch (heff_tag_of(v_r_2496)) {
            case TAG_At: {
              V v_s_24100 = heff_field(v_r_2496, 1);
              heff_take_n(v_r_2496, 2ULL, 2);
              v_t_24101 = v_s_24100;
              break;
            }
            default: heff_nomatch(v_r_2496);
            }
            V v_t_24102 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_24101, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            v_n_24103 = heff_tag_at_n(v_ru_24x4_245_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_2498}), v_t_24102});
            break;
          }
          default: heff_nomatch(v_x42_2459);
          }
          V v_c_24104 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n_24103));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam12, 2, 3, (V[]){v_c_24104, v_z_2458, v_sp_243});
        }
        default: return heff_nomatch(v_x422_2480);
        }
      }
      default: return heff_nomatch(v_x42_2459);
      }
    }
    default: return heff_nomatch(v_x4_245);
    }
  }
  case TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422: ;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nil: {
      heff_drop(v_n_249);
      V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
      V v_n_24115 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24114));
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
      V t_1 = v_sp_241;
      V t_2 = v_c_242;
      V t_3 = v_sp_243;
      V t_4 = v_i_244;
      V t_5 = v_x4_245;
      V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str24);
      V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str25);
      V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str26);
      V t_9 = v_n_24115;
      v_tag_240 = t_0;
      v_sp_241 = t_1;
      v_c_242 = t_2;
      v_sp_243 = t_3;
      v_i_244 = t_4;
      v_x4_245 = t_5;
      v_sp_246 = t_6;
      v_x3_247 = t_7;
      v_cs_248 = t_8;
      v_n_249 = t_9;
      goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
    }
    case TAG_Cons: {
      V v_x31_24116 = heff_field(v_x3_247, 0);
      V v_x32_24117 = heff_field(v_x3_247, 1);
      heff_take_n(v_x3_247, 3ULL, 2);
      switch (heff_tag_of(v_x31_24116)) {
      case TAG_At: {
        V v_x311_24118 = heff_field(v_x31_24116, 0);
        heff_take_n(v_x31_24116, 1ULL, 2);
        switch (heff_tag_of(v_x311_24118)) {
        case TAG_CInf: {
          V v_i_24120 = heff_field(v_x311_24118, 0);
          heff_take_n(v_x311_24118, 1ULL, 1);
          switch (heff_tag_of(v_x32_24117)) {
          case TAG_Nil: {
            heff_drop(v_n_249);
            heff_drop(v_i_24120);
            V v_t_24121 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
            V v_n_24122 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24121));
            V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
            V t_1 = v_sp_241;
            V t_2 = v_c_242;
            V t_3 = v_sp_243;
            V t_4 = v_i_244;
            V t_5 = v_x4_245;
            V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str27);
            V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str28);
            V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str29);
            V t_9 = v_n_24122;
            v_tag_240 = t_0;
            v_sp_241 = t_1;
            v_c_242 = t_2;
            v_sp_243 = t_3;
            v_i_244 = t_4;
            v_x4_245 = t_5;
            v_sp_246 = t_6;
            v_x3_247 = t_7;
            v_cs_248 = t_8;
            v_n_249 = t_9;
            goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
          }
          case TAG_Cons: {
            heff_take_n(v_x32_24117, 0ULL, 2);
            heff_drop_rec(v_sp_243, 2);
            heff_drop(v_i_244);
            heff_drop(v_x4_245);
            V v_t_24125 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
            V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054);
            V t_1 = v_sp_241;
            V t_2 = v_c_242;
            V t_3 = v_sp_246;
            V t_4 = v_i_24120;
            V t_5 = v_t_24125;
            V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str30);
            V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str31);
            V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str32);
            V t_9 = v_n_249;
            v_tag_240 = t_0;
            v_sp_241 = t_1;
            v_c_242 = t_2;
            v_sp_243 = t_3;
            v_i_244 = t_4;
            v_x4_245 = t_5;
            v_sp_246 = t_6;
            v_x3_247 = t_7;
            v_cs_248 = t_8;
            v_n_249 = t_9;
            goto top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInfRev_24s1605684347x540416054;
          }
          default: return heff_nomatch(v_x32_24117);
          }
        }
        case TAG_CType: {
          heff_take_n(v_x311_24118, 0ULL, 1);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24128 = (g_heff_2eelab_2etoplevel_2etupleTypeRev(v_sp_246, v_t_24127));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str33);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str34);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str35);
          V t_9 = v_n_24128;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CLam: {
          heff_take_n(v_x311_24118, 0ULL, 3);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24132 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24133 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24132));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str36);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str37);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str38);
          V t_9 = v_n_24133;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CImplicitLam: {
          heff_take_n(v_x311_24118, 0ULL, 3);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24137 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24138 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24137));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str39);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str40);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str41);
          V t_9 = v_n_24138;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CAnnLam: {
          heff_take_n(v_x311_24118, 0ULL, 4);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24143 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24144 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24143));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str42);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str43);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str44);
          V t_9 = v_n_24144;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CTag: {
          heff_take_n(v_x311_24118, 0ULL, 3);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24148 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24149 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24148));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str45);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str46);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str47);
          V t_9 = v_n_24149;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CStruct: {
          heff_take_n(v_x311_24118, 0ULL, 1);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24151 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24152 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24151));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str48);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str49);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str50);
          V t_9 = v_n_24152;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CMatch: {
          heff_take_n(v_x311_24118, 0ULL, 2);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24155 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24156 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24155));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str51);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str52);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str53);
          V t_9 = v_n_24156;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CLetIn: {
          heff_take_n(v_x311_24118, 0ULL, 2);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24159 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24160 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24159));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str54);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str55);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str56);
          V t_9 = v_n_24160;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CLocal: {
          heff_take_n(v_x311_24118, 0ULL, 2);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24163 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24164 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24163));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str57);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str58);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str59);
          V t_9 = v_n_24164;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CAbandon: {
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24165 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24166 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24165));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str60);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str61);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str62);
          V t_9 = v_n_24166;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        case TAG_CNominal: {
          heff_take_n(v_x311_24118, 0ULL, 1);
          heff_drop(v_n_249);
          heff_drop(v_x32_24117);
          V v_t_24168 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_248));
          V v_n_24169 = (g_heff_2eelab_2etoplevel_2etupleValueRev(v_sp_246, v_t_24168));
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str63);
          V t_7 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str64);
          V t_8 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str65);
          V t_9 = v_n_24169;
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588;
        }
        default: return heff_nomatch(v_x311_24118);
        }
      }
      default: return heff_nomatch(v_x31_24116);
      }
    }
    default: return heff_nomatch(v_x3_247);
    }
  }
  case TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588: {
    top_TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588: ;
    switch (heff_tag_of(v_n_249)) {
    case TAG_At: {
      V v_n1_27_24170 = heff_dup(heff_field(v_n_249, 0));
      switch (heff_tag_of(v_n1_27_24170)) {
      case TAG_IVar: {
        V v_x_24172 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24174 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam16, 2, 2, (V[]){v_x_24172, v_sp_24174});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_INotationVar: {
        V v_x_24184 = heff_field(v_n1_27_24170, 0);
        V v_ksp_24185 = heff_field(v_n1_27_24170, 1);
        V v_said_24186 = heff_field(v_n1_27_24170, 2);
        heff_take_n(v_n1_27_24170, 7ULL, 3);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24188 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam18, 2, 4, (V[]){v_sp_24188, v_x_24184, v_said_24186, v_ksp_24185});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IInt: {
        V v_i_24200 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24202 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V v_x_24203 = (g_heff_2eelab_2erules_2enumLitSyn_24s1434482260x843431432(v_i_24200, v_sp_24202));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam20, 2, 1, (V[]){v_x_24203});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IFloat: {
        V v_x_24206 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24208 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V v_x_24209 = (g_heff_2eelab_2erules_2enumLitSyn_24s1634007014x1386672(v_x_24206, v_sp_24208));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21, 2, 1, (V[]){v_x_24209});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IString: {
        V v_s_24212 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam22, 2, 1, (V[]){v_s_24212});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IBytes: {
        V v_s_24223 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24225 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam25, 2, 2, (V[]){v_sp_24225, v_s_24223});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IPrim: {
        V v_p_24259 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24261 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam30, 2, 2, (V[]){v_sp_24261, v_p_24259});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IRune: {
        V v_c_24265 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam31, 2, 1, (V[]){v_c_24265});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IApp: {
        V v_h_24276 = heff_field(v_n1_27_24170, 0);
        V v_args_24277 = heff_field(v_n1_27_24170, 1);
        heff_take_n(v_n1_27_24170, 3ULL, 2);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24280 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_h_24276)));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam34, 2, 3, (V[]){v_c_24280, v_h_24276, v_args_24277});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IAnn: {
        V v_n0_24287 = heff_field(v_n1_27_24170, 0);
        V v_n1_24288 = heff_field(v_n1_27_24170, 1);
        heff_take_n(v_n1_27_24170, 3ULL, 2);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24291 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n0_24287));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam36, 2, 2, (V[]){v_c_24291, v_n1_24288});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ISpec: {
        V v_n0_24298 = heff_field(v_n1_27_24170, 0);
        V v_x_24299 = heff_field(v_n1_27_24170, 1);
        V v_v_24301 = heff_field(v_n1_27_24170, 3);
        heff_take_n(v_n1_27_24170, 11ULL, 4);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        V v_c_24302 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_v_24301));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam39, 2, 4, (V[]){v_c_24302, v_n0_24298, v_n_249, v_x_24299});
      }
      case TAG_IUpdate: {
        V v_n0_24312 = heff_field(v_n1_27_24170, 0);
        V v_fs_24313 = heff_field(v_n1_27_24170, 1);
        heff_take_n(v_n1_27_24170, 3ULL, 2);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24315 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V v_c_24316 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_24312));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam42, 2, 3, (V[]){v_c_24316, v_fs_24313, v_sp_24315});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IAnnLam: {
        V v_x_24344 = heff_field(v_n1_27_24170, 0);
        V v_tyN_24346 = heff_field(v_n1_27_24170, 2);
        V v_body_24347 = heff_field(v_n1_27_24170, 3);
        heff_take_n(v_n1_27_24170, 13ULL, 4);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24350 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_tyN_24346));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam50, 2, 3, (V[]){v_c_24350, v_body_24347, v_x_24344});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_IInvalid: {
        V v_code_24381 = heff_field(v_n1_27_24170, 0);
        V v_why_24382 = heff_field(v_n1_27_24170, 1);
        V v_n1_273_24383 = heff_field(v_n1_27_24170, 2);
        heff_take_n(v_n1_27_24170, 7ULL, 3);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24385 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          switch (heff_tag_of(v_n1_273_24383)) {
          case TAG_Nothing: {
            return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam58, 2, 3, (V[]){v_code_24381, v_why_24382, v_sp_24385});
          }
          case TAG_Just: {
            V v_note_24394 = heff_field(v_n1_273_24383, 0);
            heff_take_n(v_n1_273_24383, 1ULL, 1);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam59, 2, 4, (V[]){v_code_24381, v_why_24382, v_sp_24385, v_note_24394});
          }
          default: return heff_nomatch(v_n1_273_24383);
          }
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_INominal: {
        V v_i_24403 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          heff_take_n(v_n_249, 0ULL, 2);
          V v_c_24406 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_24403));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam60, 2, 1, (V[]){v_c_24406});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ILitEq: {
        V v_x_24429 = heff_field(v_n1_27_24170, 0);
        V v_xsp_24430 = heff_field(v_n1_27_24170, 1);
        V v_eq_24431 = heff_field(v_n1_27_24170, 2);
        V v_lit_24432 = heff_field(v_n1_27_24170, 3);
        heff_take_n(v_n1_27_24170, 15ULL, 4);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_i_244);
        heff_drop(v_x4_245);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24434 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V v_c_24435 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_lit_24432));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam66, 2, 5, (V[]){v_c_24435, v_sp_24434, v_x_24429, v_xsp_24430, v_eq_24431});
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ILazy: {
        V v_c_24440 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_c_242);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24442 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009);
          V t_1 = v_sp_24442;
          V t_2 = v_c_24440;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = v_sp_246;
          V t_7 = v_x3_247;
          V t_8 = v_cs_248;
          V t_9 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str70);
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009;
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      case TAG_ITuple: {
        V v_cs_24443 = heff_field(v_n1_27_24170, 0);
        heff_take_n(v_n1_27_24170, 1ULL, 1);
        heff_drop(v_sp_246);
        heff_drop(v_x3_247);
        heff_drop(v_cs_248);
        switch (heff_tag_of(v_n_249)) {
        case TAG_At: {
          V v_sp_24445 = heff_field(v_n_249, 1);
          heff_take_n(v_n_249, 2ULL, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422);
          V t_1 = v_sp_241;
          V t_2 = v_c_242;
          V t_3 = v_sp_243;
          V t_4 = v_i_244;
          V t_5 = v_x4_245;
          V t_6 = v_sp_24445;
          V t_7 = heff_dup(v_cs_24443);
          V t_8 = v_cs_24443;
          V t_9 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str71);
          v_tag_240 = t_0;
          v_sp_241 = t_1;
          v_c_242 = t_2;
          v_sp_243 = t_3;
          v_i_244 = t_4;
          v_x4_245 = t_5;
          v_sp_246 = t_6;
          v_x3_247 = t_7;
          v_cs_248 = t_8;
          v_n_249 = t_9;
          goto top_TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422;
        }
        default: return heff_nomatch(v_n_249);
        }
      }
      default: return heff_nomatch(v_n1_27_24170);
      }
    }
    default: return heff_nomatch(v_n_249);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = ({ V a_0 = v_sp_241; V a_1 = v_x_2418; V r_ = (g_heff_2eelab_2erules_2elazySyn(a_0, a_1)); heff_drop(v_x_2418); r_; });
  V f_ = v_k_2417;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam1, 1, 2, (V[]){v_sp_241, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  V v_callee_2425 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_241), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str0)));
  heff_clo_take(self, 2);
  V v_t_2426 = ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = v_sp_241; V a_3 = v_callee_2425; V a_4 = v_x_2424; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_callee_2425); r_; });
  V f_ = v_k_2423;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam3, 1, 2, (V[]){v_sp_241, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam7(V self, V *args) {
  V v_x_2477 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_x_2472 = heff_env(self)[1];
  V v_x_2474 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2478 = ({ V a_0 = v_sp_243; V a_1 = v_x_2472; V a_2 = v_x_2474; V a_3 = v_x_2477; V r_ = (g_heff_2eelab_2erules_2etupleSyn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2472); heff_drop(v_x_2477); r_; });
  V f_ = v_k_2471;
  args[0] = v_t_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam6(V self, V *args) {
  V v_x_2474 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_hd_2470 = heff_env(self)[1];
  V v_x_2472 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  V v_t_2475 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_243)));
  V v_t_2476 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2475));
  heff_clo_take(self, 4);
  V f_ = v_t_2476;
  heff_room[0] = v_hd_2470;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam7, 1, 4, (V[]){v_sp_243, v_x_2472, v_x_2474, v_k_2471});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam5(V self, V *args) {
  V v_x_2472 = args[0];
  V v_z_2458 = heff_env(self)[0];
  V v_hd_2470 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_k_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2473 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_z_2458));
  V f_ = v_t_2473;
  heff_room[0] = heff_dup(v_hd_2470);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam6, 1, 4, (V[]){v_sp_243, v_hd_2470, v_x_2472, v_k_2471});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam4(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_c_2469 = heff_env(self)[0];
  V v_z_2458 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2469;
  args[0] = heff_dup(v_hd_2470);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam5, 1, 4, (V[]){v_z_2458, v_hd_2470, v_sp_243, v_k_2471});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam11(V self, V *args) {
  V v_x_2491 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_x_2486 = heff_env(self)[1];
  V v_x_2488 = heff_env(self)[2];
  V v_k_2485 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2492 = ({ V a_0 = v_sp_243; V a_1 = v_x_2486; V a_2 = v_x_2488; V a_3 = v_x_2491; V r_ = (g_heff_2eelab_2erules_2etupleSyn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2486); heff_drop(v_x_2491); r_; });
  V f_ = v_k_2485;
  args[0] = v_t_2492;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam10(V self, V *args) {
  V v_x_2488 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_hd_2484 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_k_2485 = heff_env(self)[3];
  V v_t_2489 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_243)));
  V v_t_2490 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2489));
  heff_clo_take(self, 4);
  V f_ = v_t_2490;
  heff_room[0] = v_hd_2484;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam11, 1, 4, (V[]){v_sp_243, v_x_2486, v_x_2488, v_k_2485});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam9(V self, V *args) {
  V v_x_2486 = args[0];
  V v_z_2458 = heff_env(self)[0];
  V v_hd_2484 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_k_2485 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2487 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_z_2458));
  V f_ = v_t_2487;
  heff_room[0] = heff_dup(v_hd_2484);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam10, 1, 4, (V[]){v_sp_243, v_hd_2484, v_x_2486, v_k_2485});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam8(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_c_2483 = heff_env(self)[0];
  V v_z_2458 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2483;
  args[0] = heff_dup(v_hd_2484);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam9, 1, 4, (V[]){v_z_2458, v_hd_2484, v_sp_243, v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam15(V self, V *args) {
  V v_x_24112 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_x_24107 = heff_env(self)[1];
  V v_x_24109 = heff_env(self)[2];
  V v_k_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24113 = ({ V a_0 = v_sp_243; V a_1 = v_x_24107; V a_2 = v_x_24109; V a_3 = v_x_24112; V r_ = (g_heff_2eelab_2erules_2etupleSyn(a_0, a_1, a_2, a_3)); heff_drop(v_x_24107); heff_drop(v_x_24112); r_; });
  V f_ = v_k_24106;
  args[0] = v_t_24113;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam14(V self, V *args) {
  V v_x_24109 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_hd_24105 = heff_env(self)[1];
  V v_x_24107 = heff_env(self)[2];
  V v_k_24106 = heff_env(self)[3];
  V v_t_24110 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_243)));
  V v_t_24111 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_24110));
  heff_clo_take(self, 4);
  V f_ = v_t_24111;
  heff_room[0] = v_hd_24105;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam15, 1, 4, (V[]){v_sp_243, v_x_24107, v_x_24109, v_k_24106});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam13(V self, V *args) {
  V v_x_24107 = args[0];
  V v_z_2458 = heff_env(self)[0];
  V v_hd_24105 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_k_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24108 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_z_2458));
  V f_ = v_t_24108;
  heff_room[0] = heff_dup(v_hd_24105);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam14, 1, 4, (V[]){v_sp_243, v_hd_24105, v_x_24107, v_k_24106});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam12(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k_24106 = args[1];
  V v_c_24104 = heff_env(self)[0];
  V v_z_2458 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24104;
  args[0] = heff_dup(v_hd_24105);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam13, 1, 4, (V[]){v_z_2458, v_hd_24105, v_sp_243, v_k_24106});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam17(V self, V *args) {
  V v_e_24177 = args[0];
  V v_x_24172 = heff_env(self)[0];
  V v_sp_24174 = heff_env(self)[1];
  V v_t_24178 = heff_get_n(heff_dup(heff_rfield(v_e_24177, 1)), 6, 8);
  V v_t_24179 = ({ V a_0 = v_t_24178; V a_1 = v_x_24172; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_t_24178); r_; });
  V v_t_24180 = (g_heff_2eelab_2erules_2eunboundIn(heff_dup(v_sp_24174), heff_dup(v_x_24172), v_t_24179));
  heff_clo_take(self, 2);
  HeffT1 v_t_24181 = (g_heff_2eelab_2erules_2efindOr_24cpr(v_sp_24174, v_x_24172, v_t_24180));
  {
    V v_field_24182 = v_t_24181.f[0];
    V v_f_24183 = v_field_24182;
    V f_ = v_f_24183;
    args[0] = v_e_24177;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam16(V self, V *args) {
  V v_hd_24175 = args[0];
  V v_k_24176 = args[1];
  V v_x_24172 = heff_env(self)[0];
  V v_sp_24174 = heff_env(self)[1];
  heff_drop(v_hd_24175);
  heff_clo_take(self, 2);
  V f_ = v_k_24176;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam17, 1, 2, (V[]){v_x_24172, v_sp_24174})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam19(V self, V *args) {
  V v_hd_24191 = args[0];
  V v_k2_24192 = args[1];
  V v_said_24186 = heff_env(self)[0];
  V v_ksp_24185 = heff_env(self)[1];
  V v_malg_24193 = heff_take_field(v_hd_24191, 2);
  V v_bind_24194 = heff_get_n(v_hd_24191, 1, 3);
  heff_clo_take(self, 2);
  V v_t_24195 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_said_24186, v_ksp_24185, NTAG(TAG_Nothing)});
  V v_t_24196 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24195})});
  V v_t_24197 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24196})});
  V v_t_24198 = heff_tr(heff_call(v_malg_24193, 1, (V[]){v_t_24197}));
  V f_ = v_bind_24194;
  args[0] = v_t_24198;
  args[1] = v_k2_24192;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam18(V self, V *args) {
  V v_hd_24189 = args[0];
  V v_k_24190 = args[1];
  V v_sp_24188 = heff_env(self)[0];
  V v_x_24184 = heff_env(self)[1];
  V v_said_24186 = heff_env(self)[2];
  V v_ksp_24185 = heff_env(self)[3];
  heff_drop(v_hd_24189);
  heff_clo_take(self, 4);
  V v_t_24199 = (g_heff_2eelab_2erules_2efindOr(v_sp_24188, v_x_24184, heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam19, 2, 2, (V[]){v_said_24186, v_ksp_24185})));
  V f_ = v_k_24190;
  args[0] = v_t_24199;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam20(V self, V *args) {
  V v_hd_24204 = args[0];
  V v_k_24205 = args[1];
  V v_x_24203 = heff_env(self)[0];
  heff_drop(v_hd_24204);
  heff_clo_take(self, 1);
  V f_ = v_k_24205;
  args[0] = v_x_24203;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam21(V self, V *args) {
  V v_hd_24210 = args[0];
  V v_k_24211 = args[1];
  V v_x_24209 = heff_env(self)[0];
  heff_drop(v_hd_24210);
  heff_clo_take(self, 1);
  V f_ = v_k_24211;
  args[0] = v_x_24209;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24(V self, V *args) {
  V v_u_24220 = args[0];
  heff_drop(v_u_24220);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam23(V self, V *args) {
  V v_e_24217 = args[0];
  V v_hd_24218 = args[1];
  V v_k_24219 = args[2];
  V v_s_24212 = heff_env(self)[0];
  heff_drop(v_e_24217);
  heff_drop(v_hd_24218);
  heff_clo_take(self, 1);
  V v_t_24221 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_s_24212}), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam24_clo)});
  V v_t_24222 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24221, NTAG(TAG_VPrimString)});
  V f_ = v_k_24219;
  args[0] = v_t_24222;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam22(V self, V *args) {
  V v_hd_24215 = args[0];
  V v_k_24216 = args[1];
  V v_s_24212 = heff_env(self)[0];
  heff_drop(v_hd_24215);
  heff_clo_take(self, 1);
  V f_ = v_k_24216;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam23, 3, 1, (V[]){v_s_24212})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27(V self, V *args) {
  V v_u_24246 = args[0];
  heff_drop(v_u_24246);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam28(V self, V *args) {
  V v_hd_24249 = args[0];
  V v_k_24250 = args[1];
  V v_x_24248 = heff_env(self)[0];
  heff_drop(v_hd_24249);
  heff_clo_take(self, 1);
  V f_ = v_k_24250;
  args[0] = v_x_24248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam29(V self, V *args) {
  V v_hd_24251 = args[0];
  V v_k2_24252 = args[1];
  V v_sp_24228 = heff_env(self)[0];
  V v_malg_24253 = heff_take_field(v_hd_24251, 2);
  V v_bind_24254 = heff_get_n(v_hd_24251, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24255 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str68), v_sp_24228, NTAG(TAG_Nothing)});
  V v_t_24256 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24255})});
  V v_t_24257 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24256})});
  V v_t_24258 = heff_tr(heff_call(v_malg_24253, 1, (V[]){v_t_24257}));
  V f_ = v_bind_24254;
  args[0] = v_t_24258;
  args[1] = v_k2_24252;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26(V self, V *args) {
  V v_e_24230 = args[0];
  V v_s_24229 = heff_env(self)[0];
  V v_sp_24228 = heff_env(self)[1];
  V v_t_24231 = heff_get_n(heff_get_n(v_e_24230, 1, 8), 1, 8);
  HeffT2 v_t_24232 = ({ V a_0 = v_t_24231; V b_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str66); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_t_24231); heff_drop(b_1); r_; });
  {
    V v_field_24234 = v_t_24232.f[1];
    int64_t v_tag_24233 = ((int64_t)v_t_24232.f[0]);
    if ((v_tag_24233 == ((int64_t)0ULL))) {
      heff_clo_take(self, 2);
      heff_drop(v_sp_24228);
      V v_e_24235 = v_field_24234;
      V v_key_24236 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str67);
      heff_drop(v_key_24236);
      V v_ge_24237 = v_e_24235;
      V v_t_24238 = heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_ge_24237, 2, 4)});
      HeffT2 v_t_24239 = ({ V a_0 = v_t_24238; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop_tag(v_t_24238, 1); r_; });
      {
        V v_field_24241 = v_t_24239.f[1];
        int64_t v_tag_24240 = ((int64_t)v_t_24239.f[0]);
        V v_t_24245;
        if ((v_tag_24240 == ((int64_t)0ULL))) {
          V v_x_24242 = v_field_24241;
          v_t_24245 = v_x_24242;
        } else {
          if ((v_tag_24240 == ((int64_t)1ULL))) {
            V v_x11_24243 = v_field_24241;
            heff_drop(v_x11_24243);
            v_t_24245 = heff_abandon();
          } else {
            V v_x_24244 = v_field_24241;
            v_t_24245 = v_x_24244;
          }
        }
        V v_t_24247 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_s_24229}), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam27_clo)});
        V v_x_24248 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24247, v_t_24245});
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam28, 2, 1, (V[]){v_x_24248});
      }
    } else {
      heff_clo_take(self, 2);
      heff_drop(v_s_24229);
      heff_drop(v_field_24234);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam29, 2, 1, (V[]){v_sp_24228});
    }
  }
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam25(V self, V *args) {
  V v_hd_24226 = args[0];
  V v_k_24227 = args[1];
  V v_sp_24225 = heff_env(self)[0];
  V v_s_24223 = heff_env(self)[1];
  heff_drop(v_hd_24226);
  heff_clo_take(self, 2);
  V v_sp_24228 = v_sp_24225;
  V v_s_24229 = v_s_24223;
  V f_ = v_k_24227;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam26, 1, 2, (V[]){v_s_24229, v_sp_24228})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam30(V self, V *args) {
  V v_hd_24262 = args[0];
  V v_k_24263 = args[1];
  V v_sp_24261 = heff_env(self)[0];
  V v_p_24259 = heff_env(self)[1];
  heff_drop(v_hd_24262);
  heff_clo_take(self, 2);
  V v_t_24264 = (g_heff_2eelab_2erules_2efindPrim(v_sp_24261, v_p_24259));
  V f_ = v_k_24263;
  args[0] = v_t_24264;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33(V self, V *args) {
  V v_u_24273 = args[0];
  heff_drop(v_u_24273);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam32(V self, V *args) {
  V v_e_24270 = args[0];
  V v_hd_24271 = args[1];
  V v_k_24272 = args[2];
  V v_c_24265 = heff_env(self)[0];
  heff_drop(v_e_24270);
  heff_drop(v_hd_24271);
  heff_clo_take(self, 1);
  V v_t_24274 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitRune, 1, (V[]){v_c_24265}), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam33_clo)});
  V v_t_24275 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24274, NTAG(TAG_VPrimRune)});
  V f_ = v_k_24272;
  args[0] = v_t_24275;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam31(V self, V *args) {
  V v_hd_24268 = args[0];
  V v_k_24269 = args[1];
  V v_c_24265 = heff_env(self)[0];
  heff_drop(v_hd_24268);
  heff_clo_take(self, 1);
  V f_ = v_k_24269;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam32, 3, 1, (V[]){v_c_24265})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam35(V self, V *args) {
  V v_x_24283 = args[0];
  V v_h_24276 = heff_env(self)[0];
  V v_args_24277 = heff_env(self)[1];
  V v_hd_24281 = heff_env(self)[2];
  V v_k_24282 = heff_env(self)[3];
  V v_t_24286;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_h_24276)) {
  case TAG_At: {
    V v_s_24285 = heff_field(v_h_24276, 1);
    heff_take_n(v_h_24276, 2ULL, 2);
    v_t_24286 = v_s_24285;
    break;
  }
  default: heff_nomatch(v_h_24276);
  }
  return ({ V a_0 = heff_get_n(v_t_24286, 0, 2); V a_1 = v_x_24283; V a_2 = v_args_24277; V a_3 = v_hd_24281; V a_4 = v_k_24282; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_args_24277); r_; });
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam34(V self, V *args) {
  V v_hd_24281 = args[0];
  V v_k_24282 = args[1];
  V v_c_24280 = heff_env(self)[0];
  V v_h_24276 = heff_env(self)[1];
  V v_args_24277 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24280;
  args[0] = heff_dup(v_hd_24281);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam35, 1, 4, (V[]){v_h_24276, v_args_24277, v_hd_24281, v_k_24282});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam38(V self, V *args) {
  V v_x_24296 = args[0];
  V v_x_24294 = heff_env(self)[0];
  V v_k_24293 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24297 = ({ V a_0 = v_x_24296; V a_1 = v_x_24294; V r_ = (g_heff_2eelab_2erules_2eannot(a_0, a_1)); heff_drop(v_x_24296); heff_drop(v_x_24294); r_; });
  V f_ = v_k_24293;
  args[0] = v_t_24297;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam37(V self, V *args) {
  V v_x_24294 = args[0];
  V v_n1_24288 = heff_env(self)[0];
  V v_hd_24292 = heff_env(self)[1];
  V v_k_24293 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24295 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n1_24288));
  V f_ = v_t_24295;
  heff_room[0] = v_hd_24292;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam38, 1, 2, (V[]){v_x_24294, v_k_24293});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam36(V self, V *args) {
  V v_hd_24292 = args[0];
  V v_k_24293 = args[1];
  V v_c_24291 = heff_env(self)[0];
  V v_n1_24288 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24291;
  args[0] = heff_dup(v_hd_24292);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam37, 1, 3, (V[]){v_n1_24288, v_hd_24292, v_k_24293});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam41(V self, V *args) {
  V v_x_24307 = args[0];
  V v_n_249 = heff_env(self)[0];
  V v_x_24299 = heff_env(self)[1];
  V v_x_24305 = heff_env(self)[2];
  V v_k_24304 = heff_env(self)[3];
  V v_t_24310;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_n_249)) {
  case TAG_At: {
    V v_s_24309 = heff_field(v_n_249, 1);
    heff_take_n(v_n_249, 2ULL, 2);
    v_t_24310 = v_s_24309;
    break;
  }
  default: heff_nomatch(v_n_249);
  }
  V v_t_24311 = ({ V a_0 = v_t_24310; V a_1 = v_x_24307; V a_2 = v_x_24299; V a_3 = v_x_24305; V r_ = (g_heff_2eelab_2erules_2erecordSpec(a_0, a_1, a_2, a_3)); heff_drop(v_x_24307); heff_drop(v_x_24305); r_; });
  V f_ = v_k_24304;
  args[0] = v_t_24311;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam40(V self, V *args) {
  V v_x_24305 = args[0];
  V v_n0_24298 = heff_env(self)[0];
  V v_hd_24303 = heff_env(self)[1];
  V v_n_249 = heff_env(self)[2];
  V v_x_24299 = heff_env(self)[3];
  V v_k_24304 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24306 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_24298));
  V f_ = v_t_24306;
  heff_room[0] = v_hd_24303;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam41, 1, 4, (V[]){v_n_249, v_x_24299, v_x_24305, v_k_24304});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam39(V self, V *args) {
  V v_hd_24303 = args[0];
  V v_k_24304 = args[1];
  V v_c_24302 = heff_env(self)[0];
  V v_n0_24298 = heff_env(self)[1];
  V v_n_249 = heff_env(self)[2];
  V v_x_24299 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24302;
  args[0] = heff_dup(v_hd_24303);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam40, 1, 5, (V[]){v_n0_24298, v_hd_24303, v_n_249, v_x_24299, v_k_24304});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam49(V self, V *args) {
  V v_x_24342 = args[0];
  V v_k_24331 = heff_env(self)[0];
  V v_a_24341 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_24331;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24342, v_a_24341});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam48(V self, V *args) {
  V v_x_24339 = args[0];
  V v_sp_24321 = heff_env(self)[0];
  V v_r_24325 = heff_env(self)[1];
  V v_e_24327 = heff_env(self)[2];
  V v_fs_24326 = heff_env(self)[3];
  V v_hd_24330 = heff_env(self)[4];
  V v_k_24331 = heff_env(self)[5];
  switch (heff_tag_of(v_x_24339)) {
  case TAG_MkPair: {
    V v_g_24340 = heff_field(v_x_24339, 0);
    V v_a_24341 = heff_field(v_x_24339, 1);
    heff_take_n(v_x_24339, 3ULL, 2);
    heff_clo_take(self, 6);
    return (g_heff_2eelab_2erules_2eupdateOf(v_sp_24321, v_r_24325, v_e_24327, v_g_24340, heff_dup(v_a_24341), v_fs_24326, v_hd_24330, heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam49, 1, 2, (V[]){v_k_24331, v_a_24341})));
  }
  default: return heff_nomatch(v_x_24339);
  }
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam47(V self, V *args) {
  V v_x_24332 = args[0];
  V v_e_24327 = heff_env(self)[0];
  V v_sp_24321 = heff_env(self)[1];
  V v_hd_24330 = heff_env(self)[2];
  V v_r_24325 = heff_env(self)[3];
  V v_fs_24326 = heff_env(self)[4];
  V v_k_24331 = heff_env(self)[5];
  V v_t_24335;
  switch (heff_tag_of(v_x_24332)) {
  case TAG_MkPair: {
    V v_x_24333 = heff_dup(heff_field(v_x_24332, 0));
    v_t_24335 = v_x_24333;
    break;
  }
  default: heff_nomatch(v_x_24332);
  }
  V v_t_24338;
  switch (heff_tag_of(v_x_24332)) {
  case TAG_MkPair: {
    V v_y_24337 = heff_field(v_x_24332, 1);
    heff_take_n(v_x_24332, 2ULL, 2);
    v_t_24338 = v_y_24337;
    break;
  }
  default: heff_nomatch(v_x_24332);
  }
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_24327), heff_dup(v_sp_24321), v_t_24335, v_t_24338, heff_dup(v_hd_24330), heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam48, 1, 6, (V[]){v_sp_24321, v_r_24325, v_e_24327, v_fs_24326, v_hd_24330, v_k_24331})));
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam46(V self, V *args) {
  V v_hd_24330 = args[0];
  V v_k_24331 = args[1];
  V v_c_24329 = heff_env(self)[0];
  V v_e_24327 = heff_env(self)[1];
  V v_sp_24321 = heff_env(self)[2];
  V v_r_24325 = heff_env(self)[3];
  V v_fs_24326 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24329;
  args[0] = heff_dup(v_hd_24330);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam47, 1, 6, (V[]){v_e_24327, v_sp_24321, v_hd_24330, v_r_24325, v_fs_24326, v_k_24331});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam45(V self, V *args) {
  V v_e_24327 = args[0];
  V v_s_24322 = heff_env(self)[0];
  V v_sp_24321 = heff_env(self)[1];
  V v_r_24325 = heff_env(self)[2];
  V v_fs_24326 = heff_env(self)[3];
  V v_c_24329;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_s_24322)) {
  case TAG_MkSyn: {
    V v_f_24328 = heff_field(v_s_24322, 0);
    heff_take_n(v_s_24322, 1ULL, 1);
    v_c_24329 = heff_tr(heff_call(v_f_24328, 1, (V[]){heff_dup(v_e_24327)}));
    break;
  }
  default: heff_nomatch(v_s_24322);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam46, 2, 5, (V[]){v_c_24329, v_e_24327, v_sp_24321, v_r_24325, v_fs_24326});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam44(V self, V *args) {
  V v_x_24320 = args[0];
  V v_sp_24315 = heff_env(self)[0];
  V v_x_24319 = heff_env(self)[1];
  V v_fs_24313 = heff_env(self)[2];
  V v_k_24318 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_sp_24321 = v_sp_24315;
  V v_s_24322 = v_x_24319;
  V v_t_24323 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_24313));
  V v_t_24324 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24323; V r_ = (g_list_2efoldl_24s1991317015x801331450(a_0, a_1)); heff_drop(v_t_24323); r_; });
  V v_r_24325 = ({ V a_0 = v_t_24324; V a_1 = ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_str69); V r_ = (g_heff_2eelab_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_24324); r_; });
  V v_fs_24326 = v_x_24320;
  V v_x_24343 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam45, 1, 4, (V[]){v_s_24322, v_sp_24321, v_r_24325, v_fs_24326})});
  V f_ = v_k_24318;
  args[0] = v_x_24343;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam43(V self, V *args) {
  V v_x_24319 = args[0];
  V v_fs_24313 = heff_env(self)[0];
  V v_hd_24317 = heff_env(self)[1];
  V v_sp_24315 = heff_env(self)[2];
  V v_k_24318 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_prelude_2etraverse_24s515579549x140669784(heff_dup(v_fs_24313), v_hd_24317, heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam44, 1, 4, (V[]){v_sp_24315, v_x_24319, v_fs_24313, v_k_24318})));
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam42(V self, V *args) {
  V v_hd_24317 = args[0];
  V v_k_24318 = args[1];
  V v_c_24316 = heff_env(self)[0];
  V v_fs_24313 = heff_env(self)[1];
  V v_sp_24315 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24316;
  args[0] = heff_dup(v_hd_24317);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam43, 1, 4, (V[]){v_fs_24313, v_hd_24317, v_sp_24315, v_k_24318});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam56(V self, V *args) {
  V v_v_24370 = args[0];
  V v_scope_27_24371 = args[1];
  V v_z_24372 = args[2];
  V v_z_24373 = args[3];
  V v_body_24358 = heff_env(self)[0];
  V v_e_24359 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_body_24358)) {
  case TAG_MkSyn: {
    V v_f_24374 = heff_field(v_body_24358, 0);
    heff_take_n(v_body_24358, 1ULL, 1);
    V v_t_24375 = heff_take_field(v_e_24359, 2);
    V v_t_24378;
    switch (heff_tag_of(v_t_24375)) {
    case TAG_ForNominative: {
      heff_drop(v_v_24370);
      v_t_24378 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_24376 = heff_field(v_t_24375, 0);
      V v_sp_24377 = heff_field(v_t_24375, 1);
      V v_ru_24t_24375_24ForDescriptive = heff_take_reuse_n(v_t_24375, 3ULL, 2);
      v_t_24378 = heff_tag_re_n(v_ru_24t_24375_24ForDescriptive, TAG_ForDescriptive, 2, 1ULL, (V[]){v_h_24376, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24377, v_v_24370})});
      break;
    }
    default: heff_nomatch(v_t_24375);
    }
    V v_t_24379 = ({ V rv_0 = v_scope_27_24371; V rv_2 = v_t_24378; V rr_ = heff_rec_reuse_nf(v_e_24359, 250ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65484u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
    V f_ = v_f_24374;
    args[0] = v_t_24379;
    args[1] = v_z_24372;
    args[2] = v_z_24373;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  default: return heff_nomatch(v_body_24358);
  }
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam57(V self, V *args) {
  V v_x_24380 = args[0];
  V v_e_24359 = heff_env(self)[0];
  V v_x_24356 = heff_env(self)[1];
  V v_x_24364 = heff_env(self)[2];
  V v_hd_24362 = heff_env(self)[3];
  V v_k_24363 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_e_24359; V a_1 = v_x_24356; V a_2 = v_x_24364; V a_3 = v_x_24380; V a_4 = v_hd_24362; V a_5 = v_k_24363; V r_ = (g_heff_2eelab_2erules_2elamSynthesised(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_hd_24362); r_; });
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam55(V self, V *args) {
  V v_x_24364 = args[0];
  V v_x_24356 = heff_env(self)[0];
  V v_e_24359 = heff_env(self)[1];
  V v_body_24358 = heff_env(self)[2];
  V v_hd_24362 = heff_env(self)[3];
  V v_k_24363 = heff_env(self)[4];
  V v_x1_24365 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_24364, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24369;
  switch (heff_tag_of(v_x1_24365)) {
  case TAG_Nom: {
    V v_x_24366 = heff_field(v_x1_24365, 0);
    heff_take_n(v_x1_24365, 1ULL, 1);
    v_t_24369 = v_x_24366;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24365, 0ULL, 1);
    v_t_24369 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24368 = heff_field(v_x1_24365, 0);
    heff_take_n(v_x1_24365, 1ULL, 1);
    v_t_24369 = v_x_24368;
    break;
  }
  default: heff_nomatch(v_x1_24365);
  }
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_24356), v_t_24369, heff_dup(heff_rfield(v_e_24359, 0)), heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam56, 4, 2, (V[]){v_body_24358, heff_dup(v_e_24359)}), heff_dup(v_hd_24362), heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam57, 1, 5, (V[]){v_e_24359, v_x_24356, v_x_24364, v_hd_24362, v_k_24363})));
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam54(V self, V *args) {
  V v_hd_24362 = args[0];
  V v_k_24363 = args[1];
  V v_c_24361 = heff_env(self)[0];
  V v_x_24356 = heff_env(self)[1];
  V v_e_24359 = heff_env(self)[2];
  V v_body_24358 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24361;
  args[0] = heff_dup(v_hd_24362);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam55, 1, 5, (V[]){v_x_24356, v_e_24359, v_body_24358, v_hd_24362, v_k_24363});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam53(V self, V *args) {
  V v_e_24359 = args[0];
  V v_dom_24357 = heff_env(self)[0];
  V v_x_24356 = heff_env(self)[1];
  V v_body_24358 = heff_env(self)[2];
  V v_c_24361;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_dom_24357)) {
  case TAG_MkTyp: {
    V v_f_24360 = heff_field(v_dom_24357, 0);
    heff_take_n(v_dom_24357, 1ULL, 1);
    v_c_24361 = heff_tr(heff_call(v_f_24360, 1, (V[]){heff_dup(v_e_24359)}));
    break;
  }
  default: heff_nomatch(v_dom_24357);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam54, 2, 4, (V[]){v_c_24361, v_x_24356, v_e_24359, v_body_24358});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam52(V self, V *args) {
  V v_x_24355 = args[0];
  V v_x_24344 = heff_env(self)[0];
  V v_x_24353 = heff_env(self)[1];
  V v_k_24352 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_24356 = v_x_24344;
  V v_dom_24357 = v_x_24353;
  V v_body_24358 = v_x_24355;
  V f_ = v_k_24352;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam53, 1, 3, (V[]){v_dom_24357, v_x_24356, v_body_24358})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam51(V self, V *args) {
  V v_x_24353 = args[0];
  V v_body_24347 = heff_env(self)[0];
  V v_hd_24351 = heff_env(self)[1];
  V v_x_24344 = heff_env(self)[2];
  V v_k_24352 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24354 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_body_24347));
  V f_ = v_t_24354;
  heff_room[0] = v_hd_24351;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam52, 1, 3, (V[]){v_x_24344, v_x_24353, v_k_24352});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam50(V self, V *args) {
  V v_hd_24351 = args[0];
  V v_k_24352 = args[1];
  V v_c_24350 = heff_env(self)[0];
  V v_body_24347 = heff_env(self)[1];
  V v_x_24344 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24350;
  args[0] = heff_dup(v_hd_24351);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam51, 1, 4, (V[]){v_body_24347, v_hd_24351, v_x_24344, v_k_24352});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam58(V self, V *args) {
  V v_hd_24386 = args[0];
  V v_k2_24387 = args[1];
  V v_code_24381 = heff_env(self)[0];
  V v_why_24382 = heff_env(self)[1];
  V v_sp_24385 = heff_env(self)[2];
  V v_malg_24388 = heff_take_field(v_hd_24386, 2);
  V v_bind_24389 = heff_get_n(v_hd_24386, 1, 3);
  heff_clo_take(self, 3);
  V v_t_24390 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_24381), NTAG(TAG_SError), v_why_24382, v_sp_24385, NTAG(TAG_Nothing)});
  V v_t_24391 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24390})});
  V v_t_24392 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24391})});
  V v_t_24393 = heff_tr(heff_call(v_malg_24388, 1, (V[]){v_t_24392}));
  V f_ = v_bind_24389;
  args[0] = v_t_24393;
  args[1] = v_k2_24387;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam59(V self, V *args) {
  V v_hd_24395 = args[0];
  V v_k2_24396 = args[1];
  V v_code_24381 = heff_env(self)[0];
  V v_why_24382 = heff_env(self)[1];
  V v_sp_24385 = heff_env(self)[2];
  V v_note_24394 = heff_env(self)[3];
  V v_malg_24397 = heff_take_field(v_hd_24395, 2);
  V v_bind_24398 = heff_get_n(v_hd_24395, 1, 3);
  heff_clo_take(self, 4);
  V v_t_24399 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_24381), NTAG(TAG_SError), v_why_24382, v_sp_24385, heff_tag_n(TAG_Just, 1, (V[]){v_note_24394})});
  V v_t_24400 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24399})});
  V v_t_24401 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24400})});
  V v_t_24402 = heff_tr(heff_call(v_malg_24397, 1, (V[]){v_t_24401}));
  V f_ = v_bind_24398;
  args[0] = v_t_24402;
  args[1] = v_k2_24396;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam65(V self, V *args) {
  V v_u_24422 = args[0];
  V v_val_24421 = heff_env(self)[0];
  heff_drop(v_u_24422);
  heff_clo_take(self, 1);
  V v_x1_24423 = heff_tr(heff_call(v_val_24421, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24427;
  switch (heff_tag_of(v_x1_24423)) {
  case TAG_Nom: {
    V v_x_24424 = heff_field(v_x1_24423, 0);
    heff_take_n(v_x1_24423, 1ULL, 1);
    v_t_24427 = v_x_24424;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24423, 0ULL, 1);
    v_t_24427 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24426 = heff_field(v_x1_24423, 0);
    heff_take_n(v_x1_24423, 1ULL, 1);
    v_t_24427 = v_x_24426;
    break;
  }
  default: heff_nomatch(v_x1_24423);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_24427});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam64(V self, V *args) {
  V v_x_24417 = args[0];
  V v_k_24416 = heff_env(self)[0];
  switch (heff_tag_of(v_x_24417)) {
  case TAG_MkPair: {
    V v_res_24418 = heff_field(v_x_24417, 0);
    V v_a_24419 = heff_field(v_x_24417, 1);
    heff_take_n(v_x_24417, 3ULL, 2);
    V v_stx_24420 = heff_take_field(v_res_24418, 0);
    V v_val_24421 = heff_take_field(v_res_24418, 1);
    V v_t_24428 = ({ V rv_0 = heff_tag_n(TAG_SIs, 1, (V[]){v_stx_24420}); V rv_1 = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam65, 1, 1, (V[]){v_val_24421}); V rr_ = heff_rec_reuse_nf(v_res_24418, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    heff_clo_take(self, 1);
    V f_ = v_k_24416;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24428, v_a_24419});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24417);
  }
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam63(V self, V *args) {
  V v_hd_24415 = args[0];
  V v_k_24416 = args[1];
  V v_c_24414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24414;
  args[0] = v_hd_24415;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam64, 1, 1, (V[]){v_k_24416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam62(V self, V *args) {
  V v_e_24411 = args[0];
  V v_j_24410 = heff_env(self)[0];
  V v_c_24414;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_j_24410)) {
  case TAG_MkSyn: {
    V v_f_24412 = heff_field(v_j_24410, 0);
    heff_take_n(v_j_24410, 1ULL, 1);
    V v_t_24413 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_24411, 251ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_24414 = heff_tr(heff_call(v_f_24412, 1, (V[]){v_t_24413}));
    break;
  }
  default: heff_nomatch(v_j_24410);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam63, 2, 1, (V[]){v_c_24414});
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam61(V self, V *args) {
  V v_x_24409 = args[0];
  V v_k_24408 = heff_env(self)[0];
  V v_j_24410 = v_x_24409;
  heff_clo_take(self, 1);
  V f_ = v_k_24408;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam62, 1, 1, (V[]){v_j_24410})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam60(V self, V *args) {
  V v_hd_24407 = args[0];
  V v_k_24408 = args[1];
  V v_c_24406 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24406;
  args[0] = v_hd_24407;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam61, 1, 1, (V[]){v_k_24408});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam67(V self, V *args) {
  V v_x_24438 = args[0];
  V v_sp_24434 = heff_env(self)[0];
  V v_x_24429 = heff_env(self)[1];
  V v_xsp_24430 = heff_env(self)[2];
  V v_eq_24431 = heff_env(self)[3];
  V v_k_24437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24439 = (g_heff_2eelab_2erules_2elitEq(v_sp_24434, v_x_24429, v_xsp_24430, v_eq_24431, v_x_24438));
  V f_ = v_k_24437;
  args[0] = v_t_24439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam66(V self, V *args) {
  V v_hd_24436 = args[0];
  V v_k_24437 = args[1];
  V v_c_24435 = heff_env(self)[0];
  V v_sp_24434 = heff_env(self)[1];
  V v_x_24429 = heff_env(self)[2];
  V v_xsp_24430 = heff_env(self)[3];
  V v_eq_24431 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24435;
  args[0] = v_hd_24436;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_lam67, 1, 5, (V[]){v_sp_24434, v_x_24429, v_xsp_24430, v_eq_24431, v_k_24437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11, 3, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam32(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam38(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam37(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam36(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam35(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam34(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam33(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam44(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam43(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam42(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam41(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam40(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam39(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TPi: {
      V v_b_243 = heff_field(v_x21_241, 0);
      V v_codN_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(v_b_243));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0, 2, 2, (V[]){v_c_245, v_codN_244});
    }
    case TAG_TSig: {
      V v_fields_2412 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_2413 = (g_prelude_2etraverse_24s2094958103x549422471(v_fields_2412));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3, 2, 1, (V[]){v_c_2413});
    }
    case TAG_TSum: {
      V v_variantNs_2423 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_2424 = (g_prelude_2etraverse_24s390133767x1613463851(v_variantNs_2423));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8, 2, 1, (V[]){v_c_2424});
    }
    case TAG_TType: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo);
    }
    case TAG_TInt: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo);
    }
    case TAG_TFloat: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo);
    }
    case TAG_TString: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14_clo);
    }
    case TAG_TRune: {
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15_clo);
    }
    case TAG_TArray: {
      V v_a0_2446 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_2447 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_a0_2446));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16, 2, 1, (V[]){v_c_2447});
    }
    case TAG_TFixed: {
      V v_w_2467 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22, 2, 1, (V[]){v_w_2467});
    }
    case TAG_TInf: {
      V v_i_2475 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24TInf = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24114;
      switch (heff_tag_of(v_i_2475)) {
      case TAG_At: {
        V v_x11_2476 = heff_dup(heff_field(v_i_2475, 0));
        switch (heff_tag_of(v_x11_2476)) {
        case TAG_IVar: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_INotationVar: {
          heff_take_n(v_x11_2476, 0ULL, 3);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IInt: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IFloat: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IString: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IBytes: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IPrim: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IRune: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IApp: {
          heff_take_n(v_x11_2476, 0ULL, 2);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IAnn: {
          heff_take_n(v_x11_2476, 0ULL, 2);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_ISpec: {
          heff_take_n(v_x11_2476, 0ULL, 4);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IUpdate: {
          heff_take_n(v_x11_2476, 0ULL, 2);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IAnnLam: {
          heff_take_n(v_x11_2476, 0ULL, 4);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_IInvalid: {
          heff_take_n(v_x11_2476, 0ULL, 3);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_INominal: {
          V v_i_24105 = heff_field(v_x11_2476, 0);
          heff_take_n(v_x11_2476, 1ULL, 1);
          switch (heff_tag_of(v_i_2475)) {
          case TAG_At: {
            v_t_24114 = v_i_24105;
            break;
          }
          default: heff_nomatch(v_i_2475);
          }
          break;
        }
        case TAG_ILitEq: {
          heff_take_n(v_x11_2476, 0ULL, 4);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_ILazy: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        case TAG_ITuple: {
          heff_take_n(v_x11_2476, 0ULL, 1);
          v_t_24114 = heff_dup(v_i_2475);
          break;
        }
        default: heff_nomatch(v_x11_2476);
        }
        break;
      }
      default: heff_nomatch(v_i_2475);
      }
      V v_t_24151;
      switch (heff_tag_of(v_t_24114)) {
      case TAG_At: {
        V v_x11_24115 = heff_field(v_t_24114, 0);
        V v_sp_24116 = heff_field(v_t_24114, 1);
        heff_take_n(v_t_24114, 3ULL, 2);
        switch (heff_tag_of(v_x11_24115)) {
        case TAG_IVar: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_INotationVar: {
          heff_take_n(v_x11_24115, 0ULL, 3);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IInt: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IFloat: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IString: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IBytes: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IPrim: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IRune: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IApp: {
          heff_take_n(v_x11_24115, 0ULL, 2);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IAnn: {
          heff_take_n(v_x11_24115, 0ULL, 2);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ISpec: {
          heff_take_n(v_x11_24115, 0ULL, 4);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IUpdate: {
          heff_take_n(v_x11_24115, 0ULL, 2);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IAnnLam: {
          heff_take_n(v_x11_24115, 0ULL, 4);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IInvalid: {
          heff_take_n(v_x11_24115, 0ULL, 3);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_INominal: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ILitEq: {
          heff_take_n(v_x11_24115, 0ULL, 4);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ILazy: {
          heff_take_n(v_x11_24115, 0ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24TInf, 1);
          heff_drop(v_sp_24116);
          v_t_24151 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ITuple: {
          V v_cs_24150 = heff_field(v_x11_24115, 0);
          heff_take_n(v_x11_24115, 1ULL, 1);
          v_t_24151 = heff_tag_at_n(v_ru_24x21_241_24TInf, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_MkPair, 2, (V[]){v_sp_24116, v_cs_24150})});
          break;
        }
        default: heff_nomatch(v_x11_24115);
        }
        break;
      }
      default: heff_nomatch(v_t_24114);
      }
      switch (heff_tag_of(v_t_24151)) {
      case TAG_Nothing: {
        V v_c_24152 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_2475));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25, 2, 2, (V[]){v_c_24152, v_x22_242});
      }
      case TAG_Just: {
        V v_it1_24157 = heff_field(v_t_24151, 0);
        heff_take_n(v_t_24151, 1ULL, 1);
        heff_drop(v_x22_242);
        switch (heff_tag_of(v_it1_24157)) {
        case TAG_MkPair: {
          V v_isp_24158 = heff_field(v_it1_24157, 0);
          V v_cs_24159 = heff_field(v_it1_24157, 1);
          heff_take_n(v_it1_24157, 3ULL, 2);
          V v_t_24196;
          switch (heff_tag_of(v_i_2475)) {
          case TAG_At: {
            V v_x11_24160 = heff_field(v_i_2475, 0);
            heff_take_n(v_i_2475, 1ULL, 2);
            switch (heff_tag_of(v_x11_24160)) {
            case TAG_IVar: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_INotationVar: {
              heff_take_n(v_x11_24160, 0ULL, 3);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IInt: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IFloat: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IString: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IBytes: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IPrim: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IRune: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IApp: {
              heff_take_n(v_x11_24160, 0ULL, 2);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_24160, 0ULL, 2);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_24160, 0ULL, 4);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_24160, 0ULL, 2);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_24160, 0ULL, 4);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_24160, 0ULL, 3);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_INominal: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_True);
              break;
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_24160, 0ULL, 4);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_ILazy: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            case TAG_ITuple: {
              heff_take_n(v_x11_24160, 0ULL, 1);
              v_t_24196 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_x11_24160);
            }
            break;
          }
          default: heff_nomatch(v_i_2475);
          }
          V v_c_24197 = ({ V a_0 = v_t_24196; V a_1 = v_isp_24158; V a_2 = v_cs_24159; V r_ = (g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(a_0, a_1, a_2)); heff_drop(v_t_24196); r_; });
          return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27, 2, 1, (V[]){v_c_24197});
        }
        default: return heff_nomatch(v_it1_24157);
        }
      }
      default: return heff_nomatch(v_t_24151);
      }
    }
    case TAG_TChk: {
      V v_ch_24213 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_24214 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_ch_24213));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam33, 2, 1, (V[]){v_c_24214});
    }
    case TAG_TNominal: {
      V v_t_24230 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop(v_x22_242);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_c_24231 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_24230));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam39, 2, 1, (V[]){v_c_24231});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a[0]);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = ({ V a_0 = v_x_248; V a_1 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_k_247;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_codN_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_codN_244));
  V f_ = v_t_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_codN_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1, 1, 3, (V[]){v_codN_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_2417 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = (g_heff_2eelab_2erules_2erecordOf(v_e_2417, v_x_2421));
  V f_ = v_k_2420;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_e_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7, 1, 2, (V[]){v_e_2417, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args) {
  V v_e_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2418 = (g_heff_2eelab_2erules_2eformRecord(heff_dup(v_e_2417), v_x_2416));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6, 2, 2, (V[]){v_c_2418, v_e_2417});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5, 1, 1, (V[]){v_x_2416})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_t_2428 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2427)));
  V v_t_2429 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2427));
  V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_x_2427));
  V v_t_2431 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2428), v_t_2429, heff_arrayFromList(v_t_2430)});
  V v_x_2432 = (g_heff_2eelab_2erules_2esumFormation(v_t_2431));
  heff_clo_take(self, 1);
  V f_ = v_k_2426;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9, 1, 1, (V[]){v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args) {
  V v_e_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k_2437 = args[2];
  heff_drop(v_e_2435);
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_dup(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_24rec0_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args) {
  V v_u_2460 = args[0];
  V v_val_2459 = heff_env(self)[0];
  heff_drop(v_u_2460);
  heff_clo_take(self, 1);
  V v_x1_2461 = heff_tr(heff_call(v_val_2459, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2465;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_Nom: {
    V v_x_2462 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    v_t_2465 = v_x_2462;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2465 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2464 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    v_t_2465 = v_x_2464;
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2465})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args) {
  V v_x_2457 = args[0];
  V v_k_2456 = heff_env(self)[0];
  V v_stx_2458 = heff_take_field(v_x_2457, 0);
  V v_val_2459 = heff_take_field(v_x_2457, 1);
  V v_t_2466 = ({ V rv_0 = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_stx_2458}); V rv_1 = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21, 1, 1, (V[]){v_val_2459}); V rr_ = heff_rec_reuse_nf(v_x_2457, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  heff_clo_take(self, 1);
  V f_ = v_k_2456;
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_c_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2454;
  args[0] = v_hd_2455;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20, 1, 1, (V[]){v_k_2456});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args) {
  V v_e_2452 = args[0];
  V v_a_2451 = heff_env(self)[0];
  V v_c_2454;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2451)) {
  case TAG_MkTyp: {
    V v_f_2453 = heff_field(v_a_2451, 0);
    heff_take_n(v_a_2451, 1ULL, 1);
    v_c_2454 = heff_tr(heff_call(v_f_2453, 1, (V[]){v_e_2452}));
    break;
  }
  default: heff_nomatch(v_a_2451);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19, 2, 1, (V[]){v_c_2454});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_a_2451 = v_x_2450;
  heff_clo_take(self, 1);
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18, 1, 1, (V[]){v_a_2451})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17, 1, 1, (V[]){v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args) {
  V v_u_2473 = args[0];
  V v_w_2467 = heff_env(self)[0];
  heff_drop(v_u_2473);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2467})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args) {
  V v_e_2470 = args[0];
  V v_hd_2471 = args[1];
  V v_k_2472 = args[2];
  V v_w_2467 = heff_env(self)[0];
  heff_drop(v_e_2470);
  heff_drop(v_hd_2471);
  heff_clo_take(self, 1);
  V v_t_2474 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){heff_dup(v_w_2467)}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24, 1, 1, (V[]){v_w_2467})});
  V f_ = v_k_2472;
  args[0] = v_t_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_w_2467 = heff_env(self)[0];
  heff_drop(v_hd_2468);
  heff_clo_take(self, 1);
  V f_ = v_k_2469;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23, 3, 1, (V[]){v_w_2467})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args) {
  V v_x_24155 = args[0];
  V v_x22_242 = heff_env(self)[0];
  V v_k_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24156 = ({ V a_0 = v_x22_242; V a_1 = v_x_24155; V r_ = (g_heff_2eelab_2erules_2euniverseElimSyn(a_0, a_1)); heff_drop(v_x_24155); r_; });
  V f_ = v_k_24154;
  args[0] = v_t_24156;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args) {
  V v_hd_24153 = args[0];
  V v_k_24154 = args[1];
  V v_c_24152 = heff_env(self)[0];
  V v_x22_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24152;
  args[0] = v_hd_24153;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26, 1, 2, (V[]){v_x22_242, v_k_24154});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam32(V self, V *args) {
  V v_u_24210 = args[0];
  V v_val_24209 = heff_env(self)[0];
  heff_drop(v_u_24210);
  heff_clo_take(self, 1);
  V v_t_24211 = heff_tr(heff_call(v_val_24209, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_t_24211; V r_ = (g_heff_2eelab_2evalue_2edecodeEv(a_0)); heff_drop(v_t_24211); r_; });
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam31(V self, V *args) {
  V v_x_24207 = args[0];
  V v_k_24206 = heff_env(self)[0];
  V v_stx_24208 = heff_take_field(v_x_24207, 0);
  V v_val_24209 = heff_take_field(v_x_24207, 1);
  V v_t_24212 = ({ V rv_0 = heff_tag_n(TAG_SDecode, 1, (V[]){v_stx_24208}); V rv_1 = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam32, 1, 1, (V[]){v_val_24209}); V rr_ = heff_rec_reuse_nf(v_x_24207, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  heff_clo_take(self, 1);
  V f_ = v_k_24206;
  args[0] = v_t_24212;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args) {
  V v_hd_24205 = args[0];
  V v_k_24206 = args[1];
  V v_c_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24204;
  args[0] = v_hd_24205;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam31, 1, 1, (V[]){v_k_24206});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args) {
  V v_e_24201 = args[0];
  V v_x_24200 = heff_env(self)[0];
  V v_c_24204;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_24200)) {
  case TAG_MkChk: {
    V v_f_24202 = heff_field(v_x_24200, 0);
    V v_ru_24x_24200_24MkChk = heff_take_reuse_n(v_x_24200, 1ULL, 1);
    V v_t_24203 = heff_tag_at_n(v_ru_24x_24200_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
    v_c_24204 = heff_tr(heff_call(v_f_24202, 2, (V[]){v_e_24201, v_t_24203}));
    break;
  }
  default: heff_nomatch(v_x_24200);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30, 2, 1, (V[]){v_c_24204});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args) {
  V v_x_24200 = args[0];
  V v_k_24199 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_24199;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29, 1, 1, (V[]){v_x_24200})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args) {
  V v_hd_24198 = args[0];
  V v_k_24199 = args[1];
  V v_c_24197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24197;
  args[0] = v_hd_24198;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28, 1, 1, (V[]){v_k_24199});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam38(V self, V *args) {
  V v_u_24227 = args[0];
  V v_val_24226 = heff_env(self)[0];
  heff_drop(v_u_24227);
  heff_clo_take(self, 1);
  V v_t_24228 = heff_tr(heff_call(v_val_24226, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_t_24228; V r_ = (g_heff_2eelab_2evalue_2edecodeEv(a_0)); heff_drop(v_t_24228); r_; });
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam37(V self, V *args) {
  V v_x_24224 = args[0];
  V v_k_24223 = heff_env(self)[0];
  V v_stx_24225 = heff_take_field(v_x_24224, 0);
  V v_val_24226 = heff_take_field(v_x_24224, 1);
  V v_t_24229 = ({ V rv_0 = heff_tag_n(TAG_SDecode, 1, (V[]){v_stx_24225}); V rv_1 = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam38, 1, 1, (V[]){v_val_24226}); V rr_ = heff_rec_reuse_nf(v_x_24224, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  heff_clo_take(self, 1);
  V f_ = v_k_24223;
  args[0] = v_t_24229;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam36(V self, V *args) {
  V v_hd_24222 = args[0];
  V v_k_24223 = args[1];
  V v_c_24221 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24221;
  args[0] = v_hd_24222;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam37, 1, 1, (V[]){v_k_24223});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam35(V self, V *args) {
  V v_e_24218 = args[0];
  V v_x_24217 = heff_env(self)[0];
  V v_c_24221;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_24217)) {
  case TAG_MkChk: {
    V v_f_24219 = heff_field(v_x_24217, 0);
    V v_ru_24x_24217_24MkChk = heff_take_reuse_n(v_x_24217, 1ULL, 1);
    V v_t_24220 = heff_tag_at_n(v_ru_24x_24217_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
    v_c_24221 = heff_tr(heff_call(v_f_24219, 2, (V[]){v_e_24218, v_t_24220}));
    break;
  }
  default: heff_nomatch(v_x_24217);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam36, 2, 1, (V[]){v_c_24221});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam34(V self, V *args) {
  V v_x_24217 = args[0];
  V v_k_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_24216;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam35, 1, 1, (V[]){v_x_24217})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam33(V self, V *args) {
  V v_hd_24215 = args[0];
  V v_k_24216 = args[1];
  V v_c_24214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24214;
  args[0] = v_hd_24215;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam34, 1, 1, (V[]){v_k_24216});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam44(V self, V *args) {
  V v_u_24245 = args[0];
  V v_val_24244 = heff_env(self)[0];
  heff_drop(v_u_24245);
  heff_clo_take(self, 1);
  V v_x1_24246 = heff_tr(heff_call(v_val_24244, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24250;
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_Nom: {
    V v_x_24247 = heff_field(v_x1_24246, 0);
    heff_take_n(v_x1_24246, 1ULL, 1);
    v_t_24250 = v_x_24247;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24246, 0ULL, 1);
    v_t_24250 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24249 = heff_field(v_x1_24246, 0);
    heff_take_n(v_x1_24246, 1ULL, 1);
    v_t_24250 = v_x_24249;
    break;
  }
  default: heff_nomatch(v_x1_24246);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_24250});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam43(V self, V *args) {
  V v_x_24242 = args[0];
  V v_k_24241 = heff_env(self)[0];
  V v_stx_24243 = heff_take_field(v_x_24242, 0);
  V v_val_24244 = heff_take_field(v_x_24242, 1);
  V v_t_24251 = ({ V rv_0 = heff_tag_n(TAG_SIsTy, 1, (V[]){v_stx_24243}); V rv_1 = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam44, 1, 1, (V[]){v_val_24244}); V rr_ = heff_rec_reuse_nf(v_x_24242, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  heff_clo_take(self, 1);
  V f_ = v_k_24241;
  args[0] = v_t_24251;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam42(V self, V *args) {
  V v_hd_24240 = args[0];
  V v_k_24241 = args[1];
  V v_c_24239 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24239;
  args[0] = v_hd_24240;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam43, 1, 1, (V[]){v_k_24241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam41(V self, V *args) {
  V v_e_24236 = args[0];
  V v_j_24235 = heff_env(self)[0];
  V v_c_24239;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_j_24235)) {
  case TAG_MkTyp: {
    V v_f_24237 = heff_field(v_j_24235, 0);
    heff_take_n(v_j_24235, 1ULL, 1);
    V v_t_24238 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_24236, 251ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_24239 = heff_tr(heff_call(v_f_24237, 1, (V[]){v_t_24238}));
    break;
  }
  default: heff_nomatch(v_j_24235);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam42, 2, 1, (V[]){v_c_24239});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam40(V self, V *args) {
  V v_x_24234 = args[0];
  V v_k_24233 = heff_env(self)[0];
  V v_j_24235 = v_x_24234;
  heff_clo_take(self, 1);
  V f_ = v_k_24233;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam41, 1, 1, (V[]){v_j_24235})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam39(V self, V *args) {
  V v_hd_24232 = args[0];
  V v_k_24233 = args[1];
  V v_c_24231 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24231;
  args[0] = v_hd_24232;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam40, 1, 1, (V[]){v_k_24233});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2emetasInV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emetasInV_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2emetasInV(V v_mc_240, V v_v_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_t_242, 0);
    V v_sp_244 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_h_243, 0);
      heff_take_n(v_h_243, 1ULL, 1);
      v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_HError: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_244));
    V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2emetasInV_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2etoplevel_2econcatMapM(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_2411, v_t_2414);
  }
  case TAG_VCode: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VLam: {
    heff_take_n(v_t_242, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_VCons: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2emetasInV(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args) {
  V v_v2_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_mc_240; V a_1 = v_v2_2413; V r_ = (g_heff_2eelab_2etoplevel_2emetasInV(a_0, a_1)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eshownV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eshownV_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243) {
top: ;
  V v_len_244 = heff_take_field(v_cs_242, 0);
  V v_names_245 = heff_get_n(v_cs_242, 1, 2);
  V v_t_246 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_243));
  V v_e_247 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_len_244, v_t_246));
  HeffT2 v_t_2415 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2etoplevel_2eshownV_lam0, 1, 1, (V[]){v_g_240})));
  {
    V v_field_2416 = v_t_2415.f[0];
    heff_drop(v_t_2415.f[1]);
    V v_e_2418 = heff_tr(heff_call(v_field_2416, 1, (V[]){v_e_247}));
    HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), v_names_245, v_e_2418);
  }
}
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eshownV(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_d_249 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_248)));
  heff_clo_take(self, 1);
  V v_t_2410 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_248; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2410); heff_drop(v_x_248); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_d_249);
      V v_x_2414 = v_field_2413;
      return v_x_2414;
    } else {
      heff_drop(v_field_2413);
      return v_d_249;
    }
  }
}
Clo g_heff_2eelab_2etoplevel_2estuckAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_245 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 2))));
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245));
  V v_x1_247 = (g_heff_2eelab_2etoplevel_2enubInt(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = (g_std_2eordmap_2elookup_24s1088265102x456727156(v_mc_243, v_x_248));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2411 = (g_heff_2eelab_2etoplevel_2eshownV(heff_dup(v_g_240), v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_2412 = (g_heff_2eelab_2etoplevel_2eshownV(v_g_240, v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 2))));
  return (g_heff_2eelab_2etoplevel_2estuckWith(v_fallback_241, v_p_242, v_t_2410, v_t_2411, v_t_2412));
}
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2estuckAt(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eentryFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eentryFor_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244) {
top: ;
  V v_t_2412;
  if ((heff_dup(v_prim_242) == NTAG(TAG_True))) {
    v_t_2412 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eentryFor_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_243)}), NTAG(TAG_Nothing)));
  } else {
    v_t_2412 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), v_k_241, heff_dup(v_tyStx_243), heff_dup(v_bodyStx_244)));
  }
  HeffT2 v_t_2413 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    V v_t_2419;
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2415;
      v_t_2419 = v_x_2416;
    } else {
      if ((v_tag_2414 == ((int64_t)1ULL))) {
        V v_x11_2417 = v_field_2415;
        heff_drop(v_x11_2417);
        v_t_2419 = heff_abandon();
      } else {
        V v_x_2418 = v_field_2415;
        v_t_2419 = v_x_2418;
      }
    }
    return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_244, v_tyStx_243, v_t_2412, v_t_2419});
  }
}
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eentryFor(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_243 = heff_env(self)[1];
  heff_drop(v_u_245);
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_tyStx_243, NTAG(TAG_LNil)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      return v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        return heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        return v_x_2411;
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_entry, 7, 0};

V g_heff_2eelab_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244, V v_z_245, V v_z_246) {
top: ;
  V v_val_247 = heff_take_field(v_a_244, 1);
  V v_stx_248 = heff_get_n(v_a_244, 0, 2);
  V v_t_249 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2410;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    v_t_2410 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_249);
    v_t_2410 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_k_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam0, 1, 1, (V[]){v_k_2411})})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2414}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam1, 1, 8, (V[]){v_z_245, heff_dup(v_n_242), v_d_243, v_key_240, v_val_247, v_stx_248, v_g_241, v_z_246})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabBody(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args) {
  V v_c_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_2411; V rr_ = heff_rec_reuse_nf(v_c_2412, 383ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args) {
  V v_u_2429 = args[0];
  V v_val_247 = heff_env(self)[0];
  heff_drop(v_u_2429);
  heff_clo_take(self, 1);
  V v_x1_2430 = heff_tr(heff_call(v_val_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_Nom: {
    V v_x_2431 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    return v_x_2431;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2430, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2433 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    return v_x_2433;
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args) {
  V v_c_2454 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_2454, 383ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args) {
  V v_c_2467 = args[0];
  return heff_get_n(v_c_2467, 3, 9);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args) {
  V v_x_2471 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_stx_248 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_body_2451 = heff_env(self)[5];
  V v_hd_2452 = heff_env(self)[6];
  V v_k_2453 = heff_env(self)[7];
  V v_t_2494;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2472 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 2);
    switch (heff_tag_of(v_x11_2472)) {
    case TAG_DeclEquations: {
      V v_x113_2476 = heff_field(v_x11_2472, 2);
      heff_take_n(v_x11_2472, 4ULL, 5);
      switch (heff_tag_of(v_x113_2476)) {
      case TAG_AsDefinition: {
        v_t_2494 = NTAG(TAG_False);
        break;
      }
      case TAG_AsInstance: {
        v_t_2494 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x113_2476);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2472, 0ULL, 5);
      v_t_2494 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2472, 0ULL, 4);
      v_t_2494 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2472, 0ULL, 3);
      v_t_2494 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2472, 0ULL, 2);
      v_t_2494 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2472, 0ULL, 1);
      v_t_2494 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2472);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  HeffT2 v_t_2495 = (g_heff_2eelab_2eunify_2ezonker_24cpr(v_x_2471));
  {
    V v_field_2497 = v_t_2495.f[1];
    heff_drop(v_t_2495.f[0]);
    V v_t_2498 = heff_tr(heff_call(v_field_2497, 1, (V[]){v_stx_248}));
    return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_d_243; V a_3 = v_t_2494; V a_4 = v_t_2498; V a_5 = v_x_2471; V a_6 = v_body_2451; V a_7 = v_hd_2452; V a_8 = v_k_2453; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2471); heff_drop_rec(v_hd_2452, 3); r_; });
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_2452 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_stx_248 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_body_2451 = heff_env(self)[6];
  V v_k_2453 = heff_env(self)[7];
  heff_drop(v_x_2466);
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo)})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2452, 2)), 1, (V[]){v_t_2469}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_hd_2452, 1));
  heff_room[0] = v_t_2470;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam10, 1, 8, (V[]){v_n_242, v_stx_248, v_key_240, v_g_241, v_d_243, v_body_2451, v_hd_2452, v_k_2453});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_hd_2452 = heff_env(self)[2];
  V v_stx_248 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2451 = heff_env(self)[6];
  V v_k_2453 = heff_env(self)[7];
  heff_drop(v_x_2462);
  V v_t_2465;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2464 = heff_dup(heff_field(v_n_242, 1));
    v_t_2465 = v_s_2464;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  return (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2465, heff_dup(v_d_243), heff_dup(v_hd_2452), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam8, 1, 8, (V[]){v_hd_2452, v_n_242, v_stx_248, v_key_240, v_g_241, v_d_243, v_body_2451, v_k_2453})));
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_hd_2452 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_stx_248 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2451 = heff_env(self)[6];
  V v_k_2453 = heff_env(self)[7];
  V v_t_2459 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2458, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2452, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_hd_2452, 1));
  heff_room[0] = v_t_2461;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam7, 1, 8, (V[]){v_n_242, v_d_243, v_hd_2452, v_stx_248, v_key_240, v_g_241, v_body_2451, v_k_2453});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args) {
  V v_body_2451 = args[0];
  V v_hd_2452 = args[1];
  V v_k_2453 = args[2];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_stx_248 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo)})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2452, 2)), 1, (V[]){v_t_2456}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_hd_2452, 1));
  args[0] = v_t_2457;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam6, 1, 8, (V[]){v_hd_2452, v_n_242, v_d_243, v_stx_248, v_key_240, v_g_241, v_body_2451, v_k_2453});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_val_247 = heff_env(self)[3];
  V v_stx_248 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  heff_drop(v_x_2420);
  V v_t_2423;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2422 = heff_dup(heff_field(v_n_242, 1));
    v_t_2423 = v_s_2422;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2424 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2425;
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_t_2424);
    v_t_2425 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2424);
    v_t_2425 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_t_2426 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2427;
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop(v_t_2426);
    v_t_2427 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2426);
    v_t_2427 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_h_2428 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2427});
  V v_t_2434 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2428, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam3, 1, 1, (V[]){heff_dup(v_val_247)}), NTAG(TAG_Nothing)));
  V v_x1_2435 = heff_tr(heff_call(heff_dup(v_val_247), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2439;
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Nom: {
    V v_x_2436 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2436;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2435, 0ULL, 1);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2438 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2438;
    break;
  }
  default: heff_nomatch(v_x1_2435);
  }
  V v_t_2440 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(v_stx_248), v_t_2434, v_t_2439});
  V v_t_2441 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2425, v_t_2440, heff_dup(v_g_241)));
  V v_t_2442 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2443;
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_t_2442);
    v_t_2443 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2442);
    v_t_2443 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_x1_2444 = heff_tr(heff_call(v_val_247, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2448;
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nom: {
    V v_x_2445 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_t_2448 = v_x_2445;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2444, 0ULL, 1);
    v_t_2448 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2447 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_t_2448 = v_x_2447;
    break;
  }
  default: heff_nomatch(v_x1_2444);
  }
  V v_t_2449 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2423, heff_dup(v_d_243), v_t_2441, v_t_2443, v_t_2448));
  V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2449}));
  return (g_co_2ebind_24s1421083649x484987773(v_t_2450, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam4, 3, 5, (V[]){v_n_242, v_d_243, v_stx_248, v_key_240, v_g_241}), v_z_245, v_z_246));
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_val_247 = heff_env(self)[4];
  V v_stx_248 = heff_env(self)[5];
  V v_g_241 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_t_2417 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam2, 1, 8, (V[]){v_n_242, v_d_243, v_key_240, v_val_247, v_stx_248, v_g_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etopBroken_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2etopBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_244 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_x11_244)) {
    case TAG_DeclEquations: {
      V v_f_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 5);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_f_246});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2411 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 5);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2416 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 4);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2416});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2420 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 3);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2420});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2423 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 2);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_244, 0ULL, 1);
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    heff_drop(v_n_242);
    V v_keys_2427 = heff_take_field(v_acc_241, 2);
    V v_broken_2428 = heff_take_field(v_acc_241, 3);
    V v_watches_2429 = heff_take_field(v_acc_241, 4);
    V v_tests_2430 = heff_take_field(v_acc_241, 5);
    V v_spans_2431 = heff_take_field(v_acc_241, 6);
    V v_infos_2432 = heff_take_field(v_acc_241, 7);
    V v_trace_2433 = heff_take_field(v_acc_241, 8);
    V v_unreached_2434 = heff_take_field(v_acc_241, 9);
    return ({ V rv_1 = v_diags_243; V rv_2 = v_keys_2427; V rv_3 = v_broken_2428; V rv_4 = v_watches_2429; V rv_5 = v_tests_2430; V rv_6 = v_spans_2431; V rv_7 = v_infos_2432; V rv_8 = v_trace_2433; V rv_9 = v_unreached_2434; V rr_ = heff_rec_reuse_nf(v_acc_241, 1ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
  }
  case TAG_Just: {
    V v_x_2435 = heff_field(v_t_2426, 0);
    V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
    V v_kf_2436 = heff_dup(v_kf_240);
    V v_n_2437 = heff_dup(v_n_242);
    V v_k_2438 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2435)}));
    V v_t_2439 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2435)}));
    V v_g_2441;
    if (heff_strEq_c_lent(v_t_2439, v_x_2435, 1)) {
      heff_drop(v_kf_240);
      v_g_2441 = heff_dup(heff_rfield(v_acc_241, 0));
    } else {
      V v_t_2440 = heff_tr(heff_call(v_kf_240, 1, (V[]){heff_dup(v_x_2435)}));
      v_g_2441 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2435), v_t_2440, heff_dup(heff_rfield(v_acc_241, 0))));
    }
    V v_t_2442 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_2441, 3), v_k_2438, NTAG(TAG_MkUnit)));
    V v_g_2443 = ({ V rv_3 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_g_2441, 247ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2466;
    switch (heff_tag_of(v_n_2437)) {
    case TAG_At: {
      V v_x11_2444 = heff_dup(heff_field(v_n_2437, 0));
      switch (heff_tag_of(v_x11_2444)) {
      case TAG_DeclEquations: {
        V v_f_2446 = heff_field(v_x11_2444, 0);
        heff_take_n(v_x11_2444, 1ULL, 5);
        v_t_2466 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_f_2446});
        break;
      }
      case TAG_DeclDefine: {
        V v_x_2451 = heff_field(v_x11_2444, 0);
        heff_take_n(v_x11_2444, 1ULL, 5);
        v_t_2466 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_x_2451});
        break;
      }
      case TAG_DeclTheory: {
        V v_x_2456 = heff_field(v_x11_2444, 0);
        heff_take_n(v_x11_2444, 1ULL, 4);
        v_t_2466 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_x_2456});
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2460 = heff_field(v_x11_2444, 0);
        heff_take_n(v_x11_2444, 1ULL, 3);
        v_t_2466 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_x_2460});
        break;
      }
      case TAG_DeclTest: {
        V v_x_2463 = heff_field(v_x11_2444, 0);
        heff_take_n(v_x11_2444, 1ULL, 2);
        v_t_2466 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){v_x_2463});
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2444, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2426_24Just, 1);
        v_t_2466 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2444);
      }
      break;
    }
    default: heff_nomatch(v_n_2437);
    }
    V v_globals_2496;
    switch (heff_tag_of(v_t_2466)) {
    case TAG_Nothing: {
      heff_drop(v_kf_2436);
      heff_drop(v_n_2437);
      v_globals_2496 = v_g_2443;
      break;
    }
    case TAG_Just: {
      V v_x_2467 = heff_field(v_t_2466, 0);
      heff_take_n(v_t_2466, 1ULL, 1);
      switch (heff_tag_of(v_n_2437)) {
      case TAG_At: {
        V v_x11_2468 = heff_field(v_n_2437, 0);
        V v_ru_24n_2437_24At = heff_take_reuse_n(v_n_2437, 1ULL, 2);
        switch (heff_tag_of(v_x11_2468)) {
        case TAG_DeclEquations: {
          V v_x113_2472 = heff_field(v_x11_2468, 2);
          heff_take_n(v_x11_2468, 4ULL, 5);
          switch (heff_tag_of(v_x113_2472)) {
          case TAG_AsDefinition: {
            heff_drop(v_kf_2436);
            heff_drop(v_x_2467);
            heff_drop_cell(v_ru_24n_2437_24At, 2);
            v_globals_2496 = v_g_2443;
            break;
          }
          case TAG_AsInstance: {
            V v_k_2475 = heff_tr(heff_call(heff_dup(v_kf_2436), 1, (V[]){heff_dup(v_x_2467)}));
            V v_key_2476 = heff_tr(heff_call(v_kf_2436, 1, (V[]){heff_dup(v_x_2467)}));
            V v_t_2478;
            if (heff_strEq_c_lent(v_key_2476, v_x_2467, 0)) {
              heff_drop(v_x_2467);
              heff_drop(v_key_2476);
              v_t_2478 = ((V)&g_heff_2eelab_2etoplevel_2etopBroken_str0);
            } else {
              int64_t v_t_2477 = (heff_unbox_word(heff_strLength_lent(v_key_2476, 0)) - heff_unbox_word(heff_strLength(v_x_2467)));
              v_t_2478 = heff_strSlice(v_key_2476, MK_INT(0LL), heff_box_word((v_t_2477 - ((int64_t)1ULL))));
            }
            V v_t_2479 = (g_list_2ekeepIf_24s2115931744x466898799(v_k_2475, heff_take_field(v_g_2443, 7)));
            V v_t_2480 = heff_tag_at_n(v_ru_24n_2437_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_k_2475, v_t_2478}), v_t_2479});
            v_globals_2496 = ({ V rv_7 = v_t_2480; V rr_ = heff_rec_reuse_nf(v_g_2443, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
            break;
          }
          default: heff_nomatch(v_x113_2472);
          }
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2468, 0ULL, 5);
          heff_drop(v_kf_2436);
          heff_drop(v_x_2467);
          heff_drop_cell(v_ru_24n_2437_24At, 2);
          v_globals_2496 = v_g_2443;
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2468, 0ULL, 4);
          heff_drop(v_kf_2436);
          heff_drop(v_x_2467);
          heff_drop_cell(v_ru_24n_2437_24At, 2);
          v_globals_2496 = v_g_2443;
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2468, 0ULL, 3);
          heff_drop(v_kf_2436);
          heff_drop(v_x_2467);
          heff_drop_cell(v_ru_24n_2437_24At, 2);
          v_globals_2496 = v_g_2443;
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2468, 0ULL, 2);
          heff_drop(v_kf_2436);
          heff_drop(v_x_2467);
          heff_drop_cell(v_ru_24n_2437_24At, 2);
          v_globals_2496 = v_g_2443;
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2468, 0ULL, 1);
          heff_drop(v_kf_2436);
          heff_drop(v_x_2467);
          heff_drop_cell(v_ru_24n_2437_24At, 2);
          v_globals_2496 = v_g_2443;
          break;
        }
        default: heff_nomatch(v_x11_2468);
        }
        break;
      }
      default: heff_nomatch(v_n_2437);
      }
      break;
    }
    default: heff_nomatch(v_t_2466);
    }
    V v_t_2497 = heff_take_field(v_acc_241, 3);
    V v_watches_2498 = heff_take_field(v_acc_241, 4);
    V v_tests_2499 = heff_take_field(v_acc_241, 5);
    V v_spans_24100 = heff_take_field(v_acc_241, 6);
    V v_infos_24101 = heff_take_field(v_acc_241, 7);
    V v_trace_24102 = heff_take_field(v_acc_241, 8);
    V v_unreached_24103 = heff_take_field(v_acc_241, 9);
    V v_t_24106;
    switch (heff_tag_of(v_n_242)) {
    case TAG_At: {
      V v_s_24105 = heff_field(v_n_242, 1);
      heff_take_n(v_n_242, 2ULL, 2);
      v_t_24106 = v_s_24105;
      break;
    }
    default: heff_nomatch(v_n_242);
    }
    V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2435, v_t_24106}), v_t_2497});
    return ({ V rv_0 = v_globals_2496; V rv_1 = v_diags_243; V rv_3 = v_t_24107; V rv_4 = v_watches_2498; V rv_5 = v_tests_2499; V rv_6 = v_spans_24100; V rv_7 = v_infos_24101; V rv_8 = v_trace_24102; V rv_9 = v_unreached_24103; V rr_ = heff_rec_reuse_nf(v_acc_241, 4ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopBroken(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ekeepSt_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ekeepSt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ekeepSt_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241) {
top: ;
  V v_keys_242 = heff_take_field(v_acc_241, 2);
  V v_broken_243 = heff_take_field(v_acc_241, 3);
  V v_watches_244 = heff_take_field(v_acc_241, 4);
  V v_tests_245 = heff_take_field(v_acc_241, 5);
  V v_spans_246 = heff_take_field(v_acc_241, 6);
  V v_t_2410;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_247 = heff_field(v_st_240, 0);
    v_t_2410 = heff_dup(v_c_247);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_infos_2417 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_241, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2ekeepSt_lam0, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get_n(v_t_2410, 0, 9)));
  V v_t_2421;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_2418 = heff_field(v_st_240, 0);
    v_t_2421 = heff_dup(v_c_2418);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_trace_2422 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2421, 6, 9), heff_take_field(v_acc_241, 8)));
  V v_unreached_2423 = heff_take_field(v_acc_241, 9);
  return ({ V rv_2 = v_keys_242; V rv_3 = v_broken_243; V rv_4 = v_watches_244; V rv_5 = v_tests_245; V rv_6 = v_spans_246; V rv_7 = v_infos_2417; V rv_8 = v_trace_2422; V rv_9 = v_unreached_2423; V rr_ = heff_rec_reuse_nf(v_acc_241, 3ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ekeepSt(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ekeepSt_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_n_2411 = heff_env(self)[1];
  heff_drop(v_u_2412);
  V v_t_2416;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_2413 = heff_field(v_st_240, 0);
    heff_take_n(v_st_240, 1ULL, 3);
    v_t_2416 = v_c_2413;
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V f_ = heff_get_n(v_n_2411, 4, 5);
  args[0] = heff_get_n(v_t_2416, 3, 9);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ekeepSt_lam0(V self, V *args) {
  V v_n_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ekeepSt_lam1, 1, 2, (V[]){v_st_240, heff_dup(v_n_2411)}); V rr_ = heff_rec_reuse_nf(v_n_2411, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str0, 116, "an instance takes only implicit and instance arguments, `{x : A}` and `{{x : A}}`: a search gives it no explicit one");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str1, 192, "make it implicit, solved where the instance is found (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or declare a definition, no instance, and give it its arguments where it is used");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str2, 135, "the instance's implicit argument `_` is not in what it is an instance of: a search, unifying that with the type wanted, cannot solve it");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str3, 120, "use it in what the instance is an instance of (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or leave it out");
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076(V v_sp_240, V v_implicits_241, V v_depth_242, V v_conclusion_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_conclusion_243)) {
  case TAG_SFunction: {
    V v_conclusion3_247 = heff_field(v_conclusion_243, 2);
    V v_conclusion4_248 = heff_field(v_conclusion_243, 3);
    heff_take_n(v_conclusion_243, 12ULL, 5);
    switch (heff_tag_of(v_conclusion4_248)) {
    case TAG_Expl: {
      heff_drop(v_implicits_241);
      heff_drop(v_depth_242);
      heff_drop(v_p_244);
      heff_drop(v_conclusion3_247);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_lam0, 1, 1, (V[]){v_sp_240});
    }
    case TAG_Impl: {
      switch (heff_tag_of(v_conclusion3_247)) {
      case TAG_MkAbs: {
        V v_x_2412 = heff_field(v_conclusion3_247, 0);
        V v_cod_2413 = heff_field(v_conclusion3_247, 1);
        V v_ru_24conclusion3_247_24MkAbs = heff_take_reuse_n(v_conclusion3_247, 3ULL, 2);
        V v_t_2414 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2413));
        V v_t_2415 = heff_tag_at_n(v_ru_24conclusion3_247_24MkAbs, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__level, (V[]){v_x_2412, heff_dup(v_depth_242)}), v_implicits_241});
        V t_0 = v_sp_240;
        V t_1 = v_t_2415;
        V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
        V t_3 = v_t_2414;
        V t_4 = v_p_244;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        v_p_244 = t_4;
        goto top;
      }
      case TAG_AbsConst: {
        heff_take_n(v_conclusion3_247, 0ULL, 1);
        heff_drop(v_implicits_241);
        heff_drop(v_depth_242);
        heff_drop(v_p_244);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_lam1, 1, 1, (V[]){v_sp_240});
      }
      default: return heff_nomatch(v_conclusion3_247);
      }
    }
    case TAG_Inst: {
      switch (heff_tag_of(v_conclusion3_247)) {
      case TAG_MkAbs: {
        V v_cod_2420 = heff_field(v_conclusion3_247, 1);
        heff_take_n(v_conclusion3_247, 2ULL, 2);
        V v_t_2421 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2420));
        V t_0 = v_sp_240;
        V t_1 = v_implicits_241;
        V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
        V t_3 = v_t_2421;
        V t_4 = v_p_244;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        v_p_244 = t_4;
        goto top;
      }
      case TAG_AbsConst: {
        V v_cod_2422 = heff_field(v_conclusion3_247, 0);
        heff_take_n(v_conclusion3_247, 1ULL, 1);
        V v_t_2423 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2422));
        V t_0 = v_sp_240;
        V t_1 = v_implicits_241;
        V t_2 = v_depth_242;
        V t_3 = v_t_2423;
        V t_4 = v_p_244;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        v_p_244 = t_4;
        goto top;
      }
      default: return heff_nomatch(v_conclusion3_247);
      }
    }
    default: return heff_nomatch(v_conclusion4_248);
    }
  }
  default: {
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529(v_sp_240, v_depth_242, v_conclusion_243, v_t_2424, v_p_244);
  }
  }
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_lam0(V self, V *args) {
  V v_st_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(348LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str0), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str1)})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2411}), v_st_2410});
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(350LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str2), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_str3)})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2417});
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V v_acc_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_st_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_244, heff_dup(v_acc_240)));
      V v_t_2410;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_247 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2410 = v_c_247;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2410, 1, 9)));
      V v_t_2412 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2411));
      V v_t_2413;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_rec(v_d_245, 5);
        v_t_2413 = NTAG(TAG_Nil);
      } else {
        v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2414 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_240, 1, 10), v_t_2412, v_t_2413));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(v_t_246, v_n_241, v_t_2414);
    }
    case TAG_Right: {
      V v_r_2415 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_prim_2416 = heff_take_field(v_r_2415, 2);
      V v_key_2417 = heff_take_field(v_r_2415, 1);
      V v_entry_2418 = heff_take_field(v_r_2415, 4);
      V v_name_2419 = heff_take_field(v_r_2415, 0);
      V v_isInstance_2420 = heff_take_field(v_r_2415, 3);
      V v_failed_2421 = heff_get_n(v_r_2415, 5, 6);
      V v_g_2422 = heff_take_field(v_acc_240, 0);
      V v_t_2423 = v_prim_2416;
      V v_t_2428;
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_t_2423);
        HeffT2 v_t_2424 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_2422, 1), v_key_2417));
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            heff_drop(v_entry_2418);
            V v_e_2427 = v_field_2426;
            heff_drop(v_e_2427);
            v_t_2428 = v_g_2422;
          } else {
            heff_drop(v_field_2426);
            v_t_2428 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2417), v_entry_2418, v_g_2422));
          }
        }
      } else {
        heff_drop(v_t_2423);
        v_t_2428 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(v_key_2417), v_entry_2418, v_g_2422));
      }
      V v_t_2429 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_name_2419), heff_dup(v_key_2417), v_t_2428));
      V v_globals_2430 = ({ V a_0 = v_isInstance_2420; V a_1 = heff_dup(v_key_2417); V a_2 = v_name_2419; V a_3 = v_t_2429; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(a_0, a_1, a_2, a_3)); heff_drop(v_isInstance_2420); r_; });
      V v_t_2434;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2431 = heff_dup(heff_field(v_st_244, 0));
        v_t_2434 = v_c_2431;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2434, 1, 9)));
      V v_t_2436 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2435));
      V v_t_2437 = heff_dup(v_failed_2421);
      V v_t_2439;
      switch (heff_tag_of(v_t_2437)) {
      case TAG_Nothing: {
        v_t_2439 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2438 = heff_field(v_t_2437, 0);
        heff_take_n(v_t_2437, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2438, 0)), MK_INT(-1LL))) {
          heff_drop_rec(v_d_2438, 5);
          v_t_2439 = NTAG(TAG_Nil);
        } else {
          v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2438, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      V v_diags_2440 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_240, 1), v_t_2436, v_t_2439));
      V v_broken_2441 = heff_take_field(v_acc_240, 3);
      V v_watches_2442 = heff_take_field(v_acc_240, 4);
      V v_tests_2443 = heff_take_field(v_acc_240, 5);
      V v_t_2444 = v_name_2419;
      V v_t_2445 = heff_take_field(v_acc_240, 6);
      V v_t_2449;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2446 = heff_dup(heff_field(v_st_244, 0));
        v_t_2449 = v_c_2446;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2456 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_240, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam0, 1, 1, (V[]){heff_dup(v_st_244)}), heff_get_n(v_t_2449, 0, 9)));
      V v_t_2460;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2457 = heff_dup(heff_field(v_st_244, 0));
        v_t_2460 = v_c_2457;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2461 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2460, 6, 9), heff_take_field(v_acc_240, 8)));
      V v_t_2465;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2462 = heff_dup(heff_field(v_st_244, 0));
        v_t_2465 = v_c_2462;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2466 = heff_get_n(v_t_2465, 1, 9);
      V v_t_2480;
      switch (heff_tag_of(v_t_2466)) {
      case TAG_Nil: {
        V v_t_2467 = v_failed_2421;
        switch (heff_tag_of(v_t_2467)) {
        case TAG_Nothing: {
          V v_t_2471;
          switch (heff_tag_of(v_st_244)) {
          case TAG_MkSt: {
            V v_c_2468 = heff_dup(heff_field(v_st_244, 0));
            v_t_2471 = v_c_2468;
            break;
          }
          default: heff_nomatch(v_st_244);
          }
          V v_t_2475;
          switch (heff_tag_of(v_st_244)) {
          case TAG_MkSt: {
            V v_c_2472 = heff_field(v_st_244, 0);
            heff_take_n(v_st_244, 1ULL, 3);
            v_t_2475 = v_c_2472;
            break;
          }
          default: heff_nomatch(v_st_244);
          }
          V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2475, 8, 9)));
          v_t_2480 = ({ V b_0 = heff_get_n(v_t_2471, 8, 9); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2476; V r_ = (g_heff_2eelab_2etoplevel_2earmsSaid(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2467, 0ULL, 1);
          heff_drop(v_st_244);
          v_t_2480 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_t_2467);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2466, 0ULL, 2);
        heff_drop(v_st_244);
        heff_drop(v_failed_2421);
        v_t_2480 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_t_2466);
      }
      V v_unreached_2481 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2480, heff_take_field(v_acc_240, 9)));
      V v_t_2484;
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_s_2483 = heff_field(v_n_241, 1);
        heff_take_n(v_n_241, 2ULL, 2);
        v_t_2484 = v_s_2483;
        break;
      }
      default: heff_nomatch(v_n_241);
      }
      V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_key_2417, heff_take_field(v_acc_240, 2)});
      V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_2444, v_t_2484}), v_t_2445});
      return ({ V rv_0 = v_globals_2430; V rv_1 = v_diags_2440; V rv_2 = v_t_2485; V rv_3 = v_broken_2441; V rv_4 = v_watches_2442; V rv_5 = v_tests_2443; V rv_6 = v_t_2486; V rv_7 = v_infos_2456; V rv_8 = v_trace_2461; V rv_9 = v_unreached_2481; V rr_ = heff_rec_reuse_nf(v_acc_240, 0ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam1(V self, V *args) {
  V v_u_2451 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_n_2450 = heff_env(self)[1];
  heff_drop(v_u_2451);
  V v_t_2455;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_2452 = heff_field(v_st_244, 0);
    heff_take_n(v_st_244, 1ULL, 3);
    v_t_2455 = v_c_2452;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V f_ = heff_get_n(v_n_2450, 4, 5);
  args[0] = heff_get_n(v_t_2455, 3, 9);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam0(V self, V *args) {
  V v_n_2450 = args[0];
  V v_st_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_lam1, 1, 2, (V[]){v_st_244, heff_dup(v_n_2450)}); V rr_ = heff_rec_reuse_nf(v_n_2450, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}