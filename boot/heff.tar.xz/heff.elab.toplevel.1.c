// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LNil 57394
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkFieldPat 14710
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SIs 29577
#define TAG_SOpaque 44226
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpId 35501
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_right 309870134
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s1601686549x58384075(V, V, V, V);
V g_co_2ebind_24s1601686549x58384075_entry(V self, V *a);
extern Clo g_co_2ebind_24s1601686549x58384075_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2ememoed_2edecode(V);
V g_heff_2eelab_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2edecode_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eformRecord(V, V);
V g_heff_2eelab_2erules_2eformRecord_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformRecord_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordTypeIntro(V, V);
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V);
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2efailedAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efailedAt_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2emetasInV(V, V);
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2emetasInV_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn(V);
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo;
V g_heff_2eelab_2etoplevel_2enominalTyp(V);
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2eshownV(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eshownV_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalSyn(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_res_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  V v_x1_2412 = heff_tr(heff_call(heff_get_n(v_res_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2416});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_res_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    V v_ru_24x_247_24MkPair = heff_take_reuse_n(v_x_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_res_248, 0))});
    V v_t_2417 = heff_tag_at_n(v_ru_24x_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam3, 1, 1, (V[]){v_res_248})}), v_a_249});
    V f_ = v_k_246;
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkSyn: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_call(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam1, 2, 1, (V[]){v_c_244});
}
Clo g_heff_2eelab_2etoplevel_2etagSpans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpans_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSpans(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 2);
        V v_acc_247 = (g_heff_2eelab_2etoplevel_2etagSpans(v_rest_242));
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_245));
        V v_it_249 = heff_get_n(v_t_248, 0, 2);
        switch (heff_tag_of(v_it_249)) {
        case TAG_At: {
          V v_it1_2410 = heff_field(v_it_249, 0);
          V v_tsp_2411 = heff_field(v_it_249, 1);
          heff_take_n(v_it_249, 3ULL, 2);
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_PatVar: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatTag: {
            V v_x_2413 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 3);
            return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_tsp_2411}), v_acc_247});
          }
          case TAG_PatOp: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatInt: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatFloat: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatString: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatBytes: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRune: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRecord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatWord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatAs: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          default: return heff_nomatch(v_it1_2410);
          }
        }
        default: return heff_nomatch(v_it_249);
        }
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSpans(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_244));
      v_t_246 = heff_bool(!(heff_dup(v_a_245) == NTAG(TAG_True)));
      heff_drop(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V v_sp_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_t1_242 = heff_field(v_t_241, 0);
    switch (heff_tag_of(v_t1_242)) {
    case TAG_TPi: {
      V v_c_246 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0, 2, 2, (V[]){v_c_246, v_sp_240});
    }
    case TAG_TSig: {
      V v_fields_2411 = heff_field(v_t1_242, 0);
      V v_c_2412 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(heff_dup(v_fields_2411)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2, 2, 2, (V[]){v_c_2412, v_sp_240});
    }
    case TAG_TSum: {
      V v_c_2418 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4, 2, 2, (V[]){v_c_2418, v_sp_240});
    }
    case TAG_TType: {
      V v_c_2423 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6, 2, 2, (V[]){v_c_2423, v_sp_240});
    }
    case TAG_TInt: {
      V v_c_2428 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8, 2, 2, (V[]){v_c_2428, v_sp_240});
    }
    case TAG_TFloat: {
      V v_c_2433 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10, 2, 2, (V[]){v_c_2433, v_sp_240});
    }
    case TAG_TString: {
      V v_c_2438 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12, 2, 2, (V[]){v_c_2438, v_sp_240});
    }
    case TAG_TRune: {
      V v_c_2443 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14, 2, 2, (V[]){v_c_2443, v_sp_240});
    }
    case TAG_TArray: {
      V v_c_2449 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16, 2, 2, (V[]){v_c_2449, v_sp_240});
    }
    case TAG_TFixed: {
      V v_c_2455 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18, 2, 2, (V[]){v_c_2455, v_sp_240});
    }
    case TAG_TInf: {
      V v_c_2461 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20, 2, 2, (V[]){v_c_2461, v_sp_240});
    }
    case TAG_TChk: {
      V v_c_2467 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22, 2, 2, (V[]){v_c_2467, v_sp_240});
    }
    case TAG_TNominal: {
      V v_c_2473 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24, 2, 2, (V[]){v_c_2473, v_sp_240});
    }
    default: return heff_nomatch(v_t1_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_sp_240; V a_1 = v_x_249; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1, 1, 2, (V[]){v_sp_240, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = (g_heff_2eelab_2erules_2erecordTypeIntro(v_sp_240, v_x_2415));
  V f_ = v_k_2414;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3, 1, 2, (V[]){v_sp_240, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = ({ V a_0 = v_sp_240; V a_1 = v_x_2421; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2421); r_; });
  V f_ = v_k_2420;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5, 1, 2, (V[]){v_sp_240, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = ({ V a_0 = v_sp_240; V a_1 = v_x_2426; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2426); r_; });
  V f_ = v_k_2425;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7, 1, 2, (V[]){v_sp_240, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = ({ V a_0 = v_sp_240; V a_1 = v_x_2431; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2431); r_; });
  V f_ = v_k_2430;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9, 1, 2, (V[]){v_sp_240, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args) {
  V v_x_2436 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = ({ V a_0 = v_sp_240; V a_1 = v_x_2436; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2436); r_; });
  V f_ = v_k_2435;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2433;
  args[0] = v_hd_2434;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11, 1, 2, (V[]){v_sp_240, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args) {
  V v_x_2441 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = ({ V a_0 = v_sp_240; V a_1 = v_x_2441; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2441); r_; });
  V f_ = v_k_2440;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13, 1, 2, (V[]){v_sp_240, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args) {
  V v_x_2446 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = ({ V a_0 = v_sp_240; V a_1 = v_x_2446; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2446); r_; });
  V f_ = v_k_2445;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2443;
  args[0] = v_hd_2444;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15, 1, 2, (V[]){v_sp_240, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args) {
  V v_x_2452 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = ({ V a_0 = v_sp_240; V a_1 = v_x_2452; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2452); r_; });
  V f_ = v_k_2451;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2449;
  args[0] = v_hd_2450;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17, 1, 2, (V[]){v_sp_240, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args) {
  V v_x_2458 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = ({ V a_0 = v_sp_240; V a_1 = v_x_2458; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V f_ = v_k_2457;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19, 1, 2, (V[]){v_sp_240, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args) {
  V v_x_2464 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = ({ V a_0 = v_sp_240; V a_1 = v_x_2464; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2464); r_; });
  V f_ = v_k_2463;
  args[0] = v_t_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2461;
  args[0] = v_hd_2462;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21, 1, 2, (V[]){v_sp_240, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args) {
  V v_x_2470 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471 = ({ V a_0 = v_sp_240; V a_1 = v_x_2470; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2470); r_; });
  V f_ = v_k_2469;
  args[0] = v_t_2471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_c_2467 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2467;
  args[0] = v_hd_2468;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23, 1, 2, (V[]){v_sp_240, v_k_2469});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args) {
  V v_x_2476 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477 = ({ V a_0 = v_sp_240; V a_1 = v_x_2476; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2476); r_; });
  V f_ = v_k_2475;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_c_2473 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2473;
  args[0] = v_hd_2474;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25, 1, 2, (V[]){v_sp_240, v_k_2475});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1, 2, 2, (V[]){v_t_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_t_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_245, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247})));
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12, 1, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11, 3, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TPi: {
      V v_b_243 = heff_field(v_x21_241, 0);
      V v_codN_244 = heff_field(v_x21_241, 1);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(heff_dup(v_b_243)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0, 2, 2, (V[]){v_c_245, heff_dup(v_codN_244)});
    }
    case TAG_TSig: {
      V v_fields_2412 = heff_field(v_x21_241, 0);
      V v_c_2413 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(heff_dup(v_fields_2412)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3, 2, 1, (V[]){v_c_2413});
    }
    case TAG_TSum: {
      V v_variantNs_2423 = heff_field(v_x21_241, 0);
      V v_c_2424 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(heff_dup(v_variantNs_2423)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8, 2, 1, (V[]){v_c_2424});
    }
    case TAG_TType: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo);
    }
    case TAG_TInt: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo);
    }
    case TAG_TFloat: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14_clo);
    }
    case TAG_TString: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15_clo);
    }
    case TAG_TRune: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16_clo);
    }
    case TAG_TArray: {
      V v_a0_2449 = heff_field(v_x21_241, 0);
      V v_c_2450 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_a0_2449));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17, 2, 1, (V[]){v_c_2450});
    }
    case TAG_TFixed: {
      V v_w_2455 = heff_field(v_x21_241, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19, 2, 1, (V[]){heff_dup(v_w_2455)});
    }
    case TAG_TInf: {
      V v_i_2463 = heff_field(v_x21_241, 0);
      V v_c_2464 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_2463)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22, 2, 2, (V[]){v_c_2464, heff_dup(v_x22_242)});
    }
    case TAG_TChk: {
      V v_ch_2469 = heff_field(v_x21_241, 0);
      V v_c_2470 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_ch_2469)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24, 2, 1, (V[]){v_c_2470});
    }
    case TAG_TNominal: {
      V v_t_2482 = heff_field(v_x21_241, 0);
      V v_c_2483 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2482));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29, 2, 1, (V[]){v_c_2483});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_x_248; V a_1 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_codN_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = ({ V a_0 = v_codN_244; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_codN_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_codN_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1, 1, 3, (V[]){v_codN_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_2417 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = (g_heff_2eelab_2erules_2erecordOf(v_e_2417, v_x_2421));
  V f_ = v_k_2420;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_e_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7, 1, 2, (V[]){v_e_2417, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args) {
  V v_e_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2418 = (g_heff_2eelab_2erules_2eformRecord(heff_dup(v_e_2417), v_x_2416));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6, 2, 2, (V[]){v_c_2418, v_e_2417});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5, 1, 1, (V[]){v_x_2416})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2427)));
  V v_t_2429 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2427));
  V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_x_2427));
  V v_t_2431 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2428), v_t_2429, heff_arrayFromList(v_t_2430)});
  V v_x_2432 = (g_heff_2eelab_2erules_2esumFormation(v_t_2431));
  V f_ = v_k_2426;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9, 1, 1, (V[]){v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args) {
  V v_u2_2439 = args[0];
  heff_drop(v_u2_2439);
  V v_t_2440 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2440});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args) {
  V v_e_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k_2437 = args[2];
  heff_drop(v_e_2435);
  heff_drop(v_hd_2436);
  V v_t_2438 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
  V f_ = v_k_2437;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2438, ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2454 = ({ V a_0 = v_x_2453; V r_ = (g_heff_2eelab_2erules_2eprimArray(a_0)); heff_drop(v_x_2453); r_; });
  V f_ = v_k_2452;
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_c_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2450;
  args[0] = v_hd_2451;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18, 1, 1, (V[]){v_k_2452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args) {
  V v_u_2461 = args[0];
  V v_w_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2461);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2455})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args) {
  V v_e_2458 = args[0];
  V v_hd_2459 = args[1];
  V v_k_2460 = args[2];
  V v_w_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2458);
  heff_drop(v_hd_2459);
  V v_t_2462 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){heff_dup(v_w_2455)}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21, 1, 1, (V[]){v_w_2455})});
  V f_ = v_k_2460;
  args[0] = v_t_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_w_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20, 3, 1, (V[]){v_w_2455})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args) {
  V v_x_2467 = args[0];
  V v_x22_242 = heff_env(self)[0];
  V v_k_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = ({ V a_0 = v_x22_242; V a_1 = v_x_2467; V r_ = (g_heff_2eelab_2erules_2euniverseElimSyn(a_0, a_1)); heff_drop(v_x_2467); r_; });
  V f_ = v_k_2466;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_c_2464 = heff_env(self)[0];
  V v_x22_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2464;
  args[0] = v_hd_2465;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23, 1, 2, (V[]){v_x22_242, v_k_2466});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args) {
  V v_x_2480 = args[0];
  V v_k_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2481 = (g_heff_2eelab_2ememoed_2edecode(v_x_2480));
  V f_ = v_k_2479;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_c_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2477;
  args[0] = v_hd_2478;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28, 1, 1, (V[]){v_k_2479});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args) {
  V v_e_2474 = args[0];
  V v_x_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2477;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkChk: {
    V v_f_2475 = heff_field(v_x_2473, 0);
    V v_ru_24x_2473_24MkChk = heff_take_reuse_n(v_x_2473, 1ULL, 1);
    V v_t_2476 = heff_tag_at_n(v_ru_24x_2473_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
    v_c_2477 = heff_tr(heff_call(v_f_2475, 2, (V[]){v_e_2474, v_t_2476}));
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27, 2, 1, (V[]){v_c_2477});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args) {
  V v_x_2473 = args[0];
  V v_k_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2472;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26, 1, 1, (V[]){v_x_2473})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2470;
  args[0] = v_hd_2471;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25, 1, 1, (V[]){v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args) {
  V v_x_2486 = args[0];
  V v_k_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2487 = ({ V a_0 = v_x_2486; V r_ = (g_heff_2eelab_2etoplevel_2enominalTyp(a_0)); heff_drop(v_x_2486); r_; });
  V f_ = v_k_2485;
  args[0] = v_t_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_c_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2483;
  args[0] = v_hd_2484;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30, 1, 1, (V[]){v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epoisonedLeft_str0, 54, "an implicit argument an error kept from being inferred");
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2epoisonedLeft(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epoisonedLeft(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 2, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args) {
  V v_m_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = v_x_2411; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2411); r_; });
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_me_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_get_n(v_me_2416, 1, 6);
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      heff_take_n(v_t_2417, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = ({ V a_0 = v_x_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_t_2413 = (g_list_2emap_24s1415906091x1371825187(v_t_2412));
  V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4, 1, 1, (V[]){v_x_2411}); V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2413); r_; });
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop_rec(v_hd_240, 3);
    heff_drop(v_t_2419);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2emetasInV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emetasInV_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2emetasInV(V v_mc_240, V v_v_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_t_242, 0);
    V v_sp_244 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_h_243, 0);
      heff_take_n(v_h_243, 1ULL, 1);
      v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_HError: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_244));
    V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2emetasInV_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2etoplevel_2econcatMapM(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_2411, v_t_2414);
  }
  case TAG_VCode: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VLam: {
    heff_take_n(v_t_242, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_VCons: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2emetasInV(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args) {
  V v_v2_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_mc_240; V a_1 = v_v2_2413; V r_ = (g_heff_2eelab_2etoplevel_2emetasInV(a_0, a_1)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eshownV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eshownV_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_243));
  V v_e_245 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_take_field(v_cs_242, 0), v_t_244));
  V v_t_2411 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2etoplevel_2eshownV_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 0, 2), 1, (V[]){v_e_245}));
  HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s2007615729x389282684(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_242, 1, 2), v_e_2412);
}
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eshownV(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_247 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_246)));
  V v_t_248 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_249 = ({ V a_0 = v_t_248; V a_1 = v_x_246; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_248); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nothing: {
    return v_d_247;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    heff_take_n(v_x2_249, 1ULL, 1);
    heff_drop(v_d_247);
    return v_x_2410;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
Clo g_heff_2eelab_2etoplevel_2estuckAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_245 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 2))));
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245));
  V v_x1_247 = (g_heff_2eelab_2etoplevel_2enubInt(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = (g_map_2elookup_24s567992785x1569911877(v_x_248, v_mc_243));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2411 = (g_heff_2eelab_2etoplevel_2eshownV(heff_dup(v_g_240), v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_2412 = (g_heff_2eelab_2etoplevel_2eshownV(v_g_240, v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 2))));
  return (g_heff_2eelab_2etoplevel_2estuckWith(v_fallback_241, v_p_242, v_t_2410, v_t_2411, v_t_2412));
}
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2estuckAt(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eentryFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eentryFor_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244) {
top: ;
  V v_t_2410;
  if ((heff_dup(v_prim_242) == NTAG(TAG_True))) {
    v_t_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eentryFor_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_243)}), NTAG(TAG_Nothing)));
  } else {
    v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), v_k_241, heff_dup(v_tyStx_243), heff_dup(v_bodyStx_244)));
  }
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_244, v_tyStx_243, v_t_2410, v_t_2415});
}
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eentryFor(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_245);
  V v_x1_246 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_tyStx_243, NTAG(TAG_LNil)));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_247;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_246, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_249;
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2echeckStuck(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){v_t_249}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2echeckStuck_lam1, 1, 5, (V[]){v_g_240, v_sp_241, heff_dup(v_p_245), v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2echeckStuck(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2412 = ({ V a_0 = v_g_240; V a_1 = v_sp_241; V a_2 = v_p_245; V a_3 = v_x_2411; V r_ = (g_heff_2eelab_2etoplevel_2estuckAt(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_x_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2414}));
  V f_ = heff_get_n(v_p_243, 1, 3);
  heff_room[0] = v_t_2415;
  heff_room[1] = v_p_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efailedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efailedAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2efailedAt(V v_aval_240, V v_d_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2eelab_2emeta_2eblockedTy(v_aval_240, heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2etoplevel_2efailedAt_lam0, 1, 3, (V[]){v_d_241, v_hd_242, v_k_243})));
}
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2efailedAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_d_245;
  if ((heff_dup(v_x_244) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    v_d_245 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_d_241, 30ULL, 5, shape_code__severity__msg__span__note, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_x_244);
    v_d_245 = v_d_241;
  }
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_d_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_247}));
  V f_ = heff_get_n(v_hd_242, 1, 3);
  heff_room[0] = v_t_248;
  heff_room[1] = v_k_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_entry, 7, 0};

V g_heff_2eelab_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_248;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    v_t_248 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_247);
    v_t_248 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_k_249 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam0, 1, 1, (V[]){v_k_249})})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam1, 1, 7, (V[]){v_z_245, heff_dup(v_n_242), v_d_243, v_key_240, v_a_244, v_g_241, v_z_246})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabBody(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_249; V rr_ = heff_rec_reuse_nf(v_c_2410, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args) {
  V v_u_2427 = args[0];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2427);
  V v_x1_2428 = heff_tr(heff_call(heff_get_n(v_a_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_Nom: {
    V v_x_2429 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    return v_x_2429;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2431 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    return v_x_2431;
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args) {
  V v_c_2452 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_2452, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args) {
  V v_c_2466 = args[0];
  return heff_get_n(v_c_2466, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args) {
  V v_x_2470 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_body_2449 = heff_env(self)[5];
  V v_hd_2450 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2496;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2471 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_DeclEquations: {
      V v_x113_2475 = heff_field(v_x11_2471, 2);
      V v_tyN_2476 = heff_field(v_x11_2471, 3);
      heff_take_n(v_x11_2471, 12ULL, 5);
      switch (heff_tag_of(v_x113_2475)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2476);
        v_t_2496 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2480;
        switch (heff_tag_of(v_tyN_2476)) {
        case TAG_At: {
          V v_s_2479 = heff_field(v_tyN_2476, 1);
          heff_take_n(v_tyN_2476, 2ULL, 2);
          v_t_2480 = v_s_2479;
          break;
        }
        default: heff_nomatch(v_tyN_2476);
        }
        v_t_2496 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2480});
        break;
      }
      default: heff_nomatch(v_x113_2475);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2471, 0ULL, 5);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2471, 0ULL, 4);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2471, 0ULL, 3);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2471, 0ULL, 2);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2471, 0ULL, 1);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2471);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2498;
  switch (heff_tag_of(v_t_2496)) {
  case TAG_Nothing: {
    v_t_2498 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2496, 0ULL, 1);
    v_t_2498 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2496);
  }
  V v_t_2499 = (g_heff_2eelab_2eunify_2ezonker(v_x_2470));
  V v_t_24100 = heff_tr(heff_call(heff_get_n(v_t_2499, 1, 2), 1, (V[]){heff_get_n(v_a_244, 0, 2)}));
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_d_243; V a_3 = v_t_2498; V a_4 = v_t_24100; V a_5 = v_x_2470; V a_6 = v_body_2449; V a_7 = v_hd_2450; V a_8 = v_k_2451; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2470); heff_drop_rec(v_hd_2450, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2465);
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo)})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){v_t_2468}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  heff_room[0] = v_t_2469;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam10, 1, 8, (V[]){v_n_242, v_a_244, v_key_240, v_g_241, v_d_243, v_body_2449, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args) {
  V v_x_2460 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_hd_2450 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2460);
  V v_t_2463;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2462 = heff_dup(heff_field(v_n_242, 1));
    v_t_2463 = v_s_2462;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2464 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2463, heff_dup(v_d_243)));
  V f_ = v_c_2464;
  heff_room[0] = heff_dup(v_hd_2450);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam8, 1, 8, (V[]){v_hd_2450, v_n_242, v_a_244, v_key_240, v_g_241, v_d_243, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2457 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2456, NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  heff_room[0] = v_t_2459;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam7, 1, 8, (V[]){v_n_242, v_d_243, v_hd_2450, v_a_244, v_key_240, v_g_241, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args) {
  V v_body_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo)})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){v_t_2454}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  args[0] = v_t_2455;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam6, 1, 8, (V[]){v_hd_2450, v_n_242, v_d_243, v_a_244, v_key_240, v_g_241, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2418);
  V v_t_2421;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2420 = heff_dup(heff_field(v_n_242, 1));
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2422 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2423;
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_t_2422);
    v_t_2423 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2422);
    v_t_2423 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_t_2424 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2425;
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_t_2424);
    v_t_2425 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2424);
    v_t_2425 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_h_2426 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2425});
  V v_t_2432 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2426, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam3, 1, 1, (V[]){heff_dup(v_a_244)}), NTAG(TAG_Nothing)));
  V v_x1_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2437;
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_Nom: {
    V v_x_2434 = heff_field(v_x1_2433, 0);
    heff_take_n(v_x1_2433, 1ULL, 1);
    v_t_2437 = v_x_2434;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2437 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2436 = heff_field(v_x1_2433, 0);
    heff_take_n(v_x1_2433, 1ULL, 1);
    v_t_2437 = v_x_2436;
    break;
  }
  default: heff_nomatch(v_x1_2433);
  }
  V v_t_2438 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_244, 0)), v_t_2432, v_t_2437});
  V v_t_2439 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2423, v_t_2438, heff_dup(v_g_241)));
  V v_t_2440 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2441;
  if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
    heff_drop(v_t_2440);
    v_t_2441 = heff_dup(heff_rfield(v_d_243, 0));
  } else {
    heff_drop(v_t_2440);
    v_t_2441 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
  }
  V v_x1_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nom: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2443;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2442, 0ULL, 1);
    v_t_2446 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2445 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_t_2447 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2421, heff_dup(v_d_243), v_t_2439, v_t_2441, v_t_2446));
  V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2447}));
  return (g_co_2ebind_24s1601686549x58384075(v_t_2448, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam4, 3, 5, (V[]){v_n_242, v_d_243, v_a_244, v_key_240, v_g_241}), v_z_245, v_z_246));
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam2, 1, 7, (V[]){v_n_242, v_d_243, v_key_240, v_a_244, v_g_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_244 = heff_field(v_n_242, 0);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_DeclEquations: {
      V v_f_246 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_246)});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2411 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2411)});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2416 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2420 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2420)});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2423 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2423)});
      break;
    }
    case TAG_DeclWatch: {
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    return ({ V rv_1 = v_diags_243; V rr_ = heff_rec_reuse_nf(v_acc_241, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_k_2428 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_t_2429 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_g_2432;
    if (heff_strEq_c(v_t_2429, heff_dup(v_x_2427))) {
      v_g_2432 = heff_dup(heff_rfield(v_acc_241, 0));
    } else {
      V v_t_2431 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
      v_g_2432 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2427), v_t_2431, heff_dup(heff_rfield(v_acc_241, 0))));
    }
    V v_t_2433 = (g_map_2einsert_24s1341440536x470972936(v_k_2428, NTAG(TAG_MkUnit), heff_take_field(v_g_2432, 3)));
    V v_t_2434 = ({ V rv_3 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_g_2432, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_globals_2435 = (g_heff_2eelab_2etoplevel_2ewithBrokenInstance(v_kf_240, v_n_242, v_t_2434));
    V v_t_2438;
    switch (heff_tag_of(v_n_242)) {
    case TAG_At: {
      V v_s_2437 = heff_field(v_n_242, 1);
      v_t_2438 = heff_dup(v_s_2437);
      break;
    }
    default: heff_nomatch(v_n_242);
    }
    V v_broken_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_t_2438}), heff_take_field(v_acc_241, 3)});
    return ({ V rv_0 = v_globals_2435; V rv_1 = v_diags_243; V rv_3 = v_broken_2439; V rr_ = heff_rec_reuse_nf(v_acc_241, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 261936u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etopBroken(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ekeepSt_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_242 = heff_field(v_st_240, 0);
    v_t_245 = heff_dup(v_c_242);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_infos_246 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_245, 0, 8), heff_take_field(v_acc_241, 7)));
  V v_t_2410;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_247 = heff_field(v_st_240, 0);
    v_t_2410 = heff_dup(v_c_247);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_trace_2411 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2410, 6, 8), heff_take_field(v_acc_241, 8)));
  return ({ V rv_7 = v_infos_246; V rv_8 = v_trace_2411; V rr_ = heff_rec_reuse_nf(v_acc_241, 127ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ekeepSt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V v_acc_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_st_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_244, heff_dup(v_acc_240)));
      V v_t_2410;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_247 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2410 = v_c_247;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2411 = heff_get_n(v_t_2410, 1, 8);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
      V v_t_2413 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2412));
      V v_t_2415;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2415 = NTAG(TAG_Nil);
      } else {
        v_t_2415 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2416 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_240, 1, 9), v_t_2413, v_t_2415));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(v_t_246, v_n_241, v_t_2416);
    }
    case TAG_Right: {
      V v_r_2417 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_g_2418 = heff_take_field(v_acc_240, 0);
      V v_t_2419 = heff_take_field(v_r_2417, 2);
      V v_t_2422;
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        V v_t_2420 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_r_2417, 1)), heff_rfield(v_g_2418, 1)));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nothing: {
          v_t_2422 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2417, 1)), heff_dup(heff_rfield(v_r_2417, 4)), v_g_2418));
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2420, 0ULL, 1);
          v_t_2422 = v_g_2418;
          break;
        }
        default: heff_nomatch(v_t_2420);
        }
      } else {
        heff_drop(v_t_2419);
        v_t_2422 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2417, 1)), heff_dup(heff_rfield(v_r_2417, 4)), v_g_2418));
      }
      V v_t_2423 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_r_2417, 0)), heff_dup(heff_rfield(v_r_2417, 1)), v_t_2422));
      V v_globals_2424 = (g_heff_2eelab_2etoplevel_2ewithInstance(heff_rfield(v_r_2417, 3), heff_dup(heff_rfield(v_r_2417, 1)), heff_dup(heff_rfield(v_r_2417, 0)), v_t_2423));
      V v_t_2428;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2425 = heff_dup(heff_field(v_st_244, 0));
        v_t_2428 = v_c_2425;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2429 = heff_get_n(v_t_2428, 1, 8);
      V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
      V v_t_2431 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2430));
      V v_t_2432 = heff_take_field(v_r_2417, 5);
      V v_t_2435;
      switch (heff_tag_of(v_t_2432)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        v_t_2435 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2433 = heff_field(v_t_2432, 0);
        heff_take_n(v_t_2432, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2433, 0)), MK_INT(-1LL))) {
          heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
          heff_drop_rec(v_d_2433, 5);
          v_t_2435 = NTAG(TAG_Nil);
        } else {
          v_t_2435 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_2433, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2432);
      }
      V v_diags_2436 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_240, 1), v_t_2431, v_t_2435));
      V v_t_2439;
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_n_241, 1);
        v_t_2439 = heff_dup(v_s_2438);
        break;
      }
      default: heff_nomatch(v_n_241);
      }
      V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_r_2417, 0), v_t_2439});
      V v_spans_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, heff_take_field(v_acc_240, 6)});
      V v_t_2445;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2442 = heff_dup(heff_field(v_st_244, 0));
        v_t_2445 = v_c_2442;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2446 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2445, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2450;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2447 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2450 = v_c_2447;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2451 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2450, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_2417, 1, 6), heff_take_field(v_acc_240, 2)});
      return ({ V rv_0 = v_globals_2424; V rv_1 = v_diags_2436; V rv_2 = v_t_2452; V rv_6 = v_spans_2441; V rv_7 = v_infos_2446; V rv_8 = v_trace_2451; V rr_ = heff_rec_reuse_nf(v_acc_240, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 4032u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry, 6, 0};

V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(V v_g_240, V v_n_241, V v_d_242, V v_a_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_247 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_246);
    v_t_247 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_k_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0, 1, 1, (V[]){v_k_248})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_z_244, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1, 1, 6, (V[]){v_z_244, heff_dup(v_n_241), v_d_242, v_a_243, v_g_240, v_z_245})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0(V self, V *args) {
  V v_c_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_248; V rr_ = heff_rec_reuse_nf(v_c_249, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3(V self, V *args) {
  V v_u_2426 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2426);
  V v_x1_2427 = heff_tr(heff_call(heff_get_n(v_a_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_Nom: {
    V v_x_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    return v_x_2428;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2430 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    return v_x_2430;
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5(V self, V *args) {
  V v_c_2451 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_2451, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9(V self, V *args) {
  V v_c_2465 = args[0];
  return heff_get_n(v_c_2465, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10(V self, V *args) {
  V v_x_2469 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_body_2448 = heff_env(self)[4];
  V v_hd_2449 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2495;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2470 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_2470)) {
    case TAG_DeclEquations: {
      V v_x113_2474 = heff_field(v_x11_2470, 2);
      V v_tyN_2475 = heff_field(v_x11_2470, 3);
      heff_take_n(v_x11_2470, 12ULL, 5);
      switch (heff_tag_of(v_x113_2474)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2479;
        switch (heff_tag_of(v_tyN_2475)) {
        case TAG_At: {
          V v_s_2478 = heff_field(v_tyN_2475, 1);
          heff_take_n(v_tyN_2475, 2ULL, 2);
          v_t_2479 = v_s_2478;
          break;
        }
        default: heff_nomatch(v_tyN_2475);
        }
        v_t_2495 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2479});
        break;
      }
      default: heff_nomatch(v_x113_2474);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2470, 0ULL, 5);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2470, 0ULL, 4);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2470, 0ULL, 3);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2470, 0ULL, 2);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2470, 0ULL, 1);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2470);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2497;
  switch (heff_tag_of(v_t_2495)) {
  case TAG_Nothing: {
    v_t_2497 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2495, 0ULL, 1);
    v_t_2497 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2495);
  }
  V v_t_2498 = (g_heff_2eelab_2eunify_2ezonker(v_x_2469));
  V v_t_2499 = heff_tr(heff_call(heff_get_n(v_t_2498, 1, 2), 1, (V[]){heff_get_n(v_a_243, 0, 2)}));
  return ({ V a_0 = v_g_240; V a_1 = v_d_242; V a_2 = v_t_2497; V a_3 = v_t_2499; V a_4 = v_x_2469; V a_5 = v_body_2448; V a_6 = v_hd_2449; V a_7 = v_k_2450; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2469); heff_drop_rec(v_hd_2449, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_2449 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_body_2448 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2464);
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9_clo)})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){v_t_2467}));
  V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
  heff_room[0] = v_t_2468;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10, 1, 7, (V[]){v_n_241, v_a_243, v_g_240, v_d_242, v_body_2448, v_hd_2449, v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7(V self, V *args) {
  V v_x_2459 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_2449 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2448 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2459);
  V v_t_2462;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2461 = heff_dup(heff_field(v_n_241, 1));
    v_t_2462 = v_s_2461;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2463 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2462, heff_dup(v_d_242)));
  V f_ = v_c_2463;
  heff_room[0] = heff_dup(v_hd_2449);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8, 1, 7, (V[]){v_hd_2449, v_n_241, v_a_243, v_g_240, v_d_242, v_body_2448, v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2449 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2448 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2456 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2455, NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})}));
  V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
  heff_room[0] = v_t_2458;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7, 1, 7, (V[]){v_n_241, v_d_242, v_hd_2449, v_a_243, v_g_240, v_body_2448, v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4(V self, V *args) {
  V v_body_2448 = args[0];
  V v_hd_2449 = args[1];
  V v_k_2450 = args[2];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){v_t_2453}));
  V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
  args[0] = v_t_2454;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6, 1, 7, (V[]){v_hd_2449, v_n_241, v_d_242, v_a_243, v_g_240, v_body_2448, v_k_2450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  V v_t_2420;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2419 = heff_dup(heff_field(v_n_241, 1));
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2421 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2422;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    v_t_2422 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2421);
    v_t_2422 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2423 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2424;
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_t_2423);
    v_t_2424 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2423);
    v_t_2424 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_h_2425 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2424});
  V v_t_2431 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2425, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
  V v_x1_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2436;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_t_2436 = v_x_2433;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2432, 0ULL, 1);
    v_t_2436 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_t_2436 = v_x_2435;
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V v_t_2437 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_243, 0)), v_t_2431, v_t_2436});
  V v_t_2438 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2422, v_t_2437, heff_dup(v_g_240)));
  V v_t_2439 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2440;
  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
    heff_drop(v_t_2439);
    v_t_2440 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2439);
    v_t_2440 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_x1_2441 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_t_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_t_2446 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2420, heff_dup(v_d_242), v_t_2438, v_t_2440, v_t_2445));
  V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2446}));
  return (g_co_2ebind_24s1601686549x58384075(v_t_2447, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4, 3, 4, (V[]){v_n_241, v_d_242, v_a_243, v_g_240}), v_z_244, v_z_245));
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
  V f_ = heff_dup(heff_rfield(v_z_244, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2, 1, 6, (V[]){v_n_241, v_d_242, v_a_243, v_g_240, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}