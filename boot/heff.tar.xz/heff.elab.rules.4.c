// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_v 336
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_heff_2eelab_2eenvironment_2emultiBind(V, V, V);
V g_heff_2eelab_2eenvironment_2emultiBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2emultiBind_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eglobals_2eisBroken(V, V);
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eisBroken_clo;
V g_heff_2eelab_2eglobals_2elookupKey(V, V);
V g_heff_2eelab_2eglobals_2elookupKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2elookupKey_clo;
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimRune_get(void);
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2ebrokenInstanceIn(V);
V g_heff_2eelab_2erules_2ebrokenInstanceIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebrokenInstanceIn_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2edefaultFor(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultFor_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
V g_heff_2eelab_2erules_2eelStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2eelStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelStrZ_clo;
V g_heff_2eelab_2erules_2eentriesGo_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo;
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eindexOfName(V, V, V);
V g_heff_2eelab_2erules_2eindexOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eindexOfName_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2elargeField(V, V, V, V);
V g_heff_2eelab_2erules_2elargeField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elargeField_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
V g_heff_2eelab_2erules_2enoSuchSetting(V, V, V, V);
V g_heff_2eelab_2erules_2enoSuchSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoSuchSetting_clo;
V g_heff_2eelab_2erules_2enotAFunction(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotAFunction_clo;
V g_heff_2eelab_2erules_2enotANumber(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2eplacesSaid(V);
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_clo;
V g_heff_2eelab_2erules_2eplacesSaid_24acc(V, V);
V g_heff_2eelab_2erules_2eplacesSaid_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_24acc_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2erequireAgree(V, V, V);
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erequireAgree_clo;
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2etraverseE(V, V);
V g_heff_2eelab_2erules_2etraverseE_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etraverseE_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2eupdateOf(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateOf_clo;
V g_heff_2eelab_2erules_2eupdateSetting(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateSetting_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2erules_2evaluesGo_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo;
V g_heff_2eelab_2erules_2evarGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evarGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evarGo_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
Clo g_heff_2eelab_2erules_2edownFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_entry, 1, 0};

V g_heff_2eelab_2erules_2edownFrom(V v_n_240) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_243 = (g_heff_2eelab_2erules_2edownFrom_24dps(heff_intSub(v_n_240, MK_INT(1LL)), heff_dup(v_cell_242)));
    heff_drop(v_u_243);
    return v_cell_242;
  }
}
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom(a[0]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efillHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efillHole_entry, 6, 0};

V g_heff_2eelab_2erules_2efillHole(V v_g_240, V v_m_241, V v_e_242, V v_argStx_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam0, 1, 4, (V[]){v_e_242, v_argStx_243, v_g_240, v_m_241})})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2417}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam1, 1, 2, (V[]){v_hd_244, v_k_245})});
}
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efillHole(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_argStx_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_s_247 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), heff_dup(v_argStx_243)));
  V v_x1_248 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), v_s_247, NTAG(TAG_LNil)));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2413 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), v_argStx_243));
  V v_t_2414 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413}); V rr_ = heff_rec_reuse_nf(v_e_242, 57ULL, 6, shape_ty__sol__solStx__arity__name__span, 4035u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_mc_2415 = (g_map_2einsert_24s1689409319x1710080871(v_m_241, v_t_2414, heff_take_field(v_c_246, 3)));
  return ({ V rv_3 = v_mc_2415; V rr_ = heff_rec_reuse_nf(v_c_246, 247ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2422;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ebrokenInstanceIn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ebrokenInstanceIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ebrokenInstanceIn_entry, 1, 0};

V g_heff_2eelab_2erules_2ebrokenInstanceIn(V v_e_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_e_240, 1)), 6, 7);
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_241));
  return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ebrokenInstanceIn_lam0, 1, 1, (V[]){v_e_240}); V a_1 = v_t_242; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_242); r_; });
}
V g_heff_2eelab_2erules_2ebrokenInstanceIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ebrokenInstanceIn(a[0]);
}
V g_heff_2eelab_2erules_2ebrokenInstanceIn_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_244 = heff_get_n(v_e_240, 1, 6);
  V v_k_245 = heff_get_n(v_i_243, 0, 2);
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_245), heff_rfield(v_g_244, 1)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(v_k_245, heff_rfield(v_g_244, 2)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_244, 7);
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      V v_k2_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_249 = ({ V a_0 = v_k2_248; V b_1 = heff_get_n(v_g_244, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_t_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop_rec(v_g_244, 7);
    heff_drop(v_k_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_246);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eimplicitLams_str2, 1, "_");
V g_heff_2eelab_2erules_2eimplicitLams_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eimplicitLams_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eimplicitLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitLams_entry, 1, 0};

V g_heff_2eelab_2erules_2eimplicitLams(V v_c_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam0, 4, 1, (V[]){heff_dup(v_c_240)})});
}
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eimplicitLams(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eimplicitLams_lam1(V self, V *args) {
  V v_c_245 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_245, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eimplicitLams_lam4(V self, V *args) {
  V v_u_2430 = args[0];
  V v_v_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return v_v_2424;
}
V g_heff_2eelab_2erules_2eimplicitLams_lam7(V self, V *args) {
  V v_u_2465 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2465);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_249});
}
V g_heff_2eelab_2erules_2eimplicitLams_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_cod_2415 = heff_env(self)[2];
  V v_k_2451 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2453 = heff_take_field(v_e_241, 2);
  V v_t_2456;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_ForNominative: {
    v_t_2456 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2456 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 4);
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 0, 4);
  V v_t_2459 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2458, heff_dup(v_x_249)));
  V v_t_2464;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2460 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 3);
    v_t_2464 = v_n_2460;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2415, 0ULL, 1);
    v_t_2464 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_str2);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_x_2466 = (g_heff_2eelab_2ememoed_2elam(v_t_2456, heff_get_n(v_e_241, 1, 6), v_t_2457, heff_rec_n(2, shape_stx__val, (V[]){v_t_2459, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam7, 1, 1, (V[]){v_x_249})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_2464, v_x_2452})));
  V f_ = v_k_2451;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_lam5(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_cod_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2449;
  args[0] = v_hd_2450;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam6, 1, 4, (V[]){v_e_241, v_x_249, v_cod_2415, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eimplicitLams_lam3(V self, V *args) {
  V v_v_2424 = args[0];
  V v_scope_27_2425 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_cod_2415 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_implicit_2416 = heff_env(self)[3];
  V v_dom_2414 = heff_env(self)[4];
  V v_x_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2426 = ({ V a_0 = v_c_240; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_c_240); r_; });
  V v_x1_2432;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2428 = heff_dup(heff_field(v_cod_2415, 1));
    V v_body_2429 = heff_dup(heff_field(v_cod_2415, 2));
    v_x1_2432 = heff_tr(heff_call(v_body_2429, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2428, heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam4, 1, 1, (V[]){heff_dup(v_v_2424)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2431 = heff_dup(heff_field(v_cod_2415, 0));
    v_x1_2432 = v_body_2431;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_a_2436;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_a_2436 = v_x_2433;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2432, 0ULL, 1);
    v_a_2436 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_a_2436 = v_x_2435;
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V v_c_2449;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_MkChk: {
    V v_f_2437 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    V v_t_2438 = heff_dup(heff_rfield(v_e_241, 2));
    V v_t_2441;
    switch (heff_tag_of(v_t_2438)) {
    case TAG_ForNominative: {
      v_t_2441 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2439 = heff_field(v_t_2438, 0);
      V v_sp_2440 = heff_field(v_t_2438, 1);
      V v_ru_24t_2438_24ForDescriptive = heff_take_reuse_n(v_t_2438, 3ULL, 2);
      v_t_2441 = heff_tag_at_n(v_ru_24t_2438_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2439, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2440, heff_dup(v_v_2424)})});
      break;
    }
    default: heff_nomatch(v_t_2438);
    }
    V v_t_2447;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      heff_drop(v_v_2424);
      heff_drop(v_dom_2414);
      v_t_2447 = heff_dup(heff_rfield(v_e_241, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2424);
      heff_drop(v_dom_2414);
      v_t_2447 = heff_dup(heff_rfield(v_e_241, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_2446;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2442 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2446 = v_n_2442;
        break;
      }
      case TAG_CloConst: {
        v_t_2446 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_str1);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_2446, v_dom_2414, v_v_2424}), heff_dup(heff_rfield(v_e_241, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    V v_t_2448 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2425, heff_dup(heff_rfield(v_e_241, 1)), v_t_2441, heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), v_t_2447});
    v_c_2449 = heff_tr(heff_call(v_f_2437, 2, (V[]){v_t_2448, v_a_2436}));
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam5, 2, 4, (V[]){v_c_2449, v_e_241, v_x_249, v_cod_2415});
}
V g_heff_2eelab_2erules_2eimplicitLams_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_249)));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2412 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2412;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_t_2410, 1);
    V v_cod_2415 = heff_field(v_t_2410, 2);
    V v_implicit_2416 = heff_field(v_t_2410, 3);
    heff_take_n(v_t_2410, 14ULL, 4);
    V v_t_2417;
    switch (heff_tag_of(v_implicit_2416)) {
    case TAG_Expl: {
      v_t_2417 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2416);
    }
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      heff_drop(v_implicit_2416);
      heff_drop(v_t_2417);
      switch (heff_tag_of(v_c_240)) {
      case TAG_MkChk: {
        V v_f_2418 = heff_field(v_c_240, 0);
        heff_take_n(v_c_240, 1ULL, 1);
        V f_ = v_f_2418;
        heff_room[0] = v_e_241;
        heff_room[1] = v_x_249;
        heff_room[2] = v_hd_243;
        heff_room[3] = v_k_244;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_c_240);
      }
    } else {
      heff_drop(v_t_2417);
      V v_t_2423;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2419 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2423 = v_n_2419;
        break;
      }
      case TAG_CloConst: {
        v_t_2423 = ((V)&g_heff_2eelab_2erules_2eimplicitLams_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_t_2467 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2423, heff_dup(v_dom_2414), heff_dup(heff_rfield(v_e_241, 0)), heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam3, 2, 6, (V[]){v_c_240, v_cod_2415, v_e_241, v_implicit_2416, v_dom_2414, v_x_249})));
      V f_ = v_t_2467;
      heff_room[0] = v_hd_243;
      heff_room[1] = v_k_244;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2410, 0ULL, 3);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2471 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2471;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2473 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2473;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeInt: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2474 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2474;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFloat: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2475 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2475;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeString: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2476 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2476;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeRune: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2477 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2477;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2479 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2479;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2410, 0ULL, 1);
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2481 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2481;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  case TAG_NoRules: {
    switch (heff_tag_of(v_c_240)) {
    case TAG_MkChk: {
      V v_f_2482 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      V f_ = v_f_2482;
      heff_room[0] = v_e_241;
      heff_room[1] = v_x_249;
      heff_room[2] = v_hd_243;
      heff_room[3] = v_k_244;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
    default: return heff_nomatch(v_c_240);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a0_242 = args[1];
  V v_hd_243 = args[2];
  V v_k_244 = args[3];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam1, 1, 1, (V[]){v_a0_242})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_248;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eimplicitLams_lam2, 1, 4, (V[]){v_c_240, v_e_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2erequireAgree_str0, 62, "the binder's annotation is not the argument type expected here");
V g_heff_2eelab_2erules_2erequireAgree_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erequireAgree_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erequireAgree_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erequireAgree_lam1, 2, 0};
Clo g_heff_2eelab_2erules_2erequireAgree_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erequireAgree_entry, 3, 0};

V g_heff_2eelab_2erules_2erequireAgree(V v_e_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_note_244 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_243; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_243); r_; });
    return heff_clo_n(g_heff_2eelab_2erules_2erequireAgree_lam0, 2, 2, (V[]){v_sp_241, v_note_244});
  }
  case TAG_Right: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_sp_241);
    return ((V)&g_heff_2eelab_2erules_2erequireAgree_lam1_clo);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erequireAgree(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2erequireAgree_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_note_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erequireAgree_str0), v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_244})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_249}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  args[0] = v_t_2410;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erequireAgree_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str0, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str1, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str2, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str3, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str4, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str5, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str6, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str7, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str8, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str9, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str10, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroImplicit_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntroImplicit(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2efunctionIntroImplicit(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args) {
  V v_u_2432 = args[0];
  V v_v_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2432);
  return v_v_2427;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2449 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2451 = heff_take_field(v_e_243, 2);
  V v_t_2454;
  switch (heff_tag_of(v_t_2451)) {
  case TAG_ForNominative: {
    v_t_2454 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2451, 0ULL, 2);
    v_t_2454 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2451);
  }
  V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2457 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2456, heff_dup(v_x_2411)));
  V v_x_2459 = (g_heff_2eelab_2ememoed_2elam(v_t_2454, heff_get_n(v_e_243, 1, 6), v_t_2455, heff_rec_n(2, shape_stx__val, (V[]){v_t_2457, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2450})));
  V f_ = v_k_2449;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args) {
  V v_v_2427 = args[0];
  V v_scope_27_2428 = args[1];
  V v_cod_2420 = heff_env(self)[0];
  V v_body_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_implicit_2421 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_dom_2419 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2434;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2430 = heff_field(v_cod_2420, 1);
    V v_body_2431 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2434 = heff_tr(heff_call(v_body_2431, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2430, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4, 1, 1, (V[]){heff_dup(v_v_2427)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2433 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    v_x1_2434 = v_body_2433;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2438;
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    v_a_2438 = v_x_2435;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    v_a_2438 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    v_a_2438 = v_x_2437;
    break;
  }
  default: heff_nomatch(v_x1_2434);
  }
  V v_c_2447;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2439 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2440 = heff_dup(heff_rfield(v_e_243, 2));
    V v_t_2443;
    switch (heff_tag_of(v_t_2440)) {
    case TAG_ForNominative: {
      v_t_2443 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2441 = heff_field(v_t_2440, 0);
      V v_sp_2442 = heff_field(v_t_2440, 1);
      V v_ru_24t_2440_24ForDescriptive = heff_take_reuse_n(v_t_2440, 3ULL, 2);
      v_t_2443 = heff_tag_at_n(v_ru_24t_2440_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2441, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2442, heff_dup(v_v_2427)})});
      break;
    }
    default: heff_nomatch(v_t_2440);
    }
    V v_t_2444 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
    V v_t_2445;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      heff_drop(v_v_2427);
      heff_drop(v_dom_2419);
      v_t_2445 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2427);
      heff_drop(v_dom_2419);
      v_t_2445 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Inst: {
      v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){heff_dup(v_x_241), v_dom_2419, v_v_2427}), heff_dup(heff_rfield(v_e_243, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    V v_t_2446 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2428, heff_dup(heff_rfield(v_e_243, 1)), v_t_2443, v_t_2444, heff_dup(heff_rfield(v_e_243, 4)), v_t_2445});
    v_c_2447 = heff_tr(heff_call(v_f_2439, 2, (V[]){v_t_2446, v_a_2438}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5, 2, 4, (V[]){v_c_2447, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at_n(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2417;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_x_2411);
      heff_drop(v_x_241);
      heff_drop_rec(v_e_243, 6);
      heff_drop(v_body_242);
      heff_drop(v_dom_2419);
      heff_drop(v_cod_2420);
      heff_drop(v_implicit_2421);
      heff_drop(v_t_2422);
      V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2425}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2426;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2422);
      V v_t_2460 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), heff_dup(v_dom_2419), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3, 2, 7, (V[]){v_cod_2420, v_body_242, v_e_243, v_implicit_2421, v_x_241, v_dom_2419, v_x_2411})));
      V f_ = v_t_2460;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2466}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2467;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2470 = heff_tag_at_n(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2471}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2472;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2475}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2476;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2479}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2480;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2483}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2484;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2487}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2488;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2491 = heff_tag_at_n(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2492}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2493;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2412_24LikeFixed = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2496 = heff_tag_at_n(v_ru_24t_2412_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2497}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2498;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2499 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24101}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24102;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str0, 65, "tried to apply a value as a function, where its type is not known");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str1, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str2, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str3, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str4, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str5, 27, "the value applied here is `");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str6, 1, "`");
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enotAFunction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotAFunction_entry, 6, 0};

V g_heff_2eelab_2erules_2enotAFunction(V v_e_240, V v_sp_241, V v_ecallee_242, V v_a_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2427;
  switch (heff_tag_of(v_a_243)) {
  case TAG_VU: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_247 = heff_dup(heff_field(v_a_243, 0));
    switch (heff_tag_of(v_t1_247)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_247);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_e_240);
    heff_drop_rec(v_ecallee_242, 2);
    heff_drop(v_a_243);
    heff_drop(v_t_2427);
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2enotAFunction_str0), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2430}));
    return heff_tail(heff_get_n(v_p_244, 1, 3), 2, (V[]){v_t_2431, v_p_245});
  } else {
    heff_drop(v_t_2427);
    return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_240), v_a_243, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam0, 1, 5, (V[]){v_e_240, v_ecallee_242, v_p_244, v_sp_241, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enotAFunction(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_ecallee_242 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2434 = heff_get_n(v_ecallee_242, 0, 2);
  V v_t_2470;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2434, 0ULL, 3);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2459 = heff_field(v_t_2434, 0);
    heff_take_n(v_t_2434, 1ULL, 3);
    v_t_2470 = v_k_2459;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  if (heff_intLe_c(MK_INT(0LL), v_t_2470)) {
    heff_drop(v_x_2433);
    V v_t_2472 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str1), heff_strAppend(v_x_2432, ((V)&g_heff_2eelab_2erules_2enotAFunction_str2)));
    V v_t_2473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2472, v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2475}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2476;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2477 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str3), heff_strAppend(v_x_2432, ((V)&g_heff_2eelab_2erules_2enotAFunction_str4)));
    V v_t_2478 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str5), heff_strAppend(v_x_2433, ((V)&g_heff_2eelab_2erules_2enotAFunction_str6)));
    V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2477, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2481}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2482;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ecallee_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eelStrZ(v_e_240, heff_dup(v_ecallee_242), heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam1, 1, 5, (V[]){v_ecallee_242, v_x_2432, v_sp_241, v_p_244, v_p_245})));
}
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str0, 5, "unify");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str1, 8, "   FAILS");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str2, 5, "   ok");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str3, 7, "  =\?=  ");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str4, 15, ", but got type ");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str5, 14, "expected type ");
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eapplyGo_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_lam4, 1, 0};
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eapplyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eapplyGo(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_a_27_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = heff_dup(heff_rfield(v_e_241, 0));
    return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam0, 2, 4, (V[]){v_c_248, heff_dup(v_e_241), heff_dup(v_a_242), heff_dup(v_a_27_247)}), heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam1, 1, 7, (V[]){v_m_246, v_e_241, v_a_242, v_a_27_247, v_p_244, v_sp_240, v_p_245})));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eapplyGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_p_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_248, 0), heff_get_n(v_c_248, 1, 4)});
  V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){heff_get_n(v_e_241, 1, 6), v_t_2411, v_a_242, v_a_27_247}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2412, v_p_249, v_p_2410));
}
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args) {
  V v_c_2425 = args[0];
  return heff_get_n(v_c_2425, 3, 8);
}
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args) {
  V v_u_2430 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2430);
  V v_t_2431 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_241), v_x_2429, v_a_242));
  V v_t_2432 = ({ V a_0 = v_e_241; V a_1 = v_x_2429; V a_2 = v_a_27_247; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2429); r_; });
  V v_t_2435;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str1);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str2);
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V v_t_2436 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str3), heff_strAppend(v_t_2432, v_t_2435));
  return heff_strAppend(v_t_2431, v_t_2436);
}
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_err_2440 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_note_2443 = ({ V a_0 = heff_get_n(v_e_241, 1, 6); V a_1 = v_err_2440; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2440); r_; });
  V v_t_2444 = heff_strAppend(v_x_2441, heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str4), v_x_2442));
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str5), v_t_2444), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){v_note_2443})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2447}));
  V f_ = heff_get_n(v_p_244, 1, 3);
  heff_room[0] = v_t_2448;
  heff_room[1] = v_p_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_27_247 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_err_2440 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_a_27_247, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam9, 1, 6, (V[]){v_e_241, v_err_2440, v_x_2441, v_sp_240, v_p_244, v_p_245})));
}
V g_heff_2eelab_2erules_2eapplyGo_lam10(V self, V *args) {
  V v_x_2453 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_m_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  V f_ = v_p_245;
  args[0] = v_m_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_a_27_247 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  V v_m_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2439);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2440 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    heff_drop_rec(v_m_246, 2);
    return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_241), v_a_242, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam8, 1, 6, (V[]){v_e_241, v_a_27_247, v_p_244, v_err_2440, v_sp_240, v_p_245})));
  }
  case TAG_Right: {
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    heff_drop_rec(v_e_241, 6);
    heff_drop(v_a_242);
    heff_drop(v_a_27_247);
    heff_drop(v_sp_240);
    V v_t_2450 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2451 = heff_tag_at_n(v_ru_24x_2424_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2451}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2452;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam10, 1, 2, (V[]){v_p_245, v_m_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  V v_m_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2437 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2eapplyGo_str0), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam6, 1, 5, (V[]){heff_dup(v_e_241), v_x_2429, heff_dup(v_a_242), heff_dup(v_a_27_247), heff_dup(v_x_2424)})}), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam7, 1, 8, (V[]){v_x_2424, v_e_241, v_a_242, v_p_244, v_a_27_247, v_sp_240, v_p_245, v_m_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_247 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  V v_m_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eapplyGo_lam4_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){v_t_2427}));
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2428;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam5, 1, 8, (V[]){v_sp_240, v_e_241, v_a_242, v_a_27_247, v_x_2424, v_p_244, v_p_245, v_m_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2423;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    V v_x1_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_246, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2419;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nom: {
      V v_x_2416 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2416;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2415, 0ULL, 1);
      v_t_2419 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2especialized_clo), 5, (V[]){heff_dup(v_e_241), v_t_2419, heff_dup(v_a_242), heff_dup(v_a_27_247), heff_tag_n(TAG_Left, 1, (V[]){v_err_2414})}));
    break;
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_c_2423 = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam2, 2, 1, (V[]){v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam3, 1, 7, (V[]){v_p_244, v_sp_240, v_e_241, v_a_242, v_a_27_247, v_p_245, v_m_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimRune_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimRune_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimRune_st;
static V g_heff_2eelab_2erules_2eprimRune_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimRune_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimRune_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimRune_st)) return g_heff_2eelab_2erules_2eprimRune_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimRune_val, &g_heff_2eelab_2erules_2eprimRune_st, g_heff_2eelab_2erules_2eprimRune_init);
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str0, 8, "a number");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str1, 7, "a float");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str2, 11, ", which is ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str3, 22, ", but got the literal ");
HEFF_LIT(g_heff_2eelab_2erules_2enotANumber_str4, 14, "expected type ");
V g_heff_2eelab_2erules_2enotANumber_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam0(V self, V *args);
V g_heff_2eelab_2erules_2enotANumber_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2enotANumber_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotANumber_entry, 6, 0};

V g_heff_2eelab_2erules_2enotANumber(V v_sp_240, V v_e_241, V v_a_242, V v_lit_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2427;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_247 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_h_247)) {
    case TAG_HLocal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_247);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_sp_240);
    heff_drop(v_e_241);
    heff_drop_rec(v_p_244, 3);
    heff_drop(v_t_2427);
    V v_t_2431 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam0, 1, 1, (V[]){v_a_242})});
    return heff_tail(v_p_245, 1, (V[]){v_t_2431});
  } else {
    heff_drop(v_t_2427);
    return (g_heff_2eelab_2erules_2etyStrZ(v_e_241, v_a_242, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam2, 1, 4, (V[]){heff_dup(v_lit_243), v_sp_240, v_p_244, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2enotANumber(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2enotANumber_lam1(V self, V *args) {
  V v_u_2429 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  return v_a_242;
}
V g_heff_2eelab_2erules_2enotANumber_lam0(V self, V *args) {
  V v_u_2428 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  V v_t_2430 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2enotANumber_lam1, 1, 1, (V[]){v_a_242}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2430});
}
V g_heff_2eelab_2erules_2enotANumber_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  V v_lit_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435;
  switch (heff_tag_of(v_lit_243)) {
  case TAG_IntNum: {
    V v_i_2433 = heff_dup(heff_field(v_lit_243, 0));
    v_t_2435 = heff_intShow(v_i_2433);
    break;
  }
  case TAG_FracNum: {
    V v_x_2434 = heff_tget_v(v_lit_243, 0);
    v_t_2435 = heff_floatShow(v_x_2434);
    break;
  }
  default: heff_nomatch(v_lit_243);
  }
  V v_t_2438;
  switch (heff_tag_of(v_lit_243)) {
  case TAG_IntNum: {
    heff_take_n(v_lit_243, 0ULL, 1);
    v_t_2438 = ((V)&g_heff_2eelab_2erules_2enotANumber_str0);
    break;
  }
  case TAG_FracNum: {
    heff_take_na(v_lit_243, 0ULL, 1);
    v_t_2438 = ((V)&g_heff_2eelab_2erules_2enotANumber_str1);
    break;
  }
  default: heff_nomatch(v_lit_243);
  }
  V v_t_2439 = heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str2), v_t_2438));
  V v_t_2440 = heff_strAppend(v_x_2432, heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str3), v_t_2439));
  V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2enotANumber_str4), v_t_2440), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2443}));
  V f_ = heff_get_n(v_p_244, 1, 3);
  heff_room[0] = v_t_2444;
  heff_room[1] = v_p_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam0, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam2, 1, 0};
Clo g_heff_2eelab_2erules_2enumLitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitAt(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_247, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam0_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2418});
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      V v_t_2419 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_i_246))});
      return heff_tail(v_z_245, 1, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2419, ((V)&g_heff_2eelab_2erules_2enumLitAt_lam1_clo)})});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2422 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      return (g_heff_2eelab_2erules_2eintAtFixed(v_sp_240, v_w_2422, v_i_246, v_z_244, v_z_245));
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_FracNum: {
    double v_x_2423 = heff_tflat_f64(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2424, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2424, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      V v_t_2435 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_x_2423)}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam2_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2435});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2437 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      V v_t_2438;
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I16: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I32: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I64: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U8: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U16: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U32: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U64: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_F32: {
        v_t_2438 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_e_241);
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
        heff_drop(v_t_2438);
        V v_t_2439 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_floatShow(heff_box_f64(v_x_2423)), heff_box_f64(v_x_2423)));
        return heff_tail(v_t_2439, 2, (V[]){v_z_244, v_z_245});
      } else {
        heff_drop(v_t_2438);
        return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
      }
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args) {
  V v_u_2420 = args[0];
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args) {
  V v_u_2434 = args[0];
  heff_drop(v_u_2434);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
HEFF_LIT(g_heff_2eelab_2erules_2elargeField_str0, 3, " : ");
HEFF_LIT(g_heff_2eelab_2erules_2elargeField_str1, 3, " : ");
Clo g_heff_2eelab_2erules_2elargeField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elargeField_entry, 4, 0};

V g_heff_2eelab_2erules_2elargeField(V v_e_240, V v_x_241, V v_ty_242, V v_after_243) {
top: ;
  V v_x1_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_ty_242, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_248;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nom: {
    V v_t_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    v_x1_248 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_245); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_246 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    v_x1_248 = ({ V a_0 = v_t_246; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_246); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_247 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    v_x1_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_247); r_; });
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Small: {
    heff_drop(v_e_240);
    heff_drop(v_x_241);
    heff_drop_rec(v_ty_242, 2);
    return v_after_243;
  }
  case TAG_Large: {
    heff_drop(v_after_243);
    V v_t_249 = (g_heff_2eelab_2erules_2etyStrM(v_e_240, v_ty_242));
    V v_t_2410 = heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2elargeField_str0), v_t_249));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  }
  case TAG_TopL: {
    heff_drop(v_after_243);
    V v_t_2411 = (g_heff_2eelab_2erules_2etyStrM(v_e_240, v_ty_242));
    V v_t_2412 = heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2elargeField_str1), v_t_2411));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2erules_2elargeField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2elargeField(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2erules_2eappendP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_entry, 2, 0};

V g_heff_2eelab_2erules_2eappendP(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2erules_2eappendP_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP(a[0], a[1]);
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args);
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultFor_entry, 4, 0};

V g_heff_2eelab_2erules_2edefaultFor(V v_x1_240, V v_g_241, V v_vs_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_ForNominative: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_243), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam0, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  case TAG_ForDescriptive: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(v_d_243)}), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam1, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2edefaultFor(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
}
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_247);
  V v_x1_248 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2412});
}
Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eentriesGo_24dps_entry, 7, 0};

V g_heff_2eelab_2erules_2eentriesGo_24dps(V v_n_240, V v_k_241, V v_places_242, V v_x4_243, V v_x5_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_k_241);
    heff_drop(v_places_242);
    heff_drop(v_x5_244);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_k_241);
      heff_drop(v_places_242);
      heff_drop(v_i_245);
      heff_drop_rec(v_m_247, 5);
      heff_drop(v_rest_248);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_pl_249 = heff_field(v_x5_244, 0);
      V v_pls_2410 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_pl_249)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), heff_dup(v_k_241), heff_dup(v_places_242), heff_dup(v_m_247), heff_dup(v_i_245)));
        break;
      }
      case TAG_Just: {
        V v_p_2411 = heff_field(v_pl_249, 0);
        V v_ru_24pl_249_24Just = heff_take_reuse_n(v_pl_249, 1ULL, 1);
        V v_t_2412 = heff_intSub(heff_intSub(heff_dup(v_k_241), MK_INT(1LL)), v_p_2411);
        v_t_2413 = heff_tag_at_n(v_ru_24pl_249_24Just, TAG_SLocal, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_pl_249);
      }
      V v_t_2414 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_m_247, 0, 5), v_t_2413});
      V v_cell_2415 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
      V v_u_2416 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_n_240;
      V t_1 = v_k_241;
      V t_2 = v_places_242;
      V t_3 = v_rest_248;
      V t_4 = v_pls_2410;
      V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
      V t_6 = v_cell_2415;
      v_n_240 = t_0;
      v_k_241 = t_1;
      v_places_242 = t_2;
      v_x4_243 = t_3;
      v_x5_244 = t_4;
      v_i_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eentriesGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2eelab_2erules_2evaluesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_entry, 5, 0};

V g_heff_2eelab_2erules_2evaluesGo(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_245);
      heff_drop(v_rest_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_pls_248 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_Nothing: {
        heff_drop(v_m_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_246;
        V t_3 = v_pls_248;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        goto top;
      }
      case TAG_Just: {
        V v_p_249 = heff_field(v_x41_247, 0);
        heff_take_n(v_x41_247, 1ULL, 1);
        V v_t_2410 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_249, heff_dup(v_places_241), heff_dup(v_m_245), heff_dup(v_i_244)));
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_245, v_t_2410}), heff_hole()});
        V v_u_2412 = (g_heff_2eelab_2erules_2evaluesGo_24dps(v_n_240, v_places_241, v_rest_246, v_pls_248, heff_intAdd(v_i_244, MK_INT(1LL)), heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2evaluesGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2etraverseE_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etraverseE_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etraverseE_lam0, 2, 0};
V g_heff_2eelab_2erules_2etraverseE_lam3(V self, V *args);
V g_heff_2eelab_2erules_2etraverseE_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etraverseE_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etraverseE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etraverseE_entry, 2, 0};

V g_heff_2eelab_2erules_2etraverseE(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2erules_2etraverseE_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2erules_2etraverseE_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2etraverseE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etraverseE(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etraverseE_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etraverseE_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etraverseE_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2erules_2etraverseE(v_f_240, v_xs_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etraverseE_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etraverseE_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etraverseE_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str1, 25, "no case provided for tag ");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecaseArm_str4, 43, "wrong number of arguments provided for tag ");
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseArm_entry, 7, 0};

V g_heff_2eelab_2erules_2ecaseArm(V v_sp_240, V v_e_241, V v_b_242, V v_a_243, V v_x_244, V v_ts_245, V v_casesChk_246) {
top: ;
  V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_244), heff_rfield(v_casesChk_246, 1)));
  V v_it_2413;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_it_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    V v_xs_249 = heff_dup(heff_rfield(v_casesChk_246, 2));
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_248))) {
      if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength(heff_dup(v_xs_249)))) {
        V v_t_2412 = heff_arrayIndex(v_xs_249, v_i_248);
        v_it_2413 = heff_tag_at_n(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){v_t_2412});
      } else {
        heff_drop(v_i_248);
        heff_drop_cell(v_ru_24t_247_24Just, 1);
        heff_drop(v_xs_249);
        v_it_2413 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_i_248);
      heff_drop_cell(v_ru_24t_247_24Just, 1);
      heff_drop(v_xs_249);
      v_it_2413 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_it_2413)) {
  case TAG_Nothing: {
    V v_t_2414 = (g_map_2elookup_24s1546226666x2146984184(((V)&g_heff_2eelab_2erules_2ecaseArm_str0), heff_rfield(v_casesChk_246, 1)));
    V v_it_2420;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      heff_drop_rec(v_casesChk_246, 3);
      v_it_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_2415 = heff_field(v_t_2414, 0);
      V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
      V v_xs_2416 = heff_get_n(v_casesChk_246, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2415))) {
        if (heff_intLt_c(heff_dup(v_i_2415), heff_arrayLength(heff_dup(v_xs_2416)))) {
          V v_t_2419 = heff_arrayIndex(v_xs_2416, v_i_2415);
          v_it_2420 = heff_tag_at_n(v_ru_24t_2414_24Just, TAG_Just, 1, (V[]){v_t_2419});
        } else {
          heff_drop(v_i_2415);
          heff_drop_cell(v_ru_24t_2414_24Just, 1);
          heff_drop(v_xs_2416);
          v_it_2420 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_2415);
        heff_drop_cell(v_ru_24t_2414_24Just, 1);
        heff_drop(v_xs_2416);
        v_it_2420 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    switch (heff_tag_of(v_it_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_e_241, 6);
      heff_drop(v_b_242);
      heff_drop(v_ts_245);
      return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam0, 2, 2, (V[]){v_x_244, v_sp_240});
    }
    case TAG_Just: {
      V v_it1_2427 = heff_field(v_it_2420, 0);
      heff_take_n(v_it_2420, 1ULL, 1);
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_it1_2427)) {
      case TAG_MkPair: {
        V v_bodyChk_2429 = heff_field(v_it1_2427, 1);
        heff_take_n(v_it1_2427, 2ULL, 2);
        V v_t_2430 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str2), heff_dup(v_ts_245)));
        V v_t_2431 = (g_list_2emap_24s1990719097x1419059608(heff_dup(v_ts_245)));
        V v_sc_2432 = ({ V a_0 = v_t_2430; V a_1 = v_t_2431; V a_2 = heff_take_field(v_e_241, 0); V r_ = (g_heff_2eelab_2eenvironment_2emultiBind(a_0, a_1, a_2)); heff_drop(v_t_2430); heff_drop(v_t_2431); r_; });
        V v_c_2435;
        switch (heff_tag_of(v_bodyChk_2429)) {
        case TAG_MkChk: {
          V v_f_2433 = heff_field(v_bodyChk_2429, 0);
          heff_take_n(v_bodyChk_2429, 1ULL, 1);
          V v_t_2434 = ({ V rv_0 = v_sc_2432; V rr_ = heff_rec_reuse_nf(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          v_c_2435 = heff_tr(heff_call(v_f_2433, 2, (V[]){v_t_2434, v_b_242}));
          break;
        }
        default: heff_nomatch(v_bodyChk_2429);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam1, 2, 3, (V[]){v_c_2435, v_ts_245, v_x_244});
      }
      default: return heff_nomatch(v_it1_2427);
      }
    }
    default: return heff_nomatch(v_it_2420);
    }
  }
  case TAG_Just: {
    V v_it1_2442 = heff_field(v_it_2413, 0);
    heff_take_n(v_it_2413, 1ULL, 1);
    heff_drop_rec(v_casesChk_246, 3);
    switch (heff_tag_of(v_it1_2442)) {
    case TAG_MkPair: {
      V v_xs_2443 = heff_field(v_it1_2442, 0);
      V v_bodyChk_2444 = heff_field(v_it1_2442, 1);
      heff_take_n(v_it1_2442, 3ULL, 2);
      V v_t_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_245));
      if (heff_intEq_c(heff_arrayLength(heff_dup(v_xs_2443)), v_t_2445)) {
        heff_drop(v_sp_240);
        V v_t_2447 = (g_list_2emap_24s1990719097x1419059608(v_ts_245));
        V v_sc_2448 = ({ V b_0 = heff_arrayToList(heff_dup(v_xs_2443)); V a_1 = v_t_2447; V a_2 = heff_take_field(v_e_241, 0); V r_ = (g_heff_2eelab_2eenvironment_2emultiBind(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2447); r_; });
        V v_c_2451;
        switch (heff_tag_of(v_bodyChk_2444)) {
        case TAG_MkChk: {
          V v_f_2449 = heff_field(v_bodyChk_2444, 0);
          heff_take_n(v_bodyChk_2444, 1ULL, 1);
          V v_t_2450 = ({ V rv_0 = v_sc_2448; V rr_ = heff_rec_reuse_nf(v_e_241, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          v_c_2451 = heff_tr(heff_call(v_f_2449, 2, (V[]){v_t_2450, v_b_242}));
          break;
        }
        default: heff_nomatch(v_bodyChk_2444);
        }
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam3, 2, 3, (V[]){v_c_2451, v_xs_2443, v_x_244});
      } else {
        heff_drop_rec(v_e_241, 6);
        heff_drop(v_b_242);
        heff_drop(v_ts_245);
        heff_drop(v_xs_2443);
        heff_drop(v_bodyChk_2444);
        return heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam5, 2, 2, (V[]){v_x_244, v_sp_240});
      }
    }
    default: return heff_nomatch(v_it1_2442);
    }
  }
  default: return heff_nomatch(v_it_2413);
  }
}
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2ecaseArm(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2ecaseArm_lam0(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str1), v_x_244), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_2421, 2), 1, (V[]){v_t_2425}));
  V f_ = heff_get_n(v_hd_2421, 1, 3);
  args[0] = v_t_2426;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam2(V self, V *args) {
  V v_x_2438 = args[0];
  V v_ts_245 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2ecaseArm_str3), v_ts_245));
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_2439), heff_get_n(v_x_2438, 0, 2)});
  V v_x_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_t_2440});
  V f_ = v_k_2437;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam1(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_ts_245 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam2, 1, 3, (V[]){v_ts_245, v_x_244, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam4(V self, V *args) {
  V v_x_2454 = args[0];
  V v_xs_2443 = heff_env(self)[0];
  V v_k_2453 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){v_xs_2443, heff_get_n(v_x_2454, 0, 2)});
  V f_ = v_k_2453;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_t_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam3(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_c_2451 = heff_env(self)[0];
  V v_xs_2443 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2451;
  args[0] = v_hd_2452;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseArm_lam4, 1, 3, (V[]){v_xs_2443, v_k_2453, v_x_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseArm_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2ecaseArm_str4), v_x_244), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_2456, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2456, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str0, 46, "cannot eliminate from sum type into large type");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str1, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str2, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str3, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str4, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str5, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str6, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str7, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str8, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str9, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str10, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str11, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str12, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str13, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str14, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str15, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str16, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str17, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str18, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str19, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str20, 34, "cannot match against non-sum type ");
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumElim_entry, 4, 0};

V g_heff_2eelab_2erules_2esumElim(V v_sp_240, V v_scrutSyn_241, V v_tags_242, V v_casesChk_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam0, 2, 4, (V[]){v_sp_240, heff_dup(v_scrutSyn_241), heff_dup(v_tags_242), v_casesChk_243})});
}
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2esumElim(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2412}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  args[0] = v_t_2413;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args) {
  V v_c_2421 = args[0];
  V v_a0_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2421, 3, 8); V a_1 = v_a0_2420; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args) {
  V v_u_2430 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args) {
  V v_u_2429 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  V v_t_2431 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam8, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2431});
}
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2428) == NTAG(TAG_True))) {
    heff_drop(v_x_2428);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_2432 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam7, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2428);
    V v_t_2454;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2434 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_2434)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2434, 0ULL, 1);
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2434, 0ULL, 1);
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2434, 0ULL, 1);
        v_t_2454 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2454 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2434);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop(v_t_2454);
      V v_t_2455 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str1); V a_3 = v_t_2455; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2455); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_2454);
      V v_t_2456 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_2457 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str2), v_t_2456);
      V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2457, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_2460}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_2461;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args) {
  V v_u_2468 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2468);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args) {
  V v_u_2467 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  V v_t_2469 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam11, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2469});
}
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args) {
  V v_x_2466 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2466) == NTAG(TAG_True))) {
    heff_drop(v_x_2466);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_2470 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam10, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_2470;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2466);
    V v_t_2492;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2472 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_2472)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2472, 0ULL, 1);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2472, 0ULL, 1);
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2472, 0ULL, 1);
        v_t_2492 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2492 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2472);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
      heff_drop(v_t_2492);
      V v_t_2493 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str3); V a_3 = v_t_2493; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2493); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_2492);
      V v_t_2494 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_2495 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str4), v_t_2494);
      V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2495, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
      V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_2498}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_2499;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args) {
  V v_u_24105 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24105);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args) {
  V v_u_24104 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24104);
  V v_t_24106 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam14, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24106});
}
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args) {
  V v_x_24103 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24103) == NTAG(TAG_True))) {
    heff_drop(v_x_24103);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24107 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam13, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24107;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24103);
    V v_t_24129;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24109 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24109)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24109, 0ULL, 1);
        v_t_24129 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24109, 0ULL, 1);
        v_t_24129 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24109, 0ULL, 1);
        v_t_24129 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24129 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24109);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24129) == NTAG(TAG_True))) {
      heff_drop(v_t_24129);
      V v_t_24130 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str5); V a_3 = v_t_24130; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24130); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24129);
      V v_t_24131 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24132 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str6), v_t_24131);
      V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24132, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
      V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24135}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24136;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args) {
  V v_u_24140 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24140);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args) {
  V v_u_24139 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24139);
  V v_t_24141 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam17, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24141});
}
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args) {
  V v_x_24138 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24138) == NTAG(TAG_True))) {
    heff_drop(v_x_24138);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24142 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam16, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24142;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24138);
    V v_t_24164;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24144 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24144)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24144, 0ULL, 1);
        v_t_24164 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24144, 0ULL, 1);
        v_t_24164 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24144, 0ULL, 1);
        v_t_24164 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24164 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24144);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24164 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24164) == NTAG(TAG_True))) {
      heff_drop(v_t_24164);
      V v_t_24165 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str7); V a_3 = v_t_24165; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24165); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24164);
      V v_t_24166 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24167 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str8), v_t_24166);
      V v_t_24168 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24167, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24169 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24168})});
      V v_t_24170 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24169})});
      V v_t_24171 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24170}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24171;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args) {
  V v_u_24174 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24174);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args) {
  V v_u_24173 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24173);
  V v_t_24175 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam20, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24175});
}
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args) {
  V v_x_24172 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24172) == NTAG(TAG_True))) {
    heff_drop(v_x_24172);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24176 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam19, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24176;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24172);
    V v_t_24198;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24178 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24178)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24178, 0ULL, 1);
        v_t_24198 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24178, 0ULL, 1);
        v_t_24198 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24178, 0ULL, 1);
        v_t_24198 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24198 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24178);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24198 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24198) == NTAG(TAG_True))) {
      heff_drop(v_t_24198);
      V v_t_24199 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str9); V a_3 = v_t_24199; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24199); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24198);
      V v_t_24200 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24201 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str10), v_t_24200);
      V v_t_24202 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24201, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24203 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24202})});
      V v_t_24204 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24203})});
      V v_t_24205 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24204}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24205;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args) {
  V v_u_24208 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24208);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args) {
  V v_u_24207 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24207);
  V v_t_24209 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam23, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24209});
}
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args) {
  V v_x_24206 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24206) == NTAG(TAG_True))) {
    heff_drop(v_x_24206);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24210 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam22, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24210;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24206);
    V v_t_24232;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24212 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24212)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24212, 0ULL, 1);
        v_t_24232 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24212, 0ULL, 1);
        v_t_24232 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24212, 0ULL, 1);
        v_t_24232 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24232 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24212);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24232 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24232) == NTAG(TAG_True))) {
      heff_drop(v_t_24232);
      V v_t_24233 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str11); V a_3 = v_t_24233; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24233); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24232);
      V v_t_24234 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24235 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str12), v_t_24234);
      V v_t_24236 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24235, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24237 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24236})});
      V v_t_24238 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24237})});
      V v_t_24239 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24238}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24239;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args) {
  V v_u_24242 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24242);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args) {
  V v_u_24241 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24241);
  V v_t_24243 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam26, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24243});
}
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args) {
  V v_x_24240 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24240) == NTAG(TAG_True))) {
    heff_drop(v_x_24240);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24244 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam25, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24244;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24240);
    V v_t_24266;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24246 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24246)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24246, 0ULL, 1);
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24246, 0ULL, 1);
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24246, 0ULL, 1);
        v_t_24266 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24246);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24266) == NTAG(TAG_True))) {
      heff_drop(v_t_24266);
      V v_t_24267 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str13); V a_3 = v_t_24267; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24267); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24266);
      V v_t_24268 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24269 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str14), v_t_24268);
      V v_t_24270 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24269, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24271 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24270})});
      V v_t_24272 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24271})});
      V v_t_24273 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24272}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24273;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args) {
  V v_u_24277 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24277);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args) {
  V v_u_24276 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24276);
  V v_t_24278 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam29, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24278});
}
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args) {
  V v_x_24275 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24275) == NTAG(TAG_True))) {
    heff_drop(v_x_24275);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24279 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam28, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24279;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24275);
    V v_t_24301;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24281 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24281)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24281, 0ULL, 1);
        v_t_24301 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24281, 0ULL, 1);
        v_t_24301 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24281, 0ULL, 1);
        v_t_24301 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24301 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24281);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24301 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24301) == NTAG(TAG_True))) {
      heff_drop(v_t_24301);
      V v_t_24302 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str15); V a_3 = v_t_24302; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24302); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24301);
      V v_t_24303 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24304 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str16), v_t_24303);
      V v_t_24305 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24304, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24306 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24305})});
      V v_t_24307 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24306})});
      V v_t_24308 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24307}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24308;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args) {
  V v_u_24312 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24312);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args) {
  V v_u_24311 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24311);
  V v_t_24313 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam32, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24313});
}
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args) {
  V v_x_24310 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24310) == NTAG(TAG_True))) {
    heff_drop(v_x_24310);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24314 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam31, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24314;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24310);
    V v_t_24336;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24316 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24316)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24316, 0ULL, 1);
        v_t_24336 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24316, 0ULL, 1);
        v_t_24336 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24316, 0ULL, 1);
        v_t_24336 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24336 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24316);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24336 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24336) == NTAG(TAG_True))) {
      heff_drop(v_t_24336);
      V v_t_24337 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str17); V a_3 = v_t_24337; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24337); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24336);
      V v_t_24338 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24339 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str18), v_t_24338);
      V v_t_24340 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24339, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24341 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24340})});
      V v_t_24342 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24341})});
      V v_t_24343 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24342}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24343;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args) {
  V v_u_24346 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24346);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args) {
  V v_u_24345 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24345);
  V v_t_24347 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam35, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24347});
}
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args) {
  V v_x_24344 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24344) == NTAG(TAG_True))) {
    heff_drop(v_x_24344);
    heff_drop(v_x_2425);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2419);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_2416, 3);
    V v_t_24348 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam34, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2417;
    args[0] = v_t_24348;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24344);
    V v_t_24370;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_VU: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24350 = heff_dup(heff_field(v_x_2425, 0));
      switch (heff_tag_of(v_t1_24350)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24350, 0ULL, 1);
        v_t_24370 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24350, 0ULL, 1);
        v_t_24370 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24350, 0ULL, 1);
        v_t_24370 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24370 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24350);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24370 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    if ((heff_dup(v_t_24370) == NTAG(TAG_True))) {
      heff_drop(v_t_24370);
      V v_t_24371 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2419; V a_2 = heff_dup(v_x_2425); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str19); V a_3 = v_t_24371; V a_4 = v_x_2425; V a_5 = v_b_245; V a_6 = v_hd_2416; V a_7 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24371); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2419);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24370);
      V v_t_24372 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2425));
      V v_msg_24373 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str20), v_t_24372);
      V v_t_24374 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24373, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24375 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24374})});
      V v_t_24376 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24375})});
      V v_t_24377 = heff_tr(heff_call(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_24376}));
      V f_ = heff_get_n(v_hd_2416, 1, 3);
      heff_room[0] = v_t_24377;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2419 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2426 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2425)));
  switch (heff_tag_of(v_t_2426)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2426, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam6, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2426, 0ULL, 4);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam9, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2426, 0ULL, 3);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam12, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeSum: {
    V v_vs_24137 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_244; V a_2 = v_b_245; V a_3 = v_scrut_2419; V a_4 = v_x_2425; V a_5 = v_vs_24137; V a_6 = v_tags_242; V a_7 = v_casesChk_243; V a_8 = v_hd_2416; V a_9 = v_k_2417; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_tags_242); r_; });
  }
  case TAG_LikeInt: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam15, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeFloat: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam18, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeString: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam21, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeRune: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam24, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2426, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam27, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2426, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam30, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  case TAG_NoRules: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2425), heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam33, 1, 9, (V[]){v_b_245, v_k_2417, v_x_2425, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244, v_hd_2416})));
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  V v_e_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_scrut_2419 = heff_field(v_x_2418, 0);
    V v_a0_2420 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam4, 1, 1, (V[]){v_a0_2420})})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){v_t_2423}));
    V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
    heff_room[0] = v_t_2424;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam5, 1, 8, (V[]){v_hd_2416, v_b_245, v_k_2417, v_sp_240, v_scrut_2419, v_tags_242, v_casesChk_243, v_e_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_tags_242 = heff_env(self)[3];
  V v_casesChk_243 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam3, 1, 7, (V[]){v_hd_2416, v_b_245, v_k_2417, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_scrutSyn_241 = heff_env(self)[1];
  V v_tags_242 = heff_env(self)[2];
  V v_casesChk_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_246 = (g_heff_2eelab_2evalue_2elevelOf(v_b_245));
  V v_t_247;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Small: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_Large: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_TopL: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_e_244);
    heff_drop(v_b_245);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_t_247);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam1, 2, 1, (V[]){v_sp_240});
  } else {
    heff_drop(v_t_247);
    V v_c_2415;
    switch (heff_tag_of(v_scrutSyn_241)) {
    case TAG_MkSyn: {
      V v_f_2414 = heff_field(v_scrutSyn_241, 0);
      heff_take_n(v_scrutSyn_241, 1ULL, 1);
      v_c_2415 = heff_tr(heff_call(v_f_2414, 1, (V[]){heff_dup(v_e_244)}));
      break;
    }
    default: heff_nomatch(v_scrutSyn_241);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam2, 2, 6, (V[]){v_c_2415, v_b_245, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str0, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str1, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str2, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str3, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str4, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str5, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str6, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str7, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str8, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdateOf_str9, 136, "the record's shape is not in hand here for the update: annotate the binder, `\\(x : T) -> ...`, or give the implicit argument, `(a := T)`");
V g_heff_2eelab_2erules_2eupdateOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam16(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam15(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam20(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam19(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam23(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam22(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam21(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam26(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam25(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam24(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam29(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam28(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam27(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam32(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam31(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam30(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam35(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam34(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam33(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam38(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam37(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam36(V self, V *args);
V g_heff_2eelab_2erules_2eupdateOf_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdateOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateOf_entry, 8, 0};

V g_heff_2eelab_2erules_2eupdateOf(V v_sp_240, V v_r_241, V v_e_242, V v_g_243, V v_a0_244, V v_fs_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam0, 1, 1, (V[]){v_a0_244})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam1, 1, 7, (V[]){v_hd_246, v_k_247, v_sp_240, v_e_242, v_fs_245, v_r_241, v_g_243})});
}
V g_heff_2eelab_2erules_2eupdateOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdateOf(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eupdateOf_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eupdateOf_lam4(V self, V *args) {
  V v_u_2417 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam3(V self, V *args) {
  V v_u_2416 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_t_2418 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam4, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2418});
}
V g_heff_2eelab_2erules_2eupdateOf_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2415) == NTAG(TAG_True))) {
    heff_drop(v_x_2415);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2419 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam3, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2415);
    heff_drop(v_x_2412);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam6(V self, V *args) {
  V v_u_2429 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  V v_t_2431 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam7, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2431});
}
V g_heff_2eelab_2erules_2eupdateOf_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2428) == NTAG(TAG_True))) {
    heff_drop(v_x_2428);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2432 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam6, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2428);
    heff_drop(v_x_2412);
    V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2435}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2436;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam9(V self, V *args) {
  V v_x_2443 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_fs_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2eupdateSetting(((V)&g_heff_2eelab_2erules_2eupdateOf_clo), v_e_242, v_sp_240, v_r_241, v_g_243, v_x_2412, v_fs_245, v_x_2443));
}
V g_heff_2eelab_2erules_2eupdateOf_lam11(V self, V *args) {
  V v_v_2446 = args[0];
  V v_scope_27_2447 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_2445 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_v_2446);
  V v_t_2448 = (g_heff_2eelab_2erules_2erecordIntro(v_sp_240, v_x_2445));
  switch (heff_tag_of(v_t_2448)) {
  case TAG_MkChk: {
    V v_f_2449 = heff_field(v_t_2448, 0);
    heff_take_n(v_t_2448, 1ULL, 1);
    V v_t_2450 = ({ V rv_0 = v_scope_27_2447; V rr_ = heff_rec_reuse_nf(v_e_242, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2449;
    args[0] = v_t_2450;
    args[1] = v_x_2412;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_t_2448);
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam13(V self, V *args) {
  V v_u_2460 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2460);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2eupdateOf_lam14(V self, V *args) {
  V v_u_2464 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2464);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2eupdateOf_lam12(V self, V *args) {
  V v_x_2452 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2453 = heff_take_field(v_e_242, 2);
  V v_t_2456;
  switch (heff_tag_of(v_t_2453)) {
  case TAG_ForNominative: {
    v_t_2456 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2453, 0ULL, 2);
    v_t_2456 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2453);
  }
  V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
  V v_t_2459 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2458, heff_dup(v_x_2412)));
  V v_dom_2461 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2459, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam13, 1, 1, (V[]){heff_dup(v_x_2412)})});
  V v_t_2462 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
  V v_t_2463 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2462, MK_INT(1LL)), heff_dup(v_x_2412)));
  V v_cod_2465 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_r_241), heff_rec_n(2, shape_stx__val, (V[]){v_t_2463, heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam14, 1, 1, (V[]){v_x_2412})})});
  V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_t_2467 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_242, 1)), v_t_2466, v_dom_2461, v_cod_2465));
  V v_t_2468 = (g_heff_2eelab_2ememoed_2elam(v_t_2456, heff_get_n(v_e_242, 1, 6), v_t_2457, v_t_2467, heff_tag_n(TAG_MkAbs, 2, (V[]){v_r_241, v_x_2452})));
  V v_x_2469 = (g_heff_2eelab_2ememoed_2eapp(v_t_2468, v_g_243));
  V f_ = v_k_247;
  args[0] = v_x_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateOf_lam10(V self, V *args) {
  V v_x_2445 = args[0];
  V v_r_241 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_g_243 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2451 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_r_241), heff_dup(v_x_2412), heff_dup(heff_rfield(v_e_242, 0)), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam11, 2, 4, (V[]){v_sp_240, v_x_2445, heff_dup(v_e_242), heff_dup(v_x_2412)})));
  V f_ = v_c_2451;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam12, 1, 5, (V[]){v_e_242, v_x_2412, v_r_241, v_g_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eupdateOf_lam8(V self, V *args) {
  V v_x_2442 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_g_243 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_fs_245 = heff_env(self)[5];
  V v_keys_2440 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2442);
  V v_c_2444 = (g_heff_2eelab_2erules_2etraverseE(heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam9, 1, 6, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), heff_dup(v_r_241), heff_dup(v_g_243), heff_dup(v_x_2412), v_fs_245}), v_keys_2440));
  V f_ = v_c_2444;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam10, 1, 7, (V[]){v_r_241, v_x_2412, v_e_242, v_sp_240, v_hd_246, v_g_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eupdateOf_lam17(V self, V *args) {
  V v_u_2473 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam16(V self, V *args) {
  V v_u_2472 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2472);
  V v_t_2474 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam17, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2474});
}
V g_heff_2eelab_2erules_2eupdateOf_lam15(V self, V *args) {
  V v_x_2471 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2471) == NTAG(TAG_True))) {
    heff_drop(v_x_2471);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2475 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam16, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2475;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2471);
    heff_drop(v_x_2412);
    V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2478}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2479;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam20(V self, V *args) {
  V v_u_2482 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2482);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam19(V self, V *args) {
  V v_u_2481 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  V v_t_2483 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam20, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2483});
}
V g_heff_2eelab_2erules_2eupdateOf_lam18(V self, V *args) {
  V v_x_2480 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2480) == NTAG(TAG_True))) {
    heff_drop(v_x_2480);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2484 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam19, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2484;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2480);
    heff_drop(v_x_2412);
    V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2487}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2488;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam23(V self, V *args) {
  V v_u_2491 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam22(V self, V *args) {
  V v_u_2490 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2490);
  V v_t_2492 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam23, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2492});
}
V g_heff_2eelab_2erules_2eupdateOf_lam21(V self, V *args) {
  V v_x_2489 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2489) == NTAG(TAG_True))) {
    heff_drop(v_x_2489);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2493 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam22, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_2493;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2489);
    heff_drop(v_x_2412);
    V v_t_2494 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2496}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2497;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam26(V self, V *args) {
  V v_u_24100 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24100);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam25(V self, V *args) {
  V v_u_2499 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2499);
  V v_t_24101 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam26, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24101});
}
V g_heff_2eelab_2erules_2eupdateOf_lam24(V self, V *args) {
  V v_x_2498 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2498) == NTAG(TAG_True))) {
    heff_drop(v_x_2498);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24102 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam25, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24102;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2498);
    heff_drop(v_x_2412);
    V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24105}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24106;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam29(V self, V *args) {
  V v_u_24109 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24109);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam28(V self, V *args) {
  V v_u_24108 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24108);
  V v_t_24110 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam29, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24110});
}
V g_heff_2eelab_2erules_2eupdateOf_lam27(V self, V *args) {
  V v_x_24107 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24107) == NTAG(TAG_True))) {
    heff_drop(v_x_24107);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24111 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam28, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24111;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24107);
    heff_drop(v_x_2412);
    V v_t_24112 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24114}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24115;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam32(V self, V *args) {
  V v_u_24119 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24119);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam31(V self, V *args) {
  V v_u_24118 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24118);
  V v_t_24120 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam32, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24120});
}
V g_heff_2eelab_2erules_2eupdateOf_lam30(V self, V *args) {
  V v_x_24117 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24117) == NTAG(TAG_True))) {
    heff_drop(v_x_24117);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24121 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam31, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24121;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24117);
    heff_drop(v_x_2412);
    V v_t_24122 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24124}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24125;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam35(V self, V *args) {
  V v_u_24129 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24129);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam34(V self, V *args) {
  V v_u_24128 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24128);
  V v_t_24130 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam35, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24130});
}
V g_heff_2eelab_2erules_2eupdateOf_lam33(V self, V *args) {
  V v_x_24127 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24127) == NTAG(TAG_True))) {
    heff_drop(v_x_24127);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24131 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam34, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24131;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24127);
    heff_drop(v_x_2412);
    V v_t_24132 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
    V v_t_24135 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24134}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24135;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam38(V self, V *args) {
  V v_u_24138 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24138);
  return v_x_2412;
}
V g_heff_2eelab_2erules_2eupdateOf_lam37(V self, V *args) {
  V v_u_24137 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24137);
  V v_t_24139 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam38, 1, 1, (V[]){v_x_2412}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24139});
}
V g_heff_2eelab_2erules_2eupdateOf_lam36(V self, V *args) {
  V v_x_24136 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24136) == NTAG(TAG_True))) {
    heff_drop(v_x_24136);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_24140 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam37, 1, 1, (V[]){v_x_2412})});
    V f_ = v_k_247;
    args[0] = v_t_24140;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24136);
    heff_drop(v_x_2412);
    V v_t_24141 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdateOf_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24142 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24141})});
    V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
    V v_t_24144 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24143}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24144;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2eupdateOf_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_fs_245 = heff_env(self)[4];
  V v_r_241 = heff_env(self)[5];
  V v_g_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam2, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam5, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2439 = heff_field(v_t_2413, 2);
    heff_take_n(v_t_2413, 4ULL, 3);
    V v_keys_2440 = heff_arrayToList(heff_get_n(v_fieldTypes_2439, 0, 3));
    V v_c_2441 = (g_heff_2eelab_2erules_2enoSuchSetting(heff_dup(v_e_242), heff_dup(v_x_2412), v_keys_2440, v_fs_245));
    V f_ = v_c_2441;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam8, 1, 9, (V[]){v_e_242, v_sp_240, v_r_241, v_g_243, v_x_2412, v_fs_245, v_keys_2440, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam15, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeInt: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam18, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFloat: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam21, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeString: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam24, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeRune: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam27, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam30, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam33, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  case TAG_NoRules: {
    heff_drop_rec(v_e_242, 6);
    heff_drop(v_fs_245);
    heff_drop(v_r_241);
    heff_drop(v_g_243);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eupdateOf_lam36, 1, 4, (V[]){v_x_2412, v_k_247, v_sp_240, v_hd_246})));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_24acc_str1, 6, ", and ");
HEFF_LIT(g_heff_2eelab_2erules_2eplacesSaid_24acc_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eplacesSaid_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eplacesSaid_24acc_entry, 2, 0};

V g_heff_2eelab_2erules_2eplacesSaid_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2eelab_2erules_2eplacesSaid_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2eplacesSaid_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2eelab_2erules_2eplacesSaid_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eplacesSaid_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eplacesSaid_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2efind_str0, 5, "uses ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_str1, 26, ", which does not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2efind_str2, 17, "no such variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_str3, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2efind_str4, 13, "` is defined ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_str5, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2efind_str6, 9, "variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_str7, 162, " is the definition being elaborated: it is in hand only under a lambda, where a type is expected of it (an argument, a branch, the result -- not a case scrutinee)");
V g_heff_2eelab_2erules_2efind_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efind_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efind_entry, 2, 0};

V g_heff_2eelab_2erules_2efind(V v_sp_240, V v_x_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efind_lam0, 1, 2, (V[]){v_x_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2efind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efind(a[0], a[1]);
}
V g_heff_2eelab_2erules_2efind_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str0), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_str1)));
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_t_2414, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k2_2420 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str2), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_str3)));
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2421, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_2419, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2419, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam4(V self, V *args) {
  V v_u_2431 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ge_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2431);
  return (g_heff_2eelab_2erules_2etyStr(v_e_242, heff_get_n(v_ge_2428, 3, 4)));
}
V g_heff_2eelab_2erules_2efind_lam6(V self, V *args) {
  V v_u_2436 = args[0];
  V v_ge_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2436);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_ge_2428, 2, 4)});
}
V g_heff_2eelab_2erules_2efind_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_key_2427 = heff_env(self)[0];
  V v_ge_2428 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2435);
  V v_t_2437 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_2427}), heff_clo_n(g_heff_2eelab_2erules_2efind_lam6, 1, 1, (V[]){heff_dup(v_ge_2428)})});
  V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, heff_get_n(v_ge_2428, 3, 4)});
  V f_ = v_k_2430;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efind_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_key_2427 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_ge_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_key_2427)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efind_lam4, 1, 2, (V[]){v_e_242, heff_dup(v_ge_2428)})});
  V v_t_2433 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2432, NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  args[0] = v_t_2434;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efind_lam5, 1, 3, (V[]){v_key_2427, v_ge_2428, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam7(V self, V *args) {
  V v_k_2440 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_get_n(heff_get_n(v_e_242, 1, 6), 5, 7);
  V v_t_2442 = ({ V a_0 = heff_dup(v_k_2440); V a_1 = v_t_2441; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2441); r_; });
  switch (heff_tag_of(v_t_2442)) {
  case TAG_Nothing: {
    return v_k_2440;
  }
  case TAG_Just: {
    V v_place_2443 = heff_field(v_t_2442, 0);
    heff_take_n(v_t_2442, 1ULL, 1);
    heff_drop(v_k_2440);
    return v_place_2443;
  }
  default: return heff_nomatch(v_t_2442);
  }
}
V g_heff_2eelab_2erules_2efind_lam8(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k2_2449 = args[1];
  V v_msg_2447 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(330LL), NTAG(TAG_SError), v_msg_2447, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(heff_take_field(v_hd_2448, 2), 1, (V[]){v_t_2452}));
  V f_ = heff_get_n(v_hd_2448, 1, 3);
  args[0] = v_t_2453;
  args[1] = v_k2_2449;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam9(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str6), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_str7)));
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(319LL), NTAG(TAG_SError), v_t_2456, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2459}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2460;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam10(V self, V *args) {
  V v_u_2470 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ty_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2470);
  return (g_heff_2eelab_2erules_2etyStr(v_e_242, v_ty_2463));
}
V g_heff_2eelab_2erules_2efind_lam12(V self, V *args) {
  V v_x_2476 = args[0];
  V v_k_2473 = heff_env(self)[0];
  V v_m_2462 = heff_env(self)[1];
  V v_ty_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  V f_ = v_k_2473;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2462, v_ty_2463});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efind_lam11(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_i_2471 = heff_env(self)[0];
  V v_m_2462 = heff_env(self)[1];
  V v_ty_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2474 = heff_tag_n(TAG_Record, 2, (V[]){v_i_2471, NTAG(TAG_MkUnit)});
  V v_t_2475 = heff_tr(heff_call(heff_take_field(v_hd_2472, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})}));
  V f_ = heff_get_n(v_hd_2472, 1, 3);
  args[0] = v_t_2475;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efind_lam12, 1, 3, (V[]){v_k_2473, v_m_2462, v_ty_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 1, 4);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 3, 4);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  V v_it_246 = ({ V a_0 = heff_dup(v_x_241); V a_1 = v_t_243; V a_2 = v_t_244; V a_3 = v_t_245; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V r_ = (g_heff_2eelab_2erules_2evarGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_246)) {
  case TAG_Left: {
    V v_it1_247 = heff_field(v_it_246, 0);
    heff_take_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_NotInScope: {
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 4, 7);
      V v_t_249 = ({ V a_0 = heff_dup(v_x_241); V a_1 = v_t_248; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_248); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        V v_it_2410 = (g_heff_2eelab_2eglobals_2elookupKey(heff_dup(heff_rfield(v_e_242, 1)), heff_dup(v_x_241)));
        switch (heff_tag_of(v_it_2410)) {
        case TAG_Nothing: {
          V v_t_2411 = (g_heff_2eelab_2eglobals_2eisBroken(heff_get_n(v_e_242, 1, 6), heff_dup(v_x_241)));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            return heff_clo_n(g_heff_2eelab_2erules_2efind_lam1, 2, 2, (V[]){v_x_241, v_sp_240});
          } else {
            heff_drop(v_t_2411);
            return heff_clo_n(g_heff_2eelab_2erules_2efind_lam2, 2, 2, (V[]){v_x_241, v_sp_240});
          }
        }
        case TAG_Just: {
          V v_it1_2426 = heff_field(v_it_2410, 0);
          heff_take_n(v_it_2410, 1ULL, 1);
          switch (heff_tag_of(v_it1_2426)) {
          case TAG_MkPair: {
            V v_key_2427 = heff_field(v_it1_2426, 0);
            V v_ge_2428 = heff_field(v_it1_2426, 1);
            heff_take_n(v_it1_2426, 3ULL, 2);
            return heff_clo_n(g_heff_2eelab_2erules_2efind_lam3, 2, 5, (V[]){v_sp_240, v_x_241, v_key_2427, v_e_242, v_ge_2428});
          }
          default: return heff_nomatch(v_it1_2426);
          }
        }
        default: return heff_nomatch(v_it_2410);
        }
      }
      case TAG_Just: {
        V v_ks_2439 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2444 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2efind_lam7, 1, 1, (V[]){v_e_242}), v_ks_2439));
        V v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2eelab_2erules_2eplacesSaid(a_0)); heff_drop(v_t_2444); r_; });
        V v_t_2446 = heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str4), v_t_2445));
        V v_msg_2447 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_str5), v_t_2446);
        return heff_clo_n(g_heff_2eelab_2erules_2efind_lam8, 2, 2, (V[]){v_msg_2447, v_sp_240});
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_Delayed2: {
      heff_drop_rec(v_e_242, 6);
      return heff_clo_n(g_heff_2eelab_2erules_2efind_lam9, 2, 2, (V[]){v_x_241, v_sp_240});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  case TAG_Right: {
    V v_it1_2461 = heff_field(v_it_246, 0);
    heff_take_n(v_it_246, 1ULL, 1);
    switch (heff_tag_of(v_it1_2461)) {
    case TAG_MkPair: {
      V v_m_2462 = heff_field(v_it1_2461, 0);
      V v_ty_2463 = heff_field(v_it1_2461, 1);
      heff_take_n(v_it1_2461, 3ULL, 2);
      V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 1, 4);
      V v_t_2465 = ({ V a_0 = v_t_2464; V a_1 = heff_dup(v_x_241); V a_2 = MK_INT(0LL); V r_ = (g_heff_2eelab_2erules_2eindexOfName(a_0, a_1, a_2)); heff_drop(v_t_2464); r_; });
      V v_t_2469;
      switch (heff_tag_of(v_t_2465)) {
      case TAG_Nothing: {
        v_t_2469 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_i_2466 = heff_field(v_t_2465, 0);
        heff_take_n(v_t_2465, 1ULL, 1);
        V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
        if (heff_intEq_c(v_i_2466, heff_intSub(v_t_2467, MK_INT(1LL)))) {
          v_t_2469 = heff_dup(heff_rfield(v_e_242, 4));
        } else {
          v_t_2469 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_t_2465);
      }
      V v_i_2471 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, v_t_2469, NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efind_lam10, 1, 2, (V[]){v_e_242, heff_dup(v_ty_2463)})});
      return heff_clo_n(g_heff_2eelab_2erules_2efind_lam11, 2, 3, (V[]){v_i_2471, v_m_2462, v_ty_2463});
    }
    default: return heff_nomatch(v_it1_2461);
    }
  }
  default: return heff_nomatch(v_it_246);
  }
}