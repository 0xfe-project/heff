// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimRune_get(void);
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2ecoeGoal(V, V, V);
V g_heff_2eelab_2erules_2ecoeGoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoeGoal_clo;
V g_heff_2eelab_2erules_2ecoerced(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecoerced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoerced_clo;
V g_heff_2eelab_2erules_2edefaultFor(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultFor_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
V g_heff_2eelab_2erules_2eelStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2eelStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelStrZ_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
HeffT1 g_heff_2eelab_2erules_2eetaArg_24cpr(V, V, V);
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
HeffT1 g_heff_2eelab_2erules_2efind_24cpr(V, V);
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
V g_heff_2eelab_2erules_2enameAtGo(V, V);
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enameAtGo_clo;
V g_heff_2eelab_2erules_2enotAFunction(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotAFunction_clo;
V g_heff_2eelab_2erules_2enotANumber(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eresourceEscapes(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresourceEscapes_clo;
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2erules_2evaluesGo_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
Clo g_heff_2eelab_2erules_2edownFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_entry, 1, 0};

V g_heff_2eelab_2erules_2edownFrom(V v_n_240) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_243 = (g_heff_2eelab_2erules_2edownFrom_24dps(heff_intSub(v_n_240, MK_INT(1LL)), heff_dup(v_cell_242)));
    heff_drop(v_u_243);
    return v_cell_242;
  }
}
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom(a[0]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efillHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efillHole_entry, 6, 0};

V g_heff_2eelab_2erules_2efillHole(V v_g_240, V v_m_241, V v_e_242, V v_argStx_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam0, 1, 4, (V[]){v_e_242, v_argStx_243, v_g_240, v_m_241})})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2417}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam1, 1, 2, (V[]){v_hd_244, v_k_245})});
}
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efillHole(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_argStx_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_s_247 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), heff_dup(v_argStx_243)));
  V v_x1_248 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), v_s_247, NTAG(TAG_LNil)));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2413 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), v_argStx_243));
  V v_t_2414 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413}); V rr_ = heff_rec_reuse_nf(v_e_242, 57ULL, 6, shape_ty__sol__solStx__arity__name__span, 4035u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_mc_2415 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_c_246, 3), v_m_241, v_t_2414));
  return ({ V rv_3 = v_mc_2415; V rr_ = heff_rec_reuse_nf(v_c_246, 247ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2422;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str0, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str1, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str2, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str3, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str4, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str5, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str6, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str7, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str8, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str9, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str10, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroImplicit_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntroImplicit(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2efunctionIntroImplicit(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args) {
  V v_u_2432 = args[0];
  V v_v_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2432);
  return v_v_2427;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2449 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2451 = heff_take_field(v_e_243, 2);
  V v_t_2454;
  switch (heff_tag_of(v_t_2451)) {
  case TAG_ForNominative: {
    v_t_2454 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2451, 0ULL, 2);
    v_t_2454 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2451);
  }
  V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2457 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2456, heff_dup(v_x_2411)));
  V v_x_2459 = (g_heff_2eelab_2ememoed_2elam(v_t_2454, heff_get_n(v_e_243, 1, 6), v_t_2455, heff_rec_n(2, shape_stx__val, (V[]){v_t_2457, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7, 1, 1, (V[]){v_x_2411})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2450})));
  V f_ = v_k_2449;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args) {
  V v_v_2427 = args[0];
  V v_scope_27_2428 = args[1];
  V v_cod_2420 = heff_env(self)[0];
  V v_body_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_implicit_2421 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_dom_2419 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2434;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2430 = heff_field(v_cod_2420, 1);
    V v_body_2431 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2434 = heff_tr(heff_call(v_body_2431, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2430, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4, 1, 1, (V[]){heff_dup(v_v_2427)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2433 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    v_x1_2434 = v_body_2433;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2438;
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    v_a_2438 = v_x_2435;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    v_a_2438 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    v_a_2438 = v_x_2437;
    break;
  }
  default: heff_nomatch(v_x1_2434);
  }
  V v_c_2447;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2439 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2440 = heff_dup(heff_rfield(v_e_243, 2));
    V v_t_2443;
    switch (heff_tag_of(v_t_2440)) {
    case TAG_ForNominative: {
      v_t_2443 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2441 = heff_field(v_t_2440, 0);
      V v_sp_2442 = heff_field(v_t_2440, 1);
      V v_ru_24t_2440_24ForDescriptive = heff_take_reuse_n(v_t_2440, 3ULL, 2);
      v_t_2443 = heff_tag_at_n(v_ru_24t_2440_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2441, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2442, heff_dup(v_v_2427)})});
      break;
    }
    default: heff_nomatch(v_t_2440);
    }
    V v_t_2444 = heff_intAdd(heff_dup(heff_rfield(v_e_243, 3)), MK_INT(1LL));
    V v_t_2445;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      heff_drop(v_v_2427);
      heff_drop(v_dom_2419);
      v_t_2445 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2427);
      heff_drop(v_dom_2419);
      v_t_2445 = heff_dup(heff_rfield(v_e_243, 5));
      break;
    }
    case TAG_Inst: {
      v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){heff_dup(v_x_241), v_dom_2419, v_v_2427}), heff_dup(heff_rfield(v_e_243, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    V v_t_2446 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2428, heff_dup(heff_rfield(v_e_243, 1)), v_t_2443, v_t_2444, heff_dup(heff_rfield(v_e_243, 4)), v_t_2445});
    v_c_2447 = heff_tr(heff_call(v_f_2439, 2, (V[]){v_t_2446, v_a_2438}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5, 2, 4, (V[]){v_c_2447, v_e_243, v_x_2411, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at_n(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2417;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_x_2411);
      heff_drop(v_x_241);
      heff_drop_rec(v_e_243, 6);
      heff_drop(v_body_242);
      heff_drop(v_dom_2419);
      heff_drop(v_cod_2420);
      heff_drop(v_implicit_2421);
      heff_drop(v_t_2422);
      V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2425}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2426;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2422);
      V v_t_2460 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), heff_dup(v_dom_2419), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3, 2, 7, (V[]){v_cod_2420, v_body_242, v_e_243, v_implicit_2421, v_x_241, v_dom_2419, v_x_2411})));
      V f_ = v_t_2460;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2466}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2467;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2470 = heff_tag_at_n(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2471}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2472;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2475}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2476;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2479}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2480;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2483}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2484;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2487}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2488;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2491 = heff_tag_at_n(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2492}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2493;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2412_24LikeFixed = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2496 = heff_tag_at_n(v_ru_24t_2412_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2497}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2498;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 6);
    heff_drop(v_body_242);
    V v_t_2499 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24101}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24102;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str0, 65, "tried to apply a value as a function, where its type is not known");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str1, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str2, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str3, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str4, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str5, 27, "the value applied here is `");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str6, 1, "`");
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enotAFunction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotAFunction_entry, 6, 0};

V g_heff_2eelab_2erules_2enotAFunction(V v_e_240, V v_sp_241, V v_ecallee_242, V v_a_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2427;
  switch (heff_tag_of(v_a_243)) {
  case TAG_VU: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_247 = heff_dup(heff_field(v_a_243, 0));
    switch (heff_tag_of(v_t1_247)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2427 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2427 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_247);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_e_240);
    heff_drop_rec(v_ecallee_242, 2);
    heff_drop(v_a_243);
    heff_drop(v_t_2427);
    V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2enotAFunction_str0), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2430}));
    return heff_tail(heff_get_n(v_p_244, 1, 3), 2, (V[]){v_t_2431, v_p_245});
  } else {
    heff_drop(v_t_2427);
    return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_240), v_a_243, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam0, 1, 5, (V[]){v_e_240, v_ecallee_242, v_p_244, v_sp_241, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enotAFunction(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_ecallee_242 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2434 = heff_get_n(v_ecallee_242, 0, 2);
  V v_t_2470;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2434, 0ULL, 3);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2459 = heff_field(v_t_2434, 0);
    heff_take_n(v_t_2434, 1ULL, 3);
    v_t_2470 = v_k_2459;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2434, 0ULL, 2);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2434, 0ULL, 1);
    v_t_2470 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  if (heff_intLe_c(MK_INT(0LL), v_t_2470)) {
    heff_drop(v_x_2433);
    V v_t_2472 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str1), heff_strAppend(v_x_2432, ((V)&g_heff_2eelab_2erules_2enotAFunction_str2)));
    V v_t_2473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2472, v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2475}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2476;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2477 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str3), heff_strAppend(v_x_2432, ((V)&g_heff_2eelab_2erules_2enotAFunction_str4)));
    V v_t_2478 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str5), heff_strAppend(v_x_2433, ((V)&g_heff_2eelab_2erules_2enotAFunction_str6)));
    V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2477, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2481}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2482;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ecallee_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eelStrZ(v_e_240, heff_dup(v_ecallee_242), heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam1, 1, 5, (V[]){v_ecallee_242, v_x_2432, v_sp_241, v_p_244, v_p_245})));
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V v_checksOnly_240, V v_sp_241, V v_callee_242, V v_arg_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0, 1, 4, (V[]){heff_dup(v_callee_242), v_sp_241, heff_dup(v_checksOnly_240), heff_dup(v_arg_243)})}});
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_arg_243 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_checksOnly_240; V a_1 = v_sp_241; V a_2 = v_arg_243; V a_3 = v_e_244; V a_4 = v_x_2412; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2eelab_2erules_2eelimGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_checksOnly_240); heff_drop(v_arg_243); r_; });
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_ecallee0_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_241), v_ecallee0_2410, v_a0_2411, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3, 1, 6, (V[]){v_checksOnly_240, v_sp_241, v_arg_243, v_e_244, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2, 1, 6, (V[]){v_e_244, v_sp_241, v_hd_247, v_checksOnly_240, v_arg_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_callee_242 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_checksOnly_240 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_callee_242)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_callee_242, 0);
    heff_take_n(v_callee_242, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_callee_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_241, v_checksOnly_240, v_arg_243});
}
HEFF_LIT(g_heff_2eelab_2erules_2enameAtGo_str0, 1, "\?");
Clo g_heff_2eelab_2erules_2enameAtGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enameAtGo_entry, 2, 0};

V g_heff_2eelab_2erules_2enameAtGo(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2erules_2enameAtGo_str0);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intLe_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return heff_dup(v_x_242);
    } else {
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2enameAtGo(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str0, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str1, 48, "`, a resource of a `with`, cannot leave its body");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str2, 93, "` of the body alone: use it inside the body and return what it gives (a line, a count), not `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str3, 24, "` or anything holding it");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str4, 18, "`, in the region `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str5, 14, "` is of type `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str6, 1, "`");
V g_heff_2eelab_2erules_2eresourceEscapes_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eresourceEscapes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresourceEscapes_entry, 7, 0};

V g_heff_2eelab_2erules_2eresourceEscapes(V v_e_240, V v_sp_241, V v_s_242, V v_x_243, V v_t_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2eelab_2erules_2etyStrZ(v_e_240, v_t_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2eresourceEscapes_lam0, 1, 5, (V[]){v_x_243, v_s_242, v_sp_241, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eresourceEscapes(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2eresourceEscapes_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_s_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str0), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str1)));
  V v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str2), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str3)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str4), heff_strAppend(v_s_242, v_t_249));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str5), heff_strAppend(v_x_247, v_t_2410));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str6), heff_strAppend(v_x_243, v_t_2411));
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_248, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2415}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  heff_room[0] = v_t_2416;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str0, 5, "unify");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str1, 8, "   FAILS");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str2, 5, "   ok");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str3, 7, "  =\?=  ");
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eapplyGo_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_lam4, 1, 0};
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eapplyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eapplyGo(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_a_27_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = heff_dup(heff_rfield(v_e_241, 0));
    return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam0, 2, 4, (V[]){v_c_248, heff_dup(v_e_241), heff_dup(v_a_242), heff_dup(v_a_27_247)}), heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam1, 1, 7, (V[]){v_m_246, v_e_241, v_a_242, v_a_27_247, v_p_244, v_sp_240, v_p_245})));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eapplyGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_p_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_248, 0), heff_get_n(v_c_248, 1, 4)});
  V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo), 4, (V[]){heff_get_n(v_e_241, 1, 6), v_t_2411, v_a_242, v_a_27_247}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2412, v_p_249, v_p_2410));
}
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args) {
  V v_c_2425 = args[0];
  return heff_get_n(v_c_2425, 3, 8);
}
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args) {
  V v_u_2430 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2430);
  V v_t_2431 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_241), v_x_2429, v_a_242));
  V v_t_2432 = ({ V a_0 = v_e_241; V a_1 = v_x_2429; V a_2 = v_a_27_247; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2429); r_; });
  V v_t_2435;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str1);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    v_t_2435 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str2);
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  V v_t_2436 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str3), heff_strAppend(v_t_2432, v_t_2435));
  return heff_strAppend(v_t_2431, v_t_2436);
}
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_m_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V f_ = v_p_245;
  args[0] = v_m_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_27_247 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_m_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2439);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2440 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    V v_t_2441 = (g_heff_2eelab_2erules_2ecoeGoal(heff_dup(v_e_241), heff_dup(v_a_27_247), heff_dup(v_a_242)));
    return ({ V a_0 = v_e_241; V a_1 = v_sp_240; V a_2 = v_a_242; V a_3 = v_a_27_247; V a_4 = v_m_246; V a_5 = v_err_2440; V a_6 = v_t_2441; V a_7 = v_p_244; V a_8 = v_p_245; V r_ = (g_heff_2eelab_2erules_2ecoerced(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_err_2440); r_; });
  }
  case TAG_Right: {
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    heff_drop_rec(v_e_241, 6);
    heff_drop(v_a_27_247);
    heff_drop(v_a_242);
    heff_drop(v_sp_240);
    V v_t_2443 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2444 = heff_tag_at_n(v_ru_24x_2424_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2444}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2445;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam8, 1, 2, (V[]){v_p_245, v_m_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_m_246 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2437 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2eapplyGo_str0), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam6, 1, 5, (V[]){heff_dup(v_e_241), v_x_2429, heff_dup(v_a_242), heff_dup(v_a_27_247), heff_dup(v_x_2424)})}), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam7, 1, 8, (V[]){v_x_2424, v_e_241, v_a_27_247, v_a_242, v_sp_240, v_m_246, v_p_244, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_247 = heff_env(self)[4];
  V v_m_246 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eapplyGo_lam4_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){v_t_2427}));
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2428;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam5, 1, 8, (V[]){v_sp_240, v_e_241, v_a_242, v_a_27_247, v_x_2424, v_p_244, v_m_246, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2423;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    V v_x1_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_246, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2419;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nom: {
      V v_x_2416 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2416;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2415, 0ULL, 1);
      v_t_2419 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2418 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      v_t_2419 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2especialized_clo), 5, (V[]){heff_dup(v_e_241), v_t_2419, heff_dup(v_a_242), heff_dup(v_a_27_247), heff_tag_n(TAG_Left, 1, (V[]){v_err_2414})}));
    break;
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_c_2423 = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam2, 2, 1, (V[]){v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam3, 1, 7, (V[]){v_p_244, v_sp_240, v_e_241, v_a_242, v_a_27_247, v_m_246, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimRune_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimRune_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimRune_st;
static V g_heff_2eelab_2erules_2eprimRune_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimRune_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimRune_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimRune_st)) return g_heff_2eelab_2erules_2eprimRune_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimRune_val, &g_heff_2eelab_2erules_2eprimRune_st, g_heff_2eelab_2erules_2eprimRune_init);
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam0, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam2, 1, 0};
Clo g_heff_2eelab_2erules_2enumLitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitAt(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_247, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam0_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2418});
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      V v_t_2419 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_i_246))});
      return heff_tail(v_z_245, 1, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2419, ((V)&g_heff_2eelab_2erules_2enumLitAt_lam1_clo)})});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2422 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      return (g_heff_2eelab_2erules_2eintAtFixed(v_sp_240, v_w_2422, v_i_246, v_z_244, v_z_245));
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_FracNum: {
    double v_x_2423 = heff_tflat_f64(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2424, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2424, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      V v_t_2435 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_x_2423)}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam2_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2435});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2437 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      V v_t_2438;
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I16: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I32: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I64: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U8: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U16: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U32: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U64: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_F32: {
        v_t_2438 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_e_241);
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
        heff_drop(v_t_2438);
        V v_t_2439 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_floatShow(heff_box_f64(v_x_2423)), heff_box_f64(v_x_2423)));
        return heff_tail(v_t_2439, 2, (V[]){v_z_244, v_z_245});
      } else {
        heff_drop(v_t_2438);
        return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
      }
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args) {
  V v_u_2420 = args[0];
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args) {
  V v_u_2434 = args[0];
  heff_drop(v_u_2434);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
Clo g_heff_2eelab_2erules_2eappendP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_entry, 2, 0};

V g_heff_2eelab_2erules_2eappendP(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2erules_2eappendP_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP(a[0], a[1]);
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args);
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultFor_entry, 4, 0};

V g_heff_2eelab_2erules_2edefaultFor(V v_x1_240, V v_g_241, V v_vs_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_ForNominative: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_243), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam0, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  case TAG_ForDescriptive: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(v_d_243)}), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam1, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2edefaultFor(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
}
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_247);
  V v_x1_248 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2412});
}
Clo g_heff_2eelab_2erules_2evaluesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_entry, 5, 0};

V g_heff_2eelab_2erules_2evaluesGo(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_245);
      heff_drop(v_rest_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_pls_248 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_Nothing: {
        heff_drop(v_m_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_246;
        V t_3 = v_pls_248;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        goto top;
      }
      case TAG_Just: {
        V v_p_249 = heff_field(v_x41_247, 0);
        heff_take_n(v_x41_247, 1ULL, 1);
        V v_t_2410 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_249, heff_dup(v_places_241), heff_dup(v_m_245), heff_dup(v_i_244)));
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_245, v_t_2410}), heff_hole()});
        V v_u_2412 = (g_heff_2eelab_2erules_2evaluesGo_24dps(v_n_240, v_places_241, v_rest_246, v_pls_248, heff_intAdd(v_i_244, MK_INT(1LL)), heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2evaluesGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eetaArg_24cpr(V v_sp_240, V v_l_241, V v_dom_242) {
top: ;
  return ({ V a_0 = v_sp_240; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eetaArg_24cpr_lam0, 3, 2, (V[]){v_l_241, v_dom_242})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam2(V self, V *args) {
  V v_u_249 = args[0];
  V v_dom_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_dom_242;
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_248);
  V v_t_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_l_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eetaArg_24cpr_lam2, 1, 1, (V[]){v_dom_242}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2410});
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_hd_244 = args[1];
  V v_k_245 = args[2];
  V v_l_241 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V v_t_246 = heff_get_n(heff_get_n(v_e_243, 0, 6), 0, 4);
  V v_t_247 = heff_intSub(heff_intSub(v_t_246, heff_dup(v_l_241)), MK_INT(1LL));
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_t_247}), heff_clo_n(g_heff_2eelab_2erules_2eetaArg_24cpr_lam1, 1, 2, (V[]){v_l_241, heff_dup(v_dom_242)})});
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_dom_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str0, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str1, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str2, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str3, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str4, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str5, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str6, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str7, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str8, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str9, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str10, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str11, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str12, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str13, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str14, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str15, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str16, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str17, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str18, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str19, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str20, 46, "cannot eliminate from sum type into large type");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str21, 46, "cannot eliminate from sum type into large type");
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam36(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumElim_entry, 4, 0};

V g_heff_2eelab_2erules_2esumElim(V v_sp_240, V v_scrutSyn_241, V v_tags_242, V v_casesChk_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam0, 2, 4, (V[]){heff_dup(v_scrutSyn_241), v_sp_240, heff_dup(v_tags_242), v_casesChk_243})});
}
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2esumElim(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args) {
  V v_c_2414 = args[0];
  V v_a0_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2414, 3, 8); V a_1 = v_a0_2413; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args) {
  V v_u_2423 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args) {
  V v_u_2422 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2422);
  V v_t_2424 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam7, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2424});
}
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2421) == NTAG(TAG_True))) {
    heff_drop(v_x_2421);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_2425 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam6, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2421);
    V v_t_2447;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2427 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_2427)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2427, 0ULL, 1);
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2427, 0ULL, 1);
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2427, 0ULL, 1);
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2427);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_t_2447);
      V v_t_2448 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str0); V a_3 = v_t_2448; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2448); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_2447);
      V v_t_2449 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_2450 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str1), v_t_2449);
      V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2450, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2453}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_2454;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args) {
  V v_u_2461 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2461);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args) {
  V v_u_2460 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2460);
  V v_t_2462 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam10, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2462});
}
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2459) == NTAG(TAG_True))) {
    heff_drop(v_x_2459);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_2463 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam9, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_2463;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2459);
    V v_t_2485;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2465 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_2465)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2465, 0ULL, 1);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2465, 0ULL, 1);
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2465, 0ULL, 1);
        v_t_2485 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2485 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2465);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2485 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_2485) == NTAG(TAG_True))) {
      heff_drop(v_t_2485);
      V v_t_2486 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str2); V a_3 = v_t_2486; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2486); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_2485);
      V v_t_2487 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_2488 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str3), v_t_2487);
      V v_t_2489 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2488, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2491}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_2492;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args) {
  V v_u_2498 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2498);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args) {
  V v_u_2497 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2497);
  V v_t_2499 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam13, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2499});
}
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args) {
  V v_x_2496 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2496) == NTAG(TAG_True))) {
    heff_drop(v_x_2496);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24100 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam12, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24100;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2496);
    V v_t_24122;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24102 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24102)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24102, 0ULL, 1);
        v_t_24122 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24102, 0ULL, 1);
        v_t_24122 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24102, 0ULL, 1);
        v_t_24122 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24122 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24102);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24122 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24122) == NTAG(TAG_True))) {
      heff_drop(v_t_24122);
      V v_t_24123 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str4); V a_3 = v_t_24123; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24123); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24122);
      V v_t_24124 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24125 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str5), v_t_24124);
      V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24125, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24127 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24126})});
      V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
      V v_t_24129 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24128}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24129;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args) {
  V v_u_24133 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24133);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args) {
  V v_u_24132 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24132);
  V v_t_24134 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam16, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24134});
}
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args) {
  V v_x_24131 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24131) == NTAG(TAG_True))) {
    heff_drop(v_x_24131);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24135 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam15, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24135;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24131);
    V v_t_24157;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24137 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24137)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24137, 0ULL, 1);
        v_t_24157 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24137, 0ULL, 1);
        v_t_24157 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24137, 0ULL, 1);
        v_t_24157 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24157 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24137);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24157 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24157) == NTAG(TAG_True))) {
      heff_drop(v_t_24157);
      V v_t_24158 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str6); V a_3 = v_t_24158; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24158); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24157);
      V v_t_24159 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24160 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str7), v_t_24159);
      V v_t_24161 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24160, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24162 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24161})});
      V v_t_24163 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24162})});
      V v_t_24164 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24163}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24164;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args) {
  V v_u_24167 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24167);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args) {
  V v_u_24166 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24166);
  V v_t_24168 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam19, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24168});
}
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args) {
  V v_x_24165 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24165) == NTAG(TAG_True))) {
    heff_drop(v_x_24165);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24169 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam18, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24169;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24165);
    V v_t_24191;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24171 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24171)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24171, 0ULL, 1);
        v_t_24191 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24171, 0ULL, 1);
        v_t_24191 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24171, 0ULL, 1);
        v_t_24191 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24191 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24171);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24191 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24191) == NTAG(TAG_True))) {
      heff_drop(v_t_24191);
      V v_t_24192 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str8); V a_3 = v_t_24192; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24192); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24191);
      V v_t_24193 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24194 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str9), v_t_24193);
      V v_t_24195 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24194, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24196 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24195})});
      V v_t_24197 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24196})});
      V v_t_24198 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24197}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24198;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args) {
  V v_u_24201 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24201);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args) {
  V v_u_24200 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24200);
  V v_t_24202 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam22, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24202});
}
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args) {
  V v_x_24199 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24199) == NTAG(TAG_True))) {
    heff_drop(v_x_24199);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24203 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam21, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24203;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24199);
    V v_t_24225;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24205 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24205)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24205, 0ULL, 1);
        v_t_24225 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24205, 0ULL, 1);
        v_t_24225 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24205, 0ULL, 1);
        v_t_24225 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24225 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24205);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24225 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24225) == NTAG(TAG_True))) {
      heff_drop(v_t_24225);
      V v_t_24226 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str10); V a_3 = v_t_24226; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24226); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24225);
      V v_t_24227 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24228 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str11), v_t_24227);
      V v_t_24229 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24228, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24230 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24229})});
      V v_t_24231 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24230})});
      V v_t_24232 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24231}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24232;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args) {
  V v_u_24235 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24235);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args) {
  V v_u_24234 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24234);
  V v_t_24236 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam25, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24236});
}
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args) {
  V v_x_24233 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24233) == NTAG(TAG_True))) {
    heff_drop(v_x_24233);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24237 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam24, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24237;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24233);
    V v_t_24259;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24239 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24239)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24239, 0ULL, 1);
        v_t_24259 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24239, 0ULL, 1);
        v_t_24259 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24239, 0ULL, 1);
        v_t_24259 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24259 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24239);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24259 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24259) == NTAG(TAG_True))) {
      heff_drop(v_t_24259);
      V v_t_24260 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str12); V a_3 = v_t_24260; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24260); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24259);
      V v_t_24261 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24262 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str13), v_t_24261);
      V v_t_24263 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24262, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24264 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24263})});
      V v_t_24265 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24264})});
      V v_t_24266 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24265}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24266;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args) {
  V v_u_24270 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24270);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args) {
  V v_u_24269 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24269);
  V v_t_24271 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam28, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24271});
}
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args) {
  V v_x_24268 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24268) == NTAG(TAG_True))) {
    heff_drop(v_x_24268);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24272 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam27, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24272;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24268);
    V v_t_24294;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24274 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24274)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24274, 0ULL, 1);
        v_t_24294 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24274, 0ULL, 1);
        v_t_24294 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24274, 0ULL, 1);
        v_t_24294 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24294 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24274);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24294 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24294) == NTAG(TAG_True))) {
      heff_drop(v_t_24294);
      V v_t_24295 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str14); V a_3 = v_t_24295; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24295); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24294);
      V v_t_24296 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24297 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str15), v_t_24296);
      V v_t_24298 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24297, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24299 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24298})});
      V v_t_24300 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24299})});
      V v_t_24301 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24300}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24301;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args) {
  V v_u_24305 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24305);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args) {
  V v_u_24304 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24304);
  V v_t_24306 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam31, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24306});
}
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args) {
  V v_x_24303 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24303) == NTAG(TAG_True))) {
    heff_drop(v_x_24303);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24307 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam30, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24307;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24303);
    V v_t_24329;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24309 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24309)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24309, 0ULL, 1);
        v_t_24329 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24309, 0ULL, 1);
        v_t_24329 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24309, 0ULL, 1);
        v_t_24329 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24329 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24309);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24329 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24329) == NTAG(TAG_True))) {
      heff_drop(v_t_24329);
      V v_t_24330 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str16); V a_3 = v_t_24330; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24330); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24329);
      V v_t_24331 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24332 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str17), v_t_24331);
      V v_t_24333 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24332, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24334 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24333})});
      V v_t_24335 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24334})});
      V v_t_24336 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24335}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24336;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args) {
  V v_u_24339 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24339);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args) {
  V v_u_24338 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24338);
  V v_t_24340 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam34, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24340});
}
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args) {
  V v_x_24337 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24337) == NTAG(TAG_True))) {
    heff_drop(v_x_24337);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24341 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam33, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24341;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24337);
    V v_t_24363;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24343 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24343)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24343, 0ULL, 1);
        v_t_24363 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24343, 0ULL, 1);
        v_t_24363 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24343, 0ULL, 1);
        v_t_24363 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24363 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24343);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24363 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24363) == NTAG(TAG_True))) {
      heff_drop(v_t_24363);
      V v_t_24364 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str18); V a_3 = v_t_24364; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24364); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24363);
      V v_t_24365 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24366 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str19), v_t_24365);
      V v_t_24367 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24366, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24368 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24367})});
      V v_t_24369 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24368})});
      V v_t_24370 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24369}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24370;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2419 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2418)));
  switch (heff_tag_of(v_t_2419)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2419, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam5, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2419, 0ULL, 4);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam8, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2419, 0ULL, 3);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam11, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeSum: {
    V v_vs_24130 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_244; V a_2 = v_b_245; V a_3 = v_scrut_2412; V a_4 = v_x_2418; V a_5 = v_vs_24130; V a_6 = v_tags_242; V a_7 = v_casesChk_243; V a_8 = v_hd_249; V a_9 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_tags_242); r_; });
  }
  case TAG_LikeInt: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam14, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeFloat: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam17, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeString: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam20, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeRune: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam23, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2419, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam26, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2419, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam29, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_NoRules: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam32, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  V v_e_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_scrut_2412 = heff_field(v_x_2411, 0);
    V v_a0_2413 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam3, 1, 1, (V[]){v_a0_2413})})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2416}));
    V f_ = heff_dup(heff_rfield(v_hd_249, 1));
    heff_room[0] = v_t_2417;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam4, 1, 8, (V[]){v_hd_249, v_b_245, v_k_2410, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_tags_242 = heff_env(self)[3];
  V v_casesChk_243 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam2, 1, 7, (V[]){v_hd_249, v_b_245, v_k_2410, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args) {
  V v_hd_24371 = args[0];
  V v_k2_24372 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24373 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str20), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24374 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24373})});
  V v_t_24375 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24374})});
  V v_t_24376 = heff_tr(heff_call(heff_take_field(v_hd_24371, 2), 1, (V[]){v_t_24375}));
  V f_ = heff_get_n(v_hd_24371, 1, 3);
  args[0] = v_t_24376;
  args[1] = v_k2_24372;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam36(V self, V *args) {
  V v_hd_24377 = args[0];
  V v_k2_24378 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24379 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str21), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24380 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24379})});
  V v_t_24381 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24380})});
  V v_t_24382 = heff_tr(heff_call(heff_take_field(v_hd_24377, 2), 1, (V[]){v_t_24381}));
  V f_ = heff_get_n(v_hd_24377, 1, 3);
  args[0] = v_t_24382;
  args[1] = v_k2_24378;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tags_242 = heff_env(self)[2];
  V v_casesChk_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_246 = (g_heff_2eelab_2evalue_2elevelOf(v_b_245));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Small: {
    V v_c_248;
    switch (heff_tag_of(v_scrutSyn_241)) {
    case TAG_MkSyn: {
      V v_f_247 = heff_field(v_scrutSyn_241, 0);
      heff_take_n(v_scrutSyn_241, 1ULL, 1);
      v_c_248 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_dup(v_e_244)}));
      break;
    }
    default: heff_nomatch(v_scrutSyn_241);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam1, 2, 6, (V[]){v_c_248, v_b_245, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  }
  case TAG_Large: {
    heff_drop(v_e_244);
    heff_drop(v_b_245);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam35, 2, 1, (V[]){v_sp_240});
  }
  case TAG_TopL: {
    heff_drop(v_e_244);
    heff_drop(v_b_245);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam36, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_x1_246);
  }
}
Clo g_heff_2eelab_2erules_2efind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efind_entry, 2, 0};

V g_heff_2eelab_2erules_2efind(V v_sp_240, V v_x_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2efind_24cpr(v_sp_240, v_x_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2efind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efind(a[0], a[1]);
}