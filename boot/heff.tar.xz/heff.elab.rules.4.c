// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_DelayGuessing 16914
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkFolded 17353
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_RestoreWaiting 10254
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SaveDelayed 42463
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_aliases 1464806715
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_digits 615232529
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_exponent 966452320
#define LBL_globals 352931696
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_infos 301706655
#define LBL_kind 9787483
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_negative 1666250321
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_typed 312202372
#define LBL_val 326043
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_im__indent__typed[] = {LBL_im, LBL_indent, LBL_typed};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
float g_float32_2efromDecimal_w(V, V);
V g_float32_2efromDecimal(V, V);
V g_float32_2efromDecimal_entry(V self, V *a);
extern Clo g_float32_2efromDecimal_clo;
V g_heff_2eelab_2eenvironment_2epartOf(V, V);
V g_heff_2eelab_2eenvironment_2epartOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2epartOf_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_clo;
V g_heff_2eelab_2ememoed_2eprimRune_get(void);
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eliftU_24tok1(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_24tok1_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
HeffT2 g_heff_2eelab_2erename_2erkOf_24cpr(V);
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2eatFloat64_w(V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64(V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_clo;
V g_heff_2eelab_2erules_2eatFloat64_24tok1_w(V, V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_24tok1_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2ecoeGoal(V, V, V);
V g_heff_2eelab_2erules_2ecoeGoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoeGoal_clo;
V g_heff_2eelab_2erules_2ecoerced(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecoerced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoerced_clo;
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
V g_heff_2eelab_2erules_2edelayLambda(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayLambda_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayLambda_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
HeffT3 g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(V, V);
V g_heff_2eelab_2erules_2eelimWaits(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimWaits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimWaits_clo;
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
V g_heff_2eelab_2erules_2efirstElab(V, V, V);
V g_heff_2eelab_2erules_2efirstElab_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efirstElab_clo;
V g_heff_2eelab_2erules_2efracAtFixed(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracAtFixed_clo;
V g_heff_2eelab_2erules_2efracDefault_24tok1_w(V, V, V, V, double, V, V);
V g_heff_2eelab_2erules_2efracDefault_24tok1(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracDefault_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracDefault_24tok1_clo;
V g_heff_2eelab_2erules_2efreshMeta_24rec0_get(void);
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2eguessFunctionTy(V, V, V, V, V);
V g_heff_2eelab_2erules_2eguessFunctionTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eguessFunctionTy_clo;
HeffT2 g_heff_2eelab_2erules_2eheldGiven_24cpr(V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstLocals(V);
V g_heff_2eelab_2erules_2einstLocals_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstLocals_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2eintAtFixed_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_24tok1_clo;
V g_heff_2eelab_2erules_2eintoSilent(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintoSilent_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintoSilent_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
HeffT3 g_heff_2eelab_2erules_2ementionsLocal_24cpr(V);
V g_heff_2eelab_2erules_2emetaOf(V);
V g_heff_2eelab_2erules_2emetaOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOf_clo;
V g_heff_2eelab_2erules_2emetaOfStx(V);
V g_heff_2eelab_2erules_2emetaOfStx_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOfStx_clo;
V g_heff_2eelab_2erules_2enameAtGo(V, V);
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enameAtGo_clo;
V g_heff_2eelab_2erules_2enotAFunction(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotAFunction_clo;
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572_clo;
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2epathSaid_2edown_241(V, V);
V g_heff_2eelab_2erules_2epathSaid_2edown_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epathSaid_2edown_241_clo;
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2eresourceEscapes(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresourceEscapes_clo;
V g_heff_2eelab_2erules_2esearchedNow(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esearchedNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esearchedNow_clo;
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2esumFormation_24map2(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map2_clo;
V g_heff_2eelab_2erules_2esumPaths(V, V);
V g_heff_2eelab_2erules_2esumPaths_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumPaths_clo;
V g_heff_2eelab_2erules_2ethroughCandidates(V, V, V);
V g_heff_2eelab_2erules_2ethroughCandidates_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ethroughCandidates_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2etyStrZ_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2erules_2evaluesGo_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
V g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get(void);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2007813875x1918122072(V);
V g_list_2emap_24s2007813875x1918122072_entry(V self, V *a);
extern Clo g_list_2emap_24s2007813875x1918122072_clo;
V g_list_2emap_24s570884835x2121220820(V);
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2eelab_2erules_2edownFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_entry, 1, 0};

V g_heff_2eelab_2erules_2edownFrom(V v_n_240) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_242 = (g_heff_2eelab_2erules_2edownFrom_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_cell_241));
    heff_drop(v_u_242);
    return v_cell_241;
  }
}
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom(a[0]);
}

static V g_heff_2eelab_2erules_2efreshMeta_24rec0_val;
static HEFF_ONCE g_heff_2eelab_2erules_2efreshMeta_24rec0_st;
static V g_heff_2eelab_2erules_2efreshMeta_24rec0_init(void) {
  return heff_rec_n(3, shape_im__indent__typed, (V[]){heff_dup(g_heff_2esyntax_2esurfaceprint_2eplainImplicits_get()), MK_INT(0LL), NTAG(TAG_True)});
}
V g_heff_2eelab_2erules_2efreshMeta_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2efreshMeta_24rec0_st)) return g_heff_2eelab_2erules_2efreshMeta_24rec0_val;
  return heff_global(&g_heff_2eelab_2erules_2efreshMeta_24rec0_val, &g_heff_2eelab_2erules_2efreshMeta_24rec0_st, g_heff_2eelab_2erules_2efreshMeta_24rec0_init);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efillHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efillHole_entry, 6, 0};

V g_heff_2eelab_2erules_2efillHole(V v_g_240, V v_m_241, V v_e_242, V v_argStx_243, V v_hd_244, V v_k_245) {
top: ;
  V v_malg_246 = heff_take_field(v_hd_244, 2);
  V v_bind_247 = heff_get_n(v_hd_244, 1, 3);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam0, 1, 4, (V[]){v_e_242, v_argStx_243, v_g_240, v_m_241})})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2419}));
  return heff_tail(heff_dup(v_bind_247), 2, (V[]){v_t_2420, heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam1, 1, 3, (V[]){v_malg_246, v_bind_247, v_k_245})});
}
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efillHole(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_argStx_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_t_249 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), heff_dup(v_argStx_243)));
  heff_clo_take(self, 4);
  V v_x1_2410 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, NTAG(TAG_N), v_t_249, NTAG(TAG_LNil)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(heff_rfield(v_e_242, 3)), v_argStx_243));
  V v_t_2416 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2415}); V rr_ = heff_rec_reuse_nf(v_e_242, 57ULL, 6, shape_ty__sol__solStx__arity__name__span, 4035u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_mc_2417 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_c_248, 3), v_m_241, v_t_2416));
  return ({ V rv_3 = v_mc_2417; V rr_ = heff_rec_reuse_nf(v_c_248, 503ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_malg_246 = heff_env(self)[0];
  V v_bind_247 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_t_2422 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2421, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  heff_clo_take(self, 3);
  V v_t_2424 = heff_tr(heff_call(v_malg_246, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})}));
  V f_ = v_bind_247;
  heff_room[0] = v_t_2424;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eeffectAndWorld_24cpr_str0, 5, "co.<:");
HEFF_LIT(g_heff_2eelab_2erules_2eeffectAndWorld_24cpr_str1, 5, "co.<:");

HeffT3 g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(V v_mc_240, V v_goal_241) {
top: ;
  V v_it_242 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_goal_241));
  switch (heff_tag_of(v_it_242)) {
  case TAG_VU: {
    heff_take_n(v_it_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VDecode: {
    V v_it1_244 = heff_field(v_it_242, 0);
    V v_sp_245 = heff_field(v_it_242, 1);
    heff_take_n(v_it_242, 3ULL, 5);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_sp_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_HGlobal: {
      V v_k_2410 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      switch (heff_tag_of(v_sp_245)) {
      case TAG_SpId: {
        heff_drop(v_k_2410);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_SpApp: {
        V v_sp1_2411 = heff_field(v_sp_245, 0);
        V v_w_2412 = heff_field(v_sp_245, 1);
        heff_take_n(v_sp_245, 3ULL, 2);
        switch (heff_tag_of(v_sp1_2411)) {
        case TAG_SpId: {
          heff_drop(v_k_2410);
          heff_drop(v_w_2412);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_SpApp: {
          V v_sp11_2413 = heff_field(v_sp1_2411, 0);
          V v_h_2414 = heff_field(v_sp1_2411, 1);
          heff_take_n(v_sp1_2411, 3ULL, 2);
          switch (heff_tag_of(v_sp11_2413)) {
          case TAG_SpId: {
            if (heff_strEq_c(v_k_2410, ((V)&g_heff_2eelab_2erules_2eeffectAndWorld_24cpr_str0))) {
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_h_2414, v_w_2412}});
            } else {
              heff_drop(v_w_2412);
              heff_drop(v_h_2414);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
          case TAG_SpApp: {
            heff_take_n(v_sp11_2413, 0ULL, 2);
            heff_drop(v_k_2410);
            heff_drop(v_w_2412);
            heff_drop(v_h_2414);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_SpProj: {
            heff_take_n(v_sp11_2413, 0ULL, 2);
            heff_drop(v_k_2410);
            heff_drop(v_w_2412);
            heff_drop(v_h_2414);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_SpSpec: {
            heff_take_n(v_sp11_2413, 0ULL, 3);
            heff_drop(v_k_2410);
            heff_drop(v_w_2412);
            heff_drop(v_h_2414);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          default: return ((HeffT3){{heff_nomatch(v_sp11_2413)}});
          }
        }
        case TAG_SpProj: {
          heff_take_n(v_sp1_2411, 0ULL, 2);
          heff_drop(v_k_2410);
          heff_drop(v_w_2412);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          heff_take_n(v_sp1_2411, 0ULL, 3);
          heff_drop(v_k_2410);
          heff_drop(v_w_2412);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        default: return ((HeffT3){{heff_nomatch(v_sp1_2411)}});
        }
      }
      case TAG_SpProj: {
        heff_take_n(v_sp_245, 0ULL, 2);
        heff_drop(v_k_2410);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_SpSpec: {
        heff_take_n(v_sp_245, 0ULL, 3);
        heff_drop(v_k_2410);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      default: return ((HeffT3){{heff_nomatch(v_sp_245)}});
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_sp_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_HError: {
      heff_drop(v_sp_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    default: return ((HeffT3){{heff_nomatch(v_it1_244)}});
    }
  }
  case TAG_VFunction: {
    V v_it6_2438 = heff_field(v_it_242, 5);
    heff_take_n(v_it_242, 32ULL, 6);
    switch (heff_tag_of(v_it6_2438)) {
    case TAG_Nothing: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_it61_2439 = heff_field(v_it6_2438, 0);
      heff_take_n(v_it6_2438, 1ULL, 1);
      switch (heff_tag_of(v_it61_2439)) {
      case TAG_MkFolded: {
        V v_it611_2440 = heff_field(v_it61_2439, 0);
        V v_spTh_2441 = heff_field(v_it61_2439, 1);
        heff_take_n(v_it61_2439, 3ULL, 2);
        switch (heff_tag_of(v_it611_2440)) {
        case TAG_HLocal: {
          heff_take_n(v_it611_2440, 0ULL, 1);
          heff_drop(v_spTh_2441);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_HGlobal: {
          V v_k_2443 = heff_field(v_it611_2440, 0);
          heff_take_n(v_it611_2440, 1ULL, 1);
          V v_sp_2444 = heff_tr(heff_call(v_spTh_2441, 1, (V[]){NTAG(TAG_MkUnit)}));
          switch (heff_tag_of(v_sp_2444)) {
          case TAG_SpId: {
            heff_drop(v_k_2443);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_SpApp: {
            V v_sp1_2445 = heff_field(v_sp_2444, 0);
            V v_w_2446 = heff_field(v_sp_2444, 1);
            heff_take_n(v_sp_2444, 3ULL, 2);
            switch (heff_tag_of(v_sp1_2445)) {
            case TAG_SpId: {
              heff_drop(v_k_2443);
              heff_drop(v_w_2446);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            case TAG_SpApp: {
              V v_sp11_2447 = heff_field(v_sp1_2445, 0);
              V v_h_2448 = heff_field(v_sp1_2445, 1);
              heff_take_n(v_sp1_2445, 3ULL, 2);
              switch (heff_tag_of(v_sp11_2447)) {
              case TAG_SpId: {
                if (heff_strEq_c(v_k_2443, ((V)&g_heff_2eelab_2erules_2eeffectAndWorld_24cpr_str1))) {
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_h_2448, v_w_2446}});
                } else {
                  heff_drop(v_w_2446);
                  heff_drop(v_h_2448);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
              case TAG_SpApp: {
                heff_take_n(v_sp11_2447, 0ULL, 2);
                heff_drop(v_k_2443);
                heff_drop(v_w_2446);
                heff_drop(v_h_2448);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_SpProj: {
                heff_take_n(v_sp11_2447, 0ULL, 2);
                heff_drop(v_k_2443);
                heff_drop(v_w_2446);
                heff_drop(v_h_2448);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_SpSpec: {
                heff_take_n(v_sp11_2447, 0ULL, 3);
                heff_drop(v_k_2443);
                heff_drop(v_w_2446);
                heff_drop(v_h_2448);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              default: return ((HeffT3){{heff_nomatch(v_sp11_2447)}});
              }
            }
            case TAG_SpProj: {
              heff_take_n(v_sp1_2445, 0ULL, 2);
              heff_drop(v_k_2443);
              heff_drop(v_w_2446);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            case TAG_SpSpec: {
              heff_take_n(v_sp1_2445, 0ULL, 3);
              heff_drop(v_k_2443);
              heff_drop(v_w_2446);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            default: return ((HeffT3){{heff_nomatch(v_sp1_2445)}});
            }
          }
          case TAG_SpProj: {
            heff_take_n(v_sp_2444, 0ULL, 2);
            heff_drop(v_k_2443);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_SpSpec: {
            heff_take_n(v_sp_2444, 0ULL, 3);
            heff_drop(v_k_2443);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          default: return ((HeffT3){{heff_nomatch(v_sp_2444)}});
          }
        }
        case TAG_HMeta: {
          heff_take_n(v_it611_2440, 0ULL, 1);
          heff_drop(v_spTh_2441);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_HError: {
          heff_drop(v_spTh_2441);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        default: return ((HeffT3){{heff_nomatch(v_it611_2440)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_it61_2439)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_it6_2438)}});
    }
  }
  case TAG_VRecord: {
    heff_take_n(v_it_242, 0ULL, 4);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VSum: {
    heff_take_n(v_it_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VPrimInt: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VPrimFloat: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VPrimString: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VPrimRune: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VPrimArray: {
    heff_take_n(v_it_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_VFixed: {
    heff_take_n(v_it_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  default: return ((HeffT3){{heff_nomatch(v_it_242)}});
  }
}
V g_heff_2eelab_2erules_2esearchedNow_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esearchedNow_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esearchedNow_lam0, 1, 0};
V g_heff_2eelab_2erules_2esearchedNow_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2esearchedNow_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esearchedNow_lam2, 1, 0};
V g_heff_2eelab_2erules_2esearchedNow_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esearchedNow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esearchedNow_entry, 6, 0};

V g_heff_2eelab_2erules_2esearchedNow(V v_e_240, V v_sp_241, V v_hole_242, V v_goal_243, V v_hd_244, V v_k_245) {
top: ;
  V v_stx_246 = heff_take_field(v_hole_242, 0);
  V v_val_247 = heff_get_n(v_hole_242, 1, 2);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esearchedNow_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam1, 1, 7, (V[]){v_hd_244, v_stx_246, v_e_240, v_sp_241, v_val_247, v_goal_243, v_k_245})});
}
V g_heff_2eelab_2erules_2esearchedNow_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esearchedNow(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2esearchedNow_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return v_c_248;
}
V g_heff_2eelab_2erules_2esearchedNow_lam2(V self, V *args) {
  V v_sv_2413 = args[0];
  return v_sv_2413;
}
V g_heff_2eelab_2erules_2esearchedNow_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_drop(v_x_2428);
  heff_clo_take(self, 1);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esearchedNow_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  heff_drop(v_x_2424);
  heff_clo_take(self, 3);
  V v_t_2425 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2426}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2427;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam6, 1, 1, (V[]){v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esearchedNow_lam4(V self, V *args) {
  V v_s_2419 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_drop(v_s_2419);
  V v_k_2420 = heff_dup(heff_rfield(v_hd_244, 0));
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam5, 1, 3, (V[]){v_x_2416, v_hd_244, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esearchedNow_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_stx_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_val_247 = heff_env(self)[3];
  V v_goal_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = ({ V a_0 = v_stx_246; V r_ = (g_heff_2eelab_2erules_2emetaOf(a_0)); heff_drop(v_stx_246); r_; });
  V v_t_2418 = heff_tr(g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2417, v_val_247, v_goal_243, NTAG(TAG_False), heff_dup(v_hd_244), heff_dup(heff_rfield(v_hd_244, 0))));
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam4, 1, 3, (V[]){heff_dup(v_hd_244), v_x_2412, v_x_2416})})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2430}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2431;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esearchedNow_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_stx_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_val_247 = heff_env(self)[4];
  V v_goal_243 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2esearchedNow_lam2_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam3, 1, 8, (V[]){v_stx_246, v_e_240, v_sp_241, v_val_247, v_goal_243, v_hd_244, v_x_2412, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2edelayLambda_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayLambda_lam3(V self, V *args);
V g_heff_2eelab_2erules_2edelayLambda_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayLambda_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayLambda_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayLambda_entry, 7, 0};

V g_heff_2eelab_2erules_2edelayLambda(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_a_244, V v_p_245, V v_p_246) {
top: ;
  return (g_heff_2eelab_2erules_2edelayChkBy(heff_clo_n(g_heff_2eelab_2erules_2edelayLambda_lam0, 3, 3, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_a_244)}), v_e_240, v_sp_241, v_what_242, v_c_243, v_a_244, v_p_245, v_p_246));
}
V g_heff_2eelab_2erules_2edelayLambda_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2edelayLambda(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2edelayLambda_lam1(V self, V *args) {
  V v_c_2416 = args[0];
  V v_a0_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2416, 3, 9); V a_1 = v_a0_2413; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2edelayLambda_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_t_2425;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2422, 0ULL, 1);
    v_t_2425 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edelayLambda_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_2411 = heff_env(self)[0];
  V v_sp_2412 = heff_env(self)[1];
  V v_hd_2414 = heff_env(self)[2];
  V v_k_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2eguessFunctionTy_clo), 3, (V[]){v_e_2411, v_sp_2412, v_x_2420}));
  return (g_heff_2eelab_2emeta_2eattempt(v_t_2421, v_hd_2414, heff_clo_n(g_heff_2eelab_2erules_2edelayLambda_lam3, 1, 1, (V[]){v_k_2415})));
}
V g_heff_2eelab_2erules_2edelayLambda_lam0(V self, V *args) {
  V v_chk_247 = args[0];
  V v_hd_248 = args[1];
  V v_k2_249 = args[2];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_t_2410 = heff_tr(heff_call(v_chk_247, 2, (V[]){heff_dup(v_hd_248), heff_dup(heff_rfield(v_hd_248, 0))}));
  heff_clo_take(self, 3);
  V v_e_2411 = v_e_240;
  V v_sp_2412 = v_sp_241;
  V v_a0_2413 = heff_dup(v_a_244);
  V v_hd_2414 = heff_dup(v_hd_248);
  V v_k_2415 = heff_take_field(v_hd_248, 0);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2edelayLambda_lam1, 1, 1, (V[]){v_a0_2413})})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2414, 2)), 1, (V[]){v_t_2418}));
  V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2414, 1)), 2, (V[]){v_t_2419, heff_clo_n(g_heff_2eelab_2erules_2edelayLambda_lam2, 1, 4, (V[]){v_e_2411, v_sp_2412, v_hd_2414, v_k_2415})}));
  V v_t_2427 = heff_tag_n(TAG_DelayGuessing, 4, (V[]){v_a_244, v_t_2410, v_t_2426, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2428}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  args[0] = v_t_2429;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str0, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str1, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str2, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str3, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str4, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str5, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str6, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str7, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str8, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str9, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str10, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroImplicit_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntroImplicit(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2efunctionIntroImplicit(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 9); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args) {
  V v_u_2435 = args[0];
  V v_v_2427 = heff_env(self)[0];
  heff_drop(v_u_2435);
  heff_clo_take(self, 1);
  return v_v_2427;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args) {
  V v_u_2452 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_drop(v_u_2452);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2411});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_z_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2445 = heff_take_field(v_e_243, 2);
  V v_t_2448;
  switch (heff_tag_of(v_t_2445)) {
  case TAG_ForNominative: {
    v_t_2448 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2445, 0ULL, 2);
    v_t_2448 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2445);
  }
  V v_t_2449 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 5);
  V v_t_2450 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2449, heff_dup(v_x_2411)));
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 5);
  V v_x_2453 = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(v_x_241, v_x_2444, v_t_2448, heff_get_n(v_e_243, 1, 8), v_t_2451, heff_rec_n(2, shape_stx__val, (V[]){v_t_2450, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6, 1, 1, (V[]){v_x_2411})})));
  V f_ = v_z_2430;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args) {
  V v_v_2427 = args[0];
  V v_scope_27_2428 = args[1];
  V v_z_2429 = args[2];
  V v_z_2430 = args[3];
  V v_e_243 = heff_env(self)[0];
  V v_implicit_2421 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_dom_2419 = heff_env(self)[3];
  V v_cod_2420 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_e_2431 = ({ V a_0 = heff_dup(v_e_243); V a_1 = v_implicit_2421; V a_2 = heff_dup(v_x_241); V a_3 = v_dom_2419; V a_4 = v_scope_27_2428; V a_5 = heff_dup(v_v_2427); V b_6 = NTAG(TAG_True); V r_ = (g_heff_2eelab_2erules_2eintoSilent(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_implicit_2421); heff_drop(b_6); r_; });
  V v_x1_2437;
  switch (heff_tag_of(v_cod_2420)) {
  case TAG_MkClo: {
    V v_vs_2433 = heff_field(v_cod_2420, 1);
    V v_body_2434 = heff_field(v_cod_2420, 2);
    heff_take_n(v_cod_2420, 6ULL, 3);
    v_x1_2437 = heff_tr(heff_call(v_body_2434, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2433, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4, 1, 1, (V[]){v_v_2427})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2436 = heff_field(v_cod_2420, 0);
    heff_take_n(v_cod_2420, 1ULL, 1);
    heff_drop(v_v_2427);
    v_x1_2437 = v_body_2436;
    break;
  }
  default: heff_nomatch(v_cod_2420);
  }
  V v_a_2441;
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_Nom: {
    V v_x_2438 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_a_2441 = v_x_2438;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_a_2441 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2440 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_a_2441 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_x1_2437);
  }
  V v_c_2443;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2442 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2443 = heff_tr(heff_call(v_f_2442, 2, (V[]){v_e_2431, v_a_2441}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  V f_ = v_c_2443;
  args[0] = v_z_2429;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5, 1, 4, (V[]){v_e_243, v_x_2411, v_x_241, v_z_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  V v_t_2412 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2411)));
  switch (heff_tag_of(v_t_2412)) {
  case TAG_LikeU: {
    V v_ru_24t_2412_24LikeU = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_at_n(v_ru_24t_2412_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2417;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_dom_2419 = heff_field(v_t_2412, 1);
    V v_cod_2420 = heff_field(v_t_2412, 2);
    V v_implicit_2421 = heff_field(v_t_2412, 3);
    heff_take_n(v_t_2412, 14ULL, 4);
    V v_t_2422;
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2422 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2422 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_x_2411);
      heff_clo_take(self, 6);
      heff_drop(v_x_241);
      heff_drop_rec(v_e_243, 8);
      heff_drop(v_body_242);
      heff_drop(v_dom_2419);
      heff_drop(v_cod_2420);
      heff_drop(v_implicit_2421);
      heff_drop(v_t_2422);
      V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2425}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2426;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_clo_take(self, 6);
      heff_drop(v_sp_240);
      heff_drop(v_t_2422);
      return (g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), heff_dup(v_dom_2419), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3, 4, 7, (V[]){v_e_243, v_implicit_2421, v_x_241, v_dom_2419, v_cod_2420, v_body_242, v_x_2411}), v_hd_245, v_k_246));
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2412, 0ULL, 3);
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2459}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2460;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2412_24LikeSum = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2462 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2463 = heff_tag_at_n(v_ru_24t_2412_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2464}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2465;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2468}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2469;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2472}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2473;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2476}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2477;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2478 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2480}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2481;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2412_24LikeArray = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2484 = heff_tag_at_n(v_ru_24t_2412_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
    V v_t_2486 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2485}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2486;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2412_24LikeFixed = heff_take_reuse_n(v_t_2412, 0ULL, 1);
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2488 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2489 = heff_tag_at_n(v_ru_24t_2412_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2490}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2491;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2411);
    heff_clo_take(self, 6);
    heff_drop(v_x_241);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_body_242);
    V v_t_2492 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2494}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2495;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2, 1, 6, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_e_243, v_body_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumPaths_str0, 6, "co.<+>");
Clo g_heff_2eelab_2erules_2esumPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumPaths_entry, 2, 0};

V g_heff_2eelab_2erules_2esumPaths(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SGlobal: {
    V v_k_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_240, 1), v_k_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        V v_e_247 = v_field_246;
        V t_0 = v_g_240;
        V t_1 = heff_get_n(v_e_247, 0, 4);
        v_g_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_g_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_k2_2411 = v_field_2410;
            HeffT2 v_t_2412 = ({ V a_0 = heff_rfield(v_g_240, 1); V a_1 = v_k2_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k2_2411); r_; });
            {
              V v_field_2414 = v_t_2412.f[1];
              int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
              if ((v_tag_2413 == ((int64_t)0ULL))) {
                V v_entry_2415 = v_field_2414;
                V t_0 = v_g_240;
                V t_1 = heff_get_n(v_entry_2415, 0, 4);
                v_g_240 = t_0;
                v_x2_241 = t_1;
                goto top;
              } else {
                heff_drop_rec(v_g_240, 8);
                heff_drop(v_field_2414);
                return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
              }
            }
          } else {
            heff_drop_rec(v_g_240, 8);
            heff_drop(v_field_2410);
            return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
          }
        }
      }
    }
  }
  case TAG_SCode: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SApp: {
    V v_x21_2417 = heff_field(v_x2_241, 0);
    V v_b_2418 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24SApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_SLocal: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SGlobal: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SCode: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SApp: {
      V v_x211_2422 = heff_field(v_x21_2417, 0);
      V v_a_2423 = heff_field(v_x21_2417, 1);
      heff_take_n(v_x21_2417, 3ULL, 2);
      switch (heff_tag_of(v_x211_2422)) {
      case TAG_SLocal: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SGlobal: {
        V v_k_2425 = heff_field(v_x211_2422, 0);
        heff_take_n(v_x211_2422, 1ULL, 1);
        if (heff_strEq_c(v_k_2425, ((V)&g_heff_2eelab_2erules_2esumPaths_str0))) {
          V v_t_2426 = (g_heff_2eelab_2erules_2esumPaths(heff_dup(v_g_240), v_a_2423));
          V v_t_2427 = (g_list_2emap_24s2007813875x1918122072(v_t_2426));
          V v_t_2428 = (g_heff_2eelab_2erules_2esumPaths(v_g_240, v_b_2418));
          V v_t_2429 = (g_list_2emap_24s570884835x2121220820(v_t_2428));
          return (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_241_24SApp, v_t_2427, v_t_2429));
        } else {
          heff_drop_rec(v_g_240, 8);
          heff_drop(v_b_2418);
          heff_drop(v_a_2423);
          return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
        }
      }
      case TAG_SCode: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SApp: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLam: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SCons: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SProj: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_STag: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SMatch: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SSpecialize: {
        heff_take_n(v_x211_2422, 0ULL, 3);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SIs: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SOpaque: {
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SAbandon: {
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SRec: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SFix: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SImplicit: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SPrim: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SMetaApp: {
        heff_take_n(v_x211_2422, 0ULL, 3);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitInt: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitFloat: {
        heff_take_na(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitString: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitBytes: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitRune: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitFixed: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_x211_2422);
      }
    }
    case TAG_SLam: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SCons: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SProj: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_STag: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SMatch: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x21_2417, 0ULL, 3);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SIs: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SOpaque: {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SAbandon: {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SRec: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SFix: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SImplicit: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SPrim: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x21_2417, 0ULL, 3);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitInt: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitString: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitRune: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  case TAG_SLam: {
    V v_ru_24x2_241_24SLam = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SLam, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SCons: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SProj: {
    V v_ru_24x2_241_24SProj = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SProj, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_STag: {
    V v_ru_24x2_241_24STag = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24STag, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SMatch: {
    V v_ru_24x2_241_24SMatch = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SMatch, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SIs: {
    V v_t_24105 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_g_240;
    V t_1 = v_t_24105;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SRec: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SFix: {
    V v_ru_24x2_241_24SFix = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SFix, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SImplicit: {
    V v_ru_24x2_241_24SImplicit = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SImplicit, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitString: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitFixed: {
    V v_ru_24x2_241_24SLitFixed = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SLitFixed, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2esumPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumPaths(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2ethroughCandidates_str0, 6, "\\p -> ");
V g_heff_2eelab_2erules_2ethroughCandidates_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ethroughCandidates_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ethroughCandidates_entry, 3, 0};

V g_heff_2eelab_2erules_2ethroughCandidates(V v_e_240, V v_cand_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_cand_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2erules_2einstLocals(heff_dup(v_e_240)));
    V v_t_2412 = (g_list_2emap_24tok2(v_ru_24x3_242_24Cons, heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam0, 1, 2, (V[]){v_path_243, heff_dup(v_cand_241)}), v_t_245));
    V v_t_2413 = (g_heff_2eelab_2erules_2ethroughCandidates(v_e_240, v_cand_241, v_rest_244));
    return (g_prelude_2e_2b_2b(v_t_2412, v_t_2413));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2ethroughCandidates_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ethroughCandidates(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam0(V self, V *args) {
  V v_w_246 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_cand_241 = heff_env(self)[1];
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_w_246, 0)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_w_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
  V v_t_249 = ({ V a_0 = v_w_248; V a_1 = v_path_243; V r_ = (g_heff_2eelab_2erules_2epathSaid_2edown_241(a_0, a_1)); heff_drop_tag(v_w_248, 1); r_; });
  V v_t_2410 = heff_tr(heff_call(heff_get_n(v_w_246, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_call(v_cand_241, 2, (V[]){v_path_243, heff_tag_n(TAG_Just, 1, (V[]){v_t_2410})}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2ethroughCandidates_str0), v_t_249), v_t_2411});
}
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str0, 65, "tried to apply a value as a function, where its type is not known");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str1, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str2, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str3, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str4, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str5, 27, "the value applied here is `");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str6, 1, "`");
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotAFunction_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2enotAFunction_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotAFunction_lam2, 1, 0};
V g_heff_2eelab_2erules_2enotAFunction_lam4(V self, V *args);
V g_heff_2eelab_2erules_2enotAFunction_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enotAFunction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotAFunction_entry, 6, 0};

V g_heff_2eelab_2erules_2enotAFunction(V v_e_240, V v_sp_241, V v_ecallee_242, V v_a_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_a_243)) {
  case TAG_VU: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_247 = heff_dup(heff_field(v_a_243, 0));
    switch (heff_tag_of(v_t1_247)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_247);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_e_240);
    heff_drop_rec(v_ecallee_242, 2);
    heff_drop(v_a_243);
    heff_drop(v_t_2428);
    V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2enotAFunction_str0), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2431}));
    return heff_tail(heff_get_n(v_p_244, 1, 3), 2, (V[]){v_t_2432, v_p_245});
  } else {
    heff_drop(v_t_2428);
    return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_240), v_a_243, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam0, 1, 5, (V[]){v_e_240, v_ecallee_242, v_p_244, v_sp_241, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enotAFunction(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args) {
  V v_x_2441 = args[0];
  V v_ecallee_242 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2442 = ({ V b_0 = heff_get_n(v_ecallee_242, 0, 2); V r_ = (g_heff_2eelab_2erules_2emetaOfStx(b_0)); heff_drop(b_0); r_; });
  if (heff_intLe_c(MK_INT(0LL), v_x_2442)) {
    heff_drop(v_x_2441);
    V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str1), v_x_2433), ((V)&g_heff_2eelab_2erules_2enotAFunction_str2));
    V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2443, v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2446}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2447;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str3), v_x_2433), ((V)&g_heff_2eelab_2erules_2enotAFunction_str4));
    V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str5), v_x_2441), ((V)&g_heff_2eelab_2erules_2enotAFunction_str6));
    V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2448, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2452}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2453;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2enotAFunction_lam2(V self, V *args) {
  V v_c_2455 = args[0];
  return heff_get_n(v_c_2455, 3, 9);
}
V g_heff_2eelab_2erules_2enotAFunction_lam4(V self, V *args) {
  V v_x_2464 = args[0];
  V v_globals_2435 = heff_env(self)[0];
  V v_d_2465 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2464)));
  heff_clo_take(self, 1);
  V v_t_2466 = ({ V b_0 = heff_get_n(v_globals_2435, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2467 = ({ V a_0 = v_t_2466; V a_1 = v_x_2464; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2466); heff_drop(v_x_2464); r_; });
  {
    V v_field_2469 = v_t_2467.f[1];
    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
    if ((v_tag_2468 == ((int64_t)0ULL))) {
      heff_drop(v_d_2465);
      V v_x_2470 = v_field_2469;
      return v_x_2470;
    } else {
      heff_drop(v_field_2469);
      return v_d_2465;
    }
  }
}
V g_heff_2eelab_2erules_2enotAFunction_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_globals_2435 = heff_env(self)[1];
  V v_scope_2436 = heff_env(self)[2];
  V v_k_2454 = heff_env(self)[3];
  HeffT2 v_t_2460 = ({ V a_0 = v_x_2459; HeffT2 r_ = (g_heff_2eelab_2eunify_2ezonker_24cpr(a_0)); heff_drop(v_x_2459); r_; });
  {
    V v_field_2461 = v_t_2460.f[0];
    heff_drop(v_t_2460.f[1]);
    heff_clo_take(self, 4);
    V v_e_2463 = heff_tr(heff_call(v_field_2461, 1, (V[]){heff_get_n(v_m_2437, 0, 2)}));
    HeffT2 v_t_2471 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam4, 1, 1, (V[]){v_globals_2435})));
    {
      V v_field_2472 = v_t_2471.f[0];
      heff_drop(v_t_2471.f[1]);
      V v_e_2474 = heff_tr(heff_call(v_field_2472, 1, (V[]){v_e_2463}));
      V v_x_2475 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_scope_2436, 1, 5), v_e_2474));
      V f_ = v_k_2454;
      args[0] = v_x_2475;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args) {
  V v_x_2433 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ecallee_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_e_2434 = v_e_240;
  V v_globals_2435 = heff_take_field(v_e_2434, 1);
  V v_scope_2436 = heff_get_n(v_e_2434, 0, 8);
  V v_m_2437 = heff_dup(v_ecallee_242);
  V v_hd_2438 = heff_dup(v_p_244);
  V v_malg_2439 = heff_take_field(v_hd_2438, 2);
  V v_bind_2440 = heff_get_n(v_hd_2438, 1, 3);
  V v_k_2454 = heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam1, 1, 5, (V[]){v_ecallee_242, v_x_2433, v_sp_241, v_p_244, v_p_245});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2enotAFunction_lam2_clo)})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_call(v_malg_2439, 1, (V[]){v_t_2457}));
  V f_ = v_bind_2440;
  heff_room[0] = v_t_2458;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam3, 1, 4, (V[]){v_m_2437, v_globals_2435, v_scope_2436, v_k_2454});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2enameAtGo_str0, 1, "\?");
Clo g_heff_2eelab_2erules_2enameAtGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enameAtGo_entry, 2, 0};

V g_heff_2eelab_2erules_2enameAtGo(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2erules_2enameAtGo_str0);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intLe_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return heff_dup(v_x_242);
    } else {
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2enameAtGo(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str0, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str1, 14, "` is of type `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str2, 18, "`, in the region `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str3, 93, "` of the body alone: use it inside the body and return what it gives (a line, a count), not `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str4, 24, "` or anything holding it");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str5, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str6, 48, "`, a resource of a `with`, cannot leave its body");
V g_heff_2eelab_2erules_2eresourceEscapes_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eresourceEscapes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresourceEscapes_entry, 7, 0};

V g_heff_2eelab_2erules_2eresourceEscapes(V v_e_240, V v_sp_241, V v_s_242, V v_x_243, V v_t_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2eelab_2erules_2etyStrZ(v_e_240, v_t_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2eresourceEscapes_lam0, 1, 5, (V[]){v_x_243, v_s_242, v_sp_241, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eresourceEscapes(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2eresourceEscapes_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_s_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str0), heff_dup(v_x_243)), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str1));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_x_247), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str2));
  heff_clo_take(self, 5);
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, v_s_242), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str3));
  V v_note_2411 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_x_243)), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str4));
  V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str5), v_x_243), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str6));
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2412, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2411})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2415}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  heff_room[0] = v_t_2416;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}

HeffT2 g_heff_2eelab_2erules_2eheldGiven_24cpr(V v_e_240, V v_mc_241, V v_a_242, V v_a_27_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_a_242);
    heff_drop(v_a_27_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_held_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    switch (heff_tag_of(v_held_245)) {
    case TAG_MkPair: {
      V v_it2_248 = heff_field(v_held_245, 1);
      switch (heff_tag_of(v_it2_248)) {
      case TAG_MkPair: {
        V v_l_249 = heff_field(v_it2_248, 0);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
        V v_t_2412 = heff_intSub(heff_intSub(v_t_2411, MK_INT(1LL)), heff_dup(v_l_249));
        HeffT3 v_t_2413 = (g_heff_2eelab_2erules_2ementionsLocal_24cpr(v_t_2412));
        {
          V v_field_2415 = v_t_2413.f[1];
          heff_drop(v_t_2413.f[0]);
          heff_drop(v_t_2413.f[2]);
          V v_t_2417 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, heff_dup(v_a_27_243)));
          V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
          V v_t_2419 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2418, v_t_2417));
          HeffT2 v_t_2420 = (g_heff_2eelab_2eunify_2ezonker_24cpr(v_mc_241));
          {
            V v_field_2422 = v_t_2420.f[1];
            heff_drop(v_t_2420.f[0]);
            V v_t_2423 = heff_tr(heff_call(v_field_2422, 1, (V[]){v_t_2419}));
            V v_t_2424 = heff_tr(heff_call(v_field_2415, 2, (V[]){MK_INT(0LL), v_t_2423}));
            if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
              heff_drop(v_t_2424);
              V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
              V v_t_2426 = heff_intSub(heff_intSub(v_t_2425, MK_INT(1LL)), heff_dup(v_l_249));
              HeffT3 v_t_2427 = (g_heff_2eelab_2erules_2ementionsLocal_24cpr(v_t_2426));
              {
                V v_field_2429 = v_t_2427.f[1];
                heff_drop(v_t_2427.f[0]);
                heff_drop(v_t_2427.f[2]);
                V v_t_2431 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, heff_dup(v_a_242)));
                V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
                V v_t_2433 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2432, v_t_2431));
                HeffT2 v_t_2434 = (g_heff_2eelab_2eunify_2ezonker_24cpr(v_mc_241));
                {
                  V v_field_2436 = v_t_2434.f[1];
                  heff_drop(v_t_2434.f[0]);
                  V v_t_2437 = heff_tr(heff_call(v_field_2436, 1, (V[]){v_t_2433}));
                  V v_x1_2438 = heff_tr(heff_call(v_field_2429, 2, (V[]){MK_INT(0LL), v_t_2437}));
                  if (!(heff_dup(v_x1_2438) == NTAG(TAG_True))) {
                    heff_drop_rec(v_e_240, 8);
                    heff_drop(v_a_242);
                    heff_drop(v_a_27_243);
                    heff_drop(v_x1_2438);
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_held_245)}});
                  } else {
                    heff_drop(v_x1_2438);
                    V t_0 = v_e_240;
                    V t_1 = v_mc_241;
                    V t_2 = v_a_242;
                    V t_3 = v_a_27_243;
                    V t_4 = v_rest_246;
                    v_e_240 = t_0;
                    v_mc_241 = t_1;
                    v_a_242 = t_2;
                    v_a_27_243 = t_3;
                    v_x5_244 = t_4;
                    goto top;
                  }
                }
              }
            } else {
              heff_drop(v_t_2424);
              V t_0 = v_e_240;
              V t_1 = v_mc_241;
              V t_2 = v_a_242;
              V t_3 = v_a_27_243;
              V t_4 = v_rest_246;
              v_e_240 = t_0;
              v_mc_241 = t_1;
              v_a_242 = t_2;
              v_a_27_243 = t_3;
              v_x5_244 = t_4;
              goto top;
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it2_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_held_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str0, 5, "unify");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str1, 8, "   FAILS");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str2, 5, "   ok");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str3, 7, "  =\?=  ");
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2eapplyGo_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_lam5, 1, 0};
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eapplyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eapplyGo(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_a_27_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_g_248 = heff_dup(heff_rfield(v_e_241, 1));
    V v_c_249 = heff_dup(heff_rfield(v_e_241, 0));
    V v_len_2410 = heff_take_field(v_c_249, 0);
    V v_names_2411 = heff_get_n(v_c_249, 1, 5);
    return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam0, 2, 5, (V[]){v_g_248, v_len_2410, v_names_2411, heff_dup(v_a_242), heff_dup(v_a_27_247)}), heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam1, 1, 7, (V[]){v_e_241, v_m_246, v_a_242, v_a_27_247, v_p_244, v_sp_240, v_p_245})));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eapplyGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_p_2413 = args[1];
  V v_g_248 = heff_env(self)[0];
  V v_len_2410 = heff_env(self)[1];
  V v_names_2411 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){v_g_248, heff_rec_n(2, shape_len__names, (V[]){v_len_2410, v_names_2411}), v_a_242, v_a_27_247}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2414, v_p_2412, v_p_2413));
}
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args) {
  V v_u_2417 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_drop(v_u_2417);
  heff_clo_take(self, 1);
  V v_x1_2418 = heff_tr(heff_call(heff_get_n(v_m_246, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2419;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_x_2421;
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_2422 = heff_env(self)[0];
  heff_drop(v_hd_2423);
  heff_clo_take(self, 1);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args) {
  V v_c_2427 = args[0];
  return heff_get_n(v_c_2427, 3, 9);
}
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args) {
  V v_u_2432 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_drop(v_u_2432);
  heff_clo_take(self, 5);
  V v_t_2433 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_241), v_x_2431, v_a_242));
  V v_t_2434 = ({ V a_0 = v_e_241; V a_1 = v_x_2431; V a_2 = v_a_27_247; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2431); r_; });
  V v_t_2437;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    v_t_2437 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str1);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2426, 0ULL, 1);
    v_t_2437 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str2);
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2eelab_2erules_2eapplyGo_str3)), v_t_2434);
  return heff_strAppend(v_t_2438, v_t_2437);
}
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args) {
  V v_x_2448 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_m_246 = heff_env(self)[1];
  heff_drop(v_x_2448);
  heff_clo_take(self, 2);
  V f_ = v_p_245;
  args[0] = v_m_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_27_247 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_m_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_drop(v_x_2441);
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_err_2442 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    V v_t_2443 = (g_heff_2eelab_2erules_2ecoeGoal(heff_dup(v_e_241), heff_dup(v_a_27_247), heff_dup(v_a_242)));
    return ({ V a_0 = v_e_241; V a_1 = v_sp_240; V a_2 = v_a_242; V a_3 = v_a_27_247; V a_4 = v_m_246; V a_5 = v_err_2442; V a_6 = v_t_2443; V a_7 = v_p_244; V a_8 = v_p_245; V r_ = (g_heff_2eelab_2erules_2ecoerced(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_err_2442); r_; });
  }
  case TAG_Right: {
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 0ULL, 1);
    heff_drop_rec(v_e_241, 8);
    heff_drop(v_a_27_247);
    heff_drop(v_a_242);
    heff_drop(v_sp_240);
    V v_t_2445 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2446 = heff_tag_at_n(v_ru_24x_2426_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2446}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2447;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam9, 1, 2, (V[]){v_p_245, v_m_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_m_246 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  V v_t_2439 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2eapplyGo_str0), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam7, 1, 5, (V[]){heff_dup(v_e_241), v_x_2431, heff_dup(v_a_242), heff_dup(v_a_27_247), heff_dup(v_x_2426)})}), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam8, 1, 8, (V[]){v_x_2426, v_e_241, v_a_27_247, v_a_242, v_sp_240, v_m_246, v_p_244, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_247 = heff_env(self)[4];
  V v_m_246 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eapplyGo_lam5_clo)})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){v_t_2429}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam6, 1, 8, (V[]){v_sp_240, v_e_241, v_a_242, v_a_27_247, v_x_2426, v_p_244, v_m_246, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_m_246 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  V v_t_2425;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_err_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2especialized_clo), 5, (V[]){heff_dup(v_e_241), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam2, 1, 1, (V[]){heff_dup(v_m_246)}), heff_dup(v_a_242), heff_dup(v_a_27_247), heff_tag_n(TAG_Left, 1, (V[]){v_err_2416})}));
    break;
  }
  case TAG_Right: {
    V v_x_2422 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam3, 2, 1, (V[]){v_x_2422});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  heff_clo_take(self, 7);
  V f_ = v_t_2425;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam4, 1, 7, (V[]){v_p_244, v_sp_240, v_e_241, v_a_242, v_a_27_247, v_m_246, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V v_checksOnly_240, V v_lambda_241, V v_sp_242, V v_callee_243, V v_arg_244) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0, 1, 5, (V[]){heff_dup(v_callee_243), v_sp_242, heff_dup(v_checksOnly_240), heff_dup(v_lambda_241), v_arg_244})}});
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_lambda_241 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_arg_244 = heff_env(self)[3];
  V v_e_245 = heff_env(self)[4];
  V v_hd_248 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_checksOnly_240; V a_1 = v_lambda_241; V a_2 = v_sp_242; V a_3 = v_arg_244; V a_4 = v_e_245; V a_5 = v_x_2413; V a_6 = v_hd_248; V a_7 = v_k_249; V r_ = (g_heff_2eelab_2erules_2eelimWaits(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_checksOnly_240); heff_drop(v_lambda_241); r_; });
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_245 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_lambda_241 = heff_env(self)[4];
  V v_arg_244 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_ecallee0_2411 = heff_field(v_x_2410, 0);
    V v_a0_2412 = heff_field(v_x_2410, 1);
    heff_take_n(v_x_2410, 3ULL, 2);
    heff_clo_take(self, 7);
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_245), heff_dup(v_sp_242), v_ecallee0_2411, v_a0_2412, heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3, 1, 7, (V[]){v_checksOnly_240, v_lambda_241, v_sp_242, v_arg_244, v_e_245, v_hd_248, v_k_249})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_245 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_lambda_241 = heff_env(self)[4];
  V v_arg_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2, 1, 7, (V[]){v_e_245, v_sp_242, v_hd_248, v_checksOnly_240, v_lambda_241, v_arg_244, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_callee_243 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_checksOnly_240 = heff_env(self)[2];
  V v_lambda_241 = heff_env(self)[3];
  V v_arg_244 = heff_env(self)[4];
  V v_c_247;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_callee_243)) {
  case TAG_MkSyn: {
    V v_f_246 = heff_field(v_callee_243, 0);
    heff_take_n(v_callee_243, 1ULL, 1);
    v_c_247 = heff_tr(heff_call(v_f_246, 1, (V[]){heff_dup(v_e_245)}));
    break;
  }
  default: heff_nomatch(v_callee_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1, 2, 6, (V[]){v_c_247, v_e_245, v_sp_242, v_checksOnly_240, v_lambda_241, v_arg_244});
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimRune_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimRune_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimRune_st;
static V g_heff_2eelab_2erules_2eprimRune_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimRune_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimRune_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimRune_st)) return g_heff_2eelab_2erules_2eprimRune_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimRune_val, &g_heff_2eelab_2erules_2eprimRune_st, g_heff_2eelab_2erules_2eprimRune_init);
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitAt_str0, 11, "the literal");
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2enumLitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitAt(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_247, 0ULL, 4);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeInt: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam0_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2418});
    }
    case TAG_LikeFloat: {
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      return (g_heff_2eelab_2erules_2eatFloat64_24tok1_w(v_ru_24x4_243_24IntNum, v_sp_240, heff_intShow(heff_dup(v_i_246)), heff_from_int_f64(v_i_246), v_z_244, v_z_245));
    }
    case TAG_LikeString: {
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeRune: {
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeFixed: {
      V v_w_2420 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      HEFF_LAST return g_heff_2eelab_2erules_2eintAtFixed_24tok1(v_ru_24x4_243_24IntNum, v_sp_240, v_w_2420, v_i_246, v_z_244, v_z_245);
    }
    case TAG_NoRules: {
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_i_246, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_FracNum: {
    V v_d_2421 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_2422 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_2422)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2422, 0ULL, 4);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2422, 0ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeInt: {
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeFloat: {
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      V v_t_2432 = heff_take_field(v_d_2421, 0);
      double v_x_2434;
      if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
        heff_drop(v_t_2432);
        double v_x_2433 = (g_std_2emath_2efromDecimal_w(heff_take_field(v_d_2421, 1), heff_get_n(v_d_2421, 2, 3)));
        v_x_2434 = ((-1.0) * v_x_2433);
      } else {
        heff_drop(v_t_2432);
        v_x_2434 = (g_std_2emath_2efromDecimal_w(heff_dup(heff_rfield(v_d_2421, 1)), heff_get_n(v_d_2421, 2, 3)));
      }
      V v_t_2435;
      if (((v_x_2434 - v_x_2434) == (0.0))) {
        v_t_2435 = heff_floatShow(heff_box_f64(v_x_2434));
      } else {
        v_t_2435 = ((V)&g_heff_2eelab_2erules_2enumLitAt_str0);
      }
      return (g_heff_2eelab_2erules_2eatFloat64_24tok1_w(v_ru_24x4_243_24FracNum, v_sp_240, v_t_2435, v_x_2434, v_z_244, v_z_245));
    }
    case TAG_LikeString: {
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeRune: {
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    case TAG_LikeFixed: {
      V v_w_2437 = heff_field(v_t_2422, 0);
      heff_take_n(v_t_2422, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V a_3 = v_w_2437; V a_4 = v_d_2421; V a_5 = v_z_244; V a_6 = v_z_245; V r_ = (g_heff_2eelab_2erules_2efracAtFixed(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_2437); r_; });
    }
    case TAG_NoRules: {
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s1297944089x11738572(v_d_2421, v_sp_240, v_e_241, v_a_242, v_z_244, v_z_245);
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
Clo g_heff_2eelab_2erules_2eappendP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_entry, 2, 0};

V g_heff_2eelab_2erules_2eappendP(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2erules_2eappendP_24dps(v_xs_243, v_ys_241, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2evaluesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_entry, 5, 0};

V g_heff_2eelab_2erules_2evaluesGo(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_245);
      heff_drop(v_rest_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_pls_248 = heff_field(v_x4_243, 1);
      V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_Nothing: {
        heff_drop(v_m_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_246;
        V t_3 = v_pls_248;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        goto top;
      }
      case TAG_Just: {
        V v_p_249 = heff_field(v_x41_247, 0);
        heff_take_n(v_x41_247, 1ULL, 1);
        V v_t_2410 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_249, heff_dup(v_places_241), heff_dup(v_m_245), heff_dup(v_i_244)));
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){v_m_245, v_t_2410}), heff_hole()});
        V v_u_2412 = (g_heff_2eelab_2erules_2evaluesGo_24dps(v_n_240, v_places_241, v_rest_246, v_pls_248, heff_intAdd(v_i_244, MK_INT(1LL)), v_cell_2411));
        heff_drop(v_u_2412);
        return v_cell_2411;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2evaluesGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2esumFormation_24map2_lam0(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_24map2_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_24map2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map2_entry, 2, 0};

V g_heff_2eelab_2erules_2esumFormation_24map2(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_m_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_248 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24map2_lam0, 1, 1, (V[]){v_m_242}));
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = v_t_248;
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_m_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_248 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24map2_lam1, 1, 1, (V[]){v_m_242}));
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = v_t_248;
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24map2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation_24map2(a[0], a[1]);
}
V g_heff_2eelab_2erules_2esumFormation_24map2_lam0(V self, V *args) {
  V v_u2_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_drop(v_u2_243);
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(heff_get_n(v_m_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nom: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    return v_x_245;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_244, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_247 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    return v_x_247;
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2eelab_2erules_2esumFormation_24map2_lam1(V self, V *args) {
  V v_u2_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_drop(v_u2_243);
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(heff_get_n(v_m_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nom: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    return v_x_245;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_244, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_247 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 1);
    return v_x_247;
  }
  default: return heff_nomatch(v_x1_244);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str0, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str1, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str2, 46, "cannot eliminate from sum type into large type");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str3, 46, "cannot eliminate from sum type into large type");
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumElim_entry, 4, 0};

V g_heff_2eelab_2erules_2esumElim(V v_sp_240, V v_scrutSyn_241, V v_tags_242, V v_casesChk_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam0, 2, 4, (V[]){heff_dup(v_scrutSyn_241), v_sp_240, heff_dup(v_tags_242), v_casesChk_243})});
}
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2esumElim(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args) {
  V v_c_2414 = args[0];
  V v_a0_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2414, 3, 9); V a_1 = v_a0_2413; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args) {
  V v_u_2424 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_drop(v_u_2424);
  heff_clo_take(self, 1);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args) {
  V v_u_2423 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_drop(v_u_2423);
  heff_clo_take(self, 1);
  V v_t_2425 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam7, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2425});
}
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args) {
  V v_chk_2451 = args[0];
  V v_hd_2452 = args[1];
  V v_k2_2453 = args[2];
  V v_x_2418 = heff_env(self)[0];
  V v_t_2454 = heff_tr(heff_call(v_chk_2451, 2, (V[]){heff_dup(v_hd_2452), heff_dup(heff_rfield(v_hd_2452, 0))}));
  heff_clo_take(self, 1);
  V v_t_2455 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2418, v_t_2454, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tr(heff_call(heff_take_field(v_hd_2452, 2), 1, (V[]){v_t_2456}));
  V f_ = heff_get_n(v_hd_2452, 1, 3);
  args[0] = v_t_2457;
  args[1] = v_k2_2453;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  if ((heff_dup(v_x_2422) == NTAG(TAG_True))) {
    heff_drop(v_x_2422);
    heff_clo_take(self, 9);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop_rec(v_scrut_2412, 2);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop_rec(v_e_244, 8);
    heff_drop_rec(v_hd_249, 3);
    V v_t_2426 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam6, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2422);
    V v_t_2449;
    heff_clo_take(self, 9);
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2428 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_2428)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2428, 0ULL, 1);
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2428, 0ULL, 1);
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2428, 0ULL, 1);
        v_t_2449 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2428);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2449 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_t_2449);
      V v_c_2450 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam8, 3, 1, (V[]){v_x_2418}); V a_1 = v_e_244; V a_2 = v_sp_240; V a_3 = ((V)&g_heff_2eelab_2erules_2esumElim_str0); V a_4 = v_c_2450; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2450); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop_rec(v_scrut_2412, 2);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_2449);
      V v_t_2458 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_2459 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str1), v_t_2458);
      V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2459, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2462}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_2463;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_scrut_2412 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  V v_hd_249 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  V v_t_2419 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2418)));
  switch (heff_tag_of(v_t_2419)) {
  case TAG_LikeSum: {
    V v_vs_2420 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    V v_t_2421 = (g_heff_2eelab_2eenvironment_2epartOf(heff_dup(heff_rfield(v_e_244, 0)), heff_dup(heff_rfield(v_scrut_2412, 0))));
    heff_clo_take(self, 8);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_244; V a_2 = v_b_245; V a_3 = v_scrut_2412; V a_4 = v_x_2418; V a_5 = v_t_2421; V a_6 = v_vs_2420; V a_7 = v_tags_242; V a_8 = v_casesChk_243; V a_9 = v_hd_249; V a_10 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_tags_242); r_; });
  }
  default: {
    heff_drop(v_t_2419);
    heff_clo_take(self, 8);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam5, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_scrut_2412 = heff_field(v_x_2411, 0);
    V v_a0_2413 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam3, 1, 1, (V[]){v_a0_2413})})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2416}));
    heff_clo_take(self, 7);
    V f_ = heff_dup(heff_rfield(v_hd_249, 1));
    heff_room[0] = v_t_2417;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam4, 1, 8, (V[]){v_e_244, v_scrut_2412, v_sp_240, v_b_245, v_tags_242, v_casesChk_243, v_hd_249, v_k_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam2, 1, 7, (V[]){v_hd_249, v_e_244, v_sp_240, v_b_245, v_tags_242, v_casesChk_243, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_2466 = heff_take_field(v_hd_2464, 2);
  V v_bind_2467 = heff_get_n(v_hd_2464, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2468 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str2), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tr(heff_call(v_malg_2466, 1, (V[]){v_t_2470}));
  V f_ = v_bind_2467;
  args[0] = v_t_2471;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k2_2473 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_2474 = heff_take_field(v_hd_2472, 2);
  V v_bind_2475 = heff_get_n(v_hd_2472, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str3), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_call(v_malg_2474, 1, (V[]){v_t_2478}));
  V f_ = v_bind_2475;
  args[0] = v_t_2479;
  args[1] = v_k2_2473;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tags_242 = heff_env(self)[2];
  V v_casesChk_243 = heff_env(self)[3];
  V v_x1_246 = (g_heff_2eelab_2evalue_2elevelOf(v_b_245));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Small: {
    V v_c_248;
    heff_clo_take(self, 4);
    switch (heff_tag_of(v_scrutSyn_241)) {
    case TAG_MkSyn: {
      V v_f_247 = heff_field(v_scrutSyn_241, 0);
      heff_take_n(v_scrutSyn_241, 1ULL, 1);
      v_c_248 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_dup(v_e_244)}));
      break;
    }
    default: heff_nomatch(v_scrutSyn_241);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam1, 2, 6, (V[]){v_c_248, v_e_244, v_sp_240, v_b_245, v_tags_242, v_casesChk_243});
  }
  case TAG_Large: {
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_b_245);
    heff_clo_take(self, 4);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam9, 2, 1, (V[]){v_sp_240});
  }
  case TAG_TopL: {
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_b_245);
    heff_clo_take(self, 4);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam10, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2eelab_2erules_2efirstElab_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efirstElab_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efirstElab_entry, 3, 0};

V g_heff_2eelab_2erules_2efirstElab(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    return heff_tail(heff_dup(v_m_243), 2, (V[]){heff_dup(v_p_241), heff_clo_n(g_heff_2eelab_2erules_2efirstElab_lam0, 1, 3, (V[]){heff_dup(v_ms_244), v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2efirstElab_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2efirstElab(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2efirstElab_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_ms_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_clo_take(self, 3);
    return ({ V a_0 = v_ms_244; V a_1 = v_p_241; V a_2 = v_p_242; V r_ = (g_heff_2eelab_2erules_2efirstElab(a_0, a_1, a_2)); heff_drop(v_ms_244); r_; });
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_ms_244);
    heff_drop(v_p_241);
    V f_ = v_p_242;
    args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_245);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efracDefault_24tok1_str0, 11, "the literal");
V g_heff_2eelab_2erules_2efracDefault_24tok1_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2efracDefault_24tok1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efracDefault_24tok1_lam1, 1, 0};
V g_heff_2eelab_2erules_2efracDefault_24tok1_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efracDefault_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efracDefault_24tok1_entry, 7, 0};

V g_heff_2eelab_2erules_2efracDefault_24tok1_w(V v_tok_240, V v_sp_241, V v_e_242, V v_a_243, double v_x_244, V v_z_245, V v_z_246) {
top: ;
  if (((v_x_244 - v_x_244) == (0.0))) {
    HeffT1 v_t_2413 = ({ V a_0 = v_sp_241; V b_1 = heff_tag_at_n(v_tok_240, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efracDefault_24tok1_lam0, 3, 1, (V[]){heff_box_f64(v_x_244)})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_f_2415 = v_field_2414;
      return heff_tail(v_f_2415, 4, (V[]){v_e_242, v_a_243, v_z_245, v_z_246});
    }
  } else {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_e_242);
    heff_drop(v_a_243);
    V v_t_2416;
    if (((v_x_244 - v_x_244) == (0.0))) {
      v_t_2416 = heff_floatShow(heff_box_f64(v_x_244));
    } else {
      v_t_2416 = ((V)&g_heff_2eelab_2erules_2efracDefault_24tok1_str0);
    }
    return (g_heff_2eelab_2erules_2eatFloat64_w(v_sp_241, v_t_2416, v_x_244, v_z_245, v_z_246));
  }
}
V g_heff_2eelab_2erules_2efracDefault_24tok1(V v_tok_240, V v_sp_241, V v_e_242, V v_a_243, V v_box_24x_244, V v_z_245, V v_z_246) {
  double v_x_244 = heff_unbox_f64(v_box_24x_244);
  return (g_heff_2eelab_2erules_2efracDefault_24tok1_w(v_tok_240, v_sp_241, v_e_242, v_a_243, v_x_244, v_z_245, v_z_246));
}
V g_heff_2eelab_2erules_2efracDefault_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efracDefault_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2efracDefault_24tok1_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2efracDefault_24tok1_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  V v_box_24x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  double v_x_244 = heff_unbox_f64(v_box_24x_244);
  heff_drop(v_e_247);
  heff_drop(v_hd_248);
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_x_244)}), ((V)&g_heff_2eelab_2erules_2efracDefault_24tok1_lam1_clo)});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, NTAG(TAG_VPrimFloat)});
  V f_ = v_k_249;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str0, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str1, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str2, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str3, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str4, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str5, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str6, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str7, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str8, 7, "Float32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str9, 19, ", whose values are ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str10, 4, " to ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str11, 21, " is out of range for ");
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2eintAtFixed_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_24tok1_entry, 6, 0};

V g_heff_2eelab_2erules_2eintAtFixed_24tok1(V v_tok_240, V v_sp_241, V v_w_242, V v_i_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_w_242)) {
  case TAG_I8: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_w_242);
    heff_drop(v_t_246);
    float v_t_247 = (g_float32_2efromDecimal_w(heff_dup(v_i_243), MK_INT(0LL)));
    V v_t_248 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_241, heff_intShow(v_i_243), heff_box_f64(((double)v_t_247))));
    return heff_tail(v_t_248, 2, (V[]){v_z_244, v_z_245});
  } else {
    heff_drop(v_t_246);
    V v_t_249 = (g_heff_2eelab_2efixed_2efixedMin(v_w_242));
    if ((heff_intLe_c_lent(v_t_249, v_i_243, 0) && ({ V v_t_2422 = (g_heff_2eelab_2efixed_2efixedMax(v_w_242)); int c_ = heff_intLe_c_lent(v_i_243, v_t_2422, 0); heff_drop(v_t_2422); c_; }))) {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_sp_241);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_249);
      V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFixed, 2, (V[]){v_w_242, v_i_243}), ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2411});
    } else {
      heff_drop(v_t_249);
      V v_t_2412;
      switch (heff_tag_of(v_w_242)) {
      case TAG_I8: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str0);
        break;
      }
      case TAG_I16: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str1);
        break;
      }
      case TAG_I32: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str2);
        break;
      }
      case TAG_I64: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str3);
        break;
      }
      case TAG_U8: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str4);
        break;
      }
      case TAG_U16: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str5);
        break;
      }
      case TAG_U32: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str6);
        break;
      }
      case TAG_U64: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str7);
        break;
      }
      case TAG_F32: {
        v_t_2412 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str8);
        break;
      }
      default: heff_nomatch(v_w_242);
      }
      V v_t_2413 = (g_heff_2eelab_2efixed_2efixedMin(v_w_242));
      V v_t_2414 = ({ V a_0 = v_w_242; V r_ = (g_heff_2eelab_2efixed_2efixedMax(a_0)); heff_drop(v_w_242); r_; });
      V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str9)), heff_intShow(v_t_2413));
      V v_why_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str10)), heff_intShow(v_t_2414));
      V v_t_2417 = heff_strAppend(heff_intShow(v_i_243), ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str11));
      V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), heff_strAppend(v_t_2417, v_why_2416), v_sp_241, NTAG(TAG_Nothing)});
      V v_t_2419 = heff_tag_at_n(v_tok_240, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){v_t_2420}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2421, v_z_245});
    }
  }
}
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintAtFixed_24tok1(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}