// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_RestoreWaiting 10254
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SaveDelayed 42463
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define LBL_aliases 1464806715
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_name__from__scheme__ty__stx__val[] = {LBL_name, LBL_from, LBL_scheme, LBL_ty, LBL_stx, LBL_val};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2efixed_2efixedMax(V);
V g_heff_2eelab_2efixed_2efixedMax_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMax_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimRune_get(void);
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2ecoeGoal(V, V, V);
V g_heff_2eelab_2erules_2ecoeGoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoeGoal_clo;
V g_heff_2eelab_2erules_2ecoerced(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecoerced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecoerced_clo;
V g_heff_2eelab_2erules_2edefaultFor(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultFor_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
V g_heff_2eelab_2erules_2eelStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2eelStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelStrZ_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
HeffT1 g_heff_2eelab_2erules_2eetaArg_24cpr(V, V, V);
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
HeffT1 g_heff_2eelab_2erules_2efind_24cpr(V, V);
V g_heff_2eelab_2erules_2efirstElab(V, V, V);
V g_heff_2eelab_2erules_2efirstElab_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efirstElab_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V, V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2eintAtFixed_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_24tok1_clo;
V g_heff_2eelab_2erules_2ematchLater(V, V, V, V, V);
V g_heff_2eelab_2erules_2ematchLater_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ematchLater_clo;
V g_heff_2eelab_2erules_2enameAtGo(V, V);
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enameAtGo_clo;
V g_heff_2eelab_2erules_2enotAFunction(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotAFunction_clo;
V g_heff_2eelab_2erules_2enotANumber(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2epathSaid_2edown_241(V, V);
V g_heff_2eelab_2erules_2epathSaid_2edown_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epathSaid_2edown_241_clo;
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eresolveWanted(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresolveWanted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresolveWanted_clo;
V g_heff_2eelab_2erules_2eresourceEscapes(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresourceEscapes_clo;
V g_heff_2eelab_2erules_2esearchedNow(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esearchedNow_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esearchedNow_clo;
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2esumPaths(V, V);
V g_heff_2eelab_2erules_2esumPaths_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumPaths_clo;
V g_heff_2eelab_2erules_2ethroughCandidates(V, V, V);
V g_heff_2eelab_2erules_2ethroughCandidates_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ethroughCandidates_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrZ(V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_clo;
V g_heff_2eelab_2erules_2etyStrZ_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2erules_2evaluesGo_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2007813875x1918122072(V);
V g_list_2emap_24s2007813875x1918122072_entry(V self, V *a);
extern Clo g_list_2emap_24s2007813875x1918122072_clo;
V g_list_2emap_24s570884835x2121220820(V);
V g_list_2emap_24s570884835x2121220820_entry(V self, V *a);
extern Clo g_list_2emap_24s570884835x2121220820_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2eelab_2erules_2edownFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_entry, 1, 0};

V g_heff_2eelab_2erules_2edownFrom(V v_n_240) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_242 = (g_heff_2eelab_2erules_2edownFrom_24dps(heff_intSub(v_n_240, MK_INT(1LL)), heff_dup(v_cell_241)));
    heff_drop(v_u_242);
    return v_cell_241;
  }
}
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom(a[0]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efillHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efillHole_entry, 6, 0};

V g_heff_2eelab_2erules_2efillHole(V v_g_240, V v_m_241, V v_e_242, V v_argStx_243, V v_hd_244, V v_k_245) {
top: ;
  V v_bind_246 = heff_take_field(v_hd_244, 1);
  V v_malg_247 = heff_get_n(v_hd_244, 2, 3);
  V v_ty_248 = heff_take_field(v_e_242, 0);
  V v_arity_249 = heff_take_field(v_e_242, 3);
  V v_name_2410 = heff_take_field(v_e_242, 4);
  V v_span_2411 = heff_get_n(v_e_242, 5, 6);
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam0, 1, 7, (V[]){v_arity_249, v_argStx_243, v_g_240, v_ty_248, v_name_2410, v_span_2411, v_m_241})})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_malg_247), 1, (V[]){v_t_2431}));
  return heff_tail(heff_dup(v_bind_246), 2, (V[]){v_t_2432, heff_clo_n(g_heff_2eelab_2erules_2efillHole_lam1, 1, 3, (V[]){v_malg_247, v_bind_246, v_k_245})});
}
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efillHole(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efillHole_lam0(V self, V *args) {
  V v_c_2412 = args[0];
  V v_arity_249 = heff_env(self)[0];
  V v_argStx_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_ty_248 = heff_env(self)[3];
  V v_name_2410 = heff_env(self)[4];
  V v_span_2411 = heff_env(self)[5];
  V v_m_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_metas_2413 = heff_take_field(v_c_2412, 3);
  V v_infos_2414 = heff_take_field(v_c_2412, 0);
  V v_recovered_2415 = heff_take_field(v_c_2412, 1);
  V v_poisoned_2416 = heff_take_field(v_c_2412, 2);
  V v_nextMeta_2417 = heff_take_field(v_c_2412, 4);
  V v_postponed_2418 = heff_take_field(v_c_2412, 5);
  V v_trace_2419 = heff_take_field(v_c_2412, 6);
  V v_selfKey_2420 = heff_get_n(v_c_2412, 7, 8);
  V v_s_2421 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(v_arity_249), heff_dup(v_argStx_243)));
  V v_x1_2422 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), v_s_2421, NTAG(TAG_LNil)));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_t_2427 = (g_heff_2eelab_2eunify_2elamsU(heff_dup(v_arity_249), v_argStx_243));
  V v_t_2428 = heff_rec_n(6, shape_ty__sol__solStx__arity__name__span, (V[]){v_ty_248, heff_tag_n(TAG_Just, 1, (V[]){v_t_2426}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2427}), v_arity_249, v_name_2410, v_span_2411});
  V v_mc_2429 = (g_std_2emap_2einsert_24s170109517x1206653089(v_metas_2413, v_m_241, v_t_2428));
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_2414, v_recovered_2415, v_poisoned_2416, v_mc_2429, v_nextMeta_2417, v_postponed_2418, v_trace_2419, v_selfKey_2420});
}
V g_heff_2eelab_2erules_2efillHole_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_malg_247 = heff_env(self)[0];
  V v_bind_246 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2433, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_call(v_malg_247, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})}));
  V f_ = v_bind_246;
  heff_room[0] = v_t_2436;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esearchedNow_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esearchedNow_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esearchedNow_lam0, 1, 0};
V g_heff_2eelab_2erules_2esearchedNow_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2esearchedNow_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esearchedNow_lam2, 1, 0};
V g_heff_2eelab_2erules_2esearchedNow_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esearchedNow_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esearchedNow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esearchedNow_entry, 6, 0};

V g_heff_2eelab_2erules_2esearchedNow(V v_e_240, V v_sp_241, V v_hole_242, V v_goal_243, V v_hd_244, V v_k_245) {
top: ;
  V v_stx_246 = heff_take_field(v_hole_242, 0);
  V v_val_247 = heff_get_n(v_hole_242, 1, 2);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esearchedNow_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam1, 1, 7, (V[]){v_hd_244, v_stx_246, v_e_240, v_sp_241, v_val_247, v_goal_243, v_k_245})});
}
V g_heff_2eelab_2erules_2esearchedNow_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esearchedNow(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2esearchedNow_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return v_c_248;
}
V g_heff_2eelab_2erules_2esearchedNow_lam2(V self, V *args) {
  V v_sv_2413 = args[0];
  return v_sv_2413;
}
V g_heff_2eelab_2erules_2esearchedNow_lam6(V self, V *args) {
  V v_x_2462 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2462);
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esearchedNow_lam5(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2458);
  V v_t_2459 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2460}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2461;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam6, 1, 1, (V[]){v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esearchedNow_lam4(V self, V *args) {
  V v_s_2454 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_s_2454);
  V v_t_2455 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2457;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam5, 1, 2, (V[]){v_x_2416, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esearchedNow_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_stx_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_val_247 = heff_env(self)[3];
  V v_goal_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2452;
  switch (heff_tag_of(v_stx_246)) {
  case TAG_SLocal: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_stx_246, 0ULL, 3);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2441 = heff_field(v_stx_246, 0);
    heff_take_n(v_stx_246, 1ULL, 3);
    v_t_2452 = v_k_2441;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_stx_246, 0ULL, 2);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_stx_246, 0ULL, 1);
    v_t_2452 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_stx_246);
  }
  V v_t_2453 = heff_tr(g_heff_2eelab_2erules_2eresolveWanted(v_e_240, v_sp_241, heff_dup(g_heff_2eelab_2erules_2etopSearch_get()), v_t_2452, v_val_247, v_goal_243, NTAG(TAG_False), heff_dup(v_hd_244), heff_dup(heff_rfield(v_hd_244, 0))));
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2453, heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam4, 1, 3, (V[]){v_x_2412, heff_dup(v_hd_244), v_x_2416})})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2464}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2465;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esearchedNow_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_stx_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_val_247 = heff_env(self)[4];
  V v_goal_243 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2esearchedNow_lam2_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esearchedNow_lam3, 1, 8, (V[]){v_stx_246, v_e_240, v_sp_241, v_val_247, v_goal_243, v_hd_244, v_x_2412, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str0, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str1, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str2, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str3, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str4, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str5, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str6, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str7, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str8, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str9, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroImplicit_str10, 82, "an implicit lambda `\\{x} -> ...` checked at a type that takes no implicit argument");
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroImplicit_entry, 3, 0};

V g_heff_2eelab_2erules_2efunctionIntroImplicit(V v_sp_240, V v_x_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0, 4, 3, (V[]){v_sp_240, v_x_241, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2efunctionIntroImplicit(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1(V self, V *args) {
  V v_c_2413 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2413, 3, 8); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4(V self, V *args) {
  V v_u_2438 = args[0];
  V v_v_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2438);
  return v_v_2433;
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7(V self, V *args) {
  V v_u_2459 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2459);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2417});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6(V self, V *args) {
  V v_x_2454 = args[0];
  V v_elabFor_249 = heff_env(self)[0];
  V v_scope_247 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_globals_248 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_k_2453 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2457;
  switch (heff_tag_of(v_elabFor_249)) {
  case TAG_ForNominative: {
    v_t_2457 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_elabFor_249, 0ULL, 2);
    v_t_2457 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_elabFor_249);
  }
  V v_t_2458 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_take_field(v_scope_247, 0), heff_dup(v_x_2417)));
  V v_x_2460 = (g_heff_2eelab_2ememoed_2elam(v_t_2457, v_globals_248, heff_get_n(v_scope_247, 2, 4), heff_rec_n(2, shape_stx__val, (V[]){v_t_2458, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam7, 1, 1, (V[]){v_x_2417})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2454})));
  V f_ = v_k_2453;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_c_2451 = heff_env(self)[0];
  V v_elabFor_249 = heff_env(self)[1];
  V v_scope_247 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_globals_248 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2451;
  args[0] = v_hd_2452;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam6, 1, 6, (V[]){v_elabFor_249, v_scope_247, v_x_2417, v_globals_248, v_x_241, v_k_2453});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3(V self, V *args) {
  V v_v_2433 = args[0];
  V v_scope_27_2434 = args[1];
  V v_cod_2426 = heff_env(self)[0];
  V v_body_242 = heff_env(self)[1];
  V v_elabFor_249 = heff_env(self)[2];
  V v_implicit_2427 = heff_env(self)[3];
  V v_insts_2412 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  V v_dom_2425 = heff_env(self)[6];
  V v_globals_248 = heff_env(self)[7];
  V v_lams_2410 = heff_env(self)[8];
  V v_self_2411 = heff_env(self)[9];
  V v_scope_247 = heff_env(self)[10];
  V v_x_2417 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_x1_2440;
  switch (heff_tag_of(v_cod_2426)) {
  case TAG_MkClo: {
    V v_vs_2436 = heff_field(v_cod_2426, 1);
    V v_body_2437 = heff_field(v_cod_2426, 2);
    heff_take_n(v_cod_2426, 6ULL, 3);
    v_x1_2440 = heff_tr(heff_call(v_body_2437, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2436, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam4, 1, 1, (V[]){heff_dup(v_v_2433)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2439 = heff_field(v_cod_2426, 0);
    heff_take_n(v_cod_2426, 1ULL, 1);
    v_x1_2440 = v_body_2439;
    break;
  }
  default: heff_nomatch(v_cod_2426);
  }
  V v_a_2444;
  switch (heff_tag_of(v_x1_2440)) {
  case TAG_Nom: {
    V v_x_2441 = heff_field(v_x1_2440, 0);
    heff_take_n(v_x1_2440, 1ULL, 1);
    v_a_2444 = v_x_2441;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2440, 0ULL, 1);
    v_a_2444 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2443 = heff_field(v_x1_2440, 0);
    heff_take_n(v_x1_2440, 1ULL, 1);
    v_a_2444 = v_x_2443;
    break;
  }
  default: heff_nomatch(v_x1_2440);
  }
  V v_c_2451;
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2445 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2448;
    switch (heff_tag_of(v_elabFor_249)) {
    case TAG_ForNominative: {
      v_t_2448 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2446 = heff_dup(heff_field(v_elabFor_249, 0));
      V v_sp_2447 = heff_dup(heff_field(v_elabFor_249, 1));
      v_t_2448 = heff_tag_n(TAG_ForDescriptive, 2, (V[]){v_h_2446, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2447, heff_dup(v_v_2433)})});
      break;
    }
    default: heff_nomatch(v_elabFor_249);
    }
    V v_t_2449;
    switch (heff_tag_of(v_implicit_2427)) {
    case TAG_Expl: {
      heff_drop(v_v_2433);
      heff_drop(v_dom_2425);
      v_t_2449 = v_insts_2412;
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2433);
      heff_drop(v_dom_2425);
      v_t_2449 = v_insts_2412;
      break;
    }
    case TAG_Inst: {
      v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){heff_dup(v_x_241), v_dom_2425, v_v_2433}), v_insts_2412});
      break;
    }
    default: heff_nomatch(v_implicit_2427);
    }
    V v_t_2450 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2434, heff_dup(v_globals_248), v_t_2448, heff_intAdd(v_lams_2410, MK_INT(1LL)), v_self_2411, v_t_2449});
    v_c_2451 = heff_tr(heff_call(v_f_2445, 2, (V[]){v_t_2450, v_a_2444}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam5, 2, 6, (V[]){v_c_2451, v_elabFor_249, v_scope_247, v_x_2417, v_globals_248, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_scope_247 = heff_env(self)[4];
  V v_body_242 = heff_env(self)[5];
  V v_elabFor_249 = heff_env(self)[6];
  V v_insts_2412 = heff_env(self)[7];
  V v_globals_248 = heff_env(self)[8];
  V v_lams_2410 = heff_env(self)[9];
  V v_self_2411 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2418 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2417)));
  switch (heff_tag_of(v_t_2418)) {
  case TAG_LikeU: {
    V v_ru_24t_2418_24LikeU = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_at_n(v_ru_24t_2418_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_dom_2425 = heff_field(v_t_2418, 1);
    V v_cod_2426 = heff_field(v_t_2418, 2);
    V v_implicit_2427 = heff_field(v_t_2418, 3);
    heff_take_n(v_t_2418, 14ULL, 4);
    V v_t_2428;
    switch (heff_tag_of(v_implicit_2427)) {
    case TAG_Expl: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2427);
    }
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_x_2417);
      heff_drop(v_x_241);
      heff_drop_rec(v_scope_247, 4);
      heff_drop(v_body_242);
      heff_drop(v_elabFor_249);
      heff_drop(v_insts_2412);
      heff_drop(v_globals_248);
      heff_drop(v_lams_2410);
      heff_drop(v_self_2411);
      heff_drop(v_dom_2425);
      heff_drop(v_cod_2426);
      heff_drop(v_implicit_2427);
      heff_drop(v_t_2428);
      V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2431}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2432;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2428);
      V v_t_2461 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), heff_dup(v_dom_2425), heff_dup(v_scope_247), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam3, 2, 12, (V[]){v_cod_2426, v_body_242, v_elabFor_249, v_implicit_2427, v_insts_2412, v_x_241, v_dom_2425, v_globals_248, v_lams_2410, v_self_2411, v_scope_247, v_x_2417})));
      V f_ = v_t_2461;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2418, 0ULL, 3);
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2467}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2468;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2418_24LikeSum = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2471 = heff_tag_at_n(v_ru_24t_2418_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2472}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2473;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2476}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2477;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2478 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2480}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2481;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2484}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2485;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2488}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2489;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2418_24LikeArray = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2492 = heff_tag_at_n(v_ru_24t_2418_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2493}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2494;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2418_24LikeFixed = heff_take_reuse_n(v_t_2418, 0ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2497 = heff_tag_at_n(v_ru_24t_2418_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2498}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2499;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2417);
    heff_drop(v_x_241);
    heff_drop_rec(v_scope_247, 4);
    heff_drop(v_body_242);
    heff_drop(v_elabFor_249);
    heff_drop(v_insts_2412);
    heff_drop(v_globals_248);
    heff_drop(v_lams_2410);
    heff_drop(v_self_2411);
    V v_t_24100 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(325LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroImplicit_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24102}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_24103;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroImplicit_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_scope_247 = heff_take_field(v_e_243, 0);
  V v_globals_248 = heff_take_field(v_e_243, 1);
  V v_elabFor_249 = heff_take_field(v_e_243, 2);
  V v_lams_2410 = heff_take_field(v_e_243, 3);
  V v_self_2411 = heff_take_field(v_e_243, 4);
  V v_insts_2412 = heff_get_n(v_e_243, 5, 6);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2415}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroImplicit_lam2, 1, 11, (V[]){v_sp_240, v_hd_245, v_k_246, v_x_241, v_scope_247, v_body_242, v_elabFor_249, v_insts_2412, v_globals_248, v_lams_2410, v_self_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumPaths_str0, 6, "co.<+>");
Clo g_heff_2eelab_2erules_2esumPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumPaths_entry, 2, 0};

V g_heff_2eelab_2erules_2esumPaths(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SGlobal: {
    V v_k_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_g_240, 1), v_k_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        V v_e_247 = v_field_246;
        V t_0 = v_g_240;
        V t_1 = heff_get_n(v_e_247, 0, 4);
        v_g_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_g_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_k2_2411 = v_field_2410;
            HeffT2 v_t_2412 = ({ V a_0 = heff_rfield(v_g_240, 1); V a_1 = v_k2_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k2_2411); r_; });
            {
              V v_field_2414 = v_t_2412.f[1];
              int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
              if ((v_tag_2413 == ((int64_t)0ULL))) {
                V v_entry_2415 = v_field_2414;
                V t_0 = v_g_240;
                V t_1 = heff_get_n(v_entry_2415, 0, 4);
                v_g_240 = t_0;
                v_x2_241 = t_1;
                goto top;
              } else {
                heff_drop_rec(v_g_240, 8);
                heff_drop(v_field_2414);
                return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
              }
            }
          } else {
            heff_drop_rec(v_g_240, 8);
            heff_drop(v_field_2410);
            return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
          }
        }
      }
    }
  }
  case TAG_SCode: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SApp: {
    V v_x21_2417 = heff_field(v_x2_241, 0);
    V v_b_2418 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24SApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_SLocal: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SGlobal: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SCode: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SApp: {
      V v_x211_2422 = heff_field(v_x21_2417, 0);
      V v_a_2423 = heff_field(v_x21_2417, 1);
      heff_take_n(v_x21_2417, 3ULL, 2);
      switch (heff_tag_of(v_x211_2422)) {
      case TAG_SLocal: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SGlobal: {
        V v_k_2425 = heff_field(v_x211_2422, 0);
        heff_take_n(v_x211_2422, 1ULL, 1);
        if (heff_strEq_c(v_k_2425, ((V)&g_heff_2eelab_2erules_2esumPaths_str0))) {
          V v_t_2426 = (g_heff_2eelab_2erules_2esumPaths(heff_dup(v_g_240), v_a_2423));
          V v_t_2427 = (g_list_2emap_24s2007813875x1918122072(v_t_2426));
          V v_t_2428 = (g_heff_2eelab_2erules_2esumPaths(v_g_240, v_b_2418));
          V v_t_2429 = (g_list_2emap_24s570884835x2121220820(v_t_2428));
          return (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_241_24SApp, v_t_2427, v_t_2429));
        } else {
          heff_drop_rec(v_g_240, 8);
          heff_drop(v_b_2418);
          heff_drop(v_a_2423);
          return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
        }
      }
      case TAG_SCode: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SApp: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLam: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SCons: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SProj: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_STag: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SMatch: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SSpecialize: {
        heff_take_n(v_x211_2422, 0ULL, 3);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SIs: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SOpaque: {
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SAbandon: {
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SRec: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SFix: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SImplicit: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SPrim: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SMetaApp: {
        heff_take_n(v_x211_2422, 0ULL, 3);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitInt: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitFloat: {
        heff_take_na(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitString: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitBytes: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitRune: {
        heff_take_n(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitFixed: {
        heff_take_n(v_x211_2422, 0ULL, 2);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_x211_2422, 0ULL, 1);
        heff_drop_rec(v_g_240, 8);
        heff_drop(v_b_2418);
        heff_drop(v_a_2423);
        return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_x211_2422);
      }
    }
    case TAG_SLam: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SCons: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SProj: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_STag: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SMatch: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x21_2417, 0ULL, 3);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SIs: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SOpaque: {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SAbandon: {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SRec: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SFix: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SImplicit: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SPrim: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x21_2417, 0ULL, 3);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitInt: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitString: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitRune: {
      heff_take_n(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x21_2417, 0ULL, 2);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x21_2417, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_b_2418);
      return heff_tag_at_n(v_ru_24x2_241_24SApp, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  case TAG_SLam: {
    V v_ru_24x2_241_24SLam = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SLam, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SCons: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SProj: {
    V v_ru_24x2_241_24SProj = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SProj, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_STag: {
    V v_ru_24x2_241_24STag = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24STag, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SMatch: {
    V v_ru_24x2_241_24SMatch = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SMatch, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SIs: {
    V v_t_24105 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_g_240;
    V t_1 = v_t_24105;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SRec: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SFix: {
    V v_ru_24x2_241_24SFix = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SFix, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SImplicit: {
    V v_ru_24x2_241_24SImplicit = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SImplicit, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitString: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitRune: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitFixed: {
    V v_ru_24x2_241_24SLitFixed = heff_take_reuse_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_at_n(v_ru_24x2_241_24SLitFixed, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2esumPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumPaths(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2ethroughCandidates_str0, 20, "an instance argument");
HEFF_LIT(g_heff_2eelab_2erules_2ethroughCandidates_str1, 6, "\\p -> ");
V g_heff_2eelab_2erules_2ethroughCandidates_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ethroughCandidates_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ethroughCandidates_lam0, 2, 0};
V g_heff_2eelab_2erules_2ethroughCandidates_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ethroughCandidates_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ethroughCandidates_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ethroughCandidates_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ethroughCandidates_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ethroughCandidates_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ethroughCandidates_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ethroughCandidates_lam6(V self, V *args);
Clo g_heff_2eelab_2erules_2ethroughCandidates_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ethroughCandidates_entry, 3, 0};

V g_heff_2eelab_2erules_2ethroughCandidates(V v_e_240, V v_cand_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_cand_241);
    return ((V)&g_heff_2eelab_2erules_2ethroughCandidates_lam0_clo);
  }
  case TAG_Cons: {
    V v_path_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2414 = (g_list_2emap_24tok2(v_ru_24x3_242_24Cons, heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam1, 1, 1, (V[]){heff_dup(v_e_240)}), heff_dup(heff_rfield(v_e_240, 5))));
    V v_c_2425 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam3, 1, 2, (V[]){heff_dup(v_cand_241), v_path_245}), v_t_2414));
    return heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam6, 2, 4, (V[]){v_c_2425, v_e_240, v_cand_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2ethroughCandidates_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ethroughCandidates(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam2(V self, V *args) {
  V v_u_2413 = args[0];
  V v_name_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_name_249;
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_v_248 = heff_take_field(v_c_247, 2);
  V v_name_249 = heff_take_field(v_c_247, 0);
  V v_ty_2410 = heff_get_n(v_c_247, 1, 3);
  V v_t_2411 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_stx_2412 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_t_2411, heff_dup(v_v_248)));
  return heff_rec_n(6, shape_name__from__scheme__ty__stx__val, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam2, 1, 1, (V[]){v_name_249}), ((V)&g_heff_2eelab_2erules_2ethroughCandidates_str0), NTAG(TAG_False), v_ty_2410, v_stx_2412, v_v_248});
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_w_2415 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tr(heff_call(heff_get_n(v_w_2415, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_w_2422 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
  V v_t_2423 = ({ V a_0 = v_w_2422; V a_1 = v_path_245; V r_ = (g_heff_2eelab_2erules_2epathSaid_2edown_241(a_0, a_1)); heff_drop_tag(v_w_2422, 1); heff_drop(v_path_245); r_; });
  V v_x_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2ethroughCandidates_str1), v_t_2423), v_x_2420});
  V f_ = v_k_2419;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_w_2415 = heff_env(self)[1];
  V v_path_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam5, 1, 3, (V[]){v_w_2415, v_path_245, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam3(V self, V *args) {
  V v_w_2415 = args[0];
  V v_cand_241 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_w_2415, 0)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_c_2417 = heff_tr(heff_call(v_cand_241, 2, (V[]){heff_dup(v_path_245), heff_tag_n(TAG_Just, 1, (V[]){v_t_2416})}));
  return heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam4, 2, 3, (V[]){v_c_2417, v_w_2415, v_path_245});
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2431 = (g_prelude_2e_2b_2b(v_x_2428, v_x_2430));
  V f_ = v_k_2427;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_cand_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2426 = heff_env(self)[3];
  V v_k_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2429 = (g_heff_2eelab_2erules_2ethroughCandidates(v_e_240, v_cand_241, v_rest_246));
  V f_ = v_c_2429;
  heff_room[0] = v_hd_2426;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam8, 1, 2, (V[]){v_x_2428, v_k_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ethroughCandidates_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_cand_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ethroughCandidates_lam7, 1, 5, (V[]){v_e_240, v_cand_241, v_rest_246, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str0, 65, "tried to apply a value as a function, where its type is not known");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str1, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str2, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str3, 31, "tried to apply a value of type ");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str4, 30, ", which is not a function type");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str5, 27, "the value applied here is `");
HEFF_LIT(g_heff_2eelab_2erules_2enotAFunction_str6, 1, "`");
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enotAFunction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enotAFunction_entry, 6, 0};

V g_heff_2eelab_2erules_2enotAFunction(V v_e_240, V v_sp_241, V v_ecallee_242, V v_a_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_a_243)) {
  case TAG_VU: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_247 = heff_dup(heff_field(v_a_243, 0));
    switch (heff_tag_of(v_t1_247)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_247);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_e_240);
    heff_drop_rec(v_ecallee_242, 2);
    heff_drop(v_a_243);
    heff_drop(v_t_2428);
    V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2enotAFunction_str0), v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2431}));
    return heff_tail(heff_get_n(v_p_244, 1, 3), 2, (V[]){v_t_2432, v_p_245});
  } else {
    heff_drop(v_t_2428);
    return (g_heff_2eelab_2erules_2etyStrZ(heff_dup(v_e_240), v_a_243, heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam0, 1, 5, (V[]){v_e_240, v_ecallee_242, v_p_244, v_sp_241, v_p_245})));
  }
}
V g_heff_2eelab_2erules_2enotAFunction_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enotAFunction(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enotAFunction_lam1(V self, V *args) {
  V v_x_2434 = args[0];
  V v_ecallee_242 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435 = heff_get_n(v_ecallee_242, 0, 2);
  V v_t_2471;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2435, 0ULL, 3);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2460 = heff_field(v_t_2435, 0);
    heff_take_n(v_t_2435, 1ULL, 3);
    v_t_2471 = v_k_2460;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2435, 0ULL, 2);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2435, 0ULL, 1);
    v_t_2471 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  if (heff_intLe_c(MK_INT(0LL), v_t_2471)) {
    heff_drop(v_x_2434);
    V v_t_2472 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str1), heff_strAppend(v_x_2433, ((V)&g_heff_2eelab_2erules_2enotAFunction_str2)));
    V v_t_2473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2472, v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2475}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2476;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2477 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str3), heff_strAppend(v_x_2433, ((V)&g_heff_2eelab_2erules_2enotAFunction_str4)));
    V v_t_2478 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enotAFunction_str5), heff_strAppend(v_x_2434, ((V)&g_heff_2eelab_2erules_2enotAFunction_str6)));
    V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(302LL), NTAG(TAG_SError), v_t_2477, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2481}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2482;
    heff_room[1] = v_p_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2enotAFunction_lam0(V self, V *args) {
  V v_x_2433 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ecallee_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eelStrZ(v_e_240, heff_dup(v_ecallee_242), heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2enotAFunction_lam1, 1, 5, (V[]){v_ecallee_242, v_x_2433, v_sp_241, v_p_244, v_p_245})));
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V v_checksOnly_240, V v_sp_241, V v_callee_242, V v_arg_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0, 1, 4, (V[]){heff_dup(v_callee_242), v_sp_241, heff_dup(v_checksOnly_240), heff_dup(v_arg_243)})}});
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_arg_243 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_checksOnly_240; V a_1 = v_sp_241; V a_2 = v_arg_243; V a_3 = v_e_244; V a_4 = v_x_2412; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2eelab_2erules_2eelimGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_checksOnly_240); heff_drop(v_arg_243); r_; });
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_ecallee0_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_244), heff_dup(v_sp_241), v_ecallee0_2410, v_a0_2411, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam3, 1, 6, (V[]){v_checksOnly_240, v_sp_241, v_arg_243, v_e_244, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_arg_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam2, 1, 6, (V[]){v_e_244, v_sp_241, v_hd_247, v_checksOnly_240, v_arg_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_callee_242 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_checksOnly_240 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246;
  switch (heff_tag_of(v_callee_242)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_callee_242, 0);
    heff_take_n(v_callee_242, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_callee_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionElimC_24cpr_lam1, 2, 5, (V[]){v_c_246, v_e_244, v_sp_241, v_checksOnly_240, v_arg_243});
}
HEFF_LIT(g_heff_2eelab_2erules_2enameAtGo_str0, 1, "\?");
Clo g_heff_2eelab_2erules_2enameAtGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enameAtGo_entry, 2, 0};

V g_heff_2eelab_2erules_2enameAtGo(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2erules_2enameAtGo_str0);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intLe_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return heff_dup(v_x_242);
    } else {
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2enameAtGo(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str0, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str1, 48, "`, a resource of a `with`, cannot leave its body");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str2, 93, "` of the body alone: use it inside the body and return what it gives (a line, a count), not `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str3, 24, "` or anything holding it");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str4, 18, "`, in the region `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str5, 14, "` is of type `");
HEFF_LIT(g_heff_2eelab_2erules_2eresourceEscapes_str6, 1, "`");
V g_heff_2eelab_2erules_2eresourceEscapes_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eresourceEscapes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eresourceEscapes_entry, 7, 0};

V g_heff_2eelab_2erules_2eresourceEscapes(V v_e_240, V v_sp_241, V v_s_242, V v_x_243, V v_t_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2eelab_2erules_2etyStrZ(v_e_240, v_t_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2eresourceEscapes_lam0, 1, 5, (V[]){v_x_243, v_s_242, v_sp_241, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eresourceEscapes(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2eresourceEscapes_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_s_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str0), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str1)));
  V v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str2), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2eelab_2erules_2eresourceEscapes_str3)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str4), heff_strAppend(v_s_242, v_t_249));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str5), heff_strAppend(v_x_247, v_t_2410));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eresourceEscapes_str6), heff_strAppend(v_x_243, v_t_2411));
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_248, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2415}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  heff_room[0] = v_t_2416;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str0, 5, "unify");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str1, 8, "   FAILS");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str2, 5, "   ok");
HEFF_LIT(g_heff_2eelab_2erules_2eapplyGo_str3, 7, "  =\?=  ");
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2eapplyGo_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_lam5, 1, 0};
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eapplyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapplyGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eapplyGo(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_a_27_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = heff_dup(heff_rfield(v_e_241, 0));
    V v_len_249 = heff_take_field(v_c_248, 0);
    V v_names_2410 = heff_get_n(v_c_248, 1, 4);
    return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam0, 2, 5, (V[]){heff_dup(v_e_241), v_len_249, v_names_2410, heff_dup(v_a_242), heff_dup(v_a_27_247)}), heff_dup(v_p_244), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam1, 1, 7, (V[]){v_e_241, v_m_246, v_a_242, v_a_27_247, v_p_244, v_sp_240, v_p_245})));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eapplyGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eapplyGo_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_p_2412 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_len_249 = heff_env(self)[1];
  V v_names_2410 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){heff_get_n(v_e_241, 1, 6), heff_rec_n(2, shape_len__names, (V[]){v_len_249, v_names_2410}), v_a_242, v_a_27_247}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2413, v_p_2411, v_p_2412));
}
V g_heff_2eelab_2erules_2eapplyGo_lam2(V self, V *args) {
  V v_u_2416 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_m_246, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2418;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2420;
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam5(V self, V *args) {
  V v_c_2426 = args[0];
  return heff_get_n(v_c_2426, 3, 8);
}
V g_heff_2eelab_2erules_2eapplyGo_lam7(V self, V *args) {
  V v_u_2431 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2431);
  V v_t_2432 = (g_heff_2eelab_2erules_2einstShown(heff_dup(v_e_241), v_x_2430, v_a_242));
  V v_t_2433 = ({ V a_0 = v_e_241; V a_1 = v_x_2430; V a_2 = v_a_27_247; V r_ = (g_heff_2eelab_2erules_2einstShown(a_0, a_1, a_2)); heff_drop(v_x_2430); r_; });
  V v_t_2436;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    heff_take_n(v_x_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str1);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2eelab_2erules_2eapplyGo_str2);
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_t_2437 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eapplyGo_str3), heff_strAppend(v_t_2433, v_t_2436));
  return heff_strAppend(v_t_2432, v_t_2437);
}
V g_heff_2eelab_2erules_2eapplyGo_lam9(V self, V *args) {
  V v_x_2447 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_m_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2447);
  V f_ = v_p_245;
  args[0] = v_m_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapplyGo_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_27_247 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_sp_240 = heff_env(self)[4];
  V v_m_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2440);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_err_2441 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    V v_t_2442 = (g_heff_2eelab_2erules_2ecoeGoal(heff_dup(v_e_241), heff_dup(v_a_27_247), heff_dup(v_a_242)));
    return ({ V a_0 = v_e_241; V a_1 = v_sp_240; V a_2 = v_a_242; V a_3 = v_a_27_247; V a_4 = v_m_246; V a_5 = v_err_2441; V a_6 = v_t_2442; V a_7 = v_p_244; V a_8 = v_p_245; V r_ = (g_heff_2eelab_2erules_2ecoerced(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_err_2441); r_; });
  }
  case TAG_Right: {
    V v_ru_24x_2425_24Right = heff_take_reuse_n(v_x_2425, 0ULL, 1);
    heff_drop_rec(v_e_241, 6);
    heff_drop(v_a_27_247);
    heff_drop(v_a_242);
    heff_drop(v_sp_240);
    V v_t_2444 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tr(heff_call(heff_take_field(v_p_244, 2), 1, (V[]){v_t_2445}));
    V f_ = heff_get_n(v_p_244, 1, 3);
    heff_room[0] = v_t_2446;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam9, 1, 2, (V[]){v_p_245, v_m_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2eelab_2erules_2eapplyGo_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_m_246 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2438 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2eapplyGo_str0), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam7, 1, 5, (V[]){heff_dup(v_e_241), v_x_2430, heff_dup(v_a_242), heff_dup(v_a_27_247), heff_dup(v_x_2425)})}), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2439;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam8, 1, 8, (V[]){v_x_2425, v_e_241, v_a_27_247, v_a_242, v_sp_240, v_m_246, v_p_244, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_a_27_247 = heff_env(self)[4];
  V v_m_246 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eapplyGo_lam5_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){v_t_2428}));
  V f_ = heff_dup(heff_rfield(v_p_244, 1));
  heff_room[0] = v_t_2429;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam6, 1, 8, (V[]){v_sp_240, v_e_241, v_a_242, v_a_27_247, v_x_2425, v_p_244, v_m_246, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapplyGo_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_m_246 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  V v_a_27_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2424;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    v_t_2424 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2especialized_clo), 5, (V[]){heff_dup(v_e_241), heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam2, 1, 1, (V[]){heff_dup(v_m_246)}), heff_dup(v_a_242), heff_dup(v_a_27_247), heff_tag_n(TAG_Left, 1, (V[]){v_err_2415})}));
    break;
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    v_t_2424 = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam3, 2, 1, (V[]){v_x_2421});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_t_2424;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapplyGo_lam4, 1, 7, (V[]){v_p_244, v_sp_240, v_e_241, v_a_242, v_a_27_247, v_m_246, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimRune_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimRune_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimRune_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimRune_st;
static V g_heff_2eelab_2erules_2eprimRune_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimRune_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimRune_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimRune_st)) return g_heff_2eelab_2erules_2eprimRune_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimRune_val, &g_heff_2eelab_2erules_2eprimRune_st, g_heff_2eelab_2erules_2eprimRune_init);
}
V g_heff_2eelab_2erules_2eprimRune_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam0, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_lam2, 1, 0};
Clo g_heff_2eelab_2erules_2enumLitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitAt(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_247, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      V v_t_2418 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam0_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2418});
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24IntNum, 1);
      V v_t_2419 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_i_246))});
      return heff_tail(v_z_245, 1, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2419, ((V)&g_heff_2eelab_2erules_2enumLitAt_lam1_clo)})});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2422 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      HEFF_LAST return g_heff_2eelab_2erules_2eintAtFixed_24tok1(v_ru_24x4_243_24IntNum, v_sp_240, v_w_2422, v_i_246, v_z_244, v_z_245);
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_IntNum, 1, (V[]){v_i_246}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_FracNum: {
    double v_x_2423 = heff_tflat_f64(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_na(v_x4_243, 0ULL, 1);
    V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_242)));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2424, 0ULL, 4);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2424, 0ULL, 3);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeInt: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFloat: {
      heff_drop(v_sp_240);
      heff_drop(v_e_241);
      heff_drop(v_a_242);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
      V v_t_2435 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_x_2423)}), ((V)&g_heff_2eelab_2erules_2enumLitAt_lam2_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2435});
    }
    case TAG_LikeString: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeRune: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2424, 0ULL, 1);
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    case TAG_LikeFixed: {
      V v_w_2437 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      V v_t_2438;
      switch (heff_tag_of(v_w_2437)) {
      case TAG_I8: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I16: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I32: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_I64: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U8: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U16: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U32: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_U64: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_F32: {
        v_t_2438 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_w_2437);
      }
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_e_241);
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24x4_243_24FracNum, 1);
        heff_drop(v_t_2438);
        V v_t_2439 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_240, heff_floatShow(heff_box_f64(v_x_2423)), heff_box_f64(v_x_2423)));
        return heff_tail(v_t_2439, 2, (V[]){v_z_244, v_z_245});
      } else {
        heff_drop(v_t_2438);
        return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
      }
    }
    case TAG_NoRules: {
      return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_a_242; V b_3 = heff_tag_at_nf(v_ru_24x4_243_24FracNum, TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2423)}); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2eelab_2erules_2enotANumber(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitAt_lam0(V self, V *args) {
  V v_u_2417 = args[0];
  heff_drop(v_u_2417);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam1(V self, V *args) {
  V v_u_2420 = args[0];
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitAt_lam2(V self, V *args) {
  V v_u_2434 = args[0];
  heff_drop(v_u_2434);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
Clo g_heff_2eelab_2erules_2eappendP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_entry, 2, 0};

V g_heff_2eelab_2erules_2eappendP(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2erules_2eappendP_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP(a[0], a[1]);
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args);
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultFor_entry, 4, 0};

V g_heff_2eelab_2erules_2edefaultFor(V v_x1_240, V v_g_241, V v_vs_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_ForNominative: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_dup(v_d_243), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam0, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  case TAG_ForDescriptive: {
    return heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(v_d_243)}), heff_clo_n(g_heff_2eelab_2erules_2edefaultFor_lam1, 1, 3, (V[]){v_g_241, v_d_243, v_vs_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edefaultFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2edefaultFor(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2edefaultFor_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_244);
  return (g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
}
V g_heff_2eelab_2erules_2edefaultFor_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_247);
  V v_x1_248 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_241, NTAG(TAG_N), v_d_243, v_vs_242));
  V v_t_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_249;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_248, 0ULL, 1);
    v_t_2412 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2412});
}
Clo g_heff_2eelab_2erules_2evaluesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_entry, 5, 0};

V g_heff_2eelab_2erules_2evaluesGo(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_245);
      heff_drop(v_rest_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_pls_248 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_Nothing: {
        heff_drop(v_m_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_246;
        V t_3 = v_pls_248;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        goto top;
      }
      case TAG_Just: {
        V v_p_249 = heff_field(v_x41_247, 0);
        heff_take_n(v_x41_247, 1ULL, 1);
        V v_t_2410 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_249, heff_dup(v_places_241), heff_dup(v_m_245), heff_dup(v_i_244)));
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_245, v_t_2410}), heff_hole()});
        V v_u_2412 = (g_heff_2eelab_2erules_2evaluesGo_24dps(v_n_240, v_places_241, v_rest_246, v_pls_248, heff_intAdd(v_i_244, MK_INT(1LL)), heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2evaluesGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2eetaArg_24cpr(V v_sp_240, V v_l_241, V v_dom_242) {
top: ;
  return ({ V a_0 = v_sp_240; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eetaArg_24cpr_lam0, 3, 2, (V[]){v_l_241, v_dom_242})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam2(V self, V *args) {
  V v_u_249 = args[0];
  V v_dom_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return v_dom_242;
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_248);
  V v_t_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_l_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eetaArg_24cpr_lam2, 1, 1, (V[]){v_dom_242}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2410});
}
V g_heff_2eelab_2erules_2eetaArg_24cpr_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_hd_244 = args[1];
  V v_k_245 = args[2];
  V v_l_241 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V v_t_246 = heff_get_n(heff_get_n(v_e_243, 0, 6), 0, 4);
  V v_t_247 = heff_intSub(heff_intSub(v_t_246, heff_dup(v_l_241)), MK_INT(1LL));
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_t_247}), heff_clo_n(g_heff_2eelab_2erules_2eetaArg_24cpr_lam1, 1, 2, (V[]){v_l_241, heff_dup(v_dom_242)})});
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_dom_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str0, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str1, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str2, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str3, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str4, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str5, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str6, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str7, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str8, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str9, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str10, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str11, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str12, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str13, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str14, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str15, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str16, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str17, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str18, 5, "match");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str19, 34, "cannot match against non-sum type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str20, 46, "cannot eliminate from sum type into large type");
HEFF_LIT(g_heff_2eelab_2erules_2esumElim_str21, 46, "cannot eliminate from sum type into large type");
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam36(V self, V *args);
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2esumElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumElim_entry, 4, 0};

V g_heff_2eelab_2erules_2esumElim(V v_sp_240, V v_scrutSyn_241, V v_tags_242, V v_casesChk_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam0, 2, 4, (V[]){heff_dup(v_scrutSyn_241), v_sp_240, heff_dup(v_tags_242), v_casesChk_243})});
}
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2esumElim(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2esumElim_lam3(V self, V *args) {
  V v_c_2414 = args[0];
  V v_a0_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2414, 3, 8); V a_1 = v_a0_2413; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumElim_lam7(V self, V *args) {
  V v_u_2423 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam6(V self, V *args) {
  V v_u_2422 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2422);
  V v_t_2424 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam7, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2424});
}
V g_heff_2eelab_2erules_2esumElim_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2421) == NTAG(TAG_True))) {
    heff_drop(v_x_2421);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_2425 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam6, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2421);
    V v_t_2448;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2427 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_2427)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2427, 0ULL, 1);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2427, 0ULL, 1);
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2427, 0ULL, 1);
        v_t_2448 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2448 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2427);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
      heff_drop(v_t_2448);
      V v_t_2449 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str0); V a_3 = v_t_2449; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2449); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_2448);
      V v_t_2450 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_2451 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str1), v_t_2450);
      V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2451, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      V v_t_2455 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2454}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_2455;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam10(V self, V *args) {
  V v_u_2462 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2462);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam9(V self, V *args) {
  V v_u_2461 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2461);
  V v_t_2463 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam10, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2463});
}
V g_heff_2eelab_2erules_2esumElim_lam8(V self, V *args) {
  V v_x_2460 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2460) == NTAG(TAG_True))) {
    heff_drop(v_x_2460);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_2464 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam9, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_2464;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2460);
    V v_t_2487;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2466 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_2466)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2466, 0ULL, 1);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2466, 0ULL, 1);
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2466, 0ULL, 1);
        v_t_2487 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2487 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2466);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2487 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
      heff_drop(v_t_2487);
      V v_t_2488 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str2); V a_3 = v_t_2488; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2488); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_2487);
      V v_t_2489 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_2490 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str3), v_t_2489);
      V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_2490, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2493}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_2494;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam13(V self, V *args) {
  V v_u_24100 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24100);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam12(V self, V *args) {
  V v_u_2499 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2499);
  V v_t_24101 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam13, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24101});
}
V g_heff_2eelab_2erules_2esumElim_lam11(V self, V *args) {
  V v_x_2498 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2498) == NTAG(TAG_True))) {
    heff_drop(v_x_2498);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24102 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam12, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24102;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2498);
    V v_t_24125;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24104 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24104)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24104, 0ULL, 1);
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24104, 0ULL, 1);
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24104, 0ULL, 1);
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24104);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24125 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
      heff_drop(v_t_24125);
      V v_t_24126 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str4); V a_3 = v_t_24126; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24126); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24125);
      V v_t_24127 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24128 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str5), v_t_24127);
      V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24128, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24130 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24129})});
      V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
      V v_t_24132 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24131}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24132;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam16(V self, V *args) {
  V v_u_24136 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24136);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam15(V self, V *args) {
  V v_u_24135 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24135);
  V v_t_24137 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam16, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24137});
}
V g_heff_2eelab_2erules_2esumElim_lam14(V self, V *args) {
  V v_x_24134 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24134) == NTAG(TAG_True))) {
    heff_drop(v_x_24134);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24138 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam15, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24138;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24134);
    V v_t_24161;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24140 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24140)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24140, 0ULL, 1);
        v_t_24161 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24140, 0ULL, 1);
        v_t_24161 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24140, 0ULL, 1);
        v_t_24161 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24161 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24140);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24161 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24161) == NTAG(TAG_True))) {
      heff_drop(v_t_24161);
      V v_t_24162 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str6); V a_3 = v_t_24162; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24162); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24161);
      V v_t_24163 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24164 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str7), v_t_24163);
      V v_t_24165 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24164, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24166 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24165})});
      V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
      V v_t_24168 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24167}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24168;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam19(V self, V *args) {
  V v_u_24171 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24171);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam18(V self, V *args) {
  V v_u_24170 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24170);
  V v_t_24172 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam19, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24172});
}
V g_heff_2eelab_2erules_2esumElim_lam17(V self, V *args) {
  V v_x_24169 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24169) == NTAG(TAG_True))) {
    heff_drop(v_x_24169);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24173 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam18, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24173;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24169);
    V v_t_24196;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24175 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24175)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24175, 0ULL, 1);
        v_t_24196 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24175, 0ULL, 1);
        v_t_24196 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24175, 0ULL, 1);
        v_t_24196 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24196 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24175);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24196 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24196) == NTAG(TAG_True))) {
      heff_drop(v_t_24196);
      V v_t_24197 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str8); V a_3 = v_t_24197; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24197); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24196);
      V v_t_24198 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24199 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str9), v_t_24198);
      V v_t_24200 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24199, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24201 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24200})});
      V v_t_24202 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24201})});
      V v_t_24203 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24202}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24203;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam22(V self, V *args) {
  V v_u_24206 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24206);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam21(V self, V *args) {
  V v_u_24205 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24205);
  V v_t_24207 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam22, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24207});
}
V g_heff_2eelab_2erules_2esumElim_lam20(V self, V *args) {
  V v_x_24204 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24204) == NTAG(TAG_True))) {
    heff_drop(v_x_24204);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24208 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam21, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24208;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24204);
    V v_t_24231;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24210 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24210)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24210, 0ULL, 1);
        v_t_24231 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24210, 0ULL, 1);
        v_t_24231 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24210, 0ULL, 1);
        v_t_24231 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24231 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24210);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24231 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24231) == NTAG(TAG_True))) {
      heff_drop(v_t_24231);
      V v_t_24232 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str10); V a_3 = v_t_24232; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24232); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24231);
      V v_t_24233 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24234 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str11), v_t_24233);
      V v_t_24235 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24234, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24236 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24235})});
      V v_t_24237 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24236})});
      V v_t_24238 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24237}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24238;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam25(V self, V *args) {
  V v_u_24241 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24241);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam24(V self, V *args) {
  V v_u_24240 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24240);
  V v_t_24242 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam25, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24242});
}
V g_heff_2eelab_2erules_2esumElim_lam23(V self, V *args) {
  V v_x_24239 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24239) == NTAG(TAG_True))) {
    heff_drop(v_x_24239);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24243 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam24, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24239);
    V v_t_24266;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24245 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24245)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24245, 0ULL, 1);
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24245, 0ULL, 1);
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24245, 0ULL, 1);
        v_t_24266 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24245);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24266) == NTAG(TAG_True))) {
      heff_drop(v_t_24266);
      V v_t_24267 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str12); V a_3 = v_t_24267; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24267); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24266);
      V v_t_24268 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24269 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str13), v_t_24268);
      V v_t_24270 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24269, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24271 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24270})});
      V v_t_24272 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24271})});
      V v_t_24273 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24272}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24273;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam28(V self, V *args) {
  V v_u_24277 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24277);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam27(V self, V *args) {
  V v_u_24276 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24276);
  V v_t_24278 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam28, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24278});
}
V g_heff_2eelab_2erules_2esumElim_lam26(V self, V *args) {
  V v_x_24275 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24275) == NTAG(TAG_True))) {
    heff_drop(v_x_24275);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24279 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam27, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24279;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24275);
    V v_t_24302;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24281 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24281)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24281, 0ULL, 1);
        v_t_24302 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24281, 0ULL, 1);
        v_t_24302 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24281, 0ULL, 1);
        v_t_24302 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24302 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24281);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24302) == NTAG(TAG_True))) {
      heff_drop(v_t_24302);
      V v_t_24303 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str14); V a_3 = v_t_24303; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24303); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24302);
      V v_t_24304 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24305 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str15), v_t_24304);
      V v_t_24306 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24305, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24307 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24306})});
      V v_t_24308 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24307})});
      V v_t_24309 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24308}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24309;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam31(V self, V *args) {
  V v_u_24313 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24313);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam30(V self, V *args) {
  V v_u_24312 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24312);
  V v_t_24314 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam31, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24314});
}
V g_heff_2eelab_2erules_2esumElim_lam29(V self, V *args) {
  V v_x_24311 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24311) == NTAG(TAG_True))) {
    heff_drop(v_x_24311);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24315 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam30, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24315;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24311);
    V v_t_24338;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24317 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24317)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24317, 0ULL, 1);
        v_t_24338 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24317, 0ULL, 1);
        v_t_24338 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24317, 0ULL, 1);
        v_t_24338 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24338 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24317);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24338 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24338) == NTAG(TAG_True))) {
      heff_drop(v_t_24338);
      V v_t_24339 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str16); V a_3 = v_t_24339; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24339); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24338);
      V v_t_24340 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24341 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str17), v_t_24340);
      V v_t_24342 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24341, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24343 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24342})});
      V v_t_24344 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24343})});
      V v_t_24345 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24344}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24345;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam34(V self, V *args) {
  V v_u_24348 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24348);
  return v_b_245;
}
V g_heff_2eelab_2erules_2esumElim_lam33(V self, V *args) {
  V v_u_24347 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24347);
  V v_t_24349 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam34, 1, 1, (V[]){v_b_245}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24349});
}
V g_heff_2eelab_2erules_2esumElim_lam32(V self, V *args) {
  V v_x_24346 = args[0];
  V v_b_245 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  V v_hd_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_24346) == NTAG(TAG_True))) {
    heff_drop(v_x_24346);
    heff_drop(v_x_2418);
    heff_drop(v_sp_240);
    heff_drop(v_scrut_2412);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    heff_drop(v_e_244);
    heff_drop_rec(v_hd_249, 3);
    V v_t_24350 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam33, 1, 1, (V[]){v_b_245})});
    V f_ = v_k_2410;
    args[0] = v_t_24350;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_24346);
    V v_t_24373;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_VU: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24352 = heff_dup(heff_field(v_x_2418, 0));
      switch (heff_tag_of(v_t1_24352)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24352, 0ULL, 1);
        v_t_24373 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24352, 0ULL, 1);
        v_t_24373 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24352, 0ULL, 1);
        v_t_24373 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24373 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24352);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24373 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    if ((heff_dup(v_t_24373) == NTAG(TAG_True))) {
      heff_drop(v_t_24373);
      V v_t_24374 = ({ V a_0 = heff_dup(v_sp_240); V a_1 = v_scrut_2412; V a_2 = heff_dup(v_x_2418); V a_3 = v_tags_242; V a_4 = v_casesChk_243; V r_ = (g_heff_2eelab_2erules_2ematchLater(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tags_242); r_; });
      return ({ V a_0 = v_e_244; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2esumElim_str18); V a_3 = v_t_24374; V a_4 = v_x_2418; V a_5 = v_b_245; V a_6 = v_hd_249; V a_7 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_24374); r_; });
    } else {
      heff_drop(v_b_245);
      heff_drop(v_scrut_2412);
      heff_drop(v_tags_242);
      heff_drop(v_casesChk_243);
      heff_drop(v_t_24373);
      V v_t_24375 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2418));
      V v_msg_24376 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumElim_str19), v_t_24375);
      V v_t_24377 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(318LL), NTAG(TAG_SError), v_msg_24376, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24378 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24377})});
      V v_t_24379 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24378})});
      V v_t_24380 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_24379}));
      V f_ = heff_get_n(v_hd_249, 1, 3);
      heff_room[0] = v_t_24380;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2erules_2esumElim_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_scrut_2412 = heff_env(self)[4];
  V v_tags_242 = heff_env(self)[5];
  V v_casesChk_243 = heff_env(self)[6];
  V v_e_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2419 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2418)));
  switch (heff_tag_of(v_t_2419)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2419, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam5, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2419, 0ULL, 4);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam8, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2419, 0ULL, 3);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam11, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeSum: {
    V v_vs_24133 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_244; V a_2 = v_b_245; V a_3 = v_scrut_2412; V a_4 = v_x_2418; V a_5 = v_vs_24133; V a_6 = v_tags_242; V a_7 = v_casesChk_243; V a_8 = v_hd_249; V a_9 = v_k_2410; V r_ = (g_heff_2eelab_2erules_2ecasesAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_tags_242); r_; });
  }
  case TAG_LikeInt: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam14, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeFloat: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam17, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeString: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam20, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeRune: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam23, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2419, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam26, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2419, 0ULL, 1);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam29, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  case TAG_NoRules: {
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2418), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam32, 1, 9, (V[]){v_b_245, v_k_2410, v_x_2418, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244, v_hd_249})));
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_tags_242 = heff_env(self)[4];
  V v_casesChk_243 = heff_env(self)[5];
  V v_e_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_scrut_2412 = heff_field(v_x_2411, 0);
    V v_a0_2413 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam3, 1, 1, (V[]){v_a0_2413})})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2416}));
    V f_ = heff_dup(heff_rfield(v_hd_249, 1));
    heff_room[0] = v_t_2417;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam4, 1, 8, (V[]){v_hd_249, v_b_245, v_k_2410, v_sp_240, v_scrut_2412, v_tags_242, v_casesChk_243, v_e_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eelab_2erules_2esumElim_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_tags_242 = heff_env(self)[3];
  V v_casesChk_243 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam2, 1, 7, (V[]){v_hd_249, v_b_245, v_k_2410, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam35(V self, V *args) {
  V v_hd_24381 = args[0];
  V v_k2_24382 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24383 = heff_take_field(v_hd_24381, 1);
  V v_malg_24384 = heff_get_n(v_hd_24381, 2, 3);
  V v_t_24385 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str20), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24386 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24385})});
  V v_t_24387 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24386})});
  V v_t_24388 = heff_tr(heff_call(v_malg_24384, 1, (V[]){v_t_24387}));
  V f_ = v_bind_24383;
  args[0] = v_t_24388;
  args[1] = v_k2_24382;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam36(V self, V *args) {
  V v_hd_24389 = args[0];
  V v_k2_24390 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24391 = heff_take_field(v_hd_24389, 1);
  V v_malg_24392 = heff_get_n(v_hd_24389, 2, 3);
  V v_t_24393 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(323LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2esumElim_str21), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24394 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24393})});
  V v_t_24395 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24394})});
  V v_t_24396 = heff_tr(heff_call(v_malg_24392, 1, (V[]){v_t_24395}));
  V f_ = v_bind_24391;
  args[0] = v_t_24396;
  args[1] = v_k2_24390;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumElim_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tags_242 = heff_env(self)[2];
  V v_casesChk_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_246 = (g_heff_2eelab_2evalue_2elevelOf(v_b_245));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Small: {
    V v_c_248;
    switch (heff_tag_of(v_scrutSyn_241)) {
    case TAG_MkSyn: {
      V v_f_247 = heff_field(v_scrutSyn_241, 0);
      heff_take_n(v_scrutSyn_241, 1ULL, 1);
      v_c_248 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_dup(v_e_244)}));
      break;
    }
    default: heff_nomatch(v_scrutSyn_241);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam1, 2, 6, (V[]){v_c_248, v_b_245, v_sp_240, v_tags_242, v_casesChk_243, v_e_244});
  }
  case TAG_Large: {
    heff_drop(v_e_244);
    heff_drop(v_b_245);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam35, 2, 1, (V[]){v_sp_240});
  }
  case TAG_TopL: {
    heff_drop(v_e_244);
    heff_drop(v_b_245);
    heff_drop(v_scrutSyn_241);
    heff_drop(v_tags_242);
    heff_drop(v_casesChk_243);
    return heff_clo_n(g_heff_2eelab_2erules_2esumElim_lam36, 2, 1, (V[]){v_sp_240});
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2eelab_2erules_2efirstElab_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efirstElab_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efirstElab_entry, 3, 0};

V g_heff_2eelab_2erules_2efirstElab(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_ms_244 = heff_field(v_x1_240, 1);
    return heff_tail(heff_dup(v_m_243), 2, (V[]){heff_dup(v_p_241), heff_clo_n(g_heff_2eelab_2erules_2efirstElab_lam0, 1, 3, (V[]){heff_dup(v_ms_244), v_p_241, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2efirstElab_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2efirstElab(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2efirstElab_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_ms_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    return ({ V a_0 = v_ms_244; V a_1 = v_p_241; V a_2 = v_p_242; V r_ = (g_heff_2eelab_2erules_2efirstElab(a_0, a_1, a_2)); heff_drop(v_ms_244); r_; });
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    heff_drop(v_ms_244);
    heff_drop(v_p_241);
    V f_ = v_p_242;
    args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_245);
  }
}
Clo g_heff_2eelab_2erules_2efind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efind_entry, 2, 0};

V g_heff_2eelab_2erules_2efind(V v_sp_240, V v_x_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2efind_24cpr(v_sp_240, v_x_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2efind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efind(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry, 2, 0};

V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V v_tok_240, V v_c_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(v_c_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_at_n(v_tok_240, TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eimplicitLams_24tok1(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str0, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str1, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str2, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str3, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str4, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str5, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str6, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str7, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str8, 7, "Float32");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str9, 4, " to ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str10, 19, ", whose values are ");
HEFF_LIT(g_heff_2eelab_2erules_2eintAtFixed_24tok1_str11, 21, " is out of range for ");
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2eintAtFixed_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eintAtFixed_24tok1_entry, 6, 0};

V g_heff_2eelab_2erules_2eintAtFixed_24tok1(V v_tok_240, V v_sp_241, V v_w_242, V v_i_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_w_242)) {
  case TAG_I8: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_w_242);
    heff_drop(v_t_246);
    V v_t_247 = (g_heff_2eelab_2erules_2eatFloat32(v_sp_241, heff_intShow(heff_dup(v_i_243)), heff_box_f64(heff_from_int_f64(v_i_243))));
    return heff_tail(v_t_247, 2, (V[]){v_z_244, v_z_245});
  } else {
    heff_drop(v_t_246);
    V v_t_248 = (g_heff_2eelab_2efixed_2efixedMin(v_w_242));
    if ((heff_intLe_c_lent(v_t_248, v_i_243, 0) && ({ V v_t_2422 = (g_heff_2eelab_2efixed_2efixedMax(v_w_242)); int c_ = heff_intLe_c_lent(v_i_243, v_t_2422, 0); heff_drop(v_t_2422); c_; }))) {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_sp_241);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_248);
      V v_t_2410 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitFixed, 2, (V[]){v_w_242, v_i_243}), ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0_clo)});
      return heff_tail(v_z_245, 1, (V[]){v_t_2410});
    } else {
      heff_drop(v_t_248);
      V v_t_2411;
      switch (heff_tag_of(v_w_242)) {
      case TAG_I8: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str0);
        break;
      }
      case TAG_I16: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str1);
        break;
      }
      case TAG_I32: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str2);
        break;
      }
      case TAG_I64: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str3);
        break;
      }
      case TAG_U8: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str4);
        break;
      }
      case TAG_U16: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str5);
        break;
      }
      case TAG_U32: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str6);
        break;
      }
      case TAG_U64: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str7);
        break;
      }
      case TAG_F32: {
        v_t_2411 = ((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str8);
        break;
      }
      default: heff_nomatch(v_w_242);
      }
      V v_t_2412 = (g_heff_2eelab_2efixed_2efixedMin(v_w_242));
      V v_t_2413 = ({ V a_0 = v_w_242; V r_ = (g_heff_2eelab_2efixed_2efixedMax(a_0)); heff_drop(v_w_242); r_; });
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str9), heff_intShow(v_t_2413));
      V v_t_2415 = heff_strAppend(heff_intShow(v_t_2412), v_t_2414);
      V v_why_2416 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str10), v_t_2415));
      V v_t_2417 = heff_strAppend(heff_intShow(v_i_243), heff_strAppend(((V)&g_heff_2eelab_2erules_2eintAtFixed_24tok1_str11), v_why_2416));
      V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), v_t_2417, v_sp_241, NTAG(TAG_Nothing)});
      V v_t_2419 = heff_tag_at_n(v_tok_240, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){v_t_2420}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2421, v_z_245});
    }
  }
}
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eintAtFixed_24tok1(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_lam0(V self, V *args) {
  V v_u_249 = args[0];
  heff_drop(v_u_249);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}